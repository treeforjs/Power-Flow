#include "raikou/kinetic_transport.h"
#include <algorithm>
#include <cmath>
#include <map>
#include <stdexcept>

namespace raikou::kinetics {
namespace {
[[noreturn]] void invalid(const std::string& value) { throw std::invalid_argument("kinetic streaming: " + value); }
constexpr double charge = 1.602176634e-19, mass = 9.1093837015e-31;
bool same_grid(const EedfGrid& left, const EedfGrid& right) {
    return left.cells == right.cells && left.max_energy_ev == right.max_energy_ev && left.power == right.power && left.legendre_terms == right.legendre_terms;
}
// Half-range angular integrals give the exact Galerkin |Omega.n| dissipation.
// Their integrands after azimuthal integration are polynomials of degree <=2L-1.
struct UpwindAngular {
    int terms;
    std::vector<std::vector<double>> absolute;
    explicit UpwindAngular(int count) : terms(count), absolute(static_cast<std::size_t>(count)) {
        const auto nodes = spherical_quadrature(count);
        const int np = 2 * count + 1;
        for (int m = 0; m < count; ++m) absolute[static_cast<std::size_t>(m)].assign(static_cast<std::size_t>((count-m)*(count-m)),0);
        for (int i = 0; i < count + 1; ++i) {
            const auto& original = nodes[static_cast<std::size_t>(i*np)];
            const double mu = (original.direction[2] + 1) / 2;
            const auto basis = real_spherical_harmonics(count, {std::sqrt(std::max(0.0,1-mu*mu)),0,mu});
            const double weight = original.weight * np / 2;
            for (int m = 0; m < count; ++m) for (int l = m; l < count; ++l) for (int other = m; other < count; ++other) {
                if ((l + other) % 2 != 0) continue;
                absolute[static_cast<std::size_t>(m)][static_cast<std::size_t>((l-m)*(count-m)+other-m)] +=
                    2 * weight * mu * (m == 0 ? 1 : 0.5) * basis[spherical_index(l,m)] * basis[spherical_index(other,m)];
            }
        }
    }
    double at(int l,int other,int m) const {
        return absolute[static_cast<std::size_t>(m)][static_cast<std::size_t>((l-m)*(terms-m)+other-m)];
    }
};
struct Radial {
    std::size_t cells;
    std::vector<double> edges,centres,cell_mass,dual_mass,cell_velocity,dual_velocity;
    explicit Radial(const EedfGrid& grid) : cells(static_cast<std::size_t>(grid.cells)),edges(cells+1),centres(cells),
        cell_mass(cells),dual_mass(cells,0),cell_velocity(cells),dual_velocity(cells,0) {
        for (std::size_t i=0;i<=cells;++i) edges[i]=grid.max_energy_ev*std::pow(static_cast<double>(i)/grid.cells,grid.power);
        for (std::size_t i=0;i<cells;++i) {
            centres[i]=0.5*(edges[i]+edges[i+1]);
            cell_mass[i]=2.0/3*(std::pow(edges[i+1],1.5)-std::pow(edges[i],1.5));
            cell_velocity[i]=(edges[i+1]*edges[i+1]-edges[i]*edges[i])/(2*cell_mass[i]);
        }
        for (std::size_t i=0;i+1<cells;++i) {
            dual_mass[i]=2.0/3*(std::pow(centres[i+1],1.5)-std::pow(centres[i],1.5));
            dual_velocity[i]=edges[i+1]*(centres[i+1]-centres[i])/dual_mass[i];
        }
    }
    // v/gamma overlap between an even cell i and the odd face k=i or i+1.
    double odd_to_cell(std::span<const double> values,std::size_t stride,std::size_t i,std::size_t mode) const {
        double value=0;
        if(i>0) value+=edges[i]*(edges[i]-centres[i-1])*values[(i-1)*stride+mode];
        if(i+1<cells) value+=edges[i+1]*(centres[i+1]-edges[i+1])*values[i*stride+mode];
        return value/cell_mass[i];
    }
    double cell_to_odd(std::span<const double> values,std::size_t stride,std::size_t i,std::size_t mode) const {
        if(i+1>=cells)return 0;
        const double e=edges[i+1];
        return e*((centres[i+1]-e)*values[i*stride+mode]+(e-centres[i])*values[(i+1)*stride+mode])/dual_mass[i];
    }
};
} // namespace

KineticStreamingResult kinetic_streaming_rhs(const KineticMesh& mesh,const std::vector<SphericalEedfState>& states,std::size_t threads) {
    if(states.empty() || states.size()!=mesh.cell_volumes_m3.size())invalid("cell state/volume dimensions differ or are empty");
    const auto& grid=states.front().grid;
    const int terms=grid.legendre_terms;
    const auto stride=static_cast<std::size_t>(terms*terms),size=static_cast<std::size_t>(grid.cells)*stride;
    for(std::size_t c=0;c<states.size();++c) {
        states[c].validate();
        if(!same_grid(grid,states[c].grid) || states[c].time_s!=states.front().time_s)invalid("all cells must share an energy/angular grid and time");
        if(!(mesh.cell_volumes_m3[c]>0 && std::isfinite(mesh.cell_volumes_m3[c])))invalid("cell volumes must be finite and positive");
    }
    const Radial radial(grid);
    const UpwindAngular angular(terms);
    const double gamma=std::sqrt(2*charge/mass);
    KineticStreamingResult result;
    result.density_mode_rates.assign(states.size(),std::vector<double>(size,0));
    std::vector<double> adjacent_area(states.size(),0);
    for(const auto& face:mesh.faces) {
        const bool interior=face.right!=std::numeric_limits<std::size_t>::max();
        if(face.left>=states.size() || (interior && (face.right>=states.size() || face.right==face.left)))invalid("invalid face cell indices");
        if(!(face.area_m2>0 && std::isfinite(face.area_m2)))invalid("face area must be finite and positive");
        const double normal_length=std::hypot(face.normal[0],face.normal[1],face.normal[2]);
        if(!std::isfinite(normal_length) || std::abs(normal_length-1)>1e-10)invalid("face normal must be a unit vector");
        adjacent_area[face.left]+=face.area_m2;
        if(interior)adjacent_area[face.right]+=face.area_m2;
        if(!interior && face.wall==KineticWall::PrescribedIncoming) {
            if(!face.incoming)invalid("incoming boundary distribution is missing");
            face.incoming->validate();
            if(!same_grid(grid,face.incoming->grid))invalid("incoming boundary grid differs");
        }
        const auto rotation=rotation_to_axis(face.normal);
        const HarmonicRotation to_normal(terms,inverse_rotation(rotation)),to_global(terms,rotation);
        std::vector<double> left(size),right(size,0),sum(size),jump(size),flux(size,0),global_flux(size);
        backend::parallel_for(radial.cells,threads,[&](std::size_t i) {
            const auto offset=i*stride;
            to_normal.apply(std::span<const double>(states[face.left].density_modes).subspan(offset,stride),std::span<double>(left).subspan(offset,stride));
            if(interior) to_normal.apply(std::span<const double>(states[face.right].density_modes).subspan(offset,stride),std::span<double>(right).subspan(offset,stride));
            else if(face.wall==KineticWall::PrescribedIncoming)
                to_normal.apply(std::span<const double>(face.incoming->density_modes).subspan(offset,stride),std::span<double>(right).subspan(offset,stride));
            else if(face.wall==KineticWall::Specular) for(int l=0;l<terms;++l)for(int m=-l;m<=l;++m)
                right[offset+spherical_index(l,m)]=((l+m)%2 ? -1.0:1.0)*left[offset+spherical_index(l,m)];
            for(std::size_t mode=0;mode<stride;++mode) {
                sum[offset+mode]=left[offset+mode]+right[offset+mode];
                jump[offset+mode]=left[offset+mode]-right[offset+mode];
            }
        });
        backend::parallel_for(radial.cells,threads,[&](std::size_t i) {
            const auto offset=i*stride;
            for(int l=0;l<terms;++l)for(int order=-l;order<=l;++order) {
                const int m=std::abs(order);
                if(l%2!=0 && i+1==radial.cells)continue;
                const auto mode=spherical_index(l,order);
                const auto overlap=[&](int degree) {
                    const auto input_mode=spherical_index(degree,order);
                    return l%2==0 ? radial.odd_to_cell(sum,stride,i,input_mode) : radial.cell_to_odd(sum,stride,i,input_mode);
                };
                double central=0;
                if(l>m)central+=std::sqrt(static_cast<double>(l*l-m*m)/((2*l-1.0)*(2*l+1.0)))*overlap(l-1);
                if(l+1<terms)central+=std::sqrt(static_cast<double>((l+1)*(l+1)-m*m)/((2*l+1.0)*(2*l+3.0)))*overlap(l+1);
                double dissipative=0;
                for(int other=m;other<terms;++other)if((l+other)%2==0)
                    dissipative+=angular.at(l,other,m)*jump[offset+spherical_index(other,order)];
                const double velocity=l%2==0 ? radial.cell_velocity[i] : radial.dual_velocity[i];
                flux[offset+mode]=0.5*gamma*(central+velocity*dissipative);
            }
            to_global.apply(std::span<const double>(flux).subspan(offset,stride),std::span<double>(global_flux).subspan(offset,stride));
        });
        double particles=0,energy=0;
        for(std::size_t i=0;i<radial.cells;++i) {
            particles+=radial.cell_mass[i]*global_flux[i*stride];
            energy+=radial.centres[i]*radial.cell_mass[i]*global_flux[i*stride];
        }
        result.face_particle_flux_m2_s.push_back(particles);
        result.face_energy_flux_ev_m2_s.push_back(energy);
        if(!interior) {
            result.outward_particle_rate_s+=face.area_m2*particles;
            result.outward_energy_rate_ev_s+=face.area_m2*energy;
        }
        for(std::size_t mode=0;mode<size;++mode) {
            result.density_mode_rates[face.left][mode]-=face.area_m2/mesh.cell_volumes_m3[face.left]*global_flux[mode];
            if(interior)result.density_mode_rates[face.right][mode]+=face.area_m2/mesh.cell_volumes_m3[face.right]*global_flux[mode];
        }
    }
    result.maximum_explicit_step_s=std::numeric_limits<double>::infinity();
    const double speed=gamma*std::sqrt(grid.max_energy_ev);
    for(std::size_t cell=0;cell<states.size();++cell)if(adjacent_area[cell]>0)
        result.maximum_explicit_step_s=std::min(result.maximum_explicit_step_s,0.2*mesh.cell_volumes_m3[cell]/(speed*adjacent_area[cell]*(terms+1)));
    return result;
}

KineticStreamingOperator assemble_kinetic_streaming(const KineticMesh& mesh,const EedfGrid& grid,backend::RowPartition owned) {
    const Radial radial(grid);const UpwindAngular angular(grid.legendre_terms);
    const int terms=grid.legendre_terms;
    const auto stride=static_cast<std::size_t>(terms*terms),cell_size=radial.cells*stride;
    if(owned.global_rows!=mesh.cell_volumes_m3.size()*cell_size || owned.row_begin+owned.local_rows>owned.global_rows)invalid("streaming row partition differs from mesh");
    KineticStreamingOperator result;result.affine_rates.assign(owned.local_rows,0);
    std::vector<std::map<backend::GlobalIndex,double>> rows(owned.local_rows);
    const double gamma=std::sqrt(2*charge/mass);
    const auto add=[&](backend::GlobalIndex row,backend::GlobalIndex column,double value){
        if(row>=owned.row_begin&&row-owned.row_begin<owned.local_rows&&value!=0)rows[static_cast<std::size_t>(row-owned.row_begin)][column]+=value;
    };
    for(const auto& face:mesh.faces){
        const bool interior=face.right!=std::numeric_limits<std::size_t>::max();
        if(face.left>=mesh.cell_volumes_m3.size()||(interior&&face.right>=mesh.cell_volumes_m3.size()))invalid("streaming face index outside mesh");
        const auto is_owned=[&](std::size_t c){const auto begin=static_cast<backend::GlobalIndex>(c)*cell_size,end=begin+cell_size;return begin<owned.row_begin+owned.local_rows&&end>owned.row_begin;};
        if(!is_owned(face.left)&&!(interior&&is_owned(face.right)))continue;
        if(!(face.area_m2>0&&std::isfinite(face.area_m2)))invalid("invalid streaming face area");
        const HarmonicRotation transform(terms,rotation_to_axis(face.normal));
        const auto& blocks=transform.blocks();const auto& offsets=transform.offsets();
        const auto d=[&](int l,int a,int b){return blocks[offsets[static_cast<std::size_t>(l)]+static_cast<std::size_t>((a+l)*(2*l+1)+b+l)];};
        const bool specular=!interior&&face.wall==KineticWall::Specular;
        for(int l=0;l<terms;++l)for(int k=0;k<terms;++k){
            if(std::abs(l-k)!=1&&(l+k)%2!=0)continue;
            const int bound=std::min(l,k);
            for(int output=-l;output<=l;++output)for(int input=-k;input<=k;++input){
                double central=0,dissipative=0;
                for(int order=-bound;order<=bound;++order){
                    const int m=std::abs(order);
                    const double rotation=d(l,output,order)*d(k,input,order);
                    const double reflection=(k+order)%2?-1.0:1.0;
                    if(std::abs(l-k)==1){
                        const int high=std::max(l,k);
                        central+=rotation*std::sqrt(static_cast<double>(high*high-m*m)/((2*high-1.0)*(2*high+1.0)))*(specular?1+reflection:1);
                    }
                    if((l+k)%2==0)dissipative+=rotation*angular.at(l,k,m)*(specular?1-reflection:1);
                }
                if(std::abs(central)<1e-14)central=0;
                if(std::abs(dissipative)<1e-14)dissipative=0;
                if(central==0&&dissipative==0)continue;
                for(std::size_t i=0;i<radial.cells;++i){
                    if(l%2!=0&&i+1==radial.cells)continue;
                    const auto out=i*stride+spherical_index(l,output),in=spherical_index(k,input);
                    const auto emit=[&](std::size_t j,double radial_central,double radial_dissipative){
                        const auto left_column=static_cast<backend::GlobalIndex>(face.left)*cell_size+j*stride+in;
                        const auto right_column=interior?static_cast<backend::GlobalIndex>(face.right)*cell_size+j*stride+in:0;
                        const double left_value=0.5*gamma*(central*radial_central+dissipative*radial_dissipative);
                        const double right_value=0.5*gamma*(central*radial_central-dissipative*radial_dissipative);
                        for(int side=0;side<(interior?2:1);++side){
                            const auto cell=side==0?face.left:face.right;
                            const double scale=(side==0?-1.0:1.0)*face.area_m2/mesh.cell_volumes_m3[cell];
                            const auto row=static_cast<backend::GlobalIndex>(cell)*cell_size+out;
                            add(row,left_column,scale*left_value);
                            if(interior)add(row,right_column,scale*right_value);
                        }
                    };
                    if(central!=0){
                        if(l%2==0){
                            if(i>0)emit(i-1,radial.edges[i]*(radial.edges[i]-radial.centres[i-1])/radial.cell_mass[i],0);
                            if(i+1<radial.cells)emit(i,radial.edges[i+1]*(radial.centres[i+1]-radial.edges[i+1])/radial.cell_mass[i],0);
                        }else{
                            const double e=radial.edges[i+1];
                            emit(i,e*(radial.centres[i+1]-e)/radial.dual_mass[i],0);
                            emit(i+1,e*(e-radial.centres[i])/radial.dual_mass[i],0);
                        }
                    }
                    if(dissipative!=0)emit(i,0,l%2==0?radial.cell_velocity[i]:radial.dual_velocity[i]);
                }
            }
        }
        if(!interior&&face.wall==KineticWall::PrescribedIncoming){
            if(!face.incoming)invalid("missing prescribed incoming distribution");
            SphericalEedfState zero;zero.grid=grid;zero.time_s=face.incoming->time_s;zero.density_modes.assign(cell_size,0);
            auto boundary=face;boundary.left=0;
            const auto affine=kinetic_streaming_rhs({{mesh.cell_volumes_m3[face.left]},{boundary}},{zero});
            for(std::size_t q=0;q<cell_size;++q){const auto row=static_cast<backend::GlobalIndex>(face.left)*cell_size+q;if(row>=owned.row_begin&&row-owned.row_begin<owned.local_rows)result.affine_rates[static_cast<std::size_t>(row-owned.row_begin)]+=affine.density_mode_rates[0][q];}
        }
    }
    auto& matrix=result.matrix;matrix.global_rows=owned.global_rows;matrix.row_begin=owned.row_begin;matrix.offsets.push_back(0);
    for(const auto& row:rows){for(const auto& [column,value]:row)if(value!=0){matrix.columns.push_back(column);matrix.values.push_back(value);}matrix.offsets.push_back(matrix.values.size());}
    matrix.validate_local();return result;
}

KineticStreamingStep advance_kinetic_streaming(const KineticMesh& mesh,const std::vector<SphericalEedfState>& states,double dt_s,std::size_t threads) {
    if(!(dt_s>0 && std::isfinite(dt_s)))invalid("timestep must be finite and positive");
    const auto rates=kinetic_streaming_rhs(mesh,states,threads);
    if(dt_s>rates.maximum_explicit_step_s)invalid("explicit streaming CFL limit exceeded; use a smaller step or implicit residual");
    KineticStreamingStep result{states,dt_s*rates.outward_particle_rate_s,dt_s*rates.outward_energy_rate_ev_s};
    for(std::size_t cell=0;cell<states.size();++cell) {
        auto& state=result.states[cell];
        for(std::size_t mode=0;mode<state.density_modes.size();++mode)state.density_modes[mode]+=dt_s*rates.density_mode_rates[cell][mode];
        state.time_s+=dt_s;
        const auto stride=static_cast<std::size_t>(state.grid.legendre_terms*state.grid.legendre_terms);
        for(std::size_t i=0;i<static_cast<std::size_t>(state.grid.cells);++i)
            if(!(state.density_modes[i*stride]>=0))invalid("streaming trial has negative isotropic density; no state accepted");
        state.validate();
    }
    return result;
}
} // namespace raikou::kinetics
