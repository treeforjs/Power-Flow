#include "raikou/hydrogen_molecule.h"
#include <algorithm>
#include <cmath>
#include <map>
#include <numbers>
#include <stdexcept>

namespace raikou::kinetics {
namespace {
constexpr double kCmToEv = 1.239841984e-4;   // eV per cm^-1
constexpr double kBohr = 5.29177210903e-11;  // m
constexpr double kKelvinEv = 1.380649e-23 / 1.602176634e-19;
// Band origins G(v) - G(0) of H2 X, v = 0 .. 14 (cm^-1), and the rotational constants.
constexpr double kBandOrigin[] = {0,        4161.17,  8086.93,  11782.36, 15250.31, 18491.92, 21505.80, 24287.83,
                                  26830.97, 29123.93, 31150.19, 32886.85, 34301.83, 35351.01, 35972.97};
constexpr int kTopVibration = 14;
constexpr double kBe = 60.853, kAlphaE = 3.062, kDe = 0.0471, kHe = 4.9e-5;

[[noreturn]] void bad(const std::string& what) { throw std::invalid_argument("hydrogen: " + what); }

double interpolate(const std::vector<double>& x, const std::vector<double>& y, double at) {
    if (x.empty()) return 1.0;
    if (at <= x.front()) return y.front();
    if (at >= x.back()) return y.back();
    const auto k = static_cast<std::size_t>(std::upper_bound(x.begin(), x.end(), at) - x.begin()) - 1;
    return y[k] + (y[k + 1] - y[k]) * (at - x[k]) / (x[k + 1] - x[k]);
}

double level_energy_cm(int v, int j) {
    const double bv = kBe - kAlphaE * (v + 0.5), jj = j * (j + 1.0);
    return kBandOrigin[v] + bv * jj - kDe * jj * jj + kHe * jj * jj * jj;  // increasing in J for every v
}
} // namespace

std::vector<HydrogenLevel> hydrogen_levels(int v_max, int j_max, const std::string& prefix) {
    if (v_max < 0 || v_max > kTopVibration) bad("v must be between 0 and 14");
    if (j_max < 0 || j_max > 30) bad("J must be between 0 and 30");
    std::vector<HydrogenLevel> out;
    for (int v = 0; v <= v_max; ++v)
        for (int j = 0; j <= j_max; ++j)
            out.push_back({v, j, level_energy_cm(v, j) * kCmToEv, j % 2 == 1, prefix + "(" + std::to_string(v) + "," + std::to_string(j) + ")"});
    return out;
}

int hydrogen_vibrational_state(double energy_ev) {
    int best = 0;
    for (int v = 1; v <= kTopVibration; ++v)
        if (std::abs(kBandOrigin[v] * kCmToEv - energy_ev) < std::abs(kBandOrigin[best] * kCmToEv - energy_ev)) best = v;
    return best;
}

double quadrupole_cross_section(double e, int j, double u, double q) {
    if (!(e > u) || !(e > 0)) return 0.0;
    return 8 * std::numbers::pi / 15 * kBohr * kBohr * q * q * (j + 2.0) * (j + 1.0) / ((2 * j + 3.0) * (2 * j + 1.0)) * std::sqrt(1 - u / e);
}

GasSet hydrogen_set(const std::vector<CollisionProcess>& other, const HydrogenOptions& o) {
    if (!(o.gas_temperature_k >= 0)) bad("the gas temperature must be non-negative");
    if (o.born_scale_energy_ev.size() != o.born_scale.size()) bad("the Born scaling table needs as many factors as energies");
    const double kt = kKelvinEv * o.gas_temperature_k;
    const double kv = o.vibrational_temperature_k >= 0 ? kKelvinEv * o.vibrational_temperature_k : kt;
    const auto is_rotational = [&](const CollisionProcess& p) { return p.kind == CollisionKind::Excitation && p.target == o.target && p.threshold_ev < 0.3; };
    const auto is_vibrational = [&](const CollisionProcess& p) {
        return o.rotational_ladders && p.kind == CollisionKind::Excitation && p.target == o.target && p.threshold_ev >= 0.3 && p.threshold_ev <= 4.6;
    };
    // Rotation up to the level whose thermal population drops below a tenth of min_population.
    int j_cut = o.j_max;
    if (j_cut < 0) {
        j_cut = 1;
        while (j_cut < 28 && kt > 0 && 3 * (2 * j_cut + 1) * std::exp(-level_energy_cm(0, j_cut) * kCmToEv / kt) >= o.min_population * 0.1) ++j_cut;
    }
    int v_top = 0;
    for (const auto& p : other)
        if (is_vibrational(p)) v_top = std::max(v_top, hydrogen_vibrational_state(p.threshold_ev));
    const int j_top = std::min(30, j_cut + 2);
    const auto levels = hydrogen_levels(v_top, j_top, o.target);
    const auto at = [&](int v, int j) { return static_cast<std::size_t>(v * (j_top + 1) + j); };

    // One Boltzmann population over the whole set; the spin species normalised over v = 0 when
    // the ortho:para ratio is fixed.
    std::vector<double> pop(levels.size(), 0.0);
    double ortho_sum = 0, para_sum = 0;
    for (std::size_t i = 0; i < levels.size(); ++i) {
        const auto& l = levels[i];
        const double rot = l.energy_ev - kBandOrigin[l.v] * kCmToEv;
        if (kt > 0) pop[i] = (l.ortho ? 3.0 : 1.0) * (2 * l.j + 1) * std::exp(-rot / kt) * (l.v == 0 ? 1.0 : (kv > 0 ? std::exp(-kBandOrigin[l.v] * kCmToEv / kv) : 0.0));
        if (l.v == 0) (l.ortho ? ortho_sum : para_sum) += pop[i];
    }
    if (kt <= 0) {
        pop[at(0, 0)] = 1;
        para_sum = 1;
        if (o.ortho_para_ratio > 0) pop[at(0, 1)] = ortho_sum = 1;
    }
    if (o.ortho_para_ratio > 0)
        for (std::size_t i = 0; i < levels.size(); ++i) pop[i] *= levels[i].ortho ? (ortho_sum > 0 ? o.ortho_para_ratio / ortho_sum : 0.0) : (para_sum > 0 ? 1 / para_sum : 0.0);
    double total = 0, ground = 0;
    for (std::size_t i = 0; i < levels.size(); ++i) {
        total += pop[i];
        if (levels[i].v == 0) ground += pop[i];
    }
    for (auto& p : pop) p /= total;
    ground /= total;

    // Calibration: with no table given, J -> J + 2 cross sections in the file (measured or swarm
    // fitted, with the 3 eV resonance the Born form lacks) set the scale over Born, each J from
    // the nearest J below it that the file gives (J = 0 -> 2 for any J below the first given).
    std::vector<std::vector<double>> scale_e(static_cast<std::size_t>(j_top + 1)), scale(static_cast<std::size_t>(j_top + 1));
    if (o.born_scale_energy_ev.empty() && o.scale_to_file_rotation) {
        for (int j = 0; j + 2 <= j_top; ++j) {
            const double u = levels[at(0, j + 2)].energy_ev - levels[at(0, j)].energy_ev;
            for (const auto& p : other) {
                if (!is_rotational(p) || std::abs(p.threshold_ev - u) > 0.05 * u) continue;
                auto& ex = scale_e[static_cast<std::size_t>(j)];
                auto& sx = scale[static_cast<std::size_t>(j)];
                for (std::size_t k = 0; k < p.energy_ev.size(); ++k) {
                    const double born = quadrupole_cross_section(p.energy_ev[k], j, u, o.quadrupole_ea0sq);
                    if (born > 0 && p.cross_section_m2[k] > 0) {
                        ex.push_back(p.energy_ev[k] - u);  // by energy above threshold
                        sx.push_back(p.cross_section_m2[k] / born);
                    }
                }
                break;
            }
        }
        int given = -1;
        for (int j = 0; j <= j_top; ++j)
            if (!scale_e[static_cast<std::size_t>(j)].empty()) { given = j; break; }
        for (int j = 0; j <= j_top && given >= 0; ++j) {
            if (!scale_e[static_cast<std::size_t>(j)].empty()) given = j;
            else {
                scale_e[static_cast<std::size_t>(j)] = scale_e[static_cast<std::size_t>(given)];
                scale[static_cast<std::size_t>(j)] = scale[static_cast<std::size_t>(given)];
            }
        }
    }
    const auto born_scale = [&](int j, double e, double u) {
        if (!o.born_scale_energy_ev.empty()) return interpolate(o.born_scale_energy_ev, o.born_scale, e);
        const auto& ex = scale_e[static_cast<std::size_t>(j)];
        return ex.empty() ? 1.0 : interpolate(ex, scale[static_cast<std::size_t>(j)], e - u);
    };

    GasSet set;
    set.fractions[o.target] = ground;
    std::vector<char> used(levels.size(), 0);
    used[at(0, 0)] = 1;
    // Quadrupole rotation within every ladder: J -> J + 2 where either level is populated.
    std::vector<CollisionProcess> rotational, vibrational;
    for (int v = 0; v <= v_top; ++v)
        for (int j = 0; j + 2 <= j_top; ++j) {
            const auto lo = at(v, j), hi = at(v, j + 2);
            if (std::max(pop[lo], pop[hi]) < o.min_population) continue;
            CollisionProcess p;
            p.kind = CollisionKind::Excitation;
            p.target = levels[lo].name;
            p.product = levels[hi].name;
            p.label = p.target + " <-> " + p.product;
            p.threshold_ev = levels[hi].energy_ev - levels[lo].energy_ev;
            p.weight_ratio = (2 * j + 1.0) / (2 * j + 5.0);
            p.group = CollisionProcess::Group::Rotational;
            const double u = p.threshold_ev;
            p.energy_ev.push_back(u);
            p.cross_section_m2.push_back(0.0);
            for (int k = 0; k <= 100; ++k) {
                const double e = u * (1 + 1e-4 * std::pow(1e3 / (u * 1e-4), k / 100.0));
                p.energy_ev.push_back(e);
                p.cross_section_m2.push_back(quadrupole_cross_section(e, j, u, o.quadrupole_ea0sq) * born_scale(j, e, u));
            }
            used[lo] = used[hi] = 1;
            (v == 0 ? rotational : vibrational).push_back(std::move(p));
        }
    // Vibrational excitation level by level, (0, J) -> (v, J), the cross section moved with the threshold.
    for (const auto& p : other) {
        if (!is_vibrational(p)) continue;
        const int v = hydrogen_vibrational_state(p.threshold_ev);
        const double origin = kBandOrigin[v] * kCmToEv;
        for (int j = 0; j <= j_cut; ++j) {
            const auto lo = at(0, j), hi = at(v, j);
            if (pop[lo] < o.min_population) continue;
            CollisionProcess q;
            q.kind = CollisionKind::Excitation;
            q.target = levels[lo].name;
            q.product = levels[hi].name;
            q.label = q.target + " <-> " + q.product;
            const double shift = levels[hi].energy_ev - levels[lo].energy_ev - origin;
            q.threshold_ev = p.threshold_ev + shift;
            q.weight_ratio = p.weight_ratio > 0 ? p.weight_ratio : 1.0;
            q.group = CollisionProcess::Group::Vibrational;
            q.angular = p.angular;
            q.energy_ev.push_back(q.threshold_ev);
            q.cross_section_m2.push_back(p.threshold_ev <= p.energy_ev.front() ? 0.0 : interpolate(p.energy_ev, p.cross_section_m2, p.threshold_ev));
            for (std::size_t k = 0; k < p.energy_ev.size(); ++k)
                if (p.energy_ev[k] + shift > q.threshold_ev) {
                    q.energy_ev.push_back(p.energy_ev[k] + shift);
                    q.cross_section_m2.push_back(p.cross_section_m2[k]);
                }
            used[lo] = used[hi] = 1;
            vibrational.push_back(std::move(q));
        }
    }
    for (std::size_t i = 0; i < levels.size(); ++i)
        if (used[i]) {
            set.fractions[levels[i].name] = pop[i];
            set.levels.push_back({levels[i].j, levels[i].v, 0, levels[i].energy_ev, levels[i].ortho, levels[i].name, {}});
        }
    // The momentum transfer less the thermal rotational share of v = 0 (isotropic: the cross
    // sections themselves), kept to at least 5% of the given value.
    const auto rotational_momentum = [&](double e) {
        double s = 0;
        for (const auto& p : rotational) {
            const auto up = [&](double x) { return x <= p.energy_ev.front() ? 0.0 : interpolate(p.energy_ev, p.cross_section_m2, x); };
            s += set.fractions[p.target] * up(e) + set.fractions[p.product] * p.weight_ratio * (e + p.threshold_ev) / e * up(e + p.threshold_ev);
        }
        return s / ground;
    };
    for (const auto& p : other) {
        if (is_rotational(p) || is_vibrational(p)) continue;  // replaced level by level
        CollisionProcess q = p;
        if ((p.kind == CollisionKind::Elastic || p.kind == CollisionKind::Effective) && p.target == o.target) {
            if (p.kind == CollisionKind::Effective) {
                // The elastic part: the file's own inelastic processes of the target taken out here,
                // since the replacements act on the levels rather than on the target itself.
                // A rotational cross section of the file is per molecule in its lower level, so it
                // counts in the total with that level's thermal population.
                const auto weight_of = [&](const CollisionProcess& r) {
                    if (!is_rotational(r)) return 1.0;
                    for (int j = 0; j + 2 <= j_top; ++j) {
                        const double u = levels[at(0, j + 2)].energy_ev - levels[at(0, j)].energy_ev;
                        if (std::abs(r.threshold_ev - u) <= 0.05 * u) return pop[at(0, j)] / ground;
                    }
                    return 1.0;
                };
                for (std::size_t k = 0; k < q.energy_ev.size(); ++k) {
                    double inelastic = 0;
                    for (const auto& r : other)
                        if (r.target == o.target && r.kind != CollisionKind::Elastic && r.kind != CollisionKind::Effective && !r.energy_ev.empty() &&
                            q.energy_ev[k] > r.energy_ev.front())
                            inelastic += weight_of(r) * interpolate(r.energy_ev, r.cross_section_m2, q.energy_ev[k]);
                    q.cross_section_m2[k] = std::max(q.cross_section_m2[k] - inelastic, 0.0);
                }
                q.kind = CollisionKind::Elastic;
                q.label = p.label + " (elastic part)";
            }
            for (std::size_t k = 0; k < q.energy_ev.size(); ++k) {
                const double e = std::max(q.energy_ev[k], 1e-6), given = q.cross_section_m2[k];
                const double rot = rotational_momentum(e);
                if (given > 0) set.rotational_momentum_ratio_max = std::max(set.rotational_momentum_ratio_max, std::min(1.0, rot / given));
                if (o.momentum_includes_rotation) q.cross_section_m2[k] = std::max(given - rot, 0.05 * given);
            }
            if (q.mass_ratio <= 0) q.mass_ratio = 9.1093837015e-31 / (o.mass_amu * 1.66053906660e-27);
            if (o.momentum_includes_rotation) q.label += " (less the rotational share)";
        }
        set.processes.push_back(std::move(q));
    }
    for (auto& p : rotational) set.processes.push_back(std::move(p));
    for (auto& p : vibrational) set.processes.push_back(std::move(p));
    return set;
}

} // namespace raikou::kinetics
