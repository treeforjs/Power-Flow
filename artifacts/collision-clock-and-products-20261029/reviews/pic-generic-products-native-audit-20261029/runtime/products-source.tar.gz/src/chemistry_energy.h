#pragma once

#include "raikou/chemistry.h"

namespace raikou::chemistry::detail {

// Preserve authored keys in the mechanism and its serialized form. Interpret
// unqualified reservoirs in the reaction's basis phase everywhere they are used.
inline std::string energy_reservoir_key(const Reaction& reaction, std::string_view key) {
    if (key.find('/') != std::string_view::npos) return std::string(key);
    return reaction.basis_phase + "/" + std::string(key);
}

} // namespace raikou::chemistry::detail
