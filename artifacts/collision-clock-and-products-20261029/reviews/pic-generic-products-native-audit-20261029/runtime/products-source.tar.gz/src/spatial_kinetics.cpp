#include "raikou/spatial_kinetics.h"
#include "raikou/spatial_mesh.h"
#include "raikou/kinetic_rz.h"
#include "raikou/spherical_operator.h"
#include <algorithm>
#include <cmath>
#include <limits>
#include <numeric>
#include <set>
#include <stdexcept>

namespace raikou::kinetics {
namespace {
[[noreturn]] void invalid(const std::string& text) { throw std::invalid_argument("spatial kinetics: " + text); }
bool same_grid(const EedfGrid& a, const EedfGrid& b) {
    return a.cells == b.cells && a.legendre_terms == b.legendre_terms && a.max_energy_ev == b.max_energy_ev && a.power == b.power;
}
double field_magnitude(const Vector3& field) { return std::sqrt(field[0]*field[0]+field[1]*field[1]+field[2]*field[2]); }
using Values = std::vector<double>;
struct KrylovResult { Values value; int iterations{0}; bool converged{false}; };
// Flexible, twice-reorthogonalized restarted GMRES. Vectors are rank-local;
// only scalar dot products are reduced on the supplied communicator.
KrylovResult gmres(const std::function<Values(const Values&)>& apply, const Values& rhs,
    const backend::DistributedHalo& halo, int restart, int maximum_iterations, double tolerance) {
    const auto dot = [&](const Values& a, const Values& b) {
        double sum = 0; for (std::size_t i=0;i<a.size();++i) sum += a[i]*b[i]; return halo.global_sum(sum);
    };
    const auto norm = [&](const Values& a) { return std::sqrt(std::max(0.0,dot(a,a))); };
    KrylovResult result; result.value.assign(rhs.size(),0);
    const double initial = norm(rhs);
    if(initial==0){result.converged=true;return result;}
    Values residual = rhs;
    while(result.iterations < maximum_iterations) {
        const double beta=norm(residual);
        if(beta <= tolerance*initial){result.converged=true;break;}
        const int count=std::min(restart,maximum_iterations-result.iterations);
        std::vector<Values> basis(static_cast<std::size_t>(count+1),Values(rhs.size(),0));
        for(std::size_t i=0;i<rhs.size();++i)basis[0][i]=residual[i]/beta;
        std::vector<Values> h(static_cast<std::size_t>(count+1),Values(static_cast<std::size_t>(count),0));
        Values c(static_cast<std::size_t>(count),0),s(c),g(static_cast<std::size_t>(count+1),0);g[0]=beta;
        int used=0;
        for(int j=0;j<count;++j) {
            auto work=apply(basis[static_cast<std::size_t>(j)]);
            for(int pass=0;pass<2;++pass)for(int k=0;k<=j;++k){
                const double coefficient=dot(work,basis[static_cast<std::size_t>(k)]);
                h[static_cast<std::size_t>(k)][static_cast<std::size_t>(j)]+=coefficient;
                for(std::size_t i=0;i<work.size();++i)work[i]-=coefficient*basis[static_cast<std::size_t>(k)][i];
            }
            const double next=norm(work);h[static_cast<std::size_t>(j+1)][static_cast<std::size_t>(j)]=next;
            if(next>1e-30)for(std::size_t i=0;i<work.size();++i)basis[static_cast<std::size_t>(j+1)][i]=work[i]/next;
            for(int k=0;k<j;++k){
                const double first=h[static_cast<std::size_t>(k)][static_cast<std::size_t>(j)],second=h[static_cast<std::size_t>(k+1)][static_cast<std::size_t>(j)];
                h[static_cast<std::size_t>(k)][static_cast<std::size_t>(j)]=c[static_cast<std::size_t>(k)]*first+s[static_cast<std::size_t>(k)]*second;
                h[static_cast<std::size_t>(k+1)][static_cast<std::size_t>(j)]=-s[static_cast<std::size_t>(k)]*first+c[static_cast<std::size_t>(k)]*second;
            }
            const double diagonal=h[static_cast<std::size_t>(j)][static_cast<std::size_t>(j)],length=std::hypot(diagonal,next);
            c[static_cast<std::size_t>(j)]=length>0?diagonal/length:1;s[static_cast<std::size_t>(j)]=length>0?next/length:0;
            h[static_cast<std::size_t>(j)][static_cast<std::size_t>(j)]=length;
            g[static_cast<std::size_t>(j+1)]=-s[static_cast<std::size_t>(j)]*g[static_cast<std::size_t>(j)];g[static_cast<std::size_t>(j)]*=c[static_cast<std::size_t>(j)];
            used=j+1;++result.iterations;
            if(std::abs(g[static_cast<std::size_t>(j+1)])<=tolerance*initial || next<1e-30)break;
        }
        Values coefficients(static_cast<std::size_t>(used),0);
        for(int j=used-1;j>=0;--j){
            double value=g[static_cast<std::size_t>(j)];
            for(int k=j+1;k<used;++k)value-=h[static_cast<std::size_t>(j)][static_cast<std::size_t>(k)]*coefficients[static_cast<std::size_t>(k)];
            const double diagonal=h[static_cast<std::size_t>(j)][static_cast<std::size_t>(j)];
            if(std::abs(diagonal)<1e-300)invalid("singular kinetic Krylov projection");
            coefficients[static_cast<std::size_t>(j)]=value/diagonal;
        }
        for(int j=0;j<used;++j)for(std::size_t i=0;i<rhs.size();++i)result.value[i]+=coefficients[static_cast<std::size_t>(j)]*basis[static_cast<std::size_t>(j)][i];
        const auto product=apply(result.value);
        for(std::size_t i=0;i<rhs.size();++i)residual[i]=rhs[i]-product[i];
    }
    result.converged=norm(residual)<=tolerance*initial;
    return result;
}
}

KineticMesh make_kinetic_mesh(const spatial::mesh::Geometry& geometry, std::span<const double> gas_volumes,
    std::span<const double> gas_areas, std::span<const SpatialKineticBoundary> walls,
    const std::map<std::size_t,SpatialKineticBoundary>& contacts) {
    if(gas_volumes.size()!=geometry.volume.size() || gas_areas.size()!=geometry.faces.size() || walls.size()!=geometry.walls.size())invalid("phase geometry dimensions differ");
    const auto basis_normal=[&](Vector3 normal){return geometry.axisymmetric?Vector3{normal[0],0,normal[1]}:normal;};
    KineticMesh result;result.cell_volumes_m3.resize(gas_volumes.size());
    for(std::size_t c=0;c<gas_volumes.size();++c){
        if(!(gas_volumes[c]>=0 && gas_volumes[c]<=geometry.volume[c]*(1+1e-12)))invalid("invalid gas phase volume");
        result.cell_volumes_m3[c]=gas_volumes[c]>0?gas_volumes[c]:geometry.volume[c];
    }
    for(std::size_t f=0;f<geometry.faces.size();++f){
        const auto& face=geometry.faces[f];const bool a=gas_volumes[face.a]>0,b=gas_volumes[face.b]>0;
        if(!(gas_areas[f]>=0 && gas_areas[f]<=face.area*(1+1e-12)))invalid("invalid gas face aperture");
        const auto boundary=contacts.find(f);
        if(a&&b){
            if(boundary!=contacts.end())invalid("phase contact wall cannot replace an active/active face");
            if(gas_areas[f]>0)result.faces.push_back({face.a,face.b,basis_normal(face.normal),gas_areas[f]});
        } else if(a||b){
            if(boundary==contacts.end())invalid("active/absent phase contact needs an explicit kinetic wall");
            if(gas_areas[f]>0){
                auto normal=basis_normal(face.normal);if(b)for(double& value:normal)value=-value;
                result.faces.push_back({a?face.a:face.b,std::numeric_limits<std::size_t>::max(),normal,gas_areas[f],boundary->second.kind,boundary->second.incoming});
            }
        }else if(boundary!=contacts.end())invalid("kinetic wall supplied between two absent phases");
    }
    for(const auto& [face,boundary]:contacts){(void)boundary;if(face>=geometry.faces.size())invalid("phase-contact face index outside mesh");}
    for(std::size_t w=0;w<walls.size();++w){const auto& wall=geometry.walls[w];if(gas_volumes[wall.cell]>0&&wall.area>0)result.faces.push_back({wall.cell,std::numeric_limits<std::size_t>::max(),basis_normal(wall.normal),wall.area,walls[w].kind,walls[w].incoming});}
    return result;
}

SpatialKineticResult advance_spatial_kinetics(const KineticMesh& mesh, std::span<const SpatialKineticCell> cells,
    std::span<const SphericalEedfState> previous, const SpatialKineticOptions& options, std::span<const SphericalEedfState> older) {
    if(options.execution.mpi)invalid("MPI callers must supply rank-local cell ownership to advance_distributed_spatial_kinetics");
    return advance_distributed_spatial_kinetics(mesh,{static_cast<backend::GlobalIndex>(mesh.cell_volumes_m3.size()),0,cells.size()},cells,previous,options,older);
}

SpatialKineticResult advance_distributed_spatial_kinetics(const KineticMesh& mesh, backend::RowPartition cell_partition,
    std::span<const SpatialKineticCell> cells,std::span<const SphericalEedfState> previous,
    const SpatialKineticOptions& options,std::span<const SphericalEedfState> older) {
    const auto cell_size=static_cast<std::size_t>(options.grid.cells)*static_cast<std::size_t>(options.grid.legendre_terms*options.grid.legendre_terms);
    const auto first=cell_partition.row_begin,last=first+cell_partition.local_rows;
    const auto local_count=cell_partition.local_rows;
    std::set<std::size_t> ghost_cells;
    std::vector<backend::GlobalIndex> requested;
    std::string initial_error;
    try{
        if(options.execution.device!="cpu"&&options.execution.device!="cuda")invalid("unknown kinetic execution device");
        if(options.matrix_free_reference&&options.execution.device!="cpu")invalid("the matrix-free mesh kinetic reference operator requires CPU execution");
        if(!(options.dt_s>0 && std::isfinite(options.dt_s)) || !(options.a0>0) || !(options.a1>=0) || !(options.a2>=0) ||
            !std::isfinite(options.a0+options.a1+options.a2) || std::abs(options.a0-options.a1+options.a2)>1e-12)invalid("invalid implicit time formula");
        if(!(options.relative_tolerance>0 && options.relative_tolerance<1) || options.maximum_newton_iterations<1 || options.maximum_krylov_iterations<1 || options.krylov_restart<1)invalid("invalid nonlinear/Krylov controls");
        if(cell_partition.global_rows!=mesh.cell_volumes_m3.size() || last>cell_partition.global_rows || cells.size()!=local_count || previous.size()!=local_count || (options.a2>0 && older.size()!=local_count))invalid("local cell ownership/history dimensions differ");
        if(!options.inverse_radius_m1.empty() && options.inverse_radius_m1.size()!=1 && options.inverse_radius_m1.size()!=mesh.cell_volumes_m3.size())invalid("RZ inverse-radius array must be scalar or cover the mesh");
        for(std::size_t c=0;c<local_count;++c){
            previous[c].validate();if(!same_grid(previous[c].grid,options.grid))invalid("kinetic grids differ");
            if(cells[c].coupling){
                if(!cells[c].mechanism || !(previous[c].electron_density_m3()>0))invalid("active kinetic cell requires mechanism and positive old electron density");
                if(!same_grid(cells[c].coupling->grid,options.grid))invalid("cell coupling grid differs from kinetic state");
            }
            else for(double value:previous[c].density_modes)if(value!=0)invalid("absent kinetic phase must have zero state");
            for(std::size_t q=0;q<cell_size;q+=static_cast<std::size_t>(options.grid.legendre_terms*options.grid.legendre_terms))if(previous[c].density_modes[q]<0)invalid("negative old isotropic electron distribution");
            if(options.a2>0){older[c].validate();if(!same_grid(older[c].grid,options.grid)||!(older[c].time_s<previous[c].time_s))invalid("older kinetic history grid/time differs");}
        }
        for(const auto& face:mesh.faces){
            const bool left_owned=face.left>=first&&face.left<last,right_owned=face.right>=first&&face.right<last;
            if((left_owned&&!cells[face.left-static_cast<std::size_t>(first)].coupling)||(right_owned&&!cells[face.right-static_cast<std::size_t>(first)].coupling))invalid("absent kinetic phase must not have streaming faces");
            if(left_owned && face.right<cell_partition.global_rows && !right_owned)ghost_cells.insert(face.right);
            if(right_owned && !left_owned)ghost_cells.insert(face.left);
        }
        for(auto c:ghost_cells)for(std::size_t q=0;q<cell_size;++q)requested.push_back(static_cast<backend::GlobalIndex>(c)*cell_size+q);
    }catch(const std::exception& error){initial_error=error.what();}
    backend::DistributedHalo halo({cell_partition.global_rows*cell_size,first*cell_size,local_count*cell_size},requested,options.execution);
    halo.collective_require(initial_error);
    const double global_time=halo.global_max(local_count>0?previous[0].time_s:0);
    std::string clock_error;
    for(const auto& state:previous)if(std::abs(state.time_s-global_time)>1e-12*std::max(global_time,1e-30))clock_error="kinetic cells have different old clocks";
    halo.collective_require(clock_error);
    std::vector<std::size_t> global_cells;global_cells.reserve(local_count+ghost_cells.size());
    for(std::size_t c=0;c<local_count;++c)global_cells.push_back(static_cast<std::size_t>(first)+c);
    global_cells.insert(global_cells.end(),ghost_cells.begin(),ghost_cells.end());
    std::map<std::size_t,std::size_t> compact;
    KineticMesh local_mesh;
    for(std::size_t c=0;c<global_cells.size();++c){compact[global_cells[c]]=c;local_mesh.cell_volumes_m3.push_back(mesh.cell_volumes_m3[global_cells[c]]);}
    std::vector<std::size_t> face_ids;
    for(std::size_t f=0;f<mesh.faces.size();++f){
        const auto& face=mesh.faces[f];const bool left_owned=face.left>=first&&face.left<last,right_owned=face.right>=first&&face.right<last;
        if(!(left_owned||right_owned))continue;
        auto local=face;local.left=compact.at(face.left);
        if(face.right<cell_partition.global_rows)local.right=compact.at(face.right);
        local_mesh.faces.push_back(std::move(local));face_ids.push_back(f);
    }
    Values scales(local_count,1),history(local_count*cell_size,0),iterate(history.size());
    for(std::size_t c=0;c<local_count;++c){
        for(double value:previous[c].density_modes)scales[c]=std::max(scales[c],std::abs(value));
        for(std::size_t q=0;q<cell_size;++q){
            const auto i=c*cell_size+q;iterate[i]=previous[c].density_modes[q]/scales[c];
            history[i]=(options.a1*previous[c].density_modes[q]-(options.a2>0?options.a2*older[c].density_modes[q]:0))/scales[c];
        }
    }
    struct Trial {Values residual;std::vector<SphericalEedfState> states;std::vector<SphericalEedfEvaluation> collisions;KineticStreamingResult streaming;};
    const auto evaluate=[&](const Values& values){
        Trial trial;trial.states.resize(global_cells.size());trial.collisions.resize(local_count);
        Values physical(values.size());for(std::size_t c=0;c<local_count;++c)for(std::size_t q=0;q<cell_size;++q)physical[c*cell_size+q]=values[c*cell_size+q]*scales[c];
        const auto received=halo.exchange(physical);
        std::string error;
        try{
            for(std::size_t c=0;c<trial.states.size();++c){
                auto& state=trial.states[c];state.grid=options.grid;state.time_s=0;state.density_modes.resize(cell_size);
                for(std::size_t q=0;q<cell_size;++q){
                    const auto slot=halo.compact_index(static_cast<backend::GlobalIndex>(global_cells[c])*cell_size+q);
                    state.density_modes[q]=slot<physical.size()?physical[slot]:received[slot-physical.size()];
                }
            }
            if(!trial.states.empty()){
                trial.streaming=kinetic_streaming_rhs(local_mesh,trial.states,options.execution.threads);
                if(!options.inverse_radius_m1.empty()){
                    RzGeometry rz;
                    for(auto global:global_cells)rz.inverse_radius_m1.push_back(options.inverse_radius_m1[options.inverse_radius_m1.size()==1?0:global]);
                    const auto geometry_rates=rz_geometry_rhs(rz,trial.states,options.execution.threads);
                    for(std::size_t c=0;c<local_count;++c)for(std::size_t q=0;q<cell_size;++q)trial.streaming.density_mode_rates[c][q]+=geometry_rates[c][q];
                }
            }
            trial.residual.resize(values.size());
            for(std::size_t c=0;c<local_count;++c){
                if(cells[c].coupling){
                    auto chemistry_state=cells[c].candidate_state;
                    chemistry_state.densities_m3.at(cells[c].mechanism->species_index(cells[c].coupling->electron_species))=trial.states[c].electron_density_m3();
                    auto conditions=coupled_eedf_conditions(*cells[c].mechanism,chemistry_state,cells[c].environment,field_magnitude(cells[c].electric_field_V_m),*cells[c].coupling);
                    // MPI belongs to the mesh halo/Krylov solve. Independent local
                    // collision evaluations must not issue mismatched MPI calls.
                    conditions.execution=options.execution;conditions.execution.mpi=false;conditions.execution.device="cpu";
                    trial.collisions[c]=evaluate_spherical_eedf(cells[c].coupling->processes,conditions,trial.states[c],cells[c].electric_field_V_m);
                }
                for(std::size_t q=0;q<cell_size;++q){
                    const auto i=c*cell_size+q;
                    const double collision=cells[c].coupling?trial.collisions[c].density_mode_rates[q]:0;
                    trial.residual[i]=options.a0*values[i]-history[i]-options.dt_s*(collision+trial.streaming.density_mode_rates[c][q])/scales[c];
                }
            }
        }catch(const std::exception& exception){error=exception.what();}
        halo.collective_require(error);return trial;
    };
    const auto max_norm=[&](const Values& values){double norm=0;for(double value:values)norm=std::max(norm,std::abs(value));return halo.global_max(norm);};
    auto trial=evaluate(iterate);
    SpatialKineticResult result;result.local_unknowns=iterate.size();result.halo_unknowns=halo.layout().ghost_global_ids.size();
    result.face_global_ids=face_ids;
    result.linear_device=options.execution.device;
    KineticStreamingOperator streaming_operator;
    if(!options.matrix_free_reference)streaming_operator=assemble_kinetic_streaming(mesh,options.grid,halo.partition());
    Values compact_scales(global_cells.size(),1);
    for(std::size_t c=0;c<global_cells.size();++c)for(double value:trial.states[c].density_modes)compact_scales[c]=std::max(compact_scales[c],std::abs(value));
    const double tolerance=options.relative_tolerance*std::max(1.0,max_norm(iterate));
    for(int iteration=0;iteration<options.maximum_newton_iterations;++iteration){
        result.nonlinear_residual=max_norm(trial.residual);result.nonlinear_iterations=iteration;
        if(result.nonlinear_residual<=tolerance)break;
        const auto apply=[&](const Values& direction){
            const double norm=max_norm(direction);if(norm==0)return Values(direction.size(),0);
            const double epsilon=1e-4*std::max(1.0,max_norm(iterate))/norm;
            auto plus=iterate,minus=iterate;
            for(std::size_t i=0;i<iterate.size();++i){plus[i]+=epsilon*direction[i];minus[i]-=epsilon*direction[i];}
            const auto forward=evaluate(plus),backward=evaluate(minus);
            Values product(direction.size());for(std::size_t i=0;i<product.size();++i)product[i]=(forward.residual[i]-backward.residual[i])/(2*epsilon);
            return product;
        };
        auto rhs=trial.residual;for(double& value:rhs)value=-value;
        KrylovResult step;
        if(options.matrix_free_reference){
            step=gmres(apply,rhs,halo,options.krylov_restart,options.maximum_krylov_iterations,1e-5);
        }else{
            backend::DistributedCsrMatrix matrix;matrix.global_rows=halo.partition().global_rows;matrix.row_begin=halo.partition().row_begin;matrix.offsets.push_back(0);
            Values implicit_rhs=history;
            std::string assembly_error;
            try{
                std::vector<std::map<backend::GlobalIndex,double>> rows(iterate.size());
                for(std::size_t row=0;row<rows.size();++row){
                    const auto global=matrix.row_begin+row;
                    rows[row][global]=options.a0;
                    const auto& streaming=streaming_operator.matrix;
                    for(std::size_t entry=streaming.offsets[row];entry<streaming.offsets[row+1];++entry){
                        const auto column=streaming.columns[entry];
                        const auto column_cell=static_cast<std::size_t>(column/cell_size);
                        rows[row][column]-=options.dt_s*streaming.values[entry]*compact_scales[compact.at(column_cell)]/scales[row/cell_size];
                    }
                    implicit_rhs[row]+=options.dt_s*streaming_operator.affine_rates[row]/scales[row/cell_size];
                }
                for(std::size_t c=0;c<local_count;++c){
                    if(!cells[c].coupling)continue;
                    auto chemistry_state=cells[c].candidate_state;
                    chemistry_state.densities_m3.at(cells[c].mechanism->species_index(cells[c].coupling->electron_species))=trial.states[c].electron_density_m3();
                    auto conditions=coupled_eedf_conditions(*cells[c].mechanism,chemistry_state,cells[c].environment,field_magnitude(cells[c].electric_field_V_m),*cells[c].coupling);
                    const auto collision=freeze_spherical_eedf_operator(cells[c].coupling->processes,conditions,trial.states[c],cells[c].electric_field_V_m);
                    const auto append=[&](const backend::CsrMatrix& block){for(std::size_t q=0;q<cell_size;++q)for(std::size_t entry=block.offsets[q];entry<block.offsets[q+1];++entry)
                        rows[c*cell_size+q][(first+c)*cell_size+static_cast<std::size_t>(block.columns[entry])]-=options.dt_s*block.values[entry];};
                    append(collision);
                    if(!options.inverse_radius_m1.empty())append(rz_geometry_matrix(options.grid,options.inverse_radius_m1[options.inverse_radius_m1.size()==1?0:static_cast<std::size_t>(first)+c]));
                }
                for(const auto& row:rows){for(const auto& [column,value]:row)if(value!=0){matrix.columns.push_back(column);matrix.values.push_back(value);}matrix.offsets.push_back(matrix.values.size());}
            }catch(const std::exception& error){assembly_error=error.what();}
            halo.collective_require(assembly_error);
            // F00 can exceed a newly generated quadrupole by many orders of
            // magnitude. Resolve the linear block beyond the outer normwise
            // acceptance tolerance so small retained angular responses are not
            // lost beneath an otherwise converged isotropic residual.
            auto execution=options.execution;execution.tolerance=std::min(execution.tolerance,std::max(2e-14,options.relative_tolerance*1e-5));
            execution.max_iterations=options.maximum_krylov_iterations;execution.restart=options.krylov_restart;
            const auto linear=backend::solve_distributed(std::move(matrix),implicit_rhs,execution);
            step.value=linear.local_solution;step.iterations=linear.iterations;step.converged=linear.converged;result.linear_residual=linear.residual;
            for(std::size_t i=0;i<step.value.size();++i)step.value[i]-=iterate[i];
        }
        result.krylov_iterations+=step.iterations;
        if(!step.converged)invalid("implicit collision/streaming Krylov solve did not converge");
        bool accepted=false;
        for(double alpha=1;alpha>=1.0/1024;alpha*=0.5){
            auto candidate=iterate;for(std::size_t i=0;i<candidate.size();++i)candidate[i]+=alpha*step.value[i];
            double negative=0;
            for(std::size_t c=0;c<local_count;++c)for(std::size_t q=0;q<cell_size;q+=static_cast<std::size_t>(options.grid.legendre_terms*options.grid.legendre_terms))negative=std::max(negative,-candidate[c*cell_size+q]);
            if(halo.global_max(negative)>1e-14)continue;
            auto candidate_trial=evaluate(candidate);
            if(max_norm(candidate_trial.residual)<(1-1e-4*alpha)*result.nonlinear_residual){iterate=std::move(candidate);trial=std::move(candidate_trial);accepted=true;break;}
        }
        if(!accepted)invalid("implicit collision/streaming Newton line search failed");
        result.nonlinear_iterations=iteration+1;
    }
    result.nonlinear_residual=max_norm(trial.residual);
    if(result.nonlinear_residual>tolerance)invalid("implicit collision/streaming Newton solve did not converge");
    result.states.assign(trial.states.begin(),trial.states.begin()+static_cast<std::ptrdiff_t>(local_count));result.feedback.resize(local_count);
    std::string final_error;
    try{
        for(std::size_t c=0;c<local_count;++c){
            result.states[c].time_s=previous[c].time_s+options.dt_s;
            if(cells[c].coupling)result.feedback[c]=spherical_electron_feedback(*cells[c].mechanism,cells[c].candidate_state,cells[c].environment,cells[c].electric_field_V_m,*cells[c].coupling,result.states[c],trial.collisions[c]);
        }
    }catch(const std::exception& error){final_error=error.what();}
    halo.collective_require(final_error);
    result.face_particle_flux_m2_s=std::move(trial.streaming.face_particle_flux_m2_s);result.face_energy_flux_ev_m2_s=std::move(trial.streaming.face_energy_flux_ev_m2_s);
    result.outward_particle_rate_s=halo.global_sum(trial.streaming.outward_particle_rate_s);result.outward_energy_rate_ev_s=halo.global_sum(trial.streaming.outward_energy_rate_ev_s);
    return result;
}
} // namespace raikou::kinetics
