#include "raikou/device.h"
#include "device_ilu0.h"
#include <cuda_runtime.h>
#include <algorithm>
#include <atomic>
#include <cmath>
#include <memory>
#include <stdexcept>

namespace raikou::backend {
namespace {
constexpr unsigned block_size=256, maximum_blocks=1024;
void check(cudaError_t status){if(status!=cudaSuccess)throw std::runtime_error(cudaGetErrorString(status));}
struct Context {
    cudaStream_t stream{};
    int device{};
    std::atomic<std::size_t> uploaded{},downloaded{},allocated{};
    explicit Context(int requested){
        int count=0;check(cudaGetDeviceCount(&count));if(!count)throw std::runtime_error("CUDA device unavailable; no CPU fallback");
        if(requested>=count||requested < -1)throw std::invalid_argument("CUDA device ordinal is unavailable");
        if(requested>=0)check(cudaSetDevice(requested));check(cudaGetDevice(&device));
        check(cudaStreamCreateWithFlags(&stream,cudaStreamNonBlocking));
    }
    void activate()const{check(cudaSetDevice(device));}
    ~Context(){cudaSetDevice(device);cudaStreamDestroy(stream);}
};
template<class T> struct Buffer {
    Context* context;
    T* data{};
    std::size_t count;
    Buffer(Context& owner,std::size_t size):context(&owner),count(std::max(std::size_t{1},size)){
        owner.activate();
        if(count>std::numeric_limits<std::size_t>::max()/sizeof(T))throw std::invalid_argument("device allocation size overflow");
        check(cudaMalloc(reinterpret_cast<void**>(&data),count*sizeof(T)));context->allocated+=count*sizeof(T);
    }
    ~Buffer(){cudaSetDevice(context->device);cudaFree(data);context->allocated-=count*sizeof(T);}
    Buffer(const Buffer&)=delete;Buffer& operator=(const Buffer&)=delete;
    void upload(std::span<const T> values){
        context->activate();
        if(values.empty())return;
        check(cudaMemcpyAsync(data,values.data(),values.size_bytes(),cudaMemcpyHostToDevice,context->stream));
        context->uploaded+=values.size_bytes();
    }
};
class CudaVector final:public DeviceVector {
public:
    std::shared_ptr<Context> owner;
    Buffer<double> values;
    std::size_t length;
    CudaVector(std::shared_ptr<Context> context,std::size_t size):owner(std::move(context)),values(*owner,size),length(size){}
    std::size_t size()const override{return length;}
};
class CudaIndexPlan final:public DeviceIndexPlan {
public:
    std::shared_ptr<Context> owner;
    Buffer<std::size_t> indices;
    Buffer<double> staging;
    std::size_t length,largest{};
    bool has_duplicates=false;
    CudaIndexPlan(std::shared_ptr<Context> context,std::span<const std::size_t> values):
        owner(std::move(context)),indices(*owner,values.size()),staging(*owner,values.size()),length(values.size()){
        if(!values.empty())largest=*std::max_element(values.begin(),values.end());
        std::vector<std::size_t> sorted(values.begin(),values.end());std::sort(sorted.begin(),sorted.end());
        has_duplicates=std::adjacent_find(sorted.begin(),sorted.end())!=sorted.end();
        indices.upload(values);check(cudaStreamSynchronize(owner->stream));
    }
    std::size_t size()const override{return length;}
};
unsigned blocks(std::size_t n){return static_cast<unsigned>(std::min<std::size_t>(maximum_blocks,(n+block_size-1)/block_size));}
__global__ void fill_kernel(std::size_t n,double value,double* x){
    for(auto i=static_cast<std::size_t>(blockIdx.x)*blockDim.x+threadIdx.x;i<n;i+=static_cast<std::size_t>(gridDim.x)*blockDim.x)x[i]=value;
}
__global__ void scale_kernel(std::size_t n,double value,double* x){
    for(auto i=static_cast<std::size_t>(blockIdx.x)*blockDim.x+threadIdx.x;i<n;i+=static_cast<std::size_t>(gridDim.x)*blockDim.x)x[i]*=value;
}
__global__ void axpy_kernel(std::size_t n,double a,const double* x,double* y){
    for(auto i=static_cast<std::size_t>(blockIdx.x)*blockDim.x+threadIdx.x;i<n;i+=static_cast<std::size_t>(gridDim.x)*blockDim.x)y[i]+=a*x[i];
}
__global__ void csr_kernel(std::size_t rows,const std::size_t* offsets,const int* columns,const double* values,const double* x,double* y){
    for(auto row=static_cast<std::size_t>(blockIdx.x)*blockDim.x+threadIdx.x;row<rows;row+=static_cast<std::size_t>(gridDim.x)*blockDim.x){
        double sum=0;for(auto k=offsets[row];k<offsets[row+1];++k)sum+=values[k]*x[columns[k]];y[row]=sum;
    }
}
__global__ void precondition_kernel(std::size_t rows,const std::size_t* offsets,const int* columns,const double* values,const double* x,double* y){
    for(auto row=static_cast<std::size_t>(blockIdx.x)*blockDim.x+threadIdx.x;row<rows;row+=static_cast<std::size_t>(gridDim.x)*blockDim.x){
        double diagonal=0;for(auto k=offsets[row];k<offsets[row+1];++k)if(columns[k]==static_cast<int>(row))diagonal+=values[k];
        y[row]=x[row]/(fabs(diagonal)>1e-300?diagonal:1.0);
    }
}
__global__ void ilu0_kernel(const std::size_t* offsets,const std::size_t* diagonal,const int* columns,const double* factors,
    std::size_t forward_levels,const std::size_t* forward_offsets,const int* forward_rows,
    std::size_t backward_levels,const std::size_t* backward_offsets,const int* backward_rows,
    const double* rhs,double* result) {
    // One resident block traverses the dependency levels, avoiding a kernel
    // launch per level for long, narrow energy-grid triangular factors.
    for(std::size_t level=0;level<forward_levels;++level) {
        for(auto i=forward_offsets[level]+threadIdx.x;i<forward_offsets[level+1];i+=blockDim.x) {
            const auto row=forward_rows[i];double value=rhs[row];
            for(auto k=offsets[row];k<diagonal[row];++k)value-=factors[k]*result[columns[k]];
            result[row]=value;
        }
        __syncthreads();
    }
    for(std::size_t level=0;level<backward_levels;++level) {
        for(auto i=backward_offsets[level]+threadIdx.x;i<backward_offsets[level+1];i+=blockDim.x) {
            const auto row=backward_rows[i];double value=result[row];
            for(auto k=diagonal[row]+1;k<offsets[row+1];++k)value-=factors[k]*result[columns[k]];
            result[row]=value/factors[diagonal[row]];
        }
        __syncthreads();
    }
}
struct CudaIlu0 {
    Buffer<std::size_t> offsets,diagonal,forward_offsets,backward_offsets;
    Buffer<int> columns,forward_rows,backward_rows;
    Buffer<double> factors;
    std::size_t forward_levels,backward_levels;
    unsigned threads;
    CudaIlu0(Context& context,const detail::DeviceIlu0& data):
        offsets(context,data.offsets.size()),diagonal(context,data.diagonal.size()),
        forward_offsets(context,data.forward_offsets.size()),backward_offsets(context,data.backward_offsets.size()),
        columns(context,data.columns.size()),forward_rows(context,data.forward_rows.size()),backward_rows(context,data.backward_rows.size()),
        factors(context,data.values.size()),forward_levels(data.forward_offsets.size()-1),backward_levels(data.backward_offsets.size()-1),
        threads(static_cast<unsigned>(std::clamp<std::size_t>(data.maximum_width,1,block_size))) {
        offsets.upload(data.offsets);diagonal.upload(data.diagonal);columns.upload(data.columns);factors.upload(data.values);
        forward_offsets.upload(data.forward_offsets);backward_offsets.upload(data.backward_offsets);
        forward_rows.upload(data.forward_rows);backward_rows.upload(data.backward_rows);
    }
};
__global__ void gather_kernel(std::size_t n,const std::size_t* indices,const double* x,double* values){
    for(auto i=static_cast<std::size_t>(blockIdx.x)*blockDim.x+threadIdx.x;i<n;i+=static_cast<std::size_t>(gridDim.x)*blockDim.x)values[i]=x[indices[i]];
}
__global__ void scatter_kernel(std::size_t n,const std::size_t* indices,const double* values,double* x){
    for(auto i=static_cast<std::size_t>(blockIdx.x)*blockDim.x+threadIdx.x;i<n;i+=static_cast<std::size_t>(gridDim.x)*blockDim.x)x[indices[i]]=values[i];
}
__device__ void combine_norm(double& scale,double& sum,double other_scale,double other_sum){
    if(!isfinite(scale)||!isfinite(sum)||!isfinite(other_scale)||!isfinite(other_sum)){scale=NAN;sum=NAN;return;}
    if(other_scale==0)return;
    if(scale<other_scale){const double ratio=scale/other_scale;sum=other_sum+sum*ratio*ratio;scale=other_scale;}
    else {const double ratio=other_scale/scale;sum+=other_sum*ratio*ratio;}
}
__global__ void norm_partial(std::size_t n,const double* x,double* scales,double* sums){
    __shared__ double s[block_size],q[block_size];double scale=0,sum=0;
    for(auto i=static_cast<std::size_t>(blockIdx.x)*blockDim.x+threadIdx.x;i<n;i+=static_cast<std::size_t>(gridDim.x)*blockDim.x){
        const double value=fabs(x[i]);combine_norm(scale,sum,value,value==0?0:1);
    }
    s[threadIdx.x]=scale;q[threadIdx.x]=sum;__syncthreads();
    for(unsigned stride=blockDim.x/2;stride;stride/=2){if(threadIdx.x<stride)combine_norm(s[threadIdx.x],q[threadIdx.x],s[threadIdx.x+stride],q[threadIdx.x+stride]);__syncthreads();}
    if(!threadIdx.x){scales[blockIdx.x]=s[0];sums[blockIdx.x]=q[0];}
}
__global__ void norm_finish(unsigned n,const double* scales,const double* sums,double* result){
    __shared__ double s[block_size],q[block_size];double scale=0,sum=0;
    for(unsigned i=threadIdx.x;i<n;i+=blockDim.x)combine_norm(scale,sum,scales[i],sums[i]);
    s[threadIdx.x]=scale;q[threadIdx.x]=sum;__syncthreads();
    for(unsigned stride=blockDim.x/2;stride;stride/=2){if(threadIdx.x<stride)combine_norm(s[threadIdx.x],q[threadIdx.x],s[threadIdx.x+stride],q[threadIdx.x+stride]);__syncthreads();}
    if(!threadIdx.x)*result=s[0]*sqrt(q[0]);
}
__global__ void dot_partial(std::size_t n,const double* x,const double* y,double* partial){
    __shared__ double values[block_size];double sum=0;
    for(auto i=static_cast<std::size_t>(blockIdx.x)*blockDim.x+threadIdx.x;i<n;i+=static_cast<std::size_t>(gridDim.x)*blockDim.x)sum+=x[i]*y[i];
    values[threadIdx.x]=sum;__syncthreads();
    for(unsigned stride=blockDim.x/2;stride;stride/=2){if(threadIdx.x<stride)values[threadIdx.x]+=values[threadIdx.x+stride];__syncthreads();}
    if(!threadIdx.x)partial[blockIdx.x]=values[0];
}
__global__ void dot_finish(unsigned n,const double* partial,double* result){
    __shared__ double values[block_size];double sum=0;for(unsigned i=threadIdx.x;i<n;i+=blockDim.x)sum+=partial[i];
    values[threadIdx.x]=sum;__syncthreads();
    for(unsigned stride=blockDim.x/2;stride;stride/=2){if(threadIdx.x<stride)values[threadIdx.x]+=values[threadIdx.x+stride];__syncthreads();}
    if(!threadIdx.x)*result=values[0];
}
class CudaExecutor final:public DeviceExecutor {
    std::shared_ptr<Context> context_;
    std::size_t rows_,columns_;
    Buffer<std::size_t> offsets_;
    Buffer<int> indices_;
    Buffer<double> coefficients_,partial_a_,partial_b_,scalar_;
    std::unique_ptr<CudaIlu0> ilu_;
    const CudaVector& vector(const DeviceVector& value)const{
        context_->activate();
        const auto* result=dynamic_cast<const CudaVector*>(&value);
        if(!result||result->owner!=context_)throw std::invalid_argument("device vector belongs to another executor");return *result;
    }
    CudaVector& vector(DeviceVector& value)const{return const_cast<CudaVector&>(vector(static_cast<const DeviceVector&>(value)));}
    CudaIndexPlan& plan(const DeviceIndexPlan& value)const{
        auto* result=const_cast<CudaIndexPlan*>(dynamic_cast<const CudaIndexPlan*>(&value));
        if(!result||result->owner!=context_)throw std::invalid_argument("device index plan belongs to another executor");return *result;
    }
    void compatible(const CudaVector& a,const CudaVector& b)const{if(a.length!=b.length)throw std::invalid_argument("device vector sizes differ");}
    double scalar(){
        check(cudaGetLastError());double result{};
        check(cudaMemcpyAsync(&result,scalar_.data,sizeof(double),cudaMemcpyDeviceToHost,context_->stream));
        context_->downloaded+=sizeof(double);check(cudaStreamSynchronize(context_->stream));
        if(!std::isfinite(result))throw std::runtime_error("nonfinite device reduction");return result;
    }
public:
    explicit CudaExecutor(const DeviceCsrView& A,int device,const std::string& preconditioner):context_(std::make_shared<Context>(device)),rows_(A.rows),columns_(A.columns),offsets_(*context_,A.offsets.size()),
        indices_(*context_,A.indices.size()),coefficients_(*context_,A.values.size()),partial_a_(*context_,maximum_blocks),
        partial_b_(*context_,maximum_blocks),scalar_(*context_,1){
        offsets_.upload(A.offsets);indices_.upload(A.indices);coefficients_.upload(A.values);
        if(preconditioner=="block_ilu0") {
            const auto data=detail::prepare_device_ilu0(A);
            ilu_=std::make_unique<CudaIlu0>(*context_,data);
            check(cudaStreamSynchronize(context_->stream));
        }
        check(cudaStreamSynchronize(context_->stream));
    }
    std::unique_ptr<DeviceVector> allocate(std::size_t n)override{return std::make_unique<CudaVector>(context_,n);}
    std::unique_ptr<DeviceIndexPlan> index_plan(std::span<const std::size_t> indices)override{
        return std::make_unique<CudaIndexPlan>(context_,indices);
    }
    void upload(std::span<const double> data,DeviceVector& out)override{
        auto& y=vector(out);if(data.size()!=y.length)throw std::invalid_argument("device upload size differs");
        y.values.upload(data);check(cudaStreamSynchronize(context_->stream));
    }
    std::vector<double> download(const DeviceVector& source)override{
        const auto& x=vector(source);std::vector<double> result(x.length);
        if(!x.length)return result;
        check(cudaMemcpyAsync(result.data(),x.values.data,x.length*sizeof(double),cudaMemcpyDeviceToHost,context_->stream));
        context_->downloaded+=x.length*sizeof(double);check(cudaStreamSynchronize(context_->stream));return result;
    }
    std::vector<double> gather(const DeviceVector& source,const DeviceIndexPlan& selection)override{
        const auto& x=vector(source);auto& p=plan(selection);if(p.length&&p.largest>=x.length)throw std::invalid_argument("device gather index out of bounds");
        std::vector<double> result(p.length);if(!p.length)return result;
        gather_kernel<<<blocks(p.length),block_size,0,context_->stream>>>(p.length,p.indices.data,x.values.data,p.staging.data);check(cudaGetLastError());
        check(cudaMemcpyAsync(result.data(),p.staging.data,p.length*sizeof(double),cudaMemcpyDeviceToHost,context_->stream));
        context_->downloaded+=p.length*sizeof(double);check(cudaStreamSynchronize(context_->stream));return result;
    }
    void scatter(std::span<const double> data,const DeviceIndexPlan& selection,DeviceVector& destination)override{
        auto& x=vector(destination);auto& p=plan(selection);
        if(data.size()!=p.length||(p.length&&p.largest>=x.length))throw std::invalid_argument("device scatter size or index invalid");
        if(p.has_duplicates)throw std::invalid_argument("device scatter indices must be unique");
        if(!p.length)return;p.staging.upload(data);
        scatter_kernel<<<blocks(p.length),block_size,0,context_->stream>>>(p.length,p.indices.data,p.staging.data,x.values.data);
        check(cudaGetLastError());check(cudaStreamSynchronize(context_->stream));
    }
    void fill(DeviceVector& target,double value)override{
        if(!std::isfinite(value))throw std::invalid_argument("nonfinite device fill");auto& x=vector(target);if(!x.length)return;
        fill_kernel<<<blocks(x.length),block_size,0,context_->stream>>>(x.length,value,x.values.data);check(cudaGetLastError());
    }
    void copy(const DeviceVector& source,DeviceVector& destination,std::size_t begin,std::size_t output,std::size_t count)override{
        const auto& x=vector(source);auto& y=vector(destination);
        if(begin>x.length||output>y.length)throw std::invalid_argument("device copy offset out of bounds");
        if(count==std::numeric_limits<std::size_t>::max())count=x.length-begin;
        if(count>x.length-begin||count>y.length-output)throw std::invalid_argument("device copy extent out of bounds");
        if(!count)return;
        if(&x==&y&&count&&begin!=output&&begin<output+count&&output<begin+count)throw std::invalid_argument("overlapping device copy");
        check(cudaMemcpyAsync(y.values.data+output,x.values.data+begin,count*sizeof(double),cudaMemcpyDeviceToDevice,context_->stream));
    }
    void scale(double factor,DeviceVector& target)override{
        if(!std::isfinite(factor))throw std::invalid_argument("nonfinite device scale");auto& x=vector(target);if(!x.length)return;
        scale_kernel<<<blocks(x.length),block_size,0,context_->stream>>>(x.length,factor,x.values.data);check(cudaGetLastError());
    }
    void axpy(double factor,const DeviceVector& source,DeviceVector& destination)override{
        if(!std::isfinite(factor))throw std::invalid_argument("nonfinite device axpy");const auto& x=vector(source);auto& y=vector(destination);compatible(x,y);if(!x.length)return;
        axpy_kernel<<<blocks(x.length),block_size,0,context_->stream>>>(x.length,factor,x.values.data,y.values.data);check(cudaGetLastError());
    }
    double dot(const DeviceVector& a,const DeviceVector& b)override{
        const auto& x=vector(a);const auto& y=vector(b);compatible(x,y);if(!x.length)return 0;
        const auto count=blocks(x.length);dot_partial<<<count,block_size,0,context_->stream>>>(x.length,x.values.data,y.values.data,partial_a_.data);
        dot_finish<<<1,block_size,0,context_->stream>>>(count,partial_a_.data,scalar_.data);return scalar();
    }
    double norm(const DeviceVector& a)override{
        const auto& x=vector(a);if(!x.length)return 0;const auto count=blocks(x.length);
        norm_partial<<<count,block_size,0,context_->stream>>>(x.length,x.values.data,partial_a_.data,partial_b_.data);
        norm_finish<<<1,block_size,0,context_->stream>>>(count,partial_a_.data,partial_b_.data,scalar_.data);return scalar();
    }
    void apply(const DeviceVector& source,DeviceVector& destination)override{
        const auto& x=vector(source);auto& y=vector(destination);
        if(x.length!=columns_||y.length!=rows_||&x==&y)throw std::invalid_argument("device CSR input/output dimensions or alias invalid");
        if(!rows_)return;
        csr_kernel<<<blocks(rows_),block_size,0,context_->stream>>>(rows_,offsets_.data,indices_.data,coefficients_.data,x.values.data,y.values.data);check(cudaGetLastError());
    }
    void precondition(const DeviceVector& source,DeviceVector& destination)override{
        const auto& x=vector(source);auto& y=vector(destination);if(x.length!=rows_||y.length!=rows_)throw std::invalid_argument("device preconditioner dimensions differ");
        if(!rows_)return;
        if(ilu_) {
            ilu0_kernel<<<1,ilu_->threads,0,context_->stream>>>(ilu_->offsets.data,ilu_->diagonal.data,ilu_->columns.data,ilu_->factors.data,
                ilu_->forward_levels,ilu_->forward_offsets.data,ilu_->forward_rows.data,
                ilu_->backward_levels,ilu_->backward_offsets.data,ilu_->backward_rows.data,x.values.data,y.values.data);
        } else precondition_kernel<<<blocks(rows_),block_size,0,context_->stream>>>(rows_,offsets_.data,indices_.data,coefficients_.data,x.values.data,y.values.data);
        check(cudaGetLastError());
    }
    DeviceTransferMetrics metrics()const override{return {context_->uploaded.load(),context_->downloaded.load(),context_->allocated.load()};}
};
}
std::unique_ptr<DeviceExecutor> make_cuda_executor_impl(const DeviceCsrView& matrix,int device,const std::string& preconditioner){
    return std::make_unique<CudaExecutor>(matrix,device,preconditioner);
}
} // namespace raikou::backend
