#include "raikou/c_api.h"

#include <charconv>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <set>
#include <stdexcept>
#include <string>
#include <string_view>

namespace {
using Options = std::map<std::string, std::string>;

void check(raikou_status status) {
    if (status != RAIKOU_OK) throw std::runtime_error(raikou_last_error());
}

Options parse(int argc, char** argv, const std::set<std::string>& allowed) {
    Options options;
    for (int index = 2; index < argc; ++index) {
        std::string key = argv[index];
        const auto equals = key.find('=');
        const std::string value_in_key = equals == std::string::npos ? "" : key.substr(equals + 1);
        if (equals != std::string::npos) key.resize(equals);
        if (!allowed.contains(key)) throw std::invalid_argument("Unknown option: " + key);
        if (options.contains(key)) throw std::invalid_argument("Duplicate option: " + key);
        std::string value = value_in_key;
        if (equals == std::string::npos) {
            if (++index >= argc || std::string_view(argv[index]).starts_with("--"))
                throw std::invalid_argument("Missing value for " + key);
            value = argv[index];
        }
        if (value.empty()) throw std::invalid_argument("Missing value for " + key);
        options.emplace(std::move(key), std::move(value));
    }
    return options;
}

double number(const std::string& value, const std::string& name) {
    double result{};
    const auto parsed = std::from_chars(value.data(), value.data() + value.size(), result);
    if (parsed.ec != std::errc{} || parsed.ptr != value.data() + value.size() || !std::isfinite(result))
        throw std::invalid_argument(name + " requires a finite number");
    return result;
}

void option(const Options& options, const char* name, double& value) {
    if (const auto found = options.find(name); found != options.end()) value = number(found->second, name);
}

double required(const Options& options, const char* name) {
    const auto found = options.find(name);
    if (found == options.end()) throw std::invalid_argument(std::string("Missing required option: ") + name);
    return number(found->second, name);
}

int steps(const Options& options) {
    if (const auto found = options.find("--steps"); found != options.end()) {
        int result{};
        const auto& value = found->second;
        const auto parsed = std::from_chars(value.data(), value.data() + value.size(), result);
        if (parsed.ec != std::errc{} || parsed.ptr != value.data() + value.size() || result <= 0)
            throw std::invalid_argument("--steps requires a positive integer");
        return result;
    }
    return 1;
}

template<size_t N> void array(const double (&values)[N]) {
    std::cout << '[';
    for (size_t index = 0; index < N; ++index) {
        if (index) std::cout << ',';
        std::cout << values[index];
    }
    std::cout << ']';
}

template<size_t N> void matrix(const double (&values)[N][N]) {
    std::cout << '[';
    for (size_t index = 0; index < N; ++index) {
        if (index) std::cout << ',';
        array(values[index]);
    }
    std::cout << ']';
}

void evaluate(const Options& options) {
    raikou_plasma_state state{};
    check(raikou_default_plasma_state(&state));
    option(options, "--te-ev", state.Te_eV);
    option(options, "--ne-m3", state.ne_m3);
    option(options, "--tgas-k", state.Tgas_K);
    option(options, "--nh-m3", state.nH_ground_m3);
    option(options, "--nh2-m3", state.nH2_m3);
    option(options, "--path-length-m", state.path_length_m);
    raikou_radiance_result result{};
    check(raikou_evaluate(&state, &result));
    std::cout << "{\"populations_m3\":";
    array(result.populations_m3);
    std::cout << ",\"lyman_alpha_radiance_W_m2_sr\":" << result.lyman_alpha_radiance_W_m2_sr
        << ",\"lyman_beta_radiance_W_m2_sr\":" << result.lyman_beta_radiance_W_m2_sr
        << ",\"balmer_alpha_radiance_W_m2_sr\":" << result.balmer_alpha_radiance_W_m2_sr
        << ",\"balmer_beta_radiance_W_m2_sr\":" << result.balmer_beta_radiance_W_m2_sr
        << ",\"molecular_lyman_proxy_W_m2_sr\":" << result.molecular_lyman_proxy_W_m2_sr
        << ",\"tau_0_lyman_alpha\":" << result.tau_0_lyman_alpha
        << ",\"escape_factor_lyman_alpha\":" << result.escape_factor_lyman_alpha
        << ",\"tau_0_lyman_beta\":" << result.tau_0_lyman_beta
        << ",\"escape_factor_lyman_beta\":" << result.escape_factor_lyman_beta << "}\n";
}

void rates(const Options& options) {
    raikou_rate_result result{};
    check(raikou_rate_coefficients(required(options, "--te-ev"), &result));
    std::cout << "{\"excitation_m3_s\":";
    matrix(result.excitation_m3_s);
    std::cout << ",\"deexcitation_m3_s\":";
    matrix(result.deexcitation_m3_s);
    std::cout << ",\"ionization_m3_s\":";
    array(result.ionization_m3_s);
    std::cout << ",\"radiative_recombination_m3_s\":";
    array(result.radiative_recombination_m3_s);
    std::cout << ",\"three_body_recombination_m6_s\":";
    array(result.three_body_recombination_m6_s);
    std::cout << ",\"h2_dissociation_m3_s\":";
    array(result.h2_dissociation_m3_s);
    std::cout << "}\n";
}

void fit(const Options& options) {
    raikou_fit_priors priors{};
    check(raikou_default_fit_priors(&priors));
    option(options, "--min-te-ev", priors.min_Te_eV);
    option(options, "--max-te-ev", priors.max_Te_eV);
    option(options, "--min-ne-m3", priors.min_ne_m3);
    option(options, "--max-ne-m3", priors.max_ne_m3);
    option(options, "--min-nh-m3", priors.min_nH_m3);
    option(options, "--max-nh-m3", priors.max_nH_m3);
    option(options, "--min-nh2-m3", priors.min_nH2_m3);
    option(options, "--max-nh2-m3", priors.max_nH2_m3);
    double path_length_m = 0.005, tgas_k = 5000.0;
    option(options, "--path-length-m", path_length_m);
    option(options, "--tgas-k", tgas_k);
    raikou_fit_result result{};
    check(raikou_fit_vuv_shot(required(options, "--ly-alpha"), required(options, "--ly-alpha-sigma"),
        required(options, "--molecular"), required(options, "--molecular-sigma"),
        path_length_m, tgas_k, &priors, &result));
    std::cout << "{\"Te_eV\":" << result.Te_eV
        << ",\"Te_err_eV\":" << result.Te_err_eV
        << ",\"ne_m3\":" << result.ne_m3
        << ",\"ne_err_m3\":" << result.ne_err_m3
        << ",\"nH_m3\":" << result.nH_m3
        << ",\"nH_err_m3\":" << result.nH_err_m3
        << ",\"nH2_m3\":" << result.nH2_m3
        << ",\"nH2_err_m3\":" << result.nH2_err_m3
        << ",\"tau_0_lyman_alpha\":" << result.tau_0_lyman_alpha
        << ",\"escape_factor_lyman_alpha\":" << result.escape_factor_lyman_alpha
        << ",\"chi2_reduced\":" << result.chi2_reduced
        << ",\"converged\":" << (result.converged ? "true" : "false")
        << ",\"iterations\":" << result.iterations << "}\n";
}

void spark(const Options& options) {
    raikou_spark_config config{};
    check(raikou_default_spark_config(&config));
    option(options, "--peak-current", config.peak_current);
    option(options, "--pulse-duration-s", config.pulse_duration_s);
    option(options, "--initial-density", config.initial_density);
    option(options, "--plasma-conductivity", config.plasma_conductivity);
    option(options, "--channel-length", config.channel_length);
    raikou_spark_state state{};
    check(raikou_default_spark_state(&state));
    option(options, "--time-s", state.time_s);
    option(options, "--current-a", state.current_A);
    option(options, "--channel-radius-m", state.channel_radius_m);
    option(options, "--pressure-pa", state.pressure_Pa);
    option(options, "--temperature-k", state.temperature_K);
    option(options, "--deposited-energy-j", state.deposited_energy_J);
    option(options, "--accumulated-action", state.accumulated_action);
    const double dt = required(options, "--dt");
    const int count = steps(options);
    for (int index = 0; index < count; ++index) check(raikou_step_spark(&state, dt, &config, &state));
    std::cout << "{\"time_s\":" << state.time_s
        << ",\"current_A\":" << state.current_A
        << ",\"channel_radius_m\":" << state.channel_radius_m
        << ",\"pressure_Pa\":" << state.pressure_Pa
        << ",\"temperature_K\":" << state.temperature_K
        << ",\"deposited_energy_J\":" << state.deposited_energy_J
        << ",\"accumulated_action\":" << state.accumulated_action << "}\n";
}

void help() {
    std::cout << "Raikou " RAIKOU_VERSION " - hydrogen CR chemistry and plasma breakdown\n\n"
        "Usage: raikou <command> [options]\n"
        "Numerical results are JSON on stdout; errors go to stderr.\n"
        "All values use SI units except electron temperature in eV.\n\n"
        "  evaluate  Evaluate five-level hydrogen populations and spectral radiances.\n"
        "    --te-ev 2.5 --ne-m3 1e19 --tgas-k 5000 --nh-m3 1e20\n"
        "    --nh2-m3 5e19 --path-length-m 0.005 (all optional defaults)\n"
        "  rates     Evaluate chemistry coefficients for all levels 1..5.\n"
        "    --te-ev VALUE (required)\n"
        "  fit       Fit VUV radiances with bounded priors.\n"
        "    --ly-alpha VALUE --ly-alpha-sigma VALUE --molecular VALUE\n"
        "    --molecular-sigma VALUE (all four required)\n"
        "    --path-length-m 0.005 --tgas-k 5000\n"
        "    --min-te-ev 0.5 --max-te-ev 20 --min-ne-m3 1e17 --max-ne-m3 1e22\n"
        "    --min-nh-m3 1e17 --max-nh-m3 1e23 --min-nh2-m3 1e17 --max-nh2-m3 1e23\n"
        "  spark     Advance a spark discharge (alias: step).\n"
        "    --dt SECONDS (required), --steps 1\n"
        "    --peak-current 20000 --pulse-duration-s 5e-6 --initial-density 1000\n"
        "    --plasma-conductivity 25000 --channel-length 0.01\n"
        "    --time-s 0 --current-a 0 --channel-radius-m 1e-4 --pressure-pa 1e5\n"
        "    --temperature-k 300 --deposited-energy-j 0 --accumulated-action 0\n\n"
        "  --help     Show this help.\n"
        "  --version  Show the library version.\n";
}
}

int main(int argc, char** argv) {
    try {
        std::cout << std::setprecision(std::numeric_limits<double>::max_digits10);
        if (argc == 1 || (argc == 2 && std::string_view(argv[1]) == "--help")) {
            help(); return 0;
        }
        if (argc == 2 && std::string_view(argv[1]) == "--version") {
            std::cout << "Raikou " << raikou_version() << '\n'; return 0;
        }
        const std::string command = argv[1];
        const std::set<std::string> commands{"evaluate", "rates", "fit", "spark", "step"};
        if (!commands.contains(command)) throw std::invalid_argument("Unknown command: " + command);
        if (argc == 3 && std::string_view(argv[2]) == "--help") { help(); return 0; }
        if (command == "evaluate") evaluate(parse(argc, argv,
            {"--te-ev", "--ne-m3", "--tgas-k", "--nh-m3", "--nh2-m3", "--path-length-m"}));
        else if (command == "rates") rates(parse(argc, argv, {"--te-ev"}));
        else if (command == "fit") fit(parse(argc, argv,
            {"--ly-alpha", "--ly-alpha-sigma", "--molecular", "--molecular-sigma", "--path-length-m", "--tgas-k",
             "--min-te-ev", "--max-te-ev", "--min-ne-m3", "--max-ne-m3", "--min-nh-m3", "--max-nh-m3",
             "--min-nh2-m3", "--max-nh2-m3"}));
        else spark(parse(argc, argv,
            {"--dt", "--steps", "--peak-current", "--pulse-duration-s", "--initial-density",
             "--plasma-conductivity", "--channel-length", "--time-s", "--current-a", "--channel-radius-m",
             "--pressure-pa", "--temperature-k", "--deposited-energy-j", "--accumulated-action"}));
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "raikou: " << error.what() << '\n';
        return 2;
    }
}
