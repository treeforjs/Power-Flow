#include "raikou/device_distributed.h"
#include <algorithm>
#include <cmath>
#include <limits>
#include <stdexcept>

namespace raikou::backend {
DistributedLinearResult solve_distributed_cuda(const DistributedLinearOperator& op,std::span<const double> rhs){
    const auto& halo=op.halo();const auto partition=halo.partition();const auto& options=op.options();const auto compact=op.compact_matrix();
    std::string error;
    if(rhs.size()!=partition.local_rows)error="distributed CUDA RHS size differs";
    for(double value:rhs)if(!std::isfinite(value))error="distributed CUDA RHS is nonfinite";
    if(options.preconditioner!="jacobi"&&options.preconditioner!="block_ilu0")error="distributed CUDA preconditioner must be jacobi or block_ilu0";
    halo.collective_require(error);
    const auto m=static_cast<std::size_t>(std::min<GlobalIndex>(static_cast<GlobalIndex>(options.restart),partition.global_rows));
    std::unique_ptr<DeviceExecutor> device;
    std::unique_ptr<DeviceVector> b,x,residual,w,extended;
    std::unique_ptr<DeviceIndexPlan> sends,receives;
    std::vector<std::unique_ptr<DeviceVector>> basis,preconditioned;
    try{
        device=make_cuda_executor({compact.rows,compact.input_columns,compact.offsets,compact.columns,compact.values},options.cuda_device,options.preconditioner);
        b=device->allocate(compact.rows);x=device->allocate(compact.rows);residual=device->allocate(compact.rows);w=device->allocate(compact.rows);
        extended=device->allocate(compact.input_columns);sends=device->index_plan(halo.layout().send_local_indices);
        std::vector<std::size_t> ghost_indices(halo.layout().ghost_global_ids.size());
        for(std::size_t i=0;i<ghost_indices.size();++i)ghost_indices[i]=compact.rows+i;
        receives=device->index_plan(ghost_indices);
        for(std::size_t i=0;i<=m;++i)basis.push_back(device->allocate(compact.rows));
        for(std::size_t i=0;i<m;++i)preconditioned.push_back(device->allocate(compact.rows));
        device->upload(rhs,*b);device->fill(*x,0);
    }catch(const std::exception& exception){error=exception.what();}
    halo.collective_require(error);
    const auto local=[&](const auto& action){
        std::string message;try{action();}catch(const std::exception& exception){message=exception.what();}halo.collective_require(message);
    };
    const auto norm=[&](const DeviceVector& value){
        double own=0;local([&]{own=device->norm(value);});const double largest=halo.global_max(own);
        if(largest==0)return 0.0;
        const double ratio=own/largest;const double result=largest*std::sqrt(halo.global_sum(ratio*ratio));
        if(!std::isfinite(result))throw std::runtime_error("distributed CUDA norm overflow");
        return result;
    };
    const auto dot=[&](const DeviceVector& a,const DeviceVector& c){double own=0;local([&]{own=device->dot(a,c);});return halo.global_sum(own);};
    const auto apply=[&](const DeviceVector& source,DeviceVector& destination){
        std::vector<double> packed;
        local([&]{packed=device->gather(source,*sends);});
        const auto ghosts=halo.exchange_packed_halo(packed);
        local([&]{device->copy(source,*extended,0,0,compact.rows);device->scatter(ghosts,*receives,*extended);device->apply(*extended,destination);});
    };
    const auto divide=[&](DeviceVector& value,double denominator){
        local([&]{if(denominator<std::numeric_limits<double>::min()){
            device->scale(1.0/std::numeric_limits<double>::min(),value);device->scale(std::numeric_limits<double>::min()/denominator,value);
        }else device->scale(1.0/denominator,value);});
    };
    DistributedLinearResult result;result.row_begin=partition.row_begin;result.global_rows=partition.global_rows;
    result.local_working_vector_entries=(2*m+5)*compact.rows+compact.input_columns;
    const double magnitude=norm(*b);
    if(magnitude==0){result.local_solution.assign(compact.rows,0);result.converged=true;return result;}
    while(result.iterations<options.max_iterations){
        apply(*x,*residual);local([&]{device->scale(-1,*residual);device->axpy(1,*b,*residual);});
        const double beta=norm(*residual);result.residual=beta;if(beta/magnitude<=options.tolerance){result.converged=true;break;}
        local([&]{device->copy(*residual,*basis[0]);});divide(*basis[0],beta);
        std::vector<std::vector<double>> h;
        std::vector<double> cosine,sine,g;
        local([&]{h.assign(m+1,std::vector<double>(m));cosine.resize(m);sine.resize(m);g.assign(m+1,0);});g[0]=beta;
        std::size_t count=0;
        for(std::size_t j=0;j<m&&result.iterations<options.max_iterations;++j){
            local([&]{device->precondition(*basis[j],*preconditioned[j]);});apply(*preconditioned[j],*w);
            for(int pass=0;pass<2;++pass)for(std::size_t k=0;k<=j;++k){
                const double coefficient=dot(*w,*basis[k]);h[k][j]+=coefficient;local([&]{device->axpy(-coefficient,*basis[k],*w);});
            }
            h[j+1][j]=norm(*w);const bool breakdown=h[j+1][j]==0;
            if(!breakdown){local([&]{device->copy(*w,*basis[j+1]);});divide(*basis[j+1],h[j+1][j]);}
            for(std::size_t k=0;k<j;++k){const double a=h[k][j],c=h[k+1][j];h[k][j]=cosine[k]*a+sine[k]*c;h[k+1][j]=-sine[k]*a+cosine[k]*c;}
            const double diagonal=std::hypot(h[j][j],h[j+1][j]);cosine[j]=diagonal>0?h[j][j]/diagonal:1;sine[j]=diagonal>0?h[j+1][j]/diagonal:0;
            h[j][j]=diagonal;h[j+1][j]=0;g[j+1]=-sine[j]*g[j];g[j]*=cosine[j];++result.iterations;count=j+1;
            if(std::abs(g[j+1])/magnitude<=options.tolerance||breakdown)break;
        }
        std::vector<double> y;local([&]{y.resize(count);});bool singular=false;
        for(std::size_t row=count;row-- >0;){
            double value=g[row];for(std::size_t column=row+1;column<count;++column)value-=h[row][column]*y[column];
            if(h[row][row]==0){singular=true;break;}y[row]=value/h[row][row];if(!std::isfinite(y[row])){singular=true;break;}
        }
        if(singular)break;
        local([&]{for(std::size_t j=0;j<count;++j)device->axpy(y[j],*preconditioned[j],*x);});
    }
    apply(*x,*residual);local([&]{device->scale(-1,*residual);device->axpy(1,*b,*residual);});
    result.residual=norm(*residual);result.converged=result.residual/magnitude<=options.tolerance;
    local([&]{result.local_solution=device->download(*x);});
    for(double value:result.local_solution)if(!std::isfinite(value))error="distributed CUDA solution overflow";
    halo.collective_require(error);return result;
}
} // namespace raikou::backend
