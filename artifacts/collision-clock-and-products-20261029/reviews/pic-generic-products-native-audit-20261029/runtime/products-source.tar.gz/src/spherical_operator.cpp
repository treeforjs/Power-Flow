#include "raikou/spherical_operator.h"
#include "raikou/eedf_distributed.h"
#include <algorithm>
#include <cmath>
#include <map>
#include <stdexcept>

namespace raikou::kinetics {
backend::CsrMatrix freeze_spherical_eedf_operator(const std::vector<CollisionProcess>& processes,
    const EedfConditions& conditions,const SphericalEedfState& state,const Vector3& electric_field_V_m){
    state.validate();
    const int terms=state.grid.legendre_terms,even_count=(terms+1)/2;
    const auto cells=static_cast<std::size_t>(state.grid.cells),stride=static_cast<std::size_t>(terms*terms),legacy_stride=static_cast<std::size_t>(terms);
    const double field=std::hypot(electric_field_V_m[0],electric_field_V_m[1],electric_field_V_m[2]);
    if(!(std::isfinite(field)&&conditions.gas_density_m3>0))throw std::invalid_argument("spherical operator: invalid field/gas density");
    const auto rotation=field>0?rotation_to_axis({-electric_field_V_m[0],-electric_field_V_m[1],-electric_field_V_m[2]}):AngularRotation{};
    const auto aligned=rotate_spherical_eedf(state,inverse_rotation(rotation));
    const HarmonicRotation transform(terms,rotation);
    const auto& blocks=transform.blocks();const auto& offsets=transform.offsets();
    const auto d=[&](int l,int output,int input){const double value=blocks[offsets[static_cast<std::size_t>(l)]+static_cast<std::size_t>((output+l)*(2*l+1)+input+l)];return std::abs(value)<1e-14?0.0:value;};
    const auto degree=[&](std::size_t slot){return slot<static_cast<std::size_t>(even_count)?2*static_cast<int>(slot):2*(static_cast<int>(slot)-even_count)+1;};
    DistributedEedfState frozen;frozen.grid=state.grid;frozen.time_s=state.time_s;
    frozen.partition={cells*legacy_stride,0,cells*legacy_stride};frozen.density_modes.assign(cells*legacy_stride,0);
    for(std::size_t i=0;i<cells;++i)for(std::size_t slot=0;slot<legacy_stride;++slot){const int l=degree(slot);frozen.density_modes[i*legacy_stride+slot]=aligned.density_modes[i*stride+spherical_index(l,0)]*std::sqrt(2*l+1.0);}
    auto local=conditions;local.reduced_field_td=field/conditions.gas_density_m3/1e-21;
    local.electron_fraction=state.electron_density_m3()/conditions.gas_density_m3;
    local.temporal_growth=false;local.execution.device="cpu";local.execution.mpi=false;
    std::vector<std::map<int,double>> rows(cells*stride);
    for(int m=0;m<terms;++m){
        const auto op=freeze_eedf_operator(processes,local,frozen,m,true);
        for(std::size_t row=0;row<op.matrix.local_rows();++row){
            const auto i=row/legacy_stride;const int l=degree(row%legacy_stride);
            if(l<m)continue;
            for(std::size_t entry=op.matrix.offsets[row];entry<op.matrix.offsets[row+1];++entry){
                const auto column=static_cast<std::size_t>(op.matrix.columns[entry]),j=column/legacy_stride;
                const int k=degree(column%legacy_stride);if(k<m)continue;
                const double value=op.matrix.values[entry]*(m==0?std::sqrt((2*k+1.0)/(2*l+1.0)):1.0);
                for(int sign:{-1,1}){
                    if(m==0&&sign<0)continue;
                    for(int out=-l;out<=l;++out){
                        const double output=d(l,out,sign*m);if(output==0)continue;
                        auto& output_row=rows[i*stride+spherical_index(l,out)];
                        for(int in=-k;in<=k;++in){const double input=d(k,in,sign*m);if(input!=0)output_row[static_cast<int>(j*stride+spherical_index(k,in))]+=output*value*input;}
                    }
                }
            }
        }
    }
    backend::CsrMatrix result;result.rows=rows.size();result.offsets.push_back(0);
    for(const auto& row:rows){for(const auto& [column,value]:row)if(value!=0){result.columns.push_back(column);result.values.push_back(value);}result.offsets.push_back(result.values.size());}
    result.validate();return result;
}
}
