#include "raikou/sparse_direct.h"
#include <cmath>
#include <stdexcept>
#ifdef RAIKOU_HAS_EIGEN
#include <Eigen/OrderingMethods>
#include <Eigen/SparseCore>
#include <Eigen/SparseLU>
#endif

namespace raikou::backend {

bool sparse_direct_available() {
#ifdef RAIKOU_HAS_EIGEN
    return true;
#else
    return false;
#endif
}

DirectResult solve_sparse_direct(const CsrMatrix& matrix, std::span<const double> rhs) {
    matrix.validate();
    if (rhs.size() != matrix.rows) throw std::invalid_argument("direct solve right-hand side size differs from the matrix");
    DirectResult result;
#ifdef RAIKOU_HAS_EIGEN
    using Index = Eigen::Index;
    const auto n = static_cast<Index>(matrix.rows);
    std::vector<Eigen::Triplet<double, Index>> entries;
    entries.reserve(matrix.values.size());
    for (std::size_t row = 0; row < matrix.rows; ++row)
        for (auto k = matrix.offsets[row]; k < matrix.offsets[row + 1]; ++k)
            entries.emplace_back(static_cast<Index>(row), static_cast<Index>(matrix.columns[k]), matrix.values[k]);
    Eigen::SparseMatrix<double, Eigen::ColMajor, Index> A(n, n);
    A.setFromTriplets(entries.begin(), entries.end());
    A.makeCompressed();
    Eigen::SparseLU<Eigen::SparseMatrix<double, Eigen::ColMajor, Index>, Eigen::COLAMDOrdering<Index>> lu;
    lu.compute(A);
    if (lu.info() != Eigen::Success) { result.message = "sparse LU factorization failed: " + lu.lastErrorMessage(); return result; }
    Eigen::Map<const Eigen::VectorXd> b(rhs.data(), n);
    const Eigen::VectorXd x = lu.solve(b);
    if (lu.info() != Eigen::Success) { result.message = "sparse LU solve failed"; return result; }
    result.solution.assign(x.data(), x.data() + n);
    for (const double value : result.solution) if (!std::isfinite(value)) { result.message = "sparse LU solution is not finite"; result.solution.clear(); return result; }
    result.solved = true;
#else
    (void)rhs;
    result.message = "this Raikou build has no sparse direct solver (configure with Eigen 3 available)";
#endif
    return result;
}

} // namespace raikou::backend
