#include "raikou/spatial_mesh.h"
#include <algorithm>
#include <cmath>
#include <limits>
#include <map>
#include <numbers>
#include <set>
#include <stdexcept>
#include <string>

namespace raikou::spatial::mesh {
namespace {
[[noreturn]] void bad(const std::string& message) { throw std::invalid_argument("spatial mesh: " + message); }
void require(bool value, const std::string& message) { if (!value) bad(message); }
Point add(const Point& a, const Point& b) { return {a[0] + b[0], a[1] + b[1], a[2] + b[2]}; }
Point subtract(const Point& a, const Point& b) { return {a[0] - b[0], a[1] - b[1], a[2] - b[2]}; }
Point scale(const Point& a, double v) { return {v * a[0], v * a[1], v * a[2]}; }
double dot(const Point& a, const Point& b) { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; }
Point cross(const Point& a, const Point& b) { return {a[1] * b[2] - a[2] * b[1], a[2] * b[0] - a[0] * b[2], a[0] * b[1] - a[1] * b[0]}; }
double length(const Point& a) { return std::sqrt(dot(a, a)); }
Point average(const Mesh& m, const std::vector<std::size_t>& ids) {
    // Subtract an anchor so large coordinate offsets do not dominate the sum.
    const auto anchor = m.nodes_m[ids[0]];
    Point center{};
    for (auto id : ids) center = add(center, scale(subtract(m.nodes_m[id], anchor), 1 / static_cast<double>(ids.size())));
    return add(anchor, center);
}
double cell_scale(const Mesh& m, const std::vector<std::size_t>& ids, const Point& center) {
    double s = 0;
    for (auto id : ids) s = std::max(s, length(subtract(m.nodes_m[id], center)));
    require(s > 0 && std::isfinite(s), "degenerate cell coordinates");
    return s;
}
std::vector<std::vector<std::size_t>> cell_faces(const Mesh::Cell& c, int dimension) {
    const bool tri = c.type == "tri3", quad = c.type == "quad4", tet = c.type == "tet4", hex = c.type == "hex8";
    require((dimension == 2 && (tri || quad)) || (dimension == 3 && (tet || hex)), "cell type must match dimension (tri3/quad4/tet4/hex8)");
    const auto& v = c.nodes;
    require(v.size() == (tri ? 3u : hex ? 8u : 4u), "cell connectivity length mismatch");
    if (dimension == 2) {
        std::vector<std::vector<std::size_t>> result;
        for (std::size_t k = 0; k < v.size(); ++k) result.push_back({v[k], v[(k + 1) % v.size()]});
        return result;
    }
    if (tet) return {{v[0], v[1], v[2]}, {v[0], v[1], v[3]}, {v[0], v[2], v[3]}, {v[1], v[2], v[3]}};
    return {{v[0], v[1], v[2], v[3]}, {v[4], v[5], v[6], v[7]},
        {v[0], v[1], v[5], v[4]}, {v[1], v[2], v[6], v[5]},
        {v[2], v[3], v[7], v[6]}, {v[3], v[0], v[4], v[7]}};
}
struct Polygon {
    std::size_t cell = 0;
    std::vector<std::size_t> nodes;
    Point center{}, normal{};
    double area = 0;
};
Polygon polygon(const Mesh& m, std::size_t cell, const std::vector<std::size_t>& ids,
    const Point& interior, double s) {
    Polygon p; p.cell = cell; p.nodes = ids;
    if (m.dimension == 2) {
        const auto& a = m.nodes_m[ids[0]];
        const auto& b = m.nodes_m[ids[1]];
        const Point d = subtract(b, a);
        const double edge = std::hypot(d[0], d[1]);
        require(edge > 1e-13 * s && std::isfinite(edge), "degenerate edge");
        p.normal = {d[1] / edge, -d[0] / edge, 0};
        p.center = add(a, scale(d, 0.5));
        if (m.axisymmetric) {
            const double r = p.center[0];
            require(a[0] >= 0 && b[0] >= 0, "axisymmetric radii must be nonnegative");
            p.area = 2 * std::numbers::pi * r * edge;
            if (r > 0) {
                // Exact line integrals of r^2 and r*z divided by integral r.
                p.center[0] = r + d[0] * d[0] / (12 * r);
                p.center[1] += d[0] * d[1] / (12 * r);
            }
        } else p.area = edge * m.extent_m[2];
    } else {
        const auto& anchor = m.nodes_m[ids[0]];
        Point twice_area{};
        for (std::size_t k = 1; k + 1 < ids.size(); ++k)
            twice_area = add(twice_area, cross(subtract(m.nodes_m[ids[k]], anchor), subtract(m.nodes_m[ids[k + 1]], anchor)));
        const double norm = length(twice_area);
        require(norm > 1e-13 * s * s && std::isfinite(norm), "degenerate face");
        p.normal = scale(twice_area, 1 / norm);
        Point weighted_center{};
        for (std::size_t k = 1; k + 1 < ids.size(); ++k) {
            const auto a = subtract(m.nodes_m[ids[k]], anchor);
            const auto b = subtract(m.nodes_m[ids[k + 1]], anchor);
            const double area = 0.5 * dot(cross(a, b), p.normal);
            require(area > 1e-13 * s * s, "nonconvex or inverted face connectivity");
            weighted_center = add(weighted_center, scale(add(a, b), area / 3));
            p.area += area;
        }
        p.center = add(anchor, scale(weighted_center, 1 / p.area));
        for (auto id : ids) require(std::abs(dot(subtract(m.nodes_m[id], p.center), p.normal)) <= 1e-10 * s, "nonplanar face is unsupported");
        for (std::size_t k = 0; k < ids.size(); ++k) {
            const Point a = subtract(m.nodes_m[ids[(k + 1) % ids.size()]], m.nodes_m[ids[k]]);
            const Point b = subtract(m.nodes_m[ids[(k + 2) % ids.size()]], m.nodes_m[ids[(k + 1) % ids.size()]]);
            require(dot(cross(a, b), p.normal) > 1e-13 * s * s, "nonconvex face is unsupported");
        }
    }
    if (dot(subtract(p.center, interior), p.normal) < 0) p.normal = scale(p.normal, -1);
    require(dot(subtract(p.center, interior), p.normal) > 1e-13 * s, "degenerate cell face height");
    return p;
}
void planar_moments(const Mesh& m, const std::vector<std::size_t>& ids,
    const Point& anchor, double& area, Point& centroid, double& volume) {
    double ix = 0, iy = 0, ixx = 0, ixy = 0;
    double orientation = 0;
    for (std::size_t k = 0; k < ids.size(); ++k) {
        const auto a = subtract(m.nodes_m[ids[k]], anchor);
        const auto b = subtract(m.nodes_m[ids[(k + 1) % ids.size()]], anchor);
        const double signed_twice = a[0] * b[1] - a[1] * b[0];
        if (k == 0) orientation = signed_twice;
        require(signed_twice * orientation > 0, "nonconvex or degenerate planar cell");
        const double triangle = 0.5 * std::abs(signed_twice);
        area += triangle;
        ix += triangle * (a[0] + b[0]) / 3;
        iy += triangle * (a[1] + b[1]) / 3;
        ixx += triangle * (a[0] * a[0] + a[0] * b[0] + b[0] * b[0]) / 6;
        ixy += triangle * (2 * a[0] * a[1] + a[0] * b[1] + b[0] * a[1] + 2 * b[0] * b[1]) / 12;
    }
    require(area > 0 && std::isfinite(area), "invalid planar area");
    centroid = {anchor[0] + ix / area, anchor[1] + iy / area, anchor[2]};
    if (m.axisymmetric) {
        const double ir = anchor[0] * area + ix;
        require(ir > 0 && std::isfinite(ir), "axisymmetric cell has zero radial volume");
        volume = 2 * std::numbers::pi * ir;
        centroid[0] = (anchor[0] * anchor[0] * area + 2 * anchor[0] * ix + ixx) / ir;
        centroid[1] = (anchor[0] * anchor[1] * area + anchor[1] * ix + anchor[0] * iy + ixy) / ir;
    } else volume = area * m.extent_m[2];
}
void alignment(Geometry& g, const Point& delta, const Point& normal, double dn) {
    const double norm = length(delta);
    require(norm > 0 && std::isfinite(norm) && dn > 1e-13 * norm && std::isfinite(dn), "nonpositive or degenerate normal distance");
    g.minimum_normal_cosine = std::min(g.minimum_normal_cosine, dn / norm);
    require(std::abs(dot(normal, normal) - 1) < 1e-10, "invalid face normal");
}
Geometry supplied(const Mesh& m) {
    require(!m.nodes_m.empty() && !m.cells.empty(), "supplied mesh requires nodes and cells");
    require(!m.axisymmetric || m.dimension == 2, "axisymmetric meshes must be 2D");
    require(m.extent_m[2] > 0 && std::isfinite(m.extent_m[2]), "planar depth must be positive");
    for (const auto& p : m.nodes_m) {
        for (double x : p) require(std::isfinite(x), "nonfinite mesh coordinate");
        if (m.axisymmetric) require(p[0] >= 0, "axisymmetric radii must be nonnegative");
    }
    std::map<std::vector<std::size_t>, int> boundaries;
    for (const auto& b : m.boundary_faces) {
        auto key = b.nodes;
        std::sort(key.begin(), key.end());
        require(key.size() >= 2 && key.back() < m.nodes_m.size() && std::adjacent_find(key.begin(), key.end()) == key.end(), "invalid boundary connectivity");
        require(b.side >= 0 && b.side < 6 && boundaries.emplace(key, b.side).second, "invalid or duplicate boundary side");
    }
    Geometry g; g.dimension = m.dimension; g.axisymmetric = m.axisymmetric;
    g.volume.resize(m.cells.size()); g.centers.resize(m.cells.size());
    std::map<std::vector<std::size_t>, Polygon> unmatched;
    std::set<std::vector<std::size_t>> matched;
    for (std::size_t c = 0; c < m.cells.size(); ++c) {
        const auto& ids = m.cells[c].nodes;
        const auto faces = cell_faces(m.cells[c], m.dimension);
        auto unique = ids;
        std::sort(unique.begin(), unique.end());
        require(unique.back() < m.nodes_m.size() && std::adjacent_find(unique.begin(), unique.end()) == unique.end(), "invalid cell connectivity");
        const Point anchor = average(m, ids);
        const double s = cell_scale(m, ids, anchor);
        if (m.dimension == 2) {
            for (auto id : ids) require(std::abs(m.nodes_m[id][2] - m.nodes_m[0][2]) <= 1e-10 * s, "2D supplied mesh must lie in the XY plane");
            double area = 0;
            planar_moments(m, ids, anchor, area, g.centers[c], g.volume[c]);
        }
        std::vector<Polygon> polygons;
        for (const auto& face_ids : faces) {
            auto p = polygon(m, c, face_ids, anchor, s);
            for (auto id : ids) require(dot(subtract(m.nodes_m[id], p.center), p.normal) <= 1e-10 * s, "nonconvex or inverted supplied cell");
            if (m.dimension == 3) {
                const auto a = subtract(m.nodes_m[face_ids[0]], anchor);
                for (std::size_t k = 1; k + 1 < face_ids.size(); ++k) {
                    const auto b = subtract(m.nodes_m[face_ids[k]], anchor);
                    const auto d = subtract(m.nodes_m[face_ids[k + 1]], anchor);
                    const double volume = std::abs(dot(a, cross(b, d))) / 6;
                    g.volume[c] += volume;
                    g.centers[c] = add(g.centers[c], scale(add(add(a, b), d), volume / 4));
                }
            }
            polygons.push_back(std::move(p));
        }
        require(g.volume[c] > 0 && std::isfinite(g.volume[c]), "cell volume must be finite and positive");
        if (m.dimension == 3) g.centers[c] = add(anchor, scale(g.centers[c], 1 / g.volume[c]));
        for (const auto& p : polygons) {
            const double da = dot(subtract(p.center, g.centers[c]), p.normal);
            require(da > 1e-13 * s, "geometric centroid is on or outside a face");
            auto key = p.nodes;
            std::sort(key.begin(), key.end());
            require(matched.find(key) == matched.end(), "nonmanifold face belongs to more than two cells");
            const auto previous = unmatched.find(key);
            if (previous == unmatched.end()) unmatched.emplace(std::move(key), p);
            else {
                const auto& first = previous->second;
                require(first.cell != c, "duplicate cell face");
                require(boundaries.find(key) == boundaries.end(), "an interior face cannot have a boundary label");
                require(std::abs(first.area - p.area) <= 1e-10 * std::max(first.area, p.area), "inconsistent shared face area");
                require(length(subtract(first.center, p.center)) <= 1e-10 * s && dot(first.normal, p.normal) < -1 + 1e-10, "inconsistent or overlapping shared face");
                const auto delta = subtract(g.centers[c], g.centers[first.cell]);
                const double dn = dot(delta, first.normal);
                alignment(g, delta, first.normal, dn);
                g.faces.push_back({first.cell, c, p.area, first.normal, first.center, dn, delta});
                matched.insert(key); unmatched.erase(previous);
            }
        }
    }
    for (const auto& [key, p] : unmatched) {
        const auto b = boundaries.find(key);
        require(b != boundaries.end(), "every exterior supplied face needs an explicit side label");
        const auto delta = subtract(p.center, g.centers[p.cell]);
        const double dn = dot(delta, p.normal);
        alignment(g, delta, p.normal, dn);
        g.walls.push_back({p.cell, b->second, p.area, p.normal, p.center, dn, delta});
        boundaries.erase(b);
    }
    require(boundaries.empty(), "boundary face does not belong to the exterior mesh");
    return g;
}
Geometry structured(const Mesh& m) {
    require(!m.axisymmetric || m.dimension == 2, "axisymmetric meshes must be 2D");
    if (m.dimension == 2) require(m.shape[2] == 1, "2D shape[2] must be 1");
    std::size_t nc = 1;
    Point h{};
    for (std::size_t d = 0; d < 3; ++d) {
        require(m.shape[d] > 0 && m.shape[d] <= 1000000, "invalid mesh shape");
        require(nc <= 10000000 / m.shape[d], "mesh has too many cells");
        nc *= m.shape[d];
        require(m.extent_m[d] > 0 && std::isfinite(m.extent_m[d]), "mesh extents must be finite and positive");
        h[d] = m.extent_m[d] / static_cast<double>(m.shape[d]);
    }
    Geometry g; g.dimension = m.dimension; g.axisymmetric = m.axisymmetric;
    g.volume.resize(nc); g.centers.resize(nc);
    const std::array<std::size_t, 3> stride{1, m.shape[0], m.shape[0] * m.shape[1]};
    for (std::size_t z = 0; z < m.shape[2]; ++z)
        for (std::size_t y = 0; y < m.shape[1]; ++y)
            for (std::size_t x = 0; x < m.shape[0]; ++x) {
                const std::size_t c = x + m.shape[0] * (y + m.shape[1] * z);
                const double r0 = static_cast<double>(x) * h[0], r1 = r0 + h[0];
                g.centers[c] = {(static_cast<double>(x) + 0.5) * h[0], (static_cast<double>(y) + 0.5) * h[1], (static_cast<double>(z) + 0.5) * h[2]};
                if (m.axisymmetric) {
                    g.volume[c] = std::numbers::pi * (r1 - r0) * (r1 + r0) * h[1];
                    g.centers[c][0] = (2. / 3) * (r1 * r1 + r0 * r1 + r0 * r0) / (r1 + r0);
                } else g.volume[c] = h[0] * h[1] * h[2];
                require(g.volume[c] > 0 && std::isfinite(g.volume[c]), "structured cell volume must be finite and positive");
                for (double coordinate : g.centers[c]) require(std::isfinite(coordinate), "nonfinite structured cell centroid");
            }
    for (std::size_t z = 0; z < m.shape[2]; ++z)
        for (std::size_t y = 0; y < m.shape[1]; ++y)
            for (std::size_t x = 0; x < m.shape[0]; ++x) {
                const std::size_t c = x + m.shape[0] * (y + m.shape[1] * z);
                const std::array<std::size_t, 3> index{x, y, z};
                const double r0 = static_cast<double>(x) * h[0], r1 = r0 + h[0];
                for (int d = 0; d < m.dimension; ++d) {
                    const auto dd = static_cast<std::size_t>(d);
                    const auto face_area = [&](bool high) {
                        if (!m.axisymmetric) return g.volume[c] / h[dd];
                        if (d == 0) return 2 * std::numbers::pi * (high ? r1 : r0) * h[1];
                        return std::numbers::pi * (r1 - r0) * (r1 + r0);
                    };
                    Point normal{}; normal[dd] = 1;
                    Point center = g.centers[c]; center[dd] = static_cast<double>(index[dd] + 1) * h[dd];
                    if (index[dd] + 1 < m.shape[dd]) {
                        const auto b = c + stride[dd];
                        const auto delta = subtract(g.centers[b], g.centers[c]);
                        const double dn = dot(delta, normal);
                        alignment(g, delta, normal, dn);
                        g.faces.push_back({c, b, face_area(true), normal, center, dn, delta});
                    } else {
                        const auto delta = subtract(center, g.centers[c]);
                        const double dn = dot(delta, normal);
                        alignment(g, delta, normal, dn);
                        g.walls.push_back({c, 2 * d + 1, face_area(true), normal, center, dn, delta});
                    }
                    if (index[dd] == 0) {
                        normal[dd] = -1; center[dd] = 0;
                        const auto delta = subtract(center, g.centers[c]);
                        const double dn = dot(delta, normal);
                        alignment(g, delta, normal, dn);
                        g.walls.push_back({c, 2 * d, face_area(false), normal, center, dn, delta});
                    }
                }
            }
    return g;
}
struct Form {
    std::map<std::size_t, double> cells, boundaries;
    void append(const Form& other, double factor) {
        if (factor == 0) return;
        for (const auto& [i, value] : other.cells) cells[i] += factor * value;
        for (const auto& [i, value] : other.boundaries) boundaries[i] += factor * value;
    }
    ScalarStencil stencil() const {
        ScalarStencil s;
        for (const auto& [i, value] : cells) if (value != 0) s.cells.emplace_back(i, value);
        for (const auto& [i, value] : boundaries) if (value != 0) s.boundaries.emplace_back(i, value);
        return s;
    }
};
using Matrix = std::array<std::array<double, 3>, 3>;
Matrix inverse(const Matrix& matrix, int dimension, double& condition) {
    double a[3][6]{};
    double norm = 0;
    for (int i = 0; i < dimension; ++i) {
        double row = 0;
        for (int j = 0; j < dimension; ++j) { a[i][j] = matrix[static_cast<std::size_t>(i)][static_cast<std::size_t>(j)]; row += std::abs(a[i][j]); }
        norm = std::max(norm, row); a[i][dimension + i] = 1;
    }
    require(norm > 0 && std::isfinite(norm), "least-squares reconstruction has no geometric constraints");
    for (int k = 0; k < dimension; ++k) {
        int pivot = k;
        for (int i = k + 1; i < dimension; ++i) if (std::abs(a[i][k]) > std::abs(a[pivot][k])) pivot = i;
        require(std::abs(a[pivot][k]) > 1e-13 * norm, "least-squares reconstruction is rank deficient");
        for (int j = 0; j < 2 * dimension; ++j) std::swap(a[k][j], a[pivot][j]);
        const double diagonal = a[k][k];
        for (int j = 0; j < 2 * dimension; ++j) a[k][j] /= diagonal;
        for (int i = 0; i < dimension; ++i) if (i != k) {
            const double factor = a[i][k];
            for (int j = 0; j < 2 * dimension; ++j) a[i][j] -= factor * a[k][j];
        }
    }
    Matrix result{}; double inverse_norm = 0;
    for (int i = 0; i < dimension; ++i) {
        double row = 0;
        for (int j = 0; j < dimension; ++j) { result[static_cast<std::size_t>(i)][static_cast<std::size_t>(j)] = a[i][dimension + j]; row += std::abs(a[i][dimension + j]); }
        inverse_norm = std::max(inverse_norm, row);
    }
    condition = norm * inverse_norm;
    require(condition <= 1e12 && std::isfinite(condition), "least-squares reconstruction is ill conditioned");
    return result;
}
} // namespace

double ScalarStencil::evaluate(std::span<const double> cell_values, std::span<const double> boundary_values) const {
    long double value = 0;
    for (const auto& [i, coefficient] : cells) { require(i < cell_values.size(), "cell stencil value count mismatch"); value += static_cast<long double>(coefficient) * cell_values[i]; }
    for (const auto& [i, coefficient] : boundaries) { require(i < boundary_values.size(), "boundary stencil value count mismatch"); value += static_cast<long double>(coefficient) * boundary_values[i]; }
    return static_cast<double>(value);
}

Geometry geometry(const Mesh& m) {
    require(m.dimension == 2 || m.dimension == 3, "dimension must be 2 or 3");
    if (!m.cells.empty() || !m.nodes_m.empty()) return supplied(m);
    require(m.boundary_faces.empty(), "structured meshes do not accept supplied boundary faces");
    return structured(m);
}

FluxStencils normal_derivatives(const Geometry& g, std::span<const BoundaryCondition> conditions) {
    require(g.dimension == 2 || g.dimension == 3, "invalid geometry dimension");
    require(!g.centers.empty() && g.centers.size() == g.volume.size(), "invalid geometry cell arrays");
    require(conditions.empty() || conditions.size() == g.walls.size(), "one boundary condition is required per wall");
    const auto condition = [&](std::size_t wall) { return g.walls[wall].area == 0 ? BoundaryCondition::Neumann : conditions.empty() ? BoundaryCondition::Dirichlet : conditions[wall]; };
    const std::size_t nc = g.centers.size();
    std::vector<Matrix> matrices(nc);
    std::vector<std::array<Form, 3>> right(nc), gradients(nc);
    const auto constraint = [&](std::size_t cell, const Point& delta, const Form& difference) {
        const double norm2 = dot(delta, delta);
        require(norm2 > 0 && std::isfinite(norm2), "invalid least-squares displacement");
        for (int i = 0; i < g.dimension; ++i) {
            const auto ii = static_cast<std::size_t>(i);
            right[cell][ii].append(difference, delta[ii] / norm2);
            for (int j = 0; j < g.dimension; ++j) {
                const auto jj = static_cast<std::size_t>(j);
                matrices[cell][ii][jj] += delta[ii] * delta[jj] / norm2;
            }
        }
    };
    for (const auto& f : g.faces) {
        require(f.a < nc && f.b < nc && f.a != f.b && f.normal_distance > 0, "invalid interior geometry");
        Form difference; difference.cells[f.b] = 1; difference.cells[f.a] = -1;
        constraint(f.a, f.delta, difference);
        Form reverse; reverse.append(difference, -1);
        constraint(f.b, scale(f.delta, -1), reverse);
    }
    for (std::size_t w = 0; w < g.walls.size(); ++w) {
        const auto& wall = g.walls[w];
        require(wall.cell < nc && wall.normal_distance > 0, "invalid boundary geometry");
        Form difference;
        if (condition(w) == BoundaryCondition::Dirichlet) {
            difference.cells[wall.cell] = -1; difference.boundaries[w] = 1;
            constraint(wall.cell, wall.delta, difference);
        } else constraint(wall.cell, wall.normal, difference);
    }
    FluxStencils result;
    result.cell_gradients.resize(nc); result.gradient_condition_numbers.resize(nc);
    for (std::size_t cell = 0; cell < nc; ++cell) {
        const auto inv = inverse(matrices[cell], g.dimension, result.gradient_condition_numbers[cell]);
        for (int i = 0; i < g.dimension; ++i) {
            const auto ii = static_cast<std::size_t>(i);
            for (int j = 0; j < g.dimension; ++j) gradients[cell][ii].append(right[cell][static_cast<std::size_t>(j)], inv[ii][static_cast<std::size_t>(j)]);
            result.cell_gradients[cell][ii] = gradients[cell][ii].stencil();
        }
    }
    for (const auto& f : g.faces) {
        Form flux;
        flux.cells[f.a] = -1 / f.normal_distance; flux.cells[f.b] = 1 / f.normal_distance;
        const auto correction = subtract(f.normal, scale(f.delta, 1 / f.normal_distance));
        if (length(correction) > 1e-12) result.has_nonorthogonal_corrections = true;
        const double da = dot(subtract(f.center, g.centers[f.a]), f.normal);
        const double db = dot(subtract(g.centers[f.b], f.center), f.normal);
        require(da > 0 && db > 0, "face is outside its neighboring cells");
        for (int d = 0; d < g.dimension; ++d) {
            const auto dd = static_cast<std::size_t>(d);
            flux.append(gradients[f.a][dd], correction[dd] * db / (da + db));
            flux.append(gradients[f.b][dd], correction[dd] * da / (da + db));
        }
        result.interior.push_back(flux.stencil());
    }
    for (std::size_t w = 0; w < g.walls.size(); ++w) {
        Form flux;
        const auto& wall = g.walls[w];
        if (condition(w) == BoundaryCondition::Dirichlet) {
            flux.cells[wall.cell] = -1 / wall.normal_distance; flux.boundaries[w] = 1 / wall.normal_distance;
            const auto correction = subtract(wall.normal, scale(wall.delta, 1 / wall.normal_distance));
            if (length(correction) > 1e-12) result.has_nonorthogonal_corrections = true;
            for (int d = 0; d < g.dimension; ++d) flux.append(gradients[wall.cell][static_cast<std::size_t>(d)], correction[static_cast<std::size_t>(d)]);
        }
        result.boundary.push_back(flux.stencil());
    }
    return result;
}

FluxStencils normal_derivatives_active(const Geometry& g,
    std::span<const BoundaryCondition> conditions, std::span<const double> fractions) {
    const auto nc = g.centers.size();
    require(fractions.size() == 1 || fractions.size() == nc, "active fractions must be scalar or one value per cell");
    require(conditions.empty() || conditions.size() == g.walls.size(), "one boundary condition is required per wall");
    for (double fraction : fractions) require(fraction >= 0 && fraction <= 1 && std::isfinite(fraction), "active fractions must be finite and in [0,1]");
    const auto absent = std::numeric_limits<std::size_t>::max();
    std::vector<std::size_t> local_cell(nc, absent), global_cells;
    Geometry sub; sub.dimension = g.dimension; sub.axisymmetric = g.axisymmetric;
    for (std::size_t c = 0; c < nc; ++c) if (fractions[fractions.size() == 1 ? 0 : c] > 0) {
        local_cell[c] = global_cells.size(); global_cells.push_back(c);
        sub.centers.push_back(g.centers[c]); sub.volume.push_back(g.volume.at(c));
    }
    if (global_cells.size() == nc) return normal_derivatives(g, conditions);
    FluxStencils result;
    result.cell_gradients.resize(nc); result.gradient_condition_numbers.resize(nc);
    result.interior.resize(g.faces.size()); result.boundary.resize(g.walls.size());
    if (global_cells.empty()) return result;
    std::vector<std::size_t> global_faces, global_walls;
    std::vector<BoundaryCondition> sub_conditions;
    for (std::size_t f = 0; f < g.faces.size(); ++f) {
        const auto& face = g.faces[f];
        require(face.a < nc && face.b < nc, "invalid active-phase interior geometry");
        const bool a = local_cell[face.a] != absent, b = local_cell[face.b] != absent;
        if (a && b) {
            auto local_face = face; local_face.a = local_cell[face.a]; local_face.b = local_cell[face.b];
            sub.faces.push_back(local_face); global_faces.push_back(f);
        } else if (a || b) {
            const auto cell = a ? face.a : face.b;
            const Point normal = a ? face.normal : scale(face.normal, -1);
            const Point delta = subtract(face.center, g.centers[cell]);
            const double dn = dot(delta, normal);
            require(dn > 0 && std::isfinite(dn), "invalid active-phase barrier face distance");
            sub.walls.push_back({local_cell[cell], -1, face.area, normal, face.center, dn, delta});
            sub_conditions.push_back(BoundaryCondition::Neumann); global_walls.push_back(absent);
        }
    }
    for (std::size_t w = 0; w < g.walls.size(); ++w) {
        const auto& wall = g.walls[w];
        require(wall.cell < nc, "invalid active-phase exterior geometry");
        if (local_cell[wall.cell] == absent) continue;
        auto local_wall = wall; local_wall.cell = local_cell[wall.cell];
        sub.walls.push_back(local_wall); global_walls.push_back(w);
        sub_conditions.push_back(conditions.empty() ? BoundaryCondition::Dirichlet : conditions[w]);
    }
    const auto local = normal_derivatives(sub, sub_conditions);
    const auto remap = [&](const ScalarStencil& stencil) {
        ScalarStencil mapped;
        for (const auto& [c, coefficient] : stencil.cells) mapped.cells.emplace_back(global_cells[c], coefficient);
        for (const auto& [w, coefficient] : stencil.boundaries) {
            require(global_walls[w] != absent, "phase barrier value leaked into a reconstruction stencil");
            mapped.boundaries.emplace_back(global_walls[w], coefficient);
        }
        return mapped;
    };
    for (std::size_t c = 0; c < global_cells.size(); ++c) {
        for (std::size_t d = 0; d < 3; ++d) result.cell_gradients[global_cells[c]][d] = remap(local.cell_gradients[c][d]);
        result.gradient_condition_numbers[global_cells[c]] = local.gradient_condition_numbers[c];
    }
    for (std::size_t f = 0; f < global_faces.size(); ++f) result.interior[global_faces[f]] = remap(local.interior[f]);
    for (std::size_t w = 0; w < global_walls.size(); ++w) if (global_walls[w] != absent) result.boundary[global_walls[w]] = remap(local.boundary[w]);
    result.has_nonorthogonal_corrections = local.has_nonorthogonal_corrections;
    return result;
}

EllipticAssembly assemble_elliptic(const Geometry& g, std::span<const double> conductivity,
    std::span<const double> rhs_density, std::span<const EllipticBoundary> boundaries) {
    const std::size_t nc = g.centers.size();
    require(conductivity.size() == 1 || conductivity.size() == nc, "conductivity must be scalar or one value per cell");
    require(rhs_density.empty() || rhs_density.size() == nc, "elliptic source density must have one value per cell");
    require(boundaries.size() == g.walls.size(), "elliptic boundary count mismatch");
    for (double k : conductivity) require(k > 0 && std::isfinite(k), "elliptic conductivity must be finite and positive");
    for (double source : rhs_density) require(std::isfinite(source), "nonfinite elliptic source density");
    const auto kcell = [&](std::size_t cell) { return conductivity[conductivity.size() == 1 ? 0 : cell]; };
    EllipticAssembly result;
    std::vector<BoundaryCondition> gradient_boundaries;
    result.robin_wall_dofs.assign(g.walls.size(), -1);
    std::size_t ndof = nc;
    for (std::size_t w = 0; w < g.walls.size(); ++w) {
        const auto& b = boundaries[w];
        require(std::isfinite(b.value) && b.capacitance >= 0 && std::isfinite(b.capacitance) && std::isfinite(b.source), "invalid elliptic boundary data");
        require(b.kind == EllipticBoundaryKind::Dirichlet || b.kind == EllipticBoundaryKind::Neumann || b.kind == EllipticBoundaryKind::Robin, "unknown elliptic boundary kind");
        gradient_boundaries.push_back(g.walls[w].area == 0 || b.kind == EllipticBoundaryKind::Neumann ? BoundaryCondition::Neumann : BoundaryCondition::Dirichlet);
        if (g.walls[w].area > 0 && b.kind == EllipticBoundaryKind::Robin) {
            require(ndof < static_cast<std::size_t>(std::numeric_limits<int>::max()), "elliptic system exceeds CSR index range");
            result.robin_wall_dofs[w] = static_cast<int>(ndof++);
        }
    }
    require(ndof <= static_cast<std::size_t>(std::numeric_limits<int>::max()), "elliptic system exceeds CSR index range");
    result.stencils = normal_derivatives(g, gradient_boundaries);
    result.rhs.resize(ndof);
    std::vector<std::map<int, double>> rows(ndof);
    for (std::size_t c = 0; c < nc; ++c) if (!rhs_density.empty()) result.rhs[c] = rhs_density[c] * g.volume[c];
    const auto append = [&](std::size_t row, const ScalarStencil& stencil, double factor) {
        for (const auto& [c, coefficient] : stencil.cells) rows[row][static_cast<int>(c)] += factor * coefficient;
        for (const auto& [w, coefficient] : stencil.boundaries) {
            if (result.robin_wall_dofs[w] >= 0) rows[row][result.robin_wall_dofs[w]] += factor * coefficient;
            else {
                require(boundaries[w].kind == EllipticBoundaryKind::Dirichlet, "Neumann boundary value leaked into a reconstruction stencil");
                result.rhs[row] -= factor * coefficient * boundaries[w].value;
            }
        }
    };
    for (std::size_t f = 0; f < g.faces.size(); ++f) {
        const auto& face = g.faces[f];
        const double da = dot(subtract(face.center, g.centers[face.a]), face.normal);
        const double db = dot(subtract(g.centers[face.b], face.center), face.normal);
        require(da > 0 && db > 0, "nonpositive material face distance");
        const double wa = da / (da + db), wb = db / (da + db);
        const double ka = kcell(face.a), kb = kcell(face.b), minimum = std::min(ka, kb);
        // Factoring out the smaller k avoids overflow of products/reciprocals.
        const double k = minimum / (wa * (minimum / ka) + wb * (minimum / kb));
        require(k > 0 && std::isfinite(k), "nonfinite harmonic face conductivity");
        result.interior_conductivity.push_back(k);
        append(face.a, result.stencils.interior[f], -face.area * k);
        append(face.b, result.stencils.interior[f], face.area * k);
    }
    for (std::size_t w = 0; w < g.walls.size(); ++w) {
        const auto& wall = g.walls[w];
        const double k = kcell(wall.cell);
        append(wall.cell, result.stencils.boundary[w], -wall.area * k);
        if (result.robin_wall_dofs[w] >= 0) {
            const auto row = static_cast<std::size_t>(result.robin_wall_dofs[w]);
            append(row, result.stencils.boundary[w], k);
            rows[row][result.robin_wall_dofs[w]] += boundaries[w].capacitance;
            result.rhs[row] += boundaries[w].source + boundaries[w].capacitance * boundaries[w].value;
        }
    }
    result.matrix.rows = ndof;
    result.matrix.offsets.reserve(ndof + 1);
    result.matrix.offsets.push_back(0);
    for (const auto& row : rows) {
        for (const auto& [column, coefficient] : row) if (coefficient != 0) {
            require(std::isfinite(coefficient), "nonfinite assembled elliptic coefficient");
            result.matrix.columns.push_back(column); result.matrix.values.push_back(coefficient);
        }
        result.matrix.offsets.push_back(result.matrix.values.size());
    }
    for (double value : result.rhs) require(std::isfinite(value), "nonfinite assembled elliptic right-hand side");
    return result;
}

} // namespace raikou::spatial::mesh
