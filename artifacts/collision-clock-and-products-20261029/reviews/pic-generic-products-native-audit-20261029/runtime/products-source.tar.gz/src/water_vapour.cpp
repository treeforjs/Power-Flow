#include "raikou/water_vapour.h"
#include <algorithm>
#include <cmath>
#include <numbers>
#include <stdexcept>

namespace raikou::kinetics {
namespace {
constexpr double kCmToEv = 1.239841984e-4;      // eV per cm^-1
constexpr double kBohr = 5.29177210903e-11;     // m
constexpr double kRydberg = 13.605693122994;    // eV
constexpr double kDebyeAu = 0.393430307;        // e a0 per debye
constexpr double kKelvinEv = 1.380649e-23 / 1.602176634e-19;

[[noreturn]] void bad(const std::string& what) { throw std::invalid_argument("water vapour: " + what); }

// Wigner 3j symbol for integer arguments (Racah's formula).
double log_factorial(int n) { return std::lgamma(n + 1.0); }
double wigner3j(int j1, int j2, int j3, int m1, int m2, int m3) {
    if (m1 + m2 + m3 != 0) return 0.0;
    if (j3 < std::abs(j1 - j2) || j3 > j1 + j2) return 0.0;
    if (std::abs(m1) > j1 || std::abs(m2) > j2 || std::abs(m3) > j3) return 0.0;
    const double triangle = log_factorial(j1 + j2 - j3) + log_factorial(j1 - j2 + j3) + log_factorial(-j1 + j2 + j3) - log_factorial(j1 + j2 + j3 + 1);
    const double front = 0.5 * (triangle + log_factorial(j1 + m1) + log_factorial(j1 - m1) + log_factorial(j2 + m2) + log_factorial(j2 - m2) +
                                log_factorial(j3 + m3) + log_factorial(j3 - m3));
    const int kmin = std::max({0, j2 - j3 - m1, j1 - j3 + m2}), kmax = std::min({j1 + j2 - j3, j1 - m1, j2 + m2});
    double sum = 0;
    for (int k = kmin; k <= kmax; ++k) {
        const double term = std::exp(front - log_factorial(k) - log_factorial(j1 + j2 - j3 - k) - log_factorial(j1 - m1 - k) - log_factorial(j2 + m2 - k) -
                                     log_factorial(j3 - j2 + m1 + k) - log_factorial(j3 - j1 - m2 + k));
        sum += (k % 2 == 0 ? 1.0 : -1.0) * term;
    }
    return ((j1 - j2 - m3) % 2 == 0 ? 1.0 : -1.0) * sum;
}

// Eigen-decomposition of a small symmetric matrix by cyclic Jacobi rotations.
void jacobi(std::vector<double>& a, std::size_t n, std::vector<double>& values, std::vector<double>& vectors) {
    vectors.assign(n * n, 0.0);
    for (std::size_t i = 0; i < n; ++i) vectors[i * n + i] = 1;
    for (int sweep = 0; sweep < 100; ++sweep) {
        double off = 0;
        for (std::size_t p = 0; p < n; ++p)
            for (std::size_t q = p + 1; q < n; ++q) off += a[p * n + q] * a[p * n + q];
        if (off < 1e-30) break;
        for (std::size_t p = 0; p < n; ++p)
            for (std::size_t q = p + 1; q < n; ++q) {
                const double apq = a[p * n + q];
                if (std::abs(apq) < 1e-300) continue;
                const double theta = (a[q * n + q] - a[p * n + p]) / (2 * apq);
                const double t = (theta >= 0 ? 1.0 : -1.0) / (std::abs(theta) + std::sqrt(theta * theta + 1));
                const double c = 1 / std::sqrt(t * t + 1), s = t * c;
                for (std::size_t k = 0; k < n; ++k) {
                    const double akp = a[k * n + p], akq = a[k * n + q];
                    a[k * n + p] = c * akp - s * akq;
                    a[k * n + q] = s * akp + c * akq;
                }
                for (std::size_t k = 0; k < n; ++k) {
                    const double apk = a[p * n + k], aqk = a[q * n + k];
                    a[p * n + k] = c * apk - s * aqk;
                    a[q * n + k] = s * apk + c * aqk;
                }
                for (std::size_t k = 0; k < n; ++k) {
                    const double vkp = vectors[k * n + p], vkq = vectors[k * n + q];
                    vectors[k * n + p] = c * vkp - s * vkq;
                    vectors[k * n + q] = s * vkp + c * vkq;
                }
            }
    }
    values.resize(n);
    for (std::size_t i = 0; i < n; ++i) values[i] = a[i * n + i];
}

double interpolate(const std::vector<double>& x, const std::vector<double>& y, double at) {
    if (x.empty()) return 1.0;
    if (at <= x.front()) return y.front();
    if (at >= x.back()) return y.back();
    const auto k = static_cast<std::size_t>(std::upper_bound(x.begin(), x.end(), at) - x.begin()) - 1;
    return y[k] + (y[k + 1] - y[k]) * (at - x[k]) / (x[k + 1] - x[k]);
}

// g_1 = Q_1(a) / Q_0(a) for the Born dipole angular form.
double born_g1(double a) {
    if (!(a > 1) || !std::isfinite(a)) return 0.0;
    const double q0 = 0.5 * std::log((a + 1) / (a - 1));
    return a - 1 / q0;
}
} // namespace

double born_dipole_cross_section(double e, double u, double strength_over_degeneracy, double dipole_debye) {
    if (!(e > u) || !(e > 0)) return 0.0;
    const double mu = dipole_debye * kDebyeAu;
    const double r = std::sqrt(e), s = std::sqrt(e - u);
    return 8 * std::numbers::pi / 3 * kBohr * kBohr * mu * mu * (kRydberg / e) * strength_over_degeneracy * std::log((r + s) / (r - s));
}

std::vector<RotorLevel> asymmetric_top_levels(double a_cm, double b_cm, double c_cm, int j_max, const std::string& prefix) {
    if (!(a_cm >= b_cm && b_cm >= c_cm && c_cm > 0)) bad("rotational constants must satisfy A >= B >= C > 0");
    if (j_max < 0 || j_max > 40) bad("j_max must be between 0 and 40");
    std::vector<RotorLevel> levels;
    for (int j = 0; j <= j_max; ++j) {
        const auto n = static_cast<std::size_t>(2 * j + 1);
        const double jj = j * (j + 1.0);
        std::vector<double> h(n * n, 0.0), values, vectors;
        for (int k = -j; k <= j; ++k) {
            const auto i = static_cast<std::size_t>(k + j);
            h[i * n + i] = a_cm * k * k + 0.5 * (b_cm + c_cm) * (jj - k * k);
            if (k + 2 <= j) {
                const double v = 0.25 * (b_cm - c_cm) * std::sqrt((jj - k * (k + 1.0)) * (jj - (k + 1.0) * (k + 2.0)));
                h[i * n + i + 2] = h[(i + 2) * n + i] = v;
            }
        }
        jacobi(h, n, values, vectors);
        std::vector<std::size_t> order(n);
        for (std::size_t i = 0; i < n; ++i) order[i] = i;
        std::sort(order.begin(), order.end(), [&](std::size_t x, std::size_t y) { return values[x] < values[y]; });
        for (std::size_t rank = 0; rank < n; ++rank) {
            const int tau = static_cast<int>(rank) - j;  // Ka - Kc, increasing with energy
            RotorLevel level;
            level.j = j;
            level.ka = (j + tau + 1) / 2;
            level.kc = j - (j + tau) / 2;
            level.energy_ev = values[order[rank]] * kCmToEv;
            level.ortho = (level.ka + level.kc) % 2 == 1;
            // J_KaKc, with a comma between Ka and Kc once either reaches 10 so names stay unique.
            level.name = prefix + "(" + std::to_string(j) + "_" + std::to_string(level.ka) + (j >= 10 ? "," : "") + std::to_string(level.kc) + ")";
            level.vector.resize(n);
            for (std::size_t i = 0; i < n; ++i) level.vector[i] = vectors[i * n + order[rank]];
            levels.push_back(std::move(level));
        }
    }
    const double ground = levels.front().energy_ev;
    for (auto& l : levels) l.energy_ev -= ground;
    return levels;
}

std::vector<DipoleTransition> b_dipole_transitions(const std::vector<RotorLevel>& levels, double min_strength) {
    // S = (2J+1)(2J'+1) |sum_{K,q} c'_{K+q} c_K mu_q (-1)^{K+q} (J' 1 J; -(K+q) q K)|^2 with the
    // b-axis dipole along x: mu_{+1} = -1/sqrt 2, mu_{-1} = 1/sqrt 2.
    std::vector<DipoleTransition> out;
    for (std::size_t i = 0; i < levels.size(); ++i)
        for (std::size_t f = i + 1; f < levels.size(); ++f) {
            const auto& a = levels[i];
            const auto& b = levels[f];
            if (std::abs(a.j - b.j) > 1 || a.ortho != b.ortho) continue;
            double amp = 0;
            for (int k = -a.j; k <= a.j; ++k)
                for (int q : {-1, 1}) {
                    const int kp = k + q;
                    if (std::abs(kp) > b.j) continue;
                    const double mu_q = q == 1 ? -std::numbers::sqrt2 / 2 : std::numbers::sqrt2 / 2;
                    amp += b.vector[static_cast<std::size_t>(kp + b.j)] * a.vector[static_cast<std::size_t>(k + a.j)] * mu_q * (kp % 2 == 0 ? 1.0 : -1.0) *
                           wigner3j(b.j, 1, a.j, -kp, q, k);
                }
            const double s = (2 * a.j + 1.0) * (2 * b.j + 1.0) * amp * amp;
            if (s < min_strength) continue;
            const bool up = b.energy_ev >= a.energy_ev;
            out.push_back({up ? i : f, up ? f : i, s});
        }
    return out;
}

std::vector<VibrationalLadder> water_vibrational_ladders(const std::string& target) {
    return {{target + "(010)", 31.1285, 14.6874, 9.1291, false},
            {target + "(100)", 27.1228, 14.3048, 9.1046, false},
            {target + "(001)", 26.6466, 14.4319, 9.1424, true},
            {target + "(100+001)", 26.8847, 14.3684, 9.1235, false}};
}

GasSet water_vapour_set(const std::vector<CollisionProcess>& other, const WaterVapourOptions& o) {
    if (!(o.gas_temperature_k >= 0)) bad("the gas temperature must be non-negative");
    if (o.born_scale_energy_ev.size() != o.born_scale.size()) bad("the Born scaling table needs as many factors as energies");
    const double kt = kKelvinEv * o.gas_temperature_k;
    const double kv = o.vibrational_temperature_k >= 0 ? kKelvinEv * o.vibrational_temperature_k : kt;
    // Rotational populations, thermal with nuclear-spin weights (ortho 3, para 1) or a fixed ratio.
    int j_cut = o.j_max;
    if (j_cut < 0) {
        j_cut = 1;
        while (j_cut < 40) {
            // The lowest level of J has energy above roughly B J(J+1) for a near-prolate top.
            const double lowest = 0.5 * (o.b_cm + o.c_cm) * j_cut * (j_cut + 1.0) * kCmToEv;
            if (kt <= 0 || std::exp(-lowest / kt) * (2 * j_cut + 1) * 3 < o.min_population * 0.1) break;
            ++j_cut;
        }
    }
    GasSet set;
    auto levels = asymmetric_top_levels(o.a_cm, o.b_cm, o.c_cm, std::min(40, j_cut + 1), o.target);
    // Boltzmann factor of a rotational level, before normalisation.
    const auto boltzmann = [&](bool ortho, int j, double e) { return kt > 0 ? (ortho ? 3.0 : 1.0) * (2 * j + 1) * std::exp(-e / kt) : 0.0; };
    std::vector<double> pop(levels.size(), 0.0);
    double ortho_sum = 0, para_sum = 0;
    for (std::size_t i = 0; i < levels.size(); ++i) {
        const auto& l = levels[i];
        pop[i] = boltzmann(l.ortho, l.j, l.energy_ev);
        (l.ortho ? ortho_sum : para_sum) += pop[i];
    }
    if (kt <= 0) {
        // Cold gas: the lowest para level, or the lowest of each spin species at a fixed ratio.
        pop[0] = 1;
        para_sum = 1;
        if (o.ortho_para_ratio > 0)
            for (std::size_t i = 0; i < levels.size(); ++i)
                if (levels[i].ortho) { pop[i] = 1; ortho_sum = 1; break; }
    }
    // pop = scale(spin) x Boltzmann factor, normalised over the ground state's rotation.
    double scale_ortho = 1, scale_para = 1;
    if (o.ortho_para_ratio > 0) {
        scale_ortho = ortho_sum > 0 ? o.ortho_para_ratio / ortho_sum : 0.0;
        scale_para = para_sum > 0 ? 1 / para_sum : 0.0;
    }
    double total = 0;
    for (std::size_t i = 0; i < levels.size(); ++i) total += pop[i] *= levels[i].ortho ? scale_ortho : scale_para;
    for (auto& p : pop) p /= total;
    scale_ortho /= total;
    scale_para /= total;

    // Vibrational states: the products of the target's vibrational excitations.
    struct Ladder {
        std::string state;
        double threshold_ev{0}, weight_ratio{1};
        bool antisymmetric{false};
        std::vector<RotorLevel> levels;
        std::vector<double> pop;           // relative to the vibrational ground state
        std::map<int, std::size_t> index;  // J, Ka, Kc -> level
    };
    std::vector<Ladder> ladders;
    std::map<std::string, double> lumped;  // without ladders: state -> population over the ground state
    double excited = 0;
    const auto is_vibrational = [&](const CollisionProcess& p) {
        return p.kind == CollisionKind::Excitation && p.target == o.target && !p.product.empty() && p.weight_ratio > 0;
    };
    const auto key = [](int j, int ka, int kc) { return (j * 64 + ka) * 64 + kc; };
    for (const auto& p : other) {
        if (!is_vibrational(p) || lumped.count(p.product)) continue;
        const double vib = kv > 0 ? std::exp(-p.threshold_ev / kv) / p.weight_ratio : 0.0;
        lumped[p.product] = vib;
        if (!o.rotational_ladders) {
            excited += vib;
            continue;
        }
        Ladder l;
        l.state = p.product;
        l.threshold_ev = p.threshold_ev;
        l.weight_ratio = p.weight_ratio;
        double a = o.a_cm, b = o.b_cm, c = o.c_cm;
        for (const auto& spec : o.ladders)
            if (spec.state == p.product) {
                a = spec.a_cm, b = spec.b_cm, c = spec.c_cm;
                l.antisymmetric = spec.antisymmetric;
            }
        // One J beyond the ground state's ladder, for the doublet partners of the antisymmetric case.
        l.levels = asymmetric_top_levels(a, b, c, std::min(40, j_cut + 2), p.product);
        l.pop.resize(l.levels.size());
        for (std::size_t k = 0; k < l.levels.size(); ++k) {
            const auto& lv = l.levels[k];
            // Nuclear spin follows the vibronic symmetry: in a B2 state the labels swap.
            const bool spin_ortho = lv.ortho != l.antisymmetric;
            l.pop[k] = vib * (spin_ortho ? scale_ortho : scale_para) * boltzmann(spin_ortho, lv.j, lv.energy_ev);
            excited += l.pop[k];
            l.index[key(lv.j, lv.ka, lv.kc)] = k;
        }
        ladders.push_back(std::move(l));
    }
    const double ground = 1 / (1 + excited);
    set.fractions[o.target] = ground;
    if (!o.rotational_ladders)
        for (const auto& [name, ratio] : lumped) set.fractions[name] = ground * ratio;

    // Rotational transitions of a ladder: Born dipole, with the optional rescaling.
    const auto dipole_set = [&](const std::vector<RotorLevel>& lv, const std::vector<double>& x, std::vector<char>& used, std::vector<CollisionProcess>& out) {
        for (const auto& t : b_dipole_transitions(lv)) {
            if (std::max(x[t.lower], x[t.upper]) < o.min_population) continue;
            const auto& lo = lv[t.lower];
            const auto& hi = lv[t.upper];
            CollisionProcess p;
            p.kind = CollisionKind::Excitation;
            p.target = lo.name;
            p.product = hi.name;
            p.label = lo.name + " <-> " + hi.name;
            p.threshold_ev = std::max(hi.energy_ev - lo.energy_ev, 1e-9);
            p.weight_ratio = (2 * lo.j + 1.0) / (2 * hi.j + 1.0);
            p.group = CollisionProcess::Group::Rotational;
            p.angular = CollisionProcess::Angular::BornDipole;
            const double u = p.threshold_ev, strength = t.strength / (2 * lo.j + 1);
            p.energy_ev.push_back(u);
            p.cross_section_m2.push_back(0.0);
            for (int k = 0; k <= 120; ++k) {
                const double e = u + std::max(u, 1e-6) * 1e-4 * std::pow(1e3 / (std::max(u, 1e-6) * 1e-4), k / 120.0);
                p.energy_ev.push_back(e);
                p.cross_section_m2.push_back(born_dipole_cross_section(e, u, strength, o.dipole_debye) * interpolate(o.born_scale_energy_ev, o.born_scale, e));
            }
            used[t.lower] = used[t.upper] = 1;
            out.push_back(std::move(p));
        }
    };
    std::vector<double> x(levels.size());
    for (std::size_t i = 0; i < levels.size(); ++i) x[i] = pop[i];
    std::vector<char> used(levels.size(), 0);
    std::vector<CollisionProcess> rotational, ladder_processes;
    dipole_set(levels, x, used, rotational);

    // Vibrational excitation level by level: each populated ground level to its partner in the
    // vibrational state, the cross section moved with the threshold.
    std::vector<std::vector<char>> ladder_used;
    for (auto& l : ladders) {
        ladder_used.emplace_back(l.levels.size(), char{0});
        for (const auto& p : other) {
            if (!is_vibrational(p) || p.product != l.state) continue;
            for (std::size_t i = 0; i < levels.size(); ++i) {
                if (pop[i] < o.min_population) continue;
                const auto& lo = levels[i];
                int j = lo.j, ka = lo.ka, kc = lo.kc;
                if (l.antisymmetric) {
                    // Across the asymmetry doublet (Delta Ka even, Delta Kc odd), which keeps the
                    // nuclear spin; J_0J has no partner of the same J and goes to (J+1)_0,J+1.
                    if (ka == 0) ++j, ++kc;
                    else kc = kc == j - ka ? kc + 1 : kc - 1;
                }
                const auto f = l.index.find(key(j, ka, kc));
                if (f == l.index.end()) continue;
                const auto& hi = l.levels[f->second];
                CollisionProcess q;
                q.kind = CollisionKind::Excitation;
                q.target = lo.name;
                q.product = hi.name;
                q.label = lo.name + " <-> " + hi.name;
                q.threshold_ev = p.threshold_ev + hi.energy_ev - lo.energy_ev;
                q.weight_ratio = p.weight_ratio * (2 * lo.j + 1.0) / (2 * hi.j + 1.0);
                q.group = CollisionProcess::Group::Vibrational;
                q.angular = p.angular;
                const double shift = q.threshold_ev - p.threshold_ev;
                q.energy_ev.push_back(q.threshold_ev);
                q.cross_section_m2.push_back(p.threshold_ev <= p.energy_ev.front() ? 0.0 : interpolate(p.energy_ev, p.cross_section_m2, p.threshold_ev));
                for (std::size_t k = 0; k < p.energy_ev.size(); ++k)
                    if (p.energy_ev[k] + shift > q.threshold_ev) {
                        q.energy_ev.push_back(p.energy_ev[k] + shift);
                        q.cross_section_m2.push_back(p.cross_section_m2[k]);
                    }
                used[i] = 1;
                ladder_used.back()[f->second] = 1;
                ladder_processes.push_back(std::move(q));
            }
        }
        std::vector<double> xl(l.levels.size());
        for (std::size_t k = 0; k < l.levels.size(); ++k) xl[k] = ground * l.pop[k];
        dipole_set(l.levels, xl, ladder_used.back(), ladder_processes);
    }
    for (std::size_t i = 0; i < levels.size(); ++i)
        if (used[i] || i == 0) {
            set.fractions[levels[i].name] = ground * pop[i];
            set.levels.push_back(levels[i]);
        }
    for (std::size_t n = 0; n < ladders.size(); ++n)
        for (std::size_t k = 0; k < ladders[n].levels.size(); ++k)
            if (ladder_used[n][k]) {
                set.fractions[ladders[n].levels[k].name] = ground * ladders[n].pop[k];
                set.levels.push_back(ladders[n].levels[k]);
            }

    // The momentum transfer less the thermal rotational share of the ground state, sum over
    // levels of x_i sum_f [sigma_if (1 - g1) + superelastic], kept to at least 5% of the given value.
    const auto rotational_momentum = [&](double e) {
        double s = 0;
        for (const auto& p : rotational) {
            const auto up = [&](double at) { return at <= p.energy_ev.front() ? 0.0 : interpolate(p.energy_ev, p.cross_section_m2, at); };
            const double u = p.threshold_ev;
            const double xl = set.fractions[p.target], xu = set.fractions[p.product];
            if (e > u) s += xl * up(e) * (1 - born_g1((2 * e - u) / (2 * std::sqrt(e * (e - u)))));
            if (xu > 0) s += xu * p.weight_ratio * (e + u) / e * up(e + u) * (1 - born_g1((2 * e + u) / (2 * std::sqrt(e * (e + u)))));
        }
        return s / ground;
    };
    for (const auto& p : other) {
        if (o.rotational_ladders && is_vibrational(p)) continue;  // replaced level by level
        CollisionProcess q = p;
        if ((p.kind == CollisionKind::Elastic || p.kind == CollisionKind::Effective) && p.target == o.target) {
            for (std::size_t k = 0; k < q.energy_ev.size(); ++k) {
                const double e = std::max(q.energy_ev[k], 1e-6), given = q.cross_section_m2[k];
                const double rot = rotational_momentum(e);
                if (given > 0) set.rotational_momentum_ratio_max = std::max(set.rotational_momentum_ratio_max, std::min(1.0, rot / given));
                if (o.momentum_includes_rotation) q.cross_section_m2[k] = std::max(given - rot, 0.05 * given);
            }
            q.kind = CollisionKind::Elastic;
            if (q.mass_ratio <= 0) q.mass_ratio = 9.1093837015e-31 / (o.mass_amu * 1.66053906660e-27);
            if (o.momentum_includes_rotation) q.label = p.label + " (less the rotational share)";
        }
        set.processes.push_back(std::move(q));
    }
    for (auto& p : rotational) set.processes.push_back(std::move(p));
    for (auto& p : ladder_processes) set.processes.push_back(std::move(p));
    return set;
}

} // namespace raikou::kinetics
