#include "raikou/electron_boltzmann.h"
#include "raikou/hydrogen_molecule.h"
#include "raikou/spherical_harmonics.h"
#include "raikou/eedf_distributed.h"
#include "json_collective.h"
#include <cmath>
#include <stdexcept>

namespace raikou::kinetics {
namespace {
using Json = raikou::Json;
[[noreturn]] void invalid(const std::string& message) { throw std::invalid_argument("EEDF JSON: " + message); }

CollisionKind kind_from(const std::string& kind) {
    if (kind == "elastic") return CollisionKind::Elastic;
    if (kind == "effective") return CollisionKind::Effective;
    if (kind == "excitation") return CollisionKind::Excitation;
    if (kind == "ionization") return CollisionKind::Ionization;
    if (kind == "attachment") return CollisionKind::Attachment;
    if (kind == "recombination") return CollisionKind::Recombination;
    invalid("unknown collision kind " + kind);
}
std::string kind_name(CollisionKind kind) {
    switch (kind) {
    case CollisionKind::Elastic: return "elastic";
    case CollisionKind::Effective: return "effective";
    case CollisionKind::Excitation: return "excitation";
    case CollisionKind::Ionization: return "ionization";
    case CollisionKind::Attachment: return "attachment";
    case CollisionKind::Recombination: return "recombination";
    }
    invalid("unknown collision kind");
}
Json grid_json(const EedfGrid& grid) {
    return {{"cells", grid.cells}, {"max_energy_ev", grid.max_energy_ev}, {"power", grid.power}, {"legendre_terms", grid.legendre_terms}};
}
Json budget_json(const EnergyBudget& budget) {
    return {{"field", budget.field}, {"elastic", budget.elastic}, {"rotational", budget.rotational}, {"vibrational", budget.vibrational},
            {"electronic", budget.electronic}, {"ionization", budget.ionization}, {"attachment", budget.attachment},
            {"recombination", budget.recombination}, {"electron_electron", budget.electron_electron},
            {"superelastic_gain", budget.superelastic_gain}, {"growth", budget.growth}, {"residual", budget.residual}};
}
Json swarm_json(const SwarmResult& result) {
    Json rates = Json::array();
    for (const auto& rate : result.rates)
        rates.push_back({{"label", rate.label}, {"kind", kind_name(rate.kind)}, {"target", rate.target},
                         {"fraction", rate.fraction}, {"rate_m3_s", rate.rate_m3_s},
                         {"superelastic_rate_m3_s", rate.superelastic_rate_m3_s}, {"power_ev_m3_s", rate.power_ev_m3_s}});
    const auto townsend = steady_townsend(result);
    return {{"converged", result.converged}, {"iterations", result.iterations}, {"mean_energy_ev", result.mean_energy_ev},
            {"mobility_n", result.mobility_n}, {"diffusion_n", result.diffusion_n}, {"drift_velocity_m_s", result.drift_velocity_m_s},
            {"longitudinal_diffusion_n", result.longitudinal_diffusion_n}, {"transverse_diffusion_n", result.transverse_diffusion_n},
            {"bulk_drift_velocity_m_s", result.bulk_drift_velocity_m_s}, {"gradient_residual", result.gradient_residual},
            {"ionization_rate_m3_s", result.ionization_rate_m3_s}, {"attachment_rate_m3_s", result.attachment_rate_m3_s},
            {"recombination_rate_m3_s", result.recombination_rate_m3_s}, {"net_rate_m3_s", result.net_rate_m3_s},
            {"alpha_n_m2", result.alpha_n_m2}, {"eta_n_m2", result.eta_n_m2},
            {"steady_townsend", {{"alpha_n_m2", townsend.alpha_n_m2}, {"eta_n_m2", townsend.eta_n_m2}}},
            {"rates", rates}, {"budget_ev_m3_s", budget_json(result.budget)}, {"energy_ev", result.energy_ev}, {"eepf", result.eepf}};
}
Json state_json(const EedfState& state) {
    return {{"grid", grid_json(state.grid)}, {"time_s", state.time_s}, {"density_modes", state.density_modes},
            {"electron_density_m3", state.electron_density_m3()}, {"electron_energy_ev_m3", state.electron_energy_ev_m3()},
            {"mean_energy_ev", state.mean_energy_ev()}, {"representation", "axisymmetric_legendre_fixed_direction"}};
}
WaterVapourOptions water_options(const Json& value) {
    WaterVapourOptions o;
    o.gas_temperature_k = value.value("gas_temperature_k", o.gas_temperature_k);
    o.vibrational_temperature_k = value.value("vibrational_temperature_k", o.vibrational_temperature_k);
    o.j_max = value.value("j_max", o.j_max);
    o.min_population = value.value("min_population", o.min_population);
    o.dipole_debye = value.value("dipole_debye", o.dipole_debye);
    o.a_cm = value.value("a_cm", o.a_cm); o.b_cm = value.value("b_cm", o.b_cm); o.c_cm = value.value("c_cm", o.c_cm);
    o.ortho_para_ratio = value.value("ortho_para_ratio", o.ortho_para_ratio);
    o.momentum_includes_rotation = value.value("momentum_includes_rotation", o.momentum_includes_rotation);
    o.rotational_ladders = value.value("rotational_ladders", o.rotational_ladders);
    o.target = value.value("target", o.target); o.mass_amu = value.value("mass_amu", o.mass_amu);
    o.born_scale_energy_ev = value.value("born_scale_energy_ev", std::vector<double>{});
    o.born_scale = value.value("born_scale", std::vector<double>{});
    return o;
}
struct ProblemData {
    std::vector<CollisionProcess> processes;
    EedfConditions conditions;
    EedfGrid grid;
};
Json execution_config(const Json& request) {
    if(request.contains("execution"))return request.at("execution");
    if(request.contains("conditions")&&request.at("conditions").is_object()&&request.at("conditions").contains("execution"))
        return request.at("conditions").at("execution");
    return Json::object();
}
ProblemData problem_data(const Json& request) {
    ProblemData p;
    if (request.contains("lxcat_text") && request.contains("processes")) invalid("provide either processes or lxcat_text");
    if (request.contains("lxcat_text")) p.processes = read_lxcat(request.at("lxcat_text").get<std::string>());
    else p.processes = collision_processes_from_json(request.at("processes"));
    p.conditions = eedf_conditions_from_json(request.value("conditions", Json::object()));
    if (request.contains("execution")) {
        const auto& execution = request.at("execution");
        p.conditions.execution.device = execution.value("device", std::string("cpu"));
        p.conditions.execution.mpi = execution.value("mpi", false);
        p.conditions.execution.threads = execution.value("threads", std::size_t{1});
        p.conditions.execution.communicator_f = execution.value("communicator_f", -1);
        p.conditions.execution.cuda_device = execution.value("cuda_device", -1);
        p.conditions.execution.tolerance = execution.value("tolerance", p.conditions.execution.tolerance);
        p.conditions.execution.max_iterations = execution.value("max_iterations", p.conditions.execution.max_iterations);
        p.conditions.execution.restart = execution.value("restart", p.conditions.execution.restart);
        p.conditions.execution.preconditioner = execution.value("preconditioner", p.conditions.execution.preconditioner);
    }
    p.grid = eedf_grid_from_json(request.value("grid", Json::object()));
    if (request.contains("water")) {
        auto options = water_options(request.at("water"));
        if (!request.at("water").contains("gas_temperature_k")) options.gas_temperature_k = p.conditions.gas_temperature_k;
        auto set = water_vapour_set(p.processes, options);
        p.processes = std::move(set.processes);
        // An explicit user population always overrides the thermal initializer.
        for (const auto& [name, fraction] : set.fractions)
            if (!p.conditions.fractions.contains(name)) p.conditions.fractions[name] = fraction;
    }
    return p;
}
} // namespace

std::vector<CollisionProcess> collision_processes_from_json(const Json& values) {
    if (!values.is_array()) invalid("processes must be an array");
    std::vector<CollisionProcess> result;
    for (const auto& value : values) {
        CollisionProcess process;
        process.kind = kind_from(value.at("kind").get<std::string>());
        process.target = value.at("target").get<std::string>();
        process.product = value.value("product", std::string{});
        process.label = value.value("label", process.target + ":" + kind_name(process.kind));
        process.mass_ratio = value.value("mass_ratio", 0.0);
        process.threshold_ev = value.value("threshold_ev", 0.0);
        process.weight_ratio = value.value("weight_ratio", 0.0);
        process.energy_ev = value.at("energy_ev").get<std::vector<double>>();
        process.cross_section_m2 = value.at("cross_section_m2").get<std::vector<double>>();
        process.integral_cross_section_m2 = value.value("integral_cross_section_m2", std::vector<double>{});
        const auto angular = value.value("angular", std::string("isotropic"));
        if (angular == "isotropic") process.angular = CollisionProcess::Angular::Isotropic;
        else if (angular == "born_dipole") process.angular = CollisionProcess::Angular::BornDipole;
        else if (angular == "screened") process.angular = CollisionProcess::Angular::Screened;
        else invalid("unknown angular model " + angular);
        const auto group = value.value("group", std::string("automatic"));
        if (group == "automatic") process.group = CollisionProcess::Group::Automatic;
        else if (group == "rotational") process.group = CollisionProcess::Group::Rotational;
        else if (group == "vibrational") process.group = CollisionProcess::Group::Vibrational;
        else if (group == "electronic") process.group = CollisionProcess::Group::Electronic;
        else invalid("unknown process group " + group);
        result.push_back(std::move(process));
    }
    return result;
}

EedfConditions eedf_conditions_from_json(const Json& value) {
    EedfConditions c;
    c.reduced_field_td = value.value("reduced_field_td", c.reduced_field_td);
    c.gas_temperature_k = value.value("gas_temperature_k", c.gas_temperature_k);
    c.gas_density_m3 = value.value("gas_density_m3", c.gas_density_m3);
    c.electron_fraction = value.value("electron_fraction", c.electron_fraction);
    c.ion_fraction = value.value("ion_fraction", c.ion_fraction);
    c.temporal_growth = value.value("temporal_growth", c.temporal_growth);
    c.fractions = value.value("fractions", std::map<std::string, double>{});
    if (value.contains("execution")) {
        const auto& execution = value.at("execution");
        c.execution.device = execution.value("device", std::string("cpu"));
        c.execution.mpi = execution.value("mpi", false);
        c.execution.threads = execution.value("threads", std::size_t{1});
        c.execution.communicator_f = execution.value("communicator_f", -1);
        c.execution.cuda_device = execution.value("cuda_device", -1);
        c.execution.tolerance = execution.value("tolerance", c.execution.tolerance);
        c.execution.max_iterations = execution.value("max_iterations", c.execution.max_iterations);
        c.execution.restart = execution.value("restart", c.execution.restart);
        c.execution.preconditioner = execution.value("preconditioner", c.execution.preconditioner);
    }
    const auto sharing = value.value("sharing", std::string("equal"));
    if (sharing == "equal") c.sharing = IonizationSharing::Equal;
    else if (sharing == "one_takes_all") c.sharing = IonizationSharing::OneTakesAll;
    else invalid("sharing must be equal or one_takes_all");
    return c;
}

EedfGrid eedf_grid_from_json(const Json& value) {
    EedfGrid grid;
    grid.cells = value.value("cells", grid.cells);
    grid.max_energy_ev = value.value("max_energy_ev", grid.max_energy_ev);
    grid.power = value.value("power", grid.power);
    grid.legendre_terms = value.value("legendre_terms", grid.legendre_terms);
    return grid;
}

Json solve_eedf_json(const Json& request) {
    ProblemData data;std::vector<double> fields;bool sweep=false;
    const auto control=raikou::detail::parse_collectively(execution_config(request),[&](const backend::DistributedHalo&){
        data=problem_data(request);sweep=request.contains("fields_td");
        if(sweep)fields=request.at("fields_td").get<std::vector<double>>();
    });
    const double mode=sweep?1:0;
    control.collective_require(control.global_max(mode)!=-control.global_max(-mode)?"EEDF ranks must all request a sweep or all request one field":"");
    if (sweep) {
        const auto results = solve_eedf_sweep(data.processes, data.conditions, fields, data.grid);
        Json values = Json::array();
        for (std::size_t i = 0; i < results.size(); ++i) {
            auto item = swarm_json(results[i]); item["reduced_field_td"] = fields[i]; values.push_back(std::move(item));
        }
        return {{"results", values}, {"mode", "steady_sweep"}, {"grid", grid_json(data.grid)}};
    }
    auto result = swarm_json(solve_eedf(data.processes, data.conditions, data.grid));
    result["mode"] = "steady";
    result["grid"] = grid_json(data.grid);
    result["execution_scope"] = data.conditions.execution.mpi ?
        "owned energy/mode state, local sparse assembly and halo linear solves; scalar Landau prefixes; CPU auxiliary diffusion; final result gather" :
        "collision/field CSR rows; host banded GMRES, recoil and Landau terms; replicated vectors";
    return result;
}

Json advance_eedf_json(const Json& request) {
    ProblemData data;EedfState state;double dt=0;
    raikou::detail::parse_collectively(execution_config(request),[&](const backend::DistributedHalo&){
    data=problem_data(request);
    if (request.contains("state")) {
        const auto& value = request.at("state");
        state.grid = eedf_grid_from_json(value.at("grid"));
        state.time_s = value.value("time_s", 0.0);
        state.density_modes = value.at("density_modes").get<std::vector<double>>();
        if (request.contains("grid") && grid_json(state.grid) != grid_json(data.grid)) invalid("the request grid differs from the restart state grid");
    } else {
        const auto& value = request.at("initial");
        state = maxwellian_eedf(value.at("electron_density_m3").get<double>(), value.at("mean_energy_ev").get<double>(), data.grid);
    }
    dt=request.at("dt_s").get<double>();
    });
    const auto result = advance_eedf(data.processes, data.conditions, state,dt);
    return {{"state", state_json(result.state)}, {"swarm", swarm_json(result.swarm)},
            {"linear_backward_error", result.linear_residual}, {"nonlinear_iterations", result.nonlinear_iterations},
            {"energy_balance_relative", result.energy_balance_relative}, {"mode", "transient_backward_euler"}};
}

Json spherical_state_to_json(const SphericalEedfState& state){
    state.validate();
    const double density=state.electron_density_m3(),energy=state.electron_energy_ev_m3();
    return {{"schema_version",1},{"representation","real_spherical_harmonics"},
        {"basis","R00=1; R11=sqrt(3)x; R1,-1=sqrt(3)y; R10=sqrt(3)z"},
        {"grid",grid_json(state.grid)},{"time_s",state.time_s},{"density_modes",state.density_modes},
        {"electron_density_m3",density},{"electron_energy_ev_m3",energy},
        {"mean_energy_ev",density>0?Json(energy/density):Json(nullptr)},{"particle_flux_m2_s",state.particle_flux_m2_s()}};
}
SphericalEedfState spherical_state_from_json(const Json& input){
    if(input.value("schema_version",0)!=1||input.value("representation",std::string{})!="real_spherical_harmonics")
        invalid("spherical state must declare schema_version=1 and real_spherical_harmonics representation");
    const std::string basis="R00=1; R11=sqrt(3)x; R1,-1=sqrt(3)y; R10=sqrt(3)z";
    if(input.value("basis",basis)!=basis)invalid("unsupported spherical basis convention");
    SphericalEedfState state;state.grid=eedf_grid_from_json(input.at("grid"));
    state.time_s=input.at("time_s").get<double>();state.density_modes=input.at("density_modes").get<std::vector<double>>();
    state.validate();return state;
}
namespace {
SphericalEedfState spherical_initial(const Json& request,const EedfGrid& grid){
    if(request.contains("state")){
        auto state=spherical_state_from_json(request.at("state"));
        if(request.contains("grid")&&grid_json(state.grid)!=grid_json(grid))invalid("spherical request grid differs from restart grid");
        return state;
    }
    const auto& initial=request.at("initial");
    return spherical_from_legendre(maxwellian_eedf(initial.at("electron_density_m3").get<double>(),
        initial.at("mean_energy_ev").get<double>(),grid));
}
void spherical_field_contract(const Json& request){
    if(request.contains("conditions")&&request.at("conditions").contains("reduced_field_td"))
        invalid("spherical operations take electric_field_V_m as a physical vector; omit reduced_field_td");
}
}
Json evaluate_spherical_eedf_json(const Json& request){
    ProblemData data;SphericalEedfState state;Vector3 field{};
    raikou::detail::parse_collectively(execution_config(request),[&](const backend::DistributedHalo&){
        spherical_field_contract(request);data=problem_data(request);state=spherical_initial(request,data.grid);
        field=request.at("electric_field_V_m").get<Vector3>();
    });
    const auto result=evaluate_spherical_eedf(data.processes,data.conditions,state,field);
    return {{"representation","real_spherical_harmonics"},{"density_mode_rates",result.density_mode_rates},
        {"electron_production_m3_s",result.electron_production_m3_s},
        {"electron_energy_rate_ev_m3_s",result.electron_energy_rate_ev_m3_s},{"swarm",swarm_json(result.swarm)}};
}
Json advance_spherical_eedf_json(const Json& request){
    ProblemData data;SphericalEedfState state;Vector3 field{};double dt=0;
    raikou::detail::parse_collectively(execution_config(request),[&](const backend::DistributedHalo&){
        spherical_field_contract(request);data=problem_data(request);state=spherical_initial(request,data.grid);
        field=request.at("electric_field_V_m").get<Vector3>();dt=request.at("dt_s").get<double>();
    });
    const auto result=advance_spherical_eedf(data.processes,data.conditions,state,field,dt);
    return {{"state",spherical_state_to_json(result.state)},{"swarm",swarm_json(result.swarm)},
        {"flux_velocity_m_s",result.flux_velocity_m_s},{"nonlinear_iterations",result.nonlinear_iterations},
        {"linear_backward_error",result.linear_residual},{"energy_balance_relative",result.energy_balance_relative}};
}

namespace {
constexpr const char* owned_representation="axisymmetric_legendre_owned_energy_cells";
struct OwnedEedfInput {
    ProblemData data;
    DistributedEedfState state;
    bool restart{};
    double density{}, mean_energy{}, dt{};
};
OwnedEedfInput owned_eedf_input(const Json& request,bool advancing){
    OwnedEedfInput input;
    const auto config=execution_config(request);
    const auto parsed=raikou::detail::parse_collectively(config,[&](const backend::DistributedHalo& control){
        input.data=problem_data(request);
        if(!advancing)return;
        input.dt=request.at("dt_s").get<double>();
        input.restart=request.contains("state");
        if(input.restart){
            const auto& state=request.at("state");
            if(state.value("schema_version",0)!=1||state.value("representation",std::string{})!=owned_representation)
                invalid("owned EEDF restart requires schema_version=1 and owned-energy-cell representation");
            input.state.grid=eedf_grid_from_json(state.at("grid"));
            if(request.contains("grid")&&grid_json(input.data.grid)!=grid_json(input.state.grid))
                invalid("owned EEDF request grid differs from restart grid");
            input.data.grid=input.state.grid;
            const auto& grid=input.state.grid;
            if(grid.cells<16||grid.cells>6000||grid.legendre_terms<2||grid.legendre_terms>30)
                invalid("invalid owned EEDF grid");
            const auto owned=backend::balanced_partition(static_cast<backend::GlobalIndex>(grid.cells),control.rank(),control.ranks());
            const auto stride=static_cast<backend::GlobalIndex>(grid.legendre_terms);
            input.state.time_s=state.at("time_s").get<double>();
            input.state.density_modes=state.at("density_modes").get<std::vector<double>>();
            input.state.partition={state.value("global_rows",static_cast<backend::GlobalIndex>(grid.cells)*stride),
                state.value("row_begin",owned.row_begin*stride),input.state.density_modes.size()};
        }else{
            input.density=request.at("initial").at("electron_density_m3").get<double>();
            input.mean_energy=request.at("initial").at("mean_energy_ev").get<double>();
        }
    });
    const double restart=input.restart?1:0;
    parsed.collective_require(parsed.global_max(restart)!=-parsed.global_max(-restart)?
        "owned EEDF ranks must all provide restart state or all provide initial conditions":"");
    return input;
}
Json owned_eedf_result(const DistributedEedfResult& result){
    const auto& state=result.state;
    const auto stride=static_cast<backend::GlobalIndex>(state.grid.legendre_terms);
    return {{"state",{{"schema_version",1},{"representation",owned_representation},
                {"grid",grid_json(state.grid)},{"time_s",state.time_s},
                {"global_rows",state.partition.global_rows},{"row_begin",state.partition.row_begin},
                {"energy_cell_begin",state.partition.row_begin/stride},{"density_modes",state.density_modes}}},
        {"swarm",swarm_json(result.swarm)},{"nonlinear_iterations",result.nonlinear_iterations},
        {"linear_backward_error",result.linear_residual},{"energy_balance_relative",result.energy_balance_relative},
        {"ghost_modes",result.ghost_modes},{"local_matrix_entries",result.local_matrix_entries},
        {"execution_scope","owned energy cells, sparse local rows, dependency halos and scalar reductions"}};
}
}
Json advance_distributed_eedf_json(const Json& request){
    auto input=owned_eedf_input(request,true);
    if(!input.restart)input.state=maxwellian_eedf_distributed(input.density,input.mean_energy,input.data.grid,input.data.conditions.execution);
    return owned_eedf_result(advance_eedf_distributed(input.data.processes,input.data.conditions,input.state,input.dt));
}
Json solve_distributed_eedf_json(const Json& request){
    const auto input=owned_eedf_input(request,false);
    return owned_eedf_result(solve_eedf_distributed(input.data.processes,input.data.conditions,input.data.grid));
}

Json water_levels_json(const Json& request) {
    const auto options = water_options(request);
    auto set = water_vapour_set(request.contains("processes") ? collision_processes_from_json(request.at("processes")) : std::vector<CollisionProcess>{}, options);
    Json levels = Json::array();
    for (const auto& level : set.levels)
        levels.push_back({{"name", level.name}, {"j", level.j}, {"ka", level.ka}, {"kc", level.kc},
                          {"energy_ev", level.energy_ev}, {"ortho", level.ortho}, {"fraction", set.fractions.at(level.name)}});
    return {{"levels", levels}, {"fractions", set.fractions}, {"process_count", set.processes.size()},
            {"population_convention", "state populations plus aggregate targets; aggregate aliases are not additional molecules"},
            {"closure", "thermal_rovibrational_initializer"}, {"status", "research"}};
}

Json solve_breakdown_json(const Json& request) {
    ProblemData data;BreakdownSetup s;
    raikou::detail::parse_collectively(execution_config(request),[&](const backend::DistributedHalo&){
    data=problem_data(request);const auto value=request.value("setup",Json::object());
    s.gap_m = value.value("gap_m", s.gap_m); s.area_m2 = value.value("area_m2", s.area_m2);
    s.voltage_v = value.value("voltage_v", s.voltage_v); s.series_resistance_ohm = value.value("series_resistance_ohm", s.series_resistance_ohm);
    s.seed_density_m3 = value.value("seed_density_m3", s.seed_density_m3); s.seed_mean_energy_ev = value.value("seed_mean_energy_ev", s.seed_mean_energy_ev);
    s.ion_mobility_n = value.value("ion_mobility_n", s.ion_mobility_n); s.secondary_yield = value.value("secondary_yield", s.secondary_yield);
    s.drift_loss = value.value("drift_loss", s.drift_loss); s.end_time_s = value.value("end_time_s", s.end_time_s);
    s.outputs = value.value("outputs", s.outputs); s.max_steps = value.value("max_steps", s.max_steps);
    s.collapse_fraction = value.value("collapse_fraction", s.collapse_fraction); s.step_tolerance = value.value("step_tolerance", s.step_tolerance);
    for(const double positive:{s.gap_m,s.area_m2,s.voltage_v,s.seed_density_m3,s.seed_mean_energy_ev,s.end_time_s,data.conditions.gas_density_m3})
        if(!(positive>0&&std::isfinite(positive)))invalid("breakdown geometry, source, seed, gas density and time must be positive and finite");
    if(!(s.series_resistance_ohm>=0&&std::isfinite(s.series_resistance_ohm)&&s.ion_mobility_n>=0&&std::isfinite(s.ion_mobility_n)))invalid("invalid breakdown resistance/ion mobility");
    if(!(s.secondary_yield>=0&&s.secondary_yield<1&&s.collapse_fraction>0&&s.collapse_fraction<1&&s.step_tolerance>0&&s.step_tolerance<=10))invalid("invalid breakdown closure/tolerance");
    if(s.outputs<1||s.outputs>100000||s.max_steps<1)invalid("invalid breakdown iteration/output limits");
    });
    const auto result = solve_breakdown(data.processes, data.conditions, s, data.grid);
    if (result.stop == "step limit") invalid("fixed-composition circuit breakdown exceeded its step limit");
    Json samples = Json::array();
    for (const auto& b : result.samples)
        samples.push_back({{"time_s", b.time_s}, {"gap_voltage_v", b.gap_voltage_v}, {"reduced_field_td", b.reduced_field_td},
                           {"electron_density_m3", b.electron_density_m3}, {"positive_ion_density_m3", b.positive_ion_density_m3},
                           {"negative_ion_density_m3", b.negative_ion_density_m3}, {"current_a", b.current_a},
                           {"mean_energy_ev", b.mean_energy_ev}, {"drift_velocity_m_s", b.drift_velocity_m_s},
                           {"ionization_rate_m3_s", b.ionization_rate_m3_s}, {"attachment_rate_m3_s", b.attachment_rate_m3_s}});
    const auto& e = result.energy;
    Json energy = {{"source", e.source}, {"resistor", e.resistor}, {"capacitor_change", e.capacitor_change}, {"gap", e.gap},
                   {"electron_field_work", e.electron_field_work}, {"ion_joule", e.ion_joule}, {"elastic", e.elastic},
                   {"rotational", e.rotational}, {"vibrational", e.vibrational}, {"electronic", e.electronic},
                   {"ionization", e.ionization}, {"attachment", e.attachment}, {"recombination", e.recombination},
                   {"electron_electron", e.electron_electron}, {"superelastic_gain", e.superelastic_gain},
                   {"anode_loss", e.anode_loss}, {"secondary_input", e.secondary_input}, {"electron_energy_change", e.electron_energy_change},
                   {"electron_residual", e.electron_residual}, {"gap_residual", e.gap_residual}, {"circuit_residual", e.circuit_residual}};
    return {{"samples", samples}, {"energy_J", energy}, {"stop", result.stop}, {"steps", result.steps},
            {"rejected_steps", result.rejected_steps}, {"breakdown_time_s", result.breakdown_time_s}, {"energy_ev", result.energy_ev},
            {"eepf", result.eepf}, {"mode", "fixed_composition_uniform_gap_circuit"},
            {"limitations", {"Heavy-species composition is fixed.", "Recombination uses aggregate positive-ion shares in this compatibility model."}}};
}
} // namespace raikou::kinetics
