#include "raikou/eedf_distributed.h"
#include "eedf_local_assembly.h"
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <limits>
#include <map>
#include <memory>
#include <numbers>
#include <span>
#include <sstream>
#include <stdexcept>
#include <utility>

namespace raikou::kinetics {
namespace {
using backend::DistributedHalo;
using backend::GlobalIndex;
constexpr double charge = 1.602176634e-19, mass = 9.1093837015e-31, eps0 = 8.8541878128e-12, boltzmann = 1.380649e-23;
const double gamma_v = std::sqrt(2 * charge / mass);
template<class Action> void local_phase(const DistributedHalo& halo, Action action) {
    std::string error;
    try { action(); } catch (const std::exception& exception) { error = exception.what(); }
    catch (...) { error = "unknown owned EEDF failure"; }
    halo.collective_require(error);
}
void agree(const DistributedHalo& halo, const std::string& value) {
    std::uint64_t hash = 14695981039346656037ull;
    for (unsigned char c : value) { hash ^= c; hash *= 1099511628211ull; }
    for (int shift : {0, 32}) {
        const auto part = static_cast<double>((hash >> shift) & 0xffffffffull);
        halo.collective_require(halo.global_max(part) != -halo.global_max(-part) ? "owned EEDF metadata/options differ across ranks" : "");
    }
}
Json metadata(const std::vector<CollisionProcess>& processes, const EedfConditions& c, const EedfGrid& g) {
    Json p = Json::array();
    for (const auto& process : processes) p.push_back({{"kind", static_cast<int>(process.kind)}, {"target", process.target}, {"product", process.product},
        {"label", process.label}, {"mass", process.mass_ratio}, {"threshold", process.threshold_ev}, {"weight", process.weight_ratio},
        {"group", static_cast<int>(process.group)}, {"angular", static_cast<int>(process.angular)}, {"energy", process.energy_ev},
        {"sigma", process.cross_section_m2}, {"integral_sigma", process.integral_cross_section_m2}});
    return {{"processes", p}, {"grid", {g.cells, g.max_energy_ev, g.power, g.legendre_terms}},
        {"conditions", {c.reduced_field_td, c.gas_temperature_k, c.gas_density_m3, c.electron_fraction, c.ion_fraction}},
        {"fractions", c.fractions}, {"sharing", static_cast<int>(c.sharing)}, {"growth", c.temporal_growth},
        {"execution", {c.execution.device, c.execution.tolerance, c.execution.restart, c.execution.max_iterations, c.execution.preconditioner}}};
}
double bernoulli(double z) {
    if (std::abs(z) < 1e-6) return 1 - z / 2;
    if (z > 700) return 0;
    return z / std::expm1(z);
}
struct Faces {
    std::vector<double> theta, lower, upper, recoil_lower, recoil_upper, values, slopes, sum_values, sum_slopes;
    double aee{};
};
class LocalSystem {
public:
    EedfConditions conditions;
    EedfGrid grid;
    backend::RowPartition partition;
    detail::LocalEedfAssembly data;
    std::size_t stride{}, first{}, count{};
    std::unique_ptr<DistributedHalo> halo;
    std::vector<double> diagonal;

    LocalSystem(const std::vector<CollisionProcess>& processes, const EedfConditions& c, const EedfGrid& g,
                backend::RowPartition p, int azimuthal = 0, bool normalized_real_harmonics = true) : conditions(c), grid(g), partition(p) {
        DistributedHalo control(p, {}, c.execution);
        std::string static_metadata;
        local_phase(control, [&] {
            if (g.cells < 16 || g.cells > 6000 || g.legendre_terms < 2 || g.legendre_terms > 30 || !(g.max_energy_ev > 0 && std::isfinite(g.max_energy_ev)) ||
                !(g.power >= 1 && g.power <= 4 && std::isfinite(g.power))) throw std::invalid_argument("invalid owned EEDF grid");
            stride = static_cast<std::size_t>(g.legendre_terms);
            if (p.global_rows != static_cast<GlobalIndex>(g.cells) * stride || p.row_begin % stride || p.local_rows % stride)
                throw std::invalid_argument("owned EEDF partition must contain complete packed energy cells");
            first = static_cast<std::size_t>(p.row_begin) / stride; count = p.local_rows / stride;
            if (c.execution.device != "cpu" && c.execution.device != "cuda") throw std::invalid_argument("unknown owned EEDF device");
            if (c.execution.preconditioner != "jacobi" && c.execution.preconditioner != "block_ilu0") throw std::invalid_argument("unknown owned EEDF preconditioner");
            if (!(c.execution.tolerance > 0 && std::isfinite(c.execution.tolerance)) || c.execution.restart <= 0 || c.execution.max_iterations <= 0)
                throw std::invalid_argument("invalid owned EEDF linear controls");
            static_metadata = metadata(processes, c, g).dump() + ":" + std::to_string(azimuthal) + (normalized_real_harmonics ? ":real" : ":associated");
            data = detail::assemble_local_eedf(processes, c, g, p, azimuthal, normalized_real_harmonics);
        });
        agree(control, static_metadata);
        std::vector<GlobalIndex> requested;
        local_phase(control, [&] {
            requested = data.collision.columns;
            for (std::size_t i = first; i < first + count; ++i) {
                // Both nearest energy neighbours and all modes are useful to
                // local fluxes and hydrodynamic streaming source assembly.
                for (auto cell : {i ? i - 1 : i, std::min(i + 1, static_cast<std::size_t>(g.cells - 1))})
                    for (std::size_t mode = 0; mode < stride; ++mode) requested.push_back(cell * stride + mode);
            }
            diagonal.assign(p.local_rows, 0);
            for (std::size_t row = 0; row < p.local_rows; ++row)
                for (auto entry = data.collision.offsets[row]; entry < data.collision.offsets[row + 1]; ++entry)
                    if (data.collision.columns[entry] == p.row_begin + row) diagonal[row] += std::abs(data.collision.values[entry]);
        });
        halo = std::make_unique<DistributedHalo>(p, requested, c.execution);
        conditions.execution.communicator_f = halo->communicator_f();
    }
    double value(std::span<const double> owned, std::span<const double> ghosts, GlobalIndex id) const {
        const auto index = halo->compact_index(id);
        return index < owned.size() ? owned[index] : ghosts[index - owned.size()];
    }
    void validate(std::span<const double> modes) const {
        local_phase(*halo, [&] {
            if (modes.size() != partition.local_rows) throw std::invalid_argument("owned EEDF mode vector has incorrect local size");
            for (double v : modes) if (!std::isfinite(v)) throw std::invalid_argument("non-finite owned EEDF mode");
            for (std::size_t row = 0; row < modes.size(); ++row) {
                const auto global = partition.row_begin + row;
                if (global / stride + 1 == static_cast<GlobalIndex>(grid.cells) && global % stride >= static_cast<GlobalIndex>((grid.legendre_terms + 1) / 2) && modes[row] != 0)
                    throw std::invalid_argument("owned EEDF boundary padding must be zero");
            }
        });
        double peak = 0, negative = 0;
        for (std::size_t row = 0; row < modes.size(); row += stride) { peak = std::max(peak, std::abs(modes[row])); negative = std::max(negative, -modes[row]); }
        peak = halo->global_max(peak); negative = halo->global_max(negative);
        halo->collective_require(negative <= 1e-10 * peak ? "" : "owned isotropic EEDF must be nonnegative within numerical tolerance");
    }
    double density(std::span<const double> modes, bool positive = false) const {
        double sum = 0;
        for (std::size_t cell = 0; cell < count; ++cell) sum += (positive ? std::max(modes[cell * stride], 0.0) : modes[cell * stride]) * data.m12[first + cell];
        return halo->global_sum(sum);
    }
    double energy(std::span<const double> modes, bool integral = false, bool positive = false) const {
        double sum = 0;
        for (std::size_t cell = 0; cell < count; ++cell) sum += (positive ? std::max(modes[cell * stride], 0.0) : modes[cell * stride]) *
            (integral ? data.m32[first + cell] : data.centres[first + cell] * data.m12[first + cell]);
        return halo->global_sum(sum);
    }
    // S(X)_k = sum_q min(e_q,e_k)^1.5 X_q d_q. Faces k=i+1
    // belong to energy cell i, making each prefix rank contiguous and unique.
    std::vector<double> landau_sum(std::span<const double> x) const {
        double raw = 0, weighted = 0;
        for (std::size_t i = 0; i < count; ++i) {
            const auto k = first + i + 1;
            if (k < static_cast<std::size_t>(grid.cells)) { raw += x[i] * data.dual_widths[k]; weighted += std::pow(data.faces[k], 1.5) * x[i] * data.dual_widths[k]; }
        }
        double above = halo->global_sum(raw) - halo->exclusive_sum(raw), below = halo->exclusive_sum(weighted);
        std::vector<double> result;
        local_phase(*halo, [&] {
            result.assign(count, 0);
            for (std::size_t i = 0; i < count; ++i) {
                const auto k = first + i + 1;
                if (k >= static_cast<std::size_t>(grid.cells)) continue;
                const double e32 = std::pow(data.faces[k], 1.5), contribution = x[i] * data.dual_widths[k];
                result[i] = below + e32 * above;
                below += e32 * contribution; above -= contribution;
            }
        });
        return result;
    }
    Faces faces(std::span<const double> modes) const {
        validate(modes);
        const double ne = density(modes), positive_density = density(modes, true);
        halo->collective_require(ne > 0 ? "" : "owned EEDF needs positive electron density");
        const auto ghosts = halo->exchange(modes), ghost_diagonal = halo->exchange(diagonal);
        Faces out;
        local_phase(*halo, [&] {
            out.theta.assign(count, 0.5); out.lower.assign(count, 0); out.upper.assign(count, 0);
            out.recoil_lower.assign(count, 0); out.recoil_upper.assign(count, 0);
            out.values.assign(count, 0); out.slopes.assign(count, 0);
        });
        if (conditions.electron_fraction > 0) {
            const double te = std::max(2.0 / 3 * energy(modes, true, true) / std::max(positive_density, 1e-300), 1e-3);
            const double physical_ne = conditions.electron_fraction * conditions.gas_density_m3;
            const double debye = std::sqrt(eps0 * te / (physical_ne * charge));
            const double logarithm = std::max(1.0, std::log(12 * std::numbers::pi * physical_ne * debye * debye * debye));
            out.aee = 2 * conditions.electron_fraction * charge * charge * gamma_v * logarithm / (24 * std::numbers::pi * eps0 * eps0);
        }
        const auto update_values = [&] {
            local_phase(*halo, [&] {
                for (std::size_t i = 0; i < count; ++i) {
                    const auto k = first + i + 1;
                    if (k >= static_cast<std::size_t>(grid.cells)) continue;
                    const double left = modes[i * stride] / ne, right = value(modes, ghosts, k * stride) / ne;
                    out.values[i] = out.theta[i] * left + (1 - out.theta[i]) * right;
                    out.slopes[i] = (right - left) / data.dual_widths[k];
                }
            });
            if (out.aee > 0) { out.sum_values = landau_sum(out.values); out.sum_slopes = landau_sum(out.slopes); }
            else local_phase(*halo, [&] { out.sum_values.assign(count, 0); out.sum_slopes.assign(count, 0); });
        };
        const double en = conditions.reduced_field_td * 1e-21, kT = boltzmann * conditions.gas_temperature_k / charge;
        for (int iteration = 0; iteration < 60; ++iteration) {
            update_values();
            double change = 0;
            local_phase(*halo, [&] {
                for (std::size_t i = 0; i < count; ++i) {
                    const auto k = first + i + 1;
                    if (k >= static_cast<std::size_t>(grid.cells)) continue;
                    const double e = data.faces[k], d = data.dual_widths[k];
                    const double wr = -gamma_v * e * e * data.recoil_face[k], dr = gamma_v * kT * e * e * data.recoil_face[k];
                    const auto odd = (k - 1) * stride + static_cast<std::size_t>((grid.legendre_terms + 1) / 2);
                    const double fd = (gamma_v / 3 * en * e) * (gamma_v * e * d * en) / std::max(value(diagonal, ghost_diagonal, odd), 1e-300);
                    const double w = wr + out.aee * out.sum_slopes[i], diffusion = std::max(dr + fd + std::max(out.aee * out.sum_values[i], 0.0), 1e-300);
                    const double lower = diffusion / d * bernoulli(-w * d / diffusion);
                    const double theta = std::abs(w) * d > 1e-8 * diffusion ? std::clamp((lower - diffusion / d) / w, 0.0, 1.0) : 0.5;
                    change = std::max(change, std::abs(theta - out.theta[i])); out.theta[i] = theta;
                }
            });
            if (halo->global_max(change) < 1e-12 || out.aee == 0) break;
            if (iteration == 59) throw std::invalid_argument("owned EEDF Landau face weights failed to converge");
        }
        update_values();
        local_phase(*halo, [&] {
            for (std::size_t i = 0; i < count; ++i) {
                const auto k = first + i + 1;
                if (k >= static_cast<std::size_t>(grid.cells)) continue;
                const double e = data.faces[k], d = data.dual_widths[k];
                const double wr = -gamma_v * e * e * data.recoil_face[k], dr = gamma_v * kT * e * e * data.recoil_face[k];
                out.recoil_lower[i] = wr * out.theta[i] + dr / d;
                out.recoil_upper[i] = dr / d - wr * (1 - out.theta[i]);
                out.lower[i] = out.recoil_lower[i] + out.aee * (out.theta[i] * out.sum_slopes[i] + out.sum_values[i] / d);
                out.upper[i] = out.recoil_upper[i] + out.aee * (out.sum_values[i] / d - (1 - out.theta[i]) * out.sum_slopes[i]);
                if (!std::isfinite(out.lower[i]) || !std::isfinite(out.upper[i])) throw std::invalid_argument("owned EEDF flux overflow");
            }
        });
        return out;
    }
    FrozenEedfOperator frozen(std::span<const double> modes, bool normalized) const {
        const auto f = faces(modes);
        std::vector<double> lower(partition.local_rows), upper(partition.local_rows);
        for (std::size_t i = 0; i < count; ++i) { lower[i * stride] = f.lower[i]; upper[i * stride] = f.upper[i]; }
        const auto ghost_lower = halo->exchange(lower), ghost_upper = halo->exchange(upper);
        FrozenEedfOperator out; out.mass = data.mass; out.padding = data.padding; out.ghost_modes = halo->layout().ghost_global_ids.size();
        out.matrix = {partition.global_rows, partition.row_begin, {0}, {}, {}};
        local_phase(*halo, [&] {
            for (std::size_t row = 0; row < partition.local_rows; ++row) {
                const auto global = partition.row_begin + row;
                std::map<GlobalIndex, double> entries;
                if (!data.padding[row]) {
                    for (auto entry = data.collision.offsets[row]; entry < data.collision.offsets[row + 1]; ++entry) entries[data.collision.columns[entry]] += data.collision.values[entry];
                    if (global % stride == 0 && data.azimuthal_order == 0) {
                        const auto cell = static_cast<std::size_t>(global / stride);
                        if (cell + 1 < static_cast<std::size_t>(grid.cells)) { entries[global] -= lower[row]; entries[global + stride] += upper[row]; }
                        if (cell > 0) { entries[global - stride] += value(lower, ghost_lower, global - stride); entries[global] -= value(upper, ghost_upper, global - stride); }
                    }
                    const double factor = normalized ? conditions.gas_density_m3 / data.mass[row] : 1;
                    for (const auto& [column, coefficient] : entries) if (coefficient != 0) {
                        const double v = coefficient * factor;
                        if (!std::isfinite(v)) throw std::invalid_argument("owned EEDF operator overflow");
                        out.matrix.columns.push_back(column); out.matrix.values.push_back(v);
                    }
                }
                out.matrix.offsets.push_back(out.matrix.values.size());
            }
        });
        return out;
    }
};
double maximum(const DistributedHalo& halo, std::span<const double> values) {
    double result = 0; for (double v : values) result = std::max(result, std::abs(v));
    return halo.global_max(result);
}
struct ShiftedSolution { std::vector<double> modes; double residual{}; std::size_t entries{}; };
ShiftedSolution solve_shifted(const LocalSystem& system, const FrozenEedfOperator& frozen, double growth, double shift,
    bool isotropic_shift, std::span<const double> rhs_input, std::span<const double> guess) {
    const auto& h = *system.halo;
    backend::DistributedCsrMatrix k{system.partition.global_rows, system.partition.row_begin, {0}, {}, {}};
    std::vector<double> rhs;
    local_phase(h, [&] {
        rhs.assign(rhs_input.begin(), rhs_input.end());
        for (std::size_t row = 0; row < system.partition.local_rows; ++row) {
            const auto global = system.partition.row_begin + row;
            std::map<GlobalIndex, double> entries;
            if (frozen.padding[row]) { entries[global] = 1; rhs[row] = 0; }
            else {
                for (auto entry = frozen.matrix.offsets[row]; entry < frozen.matrix.offsets[row + 1]; ++entry) entries[frozen.matrix.columns[entry]] -= frozen.matrix.values[entry];
                entries[global] += growth + (!isotropic_shift || global % system.stride == 0 ? shift : 0);
            }
            double scale = 0; for (const auto& [column, value] : entries) { (void)column; scale = std::max(scale, std::abs(value)); }
            if (!(scale > 0 && std::isfinite(scale))) throw std::invalid_argument("singular/overflowed owned EEDF linear row");
            rhs[row] /= scale;
            for (const auto& [column, value] : entries) { k.columns.push_back(column); k.values.push_back(value / scale); }
            k.offsets.push_back(k.values.size());
        }
    });
    auto execution = system.conditions.execution;
    execution.restart = std::max(execution.restart, 120); // matches the kinetic solver's multi-term Arnoldi space
    // The legacy kinetic solver uses banded LU. Its partitioned analog is
    // rank-local sparse ILU(0), applied on the selected CPU/CUDA executor.
    execution.preconditioner = "block_ilu0";
    backend::DistributedLinearOperator op(std::move(k), execution);
    const auto backward_error = [&](std::span<const double> solution, std::vector<double>* residual) {
        const auto product = op.apply(solution), ghosts = op.halo().exchange(solution);
        double error = 0, bound = 0;
        local_phase(h, [&] {
            if (residual) residual->resize(solution.size());
            const auto& a = op.matrix();
            for (std::size_t row = 0; row < solution.size(); ++row) {
                const double r = rhs[row] - product[row];
                if (residual) (*residual)[row] = r;
                error = std::max(error, std::abs(r));
                double scale = std::abs(rhs[row]);
                for (auto entry = a.offsets[row]; entry < a.offsets[row + 1]; ++entry) {
                    const auto compact = op.halo().compact_index(a.columns[entry]);
                    const double x = compact < solution.size() ? solution[compact] : ghosts[compact - solution.size()];
                    scale += std::abs(a.values[entry] * x);
                }
                bound = std::max(bound, scale);
            }
        });
        return h.global_max(error) / std::max(h.global_max(bound), 1e-300);
    };
    ShiftedSolution result; result.entries = op.matrix().values.size();
    local_phase(h, [&] { result.modes.assign(guess.begin(), guess.end()); });
    std::vector<double> residual;
    result.residual = backward_error(result.modes, &residual);
    // Near the steady null vector the pseudo-time RHS vanishes. Certify the
    // current nonzero iterate by backward error before asking Krylov to solve
    // a correction consisting mostly of cancellation noise. Transient energy
    // differences use a tighter target because their physical change is small.
    if (result.residual < (isotropic_shift ? 1e-12 : 2e-15)) return result;
    const auto correction = op.solve(residual);
    local_phase(h, [&] { for (std::size_t i = 0; i < result.modes.size(); ++i) result.modes[i] += correction.local_solution[i]; });
    result.residual = backward_error(result.modes, nullptr);
    std::ostringstream diagnostic;
    if (!(result.residual <= 1e-9 && std::isfinite(result.residual)))
        diagnostic << "owned EEDF linear backward error " << result.residual << " exceeded tolerance (shift=" << shift << ", growth=" << growth << ", isotropic=" << isotropic_shift << ")";
    h.collective_require(diagnostic.str());
    return result;
}
SwarmResult summarize(const std::vector<CollisionProcess>& processes, const LocalSystem& system, std::span<const double> modes,
                      bool steady, int iterations) {
    const auto& h = *system.halo; const auto& d = system.data;
    const double ne = system.density(modes);
    std::vector<double> shape;
    local_phase(h, [&] { shape.assign(modes.begin(), modes.end()); for (auto& value : shape) value /= ne; });
    const auto faces = system.faces(shape);
    const auto ghosts = h.exchange(shape);
    SwarmResult out; out.converged = true; out.iterations = iterations;
    out.mean_energy_ev = system.energy(shape, true);
    double drift = 0, diffusion = 0;
    const auto odd_index = static_cast<std::size_t>((system.grid.legendre_terms + 1) / 2);
    for (std::size_t i = 0; i < system.count; ++i) {
        const auto cell = system.first + i, k = cell + 1;
        out.energy_ev.push_back(d.centres[cell]); out.eepf.push_back(shape[i * system.stride]);
        if (k < static_cast<std::size_t>(system.grid.cells)) drift += d.faces[k] * shape[i * system.stride + odd_index] * d.dual_widths[k];
    }
    out.drift_velocity_m_s = gamma_v / 3 * h.global_sum(drift);
    const double en = system.conditions.reduced_field_td * 1e-21;
    out.mobility_n = en > 0 ? out.drift_velocity_m_s / en : 0;
    double gross = 0;
    for (const auto& weights : d.processes) {
        const auto& p = processes[weights.process];
        if (p.kind == CollisionKind::Elastic || p.kind == CollisionKind::Effective) continue;
        ProcessRate rate; rate.label = p.label; rate.kind = p.kind; rate.target = p.target; rate.fraction = weights.target_fraction;
        double forward = 0, reverse = 0, power = 0;
        for (std::size_t i = 0; i < system.count; ++i) {
            const double f = shape[i * system.stride];
            forward += weights.loss[i] * f; reverse += weights.superelastic_loss[i] * f; power -= weights.energy_change[i] * f;
        }
        rate.rate_m3_s = gamma_v * h.global_sum(forward); rate.superelastic_rate_m3_s = gamma_v * h.global_sum(reverse);
        rate.power_ev_m3_s = h.global_sum(power) * (p.kind == CollisionKind::Recombination ? weights.target_fraction : 1);
        out.rates.push_back(rate);
        if (p.kind == CollisionKind::Ionization) { out.ionization_rate_m3_s += rate.fraction * rate.rate_m3_s; out.budget.ionization += rate.power_ev_m3_s; }
        else if (p.kind == CollisionKind::Attachment) { out.attachment_rate_m3_s += rate.fraction * rate.rate_m3_s; out.budget.attachment += rate.power_ev_m3_s; }
        else if (p.kind == CollisionKind::Recombination) { out.recombination_rate_m3_s += rate.fraction * rate.rate_m3_s; out.budget.recombination += rate.power_ev_m3_s; }
        else {
            const auto group = p.group != CollisionProcess::Group::Automatic ? p.group : p.threshold_ev < 0.05 ? CollisionProcess::Group::Rotational :
                p.threshold_ev < 2 ? CollisionProcess::Group::Vibrational : CollisionProcess::Group::Electronic;
            if (group == CollisionProcess::Group::Rotational) out.budget.rotational += rate.power_ev_m3_s;
            else if (group == CollisionProcess::Group::Vibrational) out.budget.vibrational += rate.power_ev_m3_s;
            else out.budget.electronic += rate.power_ev_m3_s;
            out.budget.superelastic_gain += p.threshold_ev * weights.product_fraction * rate.superelastic_rate_m3_s;
        }
        gross = std::max(gross, p.threshold_ev * rate.fraction * rate.rate_m3_s);
    }
    out.net_rate_m3_s = out.ionization_rate_m3_s - out.attachment_rate_m3_s - out.recombination_rate_m3_s;
    const double growth = steady && system.conditions.temporal_growth ? out.net_rate_m3_s : 0;
    double recoil = 0, ee = 0;
    for (std::size_t i = 0; i < system.count; ++i) {
        const auto cell = system.first + i, k = cell + 1;
        const double sm = d.momentum[i] + growth / (gamma_v * std::sqrt(d.centres[cell]));
        if (sm > 0) diffusion += d.centres[cell] / sm * shape[i * system.stride] * d.widths[cell];
        if (k < static_cast<std::size_t>(system.grid.cells)) {
            const double right = system.value(shape, ghosts, k * system.stride);
            recoil += (faces.recoil_lower[i] * shape[i * system.stride] - faces.recoil_upper[i] * right) * d.dual_widths[k];
            ee += faces.aee * (faces.values[i] * faces.sum_slopes[i] - faces.slopes[i] * faces.sum_values[i]) * d.dual_widths[k];
        }
    }
    out.diffusion_n = gamma_v / 3 * h.global_sum(diffusion);
    out.budget.field = en * out.drift_velocity_m_s; out.budget.elastic = -h.global_sum(recoil); out.budget.electron_electron = -h.global_sum(ee);
    out.budget.growth = growth * system.energy(shape);
    const auto& b = out.budget;
    const double spent = b.elastic + b.rotational + b.vibrational + b.electronic + b.ionization + b.attachment + b.recombination + b.electron_electron + b.growth;
    out.budget.residual = (b.field - spent) / std::max({std::abs(b.field), std::abs(b.elastic), gross, std::abs(b.attachment), std::abs(b.recombination), 1e-300});
    if (out.drift_velocity_m_s > 0) { out.alpha_n_m2 = out.ionization_rate_m3_s / out.drift_velocity_m_s; out.eta_n_m2 = out.attachment_rate_m3_s / out.drift_velocity_m_s; }
    return out;
}

std::vector<double> landau_extra(const LocalSystem& system, const Faces& frozen, std::span<const double> modes) {
    const auto& h = *system.halo;
    std::vector<double> result(system.partition.local_rows, 0);
    if (!(frozen.aee > 0)) return result;
    const auto ghosts = h.exchange(modes);
    std::vector<double> values(system.count, 0), slopes(system.count, 0);
    for (std::size_t i = 0; i < system.count; ++i) {
        const auto k = system.first + i + 1;
        if (k >= static_cast<std::size_t>(system.grid.cells)) continue;
        const double left = modes[i * system.stride], right = system.value(modes, ghosts, k * system.stride);
        values[i] = frozen.theta[i] * left + (1 - frozen.theta[i]) * right;
        slopes[i] = (right - left) / system.data.dual_widths[k];
    }
    const auto sum_values = system.landau_sum(values), sum_slopes = system.landau_sum(slopes);
    std::vector<double> flux(system.partition.local_rows, 0);
    for (std::size_t i = 0; i < system.count; ++i)
        flux[i * system.stride] = frozen.aee * (frozen.values[i] * sum_slopes[i] - frozen.slopes[i] * sum_values[i]);
    const auto ghost_flux = h.exchange(flux);
    for (std::size_t i = 0; i < system.count; ++i) {
        const auto global = system.partition.row_begin + i * system.stride, cell = global / system.stride;
        result[i * system.stride] = system.conditions.gas_density_m3 / system.data.mass[i * system.stride] *
            (flux[i * system.stride] - (cell > 0 ? system.value(flux, ghost_flux, global - system.stride) : 0));
    }
    return result;
}
std::vector<double> streaming_source(const LocalSystem& system, std::span<const double> shape, int m) {
    const auto ghosts = system.halo->exchange(shape);
    const auto& d = system.data;
    std::vector<double> source(system.partition.local_rows, 0);
    const int L = system.grid.legendre_terms, ne = (L + 1) / 2;
    const auto even = [&](int l, std::size_t cell) { return system.value(shape, ghosts, cell * system.stride + static_cast<std::size_t>(l / 2)); };
    const auto face = [&](int l, std::size_t k) { return l >= 0 && l < L && k >= 1 && k < static_cast<std::size_t>(system.grid.cells) ?
        system.value(shape, ghosts, (k - 1) * system.stride + static_cast<std::size_t>(ne + (l - 1) / 2)) : 0.0; };
    for (std::size_t i = 0; i < system.count; ++i) {
        const auto cell = system.first + i;
        for (int l = m; l < L; ++l) {
            const double down = m == 0 ? static_cast<double>(l) / (2 * l - 1) : 1.0 / (2 * l - 1);
            const double up = m == 0 ? static_cast<double>(l + 1) / (2 * l + 3) : -1.0 / (2 * l + 3);
            if (l % 2 == 0) {
                double value = 0;
                if (l == 0) value = gamma_v / 3 * (d.faces[cell + 1] * face(1, cell + 1) * (d.faces[cell + 1] - d.centres[cell]) + d.faces[cell] * face(1, cell) * (d.centres[cell] - d.faces[cell]));
                else value = gamma_v * d.centres[cell] * d.widths[cell] *
                    ((l >= 1 ? down * 0.5 * (face(l - 1, cell) + face(l - 1, cell + 1)) : 0) + up * 0.5 * (face(l + 1, cell) + face(l + 1, cell + 1)));
                const auto row = i * system.stride + static_cast<std::size_t>(l / 2);
                source[row] = system.conditions.gas_density_m3 / d.mass[row] * value;
            } else if (cell + 1 < static_cast<std::size_t>(system.grid.cells)) {
                const auto k = cell + 1;
                const double t = (d.faces[k] - d.centres[k - 1]) / d.dual_widths[k];
                const auto centre = [&](int lp) { return lp < L ? (1 - t) * even(lp, k - 1) + t * even(lp, k) : 0.0; };
                const auto row = i * system.stride + static_cast<std::size_t>(ne + (l - 1) / 2);
                source[row] = system.conditions.gas_density_m3 / d.mass[row] * gamma_v * d.faces[k] * d.dual_widths[k] * (down * centre(l - 1) + up * centre(l + 1));
            }
        }
    }
    return source;
}
void diffusion(const std::vector<CollisionProcess>& processes, const LocalSystem& system, std::span<const double> shape,
               double tau_scale, SwarmResult& out) {
    if (!(system.conditions.reduced_field_td > 0)) return;
    const auto& h = *system.halo;
    auto cpu = system.conditions; cpu.execution.device = "cpu"; cpu.execution.preconditioner = "block_ilu0";
    cpu.execution.restart = std::max(cpu.execution.restart, 80); cpu.execution.max_iterations = std::max(cpu.execution.max_iterations, 2000);
    cpu.execution.tolerance = 1e-11;
    LocalSystem base(processes, cpu, system.grid, system.partition);
    const auto frozen = base.frozen(shape, true); const auto faces = base.faces(shape);
    const double growth = cpu.temporal_growth ? out.net_rate_m3_s * cpu.gas_density_m3 : 0;
    const double frequency = 1 / tau_scale, velocity = gamma_v, gradient_scale = cpu.gas_density_m3 * velocity * tau_scale;
    const double regularization = frequency * 1e-6;
    const bool scalar_owner = h.rank() + 1 == h.ranks();
    const auto p = backend::RowPartition{system.partition.global_rows + 1, system.partition.row_begin, system.partition.local_rows + (scalar_owner ? 1u : 0u)};
    DistributedHalo augmented(p, {}, cpu.execution);
    backend::DistributedCsrMatrix k{system.partition.global_rows, system.partition.row_begin, {0}, {}, {}};
    backend::DistributedCsrMatrix preconditioner{p.global_rows, p.row_begin, {0}, {}, {}};
    const auto source = streaming_source(base, shape, 0);
    std::vector<double> rhs(p.local_rows, 0), row_scale(system.partition.local_rows, 1);
    local_phase(h, [&] {
        for (std::size_t row = 0; row < system.partition.local_rows; ++row) {
            const auto global = system.partition.row_begin + row;
            std::map<GlobalIndex, double> entries;
            if (frozen.padding[row]) entries[global] = 1;
            else {
                for (auto entry = frozen.matrix.offsets[row]; entry < frozen.matrix.offsets[row + 1]; ++entry) entries[frozen.matrix.columns[entry]] -= frozen.matrix.values[entry];
                entries[global] += growth;
            }
            for (const auto& [column, value] : entries) { k.columns.push_back(column); k.values.push_back(value); }
            k.offsets.push_back(k.values.size());
            double scale = 0; for (const auto& [column, value] : entries) { (void)column; scale = std::max(scale, std::abs(value)); }
            const double border = frozen.padding[row] ? 0 : frequency * shape[row];
            scale = std::max({scale, std::abs(border), regularization}); row_scale[row] = scale;
            rhs[row] = source[row] / gradient_scale / scale;
            if (!frozen.padding[row] && global % system.stride == 0) entries[global] += regularization;
            for (const auto& [column, value] : entries) { preconditioner.columns.push_back(column); preconditioner.values.push_back(value / scale); }
            if (border != 0) { preconditioner.columns.push_back(system.partition.global_rows); preconditioner.values.push_back(border / scale); }
            preconditioner.offsets.push_back(preconditioner.values.size());
        }
        if (scalar_owner) { preconditioner.columns.push_back(system.partition.global_rows); preconditioner.values.push_back(1); preconditioner.offsets.push_back(preconditioner.values.size()); }
    });
    backend::DistributedLinearOperator sparse(std::move(k), cpu.execution);
    const auto apply = [&](std::span<const double> input) {
        const auto owned = input.first(system.partition.local_rows);
        auto product = sparse.apply(owned);
        const auto extra = landau_extra(base, faces, owned);
        const double bulk = augmented.global_sum(scalar_owner ? input.back() : 0);
        const double gauge = base.density(owned);
        for (std::size_t row = 0; row < product.size(); ++row)
            product[row] = (product[row] + extra[row] + (frozen.padding[row] ? 0 : frequency * shape[row] * bulk)) / row_scale[row];
        if (scalar_owner) product.push_back(gauge);
        return product;
    };
    const auto solved = backend::solve_distributed_matrix_free(augmented, preconditioner, apply, rhs, cpu.execution);
    const auto product = apply(solved.local_solution);
    double error = 0;
    for (std::size_t i = 0; i < rhs.size(); ++i) error = std::max(error, std::abs(product[i] - rhs[i]));
    const double relative = augmented.global_max(error) / std::max(maximum(augmented, rhs), 1e-300);
    augmented.collective_require(relative < 1e-8 ? "" : "owned longitudinal diffusion solve failed");
    out.gradient_residual = relative;
    out.bulk_drift_velocity_m_s = velocity * augmented.global_sum(scalar_owner ? solved.local_solution.back() : 0);
    double longitudinal = 0;
    const auto odd = static_cast<std::size_t>((system.grid.legendre_terms + 1) / 2);
    for (std::size_t i = 0; i < system.count; ++i) {
        const auto face = system.first + i + 1;
        if (face < static_cast<std::size_t>(system.grid.cells)) longitudinal += system.data.faces[face] * solved.local_solution[i * system.stride + odd] * system.data.dual_widths[face];
    }
    out.longitudinal_diffusion_n = gamma_v / 3 * gradient_scale * h.global_sum(longitudinal);
    LocalSystem transverse(processes, cpu, system.grid, system.partition, 1, false);
    const auto op1 = transverse.frozen(shape, true);
    const auto source1 = streaming_source(base, shape, 1);
    const auto solved1 = solve_shifted(transverse, op1, growth, 0, false, source1, std::vector<double>(system.partition.local_rows, 0));
    double across = 0;
    for (std::size_t i = 0; i < system.count; ++i) {
        const auto face = system.first + i + 1;
        if (face < static_cast<std::size_t>(system.grid.cells)) across += system.data.faces[face] * solved1.modes[i * system.stride + odd] * system.data.dual_widths[face];
    }
    out.transverse_diffusion_n = gamma_v / 3 * h.global_sum(across);
    out.gradient_residual = std::max(out.gradient_residual, solved1.residual);
}
}

backend::RowPartition distributed_eedf_partition(const EedfGrid& grid, const backend::ExecutionOptions& execution) {
    const auto cells = backend::distributed_partition(grid.cells > 0 ? static_cast<GlobalIndex>(grid.cells) : 0, execution);
    DistributedHalo control(cells, {}, execution);
    control.collective_require(grid.legendre_terms < 2 || grid.legendre_terms > 30 ? "invalid owned EEDF Legendre count" : "");
    const auto stride = static_cast<std::size_t>(grid.legendre_terms);
    agree(control, Json{grid.cells, grid.max_energy_ev, grid.power, grid.legendre_terms}.dump());
    return {cells.global_rows * stride, cells.row_begin * stride, cells.local_rows * stride};
}
DistributedEedfState maxwellian_eedf_distributed(double density_m3, double mean_energy_ev, const EedfGrid& grid, const backend::ExecutionOptions& execution) {
    const auto p = distributed_eedf_partition(grid, execution);
    DistributedHalo control(p, {}, execution);
    DistributedEedfState state{grid, p, 0, {}};
    double normalization = 0;
    local_phase(control, [&] {
        if (!(density_m3 > 0 && std::isfinite(density_m3) && mean_energy_ev > 0 && std::isfinite(mean_energy_ev)) ||
            grid.cells < 16 || grid.cells > 6000 || !(grid.max_energy_ev > 0 && std::isfinite(grid.max_energy_ev)) || !(grid.power >= 1 && grid.power <= 4 && std::isfinite(grid.power)))
            throw std::invalid_argument("invalid owned Maxwellian/grid parameters");
        state.density_modes.assign(p.local_rows, 0);
        const auto stride = static_cast<std::size_t>(grid.legendre_terms);
        for (std::size_t row = 0; row < p.local_rows; row += stride) {
            const auto cell = (p.row_begin + row) / stride;
            const double a = grid.max_energy_ev * std::pow(static_cast<double>(cell) / grid.cells, grid.power), b = grid.max_energy_ev * std::pow(static_cast<double>(cell + 1) / grid.cells, grid.power);
            state.density_modes[row] = std::exp(-0.5 * (a + b) / (2.0 / 3 * mean_energy_ev));
            normalization += state.density_modes[row] * 2.0 / 3 * (std::pow(b, 1.5) - std::pow(a, 1.5));
        }
    });
    agree(control, Json{density_m3, mean_energy_ev}.dump());
    normalization = control.global_sum(normalization);
    control.collective_require(normalization > 0 ? "" : "initial Maxwellian is unresolved on owned grid");
    for (double& v : state.density_modes) v *= density_m3 / normalization;
    return state;
}
FrozenEedfOperator freeze_eedf_operator(const std::vector<CollisionProcess>& processes, const EedfConditions& conditions,
    const DistributedEedfState& state, int azimuthal_order, bool mass_normalized, bool normalized_real_harmonics) {
    LocalSystem system(processes, conditions, state.grid, state.partition, azimuthal_order, normalized_real_harmonics);
    agree(*system.halo, mass_normalized ? "normalized" : "mass");
    return system.frozen(state.density_modes, mass_normalized);
}

DistributedEedfResult advance_eedf_distributed(const std::vector<CollisionProcess>& processes, const EedfConditions& conditions,
    const DistributedEedfState& initial, double dt_s) {
    LocalSystem initial_system(processes, conditions, initial.grid, initial.partition);
    const auto& h = *initial_system.halo;
    h.collective_require(dt_s > 0 && std::isfinite(dt_s) && initial.time_s >= 0 && std::isfinite(initial.time_s) ? "" : "invalid owned EEDF time/timestep");
    agree(h, Json{dt_s, initial.time_s}.dump());
    initial_system.validate(initial.density_modes);
    const double density0 = initial_system.density(initial.density_modes), energy0 = initial_system.energy(initial.density_modes);
    h.collective_require(density0 > 0 ? "" : "initial owned EEDF density must be positive");
    std::vector<double> history, iterate;
    local_phase(h, [&] { history = initial.density_modes; for (auto& value : history) value /= density0; iterate = history; });
    DistributedEedfResult result; result.state = initial;
    bool converged = false;
    for (int iteration = 0; iteration < 100; ++iteration) {
        auto c = conditions; c.electron_fraction = density0 * initial_system.density(iterate) / c.gas_density_m3; c.temporal_growth = false;
        LocalSystem system(processes, c, initial.grid, initial.partition);
        const auto frozen = system.frozen(iterate, true);
        std::vector<double> rhs;
        local_phase(h, [&] { rhs = history; for (auto& value : rhs) value /= dt_s; });
        const auto solved = solve_shifted(system, frozen, 0, 1 / dt_s, false, rhs, iterate);
        double change = 0;
        for (std::size_t i = 0; i < iterate.size(); ++i) change = std::max(change, std::abs(solved.modes[i] - iterate[i]));
        change = h.global_max(change); const double size = maximum(h, solved.modes);
        iterate = solved.modes; result.nonlinear_iterations = iteration + 1; result.linear_residual = solved.residual;
        result.ghost_modes = frozen.ghost_modes; result.local_matrix_entries = frozen.matrix.values.size();
        if (change <= 2e-13 * std::max(size, 1e-300)) { converged = true; break; }
    }
    h.collective_require(converged ? "" : "owned EEDF nonlinear iteration failed; reduce timestep");
    auto final_conditions = conditions; final_conditions.electron_fraction = density0 * initial_system.density(iterate) / conditions.gas_density_m3;
    LocalSystem final_system(processes, final_conditions, initial.grid, initial.partition);
    result.swarm = summarize(processes, final_system, iterate, false, result.nonlinear_iterations);
    local_phase(h, [&] { result.state.density_modes = iterate; for (auto& value : result.state.density_modes) value *= density0; result.state.time_s += dt_s; });
    const double density1 = final_system.density(result.state.density_modes), energy1 = final_system.energy(result.state.density_modes);
    const auto& b = result.swarm.budget;
    const double field = dt_s * conditions.gas_density_m3 * density1 * b.field;
    const double loss = dt_s * conditions.gas_density_m3 * density1 * (b.elastic + b.rotational + b.vibrational + b.electronic + b.ionization + b.attachment + b.recombination + b.electron_electron);
    result.energy_balance_relative = (field - loss - (energy1 - energy0)) / std::max({std::abs(field), std::abs(loss), std::abs(energy1 - energy0), 1e-300});
    return result;
}

DistributedEedfResult solve_eedf_distributed(const std::vector<CollisionProcess>& processes, const EedfConditions& conditions, const EedfGrid& grid) {
    auto state = maxwellian_eedf_distributed(1, std::max(1.5 * boltzmann * conditions.gas_temperature_k / charge, 1.0), grid, conditions.execution);
    LocalSystem system(processes, conditions, grid, state.partition);
    const auto& h = *system.halo;
    double worst = 0;
    const auto initial_operator = system.frozen(state.density_modes, true);
    for (std::size_t row = 0; row < state.partition.local_rows; row += system.stride) {
        double rate = 0; for (auto entry = initial_operator.matrix.offsets[row]; entry < initial_operator.matrix.offsets[row + 1]; ++entry) rate += std::abs(initial_operator.matrix.values[entry]);
        worst = std::max(worst, rate);
    }
    worst = h.global_max(worst);
    const double scale = worst > 0 ? 1 / worst : 1;
    double dt = scale, growth = 0;
    DistributedEedfResult result;
    bool converged = false;
    for (int iteration = 0; iteration < 400; ++iteration) {
        const auto frozen = system.frozen(state.density_modes, true);
        const auto summary = summarize(processes, system, state.density_modes, true, iteration);
        growth = conditions.temporal_growth ? summary.net_rate_m3_s * conditions.gas_density_m3 : 0;
        std::vector<double> rhs(state.partition.local_rows, 0);
        for (std::size_t row = 0; row < rhs.size(); row += system.stride) rhs[row] = state.density_modes[row] / dt;
        const auto solved = solve_shifted(system, frozen, growth, 1 / dt, true, rhs, state.density_modes);
        auto candidate = solved.modes;
        const double norm = system.density(candidate);
        h.collective_require(norm > 0 ? "" : "owned EEDF inverse iteration produced nonpositive density");
        for (auto& value : candidate) value /= norm;
        double change = 0, peak = 0;
        for (std::size_t row = 0; row < candidate.size(); row += system.stride) { change = std::max(change, std::abs(candidate[row] - state.density_modes[row])); peak = std::max(peak, std::abs(candidate[row])); }
        change = h.global_max(change); peak = h.global_max(peak);
        state.density_modes = std::move(candidate);
        result.nonlinear_iterations = iteration + 1; result.linear_residual = solved.residual; result.ghost_modes = frozen.ghost_modes; result.local_matrix_entries = frozen.matrix.values.size();
        if (dt >= scale * 1e6 && change <= 1e-10 * std::max(peak, 1e-300)) { converged = true; break; }
        // Retain a finite pseudo-time shift. Sending it below floating-point
        // resolution of the collision block permits spurious motion along the
        // conserved particle/energy directions, especially for strong Landau
        // scattering. At a fixed point the shift cancels exactly; the final
        // unshifted nonlinear equation is independently certified below.
        dt = std::min(dt * 10, scale * 1e6);
    }
    h.collective_require(converged ? "" : "owned steady EEDF inverse iteration did not converge");
    result.state = std::move(state); result.swarm = summarize(processes, system, result.state.density_modes, true, result.nonlinear_iterations);
    // Certify the unshifted nonlinear equation, rather than relying only on
    // the inverse-iteration update becoming small near a singular operator.
    const auto stationary = system.frozen(result.state.density_modes, true);
    auto stationary_options = system.conditions.execution;
    backend::DistributedLinearOperator stationary_operator(stationary.matrix, stationary_options);
    const auto production = stationary_operator.apply(result.state.density_modes);
    const auto ghosts = stationary_operator.halo().exchange(result.state.density_modes);
    const double stationary_growth = conditions.temporal_growth ? result.swarm.net_rate_m3_s * conditions.gas_density_m3 : 0;
    double stationary_error = 0, stationary_bound = 0;
    for (std::size_t row = 0; row < production.size(); ++row) {
        if (stationary.padding[row]) continue;
        stationary_error = std::max(stationary_error, std::abs(production[row] - stationary_growth * result.state.density_modes[row]));
        double bound = std::abs(stationary_growth * result.state.density_modes[row]);
        for (auto entry = stationary.matrix.offsets[row]; entry < stationary.matrix.offsets[row + 1]; ++entry) {
            const auto compact = stationary_operator.halo().compact_index(stationary.matrix.columns[entry]);
            const double value = compact < result.state.density_modes.size() ? result.state.density_modes[compact] : ghosts[compact - result.state.density_modes.size()];
            bound += std::abs(stationary.matrix.values[entry] * value);
        }
        stationary_bound = std::max(stationary_bound, bound);
    }
    h.collective_require(h.global_max(stationary_error) / std::max(h.global_max(stationary_bound), 1e-300) <= 1e-9 ? "" : "owned steady EEDF nonlinear residual exceeded tolerance");
    diffusion(processes, system, result.state.density_modes, scale, result.swarm);
    return result;
}
}
