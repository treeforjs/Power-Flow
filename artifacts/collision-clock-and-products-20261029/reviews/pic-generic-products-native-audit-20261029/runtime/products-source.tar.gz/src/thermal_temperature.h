#pragma once
#include "raikou/chemistry.h"
#include <string_view>

namespace raikou::thermal::detail {
inline bool is_liquid_phase(std::string_view phase) {
    return phase == "aqueous" || phase == "liquid";
}

inline double initial_temperature(const chemistry::Environment& environment, std::string_view phase) {
    return is_liquid_phase(phase) ? environment.liquid_temperature_K : environment.gas_temperature_K;
}

template<class Models> bool has_liquid_alias_collision(const Models& models) {
    return models.contains("aqueous") && models.contains("liquid");
}
} // namespace raikou::thermal::detail
