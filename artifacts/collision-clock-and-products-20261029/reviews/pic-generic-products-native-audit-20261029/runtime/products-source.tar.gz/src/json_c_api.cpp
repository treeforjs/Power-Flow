#include "raikou/c_api.h"
#include "raikou/runtime.h"
#include "raikou/backend.h"
#include <cstdlib>
#include <cstring>
#include <stdexcept>
extern "C" {
RAIKOU_API int raikou_execute_json(const char* operation,const char* request,char** output) {
    if(!output)return 1;
    *output=nullptr;
    int code=0;
    raikou::Json response;
    try {
        if(!operation || !request)throw std::invalid_argument("operation/request must not be null");
        response={{"ok",true},{"result",raikou::execute(operation,raikou::Json::parse(request))}};
    } catch(const std::exception& e) { code=1;response={{"ok",false},{"error",e.what()}}; }
    catch(...) { code=2;response={{"ok",false},{"error","unknown native exception"}}; }
    try {
        const auto text=response.dump(-1,' ',false,raikou::Json::error_handler_t::replace);
        *output=static_cast<char*>(std::malloc(text.size()+1));
        if(!*output)return 2;
        std::memcpy(*output,text.c_str(),text.size()+1);
    } catch(...) { return 2; }
    return code;
}
RAIKOU_API void raikou_free_string(char* output) { std::free(output); }
}
