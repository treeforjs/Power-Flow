#include "raikou/spatial_distributed.h"
#include "thermal_temperature.h"
#include <algorithm>
#include <cmath>
#include <set>
#include <stdexcept>

namespace raikou::spatial {
namespace {
[[noreturn]] void invalid(const std::string& text){throw std::invalid_argument("spatial MPI compatibility: "+text);}
void require(bool value,const std::string& text){if(!value)invalid(text);}
template<class Action>void collectively(const backend::DistributedHalo& halo,Action&& action){std::string error;try{action();}catch(const std::exception& exception){error=exception.what();}halo.collective_require(error);}
std::vector<double> scalar_initial(const std::vector<double>& field){return field.size()==1?field:std::vector<double>{};}
Thermal::Phase static_phase(const Thermal::Phase& source){return {source.heat_capacity_J_m3_K,source.conductivity_W_m_K,scalar_initial(source.initial_temperature_K),source.heating_W_m3,source.heat_reservoirs};}
// Deliberately do not copy global initial/checkpoint vectors into the numerical
// model. The compatibility input remains borrowed until owned advancement ends.
std::shared_ptr<Problem> static_model(const Problem& source){
    auto p=std::make_shared<Problem>();p->mesh=source.mesh;p->mechanism=source.mechanism;p->environment=source.environment;p->electron_closure=source.electron_closure;p->electron_mode=source.electron_mode;
    p->electron_field_axis=source.electron_field_axis;p->initial_electron_mean_energy_eV=source.initial_electron_mean_energy_eV;p->transport=source.transport;p->boundaries=source.boundaries;p->permittivity_F_m=source.permittivity_F_m;
    p->phase_fractions=source.phase_fractions;p->face_reactions=source.face_reactions;p->interface_heat_transfer=source.interface_heat_transfer;p->electron_phase_contacts=source.electron_phase_contacts;p->circuit=source.circuit;p->options=source.options;
    p->initial_densities_m3.assign(source.mechanism.species.size(),0);
    p->thermal.enabled=source.thermal.enabled;p->thermal.heat_capacity_J_m3_K=source.thermal.heat_capacity_J_m3_K;p->thermal.conductivity_W_m_K=source.thermal.conductivity_W_m_K;
    p->thermal.initial_temperature_K=scalar_initial(source.thermal.initial_temperature_K);p->thermal.heating_W_m3=source.thermal.heating_W_m3;p->thermal.heat_reservoirs=source.thermal.heat_reservoirs;
    p->thermal.joule_species=source.thermal.joule_species;p->thermal.use_eedf_elastic_heating=source.thermal.use_eedf_elastic_heating;
    for(const auto& [phase,value]:source.thermal.phases)p->thermal.phases[phase]=static_phase(value);
    p->radiation.reserve(source.radiation.size());
    for(const auto& group:source.radiation){RadiationGroup value;value.id=group.id;value.photon_energy_eV=group.photon_energy_eV;value.speed_m_s=group.speed_m_s;value.diffusion_m2_s=group.diffusion_m2_s;
        value.absorption_m1=group.absorption_m1;value.absorption_m1_by_phase=group.absorption_m1_by_phase;value.initial_density_m3=scalar_initial(group.initial_density_m3);value.emission_W_m3=group.emission_W_m3;
        value.energy_reservoir=group.energy_reservoir;value.absorbers=group.absorbers;value.escaping_sides=group.escaping_sides;p->radiation.push_back(std::move(value));}
    return p;
}
std::vector<std::string> thermal_names(const Problem& p){std::vector<std::string> result;if(!p.thermal.enabled)return result;if(p.thermal.phases.empty())result.emplace_back();else for(const auto& [name,field]:p.thermal.phases){(void)field;result.push_back(name);}return result;}
double initial_field(const std::vector<double>& field,std::size_t cell,std::size_t count,double fallback=0){require(field.empty()||field.size()==1||field.size()==count,"initial field must be scalar or one value per cell");return field.empty()?fallback:field[field.size()==1?0:cell];}
std::vector<double> reduce_values(const backend::DistributedHalo& halo,const std::vector<double>& local){auto result=local;for(double& value:result)value=halo.global_sum(value);return result;}
std::map<std::string,double> reduce_map(const backend::DistributedHalo& halo,const std::map<std::string,double>& local,backend::ExecutionOptions execution){
    std::set<std::string> keys;Json own=Json::array();for(const auto& [key,value]:local){(void)value;own.push_back(key);}
    execution.communicator_f=halo.communicator_f();
    for(int rank=0;rank<halo.ranks();++rank){const auto names=backend::broadcast_json(own,rank,execution);for(const auto& key:names)keys.insert(key.get<std::string>());}
    std::map<std::string,double> result;for(const auto& key:keys){const auto found=local.find(key);result[key]=halo.global_sum(found==local.end()?0:found->second);}return result;
}
}

Result solve_mpi_compat(const Problem& problem){
    backend::ExecutionOptions execution;execution.mpi=problem.options.mpi;execution.communicator_f=problem.options.communicator_f;execution.device=problem.options.device;execution.cuda_device=problem.options.cuda_device;execution.threads=problem.options.threads;
    backend::DistributedHalo control(backend::distributed_partition(1,execution),{},execution);
    std::shared_ptr<Problem> model;mesh::Geometry geometry;std::vector<std::string> thermal;
    std::vector<unsigned char> dielectric;std::vector<std::size_t> surface_index;std::size_t surfaces=0;
    const auto ns=problem.mechanism.species.size(),ng=problem.radiation.size();
    collectively(control,[&]{
        require(execution.mpi,"solve_mpi_compat requires MPI execution");model=static_model(problem);geometry=mesh::geometry(model->mesh);thermal=thermal_names(problem);
        const auto cells=geometry.volume.size();require(problem.initial_densities_m3.size()==cells*ns||problem.initial_densities_m3.size()==ns,"replicated initial species shape differs from geometry");
        dielectric.assign(geometry.walls.size(),0);surface_index.assign(geometry.walls.size(),0);
        for(std::size_t w=0;w<geometry.walls.size();++w)if(problem.boundaries[static_cast<std::size_t>(geometry.walls[w].side)].kind==BoundaryKind::Dielectric&&geometry.walls[w].area>0){dielectric[w]=1;surface_index[w]=surfaces++;}
    });
    const auto nc=geometry.volume.size();const bool circuit=problem.circuit.enabled&&problem.circuit.series_resistance_ohm>0;
    partition::DofLayout layout(geometry,ns,ng,thermal.size(),dielectric,circuit,execution);
    const auto owned=layout.owned_cells();const auto rows=layout.row_partition();
    DistributedProblem local;local.model=model;local.owned_cells=owned;local.adaptive_time=problem.options.adaptive_time;
    local.initial.density=[&](std::size_t cell,std::size_t species){return problem.initial_densities_m3[problem.initial_densities_m3.size()==ns?species:cell*ns+species];};
    local.initial.temperature=[&](std::size_t cell,std::size_t field){const auto& phase=thermal.at(field);const auto& initial=phase.empty()?problem.thermal.initial_temperature_K:problem.thermal.phases.at(phase).initial_temperature_K;return initial_field(initial,cell,nc,::raikou::thermal::detail::initial_temperature(problem.environment,phase));};
    local.initial.photon=[&](std::size_t cell,std::size_t group){return initial_field(problem.radiation.at(group).initial_density_m3,cell,nc);};
    const auto pack=[&](const State& source){
        require(source.time_s>=0&&std::isfinite(source.time_s)&&std::isfinite(source.driven_voltage_V),"checkpoint clock/voltage must be finite");
        require(source.densities_m3.size()==nc*ns&&source.potential_V.size()==nc&&source.photon_densities_m3.size()==nc*ng,"checkpoint cell fields differ from geometry");
        require(source.surface_charge_C_m2.size()==surfaces&&source.dielectric_potential_V.size()==surfaces,"checkpoint dielectric fields differ from wall ownership");
        require(source.temperature_K.size()==(!thermal.empty()&&thermal[0].empty()?nc:0),"checkpoint common temperature shape differs");
        require(source.electrons.empty()||source.spherical_electrons.empty(),"checkpoint cannot contain two electron representations");
        for(const auto& phase:thermal)if(!phase.empty())require(source.phase_temperatures_K.contains(phase)&&source.phase_temperatures_K.at(phase).size()==nc,"checkpoint phase temperature shape differs");
        DistributedState result;result.time_s=source.time_s;result.rows=rows;result.cells=owned;result.owned_values.assign(rows.local_rows,0);
        const auto set=[&](backend::GlobalIndex global,double value){require(layout.owns_dof(global),"checkpoint packing attempted a nonowned DOF");result.owned_values[static_cast<std::size_t>(global-rows.row_begin)]=value;};
        for(std::size_t c=owned.begin;c<owned.begin+owned.count;++c){for(std::size_t s=0;s<ns;++s)set(layout.cell_dof(c,s),source.densities_m3[c*ns+s]);set(layout.cell_dof(c,layout.phi_component()),source.potential_V[c]);
            for(std::size_t group=0;group<ng;++group)set(layout.cell_dof(c,layout.photon_component(group)),source.photon_densities_m3[c*ng+group]);
            for(std::size_t k=0;k<thermal.size();++k)set(layout.cell_dof(c,layout.thermal_component(k)),thermal[k].empty()?source.temperature_K[c]:source.phase_temperatures_K.at(thermal[k])[c]);}
        for(std::size_t w=0;w<geometry.walls.size();++w)if(dielectric[w]&&layout.owns_dof(layout.sigma_dof(w))){set(layout.sigma_dof(w),source.surface_charge_C_m2[surface_index[w]]);set(layout.dielectric_dof(w),source.dielectric_potential_V[surface_index[w]]);}
        if(circuit&&layout.owns_dof(layout.circuit_dof()))set(layout.circuit_dof(),source.driven_voltage_V);
        if(!source.spherical_electrons.empty()){require(source.spherical_electrons.size()==nc,"checkpoint spherical cell count differs");result.spherical_electrons.assign(source.spherical_electrons.begin()+static_cast<std::ptrdiff_t>(owned.begin),source.spherical_electrons.begin()+static_cast<std::ptrdiff_t>(owned.begin+owned.count));}
        if(!source.electrons.empty()){require(source.electrons.size()==nc,"checkpoint Legendre cell count differs");result.electrons.assign(source.electrons.begin()+static_cast<std::ptrdiff_t>(owned.begin),source.electrons.begin()+static_cast<std::ptrdiff_t>(owned.begin+owned.count));}
        return result;
    };
    collectively(control,[&]{if(problem.initial_checkpoint){
        const auto& source=*problem.initial_checkpoint;DistributedCheckpoint cp;cp.state=pack(source.state);cp.previous_state=pack(source.previous_state);cp.previous_step_s=source.previous_step_s;cp.next_step_s=source.next_step_s;cp.accepted_steps=source.accepted_steps;
        if(source.accepted_steps==0){require(source.previous_step_s>=0&&std::isfinite(source.previous_step_s)&&source.state.time_s==source.previous_state.time_s,"zero-step checkpoint has inconsistent previous history");cp.previous_step_s=0;}
        require(source.boundary_counts.size()==ns&&source.previous_boundary_counts.size()==ns,"checkpoint boundary ledger differs from species count");
        for(const auto* values:{&source.boundary_counts,&source.previous_boundary_counts})for(double value:*values)require(std::isfinite(value),"checkpoint boundary history is nonfinite");
        for(const auto* ledger:{&source.energy_integrals_J,&source.previous_energy_integrals_J})for(const auto& [name,value]:*ledger){(void)name;require(std::isfinite(value),"checkpoint energy history is nonfinite");}
        for(const auto* ledger:{&source.thermal_energy_integrals_J,&source.previous_thermal_energy_integrals_J,
                               &source.thermal_energy_residual_bound_J,&source.previous_thermal_energy_residual_bound_J}){
            if(!source.thermal_energy_ledger_available){require(ledger->empty(),"unavailable thermal history must not contain partial ledgers");continue;}
            const bool bound=ledger==&source.thermal_energy_residual_bound_J||ledger==&source.previous_thermal_energy_residual_bound_J;
            require(ledger->size()==thermal.size(),"checkpoint thermal ledger phase ownership mismatch");
            for(const auto& phase:thermal){
                require(ledger->contains(phase)&&ledger->at(phase).size()==nc,"checkpoint thermal ledger cell shape mismatch");
                for(std::size_t c=0;c<nc;++c){
                    const double value=ledger->at(phase)[c];require(std::isfinite(value)&&(!bound||value>=0),"invalid checkpoint thermal energy ledger");
                    const double fraction=phase.empty()||!problem.phase_fractions.contains(phase)?1:initial_field(problem.phase_fractions.at(phase),c,nc,1);
                    require(fraction>0||value==0,"checkpoint absent thermal phase cannot own energy");
                }
            }
        }
        if(source.thermal_energy_ledger_available)for(const auto& phase:thermal)for(std::size_t c=0;c<nc;++c)
            require(source.thermal_energy_residual_bound_J.at(phase)[c]>=source.previous_thermal_energy_residual_bound_J.at(phase)[c],"checkpoint thermal residual bound history must be monotone");
        cp.local_boundary_counts.assign(ns,0);cp.previous_local_boundary_counts.assign(ns,0);
        // Historical ledgers are already global. Assign them once, without
        // division or recomputing their physical owner, then continue locally.
        if(control.rank()==0){cp.local_boundary_counts=source.boundary_counts;cp.previous_local_boundary_counts=source.previous_boundary_counts;cp.local_energy_integrals_J=source.energy_integrals_J;cp.previous_local_energy_integrals_J=source.previous_energy_integrals_J;}
        local.checkpoint=std::move(cp);
    }});
    const auto numerical=solve_distributed(local);
    const auto gather_state=[&](const DistributedState& source){
        collectively(control,[&]{require(source.rows.global_rows==rows.global_rows&&source.rows.row_begin==rows.row_begin&&source.owned_values.size()==rows.local_rows,"completed state ownership differs from compatibility layout");});
        const auto values=backend::gather_distributed(layout.control_halo(),source.owned_values);
        State full;full.time_s=source.time_s;full.densities_m3.resize(nc*ns);full.potential_V.resize(nc);full.photon_densities_m3.resize(nc*ng);full.surface_charge_C_m2.resize(surfaces);full.dielectric_potential_V.resize(surfaces);
        if(!thermal.empty()&&thermal[0].empty())full.temperature_K.resize(nc);
        for(const auto& phase:thermal)if(!phase.empty())full.phase_temperatures_K[phase].resize(nc);
        for(std::size_t c=0;c<nc;++c){for(std::size_t s=0;s<ns;++s)full.densities_m3[c*ns+s]=values[static_cast<std::size_t>(layout.cell_dof(c,s))];full.potential_V[c]=values[static_cast<std::size_t>(layout.cell_dof(c,layout.phi_component()))];
            for(std::size_t group=0;group<ng;++group)full.photon_densities_m3[c*ng+group]=values[static_cast<std::size_t>(layout.cell_dof(c,layout.photon_component(group)))];
            for(std::size_t k=0;k<thermal.size();++k){const double temperature=values[static_cast<std::size_t>(layout.cell_dof(c,layout.thermal_component(k)))];if(thermal[k].empty())full.temperature_K[c]=temperature;else full.phase_temperatures_K[thermal[k]][c]=temperature;}}
        for(std::size_t w=0;w<geometry.walls.size();++w)if(dielectric[w]){full.surface_charge_C_m2[surface_index[w]]=values[static_cast<std::size_t>(layout.sigma_dof(w))];full.dielectric_potential_V[surface_index[w]]=values[static_cast<std::size_t>(layout.dielectric_dof(w))];}
        full.driven_voltage_V=circuit?values[static_cast<std::size_t>(layout.circuit_dof())]:problem.circuit.source_voltage_V;
        const auto gather_modes=[&](bool spherical){
            const auto& grid=problem.electron_closure->grid;const auto stride=static_cast<std::size_t>(grid.legendre_terms)*(spherical?static_cast<std::size_t>(grid.legendre_terms):1);
            const auto per_cell=static_cast<std::size_t>(grid.cells)*stride;std::vector<double> packed;
            collectively(control,[&]{const auto count=spherical?source.spherical_electrons.size():source.electrons.size();require(count==owned.count,"completed electron cell ownership differs");packed.reserve(owned.count*per_cell);
                for(std::size_t c=0;c<owned.count;++c){
                    const auto& actual_grid=spherical?source.spherical_electrons[c].grid:source.electrons[c].grid;
                    const double clock=spherical?source.spherical_electrons[c].time_s:source.electrons[c].time_s;
                    require(actual_grid.cells==grid.cells&&actual_grid.legendre_terms==grid.legendre_terms&&actual_grid.max_energy_ev==grid.max_energy_ev&&actual_grid.power==grid.power,"completed electron grid differs from declared model");
                    require(std::abs(clock-source.time_s)<=1e-12*std::max(source.time_s,1e-30),"completed electron/spatial clocks differ");
                    const auto& modes=spherical?source.spherical_electrons[c].density_modes:source.electrons[c].density_modes;require(modes.size()==per_cell,"completed electron grid differs");packed.insert(packed.end(),modes.begin(),modes.end());}});
            backend::DistributedHalo angular({static_cast<backend::GlobalIndex>(nc)*per_cell,static_cast<backend::GlobalIndex>(owned.begin)*per_cell,owned.count*per_cell},{},execution);
            const auto all=backend::gather_distributed(angular,packed);
            if(spherical){full.spherical_electrons.resize(nc);for(std::size_t c=0;c<nc;++c){auto& state=full.spherical_electrons[c];state.grid=grid;state.time_s=source.time_s;state.density_modes.assign(all.begin()+static_cast<std::ptrdiff_t>(c*per_cell),all.begin()+static_cast<std::ptrdiff_t>((c+1)*per_cell));}}
            else{full.electrons.resize(nc);for(std::size_t c=0;c<nc;++c){auto& state=full.electrons[c];state.grid=grid;state.time_s=source.time_s;state.density_modes.assign(all.begin()+static_cast<std::ptrdiff_t>(c*per_cell),all.begin()+static_cast<std::ptrdiff_t>((c+1)*per_cell));}}
        };
        if(problem.electron_closure&&problem.electron_mode=="transient_spherical")gather_modes(true);
        if(problem.electron_closure&&problem.electron_mode=="transient_boltzmann")gather_modes(false);
        return full;
    };
    Result result;result.success=numerical.success;result.message=numerical.message;result.accepted_steps=numerical.checkpoint.accepted_steps;result.rejected_steps=numerical.rejected_steps;result.samples=numerical.samples;result.particle_counts=numerical.particle_counts;
    result.particles_collected_at_boundaries=numerical.particles_collected_at_boundaries;result.chemical_energy_integrals_J=numerical.chemical_energy_integrals_J;
    result.state=gather_state(numerical.state);result.checkpoint.state=result.state;result.checkpoint.previous_state=gather_state(numerical.checkpoint.previous_state);
    result.checkpoint.previous_step_s=numerical.checkpoint.previous_step_s;result.checkpoint.next_step_s=numerical.checkpoint.next_step_s;result.checkpoint.accepted_steps=numerical.checkpoint.accepted_steps;
    result.checkpoint.boundary_counts=reduce_values(control,numerical.checkpoint.local_boundary_counts);result.checkpoint.previous_boundary_counts=reduce_values(control,numerical.checkpoint.previous_local_boundary_counts);
    result.checkpoint.energy_integrals_J=reduce_map(control,numerical.checkpoint.local_energy_integrals_J,execution);result.checkpoint.previous_energy_integrals_J=reduce_map(control,numerical.checkpoint.previous_local_energy_integrals_J,execution);
    // No thermal time has elapsed on a new zero-step checkpoint, so its
    // cumulative history is known exactly. A no-step restart can retain a
    // supplied history. Any real distributed thermal advance makes that
    // history unavailable; temperature differences cannot reconstruct it.
    const auto initial_steps=problem.initial_checkpoint?problem.initial_checkpoint->accepted_steps:0;
    if(thermal.empty()||result.accepted_steps==initial_steps){
        if(problem.initial_checkpoint){
            const auto& source=*problem.initial_checkpoint;
            result.checkpoint.thermal_energy_ledger_available=source.thermal_energy_ledger_available;
            result.checkpoint.thermal_energy_integrals_J=source.thermal_energy_integrals_J;
            result.checkpoint.previous_thermal_energy_integrals_J=source.previous_thermal_energy_integrals_J;
            result.checkpoint.thermal_energy_residual_bound_J=source.thermal_energy_residual_bound_J;
            result.checkpoint.previous_thermal_energy_residual_bound_J=source.previous_thermal_energy_residual_bound_J;
        }else for(const auto& phase:thermal){
            result.checkpoint.thermal_energy_integrals_J[phase].assign(nc,0);
            result.checkpoint.previous_thermal_energy_integrals_J[phase].assign(nc,0);
            result.checkpoint.thermal_energy_residual_bound_J[phase].assign(nc,0);
            result.checkpoint.previous_thermal_energy_residual_bound_J[phase].assign(nc,0);
        }
    }else result.checkpoint.thermal_energy_ledger_available=false;
    if(!result.checkpoint.thermal_energy_ledger_available){
        result.chemical_energy_integrals_J.erase("Thermal/net_energy");
        result.checkpoint.energy_integrals_J.erase("Thermal/net_energy");
        result.checkpoint.previous_energy_integrals_J.erase("Thermal/net_energy");
    }
    result.thermal_energy_integrals_J=result.checkpoint.thermal_energy_integrals_J;
    result.thermal_energy_residual_bound_J=result.checkpoint.thermal_energy_residual_bound_J;
    return result;
}
} // namespace raikou::spatial
