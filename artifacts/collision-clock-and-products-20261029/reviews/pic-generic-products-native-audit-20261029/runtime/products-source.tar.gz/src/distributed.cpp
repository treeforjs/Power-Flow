#include "raikou/distributed.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <limits>
#include <mutex>
#include <stdexcept>
#include <utility>
#ifdef RAIKOU_HAS_MPI
#include <mpi.h>
#endif

namespace raikou::backend {
namespace detail { void check_mpi_call_context(); }
namespace {
constexpr auto max_count = static_cast<std::size_t>(std::numeric_limits<int>::max());
#ifdef RAIKOU_HAS_MPI
void checked(int status) {
    if (status != MPI_SUCCESS) {
        std::array<char, MPI_MAX_ERROR_STRING> message{};
        int length = 0;
        MPI_Error_string(status, message.data(), &length);
        throw std::runtime_error("distributed MPI error: " + std::string(message.data(), static_cast<std::size_t>(length)));
    }
}
#endif
struct Context {
    bool mpi = false;
    int rank = 0, ranks = 1;
    int fortran_communicator = -1;
#ifdef RAIKOU_HAS_MPI
    MPI_Comm communicator = MPI_COMM_NULL;
#endif
    explicit Context(const ExecutionOptions& options) : mpi(options.mpi) {
        if (!mpi) return;
        detail::check_mpi_call_context();
#ifdef RAIKOU_HAS_MPI
        check_thread();
        const auto source = options.communicator_f >= 0 ? MPI_Comm_f2c(static_cast<MPI_Fint>(options.communicator_f)) : MPI_COMM_WORLD;
        if (source == MPI_COMM_NULL) throw std::invalid_argument("distributed communicator must not be null");
        checked(MPI_Comm_dup(source, &communicator));
        try {
            checked(MPI_Comm_set_errhandler(communicator, MPI_ERRORS_RETURN));
            checked(MPI_Comm_rank(communicator, &rank));
            checked(MPI_Comm_size(communicator, &ranks));
            fortran_communicator = static_cast<int>(MPI_Comm_c2f(communicator));
        } catch (...) { MPI_Comm_free(&communicator); throw; }
#else
        throw std::runtime_error("distributed MPI execution was not built");
#endif
    }
    ~Context() {
#ifdef RAIKOU_HAS_MPI
        if (communicator == MPI_COMM_NULL) return;
        int finalized = 0;
        MPI_Finalized(&finalized);
        if (finalized) return;
        int main_thread = 0, provided = 0;
        MPI_Is_thread_main(&main_thread);
        MPI_Query_thread(&provided);
        // Destruction on a forbidden worker thread cannot safely call MPI.
        // Such an operator should be released on the owning MPI host thread.
        if (main_thread || provided == MPI_THREAD_MULTIPLE) MPI_Comm_free(&communicator);
#endif
    }
    Context(const Context&) = delete;
    Context& operator=(const Context&) = delete;
    void check_thread() const {
        if (!mpi) return;
        detail::check_mpi_call_context();
#ifdef RAIKOU_HAS_MPI
        int initialized = 0, finalized = 0;
        checked(MPI_Initialized(&initialized));
        if (initialized) checked(MPI_Finalized(&finalized));
        if (!initialized || finalized) throw std::runtime_error("distributed MPI requires a live host-initialized runtime");
        int main_thread = 0, provided = 0;
        checked(MPI_Is_thread_main(&main_thread));
        checked(MPI_Query_thread(&provided));
        if (!main_thread && provided != MPI_THREAD_MULTIPLE)
            throw std::runtime_error("distributed MPI calls require the MPI main thread or MPI_THREAD_MULTIPLE");
#endif
    }
    void require(const std::string& error) const {
        check_thread();
#ifdef RAIKOU_HAS_MPI
        if (ranks > 1) {
            const int candidate = error.empty() ? std::numeric_limits<int>::max() : rank;
            int first = 0;
            checked(MPI_Allreduce(&candidate, &first, 1, MPI_INT, MPI_MIN, communicator));
            if (first != std::numeric_limits<int>::max()) {
                int length = rank == first ? static_cast<int>(std::min<std::size_t>(error.size(), 4096)) : 0;
                checked(MPI_Bcast(&length, 1, MPI_INT, first, communicator));
                std::array<char, 4096> text{};
                if (rank == first) std::copy_n(error.data(), length, text.data());
                checked(MPI_Bcast(text.data(), length, MPI_CHAR, first, communicator));
                throw std::invalid_argument("rank " + std::to_string(first) + ": " + std::string(text.data(), static_cast<std::size_t>(length)));
            }
            return;
        }
#endif
        if (!error.empty()) throw std::invalid_argument(error);
    }
    void same(GlobalIndex value, const char* name) const {
        check_thread();
#ifdef RAIKOU_HAS_MPI
        if (ranks > 1) {
            const auto own = static_cast<unsigned long long>(value);
            unsigned long long minimum = 0, maximum = 0;
            checked(MPI_Allreduce(&own, &minimum, 1, MPI_UNSIGNED_LONG_LONG, MPI_MIN, communicator));
            checked(MPI_Allreduce(&own, &maximum, 1, MPI_UNSIGNED_LONG_LONG, MPI_MAX, communicator));
            if (minimum != maximum) throw std::invalid_argument(std::string("distributed ranks disagree on ") + name);
        }
#else
        (void)value; (void)name;
#endif
    }
    double reduce(double value, bool maximum) const {
        require(std::isfinite(value) ? "" : "non-finite distributed reduction input");
#ifdef RAIKOU_HAS_MPI
        if (ranks > 1) {
            double result = 0;
            checked(MPI_Allreduce(&value, &result, 1, MPI_DOUBLE, maximum ? MPI_MAX : MPI_SUM, communicator));
            if (!std::isfinite(result)) throw std::runtime_error("distributed reduction overflow");
            return result;
        }
#else
        (void)maximum;
#endif
        return value;
    }
};
std::string vector_error(std::span<const double> values, std::size_t count) {
    if (values.size() != count) return "distributed vector has incorrect local ownership size";
    for (const double value : values) if (!std::isfinite(value)) return "distributed vector contains a non-finite value";
    return {};
}
}

RowPartition balanced_partition(GlobalIndex global_rows, int rank, int ranks) {
    if (!global_rows || ranks <= 0 || rank < 0 || rank >= ranks)
        throw std::invalid_argument("invalid distributed partition dimensions");
    // Quotient/remainder form avoids overflowing global_rows * rank.
    const auto divisor = static_cast<GlobalIndex>(ranks);
    const auto quotient = global_rows / divisor, remainder = global_rows % divisor;
    const auto first = quotient * static_cast<GlobalIndex>(rank) +
        remainder * static_cast<GlobalIndex>(rank) / divisor;
    const auto last = quotient * static_cast<GlobalIndex>(rank + 1) +
        remainder * static_cast<GlobalIndex>(rank + 1) / divisor;
    if (last - first > std::numeric_limits<std::size_t>::max()) throw std::invalid_argument("local partition exceeds addressable storage");
    return {global_rows, first, static_cast<std::size_t>(last - first)};
}
RowPartition distributed_partition(GlobalIndex global_rows, const ExecutionOptions& options) {
    const Context context(options);
    context.require(global_rows ? "" : "global distributed row count must be positive");
    context.same(global_rows, "global row count");
    return balanced_partition(global_rows, context.rank, context.ranks);
}
void DistributedCsrMatrix::validate_local() const {
    if (!global_rows || row_begin > global_rows || local_rows() > global_rows - row_begin || offsets.empty() ||
        offsets.front() != 0 || offsets.back() != values.size() || columns.size() != values.size())
        throw std::invalid_argument("invalid local distributed CSR dimensions");
    for (std::size_t row = 0; row < local_rows(); ++row)
        if (offsets[row] > offsets[row + 1] || offsets[row + 1] > values.size())
            throw std::invalid_argument("distributed CSR offsets exceed local buffers");
    for (std::size_t entry = 0; entry < values.size(); ++entry)
        if (columns[entry] >= global_rows || !std::isfinite(values[entry]))
            throw std::invalid_argument("invalid distributed CSR global column or coefficient");
}

struct DistributedHalo::Impl {
    Context context;
    RowPartition partition;
    HaloLayout layout;
    std::vector<GlobalIndex> starts, ends;
    std::vector<int> send_counts, receive_counts, send_displacements, receive_displacements;
    mutable std::recursive_mutex mutex;

    Impl(RowPartition owned, std::span<const GlobalIndex> requested, const ExecutionOptions& options)
        : context(options), partition(owned) {
        context.require(!owned.global_rows || owned.row_begin > owned.global_rows || owned.local_rows > owned.global_rows - owned.row_begin ?
            "invalid local distributed row interval" : "");
        context.same(owned.global_rows, "global row count");
        std::string error;
        try { starts.resize(static_cast<std::size_t>(context.ranks)); ends.resize(starts.size()); }
        catch (const std::exception& exception) { error = exception.what(); }
        context.require(error);
#ifdef RAIKOU_HAS_MPI
        if (context.ranks > 1) {
            const std::array<unsigned long long, 2> local{static_cast<unsigned long long>(owned.row_begin), static_cast<unsigned long long>(owned.local_rows)};
            std::vector<unsigned long long> ranges;
            try { ranges.resize(2 * static_cast<std::size_t>(context.ranks)); }
            catch (const std::exception& exception) { error = exception.what(); }
            context.require(error);
            checked(MPI_Allgather(local.data(), 2, MPI_UNSIGNED_LONG_LONG, ranges.data(), 2, MPI_UNSIGNED_LONG_LONG, context.communicator));
            for (int rank = 0; rank < context.ranks; ++rank) {
                const auto r = static_cast<std::size_t>(rank);
                starts[r] = static_cast<GlobalIndex>(ranges[2 * r]);
                if (ranges[2 * r + 1] > owned.global_rows - std::min(owned.global_rows, starts[r])) error = "distributed ownership interval exceeds global rows";
                ends[r] = starts[r] + static_cast<GlobalIndex>(ranges[2 * r + 1]);
            }
        } else
#endif
        { starts[0] = owned.row_begin; ends[0] = owned.row_begin + static_cast<GlobalIndex>(owned.local_rows); }
        GlobalIndex next = 0;
        for (std::size_t rank = 0; rank < starts.size(); ++rank) {
            if (starts[rank] != next || ends[rank] < starts[rank] || ends[rank] > owned.global_rows)
                error = "rank ownership intervals must cover global rows exactly in rank order";
            next = ends[rank];
        }
        if (next != owned.global_rows) error = "distributed row ownership does not cover the global problem";
        context.require(error);
        try {
            for (const auto id : requested) {
                if (id >= owned.global_rows) throw std::invalid_argument("halo requested a global ID outside the partition");
                if (id < owned.row_begin || id >= owned.row_begin + owned.local_rows) layout.ghost_global_ids.push_back(id);
            }
            std::sort(layout.ghost_global_ids.begin(), layout.ghost_global_ids.end());
            layout.ghost_global_ids.erase(std::unique(layout.ghost_global_ids.begin(), layout.ghost_global_ids.end()), layout.ghost_global_ids.end());
            if (layout.ghost_global_ids.size() > max_count) throw std::invalid_argument("halo exceeds MPI count limits");
            const auto count = static_cast<std::size_t>(context.ranks);
            receive_counts.assign(count, 0); send_counts.assign(count, 0);
            receive_displacements.assign(count, 0); send_displacements.assign(count, 0);
            for (const auto id : layout.ghost_global_ids) {
                const auto owner = static_cast<std::size_t>(std::upper_bound(ends.begin(), ends.end(), id) - ends.begin());
                if (owner >= ends.size() || id < starts[owner]) throw std::invalid_argument("halo global ID has no owner");
                ++receive_counts[owner];
            }
        } catch (const std::exception& exception) { error = exception.what(); }
        context.require(error);
#ifdef RAIKOU_HAS_MPI
        if (context.ranks > 1)
            checked(MPI_Alltoall(receive_counts.data(), 1, MPI_INT, send_counts.data(), 1, MPI_INT, context.communicator));
#endif
        std::size_t total_send = 0, total_receive = 0;
        for (std::size_t rank = 0; rank < send_counts.size(); ++rank) {
            send_displacements[rank] = static_cast<int>(total_send);
            receive_displacements[rank] = static_cast<int>(total_receive);
            total_send += static_cast<std::size_t>(send_counts[rank]);
            total_receive += static_cast<std::size_t>(receive_counts[rank]);
            if (total_send > max_count || total_receive > max_count) error = "combined halo exchange exceeds MPI count limits";
        }
        context.require(error);
        std::vector<GlobalIndex> requested_by_peers;
        try { requested_by_peers.resize(total_send); layout.send_local_indices.resize(total_send); }
        catch (const std::exception& exception) { error = exception.what(); }
        context.require(error);
#ifdef RAIKOU_HAS_MPI
        if (context.ranks > 1)
            checked(MPI_Alltoallv(layout.ghost_global_ids.data(), receive_counts.data(), receive_displacements.data(), MPI_UNSIGNED_LONG_LONG,
                requested_by_peers.data(), send_counts.data(), send_displacements.data(), MPI_UNSIGNED_LONG_LONG, context.communicator));
#endif
        for (std::size_t index = 0; index < requested_by_peers.size(); ++index) {
            const auto id = requested_by_peers[index];
            if (id < owned.row_begin || id >= owned.row_begin + owned.local_rows) error = "peer requested a halo value from the wrong owner";
            else layout.send_local_indices[index] = static_cast<std::size_t>(id - owned.row_begin);
        }
        context.require(error);
    }
};

DistributedHalo::DistributedHalo(RowPartition partition, std::span<const GlobalIndex> requested, const ExecutionOptions& options)
    : impl_(std::make_shared<Impl>(partition, requested, options)) {}
RowPartition DistributedHalo::partition() const noexcept { return impl_->partition; }
const HaloLayout& DistributedHalo::layout() const noexcept { return impl_->layout; }
int DistributedHalo::rank() const noexcept { return impl_->context.rank; }
int DistributedHalo::ranks() const noexcept { return impl_->context.ranks; }
int DistributedHalo::communicator_f() const noexcept {
    return impl_->context.fortran_communicator;
}
std::size_t DistributedHalo::compact_index(GlobalIndex id) const {
    const auto& p = impl_->partition;
    if (id >= p.row_begin && id < p.row_begin + p.local_rows) return static_cast<std::size_t>(id - p.row_begin);
    const auto& ghosts = impl_->layout.ghost_global_ids;
    const auto found = std::lower_bound(ghosts.begin(), ghosts.end(), id);
    if (found == ghosts.end() || *found != id) throw std::out_of_range("global ID is absent from this halo");
    return p.local_rows + static_cast<std::size_t>(found - ghosts.begin());
}
void DistributedHalo::collective_require(const std::string& error) const { impl_->context.require(error); }
double DistributedHalo::global_sum(double value) const { return impl_->context.reduce(value, false); }
double DistributedHalo::global_max(double value) const { return impl_->context.reduce(value, true); }
double DistributedHalo::exclusive_sum(double value) const {
    collective_require(std::isfinite(value) ? "" : "non-finite distributed prefix reduction input");
#ifdef RAIKOU_HAS_MPI
    if (impl_->context.ranks > 1) {
        double result = 0;
        checked(MPI_Exscan(&value, &result, 1, MPI_DOUBLE, MPI_SUM, impl_->context.communicator));
        if (impl_->context.rank == 0) result = 0;
        collective_require(std::isfinite(result) ? "" : "distributed prefix reduction overflow");
        return result;
    }
#endif
    return 0;
}
std::vector<double> DistributedHalo::exchange(std::span<const double> local) const {
    std::lock_guard lock(impl_->mutex);
    collective_require(vector_error(local, impl_->partition.local_rows));
    std::vector<double> packed;
    std::string error;
    try {
        packed.resize(impl_->layout.send_local_indices.size());
        for (std::size_t index = 0; index < packed.size(); ++index) packed[index] = local[impl_->layout.send_local_indices[index]];
    } catch (const std::exception& exception) { error = exception.what(); }
    collective_require(error);
    return exchange_packed_halo(packed);
}
std::vector<double> DistributedHalo::exchange_packed_halo(std::span<const double> packed) const {
    std::lock_guard lock(impl_->mutex);
    collective_require(vector_error(packed, impl_->layout.send_local_indices.size()));
    std::vector<double> received;
    std::string error;
#ifdef RAIKOU_HAS_MPI
    std::vector<MPI_Request> requests;
#endif
    try {
        received.resize(impl_->layout.ghost_global_ids.size());
#ifdef RAIKOU_HAS_MPI
        requests.reserve(2 * static_cast<std::size_t>(impl_->context.ranks));
#endif
    } catch (const std::exception& exception) { error = exception.what(); }
    collective_require(error);
#ifdef RAIKOU_HAS_MPI
    if (impl_->context.ranks > 1) {
        constexpr int tag = 9014;
        for (int rank = 0; rank < impl_->context.ranks; ++rank) {
            const auto r = static_cast<std::size_t>(rank);
            if (impl_->receive_counts[r]) {
                requests.push_back(MPI_REQUEST_NULL);
                checked(MPI_Irecv(received.data() + impl_->receive_displacements[r], impl_->receive_counts[r], MPI_DOUBLE,
                    rank, tag, impl_->context.communicator, &requests.back()));
            }
        }
        for (int rank = 0; rank < impl_->context.ranks; ++rank) {
            const auto r = static_cast<std::size_t>(rank);
            if (impl_->send_counts[r]) {
                requests.push_back(MPI_REQUEST_NULL);
                checked(MPI_Isend(packed.data() + impl_->send_displacements[r], impl_->send_counts[r], MPI_DOUBLE,
                    rank, tag, impl_->context.communicator, &requests.back()));
            }
        }
        if (!requests.empty()) checked(MPI_Waitall(static_cast<int>(requests.size()), requests.data(), MPI_STATUSES_IGNORE));
    }
#endif
    collective_require(vector_error(received, impl_->layout.ghost_global_ids.size()));
    return received;
}

std::vector<double> gather_distributed(const DistributedHalo& halo, std::span<const double> local) {
    halo.collective_require(vector_error(local, halo.partition().local_rows));
    halo.collective_require(halo.partition().global_rows > max_count ? "compatibility gather exceeds MPI count limits" : "");
    std::vector<double> result;
    std::string error;
    try { result.resize(static_cast<std::size_t>(halo.partition().global_rows)); }
    catch (const std::exception& exception) { error = exception.what(); }
    halo.collective_require(error);
#ifdef RAIKOU_HAS_MPI
    if (halo.ranks() > 1) {
        std::vector<int> counts, starts;
        try { counts.resize(static_cast<std::size_t>(halo.ranks())); starts.resize(counts.size()); }
        catch (const std::exception& exception) { error = exception.what(); }
        halo.collective_require(error);
        const int size = static_cast<int>(local.size()), begin = static_cast<int>(halo.partition().row_begin);
        const auto comm = MPI_Comm_f2c(static_cast<MPI_Fint>(halo.communicator_f()));
        checked(MPI_Allgather(&size, 1, MPI_INT, counts.data(), 1, MPI_INT, comm));
        checked(MPI_Allgather(&begin, 1, MPI_INT, starts.data(), 1, MPI_INT, comm));
        checked(MPI_Allgatherv(local.data(), size, MPI_DOUBLE, result.data(), counts.data(), starts.data(), MPI_DOUBLE, comm));
        return result;
    }
#endif
    std::copy(local.begin(), local.end(), result.begin());
    return result;
}

DistributedCsrMatrix partition_replicated(const CsrMatrix& source, RowPartition p) {
    source.validate();
    if (p.global_rows != source.rows || p.row_begin > source.rows || p.local_rows > source.rows - p.row_begin)
        throw std::invalid_argument("compatibility CSR partition does not match global matrix");
    DistributedCsrMatrix result;
    result.global_rows = p.global_rows; result.row_begin = p.row_begin;
    const auto first = source.offsets[static_cast<std::size_t>(p.row_begin)];
    const auto last = source.offsets[static_cast<std::size_t>(p.row_begin) + p.local_rows];
    result.offsets.reserve(p.local_rows + 1);
    result.values.assign(source.values.begin() + static_cast<std::ptrdiff_t>(first), source.values.begin() + static_cast<std::ptrdiff_t>(last));
    result.columns.reserve(last - first);
    for (std::size_t row = 0; row <= p.local_rows; ++row) result.offsets.push_back(source.offsets[static_cast<std::size_t>(p.row_begin) + row] - first);
    for (std::size_t entry = first; entry < last; ++entry) result.columns.push_back(static_cast<GlobalIndex>(source.columns[entry]));
    return result;
}
}
