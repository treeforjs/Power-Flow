#include "raikou/spatial_interface.h"
#include <algorithm>
#include <cmath>
#include <stdexcept>

namespace raikou::spatial::phase_interface {
namespace {
constexpr double qe = 1.602176634e-19;
void require(bool valid, const char* message) { if (!valid) throw std::invalid_argument(message); }
}
ReactionEvaluation evaluate_reaction(const chemistry::Mechanism& mechanism,
    const FaceReaction& binding, const chemistry::State& state,
    const chemistry::Environment& environment, double area,
    double phi_a, double phi_b) {
    require(binding.phase_a != binding.phase_b && area >= 0 && std::isfinite(area) && std::isfinite(phi_a) && std::isfinite(phi_b), "spatial interface: invalid face geometry or phase binding");
    const auto at = std::find_if(mechanism.reactions.begin(), mechanism.reactions.end(), [&](const auto& reaction) { return reaction.id == binding.reaction_id; });
    require(at != mechanism.reactions.end() && !at->basis_interface.empty(), "spatial interface: missing authored area reaction");
    for (const auto* terms : {&at->reactants, &at->products, &at->orders}) for (const auto& term : *terms) {
        const auto& phase = mechanism.species.at(term.species).phase;
        require(phase == binding.phase_a || phase == binding.phase_b, "spatial interface: reaction contains a third phase without a surface owner");
    }
    require(environment.phase_volumes_m3.contains(binding.phase_a) && environment.phase_volumes_m3.contains(binding.phase_b), "spatial interface: missing actual phase volume");
    for (const auto* phase : {&binding.phase_a, &binding.phase_b}) require(environment.phase_volumes_m3.at(*phase) > 0 && std::isfinite(environment.phase_volumes_m3.at(*phase)), "spatial interface: phase volume must be finite and positive");
    auto selected = mechanism; selected.reactions = {*at};
    auto normalized = environment;
    // Area kinetics depends on concentration and temperature, not arbitrary
    // receiving volume. Evaluate unit measure, then scatter physical rates.
    for (const auto& species : mechanism.species) normalized.phase_volumes_m3[species.phase] = 1;
    normalized.interface_areas_m2[at->basis_interface] = 1;
    ReactionEvaluation result; result.own_volume_sources = chemistry::evaluate(selected, state, normalized);
    const auto ns = mechanism.species.size(); result.particle_rates_s.resize(ns); result.particle_jacobian_s_m3.resize(ns * ns);
    for (std::size_t s = 0; s < ns; ++s) {
        const auto& species = mechanism.species[s];
        if (species.phase != binding.phase_a && species.phase != binding.phase_b) continue;
        const double volume = environment.phase_volumes_m3.at(species.phase);
        result.particle_rates_s[s] = result.own_volume_sources.production_rates_m3_s[s] * area;
        result.own_volume_sources.production_rates_m3_s[s] = result.particle_rates_s[s] / volume;
        for (std::size_t t = 0; t < ns; ++t) {
            const auto index = s * ns + t;
            result.particle_jacobian_s_m3[index] = result.own_volume_sources.jacobian_row_major[index] * area;
            result.own_volume_sources.jacobian_row_major[index] = result.particle_jacobian_s_m3[index] / volume;
        }
        const double charge = qe * static_cast<double>(species.charge) * result.particle_rates_s[s];
        if (species.phase == binding.phase_a) result.phase_a_charge_rate_A += charge;
        else result.phase_b_charge_rate_A += charge;
        require(std::isfinite(result.particle_rates_s[s]), "spatial interface: nonfinite transfer rate");
    }
    for (auto& [key, power] : result.own_volume_sources.energy_sources_W_m3) {
        const auto phase = key.substr(0, key.find('/'));
        require(phase == binding.phase_a || phase == binding.phase_b, "spatial interface: energy reservoir needs an owner in one participating phase");
        result.energy_powers_W[key] = power * area;
        power = result.energy_powers_W[key] / environment.phase_volumes_m3.at(phase);
        require(std::isfinite(power) && std::isfinite(result.energy_powers_W[key]), "spatial interface: nonfinite energy transfer");
    }
    result.electric_power_W = -result.phase_a_charge_rate_A * phi_a - result.phase_b_charge_rate_A * phi_b;
    return result;
}
} // namespace raikou::spatial::phase_interface
