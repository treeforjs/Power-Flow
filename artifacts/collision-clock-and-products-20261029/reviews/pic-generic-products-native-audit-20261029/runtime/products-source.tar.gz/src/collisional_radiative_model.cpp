#include "raikou/collisional_radiative_model.h"

namespace raikou {

namespace {
void require_positive(double value, const char* name) {
    if (!std::isfinite(value) || value <= 0.0) {
        throw std::invalid_argument(std::string(name) + " must be finite and positive");
    }
}

void require_nonnegative(double value, const char* name) {
    if (!std::isfinite(value) || value < 0.0) {
        throw std::invalid_argument(std::string(name) + " must be finite and nonnegative");
    }
}
} // namespace

CollisionalRadiativeModel::CollisionalRadiativeModel() {
    init_atomic_data();
}

void CollisionalRadiativeModel::init_atomic_data() {
    // Energy levels (eV) and statistical weights g_n = 2 * n^2
    for (int n = 1; n <= NUM_LEVELS; ++n) {
        level_energies_eV_[n - 1] = IH_EV * (1.0 - 1.0 / (static_cast<double>(n) * static_cast<double>(n)));
        stat_weights_[n - 1] = 2.0 * static_cast<double>(n) * static_cast<double>(n);
    }

    // Initialize transition arrays to zero
    for (int i = 0; i < NUM_LEVELS; ++i) {
        for (int j = 0; j < NUM_LEVELS; ++j) {
            A_einstein_[i][j] = 0.0;
            f_oscillator_[i][j] = 0.0;
        }
    }

    // Einstein spontaneous emission coefficients A_ji (s^-1) from NIST ASD
    // Indices are 0-based: n=1 -> 0, n=2 -> 1, n=3 -> 2, n=4 -> 3, n=5 -> 4
    // Ly-alpha: 2 -> 1 (121.567 nm)
    A_einstein_[1][0] = 4.699e8;
    f_oscillator_[0][1] = 0.4162;

    // Ly-beta: 3 -> 1 (102.572 nm)
    A_einstein_[2][0] = 5.575e7;
    f_oscillator_[0][2] = 0.0791;

    // H-alpha: 3 -> 2 (656.28 nm)
    A_einstein_[2][1] = 4.410e7;
    f_oscillator_[1][2] = 0.6407;

    // Ly-gamma: 4 -> 1 (97.254 nm)
    A_einstein_[3][0] = 1.278e7;
    f_oscillator_[0][3] = 0.0290;

    // H-beta: 4 -> 2 (486.13 nm)
    A_einstein_[3][1] = 8.419e6;
    f_oscillator_[1][3] = 0.1193;

    // Pa-alpha: 4 -> 3 (1875.1 nm)
    A_einstein_[3][2] = 8.986e6;
    f_oscillator_[2][3] = 0.8421;

    // Ly-delta: 5 -> 1 (94.974 nm)
    A_einstein_[4][0] = 4.125e6;
    f_oscillator_[0][4] = 0.0139;

    // H-gamma: 5 -> 2 (434.05 nm)
    A_einstein_[4][1] = 2.530e6;
    f_oscillator_[1][4] = 0.0447;

    // Pa-beta: 5 -> 3 (1281.8 nm)
    A_einstein_[4][2] = 2.201e6;
    f_oscillator_[2][4] = 0.1506;

    // Br-alpha: 5 -> 4 (4051.2 nm)
    A_einstein_[4][3] = 2.699e6;
    f_oscillator_[3][4] = 1.0380;
}

double CollisionalRadiativeModel::compute_lyman_alpha_cross_section(double Tgas_K) {
    require_positive(Tgas_K, "Tgas_K");
    const double T_eff = std::max(Tgas_K, 300.0);
    const double v_th = std::sqrt(2.0 * KB * T_eff / M_H);
    constexpr double lambda_21 = 121.567e-9;
    constexpr double f_12 = 0.4162;
    // sigma_0 = (e^2 * f * lambda) / (4 * eps0 * me * c * sqrt(pi) * v_th)
    const double numerator = QE * QE * f_12 * lambda_21;
    const double denominator = 4.0 * EPS0 * ME * C_LIGHT * std::sqrt(PI) * v_th;
    return numerator / denominator;
}

double CollisionalRadiativeModel::compute_lyman_beta_cross_section(double Tgas_K) {
    require_positive(Tgas_K, "Tgas_K");
    const double T_eff = std::max(Tgas_K, 300.0);
    const double v_th = std::sqrt(2.0 * KB * T_eff / M_H);
    constexpr double lambda_31 = 102.572e-9;
    constexpr double f_13 = 0.0791;
    const double numerator = QE * QE * f_13 * lambda_31;
    const double denominator = 4.0 * EPS0 * ME * C_LIGHT * std::sqrt(PI) * v_th;
    return numerator / denominator;
}

double CollisionalRadiativeModel::compute_optical_depth(double ground_density_m3, double path_length_m, double cross_section_m2) {
    require_nonnegative(ground_density_m3, "ground_density_m3");
    require_nonnegative(path_length_m, "path_length_m");
    require_nonnegative(cross_section_m2, "cross_section_m2");
    return std::max(0.0, ground_density_m3 * path_length_m * cross_section_m2);
}

double CollisionalRadiativeModel::compute_holstein_escape_factor(double tau_0) {
    require_nonnegative(tau_0, "tau_0");
    if (tau_0 <= 1e-4) {
        return 1.0;
    }
    // Continuous Drawin/Holstein rational approximation for Doppler broadening in slab geometry:
    // Matches 1 - tau_0 / sqrt(2) at tau_0 << 1, and 1.6 / (tau_0 * sqrt(pi * ln(tau_0 + 1.2))) at tau_0 >> 1
    const double term_asymp = (tau_0 / 1.6) * std::sqrt(PI * std::log(tau_0 + 1.2));
    const double g_val = 1.0 / (1.0 + term_asymp);
    return std::clamp(g_val, 1e-5, 1.0);
}

// Numerical exponential integral E1(u) approximation
static double exponential_integral_e1(double u) {
    if (u <= 0.0) return 100.0;
    if (u <= 1.0) {
        // Series expansion
        constexpr double a1 = -0.57721566;
        constexpr double a2 =  0.99999193;
        constexpr double a3 = -0.24991055;
        constexpr double a4 =  0.05519968;
        constexpr double a5 = -0.00976004;
        constexpr double a6 =  0.00107857;
        return -std::log(u) + a1 + u * (a2 + u * (a3 + u * (a4 + u * (a5 + u * a6))));
    } else {
        // Rational approximation
        const double num = u * u + 2.334733 * u + 0.250621;
        const double den = u * u + 3.330657 * u + 1.681534;
        return (std::exp(-u) / u) * (num / den);
    }
}

double CollisionalRadiativeModel::excitation_rate(int i, int j, double Te_eV) {
    require_positive(Te_eV, "Te_eV");
    if (i >= j || i < 1 || j > NUM_LEVELS) return 0.0;
    const double Te = std::max(Te_eV, 0.1);
    const double delta_E = IH_EV * (1.0 / (static_cast<double>(i) * static_cast<double>(i)) -
                                     1.0 / (static_cast<double>(j) * static_cast<double>(j)));
    const double u = delta_E / Te;

    // Dipole oscillator approximation
    double f_val = 0.0;
    if (i == 1 && j == 2) f_val = 0.4162;
    else if (i == 1 && j == 3) f_val = 0.0791;
    else if (i == 1 && j == 4) f_val = 0.0290;
    else if (i == 1 && j == 5) f_val = 0.0139;
    else if (i == 2 && j == 3) f_val = 0.6407;
    else if (i == 2 && j == 4) f_val = 0.1193;
    else if (i == 2 && j == 5) f_val = 0.0447;
    else if (i == 3 && j == 4) f_val = 0.8421;
    else if (i == 3 && j == 5) f_val = 0.1506;
    else if (i == 4 && j == 5) f_val = 1.0380;
    else f_val = 0.5 / (static_cast<double>(j - i) * static_cast<double>(j - i));

    const double v_th_e = std::sqrt(2.0 * QE * Te / ME);
    const double prefactor = (8.0 * PI * A0 * A0 / std::sqrt(PI)) * (v_th_e / 2.0) *
                             std::pow(IH_EV / Te, 2.0) * f_val;
    const double bracket = (std::exp(-u) / u) - exponential_integral_e1(u);
    const double j2 = static_cast<double>(j * j);
    const double i2 = static_cast<double>(i * i);
    const double geom = j2 / (j2 - i2);

    return std::max(0.0, prefactor * std::max(bracket, 1e-30) * geom);
}

double CollisionalRadiativeModel::deexcitation_rate(int j, int i, double Te_eV) {
    require_positive(Te_eV, "Te_eV");
    if (j <= i || i < 1 || j > NUM_LEVELS) return 0.0;
    const double Te = std::max(Te_eV, 0.1);
    const double C_ij = excitation_rate(i, j, Te);
    const double delta_E = IH_EV * (1.0 / (static_cast<double>(i) * static_cast<double>(i)) -
                                     1.0 / (static_cast<double>(j) * static_cast<double>(j)));
    const double g_i = 2.0 * static_cast<double>(i * i);
    const double g_j = 2.0 * static_cast<double>(j * j);

    return C_ij * (g_i / g_j) * std::exp(delta_E / Te);
}

double CollisionalRadiativeModel::ionization_rate(int n, double Te_eV) {
    require_positive(Te_eV, "Te_eV");
    if (n < 1 || n > NUM_LEVELS) return 0.0;
    const double Te = std::max(Te_eV, 0.1);
    const double chi_n = IH_EV / (static_cast<double>(n * n));
    const double u = chi_n / Te;

    // Johnson (1972) ionization rate in m^3/s (converted from 1e-13 cm^3/s -> 1e-19 m^3/s)
    const double n_sq = static_cast<double>(n * n);
    return 1.0e-19 * (n_sq / (chi_n * std::sqrt(Te))) * (std::exp(-u) / (u + 1.0));
}

double CollisionalRadiativeModel::radiative_recombination(int n, double Te_eV) {
    require_positive(Te_eV, "Te_eV");
    if (n < 1 || n > NUM_LEVELS) return 0.0;
    const double Te = std::max(Te_eV, 0.1);
    const double n3 = static_cast<double>(n * n * n);
    // Kramers / Seaton formula in m^3/s
    return 5.2e-20 * (1.0 / n3) * std::sqrt(IH_EV / Te);
}

double CollisionalRadiativeModel::three_body_recombination(int n, double Te_eV) {
    require_positive(Te_eV, "Te_eV");
    if (n < 1 || n > NUM_LEVELS) return 0.0;
    const double Te = std::max(Te_eV, 0.1);
    const double S_n = ionization_rate(n, Te);
    const double g_n = 2.0 * static_cast<double>(n * n);
    const double chi_n = IH_EV / (static_cast<double>(n * n));

    // Saha detailed balance
    const double thermal_wavelength_3 = std::pow(H_PLANCK * H_PLANCK / (2.0 * PI * ME * QE * Te), 1.5);
    return S_n * (g_n / 2.0) * thermal_wavelength_3 * std::exp(chi_n / Te);
}

double CollisionalRadiativeModel::h2_dissociation_to_level(int p, double Te_eV) {
    require_positive(Te_eV, "Te_eV");
    if (p < 1 || p > NUM_LEVELS) return 0.0;
    const double Te = std::max(Te_eV, 0.1);
    const double p3 = static_cast<double>(p * p * p);
    // Janev/Reiter 2003 cross-section parameterized rate in m^3/s
    return 1.5e-15 * (8.0 / p3) * std::exp(-14.5 / Te);
}

void CollisionalRadiativeModel::solve_4x4(const double M[4][4], const double b[4], double x[4]) {
    double A[4][5];
    for (int r = 0; r < 4; ++r) {
        for (int c = 0; c < 4; ++c) {
            A[r][c] = M[r][c];
        }
        A[r][4] = b[r];
    }

    // Gaussian elimination with partial pivoting
    for (int i = 0; i < 4; ++i) {
        int max_r = i;
        double max_val = std::abs(A[i][i]);
        for (int r = i + 1; r < 4; ++r) {
            if (std::abs(A[r][i]) > max_val) {
                max_val = std::abs(A[r][i]);
                max_r = r;
            }
        }
        if (max_r != i) {
            for (int c = i; c < 5; ++c) {
                std::swap(A[i][c], A[max_r][c]);
            }
        }

        const double pivot = A[i][i];
        if (std::abs(pivot) < 1e-30) {
            // Degenerate pivot fallback
            x[0] = x[1] = x[2] = x[3] = 0.0;
            return;
        }

        for (int r = i + 1; r < 4; ++r) {
            const double factor = A[r][i] / pivot;
            for (int c = i; c < 5; ++c) {
                A[r][c] -= factor * A[i][c];
            }
        }
    }

    // Back substitution
    for (int i = 3; i >= 0; --i) {
        double sum = A[i][4];
        for (int c = i + 1; c < 4; ++c) {
            sum -= A[i][c] * x[c];
        }
        x[i] = sum / A[i][i];
    }
}

CollisionalRadiativeModel::CRRadianceResult CollisionalRadiativeModel::evaluate(const PlasmaState& state) const {
    require_positive(state.Te_eV, "Te_eV");
    require_positive(state.Tgas_K, "Tgas_K");
    require_nonnegative(state.ne_m3, "ne_m3");
    require_nonnegative(state.nH_ground_m3, "nH_ground_m3");
    require_nonnegative(state.nH2_m3, "nH2_m3");
    require_nonnegative(state.path_length_m, "path_length_m");
    CRRadianceResult res;
    res.populations_m3[0] = state.nH_ground_m3;

    // Optical depth and escape factor for Lyman lines
    const double sigma_ly_a = compute_lyman_alpha_cross_section(state.Tgas_K);
    const double sigma_ly_b = compute_lyman_beta_cross_section(state.Tgas_K);
    res.tau_0_lyman_alpha = compute_optical_depth(state.nH_ground_m3, state.path_length_m, sigma_ly_a);
    res.escape_factor_lyman_alpha = compute_holstein_escape_factor(res.tau_0_lyman_alpha);
    res.tau_0_lyman_beta = compute_optical_depth(state.nH_ground_m3, state.path_length_m, sigma_ly_b);
    res.escape_factor_lyman_beta = compute_holstein_escape_factor(res.tau_0_lyman_beta);

    const double ne = std::max(state.ne_m3, 1.0);
    const double Te = std::max(state.Te_eV, 0.1);

    // Build 4x4 QSS rate matrix for excited states n = 2, 3, 4, 5
    // Row r corresponds to state p = r + 2 (p = 2, 3, 4, 5)
    double M[4][4] = {{0.0}};
    double b[4] = {0.0};

    for (int r = 0; r < 4; ++r) {
        const int p = r + 2; // Level p in 1-based indexing (2, 3, 4, 5)

        // Loss terms from state p (Diagonal M[r][r])
        double total_loss = 0.0;

        // 1. Spontaneous radiative decay to all lower states q < p
        for (int q = 1; q < p; ++q) {
            double A_pq = A_einstein_[p - 1][q - 1];
            double escape = 1.0;
            if (q == 1) {
                if (p == 2) escape = res.escape_factor_lyman_alpha;
                else if (p == 3) escape = res.escape_factor_lyman_beta;
            }
            total_loss += A_pq * escape;
        }

        // 2. Collisional de-excitation to all lower states q < p
        for (int q = 1; q < p; ++q) {
            total_loss += ne * deexcitation_rate(p, q, Te);
        }

        // 3. Collisional excitation to all higher states q > p
        for (int q = p + 1; q <= NUM_LEVELS; ++q) {
            total_loss += ne * excitation_rate(p, q, Te);
        }

        // 4. Electron-impact ionization from state p
        total_loss += ne * ionization_rate(p, Te);

        M[r][r] = total_loss;

        // Gain terms from other excited states q in {2, 3, 4, 5} (Off-diagonal -M[r][c])
        for (int c = 0; c < 4; ++c) {
            if (c == r) continue;
            const int q = c + 2;
            double gain_from_q = 0.0;
            if (q < p) {
                // Excitation from lower excited state q to p
                gain_from_q += ne * excitation_rate(q, p, Te);
            } else {
                // De-excitation + Radiative decay from higher excited state q to p
                double A_qp = A_einstein_[q - 1][p - 1];
                // For p >= 2, visible/IR transitions are optically thin
                gain_from_q += A_qp + ne * deexcitation_rate(q, p, Te);
            }
            M[r][c] = -gain_from_q;
        }

        // Source term b[r] from ground state n=1, recombination, and H2 dissociation
        double source = 0.0;
        // Ground-state excitation: e + H(1) -> e + H(p)
        source += ne * state.nH_ground_m3 * excitation_rate(1, p, Te);
        // Radiative & Three-body recombination from H+ (assume quasi-neutral plasma n_i ~ n_e)
        source += ne * ne * radiative_recombination(p, Te);
        source += ne * ne * ne * three_body_recombination(p, Te);
        // H2 electron-impact dissociation
        source += ne * state.nH2_m3 * h2_dissociation_to_level(p, Te);

        b[r] = source;
    }

    double x[4] = {0.0};
    solve_4x4(M, b, x);

    for (int r = 0; r < 4; ++r) {
        res.populations_m3[r + 1] = std::max(0.0, x[r]);
    }

    // Compute Line Radiances: I = (h * nu / 4pi) * A_ji * Lambda_ji * n_j * L
    const double L = state.path_length_m;

    // Lyman-alpha (2 -> 1, 121.567 nm, 10.204 eV)
    constexpr double nu_21 = C_LIGHT / 121.567e-9;
    res.lyman_alpha_radiance_W_m2_sr = (H_PLANCK * nu_21 / (4.0 * PI)) *
                                      A_einstein_[1][0] * res.escape_factor_lyman_alpha *
                                      res.populations_m3[1] * L;

    // Lyman-beta (3 -> 1, 102.572 nm, 12.094 eV)
    constexpr double nu_31 = C_LIGHT / 102.572e-9;
    res.lyman_beta_radiance_W_m2_sr = (H_PLANCK * nu_31 / (4.0 * PI)) *
                                     A_einstein_[2][0] * res.escape_factor_lyman_beta *
                                     res.populations_m3[2] * L;

    // Balmer-alpha (3 -> 2, 656.28 nm, 1.889 eV)
    constexpr double nu_32 = C_LIGHT / 656.28e-9;
    res.balmer_alpha_radiance_W_m2_sr = (H_PLANCK * nu_32 / (4.0 * PI)) *
                                       A_einstein_[2][1] * 1.0 *
                                       res.populations_m3[2] * L;

    // Balmer-beta (4 -> 2, 486.13 nm, 2.550 eV)
    constexpr double nu_42 = C_LIGHT / 486.13e-9;
    res.balmer_beta_radiance_W_m2_sr = (H_PLANCK * nu_42 / (4.0 * PI)) *
                                      A_einstein_[3][1] * 1.0 *
                                      res.populations_m3[3] * L;

    // Molecular Lyman band proxy (~160 nm, B1Sigma_u+ -> X1Sigma_g+)
    constexpr double nu_mol = C_LIGHT / 160.8e-9;
    const double K_mol_ex = 8.0e-16 * std::exp(-11.5 / Te); // Effective excitation rate m^3/s
    res.molecular_lyman_proxy_W_m2_sr = (H_PLANCK * nu_mol / (4.0 * PI)) *
                                       ne * state.nH2_m3 * K_mol_ex * L;

    const std::array<double, 9> diagnostics{
        res.lyman_alpha_radiance_W_m2_sr, res.lyman_beta_radiance_W_m2_sr,
        res.balmer_alpha_radiance_W_m2_sr, res.balmer_beta_radiance_W_m2_sr,
        res.molecular_lyman_proxy_W_m2_sr, res.tau_0_lyman_alpha,
        res.escape_factor_lyman_alpha, res.tau_0_lyman_beta,
        res.escape_factor_lyman_beta};
    const auto finite = [](double value) { return std::isfinite(value); };
    if (!std::all_of(res.populations_m3.begin(), res.populations_m3.end(), finite) ||
        !std::all_of(diagnostics.begin(), diagnostics.end(), finite)) {
        throw std::overflow_error("CR evaluation produced a non-finite result");
    }

    return res;
}

CollisionalRadiativeModel::FitResult CollisionalRadiativeModel::fit_vuv_shot(
    double measured_ly_alpha_radiance,
    double measured_ly_alpha_sigma,
    double measured_molecular_radiance,
    double measured_molecular_sigma,
    double path_length_m,
    double fixed_Tgas_K,
    const FitPriors& priors
) const {
    FitResult res;

    require_nonnegative(measured_ly_alpha_radiance, "measured_ly_alpha_radiance");
    require_positive(measured_ly_alpha_sigma, "measured_ly_alpha_sigma");
    require_nonnegative(measured_molecular_radiance, "measured_molecular_radiance");
    require_positive(measured_molecular_sigma, "measured_molecular_sigma");
    require_positive(path_length_m, "path_length_m");
    require_positive(fixed_Tgas_K, "fixed_Tgas_K");
    auto require_bounds = [](double lower, double upper, const char* name) {
        require_positive(lower, name);
        require_positive(upper, name);
        if (lower > upper) throw std::invalid_argument(std::string(name) + " bounds are reversed");
    };
    require_bounds(priors.min_Te_eV, priors.max_Te_eV, "Te_eV");
    require_bounds(priors.min_ne_m3, priors.max_ne_m3, "ne_m3");
    require_bounds(priors.min_nH_m3, priors.max_nH_m3, "nH_m3");
    require_bounds(priors.min_nH2_m3, priors.max_nH2_m3, "nH2_m3");

    // Bounds in log10 space: [log10_Te, log10_ne, log10_nH, log10_nH2]
    const double low_log_Te = std::log10(priors.min_Te_eV);
    const double high_log_Te = std::log10(priors.max_Te_eV);
    const double low_log_ne = std::log10(priors.min_ne_m3);
    const double high_log_ne = std::log10(priors.max_ne_m3);
    const double low_log_nH = std::log10(priors.min_nH_m3);
    const double high_log_nH = std::log10(priors.max_nH_m3);
    const double low_log_nH2 = std::log10(priors.min_nH2_m3);
    const double high_log_nH2 = std::log10(priors.max_nH2_m3);

    // Initial parameter guess
    double current[4] = {
        0.5 * (low_log_Te + high_log_Te),
        0.5 * (low_log_ne + high_log_ne),
        0.5 * (low_log_nH + high_log_nH),
        0.5 * (low_log_nH2 + high_log_nH2)
    };

    auto evaluate_chi2 = [&](const double p[4]) -> double {
        PlasmaState st;
        st.Te_eV = std::pow(10.0, std::clamp(p[0], low_log_Te, high_log_Te));
        st.ne_m3 = std::pow(10.0, std::clamp(p[1], low_log_ne, high_log_ne));
        st.nH_ground_m3 = std::pow(10.0, std::clamp(p[2], low_log_nH, high_log_nH));
        st.nH2_m3 = std::pow(10.0, std::clamp(p[3], low_log_nH2, high_log_nH2));
        st.Tgas_K = fixed_Tgas_K;
        st.path_length_m = path_length_m;

        CRRadianceResult sim = evaluate(st);

        // Chi^2 on log-radiance to span orders of magnitude stably
        const double log_meas_la = std::log10(std::max(measured_ly_alpha_radiance, 1e-12));
        const double log_sim_la = std::log10(std::max(sim.lyman_alpha_radiance_W_m2_sr, 1e-12));
        const double sig_la = std::max(0.05, measured_ly_alpha_sigma / std::max(measured_ly_alpha_radiance, 1e-12));

        const double log_meas_mol = std::log10(std::max(measured_molecular_radiance, 1e-12));
        const double log_sim_mol = std::log10(std::max(sim.molecular_lyman_proxy_W_m2_sr, 1e-12));
        const double sig_mol = std::max(0.05, measured_molecular_sigma / std::max(measured_molecular_radiance, 1e-12));

        double chi2 = std::pow((log_meas_la - log_sim_la) / sig_la, 2.0) +
                      std::pow((log_meas_mol - log_sim_mol) / sig_mol, 2.0);

        // Regularization penalty for extreme ionization fraction drift
        const double log_ratio = std::log10(st.ne_m3) - std::log10(st.nH_ground_m3);
        chi2 += 0.01 * (log_ratio * log_ratio);

        return chi2;
    };

    // Nelder-Mead Simplex Minimization
    constexpr int N = 4;
    double simplex[N + 1][N];
    double f_vals[N + 1];

    for (int i = 0; i < N; ++i) simplex[0][i] = current[i];
    f_vals[0] = evaluate_chi2(simplex[0]);

    for (int j = 1; j <= N; ++j) {
        for (int i = 0; i < N; ++i) {
            simplex[j][i] = simplex[0][i] + ((i == j - 1) ? 0.35 : 0.0);
        }
        f_vals[j] = evaluate_chi2(simplex[j]);
    }

    int iter = 0;
    constexpr int max_iter = 200;
    while (iter < max_iter) {
        iter++;
        // Order simplex vertices
        int b_idx = 0, w_idx = 0;
        for (int i = 1; i <= N; ++i) {
            if (f_vals[i] < f_vals[b_idx]) b_idx = i;
            if (f_vals[i] > f_vals[w_idx]) w_idx = i;
        }

        if (f_vals[w_idx] - f_vals[b_idx] < 1e-5) break;

        // Centroid of all except worst
        double centroid[N] = {0.0};
        for (int i = 0; i <= N; ++i) {
            if (i == w_idx) continue;
            for (int k = 0; k < N; ++k) centroid[k] += simplex[i][k] / static_cast<double>(N);
        }

        // Reflection
        double reflected[N];
        for (int k = 0; k < N; ++k) reflected[k] = 2.0 * centroid[k] - simplex[w_idx][k];
        double f_refl = evaluate_chi2(reflected);

        if (f_refl < f_vals[b_idx]) {
            // Expansion
            double expanded[N];
            for (int k = 0; k < N; ++k) expanded[k] = 3.0 * centroid[k] - 2.0 * simplex[w_idx][k];
            double f_exp = evaluate_chi2(expanded);
            if (f_exp < f_refl) {
                for (int k = 0; k < N; ++k) simplex[w_idx][k] = expanded[k];
                f_vals[w_idx] = f_exp;
            } else {
                for (int k = 0; k < N; ++k) simplex[w_idx][k] = reflected[k];
                f_vals[w_idx] = f_refl;
            }
        } else if (f_refl < f_vals[w_idx]) {
            for (int k = 0; k < N; ++k) simplex[w_idx][k] = reflected[k];
            f_vals[w_idx] = f_refl;
        } else {
            // Contraction
            double contracted[N];
            for (int k = 0; k < N; ++k) contracted[k] = 0.5 * (centroid[k] + simplex[w_idx][k]);
            double f_cont = evaluate_chi2(contracted);
            if (f_cont < f_vals[w_idx]) {
                for (int k = 0; k < N; ++k) simplex[w_idx][k] = contracted[k];
                f_vals[w_idx] = f_cont;
            } else {
                // Shrink
                for (int i = 0; i <= N; ++i) {
                    if (i == b_idx) continue;
                    for (int k = 0; k < N; ++k) {
                        simplex[i][k] = 0.5 * (simplex[i][k] + simplex[b_idx][k]);
                    }
                    f_vals[i] = evaluate_chi2(simplex[i]);
                }
            }
        }
    }

    int best = 0;
    for (int i = 1; i <= N; ++i) {
        if (f_vals[i] < f_vals[best]) best = i;
    }

    // Return the same bounded state that was actually scored by the objective.
    res.Te_eV = std::clamp(std::pow(10.0, std::clamp(simplex[best][0], low_log_Te, high_log_Te)), priors.min_Te_eV, priors.max_Te_eV);
    res.ne_m3 = std::clamp(std::pow(10.0, std::clamp(simplex[best][1], low_log_ne, high_log_ne)), priors.min_ne_m3, priors.max_ne_m3);
    res.nH_m3 = std::clamp(std::pow(10.0, std::clamp(simplex[best][2], low_log_nH, high_log_nH)), priors.min_nH_m3, priors.max_nH_m3);
    res.nH2_m3 = std::clamp(std::pow(10.0, std::clamp(simplex[best][3], low_log_nH2, high_log_nH2)), priors.min_nH2_m3, priors.max_nH2_m3);
    res.chi2_reduced = f_vals[best] / 2.0;
    res.converged = (res.chi2_reduced < 5.0);
    res.iterations = iter;

    // Approximate parameter standard errors from simplex span
    double span[4] = {0.0};
    for (int k = 0; k < N; ++k) {
        double min_val = simplex[0][k], max_val = simplex[0][k];
        for (int i = 1; i <= N; ++i) {
            min_val = std::min(min_val, simplex[i][k]);
            max_val = std::max(max_val, simplex[i][k]);
        }
        span[k] = (max_val - min_val) * 0.5;
    }

    res.Te_err_eV = res.Te_eV * std::max(0.1, span[0] * 2.302585);
    res.ne_err_m3 = res.ne_m3 * std::max(0.15, span[1] * 2.302585);
    res.nH_err_m3 = res.nH_m3 * std::max(0.15, span[2] * 2.302585);
    res.nH2_err_m3 = res.nH2_m3 * std::max(0.15, span[3] * 2.302585);

    // Final evaluated opacity
    PlasmaState final_state;
    final_state.Te_eV = res.Te_eV;
    final_state.ne_m3 = res.ne_m3;
    final_state.nH_ground_m3 = res.nH_m3;
    final_state.nH2_m3 = res.nH2_m3;
    final_state.Tgas_K = fixed_Tgas_K;
    final_state.path_length_m = path_length_m;

    CRRadianceResult final_rad = evaluate(final_state);
    res.tau_0_lyman_alpha = final_rad.tau_0_lyman_alpha;
    res.escape_factor_lyman_alpha = final_rad.escape_factor_lyman_alpha;

    return res;
}

} // namespace raikou
