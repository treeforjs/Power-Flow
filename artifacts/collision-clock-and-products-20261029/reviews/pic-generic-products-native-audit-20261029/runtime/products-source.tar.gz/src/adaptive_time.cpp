#include "raikou/adaptive_time.h"
#include <algorithm>
#include <cmath>
#include <limits>
#include <stdexcept>
#include <string>

namespace raikou::time {
namespace {
[[noreturn]] void invalid(const std::string& message) { throw std::invalid_argument("adaptive time: " + message); }
void validate_order(int order) { if (order != 1 && order != 2) invalid("BDF order must be 1 or 2"); }
double full_multiplier(int order, double ratio) {
    validate_order(order);
    if (order == 1) return 2;
    if (!(ratio > 0 && std::isfinite(ratio))) invalid("timestep ratio must be finite and positive");
    const double x = ratio <= 1 ? ratio / (1 + ratio) : 1 / (1 + 1 / ratio);
    const double y = 1 / (1 + ratio);
    return 12 / (6*x*x*x + 21*x*x*y + 22*x*y*y + 8*y*y*y);
}
} // namespace

BdfWeights coefficients(double dt, double previous_dt, int order) {
    validate_order(order);
    if (!(dt > 0 && std::isfinite(dt) && previous_dt >= 0 && std::isfinite(previous_dt))) invalid("timesteps must be finite with dt>0 and previous_dt>=0");
    if (order == 1) return {};
    if (!(previous_dt > 0)) invalid("BDF2 requires positive accepted history timestep");
    const double ratio = dt / previous_dt;
    if (!(ratio > 0 && std::isfinite(ratio))) invalid("BDF2 timestep ratio is outside the representable range");
    const double fraction = ratio <= 1 ? ratio / (1 + ratio) : 1 / (1 + 1 / ratio);
    return {1 + fraction, -(1 + ratio), ratio * fraction, 2};
}

ErrorEstimate estimate_error(std::span<const double> full, std::span<const double> refined,
    std::span<const double> atol, double rtol, int order, double ratio) {
    if (refined.size() != full.size()) invalid("full/refined states must have matching sizes");
    if (atol.size() != 1 && atol.size() != full.size()) invalid("absolute tolerances must be scalar or match state size");
    if (!(rtol >= 0 && std::isfinite(rtol))) invalid("relative tolerance must be finite and nonnegative");
    for (double tolerance : atol) if (!(tolerance > 0 && std::isfinite(tolerance))) invalid("absolute tolerances must be finite and positive");
    ErrorEstimate result; result.full_error_multiplier = full_multiplier(order, ratio);
    result.component_errors.resize(full.size());
    for (std::size_t i = 0; i < full.size(); ++i) {
        if (!std::isfinite(full[i]) || !std::isfinite(refined[i])) invalid("candidate states must be finite");
        const double scale = atol[atol.size() == 1 ? 0 : i] + rtol * std::max(std::abs(full[i]), std::abs(refined[i]));
        const double error = result.full_error_multiplier * (full[i] - refined[i]);
        if (!(scale > 0 && std::isfinite(scale)) || !std::isfinite(error)) invalid("error estimate or tolerance scale overflow");
        result.component_errors[i] = error;
        const double normalized = std::abs(error) / scale;
        if (!std::isfinite(normalized)) invalid("normalized error overflow");
        result.normalized_error = std::max(result.normalized_error, normalized);
    }
    return result;
}

double recommended_factor(double error, int order, bool accepted, double minimum, double maximum, double safety) {
    validate_order(order);
    if (!(minimum > 0 && minimum < 1 && std::isfinite(minimum) && maximum >= 1 && std::isfinite(maximum) &&
        safety > 0 && safety < 1 && std::isfinite(safety))) invalid("invalid step controller bounds or safety factor");
    if (std::isnan(error) || error < 0 || (accepted && !std::isfinite(error))) invalid("error must be nonnegative and finite for an accepted trial");
    if (!std::isfinite(error)) return minimum;
    const double factor = error > 0 ? safety * std::pow(error, -1. / (order + 1)) : maximum;
    const double upper = accepted ? maximum : std::max(minimum, .5);
    return std::clamp(factor, minimum, upper);
}
} // namespace raikou::time
