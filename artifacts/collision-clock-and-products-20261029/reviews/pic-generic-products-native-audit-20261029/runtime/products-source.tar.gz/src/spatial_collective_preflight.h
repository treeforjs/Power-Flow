#pragma once
#include "raikou/spatial_distributed.h"
#include "raikou/spherical_harmonics.h"
#include "legendre_admissibility.h"
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <limits>
#include <stdexcept>

namespace raikou::spatial::detail {
// Call once after constructing DofLayout, before checkpoint/solver branches.
// MPI enablement/communicator validity are host entry-point preconditions.
// Callbacks, custom owned intervals and local numerical values are never hashed.
inline void preflight_spatial_distributed(const DistributedProblem& input, const partition::DofLayout& layout) {
    const auto& control = layout.control_halo();
    std::string error, shared;
    const auto require = [](bool ok, const std::string& message) { if (!ok) throw std::invalid_argument("owned spatial preflight: " + message); };
    const auto grid_json = [](const kinetics::EedfGrid& g) { return Json{g.cells,g.max_energy_ev,g.power,g.legendre_terms}; };
    const auto execution_json = [](const backend::ExecutionOptions& e) {
        // Device ordinals and communicator handles may legitimately differ.
        return Json{{"device",e.device},{"mpi",e.mpi},{"tolerance",e.tolerance},
            {"iterations",e.max_iterations},{"restart",e.restart},{"preconditioner",e.preconditioner}};
    };
    const auto finite_json = [&](const auto& self, const Json& j) -> void {
        if (j.is_number_float()) require(std::isfinite(j.get<double>()), "nonfinite shared metadata");
        else if (j.is_structured()) for (const auto& value : j) self(self,value);
    };
    try {
        require(static_cast<bool>(input.model),"physical model is required");
        const auto& p = *input.model; const auto& o = p.options;
        const auto positive = [&](double value) { require(value>0&&std::isfinite(value),"positive finite tolerance/time-step required"); };
        positive(o.time_step_s);positive(o.minimum_time_step_s);require(o.minimum_time_step_s<=o.time_step_s,"minimum time-step exceeds maximum");
        require(o.end_time_s>=0&&std::isfinite(o.end_time_s),"end time must be finite and nonnegative");
        for(double value:{o.relative_tolerance,o.absolute_density_tolerance_m3,o.potential_tolerance_V,o.surface_charge_tolerance_C_m2,
            o.circuit_charge_tolerance_C,o.temporal_relative_tolerance,o.temporal_density_tolerance_m3,o.temporal_temperature_tolerance_K,
            o.temporal_potential_tolerance_V,o.temporal_surface_charge_tolerance_C_m2})positive(value);
        require(o.maximum_newton_iterations>0&&o.maximum_steps>0&&o.linear_restart>0&&o.linear_max_iterations>0,"iteration budgets must be positive");
        require(o.device=="cpu"||o.device=="cuda","unknown execution device");
        require(o.cuda_device>=-1,"invalid CUDA ordinal");
        require(o.preconditioner=="auto"||o.preconditioner=="jacobi"||o.preconditioner=="block_ilu0","unknown preconditioner");
        require(o.nonorthogonal_correction_limiter>=0&&std::isfinite(o.nonorthogonal_correction_limiter),"invalid nonorthogonal limiter");
        require(p.circuit.series_resistance_ohm>=0&&std::isfinite(p.circuit.series_resistance_ohm)&&p.circuit.external_capacitance_F>=0&&std::isfinite(p.circuit.external_capacitance_F),"invalid circuit coefficients");
        chemistry::validate_environment(p.environment);
        Json j{{"mechanism",p.mechanism.to_json()},{"environment",{{"gas",p.environment.gas_temperature_K},{"liquid",p.environment.liquid_temperature_K},
            {"electron",p.environment.electron_temperature_eV},{"electron_rates",p.environment.electron_rates},{"parameters",p.environment.parameters},
            {"volumes",p.environment.phase_volumes_m3},{"areas",p.environment.interface_areas_m2}}},
            {"mesh",{{"dimension",p.mesh.dimension},{"axisymmetric",p.mesh.axisymmetric},{"shape",p.mesh.shape},{"extent",p.mesh.extent_m},{"nodes",p.mesh.nodes_m}}},
            {"permittivity",p.permittivity_F_m},{"initial_densities",p.initial_densities_m3},{"phase_fractions",p.phase_fractions},
            {"electron_mode",p.electron_mode},{"electron_axis",p.electron_field_axis},{"initial_electron_energy",p.initial_electron_mean_energy_eV},
            {"circuit",{p.circuit.enabled,p.circuit.driven_side,p.circuit.source_voltage_V,p.circuit.initial_voltage_V,p.circuit.series_resistance_ohm,p.circuit.external_capacitance_F}},
            {"options",{{"dt",o.time_step_s},{"minimum_dt",o.minimum_time_step_s},{"end",o.end_time_s},{"rtol",o.relative_tolerance},
                {"atol",o.absolute_density_tolerance_m3},{"phi",o.potential_tolerance_V},{"sigma",o.surface_charge_tolerance_C_m2},{"circuit",o.circuit_charge_tolerance_C},
                {"newton",o.maximum_newton_iterations},{"steps",o.maximum_steps},{"mpi",o.mpi},{"bdf2",o.bdf2},
                {"adaptive",input.adaptive_time.value_or(o.adaptive_time)},{"temporal_rtol",o.temporal_relative_tolerance},
                {"temporal_density",o.temporal_density_tolerance_m3},{"temporal_temperature",o.temporal_temperature_tolerance_K},
                {"temporal_phi",o.temporal_potential_tolerance_V},{"temporal_sigma",o.temporal_surface_charge_tolerance_C_m2},
                {"device",o.device},{"preconditioner",o.preconditioner},{"restart",o.linear_restart},{"linear_iterations",o.linear_max_iterations},
                {"nonorthogonal_limiter",o.nonorthogonal_correction_limiter}}},{"checkpoint",input.checkpoint.has_value()},
            {"legacy_checkpoint",p.initial_checkpoint.has_value()}};
        j["mesh"]["cells"]=Json::array();for(const auto& cell:p.mesh.cells)j["mesh"]["cells"].push_back({cell.type,cell.nodes});
        j["mesh"]["boundaries"]=Json::array();for(const auto& face:p.mesh.boundary_faces)j["mesh"]["boundaries"].push_back({face.side,face.nodes});
        j["transport"]=Json::array();for(const auto& t:p.transport)j["transport"].push_back({t.mobility_m2_V_s,t.diffusion_m2_s});
        j["boundaries"]=Json::array();
        for(const auto& b:p.boundaries){Json value{{"kind",static_cast<int>(b.kind)},{"potential",b.potential_V},{"absorbing",b.absorbing},
            {"capacitance",b.capacitance_F_m2},{"sigma",b.initial_surface_charge_C_m2},{"kinetic",b.kinetic_electrons},{"secondary_energy",b.secondary_energy_eV}};
            value["sheaths"]=Json::array();for(const auto& sheath:b.sheaths)value["sheaths"].push_back({sheath.species,sheath.model,sheath.temperature_eV,sheath.electron_temperature_eV,sheath.transmission});
            value["secondary"]=Json::array();for(const auto& emission:b.secondary_emission)value["secondary"].push_back({emission.incident_species,emission.emitted_species,emission.yield});
            value["incoming"]=b.incoming_electrons?kinetics::spherical_state_to_json(*b.incoming_electrons):Json(nullptr);j["boundaries"].push_back(std::move(value));}
        const auto phase_json=[](const Thermal::Phase& phase){return Json{{"capacity",phase.heat_capacity_J_m3_K},{"conductivity",phase.conductivity_W_m_K},
            {"initial",phase.initial_temperature_K},{"heating",phase.heating_W_m3},{"reservoirs",phase.heat_reservoirs}};};
        j["thermal"]={{"enabled",p.thermal.enabled},{"common",phase_json({p.thermal.heat_capacity_J_m3_K,p.thermal.conductivity_W_m_K,p.thermal.initial_temperature_K,p.thermal.heating_W_m3,p.thermal.heat_reservoirs})},
            {"joule",p.thermal.joule_species},{"eedf_elastic",p.thermal.use_eedf_elastic_heating},{"phases",Json::object()}};
        for(const auto& [name,phase]:p.thermal.phases)j["thermal"]["phases"][name]=phase_json(phase);
        j["radiation"]=Json::array();for(const auto& group:p.radiation){Json value{{"id",group.id},{"energy",group.photon_energy_eV},{"speed",group.speed_m_s},{"diffusion",group.diffusion_m2_s},
            {"opacity",group.absorption_m1},{"phase_opacity",group.absorption_m1_by_phase},{"initial",group.initial_density_m3},{"emission",group.emission_W_m3},{"reservoir",group.energy_reservoir},{"escape",group.escaping_sides},{"absorbers",Json::array()}};
            for(const auto& absorber:group.absorbers){value["absorbers"].push_back({absorber.reaction_id,absorber.cross_section_m2});}
            j["radiation"].push_back(std::move(value));}
        j["face_reactions"]=Json::array();for(const auto& r:p.face_reactions)j["face_reactions"].push_back({r.reaction_id,r.phase_a,r.phase_b,r.electrical_work_to_phase});
        j["heat_transfer"]=Json::array();for(const auto& r:p.interface_heat_transfer)j["heat_transfer"].push_back({r.phase_a,r.phase_b,r.conductance_W_m2_K});
        j["phase_contacts"]=Json::array();for(const auto& [face,contact]:p.electron_phase_contacts)j["phase_contacts"].push_back({face,static_cast<int>(contact.boundary.kind),
            contact.boundary.incoming?kinetics::spherical_state_to_json(*contact.boundary.incoming):Json(nullptr),contact.absorbed_species,contact.energy_to_phase});
        j["electron_closure"]=nullptr;
        if(p.electron_closure){const auto& closure=*p.electron_closure;const auto& c=closure.conditions;
            require(closure.grid.cells>=16&&closure.grid.cells<=6000&&closure.grid.legendre_terms>=2&&closure.grid.legendre_terms<=30&&
                closure.grid.max_energy_ev>0&&std::isfinite(closure.grid.max_energy_ev)&&closure.grid.power>=1&&closure.grid.power<=4,
                "invalid electron closure grid");
            Json value{{"grid",grid_json(closure.grid)},{"species",closure.electron_species},{"targets",closure.targets},{"gas_density",closure.gas_density_m3},{"strict",closure.strict_event_mapping},
                {"conditions",{c.reduced_field_td,c.gas_temperature_k,c.gas_density_m3,c.electron_fraction,c.ion_fraction}},{"fractions",c.fractions},{"sharing",static_cast<int>(c.sharing)},
                {"growth",c.temporal_growth},{"execution",execution_json(c.execution)},{"processes",Json::array()}};
            for(const auto& process:closure.processes)value["processes"].push_back({static_cast<int>(process.kind),process.target,process.product,process.label,process.mass_ratio,
                process.threshold_ev,process.weight_ratio,static_cast<int>(process.group),process.energy_ev,process.cross_section_m2,static_cast<int>(process.angular),process.integral_cross_section_m2});
            j["electron_closure"]=std::move(value);
        }
        if(input.checkpoint){const auto& cp=*input.checkpoint;const auto expected=layout.row_partition();const auto cells=layout.owned_cells();
            const auto close=[](double a,double b){return std::abs(a-b)<=64*std::numeric_limits<double>::epsilon()*std::max({std::abs(a),std::abs(b),1e-300});};
            require(cp.previous_step_s>=0&&std::isfinite(cp.previous_step_s)&&cp.next_step_s>0&&std::isfinite(cp.next_step_s),"invalid checkpoint step history");
            require(cp.state.time_s>=0&&cp.state.time_s<=o.end_time_s&&std::isfinite(cp.state.time_s),"invalid checkpoint current clock");
            require(cp.previous_state.time_s>=0&&cp.previous_state.time_s<=cp.state.time_s&&std::isfinite(cp.previous_state.time_s),"invalid checkpoint previous clock");
            require(cp.accepted_steps==0?cp.previous_step_s==0:cp.previous_step_s>0,"checkpoint step count and previous step disagree");
            require(close(cp.previous_state.time_s,cp.state.time_s-cp.previous_step_s),"checkpoint previous clock differs from BDF history");
            const bool spherical=p.electron_closure&&p.electron_mode=="transient_spherical";
            const bool axial=p.electron_closure&&p.electron_mode=="transient_boltzmann";
            const auto electron=spherical||axial?p.mechanism.species_index(p.electron_closure->electron_species):0;
            for(const auto* state:{&cp.state,&cp.previous_state}){
                require(state->rows.global_rows==expected.global_rows&&state->rows.row_begin==expected.row_begin&&state->rows.local_rows==expected.local_rows&&state->owned_values.size()==expected.local_rows,"checkpoint row ownership/shape differs from layout");
                require(state->cells.begin==cells.begin&&state->cells.count==cells.count,"checkpoint cell ownership differs from layout");
                for(double value:state->owned_values)require(std::isfinite(value),"nonfinite checkpoint owned value");
                const auto owned_value=[&](std::size_t cell,std::size_t component){return state->owned_values[static_cast<std::size_t>(layout.cell_dof(cell,component)-expected.row_begin)];};
                for(std::size_t cell=cells.begin;cell<cells.begin+cells.count;++cell){
                    for(std::size_t species=0;species<p.mechanism.species.size();++species){const auto& definition=p.mechanism.species[species];const double value=owned_value(cell,species);
                        if(definition.nonnegative)require(value>=0,"negative checkpoint nonnegative species");
                        if(const auto phase=p.phase_fractions.find(definition.phase);phase!=p.phase_fractions.end()){
                            require(phase->second.size()==1||phase->second.size()==layout.cells(),"explicit phase fraction shape differs from mesh");
                            if(phase->second[phase->second.size()==1?0:cell]==0)require(value==0,"checkpoint species must vanish in an absent phase");
                        }
                    }
                    for(std::size_t group=0;group<p.radiation.size();++group)require(owned_value(cell,layout.photon_component(group))>=0,"negative checkpoint photon density");
                    for(std::size_t component=p.mechanism.species.size()+1+p.radiation.size();component<layout.components();++component)
                        require(owned_value(cell,component)>0,"checkpoint thermal temperature must be positive");
                }
                require(state->spherical_electrons.size()==(spherical?cells.count:0)&&state->electrons.size()==(axial?cells.count:0),"checkpoint kinetic state count differs from owned cells/mode");
                const auto moment=[&](const auto& electrons,std::size_t local,std::size_t stride){
                    if(spherical){for(std::size_t slot=0;slot<static_cast<std::size_t>(electrons.grid.cells);++slot)require(electrons.density_modes[slot*stride]>=0,"checkpoint F00 must be nonnegative");}
                    else require(kinetics::detail::legendre_isotropic_nonnegative(electrons.density_modes,static_cast<std::size_t>(electrons.grid.cells),stride),"checkpoint F0 must be nonnegative within numerical tolerance");
                    const double ne=state->owned_values[static_cast<std::size_t>(layout.cell_dof(cells.begin+local,electron)-expected.row_begin)];
                    const double kinetic_ne=electrons.electron_density_m3();
                    require(ne>=0&&std::isfinite(kinetic_ne)&&std::abs(kinetic_ne-ne)<=o.absolute_density_tolerance_m3+o.relative_tolerance*ne,"checkpoint fluid electron density differs from kinetic moment");
                    require(electrons.electron_energy_ev_m3()>=0&&std::isfinite(electrons.electron_energy_ev_m3()),"invalid checkpoint electron energy");
                    if(ne==0&&kinetic_ne==0)for(double value:electrons.density_modes)require(value==0,"zero-density/inactive kinetic state must be exactly zero");
                };
                for(std::size_t local=0;local<state->spherical_electrons.size();++local){const auto& electrons=state->spherical_electrons[local];electrons.validate();require(close(electrons.time_s,state->time_s),"checkpoint spherical clock differs from fluid clock");require(grid_json(electrons.grid)==grid_json(p.electron_closure->grid),"checkpoint spherical grid differs from model");
                    moment(electrons,local,static_cast<std::size_t>(electrons.grid.legendre_terms*electrons.grid.legendre_terms));}
                for(std::size_t local=0;local<state->electrons.size();++local){const auto& electrons=state->electrons[local];require(grid_json(electrons.grid)==grid_json(p.electron_closure->grid),"checkpoint Legendre grid differs from model");require(close(electrons.time_s,state->time_s),"checkpoint Legendre clock differs from fluid clock");
                    const auto stride=static_cast<std::size_t>(electrons.grid.legendre_terms);require(electrons.density_modes.size()==static_cast<std::size_t>(electrons.grid.cells)*stride,"checkpoint Legendre mode count differs from grid");for(double value:electrons.density_modes)require(std::isfinite(value),"nonfinite checkpoint Legendre mode");
                    require(kinetics::detail::legendre_padding_zero(electrons.density_modes,static_cast<std::size_t>(electrons.grid.cells),stride),"checkpoint Legendre padding must be zero");
                    moment(electrons,local,stride);}
            }
            require(cp.local_boundary_counts.size()==p.mechanism.species.size()&&cp.previous_local_boundary_counts.size()==p.mechanism.species.size(),"checkpoint boundary ledger shape differs from species");
            for(const auto* ledger:{&cp.local_boundary_counts,&cp.previous_local_boundary_counts})for(double value:*ledger)require(std::isfinite(value),"nonfinite checkpoint boundary ledger");
            for(const auto* ledger:{&cp.local_energy_integrals_J,&cp.previous_local_energy_integrals_J})for(const auto& [key,value]:*ledger)require(!key.empty()&&std::isfinite(value),"invalid checkpoint energy ledger");
            j["checkpoint_control"]={cp.state.time_s,cp.previous_state.time_s,cp.previous_step_s,cp.next_step_s,cp.accepted_steps};
        }
        finite_json(finite_json,j);shared=j.dump();
    }catch(const std::exception& exception){error=exception.what();}catch(...){error="unknown owned spatial preflight failure";}
    control.collective_require(error);
    std::uint64_t hash=14695981039346656037ull;
    for(unsigned char byte:shared){hash^=byte;hash*=1099511628211ull;}
    bool same=true;for(unsigned shift:{0u,32u}){const double part=static_cast<double>((hash>>shift)&0xffffffffull);if(control.global_max(part)!=-control.global_max(-part))same=false;}
    control.collective_require(same?"":"owned spatial ranks supplied different shared physical metadata, solver controls or checkpoint clocks");
}
}
