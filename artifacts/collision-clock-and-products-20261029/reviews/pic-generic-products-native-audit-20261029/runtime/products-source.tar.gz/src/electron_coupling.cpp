#include "raikou/electron_coupling.h"
#include "chemistry_energy.h"
#include "json_collective.h"
#include "thermal_temperature.h"
#include <algorithm>
#include <cmath>
#include <initializer_list>
#include <set>
#include <tuple>
#include <stdexcept>

namespace raikou::kinetics {
namespace {
[[noreturn]] void invalid(const std::string& message) { throw std::invalid_argument("electron coupling: " + message); }
constexpr double charge_C = 1.602176634e-19;
raikou::Json coupled_shared_input(const chemistry::Mechanism& mechanism,const chemistry::State& state,
    const chemistry::Environment& environment,const ElectronCoupling& coupling,const EedfState& electrons,
    double field,double dt,const CoupledCellOptions& options) {
    const auto& c=coupling.conditions;const auto& e=c.execution;const auto& g=coupling.grid;
    raikou::Json shared{{"mechanism",mechanism.to_json()},{"densities",state.densities_m3},
        {"environment",{environment.gas_temperature_K,environment.liquid_temperature_K,environment.electron_temperature_eV,
            environment.electron_rates,environment.parameters,environment.phase_volumes_m3,environment.interface_areas_m2}},
        {"closure",{coupling.electron_species,coupling.targets,coupling.gas_density_m3,coupling.strict_event_mapping}},
        {"grid",{g.cells,g.max_energy_ev,g.power,g.legendre_terms}},
        {"conditions",{c.reduced_field_td,c.gas_temperature_k,c.gas_density_m3,c.electron_fraction,c.ion_fraction,c.fractions,static_cast<int>(c.sharing),c.temporal_growth}},
        // CUDA device mappings and host thread counts are deliberately local.
        {"execution",{e.mpi,e.device,e.tolerance,e.max_iterations,e.restart,e.preconditioner}},
        {"electrons",{electrons.time_s,electrons.density_modes}},{"field",field},{"dt",dt},
        {"options",{options.relative_tolerance,options.absolute_density_tolerance_m3,options.temperature_tolerance_K,
            options.maximum_newton_iterations,options.heat_capacity_J_m3_K,options.thermal_reservoirs}},{"processes",raikou::Json::array()}};
    for(const auto& p:coupling.processes)shared["processes"].push_back({static_cast<int>(p.kind),p.target,p.product,p.label,p.mass_ratio,p.threshold_ev,p.weight_ratio,
        static_cast<int>(p.group),p.energy_ev,p.cross_section_m2,static_cast<int>(p.angular),p.integral_cross_section_m2});
    return shared;
}
std::map<std::string, std::size_t> species_indices(const chemistry::Mechanism& mechanism) {
    std::map<std::string, std::size_t> result;
    for (std::size_t i = 0; i < mechanism.species.size(); ++i)
        if (!result.emplace(mechanism.species[i].id, i).second) invalid("duplicate chemistry species " + mechanism.species[i].id);
    return result;
}

double kinetic_electron_activity(double density, double gas_density, const SwarmResult& swarm) {
    return density * gas_density * (swarm.ionization_rate_m3_s + swarm.attachment_rate_m3_s + swarm.recombination_rate_m3_s);
}

ElectronFeedback feedback_from(const chemistry::Mechanism& mechanism, const chemistry::State& state,
    const chemistry::Environment& environment, const ElectronCoupling& coupling,
    const EedfConditions& conditions, SwarmResult swarm, double electron_temperature_eV) {
    ElectronFeedback result;
    result.conditions = conditions;
    result.swarm = std::move(swarm);
    result.environment = environment;
    // The equivalent temperature serves temperature-dependent heavy/thermal closures.
    result.environment.electron_temperature_eV = electron_temperature_eV;
    result.mobility_m2_V_s = result.swarm.mobility_n / conditions.gas_density_m3;
    result.diffusion_m2_s = result.swarm.diffusion_n / conditions.gas_density_m3;
    const auto electron = mechanism.species_index(coupling.electron_species);
    const double ne = state.densities_m3.at(electron), Ngas = conditions.gas_density_m3;
    std::map<std::string, const CollisionProcess*> by_label;
    for (const auto& process : coupling.processes) {
        if (process.kind == CollisionKind::Elastic || process.kind == CollisionKind::Effective) continue;
        if (process.label.empty() || !by_label.emplace(process.label, &process).second) invalid("nonelastic collision labels must be nonempty and unique");
    }
    // Far below the threshold of a process the steady distribution's tail is roundoff, and its rate integral can
    // come out a few hundred orders of magnitude below the largest rate but negative. Such a rate is zero; a rate
    // negative beyond kRateRoundoff of the largest one is a solve defect and still fails the chemistry check.
    double rate_scale = std::max(std::abs(result.swarm.ionization_rate_m3_s), std::abs(result.swarm.attachment_rate_m3_s));
    for (const auto& rate : result.swarm.rates) rate_scale = std::max({rate_scale, std::abs(rate.rate_m3_s), std::abs(rate.superelastic_rate_m3_s)});
    constexpr double kRateRoundoff = 1e-12;
    std::size_t floored = 0;
    const auto floor_roundoff = [&](double& value) { if (value < 0 && value >= -kRateRoundoff * rate_scale) { value = 0; ++floored; } };
    floor_roundoff(result.swarm.ionization_rate_m3_s); floor_roundoff(result.swarm.attachment_rate_m3_s);
    for (auto& rate : result.swarm.rates) { floor_roundoff(rate.rate_m3_s); floor_roundoff(rate.superelastic_rate_m3_s); }
    if (floored) result.diagnostics.push_back(std::to_string(floored) + " roundoff-negative EEDF rates set to zero");
    result.kinetic_electron_source_m3_s = ne * Ngas *
        (result.swarm.ionization_rate_m3_s - result.swarm.attachment_rate_m3_s - result.swarm.recombination_rate_m3_s);
    for (const auto& rate : result.swarm.rates) {
        result.environment.electron_rates[rate.label] = rate.rate_m3_s;
        if (rate.kind == CollisionKind::Excitation)
            result.environment.electron_rates[rate.label + ".reverse"] = rate.superelastic_rate_m3_s;
    }
    std::set<std::string> mapped;
    std::map<std::string, std::size_t> reaction_for_label;
    const auto single_target_index = [&](const std::string& target) {
        const auto alias = coupling.targets.find(target);
        if (alias == coupling.targets.end()) return mechanism.species_index(target);
        if (alias->second.size() != 1) invalid("reactive aggregate target needs separate state-specific collision channels: " + target);
        return mechanism.species_index(alias->second.front());
    };
    const auto term_counts = [](const std::vector<chemistry::Term>& terms) {
        std::map<std::size_t, double> counts;
        for (const auto& term : terms) counts[term.species] += term.coefficient;
        return counts;
    };
    for (std::size_t reaction_index = 0; reaction_index < mechanism.reactions.size(); ++reaction_index) {
        const auto& reaction = mechanism.reactions[reaction_index];
        if (reaction.rate.kind != chemistry::RateKind::ElectronEedf) continue;
        const std::string label = reaction.rate.key.empty() ? reaction.collision_label : reaction.rate.key;
        const bool reverse = label.ends_with(".reverse");
        const std::string base = reverse ? label.substr(0, label.size() - 8) : label;
        const auto found = by_label.find(base);
        if (found == by_label.end()) invalid("reaction " + reaction.id + " has no collision channel " + label);
        const auto& process = *found->second;
        if (reverse && !(process.kind == CollisionKind::Excitation && process.weight_ratio > 0 && !process.product.empty()))
            invalid("reaction " + reaction.id + " requests an unavailable superelastic channel");
        double electron_change = 0;
        for (const auto& term : reaction.products) if (term.species == electron) electron_change += term.coefficient;
        for (const auto& term : reaction.reactants) if (term.species == electron) electron_change -= term.coefficient;
        const double expected = process.kind == CollisionKind::Ionization ? 1.0 :
            (process.kind == CollisionKind::Attachment || process.kind == CollisionKind::Recombination ? -1.0 : 0.0);
        if (std::abs(electron_change - expected) > 1e-12) invalid("reaction " + reaction.id + " disagrees with its collision electron count");
        if (reaction.basis_phase != "gas" || !reaction.basis_interface.empty()) invalid("EEDF collision reaction must use a gas volume basis: " + reaction.id);
        const auto target = single_target_index(reverse ? process.product : process.target);
        const std::map<std::size_t, double> expected_reactants{{electron, 1}, {target, 1}};
        if (term_counts(reaction.reactants) != expected_reactants)
            invalid("reaction " + reaction.id + " reactants disagree with collision target " + (reverse ? process.product : process.target));
        if (term_counts(reaction.explicit_orders ? reaction.orders : reaction.reactants) != expected_reactants)
            invalid("reaction " + reaction.id + " orders disagree with its two-body electron collision");
        if (process.kind == CollisionKind::Excitation && !process.product.empty()) {
            const auto product = single_target_index(reverse ? process.target : process.product);
            const std::map<std::size_t, double> expected_products{{electron, 1}, {product, 1}};
            if (term_counts(reaction.products) != expected_products)
                invalid("reaction " + reaction.id + " products disagree with its excited-state collision");
        }
        if (!mapped.insert(label).second) invalid("more than one reaction binds collision " + label + "; explicit branching channels are required");
        reaction_for_label[label] = reaction_index;
    }
    result.collision_event_mapping_complete = true;
    for (const auto& [label, process] : by_label) {
        if (!mapped.contains(label)) {
            result.collision_event_mapping_complete = false;
            result.diagnostics.push_back("Collision has no evolving chemistry reaction: " + label);
        }
        if (process->kind == CollisionKind::Excitation && process->weight_ratio > 0 && !process->product.empty() && !mapped.contains(label + ".reverse")) {
            result.collision_event_mapping_complete = false;
            result.diagnostics.push_back("Superelastic channel has no evolving chemistry reaction: " + label + ".reverse");
        }
    }
    if (coupling.strict_event_mapping && !result.collision_event_mapping_complete) invalid(result.diagnostics.front());
    const auto chemistry = chemistry::evaluate(mechanism, state, result.environment);
    for (const auto& rate : result.swarm.rates) {
        const auto& process = *by_label.at(rate.label);
        const auto verify_event_rate = [&](const std::string& label, const std::string& target, double coefficient) {
            const auto reaction = reaction_for_label.find(label);
            if (reaction == reaction_for_label.end()) return;
            const double expected_events = ne * Ngas * conditions.fractions.at(target) * coefficient;
            const double actual_events = chemistry.reaction_rates_m3_s[reaction->second];
            const double scale = std::max({std::abs(expected_events), std::abs(actual_events), 1e-300});
            if (std::abs(expected_events - actual_events) > 1e-8 * scale)
                invalid("chemistry and EEDF event rates disagree for " + label);
        };
        verify_event_rate(rate.label, process.target, rate.rate_m3_s);
        if (process.kind == CollisionKind::Excitation && process.weight_ratio > 0 && !process.product.empty())
            verify_event_rate(rate.label + ".reverse", process.product, rate.superelastic_rate_m3_s);
    }
    double mapped_activity = 0;
    for (std::size_t r = 0; r < mechanism.reactions.size(); ++r) {
        const auto& reaction = mechanism.reactions[r];
        if (reaction.rate.kind != chemistry::RateKind::ElectronEedf) continue;
        double electron_change = 0;
        for (const auto& term : reaction.products) if (term.species == electron) electron_change += term.coefficient;
        for (const auto& term : reaction.reactants) if (term.species == electron) electron_change -= term.coefficient;
        const double source = electron_change * chemistry.reaction_rates_m3_s[r];
        result.mapped_electron_source_m3_s += source;
        mapped_activity += std::abs(source);
    }
    // Opposing production and loss can cancel to rounding. Certify the net
    // against their gross activity, after checking every mapped event above.
    const double scale = std::max({mapped_activity, kinetic_electron_activity(ne, Ngas, result.swarm),
        std::abs(result.mapped_electron_source_m3_s), std::abs(result.kinetic_electron_source_m3_s), 1e-300});
    if (result.collision_event_mapping_complete && std::abs(result.mapped_electron_source_m3_s - result.kinetic_electron_source_m3_s) > 1e-8 * scale)
        invalid("chemistry and EEDF electron production disagree; verify reaction orders and target aliases");
    const auto& budget = result.swarm.budget;
    const double to_W_m3 = charge_C * ne * Ngas;
    result.collision_energy_sources_W_m3 = {{"gas/translation", to_W_m3 * budget.elastic},
        {"gas/rotation", to_W_m3 * budget.rotational}, {"gas/vibration", to_W_m3 * budget.vibrational},
        {"gas/electronic", to_W_m3 * budget.electronic}, {"gas/ionization", to_W_m3 * budget.ionization},
        {"removed_electrons/attachment", to_W_m3 * budget.attachment}, {"removed_electrons/recombination", to_W_m3 * budget.recombination},
        {"electrons/field", to_W_m3 * budget.field}};
    return result;
}
} // namespace

ElectronCoupling ElectronCoupling::from_json(const raikou::Json& value) {
    ElectronCoupling result;
    result.processes = value.contains("lxcat_text") ? read_lxcat(value.at("lxcat_text").get<std::string>()) :
        collision_processes_from_json(value.at("processes"));
    if (value.contains("lxcat_text") && value.contains("processes")) invalid("provide either processes or lxcat_text");
    result.grid = eedf_grid_from_json(value.value("grid", raikou::Json::object()));
    result.conditions = eedf_conditions_from_json(value.value("conditions", raikou::Json::object()));
    if (value.contains("execution")) {
        const auto& execution = value.at("execution");
        result.conditions.execution.device = execution.value("device", std::string("cpu"));
        result.conditions.execution.mpi = execution.value("mpi", false);
        result.conditions.execution.threads = execution.value("threads", std::size_t{1});
        result.conditions.execution.communicator_f = execution.value("communicator_f", -1);
        result.conditions.execution.cuda_device = execution.value("cuda_device", -1);
        result.conditions.execution.tolerance = execution.value("tolerance", result.conditions.execution.tolerance);
        result.conditions.execution.max_iterations = execution.value("max_iterations", result.conditions.execution.max_iterations);
        result.conditions.execution.restart = execution.value("restart", result.conditions.execution.restart);
        result.conditions.execution.preconditioner = execution.value("preconditioner", result.conditions.execution.preconditioner);
    }
    const auto& execution = result.conditions.execution;
    if (execution.preconditioner != "jacobi" && execution.preconditioner != "block_ilu0") invalid("unknown execution preconditioner");
    if (!(execution.tolerance > 0 && std::isfinite(execution.tolerance)) || execution.max_iterations <= 0 || execution.restart <= 0)
        invalid("execution tolerance and iteration limits must be positive and finite");
    result.electron_species = value.value("electron_species", result.electron_species);
    result.gas_density_m3 = value.value("gas_density_m3", result.gas_density_m3);
    result.strict_event_mapping = value.value("strict_event_mapping", result.strict_event_mapping);
    if (value.contains("targets")) {
        for (const auto& [target, species] : value.at("targets").items()) {
            if (species.is_string()) result.targets[target] = {species.get<std::string>()};
            else result.targets[target] = species.get<std::vector<std::string>>();
        }
    }
    return result;
}

EedfConditions coupled_eedf_conditions(const chemistry::Mechanism& mechanism, const chemistry::State& state,
    const chemistry::Environment& environment, double field_magnitude_V_m, const ElectronCoupling& coupling) {
    if (!(field_magnitude_V_m >= 0 && std::isfinite(field_magnitude_V_m))) invalid("field magnitude must be finite and non-negative");
    if (state.densities_m3.size() != mechanism.species.size()) invalid("species inventory size mismatch");
    if (!(coupling.gas_density_m3 >= 0 && std::isfinite(coupling.gas_density_m3))) invalid("reference gas density must be finite and non-negative");
    const auto indices = species_indices(mechanism);
    const auto found_electron = indices.find(coupling.electron_species);
    if (found_electron == indices.end()) invalid("missing electron species " + coupling.electron_species);
    const auto electron = found_electron->second;
    constexpr double electron_mass_kg = 9.1093837015e-31;
    const auto& electron_species = mechanism.species[electron];
    if (electron_species.phase != "gas" || electron_species.charge != -1 || !electron_species.elements.empty() ||
        !std::isfinite(electron_species.mass_kg) || (electron_species.mass_kg != 0 && std::abs(electron_species.mass_kg / electron_mass_kg - 1) > 1e-6))
        invalid("the kinetic electron species must be element-free gas electrons with charge -1 and the electron mass");
    double heavy = 0, ion_strength = 0;
    for (std::size_t i = 0; i < mechanism.species.size(); ++i) {
        const double density = state.densities_m3[i];
        if (!(density >= 0 && std::isfinite(density))) invalid("invalid density for " + mechanism.species[i].id);
        if (i == electron || mechanism.species[i].phase != "gas") continue;
        if (mechanism.species[i].elements.empty()) invalid("additional element-free gas electron populations are not supported as heavy species: " + mechanism.species[i].id);
        heavy += density;
        if (mechanism.species[i].charge > 0) {
            const double z = static_cast<double>(mechanism.species[i].charge);
            ion_strength += z * z * density;
        }
    }
    const double Ngas = coupling.gas_density_m3 > 0 ? coupling.gas_density_m3 : heavy;
    if (!(Ngas > 0 && std::isfinite(Ngas))) invalid("a positive reference gas density is required");
    EedfConditions conditions = coupling.conditions;
    conditions.gas_density_m3 = Ngas;
    conditions.gas_temperature_k = environment.gas_temperature_K;
    conditions.reduced_field_td = field_magnitude_V_m / Ngas / 1e-21;
    conditions.electron_fraction = state.densities_m3[electron] / Ngas;
    conditions.ion_fraction = ion_strength / Ngas;
    conditions.fractions.clear();
    const auto population = [&](const std::string& target) {
        const auto alias = coupling.targets.find(target);
        std::vector<std::string> direct;
        if (alias == coupling.targets.end()) direct.push_back(target);
        const auto& names = alias == coupling.targets.end() ? direct : alias->second;
        if (names.empty()) invalid("target alias is empty: " + target);
        double density = 0;
        std::set<std::string> seen;
        for (const auto& name : names) {
            const auto found = indices.find(name);
            if (found == indices.end()) invalid("collision target " + target + " has no chemistry species " + name);
            if (!seen.insert(name).second) invalid("duplicate species in target alias " + target);
            if (found->second == electron || mechanism.species[found->second].phase != "gas" || mechanism.species[found->second].elements.empty())
                invalid("collision target must map to gas heavy species: " + target);
            density += state.densities_m3[found->second];
        }
        return density / Ngas;
    };
    for (const auto& process : coupling.processes) {
        conditions.fractions[process.target] = population(process.target);
        if (process.kind == CollisionKind::Excitation && process.weight_ratio > 0 && !process.product.empty())
            conditions.fractions[process.product] = population(process.product);
    }
    return conditions;
}

ElectronFeedback evaluate_electron_feedback(const chemistry::Mechanism& mechanism, const chemistry::State& state,
    const chemistry::Environment& environment, double field_magnitude_V_m, const ElectronCoupling& coupling) {
    const auto conditions = coupled_eedf_conditions(mechanism, state, environment, field_magnitude_V_m, coupling);
    auto swarm = solve_eedf(coupling.processes, conditions, coupling.grid);
    const double temperature = 2.0 / 3 * swarm.mean_energy_ev;
    return feedback_from(mechanism, state, environment, coupling, conditions, std::move(swarm), temperature);
}

ElectronFeedback evaluate_electron_feedback(const chemistry::Mechanism& mechanism, const chemistry::State& state,
    const chemistry::Environment& environment, double field_magnitude_V_m, const ElectronCoupling& coupling, SteadyEedfReuse& reuse) {
    const auto conditions = coupled_eedf_conditions(mechanism, state, environment, field_magnitude_V_m, coupling);
    auto swarm = solve_eedf(coupling.processes, conditions, coupling.grid, reuse);
    const double temperature = 2.0 / 3 * swarm.mean_energy_ev;
    return feedback_from(mechanism, state, environment, coupling, conditions, std::move(swarm), temperature);
}

namespace {
double between(double a, double b, double w) {
    if (a > 0 && b > 0) return std::exp((1 - w) * std::log(a) + w * std::log(b));
    return (1 - w) * a + w * b;
}
} // namespace

SteadyEedfTable SteadyEedfTable::build(const std::vector<CollisionProcess>& processes, const EedfConditions& conditions,
                                       std::vector<double> reduced_fields_td, const EedfGrid& grid) {
    if (reduced_fields_td.size() < 2) invalid("a local field table needs at least two reduced fields");
    for (std::size_t i = 0; i < reduced_fields_td.size(); ++i)
        if (!(reduced_fields_td[i] > 0 && std::isfinite(reduced_fields_td[i])) || (i && !(reduced_fields_td[i] > reduced_fields_td[i - 1])))
            invalid("local field table reduced fields must be positive, finite and strictly increasing");
    SteadyEedfTable table;
    table.conditions = conditions;
    table.conditions.electron_fraction = 0;
    table.conditions.ion_fraction = 0;
    table.swarms = solve_eedf_sweep(processes, table.conditions, reduced_fields_td, grid);
    for (std::size_t i = 0; i < table.swarms.size(); ++i)
        if (!table.swarms[i].converged) invalid("local field table: the steady swarm at " + std::to_string(reduced_fields_td[i]) + " Td did not converge");
    table.reduced_field_td = std::move(reduced_fields_td);
    return table;
}

SwarmResult SteadyEedfTable::at(double td, bool* above) const {
    if (above) *above = td > reduced_field_td.back();
    if (td <= reduced_field_td.front()) return swarms.front();
    if (td >= reduced_field_td.back()) return swarms.back();
    const auto upper = static_cast<std::size_t>(std::upper_bound(reduced_field_td.begin(), reduced_field_td.end(), td) - reduced_field_td.begin());
    const auto lower = upper - 1;
    const double w = std::log(td / reduced_field_td[lower]) / std::log(reduced_field_td[upper] / reduced_field_td[lower]);
    const auto& a = swarms[lower];
    const auto& b = swarms[upper];
    SwarmResult s = w < 0.5 ? a : b;
    s.converged = true;
    for (auto [out, x, y] : std::initializer_list<std::tuple<double*, double, double>>{{&s.mean_energy_ev, a.mean_energy_ev, b.mean_energy_ev}, {&s.mobility_n, a.mobility_n, b.mobility_n},
                             {&s.diffusion_n, a.diffusion_n, b.diffusion_n}, {&s.drift_velocity_m_s, a.drift_velocity_m_s, b.drift_velocity_m_s},
                             {&s.longitudinal_diffusion_n, a.longitudinal_diffusion_n, b.longitudinal_diffusion_n},
                             {&s.transverse_diffusion_n, a.transverse_diffusion_n, b.transverse_diffusion_n},
                             {&s.bulk_drift_velocity_m_s, a.bulk_drift_velocity_m_s, b.bulk_drift_velocity_m_s},
                             {&s.ionization_rate_m3_s, a.ionization_rate_m3_s, b.ionization_rate_m3_s},
                             {&s.attachment_rate_m3_s, a.attachment_rate_m3_s, b.attachment_rate_m3_s},
                             {&s.recombination_rate_m3_s, a.recombination_rate_m3_s, b.recombination_rate_m3_s},
                             {&s.alpha_n_m2, a.alpha_n_m2, b.alpha_n_m2}, {&s.eta_n_m2, a.eta_n_m2, b.eta_n_m2},
                             {&s.net_rate_m3_s, a.net_rate_m3_s, b.net_rate_m3_s},
                             {&s.budget.field, a.budget.field, b.budget.field}, {&s.budget.elastic, a.budget.elastic, b.budget.elastic},
                             {&s.budget.rotational, a.budget.rotational, b.budget.rotational},
                             {&s.budget.vibrational, a.budget.vibrational, b.budget.vibrational},
                             {&s.budget.electronic, a.budget.electronic, b.budget.electronic},
                             {&s.budget.ionization, a.budget.ionization, b.budget.ionization},
                             {&s.budget.superelastic_gain, a.budget.superelastic_gain, b.budget.superelastic_gain},
                             {&s.budget.attachment, a.budget.attachment, b.budget.attachment},
                             {&s.budget.recombination, a.budget.recombination, b.budget.recombination},
                             {&s.budget.growth, a.budget.growth, b.budget.growth},
                             {&s.budget.electron_electron, a.budget.electron_electron, b.budget.electron_electron},
                             {&s.budget.residual, a.budget.residual, b.budget.residual}})
        *out = between(x, y, w);
    if (a.rates.size() != b.rates.size()) invalid("local field table rows bind different processes");
    for (std::size_t k = 0; k < s.rates.size(); ++k) {
        if (a.rates[k].label != b.rates[k].label) invalid("local field table rows bind different processes");
        s.rates[k].rate_m3_s = between(a.rates[k].rate_m3_s, b.rates[k].rate_m3_s, w);
        s.rates[k].superelastic_rate_m3_s = between(a.rates[k].superelastic_rate_m3_s, b.rates[k].superelastic_rate_m3_s, w);
        s.rates[k].power_ev_m3_s = between(a.rates[k].power_ev_m3_s, b.rates[k].power_ev_m3_s, w);
    }
    return s;
}

ElectronFeedback evaluate_electron_feedback(const chemistry::Mechanism& mechanism, const chemistry::State& state,
    const chemistry::Environment& environment, double field_magnitude_V_m, const ElectronCoupling& coupling, const SteadyEedfTable& table) {
    const auto conditions = coupled_eedf_conditions(mechanism, state, environment, field_magnitude_V_m, coupling);
    auto swarm = table.at(conditions.reduced_field_td);
    double ionization = 0, attachment = 0;
    for (auto& rate : swarm.rates) {
        const auto found = conditions.fractions.find(rate.target);
        rate.fraction = found == conditions.fractions.end() ? 0 : found->second;
        if (rate.kind == CollisionKind::Ionization) ionization += rate.fraction * rate.rate_m3_s;
        if (rate.kind == CollisionKind::Attachment) attachment += rate.fraction * rate.rate_m3_s;
    }
    swarm.ionization_rate_m3_s = ionization;
    swarm.attachment_rate_m3_s = attachment;
    const double temperature = 2.0 / 3 * swarm.mean_energy_ev;
    return feedback_from(mechanism, state, environment, coupling, conditions, std::move(swarm), temperature);
}

ElectronFeedback spherical_electron_feedback(const chemistry::Mechanism& mechanism, const chemistry::State& candidate_state,
    const chemistry::Environment& environment, const Vector3& electric_field_V_m, const ElectronCoupling& coupling,
    const SphericalEedfState& electrons, const SphericalEedfEvaluation& evaluation) {
    auto state = candidate_state;
    state.densities_m3.at(mechanism.species_index(coupling.electron_species)) = electrons.electron_density_m3();
    double magnitude_squared = 0;
    for (double value : electric_field_V_m) magnitude_squared += value * value;
    const auto conditions = coupled_eedf_conditions(mechanism, state, environment, std::sqrt(magnitude_squared), coupling);
    auto result = feedback_from(mechanism, state, environment, coupling, conditions, evaluation.swarm, 2.0 / 3 * electrons.mean_energy_ev());
    result.kinetic_electron_source_m3_s = evaluation.electron_production_m3_s;
    if (evaluation.density_mode_rates.size() != electrons.density_modes.size()) invalid("full angular derivative size differs from its state");
    double operator_activity = 0;
    const auto stride = static_cast<std::size_t>(electrons.grid.legendre_terms * electrons.grid.legendre_terms);
    for (int i = 0; i < electrons.grid.cells; ++i) {
        const double lo = electrons.grid.max_energy_ev * std::pow(static_cast<double>(i) / electrons.grid.cells, electrons.grid.power);
        const double hi = electrons.grid.max_energy_ev * std::pow(static_cast<double>(i + 1) / electrons.grid.cells, electrons.grid.power);
        operator_activity += 2.0 / 3 * (std::pow(hi, 1.5) - std::pow(lo, 1.5)) *
            std::abs(evaluation.density_mode_rates[static_cast<std::size_t>(i) * stride]);
    }
    // Conservative field/recoil/Landau fluxes also cancel in the number moment.
    // Their absolute moment supplies a rate-valued roundoff scale even when no
    // number-changing collision channel is present.
    const double scale = std::max({std::abs(result.kinetic_electron_source_m3_s), std::abs(result.mapped_electron_source_m3_s),
        kinetic_electron_activity(electrons.electron_density_m3(), conditions.gas_density_m3, result.swarm), operator_activity, 1e-300});
    if (result.collision_event_mapping_complete && std::abs(result.kinetic_electron_source_m3_s - result.mapped_electron_source_m3_s) > 1e-7 * scale)
        invalid("full angular number moment disagrees with mapped chemistry collision events");
    return result;
}

TransientElectronFeedback advance_electron_feedback(const chemistry::Mechanism& mechanism, const chemistry::State& candidate_state,
    const chemistry::Environment& environment, double field_magnitude_V_m, const ElectronCoupling& coupling,
    const EedfState& previous_electrons, double dt_s) {
    const auto conditions = coupled_eedf_conditions(mechanism, candidate_state, environment, field_magnitude_V_m, coupling);
    TransientElectronFeedback result;
    result.kinetic_step = advance_eedf(coupling.processes, conditions, previous_electrons, dt_s);
    auto updated = candidate_state;
    updated.densities_m3.at(mechanism.species_index(coupling.electron_species)) = result.kinetic_step.state.electron_density_m3();
    auto final_conditions = conditions;
    final_conditions.electron_fraction = result.kinetic_step.state.electron_density_m3() / conditions.gas_density_m3;
    // Chemistry validity and rates must use the same conserved moment as the
    // returned transient thermal diagnostic, before any chemistry evaluation.
    result.feedback = feedback_from(mechanism, updated, environment, coupling, final_conditions, result.kinetic_step.swarm,
        2.0 / 3 * result.kinetic_step.state.mean_energy_ev());
    return result;
}

CoupledCellResult advance_coupled_cell(const chemistry::Mechanism& mechanism, const chemistry::State& initial,
    const chemistry::Environment& environment, const ElectronCoupling& coupling,
    const EedfState& previous_electrons, double field_magnitude_V_m, double dt_s, const CoupledCellOptions& options) {
    // Valid common MPI/communicator selectors are an entry precondition. All
    // remaining validation finishes collectively before kinetic work begins.
    backend::ExecutionOptions bootstrap;bootstrap.mpi=coupling.conditions.execution.mpi;
    bootstrap.communicator_f=coupling.conditions.execution.communicator_f;
    backend::DistributedHalo control(backend::distributed_partition(1,bootstrap),{},bootstrap);
    std::string error,shared;
    std::size_t ns=0,electron=0,size=0;
    std::vector<std::string> phases;
    std::vector<double> temperatures,scales,variables;
    ElectronCoupling complete_coupling;
    try {
    if (!(dt_s > 0 && std::isfinite(dt_s))) invalid("coupled timestep must be finite and positive");
    if (!(options.relative_tolerance > 0 && std::isfinite(options.relative_tolerance)) ||
        !(options.absolute_density_tolerance_m3 > 0 && std::isfinite(options.absolute_density_tolerance_m3)) ||
        !(options.temperature_tolerance_K > 0 && std::isfinite(options.temperature_tolerance_K)) || options.maximum_newton_iterations == 0)
        invalid("coupled tolerances and iteration limit must be positive");
    const auto errors = mechanism.validate();
    if (!errors.empty()) invalid(errors.front());
    ns = mechanism.species.size();electron = mechanism.species_index(coupling.electron_species);
    if (initial.densities_m3.size() != ns) invalid("initial coupled inventory size mismatch");
    for(double density:initial.densities_m3)if(!(density>=0&&std::isfinite(density)))invalid("initial coupled densities must be finite and nonnegative");
    chemistry::validate_environment(environment);
    const auto& execution=coupling.conditions.execution;
    if(execution.device!="cpu"&&execution.device!="cuda")invalid("unknown execution device");
    if(execution.cuda_device< -1)invalid("invalid CUDA device ordinal");
    if(execution.preconditioner!="jacobi"&&execution.preconditioner!="block_ilu0")invalid("unknown execution preconditioner");
    if(!(execution.tolerance>0&&std::isfinite(execution.tolerance))||execution.restart<=0||execution.max_iterations<=0)invalid("invalid execution tolerance/iteration limits");
    const double ne0 = previous_electrons.electron_density_m3();
    if (std::abs(initial.densities_m3[electron] - ne0) > options.absolute_density_tolerance_m3 + options.relative_tolerance * std::abs(ne0))
        invalid("initial chemistry electron count differs from kinetic moment");
    if (previous_electrons.grid.cells != coupling.grid.cells || previous_electrons.grid.max_energy_ev != coupling.grid.max_energy_ev ||
        previous_electrons.grid.power != coupling.grid.power || previous_electrons.grid.legendre_terms != coupling.grid.legendre_terms)
        invalid("coupled collision grid differs from the full kinetic state grid");
    for (const auto& reaction : mechanism.reactions) {
        double electron_change = 0;
        for (const auto& term : reaction.products) if (term.species == electron) electron_change += term.coefficient;
        for (const auto& term : reaction.reactants) if (term.species == electron) electron_change -= term.coefficient;
        if (electron_change != 0 && reaction.rate.kind != chemistry::RateKind::ElectronEedf)
            invalid("electron-producing/removing reaction requires a kinetic collision operator: " + reaction.id);
        if (reaction.rate.kind != chemistry::RateKind::ElectronEedf) {
            for (const auto& [reservoir, energy] : reaction.energy_eV_per_event) {
                const auto key = chemistry::detail::energy_reservoir_key(reaction, reservoir);
                if ((key == "gas/electron" || key == "gas/electrons") && energy != 0)
                    invalid("non-collision electron energy transfer requires a kinetic distribution source operator: " + reaction.id);
            }
        }
    }
    if (thermal::detail::has_liquid_alias_collision(options.heat_capacity_J_m3_K))
        invalid("liquid and aqueous share one liquid_temperature_K; select only one thermal phase name");
    for (const auto& [phase, capacity] : options.heat_capacity_J_m3_K) {
        if (phase != "gas" && phase != "liquid" && phase != "aqueous") invalid("thermal phase must be gas, liquid, or aqueous: " + phase);
        if (!(capacity > 0 && std::isfinite(capacity))) invalid("phase heat capacity must be finite and positive");
        phases.push_back(phase);
        temperatures.push_back(thermal::detail::initial_temperature(environment, phase));
    }
    std::set<std::string> defined_reservoirs;
    for (const auto& reaction : mechanism.reactions)
        for (const auto& [reservoir, energy] : reaction.energy_eV_per_event) {
            (void)energy; defined_reservoirs.insert(chemistry::detail::energy_reservoir_key(reaction, reservoir));
        }
    for (const auto& [phase, reservoirs] : options.thermal_reservoirs) {
        if (!options.heat_capacity_J_m3_K.contains(phase)) invalid("thermal reservoir has no phase heat capacity: " + phase);
        std::set<std::string> unique;
        for (const auto& reservoir : reservoirs) {
            if (!reservoir.starts_with(phase + "/") || reservoir == phase + "/electron" || reservoir == phase + "/electrons")
                invalid("thermal reservoir must belong to its phase and cannot own electron energy: " + reservoir);
            if (!unique.insert(reservoir).second) invalid("duplicate thermal reservoir " + reservoir);
            if (!defined_reservoirs.contains(reservoir)) invalid("unknown selected chemistry thermal reservoir " + reservoir);
        }
    }
    complete_coupling = coupling;
    complete_coupling.strict_event_mapping = true;
    // This validates target aliases, field and plasma fractions without solving.
    (void)coupled_eedf_conditions(mechanism,initial,environment,field_magnitude_V_m,complete_coupling);
    size = ns + phases.size();
    double largest_density = 0;
    for (double density : initial.densities_m3) largest_density = std::max(largest_density, std::abs(density));
    scales.resize(size);variables.resize(size);
    for (std::size_t i = 0; i < ns; ++i) {
        scales[i] = std::max({std::abs(initial.densities_m3[i]), largest_density * 1e-8,
                              options.absolute_density_tolerance_m3 / options.relative_tolerance});
        variables[i] = initial.densities_m3[i] / scales[i];
    }
    for (std::size_t i = 0; i < phases.size(); ++i) {
        if (!(temperatures[i] > 0 && std::isfinite(temperatures[i]))) invalid("initial phase temperature must be finite and positive");
        scales[ns + i] = temperatures[i]; variables[ns + i] = 1;
    }
    if(control.ranks()>1)shared=coupled_shared_input(mechanism,initial,environment,coupling,previous_electrons,field_magnitude_V_m,dt_s,options).dump();
    }catch(const std::exception& exception){error=exception.what();}catch(...){error="unknown coupled input validation failure";}
    control.collective_require(error);
    if(control.ranks()>1){
        std::uint64_t hash=14695981039346656037ull;for(unsigned char byte:shared){hash^=byte;hash*=1099511628211ull;}
        bool same=true;for(unsigned shift:{0u,32u}){const double part=static_cast<double>((hash>>shift)&0xffffffffull);if(control.global_max(part)!=-control.global_max(-part))same=false;}
        control.collective_require(same?"":"replicated coupled ranks supplied different physics, state or solver controls");
    }
    struct Trial {
        CoupledCellResult result;
        std::vector<double> residual;
        std::vector<double> raw_residual;
        std::vector<double> tolerance;
        double norm{0};
    };
    const auto evaluate_trial = [&](const std::vector<double>& values) {
        Trial trial;
        trial.result.state.densities_m3.resize(ns);
        trial.result.environment = environment;
        for (std::size_t i = 0; i < ns; ++i) {
            trial.result.state.densities_m3[i] = values[i] * scales[i];
            if (!(trial.result.state.densities_m3[i] >= 0 && std::isfinite(trial.result.state.densities_m3[i]))) invalid("negative/non-finite coupled trial density");
        }
        for (std::size_t i = 0; i < phases.size(); ++i) {
            const double temperature = values[ns + i] * scales[ns + i];
            if (!(temperature > 0 && std::isfinite(temperature))) invalid("non-positive coupled trial temperature");
            if (phases[i] == "gas") trial.result.environment.gas_temperature_K = temperature;
            else trial.result.environment.liquid_temperature_K = temperature;
        }
        const auto kinetic = advance_electron_feedback(mechanism, trial.result.state, trial.result.environment,
            field_magnitude_V_m, complete_coupling, previous_electrons, dt_s);
        trial.result.electrons = kinetic.kinetic_step.state;
        trial.result.feedback = kinetic.feedback;
        trial.result.environment = kinetic.feedback.environment;
        trial.result.chemistry = chemistry::evaluate(mechanism, trial.result.state, trial.result.environment);
        trial.residual.resize(size);
        trial.raw_residual.resize(size);
        trial.tolerance.resize(size);
        for (std::size_t i = 0; i < ns; ++i) {
            const double density = trial.result.state.densities_m3[i];
            const double raw = i == electron ? density - trial.result.electrons.electron_density_m3() :
                density - initial.densities_m3[i] - dt_s * trial.result.chemistry.production_rates_m3_s[i];
            const double tolerance = options.absolute_density_tolerance_m3 + options.relative_tolerance *
                std::max(std::abs(initial.densities_m3[i]), std::abs(density));
            trial.raw_residual[i] = raw; trial.tolerance[i] = tolerance;
            trial.residual[i] = raw / tolerance;
        }
        for (std::size_t i = 0; i < phases.size(); ++i) {
            const auto& phase = phases[i];
            const double capacity = options.heat_capacity_J_m3_K.at(phase);
            const double temperature = phase == "gas" ? trial.result.environment.gas_temperature_K : trial.result.environment.liquid_temperature_K;
            const double change = capacity * (temperature - temperatures[i]);
            double power = phase == "gas" ? trial.result.feedback.collision_energy_sources_W_m3.at("gas/translation") : 0;
            const auto reservoirs = options.thermal_reservoirs.find(phase);
            if (reservoirs != options.thermal_reservoirs.end())
                for (const auto& reservoir : reservoirs->second) {
                    const auto found = trial.result.chemistry.energy_sources_W_m3.find(reservoir);
                    if (found != trial.result.chemistry.energy_sources_W_m3.end()) power += found->second;
                }
            trial.result.thermal_energy_change_J_m3[phase] = change;
            trial.raw_residual[ns + i] = change - dt_s * power;
            trial.tolerance[ns + i] = capacity *
                (options.temperature_tolerance_K + options.relative_tolerance * std::max(temperature, temperatures[i]));
            trial.residual[ns + i] = trial.raw_residual[ns + i] / trial.tolerance[ns + i];
        }
        for (double value : trial.residual) {
            if (!std::isfinite(value)) invalid("non-finite coupled residual");
            trial.norm = std::max(trial.norm, std::abs(value));
        }
        return trial;
    };
    Trial trial = evaluate_trial(variables);
    for (std::size_t iteration = 0; iteration < options.maximum_newton_iterations; ++iteration) {
        if (trial.norm <= 1) {
            // Commit the moment-owned count exactly. Re-evaluate every coupled equation
            // after this projection, so a tolerance-sized electron correction cannot hide
            // a failed heavy-species or thermal balance.
            variables[electron] = trial.result.electrons.electron_density_m3() / scales[electron];
            trial = evaluate_trial(variables);
            if (trial.norm <= 1) {
                trial.result.state.densities_m3[electron] = trial.result.electrons.electron_density_m3();
                trial.result.chemistry = chemistry::evaluate(mechanism, trial.result.state, trial.result.environment);
                trial.result.nonlinear_iterations = iteration;
                trial.result.nonlinear_residual = trial.norm;
                return trial.result;
            }
        }
        std::vector<double> matrix(size * size), rhs(size);
        for (std::size_t row = 0; row < size; ++row) rhs[row] = -trial.residual[row];
        for (std::size_t column = 0; column < size; ++column) {
            const double delta = 1e-6 * std::max(std::abs(variables[column]), 1.0);
            bool differentiated = false;
            double step = delta;
            for (int attempt = 0; attempt < 10 && !differentiated; ++attempt, step *= 0.5) {
                for (double sign : {1.0, -1.0}) {
                    auto perturbed = variables;
                    const double signed_step = sign * step;
                    perturbed[column] += signed_step;
                    try {
                        const auto shifted = evaluate_trial(perturbed);
                        for (std::size_t row = 0; row < size; ++row)
                            matrix[row * size + column] = (shifted.raw_residual[row] - trial.raw_residual[row]) / (trial.tolerance[row] * signed_step);
                        differentiated = true;
                        break;
                    } catch (const std::invalid_argument&) {
                        // A valid iterate can lie on a temperature applicability or density
                        // boundary. Try its admissible one-sided derivative before shrinking.
                    }
                }
            }
            if (!differentiated) invalid("no admissible coupled Newton finite difference for variable " + std::to_string(column));
        }
        const auto& execution = coupling.conditions.execution;
        if (execution.mpi || execution.device != "cpu" || execution.threads != 1) {
            backend::CsrMatrix sparse;
            sparse.rows = size; sparse.offsets.push_back(0);
            for (std::size_t row = 0; row < size; ++row) {
                for (std::size_t column = 0; column < size; ++column) if (matrix[row * size + column] != 0) {
                    sparse.columns.push_back(static_cast<int>(column)); sparse.values.push_back(matrix[row * size + column]);
                }
                sparse.offsets.push_back(sparse.values.size());
            }
            auto linear_options = execution;
            linear_options.tolerance = std::min(execution.tolerance, 1e-12);
            const auto linear = backend::solve_csr(sparse, rhs, linear_options);
            if (!linear.converged) invalid("coupled Newton linear solve failed; no state was accepted");
            rhs = linear.solution;
        } else {
        // Partial-pivot dense LU is the small serial local-block path. Requested parallel
        // execution uses the same assembled block through the native backend above.
        for (std::size_t column = 0; column < size; ++column) {
            std::size_t pivot = column;
            for (std::size_t row = column + 1; row < size; ++row)
                if (std::abs(matrix[row * size + column]) > std::abs(matrix[pivot * size + column])) pivot = row;
            if (!(std::abs(matrix[pivot * size + column]) > 1e-20)) invalid("coupled Newton Jacobian is singular; reduce the timestep");
            if (pivot != column) {
                for (std::size_t k = column; k < size; ++k) std::swap(matrix[column * size + k], matrix[pivot * size + k]);
                std::swap(rhs[column], rhs[pivot]);
            }
            for (std::size_t row = column + 1; row < size; ++row) {
                const double factor = matrix[row * size + column] / matrix[column * size + column];
                for (std::size_t k = column + 1; k < size; ++k) matrix[row * size + k] -= factor * matrix[column * size + k];
                rhs[row] -= factor * rhs[column];
            }
        }
        for (std::size_t row = size; row-- > 0;) {
            for (std::size_t column = row + 1; column < size; ++column) rhs[row] -= matrix[row * size + column] * rhs[column];
            rhs[row] /= matrix[row * size + row];
        }
        }
        bool accepted = false;
        double damping = 1;
        for (int search = 0; search < 24; ++search, damping *= 0.5) {
            auto candidate = variables;
            for (std::size_t i = 0; i < size; ++i) candidate[i] += damping * rhs[i];
            try {
                auto next = evaluate_trial(candidate);
                if (next.norm < trial.norm) { variables = std::move(candidate); trial = std::move(next); accepted = true; break; }
            } catch (const std::invalid_argument&) { /* Reject this complete trial; no state escapes. */ }
        }
        if (!accepted) invalid("coupled Newton line search failed; reduce the timestep");
    }
    if (trial.norm <= 1) {
        variables[electron] = trial.result.electrons.electron_density_m3() / scales[electron];
        trial = evaluate_trial(variables);
    }
    if (trial.norm <= 1) {
        trial.result.state.densities_m3[electron] = trial.result.electrons.electron_density_m3();
        trial.result.chemistry = chemistry::evaluate(mechanism, trial.result.state, trial.result.environment);
        trial.result.nonlinear_iterations = options.maximum_newton_iterations;
        trial.result.nonlinear_residual = trial.norm;
        return trial.result;
    }
    invalid("coupled Newton iteration limit (normalized residual " + std::to_string(trial.norm) + "); no state was accepted");
}

raikou::Json advance_coupled_cell_json(const raikou::Json& request) {
    using Json = raikou::Json;
    Json defaults=Json::object();const Json* execution=&defaults;
    if(request.contains("execution"))execution=&request.at("execution");
    else if(request.contains("electron_closure")&&request.at("electron_closure").is_object()){
        const auto& closure=request.at("electron_closure");
        if(closure.contains("execution"))execution=&closure.at("execution");
        else if(closure.contains("conditions")&&closure.at("conditions").is_object()&&closure.at("conditions").contains("execution"))
            execution=&closure.at("conditions").at("execution");
    }
    chemistry::Mechanism mechanism;
    chemistry::State state;
    chemistry::Environment environment;
    ElectronCoupling coupling;
    EedfState electrons;
    CoupledCellOptions options;
    double field=0,dt=0;
    const auto control=raikou::detail::parse_collectively(*execution,[&](const backend::DistributedHalo&){
    mechanism = chemistry::Mechanism::from_json(request.at("mechanism"));
    const auto& densities = request.at("state").at("densities_m3");
    if (densities.is_array()) state.densities_m3 = densities.get<std::vector<double>>();
    else for (const auto& species : mechanism.species) state.densities_m3.push_back(densities.at(species.id).get<double>());
    const auto env = request.value("environment", Json::object());
    environment.gas_temperature_K = env.value("gas_temperature_K", environment.gas_temperature_K);
    environment.liquid_temperature_K = env.value("liquid_temperature_K", environment.liquid_temperature_K);
    environment.electron_temperature_eV = env.value("electron_temperature_eV", environment.electron_temperature_eV);
    environment.parameters = env.value("parameters", environment.parameters);
    environment.phase_volumes_m3 = env.value("phase_volumes_m3", environment.phase_volumes_m3);
    environment.interface_areas_m2 = env.value("interface_areas_m2", environment.interface_areas_m2);
    coupling = ElectronCoupling::from_json(request.at("electron_closure"));
    if (request.contains("execution")) {
        auto settings = request.at("electron_closure"); settings["execution"] = request.at("execution");
        coupling = ElectronCoupling::from_json(settings);
    }
    if (request.contains("electrons")) {
        const auto& value = request.at("electrons"); electrons.grid = eedf_grid_from_json(value.at("grid"));
        electrons.time_s = value.value("time_s", 0.0); electrons.density_modes = value.at("density_modes").get<std::vector<double>>();
    } else electrons = maxwellian_eedf(state.densities_m3.at(mechanism.species_index(coupling.electron_species)),
                                      request.at("initial_mean_energy_ev").get<double>(), coupling.grid);
    const auto settings = request.value("options", Json::object());
    options.relative_tolerance = settings.value("relative_tolerance", options.relative_tolerance);
    options.absolute_density_tolerance_m3 = settings.value("absolute_density_tolerance_m3", options.absolute_density_tolerance_m3);
    options.temperature_tolerance_K = settings.value("temperature_tolerance_K", options.temperature_tolerance_K);
    options.maximum_newton_iterations = settings.value("maximum_newton_iterations", options.maximum_newton_iterations);
    options.heat_capacity_J_m3_K = settings.value("heat_capacity_J_m3_K", options.heat_capacity_J_m3_K);
    options.thermal_reservoirs = settings.value("thermal_reservoirs", options.thermal_reservoirs);
    field=request.at("field_magnitude_V_m").get<double>();dt=request.at("dt_s").get<double>();
    });
    (void)control;
    const auto result = advance_coupled_cell(mechanism, state, environment, coupling, electrons,
        field,dt,options);
    Json values = Json::object();
    for (std::size_t i = 0; i < mechanism.species.size(); ++i) values[mechanism.species[i].id] = result.state.densities_m3[i];
    const auto& grid = result.electrons.grid;
    Json electron_json = {{"grid", {{"cells", grid.cells}, {"max_energy_ev", grid.max_energy_ev}, {"power", grid.power}, {"legendre_terms", grid.legendre_terms}}},
        {"time_s", result.electrons.time_s}, {"density_modes", result.electrons.density_modes},
        {"electron_density_m3", result.electrons.electron_density_m3()}, {"electron_energy_ev_m3", result.electrons.electron_energy_ev_m3()}};
    return {{"state", {{"densities_m3", values}}}, {"electrons", electron_json},
        {"environment", {{"gas_temperature_K", result.environment.gas_temperature_K}, {"liquid_temperature_K", result.environment.liquid_temperature_K},
                          {"electron_temperature_eV", result.environment.electron_temperature_eV}, {"electron_rates", result.environment.electron_rates},
                          {"parameters", result.environment.parameters}, {"phase_volumes_m3", result.environment.phase_volumes_m3}, {"interface_areas_m2", result.environment.interface_areas_m2}}},
        {"thermal_energy_change_J_m3", result.thermal_energy_change_J_m3}, {"collision_energy_sources_W_m3", result.feedback.collision_energy_sources_W_m3},
        {"chemical_energy_sources_W_m3", result.chemistry.energy_sources_W_m3}, {"nonlinear_iterations", result.nonlinear_iterations},
        {"nonlinear_residual", result.nonlinear_residual}, {"mode", "monolithic_local_backward_euler_fixed_field_direction"},
        {"execution_scope", "parallel collision/field CSR and Newton block; host kinetic fluxes/Krylov and replicated vectors"}};
}
} // namespace raikou::kinetics
