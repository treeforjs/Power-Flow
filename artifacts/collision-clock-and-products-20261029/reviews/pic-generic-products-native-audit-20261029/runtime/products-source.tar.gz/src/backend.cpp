#include "raikou/backend.h"
#include "raikou/distributed.h"
#include "raikou/device.h"
#include "json_collective.h"
#include <algorithm>
#include <atomic>
#include <bit>
#include <cmath>
#include <cstdint>
#include <exception>
#include <condition_variable>
#include <deque>
#include <future>
#include <limits>
#include <mutex>
#include <memory>
#include <numeric>
#include <stdexcept>
#include <thread>
#ifdef _WIN32
#ifndef NOMINMAX
#define NOMINMAX
#endif
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#include <windows.h>
#include <system_error>
#endif
#ifdef RAIKOU_HAS_MPI
#include <mpi.h>
#endif

namespace raikou::backend {
#ifdef RAIKOU_HAS_CUDA
bool cuda_runtime_available();
#endif
void CsrMatrix::validate() const {
    if (!rows || rows > static_cast<std::size_t>(std::numeric_limits<int>::max()) ||
        offsets.size() != rows + 1 || offsets.front() != 0 ||
        offsets.back() != values.size() || columns.size() != values.size())
        throw std::invalid_argument("invalid square CSR matrix dimensions");
    // Validate the entire index structure before dereferencing any element.
    // Checking while iterating a row can access beyond the buffers when an
    // intermediate offset is large and a later offset decreases again.
    for (std::size_t r = 0; r < rows; ++r)
        if (offsets[r] > offsets[r+1] || offsets[r+1] > values.size())
            throw std::invalid_argument("CSR offsets must increase within the buffers");
    for (std::size_t r = 0; r < rows; ++r) {
        for (auto k = offsets[r]; k < offsets[r+1]; ++k)
            if (columns[k] < 0 || static_cast<std::size_t>(columns[k]) >= rows || !std::isfinite(values[k]))
                throw std::invalid_argument("invalid CSR column or coefficient");
    }
}
namespace {
thread_local bool inside_parallel = false;
thread_local bool inside_jobs = false;
// Batch workers may report capabilities but may not call MPI under FUNNELED.
// The scheduling thread refreshes this snapshot before starting any jobs.
std::atomic<bool> cached_mpi_ready{false};
std::atomic<int> cached_mpi_rank{0};
std::atomic<int> cached_mpi_size{1};
#ifdef _WIN32
// Windows invokes DLL destructors under the loader lock, after process worker
// threads may already have exited. A persistent std::thread pool cannot safely
// join there. The OS pool owns its threads; each parallel call owns and drains
// only its work objects before returning, so no callback survives DLL unload.
class WorkerPool {
    struct Job {
        std::packaged_task<void()> task;
        PTP_WORK work{};
        explicit Job(std::function<void()> action) : task(std::move(action)) {}
    };
    std::vector<std::unique_ptr<Job>> jobs_;
    static void CALLBACK run(PTP_CALLBACK_INSTANCE, void* context, PTP_WORK) {
        inside_parallel=true;
        static_cast<Job*>(context)->task();
        inside_parallel=false;
    }
public:
    ~WorkerPool() {
        for (const auto& job:jobs_) {
            WaitForThreadpoolWorkCallbacks(job->work,FALSE);
            CloseThreadpoolWork(job->work);
        }
    }
    std::future<void> submit(std::function<void()> action) {
        auto job=std::make_unique<Job>(std::move(action));
        auto future=job->task.get_future();
        // Reserve before creating an OS handle so allocation failure cannot
        // leak a work object or leave a callback with a dangling context.
        jobs_.reserve(jobs_.size()+1);
        job->work=CreateThreadpoolWork(run,job.get(),nullptr);
        if(!job->work)throw std::system_error(static_cast<int>(GetLastError()),std::system_category(),"CreateThreadpoolWork");
        const auto work=job->work;
        jobs_.push_back(std::move(job));
        SubmitThreadpoolWork(work);
        return future;
    }
};
#else
class WorkerPool {
    std::mutex mutex_;
    std::condition_variable ready_;
    std::deque<std::packaged_task<void()>> tasks_;
    bool stopping_ = false;
    std::vector<std::thread> workers_;
public:
    void ensure(std::size_t count) {
        std::lock_guard lock(mutex_);
        while(workers_.size()<count) workers_.emplace_back([this] {
            inside_parallel=true;
            for(;;) {
                std::packaged_task<void()> task;
                {
                    std::unique_lock wait_lock(mutex_);
                    ready_.wait(wait_lock,[&]{return stopping_ || !tasks_.empty();});
                    if(stopping_ && tasks_.empty()) return;
                    task=std::move(tasks_.front()); tasks_.pop_front();
                }
                task();
            }
        });
    }
    ~WorkerPool() {
        {std::lock_guard lock(mutex_);stopping_=true;}
        ready_.notify_all();
        for(auto& worker:workers_) worker.join();
    }
    std::future<void> submit(std::function<void()> action) {
        std::packaged_task<void()> task(std::move(action));
        auto result=task.get_future();
        {std::lock_guard lock(mutex_);tasks_.push_back(std::move(task));}
        ready_.notify_one();return result;
    }
};
#endif
}
void parallel_for(std::size_t n, std::size_t threads, const std::function<void(std::size_t)>& action) {
    if (!n) return;
    const auto available=static_cast<std::size_t>(std::max(1u,std::thread::hardware_concurrency()));
    threads = std::min({n, threads ? threads : available, available});
    if (inside_parallel || threads == 1 || n < 32) { for (std::size_t i=0; i<n; ++i) action(i); return; }
#ifdef _WIN32
    WorkerPool pool;
#else
    static WorkerPool pool;
    pool.ensure(threads-1);
#endif
    std::atomic<std::size_t> next{};
    std::atomic<bool> failed{false};
    std::exception_ptr error;
    std::mutex error_mutex;
    const bool parent_inside_jobs=inside_jobs;
    const auto run=[&] {
        struct JobContext {
            bool previous=inside_jobs;
            explicit JobContext(bool active){inside_jobs=active;}
            ~JobContext(){inside_jobs=previous;}
        } context(parent_inside_jobs);
        try {
            while (!failed.load()) {
                const auto i=next.fetch_add(1);
                if (i>=n) break;
                action(i);
            }
        } catch (...) {
            std::lock_guard lock(error_mutex);
            if (!error) error=std::current_exception();
            failed=true;
        }
    };
    std::vector<std::future<void>> workers;
    workers.reserve(threads-1);
    try {
        for(std::size_t t=1;t<threads;++t) workers.push_back(pool.submit(run));
    } catch (...) {
        failed=true;
        for(auto& worker:workers) worker.wait();
        throw;
    }
    inside_parallel=true;
    run();
    inside_parallel=false;
    for(auto& worker:workers) worker.get();
    if (error) std::rethrow_exception(error);
}
namespace {
#ifdef RAIKOU_HAS_MPI
void mpi_check(int status) {
    if (status != 0) throw std::runtime_error("MPI collective failed");
}
#endif
bool mpi_ready() {
    if(inside_jobs)return cached_mpi_ready.load();
#ifdef RAIKOU_HAS_MPI
    int initialized=0, finalized=0;
    MPI_Initialized(&initialized);
    if (initialized) MPI_Finalized(&finalized);
    const bool ready=initialized && !finalized;
    cached_mpi_ready=ready;
    return ready;
#else
    return false;
#endif
}
struct Team {
    int rank{0}, size{1};
    std::size_t first{}, last{};
#ifdef RAIKOU_HAS_MPI
    MPI_Comm communicator{MPI_COMM_SELF};
#endif
    explicit Team(std::size_t n, const ExecutionOptions& options) {
        if (options.mpi) {
            if (inside_jobs) throw std::invalid_argument("batch job callbacks cannot call MPI backends");
            if (!mpi_ready()) throw std::runtime_error("MPI requested but not initialized or built");
#ifdef RAIKOU_HAS_MPI
            int main_thread=0,provided=0;
            mpi_check(MPI_Is_thread_main(&main_thread));
            mpi_check(MPI_Query_thread(&provided));
            if(!main_thread && provided<MPI_THREAD_MULTIPLE)
                throw std::runtime_error("MPI backend must run on the MPI main thread");
            communicator=options.communicator_f>=0?MPI_Comm_f2c(static_cast<MPI_Fint>(options.communicator_f)):MPI_COMM_WORLD;
            if(communicator==MPI_COMM_NULL) throw std::invalid_argument("MPI communicator must not be null");
            mpi_check(MPI_Comm_rank(communicator, &rank));
            mpi_check(MPI_Comm_size(communicator, &size));
#endif
        }
        first=n*static_cast<std::size_t>(rank)/static_cast<std::size_t>(size);
        last=n*static_cast<std::size_t>(rank+1)/static_cast<std::size_t>(size);
    }
    void require(bool valid,const std::string& message) const {
#ifdef RAIKOU_HAS_MPI
        if(size>1) {
            if(inside_jobs)throw std::invalid_argument("batch job callbacks cannot call MPI backends");
            const int local=valid?1:0;
            int all=0;
            mpi_check(MPI_Allreduce(&local,&all,1,MPI_INT,MPI_MIN,communicator));
            if(!all)throw std::invalid_argument(valid?"MPI peer rejected input or operator execution":message);
        }
#endif
        if(!valid)throw std::invalid_argument(message);
    }
    void same_size(std::size_t value) const {
#ifdef RAIKOU_HAS_MPI
        if(size>1) {
            const auto local=static_cast<unsigned long long>(value);
            unsigned long long smallest=0,largest=0;
            mpi_check(MPI_Allreduce(&local,&smallest,1,MPI_UNSIGNED_LONG_LONG,MPI_MIN,communicator));
            mpi_check(MPI_Allreduce(&local,&largest,1,MPI_UNSIGNED_LONG_LONG,MPI_MAX,communicator));
            if(smallest!=largest)throw std::invalid_argument("MPI ranks supplied inconsistent replicated dimensions or solver settings");
        }
#else
        (void)value;
#endif
    }
    double sum(double value) const {
#ifdef RAIKOU_HAS_MPI
        if(size>1) {
            if(inside_jobs)throw std::invalid_argument("batch job callbacks cannot call MPI backends");
            double total{}; mpi_check(MPI_Allreduce(&value,&total,1,MPI_DOUBLE,MPI_SUM,communicator)); return total;
        }
#endif
        return value;
    }
    double dot(std::span<const double> a, std::span<const double> b) const {
        double value=0;
        for (auto i=first;i<last;++i) value+=a[i]*b[i];
        const double total=sum(value);
        if(!std::isfinite(total))throw std::runtime_error("linear dot product overflow");
        return total;
    }
    double norm(std::span<const double> values) const {
        double scale=0.0;
        for(auto i=first;i<last;++i)scale=std::max(scale,std::abs(values[i]));
#ifdef RAIKOU_HAS_MPI
        if(size>1) {
            double largest=0;
            mpi_check(MPI_Allreduce(&scale,&largest,1,MPI_DOUBLE,MPI_MAX,communicator));
            scale=largest;
        }
#endif
        if(scale==0.0)return 0.0;
        double squares=0.0;
        for(auto i=first;i<last;++i) {const double normalized=values[i]/scale;squares+=normalized*normalized;}
        const double result=scale*std::sqrt(sum(squares));
        if(!std::isfinite(result))throw std::runtime_error("linear norm overflow");
        return result;
    }
    void gather(std::vector<double>& values) const {
#ifdef RAIKOU_HAS_MPI
        if(size>1) {
            if(inside_jobs)throw std::invalid_argument("batch job callbacks cannot call MPI backends");
            std::vector<int> counts(static_cast<std::size_t>(size)), starts(counts.size());
            const auto n=values.size();
            for(int i=0;i<size;++i) {
                const auto start=n*static_cast<std::size_t>(i)/static_cast<std::size_t>(size);
                const auto end=n*static_cast<std::size_t>(i+1)/static_cast<std::size_t>(size);
                counts[static_cast<std::size_t>(i)]=static_cast<int>(end-start);
                starts[static_cast<std::size_t>(i)]=static_cast<int>(start);
            }
            mpi_check(MPI_Allgatherv(MPI_IN_PLACE,0,MPI_DATATYPE_NULL,values.data(),counts.data(),starts.data(),MPI_DOUBLE,communicator));
        }
#else
        (void)values;
#endif
    }
};
using DeviceOperator=std::function<std::vector<double>(std::span<const double>)>;
void check_matrix(const CsrMatrix& matrix,const Team& team) {
    std::string error;
    try {matrix.validate();}catch(const std::exception& exception){error=exception.what();}
    team.require(error.empty(),error);
    team.same_size(matrix.rows);
    // Distributed storage is replicated: reject differing matrices rather than
    // entering a Krylov iteration with incompatible local operators.
    std::uint64_t hash=1469598103934665603ULL;
    const auto add=[&](std::uint64_t value){hash^=value;hash*=1099511628211ULL;};
    for(const auto value:matrix.offsets)add(static_cast<std::uint64_t>(value));
    for(const auto value:matrix.columns)add(static_cast<std::uint64_t>(value));
    for(const auto value:matrix.values)add(std::bit_cast<std::uint64_t>(value));
    team.same_size(static_cast<std::size_t>(hash));
}
void check_vector(std::span<const double> values,std::size_t count,const Team& team,bool replicated) {
    bool valid=values.size()==count;
    for(const double value:values)valid=valid && std::isfinite(value);
    team.require(valid,"CSR input vector has invalid dimensions or non-finite values");
    if(replicated) {
        std::uint64_t hash=1469598103934665603ULL;
        for(const double value:values){hash^=std::bit_cast<std::uint64_t>(value);hash*=1099511628211ULL;}
        team.same_size(static_cast<std::size_t>(hash));
    }
}
DeviceOperator make_device_operator(const CsrMatrix& A,const ExecutionOptions& options,const Team& team) {
    DeviceOperator result;
    std::string error;
    try {
    if(options.device=="cpu") { }
    else if (options.device=="cuda") {
#ifdef RAIKOU_HAS_CUDA
        auto device=std::shared_ptr<DeviceExecutor>(make_cuda_executor({A.rows,A.rows,A.offsets,A.columns,A.values},options.cuda_device));
        auto input=std::shared_ptr<DeviceVector>(device->allocate(A.rows));
        auto output=std::shared_ptr<DeviceVector>(device->allocate(A.rows));
        auto mutex=std::make_shared<std::mutex>();
        result=[device=std::move(device),input,output,mutex](std::span<const double> x) {
            std::lock_guard lock(*mutex);
            device->upload(x,*input);device->apply(*input,*output);return device->download(*output);
        };
#else
        (void)A;(void)team;
        throw std::runtime_error("CUDA backend is not built; choose cpu explicitly");
#endif
    }
    else throw std::invalid_argument("backend must be cpu or cuda");
    } catch(const std::exception& exception) {error=exception.what();}
    team.require(error.empty(),error);
    return result;
}
std::vector<double> multiply(const CsrMatrix& A, std::span<const double> x, const ExecutionOptions& options, const Team& team, const DeviceOperator& device) {
    std::vector<double> y;
    std::string error;
    try {
    if(device)y=device(x);
    else {
    y.assign(A.rows,0.0);
    parallel_for(team.last-team.first, options.threads, [&](std::size_t local) {
        const auto r=team.first+local;
        for (auto k=A.offsets[r];k<A.offsets[r+1];++k) y[r]+=A.values[k]*x[static_cast<std::size_t>(A.columns[k])];
    });
    }
    for(auto i=team.first;i<team.last;++i)if(!std::isfinite(y[i]))throw std::runtime_error("CSR multiplication overflow");
    } catch(const std::exception& exception) {error=exception.what();}
    team.require(error.empty(),error);
    team.gather(y);
    return y;
}
} // namespace
namespace detail {
void check_mpi_call_context() {
    if(inside_jobs)throw std::invalid_argument("batch job callbacks cannot call MPI backends");
}
}
bool cuda_available() {
#ifdef RAIKOU_HAS_CUDA
    return cuda_runtime_available();
#else
    return false;
#endif
}
int mpi_rank() {
    if(inside_jobs)return cached_mpi_rank.load();
#ifdef RAIKOU_HAS_MPI
    if(mpi_ready()) { int rank{}; mpi_check(MPI_Comm_rank(MPI_COMM_WORLD,&rank)); cached_mpi_rank=rank; return rank; }
#endif
    return 0;
}
int mpi_size() {
    if(inside_jobs)return cached_mpi_size.load();
#ifdef RAIKOU_HAS_MPI
    if(mpi_ready()) { int size{}; mpi_check(MPI_Comm_size(MPI_COMM_WORLD,&size)); cached_mpi_size=size; return size; }
#endif
    return 1;
}
Runtime::Runtime(bool initialize_mpi) {
    if (!initialize_mpi) return;
#ifdef RAIKOU_HAS_MPI
    if (!mpi_ready()) {
        int finalized=0; MPI_Finalized(&finalized);
        if(finalized) throw std::runtime_error("MPI cannot be reinitialized after finalization");
        int provided{};
        mpi_check(MPI_Init_thread(nullptr,nullptr,MPI_THREAD_FUNNELED,&provided));
        if(provided<MPI_THREAD_FUNNELED) throw std::runtime_error("MPI runtime lacks funneled threading");
        owns_mpi_=true;
    }
#else
    throw std::runtime_error("MPI backend was not built");
#endif
}
Runtime::~Runtime() {
#ifdef RAIKOU_HAS_MPI
    if(owns_mpi_ && mpi_ready()) MPI_Finalize();
#endif
}
std::vector<double> csr_multiply(const CsrMatrix& A, std::span<const double> x, const ExecutionOptions& options) {
    const Team team(A.rows,options);
    check_matrix(A,team);
    check_vector(x,A.rows,team,true);
    if(options.mpi) {
        const auto partition=balanced_partition(static_cast<GlobalIndex>(A.rows),team.rank,team.size);
        DistributedLinearOperator local(partition_replicated(A,partition),options);
        const auto product=local.apply(x.subspan(static_cast<std::size_t>(partition.row_begin),partition.local_rows));
        return gather_distributed(local.halo(),product);
    }
    return multiply(A,x,options,team,make_device_operator(A,options,team));
}
CsrOperator make_csr_operator(const CsrMatrix& matrix,const ExecutionOptions& options) {
    const Team team(matrix.rows,options);
    check_matrix(matrix,team);
    if(options.mpi) {
        const auto partition=balanced_partition(static_cast<GlobalIndex>(matrix.rows),team.rank,team.size);
        auto local=std::make_shared<DistributedLinearOperator>(partition_replicated(matrix,partition),options);
        auto retained_options=options;retained_options.communicator_f=local->halo().communicator_f();
        const Team retained_team(matrix.rows,retained_options);
        return [local,partition,retained_team](std::span<const double> x) {
            check_vector(x,static_cast<std::size_t>(partition.global_rows),retained_team,true);
            const auto product=local->apply(x.subspan(static_cast<std::size_t>(partition.row_begin),partition.local_rows));
            return gather_distributed(local->halo(),product);
        };
    }
    struct Context {
        CsrMatrix matrix;
        ExecutionOptions options;
        Team team;
        DeviceOperator device;
        Context(const CsrMatrix& A,const ExecutionOptions& o,const Team& t):
            matrix(A),options(o),team(t),device(make_device_operator(matrix,options,team)) {}
    };
    auto context=std::make_shared<Context>(matrix,options,team);
    return [context](std::span<const double> x) {
        check_vector(x,context->matrix.rows,context->team,true);
        return multiply(context->matrix,x,context->options,context->team,context->device);
    };
}
LinearResult solve_csr(const CsrMatrix& A, std::span<const double> b, const ExecutionOptions& options) {
    const auto n=A.rows;
    Team team(n,options);
    check_matrix(A,team);
    check_vector(b,A.rows,team,true);
    team.require(options.tolerance>0 && std::isfinite(options.tolerance) && options.max_iterations>0 && options.restart>0,
                 "invalid linear solver settings");
    team.same_size(static_cast<std::size_t>(options.max_iterations));
    team.same_size(static_cast<std::size_t>(options.restart));
    team.same_size(static_cast<std::size_t>(std::bit_cast<std::uint64_t>(options.tolerance)));
    if(options.mpi || (options.device=="cpu" && options.preconditioner=="block_ilu0")) {
        const auto partition=balanced_partition(static_cast<GlobalIndex>(n),team.rank,team.size);
        DistributedLinearOperator local(partition_replicated(A,partition),options);
        const auto solved=local.solve(b.subspan(static_cast<std::size_t>(partition.row_begin),partition.local_rows));
        return {gather_distributed(local.halo(),solved.local_solution),solved.converged,solved.iterations,solved.residual};
    }
    if(options.device=="cuda")return solve_cuda_resident(A,b,options).linear;
    if(options.preconditioner!="jacobi")throw std::invalid_argument("unknown or unsupported linear preconditioner");
    const auto device=make_device_operator(A,options,team);
    const auto norm=[&](std::span<const double> x) { return team.norm(x); };
    const double bnorm=norm(b);
    LinearResult result;
    result.solution.assign(n,0);
    if(bnorm==0) { result.converged=true; return result; }
    std::vector<double> diagonal(n,1);
    for(std::size_t i=0;i<n;++i) for(auto k=A.offsets[i];k<A.offsets[i+1];++k)
        // Leave subnormal diagonals unscaled: dividing a unit Arnoldi vector
        // by them can overflow although the physical quotient b/A is finite.
        if(static_cast<std::size_t>(A.columns[k])==i && std::abs(A.values[k])>=std::numeric_limits<double>::min()) diagonal[i]=A.values[k];
    const int m=std::min(options.restart,static_cast<int>(n));
    while(result.iterations<options.max_iterations) {
        auto residual=multiply(A,result.solution,options,team,device);
        for(std::size_t i=0;i<n;++i) residual[i]=b[i]-residual[i];
        const double beta=norm(residual);
        result.residual=beta;
        if(beta/bnorm<=options.tolerance) { result.converged=true; return result; }
        std::vector<std::vector<double>> V(static_cast<std::size_t>(m+1),std::vector<double>(n));
        std::vector<std::vector<double>> Z(static_cast<std::size_t>(m),std::vector<double>(n));
        std::vector<std::vector<double>> H(static_cast<std::size_t>(m+1),std::vector<double>(static_cast<std::size_t>(m)));
        std::vector<double> cs(static_cast<std::size_t>(m)),sn(cs.size()),g(static_cast<std::size_t>(m+1));
        for(std::size_t i=0;i<n;++i) V[0][i]=residual[i]/beta;
        g[0]=beta;
        int count=0;
        for(int j=0;j<m && result.iterations<options.max_iterations;++j) {
            const auto q=static_cast<std::size_t>(j);
            for(std::size_t i=0;i<n;++i) Z[q][i]=V[q][i]/diagonal[i];
            auto w=multiply(A,Z[q],options,team,device);
            // Two-pass modified Gram-Schmidt prevents loss of orthogonality.
            for(int pass=0;pass<2;++pass) for(int k=0;k<=j;++k) {
                const auto p=static_cast<std::size_t>(k);
                const double h=team.dot(w,V[p]); H[p][q]+=h;
                for(std::size_t i=0;i<n;++i) w[i]-=h*V[p][i];
            }
            H[q+1][q]=norm(w);
            const bool breakdown=H[q+1][q]==0;
            if(!breakdown) for(std::size_t i=0;i<n;++i) V[q+1][i]=w[i]/H[q+1][q];
            for(int k=0;k<j;++k) {
                const auto p=static_cast<std::size_t>(k);
                const double a=H[p][q],c=H[p+1][q];
                H[p][q]=cs[p]*a+sn[p]*c; H[p+1][q]=-sn[p]*a+cs[p]*c;
            }
            const double hyp=std::hypot(H[q][q],H[q+1][q]);
            cs[q]=hyp>0?H[q][q]/hyp:1; sn[q]=hyp>0?H[q+1][q]/hyp:0;
            H[q][q]=hyp; H[q+1][q]=0;
            g[q+1]=-sn[q]*g[q]; g[q]*=cs[q];
            ++result.iterations; count=j+1;
            if(std::abs(g[q+1])/bnorm<=options.tolerance || breakdown) break;
        }
        std::vector<double> y(static_cast<std::size_t>(count));
        for(int i=count-1;i>=0;--i) {
            const auto q=static_cast<std::size_t>(i);
            double value=g[q];
            for(int j=i+1;j<count;++j) value-=H[q][static_cast<std::size_t>(j)]*y[static_cast<std::size_t>(j)];
            if(H[q][q]==0) return result;
            y[q]=value/H[q][q];
            if(!std::isfinite(y[q]))throw std::runtime_error("linear projected solution overflow");
        }
        for(int j=0;j<count;++j) for(std::size_t i=0;i<n;++i) result.solution[i]+=Z[static_cast<std::size_t>(j)][i]*y[static_cast<std::size_t>(j)];
        for(const auto value:result.solution)if(!std::isfinite(value))throw std::runtime_error("linear solution overflow");
    }
    auto r=multiply(A,result.solution,options,team,device);
    for(std::size_t i=0;i<n;++i) r[i]=b[i]-r[i];
    result.residual=norm(r); result.converged=result.residual/bnorm<=options.tolerance;
    return result;
}
Json broadcast_json(const Json& value,int root,const ExecutionOptions& options) {
    const Team team(0,options);
    team.require(root>=0 && root<team.size,"invalid MPI broadcast root");
    team.same_size(static_cast<std::size_t>(root));
#ifdef RAIKOU_HAS_MPI
    if(team.size>1) {
        std::string encoded;
        bool valid=true;
        if(team.rank==root) {
            try {encoded=value.dump();valid=encoded.size()<=static_cast<std::size_t>(std::numeric_limits<int>::max());}
            catch(...) {valid=false;}
        }
        team.require(valid,"request cannot be serialized for MPI broadcast");
        int count=static_cast<int>(encoded.size());
        mpi_check(MPI_Bcast(&count,1,MPI_INT,root,team.communicator));
        bool allocated=true;
        try {encoded.resize(static_cast<std::size_t>(count));}catch(...){allocated=false;}
        team.require(allocated,"cannot allocate MPI request buffer");
        mpi_check(MPI_Bcast(encoded.data(),count,MPI_CHAR,root,team.communicator));
        return Json::parse(encoded);
    }
#endif
    return value;
}
Json capabilities_json() {
    return {{"cpu",true},{"threads",std::max(1u,std::thread::hardware_concurrency())},{"cuda",cuda_available()},
#ifdef RAIKOU_HAS_CUDA
        {"cuda_built",true},
#else
        {"cuda_built",false},
#endif
#ifdef RAIKOU_HAS_MPI
        {"mpi_built",true},
#else
        {"mpi_built",false},
#endif
        {"mpi_initialized",mpi_ready()},{"mpi_rank",mpi_rank()},{"mpi_size",mpi_size()},
        {"linear_solver","native_fgmres_jacobi_or_local_ilu0"},{"distributed_vector_storage","owned rows and vectors with requested halos; legacy APIs gather at explicit compatibility boundaries"},
        {"cuda_scope","resident matrix, Krylov vectors and preconditioner; host rotation scalars and MPI halo staging"}};
}
Json map_jobs(const Json& jobs,const std::function<Json(const Json&)>& action,const ExecutionOptions& options) {
    const Team team(jobs.size(),options);
    if(mpi_ready()){static_cast<void>(mpi_rank());static_cast<void>(mpi_size());}
    team.require(jobs.is_array(),"jobs must be an array");
    team.require(options.device=="cpu","batch scheduling requires cpu; each job selects its own device");
    team.same_size(jobs.size());
    std::string serialized_jobs;
    std::string serialization_error;
    try {serialized_jobs=jobs.dump();}catch(const std::exception& exception){serialization_error=exception.what();}
    team.require(serialization_error.empty(),serialization_error);
    std::uint64_t job_hash=1469598103934665603ULL;
    for(const unsigned char value:serialized_jobs){job_hash^=value;job_hash*=1099511628211ULL;}
    team.same_size(static_cast<std::size_t>(job_hash));
    const auto count=team.last-team.first;
    std::vector<Json> local(count);
    parallel_for(count,options.threads,[&](std::size_t offset){
        const auto index=team.first+offset;
        struct JobGuard {
            bool previous=inside_jobs;
            JobGuard(){inside_jobs=true;}
            ~JobGuard(){inside_jobs=previous;}
        } guard;
        try {
            auto result=action(jobs.at(index));
            const bool ok=!result.is_object() ||
                ((!result.contains("success") || result.at("success").get<bool>()) &&
                 (!result.contains("converged") || result.at("converged").get<bool>()));
            local[offset]={{"index",index},{"ok",ok},{"result",std::move(result)}};
            if(!ok)local[offset]["error"]="job reported an unsuccessful solve";
        }
        catch(const std::exception& e){local[offset]={{"index",index},{"ok",false},{"error",e.what()}};}
        catch(...){local[offset]={{"index",index},{"ok",false},{"error","unknown native exception"}};}
    });
    Json results=Json::array();
    for(auto& item:local)results.push_back(std::move(item));
#ifdef RAIKOU_HAS_MPI
    if(team.size>1) {
        std::string encoded;
        std::string error;
        try {encoded=results.dump();}catch(const std::exception& exception){error=exception.what();}
        team.require(error.empty(),error);
        team.require(encoded.size()<=static_cast<std::size_t>(std::numeric_limits<int>::max()),"batch result exceeds MPI count limits");
        const int length=static_cast<int>(encoded.size());
        std::vector<int> lengths(static_cast<std::size_t>(team.size)),starts(lengths.size());
        mpi_check(MPI_Allgather(&length,1,MPI_INT,lengths.data(),1,MPI_INT,team.communicator));
        std::size_t total=0;
        for(int r=0;r<team.size;++r){
            starts[static_cast<std::size_t>(r)]=static_cast<int>(total);
            total+=static_cast<std::size_t>(lengths[static_cast<std::size_t>(r)]);
            if(total>static_cast<std::size_t>(std::numeric_limits<int>::max()))throw std::invalid_argument("combined batch results exceed MPI count limits");
        }
        std::vector<char> bytes(total);
        mpi_check(MPI_Allgatherv(encoded.data(),length,MPI_CHAR,bytes.data(),lengths.data(),starts.data(),MPI_CHAR,team.communicator));
        results=Json::array();
        for(int r=0;r<team.size;++r) {
            const auto first=bytes.begin()+starts[static_cast<std::size_t>(r)];
            for(auto& item:Json::parse(first,first+lengths[static_cast<std::size_t>(r)]))results.push_back(std::move(item));
        }
    }
#endif
    bool success=true;
    for(const auto& item:results)success=success && item.at("ok").get<bool>();
    return {{"success",success},{"results",results},{"execution",{{"ranks",team.size},{"threads",options.threads}}}};
}
Json linear_solve_json(const Json& request) {
    CsrMatrix A;
    std::vector<double> b;
    ExecutionOptions o;
    const auto config=request.value("execution",Json::object());
    raikou::detail::parse_collectively(config,[&](const DistributedHalo&){
    const auto& m=request.at("matrix");
    A={m.at("rows").get<std::size_t>(),m.at("offsets").get<std::vector<std::size_t>>(),
        m.at("columns").get<std::vector<int>>(),m.at("values").get<std::vector<double>>()};
    b=request.at("rhs").get<std::vector<double>>();
    o.device=config.value("device","cpu"); o.mpi=config.value("mpi",false); o.threads=config.value("threads",std::size_t{});
    o.communicator_f=config.value("communicator_f",-1);
    o.tolerance=config.value("tolerance",o.tolerance);o.max_iterations=config.value("max_iterations",o.max_iterations);
    o.restart=config.value("restart",o.restart);
    o.preconditioner=config.value("preconditioner",o.preconditioner);
    o.cuda_device=config.value("cuda_device",o.cuda_device);
    });
    const auto r=solve_csr(A,b,o);
    return {{"solution",r.solution},{"converged",r.converged},{"iterations",r.iterations},{"residual",r.residual},{"execution",capabilities_json()}};
}
} // namespace raikou::backend
