#pragma once
#include "raikou/device.h"
#include <algorithm>
#include <cmath>
#include <map>
#include <stdexcept>

namespace raikou::backend::detail {
struct DeviceIlu0 {
    std::vector<std::size_t> offsets{0}, diagonal, forward_offsets, backward_offsets;
    std::vector<int> columns, forward_rows, backward_rows;
    std::vector<double> values;
    std::size_t maximum_width{};
};
// Static setup only: factor the owned block, dropping fill and halo columns.
// Iterative triangular applications use these factors entirely on the GPU.
inline DeviceIlu0 prepare_device_ilu0(const DeviceCsrView& matrix) {
    if(matrix.rows>static_cast<std::size_t>(std::numeric_limits<int>::max()))
        throw std::invalid_argument("CUDA ILU0 local row count exceeds index range");
    std::vector<std::map<std::size_t,double>> rows(matrix.rows);
    for(std::size_t row=0;row<matrix.rows;++row)
        for(auto k=matrix.offsets[row];k<matrix.offsets[row+1];++k)
            if(static_cast<std::size_t>(matrix.indices[k])<matrix.rows) {
                auto& value=rows[row][static_cast<std::size_t>(matrix.indices[k])];
                value+=matrix.values[k];
                if(!std::isfinite(value))throw std::runtime_error("CUDA ILU0 input overflow");
            }
    for(std::size_t row=0;row<rows.size();++row) {
        auto& entries=rows[row];
        for(auto lower=entries.begin();lower!=entries.end()&&lower->first<row;++lower) {
            const auto column=lower->first;
            const auto pivot=rows[column].find(column);
            if(pivot==rows[column].end()||pivot->second==0||!std::isfinite(pivot->second))
                throw std::runtime_error("CUDA ILU0 has a zero pivot in the owned block");
            lower->second/=pivot->second;
            if(!std::isfinite(lower->second))throw std::runtime_error("CUDA ILU0 factor overflow");
            for(auto upper=rows[column].upper_bound(column);upper!=rows[column].end();++upper) {
                const auto found=entries.find(upper->first);
                if(found!=entries.end()) {
                    found->second-=lower->second*upper->second;
                    if(!std::isfinite(found->second))throw std::runtime_error("CUDA ILU0 factor overflow");
                }
            }
        }
        const auto pivot=entries.find(row);
        if(pivot==entries.end()||pivot->second==0||!std::isfinite(pivot->second))
            throw std::runtime_error("CUDA ILU0 requires a nonsingular owned diagonal block");
    }
    DeviceIlu0 result;
    std::vector<std::size_t> forward(matrix.rows), backward(matrix.rows);
    for(std::size_t row=0;row<matrix.rows;++row) {
        for(const auto& [column,value]:rows[row]) {
            if(column<row)forward[row]=std::max(forward[row],forward[column]+1);
            if(column==row)result.diagonal.push_back(result.values.size());
            result.columns.push_back(static_cast<int>(column)); result.values.push_back(value);
        }
        result.offsets.push_back(result.values.size());
    }
    for(std::size_t row=matrix.rows;row-->0;)
        for(auto k=result.diagonal[row]+1;k<result.offsets[row+1];++k)
            backward[row]=std::max(backward[row],backward[static_cast<std::size_t>(result.columns[k])]+1);
    const auto levels=[&](const std::vector<std::size_t>& level,std::vector<std::size_t>& offsets,std::vector<int>& order) {
        const auto count=level.empty()?0:*std::max_element(level.begin(),level.end())+1;
        offsets.assign(count+1,0);order.resize(level.size());
        for(auto value:level)++offsets[value+1];
        for(std::size_t i=0;i<count;++i) {
            result.maximum_width=std::max(result.maximum_width,offsets[i+1]);
            offsets[i+1]+=offsets[i];
        }
        auto next=offsets;
        for(std::size_t row=0;row<level.size();++row)order[next[level[row]]++]=static_cast<int>(row);
    };
    levels(forward,result.forward_offsets,result.forward_rows);
    levels(backward,result.backward_offsets,result.backward_rows);
    return result;
}
}
