#include "raikou/c_api.h"
#include "raikou/collisional_radiative_model.h"
#include "raikou/spark_breakdown_solver.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdio>
#include <exception>
#include <stdexcept>
#include <string>

namespace {
using CR = raikou::CollisionalRadiativeModel;
using Spark = raikou::SparkBreakdownSolver;
thread_local std::array<char, 1024> last_error{};

template<class F> raikou_status guarded(F&& action) noexcept {
    last_error[0] = '\0';
    try {
        action();
        return RAIKOU_OK;
    } catch (const std::invalid_argument& error) {
        std::snprintf(last_error.data(), last_error.size(), "%s", error.what());
        return RAIKOU_INVALID_ARGUMENT;
    } catch (const std::overflow_error& error) {
        std::snprintf(last_error.data(), last_error.size(), "%s", error.what());
        return RAIKOU_NUMERICAL_ERROR;
    } catch (const std::runtime_error& error) {
        std::snprintf(last_error.data(), last_error.size(), "%s", error.what());
        return RAIKOU_NUMERICAL_ERROR;
    } catch (const std::exception& error) {
        std::snprintf(last_error.data(), last_error.size(), "%s", error.what());
        return RAIKOU_INTERNAL_ERROR;
    } catch (...) {
        std::snprintf(last_error.data(), last_error.size(), "Unknown internal error");
        return RAIKOU_INTERNAL_ERROR;
    }
}

void require(const void* pointer, const char* name) {
    if (!pointer) throw std::invalid_argument(std::string(name) + " must not be null");
}

void validate(double value, const char* name, bool strictly_positive = false) {
    if (!std::isfinite(value) || (strictly_positive ? value <= 0.0 : value < 0.0)) {
        throw std::invalid_argument(std::string(name) +
            (strictly_positive ? " must be finite and positive" : " must be finite and nonnegative"));
    }
}

void finite_result(double value) {
    if (!std::isfinite(value)) throw std::overflow_error("Model produced a non-finite result");
}

template<size_t N> void finite_result(const double (&values)[N]) {
    for (double value : values) finite_result(value);
}

raikou_spark_state convert(const Spark::SparkState& value) {
    return {value.time_s, value.current_A, value.channel_radius_m, value.pressure_Pa,
        value.temperature_K, value.deposited_energy_J, value.accumulated_action};
}
}

extern "C" {
const char* raikou_version(void) { return RAIKOU_VERSION; }
const char* raikou_last_error(void) { return last_error.data(); }

raikou_status raikou_default_plasma_state(raikou_plasma_state* out) {
    return guarded([&] {
        require(out, "out");
        const CR::PlasmaState value;
        *out = {value.Te_eV, value.ne_m3, value.Tgas_K, value.nH_ground_m3,
            value.nH2_m3, value.path_length_m};
    });
}

raikou_status raikou_evaluate(const raikou_plasma_state* state, raikou_radiance_result* out) {
    return guarded([&] {
        require(state, "state"); require(out, "out");
        validate(state->Te_eV, "Te_eV", true);
        validate(state->ne_m3, "ne_m3");
        validate(state->Tgas_K, "Tgas_K", true);
        validate(state->nH_ground_m3, "nH_ground_m3");
        validate(state->nH2_m3, "nH2_m3");
        validate(state->path_length_m, "path_length_m");
        const auto value = CR{}.evaluate({state->Te_eV, state->ne_m3, state->Tgas_K,
            state->nH_ground_m3, state->nH2_m3, state->path_length_m});
        raikou_radiance_result result{};
        std::copy(value.populations_m3.begin(), value.populations_m3.end(), result.populations_m3);
        result.lyman_alpha_radiance_W_m2_sr = value.lyman_alpha_radiance_W_m2_sr;
        result.lyman_beta_radiance_W_m2_sr = value.lyman_beta_radiance_W_m2_sr;
        result.balmer_alpha_radiance_W_m2_sr = value.balmer_alpha_radiance_W_m2_sr;
        result.balmer_beta_radiance_W_m2_sr = value.balmer_beta_radiance_W_m2_sr;
        result.molecular_lyman_proxy_W_m2_sr = value.molecular_lyman_proxy_W_m2_sr;
        result.tau_0_lyman_alpha = value.tau_0_lyman_alpha;
        result.escape_factor_lyman_alpha = value.escape_factor_lyman_alpha;
        result.tau_0_lyman_beta = value.tau_0_lyman_beta;
        result.escape_factor_lyman_beta = value.escape_factor_lyman_beta;
        finite_result(result.populations_m3);
        finite_result(result.lyman_alpha_radiance_W_m2_sr);
        finite_result(result.lyman_beta_radiance_W_m2_sr);
        finite_result(result.balmer_alpha_radiance_W_m2_sr);
        finite_result(result.balmer_beta_radiance_W_m2_sr);
        finite_result(result.molecular_lyman_proxy_W_m2_sr);
        finite_result(result.tau_0_lyman_alpha);
        finite_result(result.escape_factor_lyman_alpha);
        finite_result(result.tau_0_lyman_beta);
        finite_result(result.escape_factor_lyman_beta);
        *out = result;
    });
}

raikou_status raikou_rate_coefficients(double Te_eV, raikou_rate_result* out) {
    return guarded([&] {
        require(out, "out"); validate(Te_eV, "Te_eV", true);
        raikou_rate_result result{};
        for (int source = 1; source <= RAIKOU_NUM_LEVELS; ++source) {
            for (int destination = 1; destination <= RAIKOU_NUM_LEVELS; ++destination) {
                if (source < destination)
                    result.excitation_m3_s[source - 1][destination - 1] = CR::excitation_rate(source, destination, Te_eV);
                if (source > destination)
                    result.deexcitation_m3_s[source - 1][destination - 1] = CR::deexcitation_rate(source, destination, Te_eV);
            }
            result.ionization_m3_s[source - 1] = CR::ionization_rate(source, Te_eV);
            result.radiative_recombination_m3_s[source - 1] = CR::radiative_recombination(source, Te_eV);
            result.three_body_recombination_m6_s[source - 1] = CR::three_body_recombination(source, Te_eV);
            result.h2_dissociation_m3_s[source - 1] = CR::h2_dissociation_to_level(source, Te_eV);
        }
        for (const auto& row : result.excitation_m3_s) finite_result(row);
        for (const auto& row : result.deexcitation_m3_s) finite_result(row);
        finite_result(result.ionization_m3_s);
        finite_result(result.radiative_recombination_m3_s);
        finite_result(result.three_body_recombination_m6_s);
        finite_result(result.h2_dissociation_m3_s);
        *out = result;
    });
}

raikou_status raikou_default_fit_priors(raikou_fit_priors* out) {
    return guarded([&] {
        require(out, "out");
        const CR::FitPriors value;
        *out = {value.min_Te_eV, value.max_Te_eV, value.min_ne_m3, value.max_ne_m3,
            value.min_nH_m3, value.max_nH_m3, value.min_nH2_m3, value.max_nH2_m3};
    });
}

raikou_status raikou_fit_vuv_shot(double measured_ly_alpha_radiance, double measured_ly_alpha_sigma,
    double measured_molecular_radiance, double measured_molecular_sigma,
    double path_length_m, double fixed_Tgas_K, const raikou_fit_priors* priors, raikou_fit_result* out) {
    return guarded([&] {
        require(out, "out");
        validate(measured_ly_alpha_radiance, "measured_ly_alpha_radiance");
        validate(measured_ly_alpha_sigma, "measured_ly_alpha_sigma", true);
        validate(measured_molecular_radiance, "measured_molecular_radiance");
        validate(measured_molecular_sigma, "measured_molecular_sigma", true);
        validate(path_length_m, "path_length_m", true);
        validate(fixed_Tgas_K, "fixed_Tgas_K", true);
        CR::FitPriors bounds;
        if (priors) {
            const std::array<std::array<double, 2>, 4> ranges{{
                {priors->min_Te_eV, priors->max_Te_eV}, {priors->min_ne_m3, priors->max_ne_m3},
                {priors->min_nH_m3, priors->max_nH_m3}, {priors->min_nH2_m3, priors->max_nH2_m3}}};
            for (const auto& range : ranges) {
                validate(range[0], "prior lower bound", true); validate(range[1], "prior upper bound", true);
                if (range[1] < range[0]) throw std::invalid_argument("Prior upper bounds must be >= lower bounds");
            }
            bounds = {priors->min_Te_eV, priors->max_Te_eV, priors->min_ne_m3, priors->max_ne_m3,
                priors->min_nH_m3, priors->max_nH_m3, priors->min_nH2_m3, priors->max_nH2_m3};
        }
        const auto value = CR{}.fit_vuv_shot(measured_ly_alpha_radiance, measured_ly_alpha_sigma,
            measured_molecular_radiance, measured_molecular_sigma, path_length_m, fixed_Tgas_K, bounds);
        const raikou_fit_result result{value.Te_eV, value.Te_err_eV, value.ne_m3, value.ne_err_m3,
            value.nH_m3, value.nH_err_m3, value.nH2_m3, value.nH2_err_m3,
            value.tau_0_lyman_alpha, value.escape_factor_lyman_alpha,
            value.chi2_reduced, value.converged ? 1 : 0, value.iterations};
        finite_result(result.Te_eV); finite_result(result.Te_err_eV);
        finite_result(result.ne_m3); finite_result(result.ne_err_m3);
        finite_result(result.nH_m3); finite_result(result.nH_err_m3);
        finite_result(result.nH2_m3); finite_result(result.nH2_err_m3);
        finite_result(result.tau_0_lyman_alpha); finite_result(result.escape_factor_lyman_alpha);
        finite_result(result.chi2_reduced);
        *out = result;
    });
}

raikou_status raikou_default_spark_config(raikou_spark_config* out) {
    return guarded([&] {
        require(out, "out");
        const Spark::SparkConfig value;
        *out = {value.peak_current, value.pulse_duration_s, value.initial_density,
            value.plasma_conductivity, value.channel_length};
    });
}

raikou_status raikou_default_spark_state(raikou_spark_state* out) {
    return guarded([&] { require(out, "out"); *out = convert(Spark::SparkState{}); });
}

raikou_status raikou_step_spark(const raikou_spark_state* current, double dt_s,
    const raikou_spark_config* config, raikou_spark_state* out) {
    return guarded([&] {
        require(current, "current"); require(config, "config"); require(out, "out");
        validate(dt_s, "dt_s", true);
        validate(current->time_s, "time_s"); validate(current->current_A, "current_A");
        validate(current->channel_radius_m, "channel_radius_m", true);
        validate(current->pressure_Pa, "pressure_Pa"); validate(current->temperature_K, "temperature_K", true);
        validate(current->deposited_energy_J, "deposited_energy_J");
        validate(current->accumulated_action, "accumulated_action");
        validate(config->peak_current, "peak_current"); validate(config->pulse_duration_s, "pulse_duration_s", true);
        validate(config->initial_density, "initial_density", true);
        validate(config->plasma_conductivity, "plasma_conductivity", true);
        validate(config->channel_length, "channel_length", true);
        const Spark::SparkState state{current->time_s, current->current_A, current->channel_radius_m,
            current->pressure_Pa, current->temperature_K, current->deposited_energy_J, current->accumulated_action};
        const Spark::SparkConfig settings{config->peak_current, config->pulse_duration_s,
            config->initial_density, config->plasma_conductivity, config->channel_length};
        const auto result = convert(Spark::step_spark_discharge(state, dt_s, settings));
        finite_result(result.time_s); finite_result(result.current_A); finite_result(result.channel_radius_m);
        finite_result(result.pressure_Pa); finite_result(result.temperature_K);
        finite_result(result.deposited_energy_J); finite_result(result.accumulated_action);
        *out = result;
    });
}
}
