#include "raikou/spectrometer_calibration.h"

namespace raikou {

SpectrometerCalibration::SpectrometerCalibration(
    const CollectionGeometry& geom,
    const DetectorConfig& det
) : geom_(geom), det_(det) {
    init_n2_lbh_table();
}

void SpectrometerCalibration::init_n2_lbh_table() {
    n2_lbh_table_.clear();

    // Molecular Nitrogen N2 Lyman-Birge-Hopfield (LBH) band system (a^1Pi_g -> X^1Sigma_g+)
    // Transition data from Gilmore, Laher, & Espy (JPCRD 1992) and Ajello et al.

    // v' = 0 Progression
    n2_lbh_table_.push_back({0, 0, 145.0, 1.83e3, 0.0988});
    n2_lbh_table_.push_back({0, 1, 149.3, 2.99e3, 0.1764});
    n2_lbh_table_.push_back({0, 2, 153.8, 2.92e3, 0.1878});
    n2_lbh_table_.push_back({0, 3, 158.6, 2.11e3, 0.1481});

    // v' = 1 Progression
    n2_lbh_table_.push_back({1, 0, 141.6, 4.02e3, 0.1983});
    n2_lbh_table_.push_back({1, 1, 146.4, 1.50e3, 0.0815});
    n2_lbh_table_.push_back({1, 2, 151.1, 4.54e2, 0.0270});
    n2_lbh_table_.push_back({1, 3, 156.0, 1.63e3, 0.1060});

    // v' = 2 Progression
    n2_lbh_table_.push_back({2, 0, 138.4, 5.01e3, 0.2281});
    n2_lbh_table_.push_back({2, 1, 143.0, 1.52e2, 0.0076});
    n2_lbh_table_.push_back({2, 2, 147.6, 1.64e3, 0.0894});
    n2_lbh_table_.push_back({2, 3, 152.3, 1.35e3, 0.0805});

    // v' = 3 Progression
    n2_lbh_table_.push_back({3, 0, 135.4, 4.88e3, 0.2050});
    n2_lbh_table_.push_back({3, 1, 139.7, 2.45e2, 0.0112});
    n2_lbh_table_.push_back({3, 2, 144.3, 8.90e2, 0.0440});

    // v' = 6 Progression (extends into the deep VUV down to 127 nm)
    n2_lbh_table_.push_back({6, 0, 127.3, 2.40e3, 0.0820});
    n2_lbh_table_.push_back({6, 1, 131.0, 1.65e3, 0.0610});
    n2_lbh_table_.push_back({6, 2, 135.0, 8.50e2, 0.0340});
}

double SpectrometerCalibration::transmission_mgf2(double wavelength_nm) noexcept {
    if (wavelength_nm <= 112.0) return 0.0;
    if (wavelength_nm < 125.0) {
        // Steep rise from 112 nm cutoff to ~50% at 121.57 nm (Ly-alpha) and 65% at 125 nm
        const double t = (wavelength_nm - 112.0) / 13.0;
        return 0.65 * std::pow(t, 0.85);
    }
    // Plateau above 125 nm (65% - 82%)
    const double w_norm = std::clamp((wavelength_nm - 125.0) / 75.0, 0.0, 1.0);
    return 0.65 + 0.17 * std::sin(w_norm * PI * 0.5);
}

double SpectrometerCalibration::reflectance_mirrors(double wavelength_nm, int num_mirrors) noexcept {
    // Al + MgF2 front surface VUV mirror reflectance
    double single_mirror_R = 0.0;
    if (wavelength_nm <= 115.0) single_mirror_R = 0.30;
    else if (wavelength_nm < 130.0) {
        // R ~ 0.75 - 0.80 near 121.6 nm
        const double t = (wavelength_nm - 115.0) / 15.0;
        single_mirror_R = 0.65 + 0.15 * t;
    } else {
        // Plateau around 86% above 140 nm
        const double t = std::clamp((wavelength_nm - 130.0) / 70.0, 0.0, 1.0);
        single_mirror_R = 0.80 + 0.07 * t;
    }

    return std::pow(single_mirror_R, static_cast<double>(num_mirrors));
}

double SpectrometerCalibration::efficiency_grating(double wavelength_nm) noexcept {
    // 1200 lines/mm concave grating blazed at 135 nm
    constexpr double blaze_lambda = 135.0;
    constexpr double peak_efficiency = 0.38;
    constexpr double width = 35.0; // nm
    const double delta = (wavelength_nm - blaze_lambda) / width;
    return peak_efficiency * std::exp(-0.5 * delta * delta);
}

double SpectrometerCalibration::photocathode_qe(double wavelength_nm) noexcept {
    // Photek CsI solar-blind photocathode on microchannel plate
    if (wavelength_nm < 110.0) return 0.05;
    if (wavelength_nm <= 130.0) {
        // Peaks near Ly-alpha ~ 12%
        const double t = (wavelength_nm - 110.0) / 20.0;
        return 0.08 + 0.04 * std::sin(t * PI);
    }
    // Slowly rolls off towards 200 nm
    const double decay = (200.0 - std::clamp(wavelength_nm, 130.0, 200.0)) / 70.0;
    return 0.10 * std::pow(decay, 1.2);
}

double SpectrometerCalibration::master_efficiency(double wavelength_nm) const noexcept {
    // Optical train transmission: T_opt = T_window * R_mirrors * eta_grating
    const double T_opt = transmission_mgf2(wavelength_nm) *
                         reflectance_mirrors(wavelength_nm, 2) *
                         efficiency_grating(wavelength_nm);

    // Detector chain: E_det = QE_pc * G_mcp * eta_ph * eta_fiber * eta_cmos * k_adc
    const double E_det = photocathode_qe(wavelength_nm) *
                         det_.mcp_gain *
                         det_.phosphor_photons_per_electron *
                         det_.fiber_coupling_efficiency *
                         det_.cmos_quantum_efficiency *
                         det_.adc_counts_per_photoelectron;

    return T_opt * E_det;
}

double SpectrometerCalibration::counts_to_radiance(
    double raw_counts,
    double wavelength_nm,
    double gate_time_s
) const {
    if (raw_counts <= 0.0 || gate_time_s <= 0.0) return 0.0;

    const double lambda_m = wavelength_nm * 1.0e-9;
    const double photon_energy_J = (H_PLANCK * C_LIGHT) / lambda_m;
    const double G_etendue = geom_.etendue_m2_sr();
    const double E_master = master_efficiency(wavelength_nm);

    if (E_master <= 1e-15 || G_etendue <= 1e-25) {
        throw std::runtime_error("Zero or negative spectrometer throughput at wavelength: " + std::to_string(wavelength_nm));
    }

    // counts = (I * G * E_master * delta_t) / photon_energy
    // => I = (photon_energy * counts) / (G * E_master * delta_t)
    return (photon_energy_J * raw_counts) / (G_etendue * E_master * gate_time_s);
}

double SpectrometerCalibration::radiance_to_counts(
    double radiance_W_m2_sr,
    double wavelength_nm,
    double gate_time_s
) const {
    if (radiance_W_m2_sr <= 0.0 || gate_time_s <= 0.0) return 0.0;

    const double lambda_m = wavelength_nm * 1.0e-9;
    const double photon_energy_J = (H_PLANCK * C_LIGHT) / lambda_m;
    const double G_etendue = geom_.etendue_m2_sr();
    const double E_master = master_efficiency(wavelength_nm);

    return (radiance_W_m2_sr * G_etendue * E_master * gate_time_s) / photon_energy_J;
}

double SpectrometerCalibration::theoretical_branching_ratio(
    int v_prime,
    int v_double_prime_1,
    int v_double_prime_2
) const {
    double A1 = 0.0, A2 = 0.0;
    bool found1 = false, found2 = false;

    for (const auto& trans : n2_lbh_table_) {
        if (trans.v_upper == v_prime) {
            if (trans.v_lower == v_double_prime_1) {
                A1 = trans.einstein_A_s;
                found1 = true;
            }
            if (trans.v_lower == v_double_prime_2) {
                A2 = trans.einstein_A_s;
                found2 = true;
            }
        }
    }

    if (!found1 || !found2 || A2 <= 0.0) {
        throw std::invalid_argument("N2 LBH transition pair not found for v' = " + std::to_string(v_prime));
    }

    return A1 / A2;
}

std::vector<SpectrometerCalibration::RelativeCalibrationPoint> SpectrometerCalibration::evaluate_branching_calibration(
    const std::vector<MeasuredBand>& measured_bands
) const {
    std::vector<RelativeCalibrationPoint> calib_points;
    if (measured_bands.size() < 2) return calib_points;

    // Group bands by v_upper
    for (size_t i = 0; i < measured_bands.size(); ++i) {
        const auto& b1 = measured_bands[i];
        for (size_t j = i + 1; j < measured_bands.size(); ++j) {
            const auto& b2 = measured_bands[j];
            if (b1.v_upper == b2.v_upper && b1.v_lower != b2.v_lower) {
                // Same upper state! True photon intensity ratio is A1 / A2
                const double R_theory = theoretical_branching_ratio(b1.v_upper, b1.v_lower, b2.v_lower);
                if (b2.raw_counts > 0.0 && R_theory > 0.0) {
                    // S1 / S2 = (I1 * E1) / (I2 * E2) = (A1 / A2) * (E1 / E2)
                    // => E1 / E2 = (S1 / S2) / (A1 / A2)
                    const double meas_ratio = b1.raw_counts / b2.raw_counts;
                    const double relative_E1_over_E2 = meas_ratio / R_theory;

                    // Compute relative error propagation
                    const double rel_err_S1 = b1.counts_sigma / std::max(b1.raw_counts, 1.0);
                    const double rel_err_S2 = b2.counts_sigma / std::max(b2.raw_counts, 1.0);
                    const double total_rel_unc = std::sqrt(rel_err_S1 * rel_err_S1 + rel_err_S2 * rel_err_S2);

                    calib_points.push_back({b1.wavelength_nm, relative_E1_over_E2, total_rel_unc * relative_E1_over_E2});
                }
            }
        }
    }

    return calib_points;
}

} // namespace raikou
