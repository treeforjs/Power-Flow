#pragma once
#include "raikou/electron_boltzmann.h"
namespace raikou::kinetics::detail {
struct AzimuthalStep {
    std::vector<double> modes;
    double linear_residual{0};
};
struct AzimuthalEvaluation {
    std::vector<double> rates;
    SwarmResult swarm;
};
[[nodiscard]] AzimuthalEvaluation evaluate_azimuthal_rhs(const std::vector<CollisionProcess>& processes,
    const EedfConditions& conditions, const EedfGrid& grid, int azimuthal_order,
    const std::vector<double>& modes, const std::vector<double>& isotropic_modes);
// Packed l modes use the legacy even/odd energy layout, with l<m padded to zero.
// Unlike the legacy m=0 coefficients, these are normalized real-harmonic modes.
[[nodiscard]] AzimuthalStep advance_azimuthal_eedf(const std::vector<CollisionProcess>& processes,
    const EedfConditions& conditions, const EedfGrid& grid, int azimuthal_order,
    const std::vector<double>& initial_modes, const std::vector<double>& isotropic_modes,
    double dt_s);
}
