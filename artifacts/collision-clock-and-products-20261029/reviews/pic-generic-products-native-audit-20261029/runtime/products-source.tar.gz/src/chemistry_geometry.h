#pragma once

#include "chemistry_energy.h"
#include <set>

namespace raikou::chemistry::detail {

// A same-phase volumetric rate needs no absolute volume: its basis and
// receiving volume cancel. Surface rates and transfers between any affected
// phases require caller-supplied geometry, including energy-only transfers.
inline std::set<std::string> required_phase_volumes(const Reaction& reaction, const Mechanism& mechanism) {
    std::set<std::string> phases;
    if (reaction.basis_interface.empty()) phases.insert(reaction.basis_phase);
    for (const auto& term : reaction.reactants) phases.insert(mechanism.species[term.species].phase);
    for (const auto& term : reaction.products) phases.insert(mechanism.species[term.species].phase);
    for (const auto& [name, energy] : reaction.energy_eV_per_event) {
        (void)energy;
        const auto key = energy_reservoir_key(reaction, name);
        phases.insert(key.substr(0, key.find('/')));
    }
    if (reaction.basis_interface.empty() && phases.size() <= 1) phases.clear();
    return phases;
}

} // namespace raikou::chemistry::detail
