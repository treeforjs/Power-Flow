#include "raikou/chemistry_distributed.h"
#include "chemistry_energy.h"
#include "chemistry_geometry.h"
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <limits>
#include <memory>
#include <set>
#include <span>
#include <stdexcept>
#include <utility>

namespace raikou::chemistry {
namespace {
using backend::DistributedHalo;
using backend::GlobalIndex;
template<class Action> void local_phase(const DistributedHalo& halo, Action action) {
    std::string error;
    try { action(); } catch (const std::exception& exception) { error = exception.what(); }
    catch (...) { error = "unknown distributed chemistry failure"; }
    halo.collective_require(error);
}
void agree(const DistributedHalo& halo, const std::string& text) {
    std::uint64_t hash = 14695981039346656037ull;
    for (const unsigned char value : text) { hash ^= value; hash *= 1099511628211ull; }
    for (int shift : {0, 32}) {
        const double part = static_cast<double>((hash >> shift) & 0xffffffffull);
        halo.collective_require(halo.global_max(part) != -halo.global_max(-part) ? "distributed chemistry metadata/options differ across ranks" : "");
    }
}
double volume(const Environment& env, const std::string& phase, bool required) {
    const auto found = env.phase_volumes_m3.find(phase);
    if (found != env.phase_volumes_m3.end()) return found->second;
    if (required) throw std::invalid_argument("cross-phase reaction requires phase_volumes_m3." + phase);
    return 1;
}
struct Plan {
    const Reaction* reaction{};
    double coefficient{};
    std::vector<std::pair<std::size_t, double>> rows;
    std::map<std::string, double> energy;
};
class Engine {
    backend::RowPartition partition_;
    backend::ExecutionOptions execution_;
    std::vector<bool> mask_;
    std::vector<Plan> plans_;
    std::set<std::string> energy_keys_;
    std::unique_ptr<DistributedHalo> halo_;
public:
    Engine(const Mechanism& mechanism, backend::RowPartition partition, const Environment& environment,
           const backend::ExecutionOptions& execution, const std::vector<bool>& override_mask = {})
        : partition_(partition), execution_(execution) {
        // Validation/plan failures propagate before dependency exchange starts.
        DistributedHalo control(partition, {}, execution);
        std::vector<GlobalIndex> requested;
        std::string metadata;
        local_phase(control, [&] {
            const auto errors = mechanism.validate();
            if (!errors.empty()) throw std::invalid_argument(errors.front());
            if (partition.global_rows != mechanism.species.size()) throw std::invalid_argument("distributed species partition does not match mechanism");
            validate_environment(environment);
            if (execution.device != "cpu" && execution.device != "cuda") throw std::invalid_argument("unknown chemistry execution device");
            if (execution.device == "cuda" && !backend::cuda_available()) throw std::invalid_argument("distributed chemistry CUDA unavailable");
            if (!(execution.tolerance > 0 && std::isfinite(execution.tolerance)) || execution.restart <= 0 || execution.max_iterations <= 0)
                throw std::invalid_argument("invalid distributed chemistry linear controls");
            if (execution.preconditioner != "jacobi" && execution.preconditioner != "block_ilu0") throw std::invalid_argument("unknown chemistry preconditioner");
            mask_ = override_mask;
            if (mask_.empty()) for (const auto& species : mechanism.species) mask_.push_back(species.nonnegative);
            if (mask_.size() != mechanism.species.size()) throw std::invalid_argument("nonnegative mask must match species count");
            metadata = Json{{"mechanism", mechanism.to_json()}, {"environment", {
                {"Tg", environment.gas_temperature_K}, {"Tl", environment.liquid_temperature_K}, {"Te", environment.electron_temperature_eV},
                {"electron_rates", environment.electron_rates}, {"parameters", environment.parameters},
                {"volumes", environment.phase_volumes_m3}, {"areas", environment.interface_areas_m2}}},
                {"mask", mask_}, {"device", execution.device}, {"tolerance", execution.tolerance},
                {"restart", execution.restart}, {"iterations", execution.max_iterations}, {"preconditioner", execution.preconditioner}}.dump();
            for (const auto& reaction : mechanism.reactions) {
                // Co-locate reaction ownership with a participating species.
                // Cyclic rank assignment would create unnecessary global halos
                // even for a nearest-neighbour reaction chain.
                const auto owner_species = reaction.reactants.empty() ? reaction.products.front().species : reaction.reactants.front().species;
                const bool owner = owner_species >= partition.row_begin && owner_species - partition.row_begin < partition.local_rows;
                const auto required_volumes = detail::required_phase_volumes(reaction, mechanism);
                for (const auto& phase : required_volumes) (void)volume(environment, phase, true);
                const bool cross = !required_volumes.empty();
                double measure = 0;
                if (reaction.basis_interface.empty()) measure = volume(environment, reaction.basis_phase, cross);
                else {
                    const auto found = environment.interface_areas_m2.find(reaction.basis_interface);
                    if (found == environment.interface_areas_m2.end()) throw std::invalid_argument("missing interface area: " + reaction.basis_interface);
                    measure = found->second;
                }
                Plan plan; plan.reaction = &reaction; plan.coefficient = rate_coefficient(reaction, environment);
                std::map<std::size_t, double> rows;
                const auto add = [&](const std::vector<Term>& terms, double sign) {
                    for (const auto& term : terms) {
                        const double factor = sign * term.coefficient * measure / volume(environment, mechanism.species[term.species].phase, cross);
                        if (term.species >= partition.row_begin && term.species - partition.row_begin < partition.local_rows)
                            rows[static_cast<std::size_t>(term.species - partition.row_begin)] += factor;
                    }
                };
                add(reaction.reactants, -1); add(reaction.products, 1);
                for (const auto& [row, factor] : rows) if (factor != 0) plan.rows.emplace_back(row, factor);
                for (const auto& [reservoir, energy] : reaction.energy_eV_per_event) {
                    const auto key = detail::energy_reservoir_key(reaction, reservoir);
                    const auto phase = key.substr(0, key.find('/'));
                    energy_keys_.insert(key);
                    const double factor = energy * 1.602176634e-19 * measure / volume(environment, phase, cross);
                    if (owner) plan.energy[key] += factor;
                }
                // Unique owners validate even net-zero reactions.
                if (owner || !plan.rows.empty()) {
                    const auto& orders = reaction.explicit_orders ? reaction.orders : reaction.reactants;
                    for (const auto& order : orders) requested.push_back(order.species);
                    plans_.push_back(std::move(plan));
                }
            }
        });
        agree(control, metadata);
        halo_ = std::make_unique<DistributedHalo>(partition, requested, execution);
        execution_.communicator_f = halo_->communicator_f();
    }
    const DistributedHalo& halo() const { return *halo_; }
    void validate(std::span<const double> state) const {
        local_phase(halo(), [&] {
            if (state.size() != partition_.local_rows) throw std::invalid_argument("distributed chemistry state has wrong local size");
            for (std::size_t i = 0; i < state.size(); ++i)
                if (!std::isfinite(state[i]) || (mask_[static_cast<std::size_t>(partition_.row_begin) + i] && state[i] < 0))
                    throw std::invalid_argument("invalid owned species density");
        });
    }
    bool nonnegative(std::span<const double> state) const {
        double invalid = 0;
        for (std::size_t i = 0; i < state.size(); ++i)
            if (!std::isfinite(state[i]) || (mask_[static_cast<std::size_t>(partition_.row_begin) + i] && state[i] < 0)) invalid = 1;
        return halo().global_max(invalid) == 0;
    }
    DistributedEvaluation evaluate(std::span<const double> state) const {
        validate(state);
        const auto ghosts = halo().exchange(state);
        DistributedEvaluation result;
        result.ghost_species = ghosts.size();
        local_phase(halo(), [&] {
            result.production_rates_m3_s.assign(partition_.local_rows, 0);
            result.jacobian = {partition_.global_rows, partition_.row_begin, {0}, {}, {}};
            std::vector<std::map<GlobalIndex, double>> rows(partition_.local_rows);
            for (const auto& key : energy_keys_) result.energy_sources_W_m3[key] = 0;
            const auto density = [&](std::size_t id) {
                const auto compact = halo().compact_index(id);
                return compact < state.size() ? state[compact] : ghosts[compact - state.size()];
            };
            for (const auto& plan : plans_) {
                const auto& reaction = *plan.reaction;
                const auto& orders = reaction.explicit_orders ? reaction.orders : reaction.reactants;
                double progress = plan.coefficient;
                for (const auto& order : orders) progress *= std::pow(density(order.species), order.coefficient);
                if (!std::isfinite(progress)) throw std::invalid_argument("non-finite reaction progress: " + reaction.id);
                std::map<GlobalIndex, double> derivatives;
                for (const auto& differentiated : orders) {
                    if (differentiated.coefficient == 0) continue;
                    double value = plan.coefficient * differentiated.coefficient;
                    for (const auto& order : orders) {
                        const double exponent = order.coefficient - (order.species == differentiated.species ? 1 : 0);
                        if (exponent != 0) value *= std::pow(density(order.species), exponent);
                    }
                    if (!std::isfinite(value)) throw std::invalid_argument("singular rate derivative: " + reaction.id);
                    derivatives[differentiated.species] += value;
                }
                for (const auto& [row, factor] : plan.rows) {
                    result.production_rates_m3_s[row] += factor * progress;
                    for (const auto& [column, derivative] : derivatives) rows[row][column] += factor * derivative;
                }
                for (const auto& [key, factor] : plan.energy) result.energy_sources_W_m3[key] += factor * progress;
            }
            for (const auto& row : rows) {
                for (const auto& [column, value] : row) {
                    if (!std::isfinite(value)) throw std::invalid_argument("distributed chemistry Jacobian overflow");
                    if (value != 0) { result.jacobian.columns.push_back(column); result.jacobian.values.push_back(value); }
                }
                result.jacobian.offsets.push_back(result.jacobian.values.size());
            }
            for (const double value : result.production_rates_m3_s) if (!std::isfinite(value)) throw std::invalid_argument("distributed chemistry production overflow");
        });
        for (auto& [key, value] : result.energy_sources_W_m3) { (void)key; value = halo().global_sum(value); }
        return result;
    }
    double residual(std::span<const double> start, std::span<const double> trial,
                    const DistributedEvaluation& evaluation, double dt, const AdvanceOptions& options,
                    std::vector<double>* values = nullptr) const {
        double norm = 0;
        local_phase(halo(), [&] {
            if (values) values->resize(start.size());
            for (std::size_t i = 0; i < start.size(); ++i) {
                const double value = trial[i] - start[i] - dt * evaluation.production_rates_m3_s[i];
                const double scale = options.absolute_tolerance_m3 + options.relative_tolerance * std::max(std::abs(start[i]), std::abs(trial[i]));
                if (!std::isfinite(value) || !std::isfinite(scale) || scale <= 0) throw std::invalid_argument("distributed chemistry residual overflow");
                norm = std::max(norm, std::abs(value) / scale);
                if (values) (*values)[i] = value;
            }
        });
        return halo().global_max(norm);
    }
    bool implicit(std::span<const double> start, double dt, const AdvanceOptions& options,
                  std::vector<double>& output, DistributedEvaluation& final) const {
        local_phase(halo(), [&] { output.assign(start.begin(), start.end()); });
        for (std::size_t iteration = 0; iteration < options.maximum_newton_iterations; ++iteration) {
            auto evaluation = evaluate(output);
            std::vector<double> values;
            const double norm = residual(start, output, evaluation, dt, options, &values);
            if (norm <= 0.01) { final = std::move(evaluation); return true; }
            std::vector<double> scale;
            local_phase(halo(), [&] {
                scale.resize(start.size());
                for (std::size_t i = 0; i < scale.size(); ++i) scale[i] = options.absolute_tolerance_m3 + options.relative_tolerance * std::max(std::abs(start[i]), std::abs(output[i]));
            });
            const auto ghost_scale = halo().exchange(scale);
            backend::DistributedCsrMatrix matrix{partition_.global_rows, partition_.row_begin, {0}, {}, {}};
            local_phase(halo(), [&] {
                for (std::size_t row = 0; row < start.size(); ++row) {
                    values[row] = -values[row] / scale[row];
                    std::map<GlobalIndex, double> entries{{partition_.row_begin + row, 1}};
                    const auto& j = evaluation.jacobian;
                    for (auto entry = j.offsets[row]; entry < j.offsets[row + 1]; ++entry) {
                        const auto compact = halo().compact_index(j.columns[entry]);
                        const double column_scale = compact < scale.size() ? scale[compact] : ghost_scale[compact - scale.size()];
                        entries[j.columns[entry]] -= dt * j.values[entry] * column_scale / scale[row];
                    }
                    for (const auto& [column, value] : entries) { matrix.columns.push_back(column); matrix.values.push_back(value); }
                    matrix.offsets.push_back(matrix.values.size());
                }
            });
            const auto linear = backend::solve_distributed(std::move(matrix), values, execution_);
            if (!linear.converged) return false;
            std::vector<double> correction;
            local_phase(halo(), [&] {
                correction = linear.local_solution;
                for (std::size_t i = 0; i < correction.size(); ++i) correction[i] *= scale[i];
            });
            double alpha = 1;
            bool accepted = false;
            for (int search = 0; search < 40; ++search) {
                std::vector<double> candidate;
                local_phase(halo(), [&] {
                    candidate = output;
                    for (std::size_t i = 0; i < candidate.size(); ++i) candidate[i] += alpha * correction[i];
                });
                if (nonnegative(candidate)) {
                    try {
                        const auto candidate_evaluation = evaluate(candidate);
                        if (residual(start, candidate, candidate_evaluation, dt, options) < norm) { output = std::move(candidate); accepted = true; break; }
                    } catch (const std::invalid_argument&) { /* Recoverable nonlinear trial. */ }
                }
                alpha *= 0.5;
            }
            if (!accepted) return false;
        }
        return false;
    }
};
}

DistributedEvaluation evaluate_distributed(const Mechanism& mechanism, const DistributedState& state,
                                          const Environment& environment, const backend::ExecutionOptions& execution) {
    Engine engine(mechanism, state.partition, environment, execution);
    return engine.evaluate(state.densities_m3);
}
DistributedAdvanceResult advance_distributed(const Mechanism& mechanism, const DistributedState& state,
                                             const Environment& environment, double interval_s, const AdvanceOptions& options) {
    DistributedAdvanceResult result;
    result.state = state;
    try {
        Engine engine(mechanism, state.partition, environment, options.execution, options.nonnegative);
        const auto& halo = engine.halo();
        std::string metadata;
        local_phase(halo, [&] {
            if (!std::isfinite(interval_s) || interval_s < 0 || !std::isfinite(options.relative_tolerance) || options.relative_tolerance <= 0 ||
                !std::isfinite(options.absolute_tolerance_m3) || options.absolute_tolerance_m3 <= 0 || !std::isfinite(options.minimum_step_s) || options.minimum_step_s <= 0 ||
                !std::isfinite(options.maximum_step_s) || options.maximum_step_s < 0 || options.maximum_steps == 0 || options.maximum_newton_iterations == 0)
                throw std::invalid_argument("invalid distributed chemistry advance options");
            metadata = Json{{"interval", interval_s}, {"rtol", options.relative_tolerance}, {"atol", options.absolute_tolerance_m3},
                {"min", options.minimum_step_s}, {"max", options.maximum_step_s}, {"steps", options.maximum_steps}, {"newton", options.maximum_newton_iterations}}.dump();
        });
        agree(halo, metadata);
        static_cast<void>(engine.evaluate(state.densities_m3));
        result.ghost_species = halo.layout().ghost_global_ids.size();
        std::vector<double> current;
        local_phase(halo, [&] { current = state.densities_m3; });
        double time = 0, step = options.maximum_step_s > 0 ? std::min(interval_s, options.maximum_step_s) : interval_s;
        std::map<std::string, double> energy;
        while (time < interval_s) {
            if (result.accepted_steps + result.rejected_steps >= options.maximum_steps) throw std::invalid_argument("distributed chemistry step budget exhausted; state rolled back");
            const double remaining = interval_s - time;
            step = std::min(step, remaining);
            if (!(step > 0) || time + step == time || (step < options.minimum_step_s && remaining > options.minimum_step_s)) throw std::invalid_argument("distributed chemistry minimum step reached; state rolled back");
            std::vector<double> full, half, two_half;
            DistributedEvaluation full_eval, half_eval, final_eval;
            bool solved = false;
            try {
                solved = engine.implicit(current, step, options, full, full_eval);
                if (solved) solved = engine.implicit(current, step * 0.5, options, half, half_eval);
                if (solved) solved = engine.implicit(half, step * 0.5, options, two_half, final_eval);
            } catch (const std::invalid_argument&) { solved = false; }
            double error = std::numeric_limits<double>::infinity();
            if (solved) {
                double local_error = 0;
                local_phase(halo, [&] {
                    for (std::size_t i = 0; i < current.size(); ++i) {
                        const double scale = options.absolute_tolerance_m3 + options.relative_tolerance * std::max(std::abs(current[i]), std::abs(two_half[i]));
                        local_error = std::max(local_error, std::abs(two_half[i] - full[i]) / scale);
                    }
                });
                error = halo.global_max(local_error);
            }
            if (!solved || error > 1 || !std::isfinite(error)) {
                ++result.rejected_steps;
                if (step <= options.minimum_step_s) throw std::invalid_argument("distributed chemistry minimum step reached; state rolled back");
                step = std::max(options.minimum_step_s, step *
                    (std::isfinite(error) && error > 0 ? std::clamp(0.9 / std::sqrt(error), 0.1, 0.5) : 0.5));
                continue;
            }
            local_phase(halo, [&] {
                for (const auto& [key, value] : half_eval.energy_sources_W_m3) energy[key] += value * step * 0.5;
                for (const auto& [key, value] : final_eval.energy_sources_W_m3) energy[key] += value * step * 0.5;
                for (const auto& [key, value] : energy) { (void)key; if (!std::isfinite(value)) throw std::invalid_argument("distributed integrated energy overflow"); }
            });
            current = std::move(two_half); time += step; ++result.accepted_steps;
            step = std::max(options.minimum_step_s, step *
                (error > 0 ? std::clamp(0.9 / std::sqrt(error), 0.5, 2.0) : 2));
            if (options.maximum_step_s > 0) step = std::min(step, options.maximum_step_s);
        }
        result.state.densities_m3 = std::move(current); result.success = true; result.advanced_time_s = interval_s;
        result.integrated_energy_J_m3 = std::move(energy); result.message = "completed";
    } catch (const std::exception& exception) {
        result.success = false; result.advanced_time_s = 0; result.integrated_energy_J_m3.clear(); result.message = exception.what();
    }
    return result;
}
}
