#pragma once
#include <algorithm>
#include <cmath>
#include <cstddef>
#include <span>

namespace raikou::kinetics::detail {
inline bool legendre_isotropic_nonnegative(std::span<const double> modes, std::size_t cells, std::size_t stride) {
    if (cells == 0 || stride < 2 || modes.size() % stride != 0 || modes.size() / stride != cells) return false;
    double peak = 0;
    for (std::size_t cell = 0; cell < cells; ++cell) peak = std::max(peak, std::abs(modes[cell * stride]));
    // The transient kinetic solve admits this relative roundoff tail without
    // projecting its density or energy moments. Restarts preserve that state.
    for (std::size_t cell = 0; cell < cells; ++cell) if (!(modes[cell * stride] >= -1e-10 * peak)) return false;
    return true;
}
inline bool legendre_padding_zero(std::span<const double> modes, std::size_t cells, std::size_t stride) {
    if (cells == 0 || stride < 2 || modes.size() % stride != 0 || modes.size() / stride != cells) return false;
    const auto last = (cells - 1) * stride;
    for (std::size_t mode = (stride + 1) / 2; mode < stride; ++mode) if (modes[last + mode] != 0) return false;
    return true;
}
} // namespace raikou::kinetics::detail
