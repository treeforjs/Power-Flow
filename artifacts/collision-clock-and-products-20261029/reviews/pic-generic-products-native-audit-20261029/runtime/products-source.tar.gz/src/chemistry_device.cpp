#include "chemistry_device_internal.h"
#include "chemistry_energy.h"
#include "chemistry_geometry.h"
#include <algorithm>
#include <cmath>
#include <limits>
#include <set>
#include <stdexcept>

namespace raikou::chemistry {
namespace {
std::vector<double> compile_coefficients(const Mechanism& mechanism,const Environment& environment){
    validate_environment(environment);
    std::vector<double> result;result.reserve(mechanism.reactions.size());
    for(const auto& reaction:mechanism.reactions){
        for(const auto& phase:detail::required_phase_volumes(reaction,mechanism))
            if(!environment.phase_volumes_m3.contains(phase))throw std::invalid_argument("missing phase volume: "+phase);
        if(!reaction.basis_interface.empty()&&!environment.interface_areas_m2.contains(reaction.basis_interface))
            throw std::invalid_argument("missing interface area: "+reaction.basis_interface);
        result.push_back(rate_coefficient(reaction,environment));
    }return result;
}
detail::PackedNetwork pack(const Mechanism& mechanism,std::span<const State> states,std::span<const Environment> environments,
                           const std::vector<bool>& positivity={}){
    if(states.empty())throw std::invalid_argument("CUDA chemistry batch must contain at least one cell");
    if(environments.size()!=1&&environments.size()!=states.size())throw std::invalid_argument("CUDA chemistry environment count must be one or match cells");
    const auto errors=mechanism.validate();if(!errors.empty())throw std::invalid_argument(errors.front());
    detail::PackedNetwork p;p.species=mechanism.species.size();p.reactions=mechanism.reactions.size();p.cells=states.size();
    const auto checked_product=[](std::size_t a,std::size_t b){
        if(a&&b>std::numeric_limits<std::size_t>::max()/a)throw std::invalid_argument("CUDA chemistry dimensions overflow");
        return a*b;
    };
    if(p.species>static_cast<std::size_t>(std::numeric_limits<int>::max()))throw std::invalid_argument("CUDA chemistry species exceed index range");
    (void)checked_product(checked_product(p.cells,p.species),p.species);
    (void)checked_product(p.cells,p.reactions);
    (void)checked_product(p.reactions,p.species);
    if(!positivity.empty()&&positivity.size()!=p.species)throw std::invalid_argument("CUDA chemistry positivity mask size differs");
    std::vector<std::string> phases;
    const auto phase_index=[&](const std::string& name){
        auto found=std::find(phases.begin(),phases.end(),name);if(found==phases.end()){phases.push_back(name);return static_cast<int>(phases.size()-1);}
        return static_cast<int>(found-phases.begin());
    };
    for(std::size_t i=0;i<p.species;++i){p.species_phase.push_back(phase_index(mechanism.species[i].phase));p.nonnegative.push_back(static_cast<unsigned char>(positivity.empty()?mechanism.species[i].nonnegative:positivity[i]));}
    p.order_offsets.push_back(0);p.stoichiometry.assign(p.species*p.reactions,0);
    std::set<std::string> keys;
    for(const auto& reaction:mechanism.reactions)for(const auto& [name,energy]:reaction.energy_eV_per_event){
        (void)energy;keys.insert(detail::energy_reservoir_key(reaction,name));
    }
    for(const auto& key:keys){p.energy_keys.push_back(key);p.energy_phase.push_back(phase_index(key.substr(0,key.find('/'))));}
    p.phases=phases.size();p.energies=keys.size();p.energy_per_event_J.assign(p.reactions*p.energies,0);
    for(std::size_t r=0;r<p.reactions;++r){
        const auto& reaction=mechanism.reactions[r];
        for(const auto& term:(reaction.explicit_orders?reaction.orders:reaction.reactants)){
            if(p.order_species.size()>=static_cast<std::size_t>(std::numeric_limits<int>::max()))throw std::invalid_argument("CUDA reaction order count exceeds index range");
            p.order_species.push_back(static_cast<int>(term.species));p.order_power.push_back(term.coefficient);
        }
        p.order_offsets.push_back(static_cast<int>(p.order_species.size()));
        for(const auto& term:reaction.reactants)p.stoichiometry[r*p.species+term.species]-=term.coefficient;
        for(const auto& term:reaction.products)p.stoichiometry[r*p.species+term.species]+=term.coefficient;
        for(const auto& [name,energy]:reaction.energy_eV_per_event){
            const auto key=detail::energy_reservoir_key(reaction,name);
            const auto index=static_cast<std::size_t>(std::find(p.energy_keys.begin(),p.energy_keys.end(),key)-p.energy_keys.begin());
            p.energy_per_event_J[r*p.energies+index]+=energy*1.602176634e-19;
        }
    }
    const auto shared_coefficients=environments.size()==1?compile_coefficients(mechanism,environments.front()):std::vector<double>{};
    p.densities.reserve(p.cells*p.species);p.coefficients.reserve(p.cells*p.reactions);p.measures.reserve(p.cells*p.reactions);
    p.volumes.reserve(checked_product(p.cells,p.phases));
    for(std::size_t cell=0;cell<p.cells;++cell){
        const auto& state=states[cell];if(state.densities_m3.size()!=p.species)throw std::invalid_argument("CUDA cell density count differs");
        for(std::size_t i=0;i<p.species;++i){const double value=state.densities_m3[i];if(!std::isfinite(value)||(p.nonnegative[i]&&value<0))throw std::invalid_argument("invalid initial CUDA cell density");p.densities.push_back(value);}
        const auto& env=environments[environments.size()==1?0:cell];
        // Validate every rate and geometry requirement before any device work.
        const auto coefficients=environments.size()==1?shared_coefficients:compile_coefficients(mechanism,env);
        p.coefficients.insert(p.coefficients.end(),coefficients.begin(),coefficients.end());
        for(const auto& reaction:mechanism.reactions){
            if(reaction.basis_interface.empty()){
                const auto found=env.phase_volumes_m3.find(reaction.basis_phase);p.measures.push_back(found==env.phase_volumes_m3.end()?1:found->second);
            }else p.measures.push_back(env.interface_areas_m2.at(reaction.basis_interface));
        }
        for(const auto& phase:phases){const auto found=env.phase_volumes_m3.find(phase);p.volumes.push_back(found==env.phase_volumes_m3.end()?1:found->second);}
    }
    return p;
}
}
DeviceEvaluationBatch evaluate_cuda_batch(const Mechanism& mechanism,std::span<const State> states,std::span<const Environment> environments,int device_id){
    auto p=pack(mechanism,states,environments);p.cuda_device=device_id;
#ifdef RAIKOU_HAS_CUDA
    const auto evaluated=detail::evaluate_cuda_impl(p);DeviceEvaluationBatch result;result.transfers=evaluated.transfers;result.cells.resize(p.cells);
    for(std::size_t c=0;c<p.cells;++c){auto& e=result.cells[c];
        e.production_rates_m3_s.assign(evaluated.sources.begin()+static_cast<std::ptrdiff_t>(c*p.species),evaluated.sources.begin()+static_cast<std::ptrdiff_t>((c+1)*p.species));
        e.jacobian_row_major.assign(evaluated.jacobians.begin()+static_cast<std::ptrdiff_t>(c*p.species*p.species),evaluated.jacobians.begin()+static_cast<std::ptrdiff_t>((c+1)*p.species*p.species));
        e.reaction_rates_m3_s.assign(evaluated.progress.begin()+static_cast<std::ptrdiff_t>(c*p.reactions),evaluated.progress.begin()+static_cast<std::ptrdiff_t>((c+1)*p.reactions));
        e.rate_coefficients.assign(p.coefficients.begin()+static_cast<std::ptrdiff_t>(c*p.reactions),p.coefficients.begin()+static_cast<std::ptrdiff_t>((c+1)*p.reactions));
        for(std::size_t k=0;k<p.energies;++k)e.energy_sources_W_m3[p.energy_keys[k]]=evaluated.energy[c*p.energies+k];
    }return result;
#else
    (void)p;throw std::runtime_error("CUDA chemistry was not built; no CPU fallback");
#endif
}
DeviceAdvanceBatch advance_cuda_batch(const Mechanism& mechanism,std::span<const State> states,std::span<const Environment> environments,
                                     double interval,const AdvanceOptions& options){
    if(options.execution.mpi)throw std::invalid_argument("CUDA independent-cell batch does not issue MPI collectives");
    if(!std::isfinite(interval)||interval<0||!(options.relative_tolerance>0)||!std::isfinite(options.relative_tolerance)||
       !(options.absolute_tolerance_m3>0)||!std::isfinite(options.absolute_tolerance_m3)||!(options.minimum_step_s>0)||
       !std::isfinite(options.minimum_step_s)||options.maximum_step_s<0||!std::isfinite(options.maximum_step_s)||
       !options.maximum_steps||!options.maximum_newton_iterations)throw std::invalid_argument("invalid CUDA chemistry advance options");
    auto p=pack(mechanism,states,environments,options.nonnegative);p.cuda_device=options.execution.cuda_device;
#ifdef RAIKOU_HAS_CUDA
    const auto advanced=detail::advance_cuda_impl(p,interval,options);DeviceAdvanceBatch result;result.transfers=advanced.transfers;result.cells.resize(p.cells);
    for(std::size_t c=0;c<p.cells;++c){auto& out=result.cells[c];const auto& progress=advanced.progress[c];out.state=states[c];out.accepted_steps=progress.accepted;out.rejected_steps=progress.rejected;
        out.success=progress.code==0;out.advanced_time_s=out.success?interval:0;
        out.message=out.success?"completed on CUDA":(progress.code==1?"CUDA chemistry step budget exhausted; state rolled back":
            (progress.code==2?"CUDA chemistry minimum timestep reached; state rolled back":"nonfinite CUDA chemistry state, rate or energy; state rolled back"));
        if(out.success){out.state.densities_m3.assign(advanced.densities.begin()+static_cast<std::ptrdiff_t>(c*p.species),advanced.densities.begin()+static_cast<std::ptrdiff_t>((c+1)*p.species));
            for(std::size_t k=0;k<p.energies;++k)out.integrated_energy_J_m3[p.energy_keys[k]]=advanced.energies[c*p.energies+k];}
    }return result;
#else
    (void)p;throw std::runtime_error("CUDA chemistry was not built; no CPU fallback");
#endif
}
} // namespace raikou::chemistry
