#include "raikou/runtime.h"
#include "raikou/backend.h"
#include "raikou/chemistry.h"
#include "raikou/electron_boltzmann.h"
#include "raikou/electron_coupling.h"
#include "raikou/spherical_harmonics.h"
#include "raikou/eedf_distributed.h"
#include "raikou/spatial.h"
#include "raikou/spatial_distributed.h"
#include "json_collective.h"
#include <stdexcept>

namespace raikou {
namespace {
Json runtime_bootstrap(const Json& request,std::string_view operation) {
    const Json* fallback=nullptr;
    if(operation=="spatial.solve"&&request.contains("solver")&&request.at("solver").is_object())fallback=&request.at("solver");
    else if(operation=="chemistry.advance"&&request.contains("options")&&request.at("options").is_object()&&request.at("options").contains("execution"))
        fallback=&request.at("options").at("execution");
    else if((operation.starts_with("eedf.")||operation=="breakdown.solve")&&request.contains("conditions")&&request.at("conditions").is_object()&&request.at("conditions").contains("execution"))
        fallback=&request.at("conditions").at("execution");
    const Json empty=Json::object();
    const auto& execution=request.contains("execution")?request.at("execution"):(fallback?*fallback:empty);
    // Spatial execution settings inherit missing fields from solver settings;
    // chemistry/EEDF execution objects replace their nested execution object.
    const bool inherit=operation=="spatial.solve"&&fallback;
    const auto selected=[&](const char* name)->const Json*{
        if(execution.is_object()&&execution.contains(name))return &execution.at(name);
        if(inherit&&fallback->contains(name))return &fallback->at(name);
        return nullptr;
    };
    const auto* mpi=selected("mpi");const auto* communicator=selected("communicator_f");
    return {{"mpi",mpi?mpi->get<bool>():false},{"communicator_f",communicator?communicator->get<int>():-1}};
}
bool requests_nested_mpi(const Json& value) {
    if(value.is_object()) {
        for(const auto& [name,item]:value.items()) {
            if((name=="execution" || name=="options" || name=="solver") && item.is_object() && item.value("mpi",false))return true;
            if(requests_nested_mpi(item))return true;
        }
    } else if(value.is_array()) {
        for(const auto& item:value)if(requests_nested_mpi(item))return true;
    }
    return false;
}
}
Json execute(std::string_view operation, const Json& request) {
    if(!request.is_object()) throw std::invalid_argument("request must be an object");
    if(operation=="capabilities") {
        auto result=backend::capabilities_json();
        result["version"]="1.0.0";
        result["status"]="research-release";
        result["operations"]={"capabilities","batch.execute","linear.solve","mechanism.validate","chemistry.evaluate","chemistry.advance","chemistry.evaluate_batch","chemistry.advance_batch","chemistry.evaluate_distributed","chemistry.advance_distributed","eedf.solve","eedf.advance","eedf.evaluate_spherical","eedf.advance_spherical","eedf.solve_distributed","eedf.advance_distributed","coupled.advance","water.levels","breakdown.solve","spatial.solve","spatial.reconfigure","spatial.solve_distributed"};
        result["physics_execution"]={
            {"chemistry","CPU or device-resident CUDA rates, Jacobians, Newton and adaptive integration for independent cells; distributed chemistry uses CPU assembly and owned CPU/CUDA linear solves"},
            {"eedf","CPU collision/field/Landau assembly; owned CPU or resident CUDA Krylov and ILU0; auxiliary hydrodynamic diffusion solves use owned CPU vectors"},
            {"spatial","CPU nonlinear assembly; CPU or resident CUDA linear solves; implicit full-angular collision and spatial streaming"}};
        return result;
    }
    if(operation=="linear.solve") return backend::linear_solve_json(request);
    if(operation=="batch.execute") {
        const auto config=request.value("execution",Json::object());
        backend::ExecutionOptions execution;
        const Json* jobs=nullptr;
        raikou::detail::parse_collectively(config,[&](const backend::DistributedHalo&){
        execution.threads=config.value("threads",std::size_t{});execution.mpi=config.value("mpi",false);
        execution.communicator_f=config.value("communicator_f",-1);execution.device=config.value("device",std::string("cpu"));
        jobs=&request.at("jobs");
        if(!jobs->is_array())throw std::invalid_argument("jobs must be an array");
        });
        return backend::map_jobs(*jobs,[](const Json& job){
            const auto op=job.at("operation").get<std::string>();
            if(op=="batch.execute")throw std::invalid_argument("nested batches are unsupported");
            auto data=job.value("request",Json::object());
            if(requests_nested_mpi(data))
                throw std::invalid_argument("individual batch jobs cannot use MPI collectives");
            return execute(op,data);
        },execution);
    }
    // Owned operations validate the remainder of each request collectively.
    // Dispatch before generic field parsing, which could otherwise strand a
    // peer if only one rank supplied a malformed device/options value.
    if(operation=="chemistry.evaluate_distributed") return chemistry::evaluate_distributed_json(request);
    if(operation=="chemistry.advance_distributed") return chemistry::advance_distributed_json(request);
    if(operation=="eedf.solve_distributed") return kinetics::solve_distributed_eedf_json(request);
    if(operation=="eedf.advance_distributed") return kinetics::advance_distributed_eedf_json(request);
    if(operation=="spatial.solve_distributed") return spatial::solve_distributed_json(request);
    if(operation=="coupled.advance") return kinetics::advance_coupled_cell_json(request);
    raikou::detail::parse_collectively(runtime_bootstrap(request,operation),[&](const backend::DistributedHalo&){
    const auto device=request.value("execution",Json::object()).value("device",std::string("cpu"));
    if(device!="cpu" && operation!="spatial.solve" && operation!="chemistry.advance" && operation!="chemistry.evaluate" &&
        operation!="chemistry.evaluate_batch" && operation!="chemistry.advance_batch" &&
        operation!="chemistry.evaluate_distributed" && operation!="chemistry.advance_distributed" &&
        operation!="eedf.evaluate_spherical" && operation!="eedf.advance_spherical" &&
        operation!="eedf.solve_distributed" && operation!="eedf.advance_distributed" &&
        operation!="eedf.solve" && operation!="eedf.advance" && operation!="breakdown.solve" && operation!="coupled.advance")
        throw std::invalid_argument("operation "+std::string(operation)+" currently requires execution.device=cpu");
    });
    if(operation=="mechanism.validate") return chemistry::validate_mechanism(request.contains("mechanism")?request.at("mechanism"):request);
    if(operation=="chemistry.evaluate") return chemistry::evaluate_json(request);
    if(operation=="chemistry.advance") return chemistry::advance_json(request);
    if(operation=="chemistry.evaluate_batch") return chemistry::evaluate_batch_json(request);
    if(operation=="chemistry.advance_batch") return chemistry::advance_batch_json(request);
    if(operation=="eedf.solve") return kinetics::solve_eedf_json(request);
    if(operation=="eedf.advance") return kinetics::advance_eedf_json(request);
    if(operation=="eedf.evaluate_spherical") return kinetics::evaluate_spherical_eedf_json(request);
    if(operation=="eedf.advance_spherical") return kinetics::advance_spherical_eedf_json(request);
    if(operation=="water.levels") return kinetics::water_levels_json(request);
    if(operation=="breakdown.solve") return kinetics::solve_breakdown_json(request);
    if(operation=="spatial.solve") return spatial::solve_json(request);
    if(operation=="spatial.reconfigure") return spatial::reconfigure_json(request);
    throw std::invalid_argument("unknown Raikou operation: "+std::string(operation));
}
}
