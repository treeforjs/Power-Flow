#include "raikou/spatial_kinetic_adapter.h"
#include "raikou/spatial.h"
#include "raikou/kinetic_rz.h"
#include "raikou/spatial_boundary.h"
#include <algorithm>
#include <cmath>
#include <set>
#include <stdexcept>

namespace raikou::kinetics {
namespace {
[[noreturn]] void invalid(const std::string& text){throw std::invalid_argument("owned kinetic adapter: "+text);}
void require(bool value,const std::string& text){if(!value)invalid(text);}
double fraction_at(const std::vector<double>& field,std::size_t cell,std::size_t count){
    require(field.size()==1||field.size()==count,"phase fraction dimensions differ from mesh");
    const double value=field[field.size()==1?0:cell];require(value>=0&&value<=1&&std::isfinite(value),"invalid phase fraction");return value;
}
KineticWall wall_kind(const spatial::Boundary& wall){
    const auto kind=wall.kinetic_electrons=="auto"?(wall.absorbing?"absorbing":"specular"):wall.kinetic_electrons;
    if(kind=="specular")return KineticWall::Specular;
    if(kind=="absorbing")return KineticWall::Absorbing;
    if(kind=="prescribed_incoming")return KineticWall::PrescribedIncoming;
    if(kind=="secondary_emission")return KineticWall::Absorbing;
    invalid("unknown kinetic wall kind "+kind);
}
}
struct OwnedKineticAdapter::Impl {
    KineticMesh kinetic_mesh;
    std::vector<KineticBoundaryRecord> records;
    std::vector<KineticEmissionTemplate> emission_templates;
    std::vector<double> gas_fractions,inverse_radius;
    std::vector<backend::GlobalIndex> moment_offsets,face_moment_ids;
    spatial::partition::CellInterval owned;
    ElectronCoupling coupling;
    backend::ExecutionOptions execution;
    std::optional<backend::DistributedHalo> moments;
};
OwnedKineticAdapter::OwnedKineticAdapter(const spatial::Problem& model,const spatial::mesh::Geometry& geometry,
    const std::map<std::string,std::vector<double>>& fractions,spatial::partition::CellInterval owned,const backend::ExecutionOptions& execution){
    auto data=std::make_shared<Impl>();data->owned=owned;data->execution=execution;
    const auto count=geometry.volume.size();
    backend::DistributedHalo control(backend::distributed_partition(count,execution),{},execution);
    std::string error;
    try{
        require(model.electron_closure.has_value()&&model.electron_mode=="transient_spherical","full angular transient electron closure is required");
        require(owned.begin<=count&&owned.count<=count-owned.begin,"owned cell interval exceeds mesh");data->coupling=*model.electron_closure;
        const auto gas=fractions.find("gas");require(gas!=fractions.end(),"gas phase fractions are required");
        data->gas_fractions.resize(count);std::vector<double> volumes(count),areas(geometry.faces.size());
        for(std::size_t c=0;c<count;++c){data->gas_fractions[c]=fraction_at(gas->second,c,count);volumes[c]=data->gas_fractions[c]*geometry.volume[c];}
        std::map<std::size_t,SpatialKineticBoundary> contacts;
        std::vector<KineticBoundaryRecord> interior_records;
        std::size_t kinetic_index=0;
        for(std::size_t f=0;f<geometry.faces.size();++f){
            const auto& face=geometry.faces[f];const double af=data->gas_fractions.at(face.a),bf=data->gas_fractions.at(face.b);
            const double aperture=af>0&&bf>0?2*af*bf/(af+bf):std::max(af,bf);areas[f]=face.area*aperture;
            if((af>0)!=(bf>0)){
                const auto contact=model.electron_phase_contacts.find(f);require(contact!=model.electron_phase_contacts.end(),"active/absent contact requires explicit kinetic boundary");
                KineticBoundaryRecord record;record.kinetic_face=kinetic_index;record.owner=KineticBoundaryOwner::PhaseContact;record.geometric_face=f;record.gas_cell=af>0?face.a:face.b;record.receiving_cell=af>0?face.b:face.a;
                auto boundary=contact->second.boundary;
                if(record.gas_cell<owned.begin||record.gas_cell-owned.begin>=owned.count)boundary.incoming.reset();
                contacts[f]=std::move(boundary);
                if(!contact->second.absorbed_species.empty()){
                    const auto s=model.mechanism.species_index(contact->second.absorbed_species);const auto& species=model.mechanism.species[s];
                    require(species.phase!="gas"&&species.charge==-1&&species.elements.empty(),"contact species must own non-gas electrons");
                    const auto phase=fractions.find(species.phase);require(phase!=fractions.end()&&fraction_at(phase->second,record.receiving_cell,count)>0,"contact electron owner is absent from receiving cell");record.absorbed_species=s;
                }
                require(contact->second.boundary.kind==KineticWall::Specular||record.absorbed_species.has_value(),"nonreflecting contact needs an electron charge owner");
                record.energy_to_phase=contact->second.energy_to_phase;
                if(!record.energy_to_phase.empty()){
                    const auto phase=fractions.find(record.energy_to_phase);require(phase!=fractions.end(),"contact heat names an unknown phase");
                    if(fraction_at(phase->second,record.receiving_cell,count)>0)record.energy_cell=record.receiving_cell;
                    else if(fraction_at(phase->second,record.gas_cell,count)>0)record.energy_cell=record.gas_cell;
                    else invalid("contact heat phase is absent from both contact cells");
                }
                if(areas[f]>0)interior_records.push_back(std::move(record));
            }else require(!model.electron_phase_contacts.contains(f),"contact boundary does not separate active and absent gas phases");
            if(areas[f]>0&&(af>0||bf>0))++kinetic_index;
        }
        for(const auto& [index,contact]:model.electron_phase_contacts){(void)contact;require(index<geometry.faces.size(),"contact face index exceeds mesh");}
        auto physical=geometry;std::vector<SpatialKineticBoundary> walls;walls.reserve(geometry.walls.size());
        data->records=std::move(interior_records);
        for(std::size_t w=0;w<geometry.walls.size();++w){
            const auto& wall=geometry.walls[w];const auto& boundary=model.boundaries.at(static_cast<std::size_t>(wall.side));
            physical.walls[w].area*=data->gas_fractions.at(wall.cell);const auto kind=wall_kind(boundary);
            const bool owned_wall=wall.cell>=owned.begin&&wall.cell-owned.begin<owned.count;
            walls.push_back({kind,boundary.kinetic_electrons=="secondary_emission"||!owned_wall?std::nullopt:boundary.incoming_electrons});
            if(physical.walls[w].area<=0)continue;
            require(boundary.kind!=spatial::BoundaryKind::Insulating||kind==KineticWall::Specular,"kinetic wall exchange requires an electrical charge owner");
            KineticBoundaryRecord record;record.kinetic_face=kinetic_index++;record.owner=KineticBoundaryOwner::ExteriorWall;record.geometric_wall=w;record.side=wall.side;record.gas_cell=wall.cell;data->records.push_back(std::move(record));
        }
        data->kinetic_mesh=make_kinetic_mesh(physical,volumes,areas,walls,contacts);
        require(kinetic_index==data->kinetic_mesh.faces.size(),"kinetic/static face ownership mismatch");
        for(const auto& record:data->records)if(record.owner==KineticBoundaryOwner::ExteriorWall){
            const auto& boundary=model.boundaries.at(static_cast<std::size_t>(record.side));if(boundary.kinetic_electrons!="secondary_emission")continue;
            if(record.gas_cell<owned.begin||record.gas_cell-owned.begin>=owned.count)continue;
            require(boundary.incoming_electrons.has_value()&&!boundary.secondary_emission.empty(),"secondary wall requires authored incoming shape and yields");
            const auto& grid=boundary.incoming_electrons->grid;const auto& expected=data->coupling.grid;
            require(grid.cells==expected.cells&&grid.legendre_terms==expected.legendre_terms&&grid.max_energy_ev==expected.max_energy_ev&&grid.power==expected.power,"secondary template grid differs from kinetic state");
            const auto normalized=spatial::boundary::normalize_incoming(*boundary.incoming_electrons,data->kinetic_mesh.faces[record.kinetic_face].normal);
            data->emission_templates.push_back({record.kinetic_face,record.geometric_wall,normalized.per_unit_number_flux,normalized.mean_incoming_energy_eV});
        }
        if(geometry.axisymmetric)data->inverse_radius=rz_geometry(model.mesh).inverse_radius_m1;
        data->moment_offsets.assign(count+1,0);
        for(const auto& face:data->kinetic_mesh.faces)data->moment_offsets[face.left+1]+=2;
        for(std::size_t c=0;c<count;++c)data->moment_offsets[c+1]+=data->moment_offsets[c];
        // A mesh may contain no gas anywhere. Retain one unused scalar on the
        // last cell's owner so the collective halo still has a valid partition;
        // no physical face moment or distribution is introduced.
        if(data->moment_offsets.back()==0)data->moment_offsets.back()=1;
        auto next=data->moment_offsets;data->face_moment_ids.resize(data->kinetic_mesh.faces.size());
        for(std::size_t f=0;f<data->kinetic_mesh.faces.size();++f){const auto c=data->kinetic_mesh.faces[f].left;data->face_moment_ids[f]=next[c];next[c]+=2;}
    }catch(const std::exception& exception){error=exception.what();}
    control.collective_require(error);
    const auto own_cell=[&](std::size_t cell){return cell>=owned.begin&&cell-owned.begin<owned.count;};
    std::vector<backend::GlobalIndex> requested;
    for(const auto& record:data->records)if(record.owner==KineticBoundaryOwner::PhaseContact&&own_cell(record.receiving_cell)&&!own_cell(record.gas_cell)){
        requested.push_back(data->face_moment_ids[record.kinetic_face]);requested.push_back(data->face_moment_ids[record.kinetic_face]+1);
    }
    const auto begin=data->moment_offsets[owned.begin],end=data->moment_offsets[owned.begin+owned.count];
    data->moments.emplace(backend::RowPartition{data->moment_offsets.back(),begin,static_cast<std::size_t>(end-begin)},requested,execution);
    impl_=std::move(data);
}
const KineticMesh& OwnedKineticAdapter::mesh() const{return impl_->kinetic_mesh;}
const std::vector<KineticBoundaryRecord>& OwnedKineticAdapter::boundary_records() const{return impl_->records;}
const std::vector<KineticEmissionTemplate>& OwnedKineticAdapter::emission_templates() const{return impl_->emission_templates;}
OwnedKineticTrial OwnedKineticAdapter::evaluate(std::span<const chemistry::Mechanism> mechanisms,
    std::span<const chemistry::State> candidates,std::span<const chemistry::Environment> environments,std::span<const Vector3> fields,
    std::span<const SphericalEedfState> previous,const SpatialKineticOptions& time_options,std::span<const SphericalEedfState> older,
    std::span<const KineticIncomingOverride> incoming) const{
    const auto& data=*impl_;const auto& halo=*data.moments;const auto owned=data.owned;
    std::vector<SpatialKineticCell> cells;auto mesh=data.kinetic_mesh;auto options=time_options;
    std::string error;
    try{
        require(mechanisms.size()==owned.count&&candidates.size()==owned.count&&environments.size()==owned.count&&fields.size()==owned.count&&previous.size()==owned.count,"owned kinetic trial dimensions differ");
        cells.resize(owned.count);
        for(std::size_t c=0;c<owned.count;++c){cells[c].candidate_state=candidates[c];cells[c].environment=environments[c];cells[c].electric_field_V_m=fields[c];
            if(data.gas_fractions[owned.begin+c]>0){cells[c].mechanism=&mechanisms[c];cells[c].coupling=&data.coupling;}}
        std::set<std::size_t> overridden;
        for(const auto& override:incoming){
            require(override.kinetic_face<mesh.faces.size()&&overridden.insert(override.kinetic_face).second,"invalid/duplicate incoming face override");auto& face=mesh.faces[override.kinetic_face];
            require(face.right==std::numeric_limits<std::size_t>::max()&&face.left>=owned.begin&&face.left-owned.begin<owned.count,"incoming override must belong to an owned gas wall/contact");
            require(face.wall!=KineticWall::Specular,"incoming override cannot silently replace specular reflection");
            override.incoming.validate();face.wall=KineticWall::PrescribedIncoming;face.incoming=override.incoming;
        }
        for(const auto& source:data.emission_templates){const auto cell=mesh.faces[source.kinetic_face].left;if(cell>=owned.begin&&cell-owned.begin<owned.count)require(overridden.contains(source.kinetic_face),"owned secondary wall requires a candidate incident-ion flux override, including zero flux");}
        options.grid=data.coupling.grid;options.execution=data.execution;options.inverse_radius_m1=data.inverse_radius;
    }catch(const std::exception& exception){error=exception.what();}
    halo.collective_require(error);
    OwnedKineticTrial result;
    result.kinetic=advance_distributed_spatial_kinetics(mesh,{static_cast<backend::GlobalIndex>(mesh.cell_volumes_m3.size()),owned.begin,owned.count},cells,previous,options,older);
    std::vector<double> local_moments(halo.partition().local_rows,0);
    for(std::size_t f=0;f<result.kinetic.face_global_ids.size();++f){
        const auto global=result.kinetic.face_global_ids[f];const auto& face=mesh.faces[global];
        if(face.left<owned.begin||face.left-owned.begin>=owned.count)continue;
        const auto local=static_cast<std::size_t>(data.face_moment_ids[global]-halo.partition().row_begin);
        local_moments[local]=face.area_m2*result.kinetic.face_particle_flux_m2_s[f];
        local_moments[local+1]=1.602176634e-19*face.area_m2*result.kinetic.face_energy_flux_ev_m2_s[f];
    }
    const auto received=halo.exchange(local_moments);
    const auto moment=[&](backend::GlobalIndex id){const auto compact=halo.compact_index(id);return compact<local_moments.size()?local_moments[compact]:received[compact-local_moments.size()];};
    for(const auto& record:data.records){
        const bool gas=record.gas_cell>=owned.begin&&record.gas_cell-owned.begin<owned.count;
        const bool receiver=record.receiving_cell>=owned.begin&&record.receiving_cell-owned.begin<owned.count;
        if(!(gas||receiver))continue;
        const bool energy=record.energy_cell>=owned.begin&&record.energy_cell-owned.begin<owned.count;
        const auto id=data.face_moment_ids[record.kinetic_face];result.boundary_moments.push_back({record,moment(id),moment(id+1),gas,receiver,energy});
    }
    return result;
}
}
