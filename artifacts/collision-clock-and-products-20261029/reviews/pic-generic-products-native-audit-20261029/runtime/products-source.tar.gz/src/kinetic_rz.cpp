#include "raikou/kinetic_rz.h"
#include "raikou/spatial_mesh.h"
#include <algorithm>
#include <cmath>
#include <limits>
#include <map>
#include <numbers>
#include <stdexcept>
#include <string>

namespace raikou::kinetics {
namespace {
[[noreturn]] void invalid(const std::string& value) { throw std::invalid_argument("cylindrical kinetic geometry: " + value); }
constexpr double charge = 1.602176634e-19, mass = 9.1093837015e-31;
void validate_grid(const EedfGrid& grid) {
    if (grid.cells < 16 || grid.cells > 6000 || grid.legendre_terms < 2 || grid.legendre_terms > 30 ||
        !(grid.max_energy_ev > 0 && std::isfinite(grid.max_energy_ev)) || !(grid.power >= 1 && grid.power <= 4)) invalid("invalid energy/angular grid");
}
bool same_grid(const EedfGrid& a, const EedfGrid& b) {
    return a.cells == b.cells && a.legendre_terms == b.legendre_terms && a.max_energy_ev == b.max_energy_ev && a.power == b.power;
}
struct AngularEntry { std::size_t output, input; double value; bool output_even; };
std::vector<AngularEntry> angular_entries(int terms) {
    std::vector<AngularEntry> entries;
    const auto nodes = spherical_quadrature(terms);
    for (int l = 1; l < terms; ++l) for (int m = -l; m <= l; ++m) {
        if (m == 0) continue; // d_beta R_l0 is exactly zero, not a quadrature zero.
        const int a = std::abs(m);
        const auto output = spherical_index(l, m), differentiated = spherical_index(l, -m);
        // -d_beta R_lm = +m R_l,-m (m>0), and m R_l,-m (m<0).
        // Multiplication by sin(beta) preserves the original real sine/cosine
        // family and couples only |m|+-1 and l+-1.
        for (int other_l : {l - 1, l + 1}) {
            if (other_l < 0 || other_l >= terms) continue;
            for (int other_a : {a - 1, a + 1}) {
                if (other_a > other_l || (m < 0 && other_a == 0)) continue;
                const int other_m = m < 0 ? -other_a : other_a;
                const auto input = spherical_index(other_l, other_m);
                double coefficient = 0;
                for (const auto& node : nodes)
                    coefficient += static_cast<double>(m) * node.weight * node.basis[differentiated] * node.direction[1] * node.basis[input];
                if (!std::isfinite(coefficient)) invalid("nonfinite angular geometry coefficient");
                if (coefficient != 0) entries.push_back({output, input, coefficient, l % 2 == 0});
            }
        }
    }
    return entries;
}
struct Radial {
    std::size_t cells;
    std::vector<double> edge, center, cell_mass, dual_mass;
    explicit Radial(const EedfGrid& grid) : cells(static_cast<std::size_t>(grid.cells)),
        edge(cells + 1), center(cells), cell_mass(cells), dual_mass(cells) {
        for (std::size_t i = 0; i <= cells; ++i) edge[i] = grid.max_energy_ev * std::pow(static_cast<double>(i) / grid.cells, grid.power);
        for (std::size_t i = 0; i < cells; ++i) {
            center[i] = .5 * (edge[i] + edge[i + 1]);
            cell_mass[i] = 2. / 3 * (std::pow(edge[i + 1], 1.5) - std::pow(edge[i], 1.5));
        }
        for (std::size_t i = 0; i + 1 < cells; ++i)
            dual_mass[i] = 2. / 3 * (std::pow(center[i + 1], 1.5) - std::pow(center[i], 1.5));
    }
    template<class Function> void overlap(std::size_t i, bool even, Function&& add) const {
        if (even) {
            if (i > 0) add(i - 1, edge[i] * (edge[i] - center[i - 1]) / cell_mass[i]);
            if (i + 1 < cells) add(i, edge[i + 1] * (center[i + 1] - edge[i + 1]) / cell_mass[i]);
        } else if (i + 1 < cells) {
            const double energy = edge[i + 1];
            add(i, energy * (center[i + 1] - energy) / dual_mass[i]);
            add(i + 1, energy * (energy - center[i]) / dual_mass[i]);
        }
    }
};
void validate_inverse(double inverse) {
    if (!(inverse >= 0 && std::isfinite(inverse))) invalid("inverse radii must be finite and nonnegative");
}
} // namespace

RzGeometry make_rz_geometry(std::span<const double> areas, std::span<const double> volumes) {
    if (areas.empty() || areas.size() != volumes.size()) invalid("meridional area/volume dimensions differ or are empty");
    RzGeometry result; result.inverse_radius_m1.reserve(areas.size());
    for (std::size_t c = 0; c < areas.size(); ++c) {
        if (!(areas[c] > 0 && std::isfinite(areas[c]) && volumes[c] > 0 && std::isfinite(volumes[c]))) invalid("areas and physical volumes must be finite and positive");
        const double inverse = (areas[c] / volumes[c]) * (2 * std::numbers::pi);
        validate_inverse(inverse); result.inverse_radius_m1.push_back(inverse);
    }
    return result;
}

RzGeometry rz_geometry(const spatial::Mesh& mesh) {
    if (mesh.dimension != 2 || !mesh.axisymmetric) invalid("mesh must be axisymmetric 2D with x=r,y=z");
    const auto physical = spatial::mesh::geometry(mesh);
    auto meridional = mesh; meridional.axisymmetric = false; meridional.extent_m[2] = 1;
    const auto planar = spatial::mesh::geometry(meridional);
    return make_rz_geometry(planar.volume, physical.volume);
}

backend::CsrMatrix rz_geometry_matrix(const EedfGrid& grid, double inverse) {
    validate_grid(grid); validate_inverse(inverse);
    const auto stride = static_cast<std::size_t>(grid.legendre_terms * grid.legendre_terms);
    const Radial radial(grid);
    const auto angular = angular_entries(grid.legendre_terms);
    const double scale = inverse * std::sqrt(2 * charge / mass);
    backend::CsrMatrix matrix; matrix.rows = radial.cells * stride;
    std::vector<std::map<int, double>> rows(matrix.rows);
    if (inverse > 0) for (std::size_t i = 0; i < radial.cells; ++i) for (const auto& entry : angular)
        radial.overlap(i, entry.output_even, [&](std::size_t j, double velocity) {
            const double coefficient = scale * entry.value * velocity;
            if (!std::isfinite(coefficient)) invalid("geometry operator coefficient overflow");
            if (coefficient != 0) rows[i * stride + entry.output][static_cast<int>(j * stride + entry.input)] += coefficient;
        });
    matrix.offsets.reserve(matrix.rows + 1); matrix.offsets.push_back(0);
    for (const auto& row : rows) {
        for (const auto& [column, coefficient] : row) { matrix.columns.push_back(column); matrix.values.push_back(coefficient); }
        matrix.offsets.push_back(matrix.values.size());
    }
    return matrix;
}

std::vector<std::vector<double>> rz_geometry_rhs(const RzGeometry& geometry,
    const std::vector<SphericalEedfState>& states, std::size_t threads) {
    if (states.empty()) invalid("at least one kinetic cell is required");
    if (geometry.inverse_radius_m1.size() != 1 && geometry.inverse_radius_m1.size() != states.size()) invalid("inverse radius count must be scalar or match cells");
    for (double inverse : geometry.inverse_radius_m1) validate_inverse(inverse);
    const auto& grid = states.front().grid;
    for (const auto& state : states) {
        state.validate();
        if (!same_grid(grid, state.grid) || state.time_s != states.front().time_s) invalid("cells must share one energy/angular grid and time");
    }
    const auto stride = static_cast<std::size_t>(grid.legendre_terms * grid.legendre_terms);
    const Radial radial(grid);
    const auto angular = angular_entries(grid.legendre_terms);
    const double gamma = std::sqrt(2 * charge / mass);
    std::vector<std::vector<double>> result(states.size(), std::vector<double>(radial.cells * stride));
    backend::parallel_for(states.size(), threads, [&](std::size_t cell) {
        const double inverse = geometry.inverse_radius_m1[geometry.inverse_radius_m1.size() == 1 ? 0 : cell];
        if (inverse == 0) return;
        const auto& input = states[cell].density_modes;
        auto& output = result[cell];
        for (std::size_t i = 0; i < radial.cells; ++i) for (const auto& entry : angular) {
            double velocity_weighted = 0;
            radial.overlap(i, entry.output_even, [&](std::size_t j, double velocity) { velocity_weighted += velocity * input[j * stride + entry.input]; });
            output[i * stride + entry.output] += gamma * inverse * entry.value * velocity_weighted;
        }
        for (double value : output) if (!std::isfinite(value)) invalid("geometry RHS overflow");
    });
    return result;
}

} // namespace raikou::kinetics
