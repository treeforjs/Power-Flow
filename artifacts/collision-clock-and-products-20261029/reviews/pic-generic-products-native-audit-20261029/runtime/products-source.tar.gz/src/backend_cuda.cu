#include "raikou/backend.h"
#include <cuda_runtime.h>
#include <stdexcept>
#include <memory>
namespace raikou::backend {
namespace {
void checked(cudaError_t e) { if(e!=cudaSuccess) throw std::runtime_error(cudaGetErrorString(e)); }
template<class T> struct DeviceBuffer {
    T* data{};
    explicit DeviceBuffer(std::size_t n) { checked(cudaMalloc(reinterpret_cast<void**>(&data),std::max(std::size_t{1},n)*sizeof(T))); }
    ~DeviceBuffer() { cudaFree(data); }
    DeviceBuffer(const DeviceBuffer&)=delete;
    DeviceBuffer& operator=(const DeviceBuffer&)=delete;
};
__global__ void csr_kernel(std::size_t first,std::size_t last,const std::size_t* offsets,const int* columns,const double* values,const double* x,double* y) {
    const auto row=first+static_cast<std::size_t>(blockIdx.x)*blockDim.x+threadIdx.x;
    if(row>=last)return;
    double sum=0;
    for(auto k=offsets[row];k<offsets[row+1];++k)sum+=values[k]*x[columns[k]];
    y[row]=sum;
}
struct CudaCsrWorkspace {
    std::size_t rows,first,last;
    DeviceBuffer<std::size_t> offsets;
    DeviceBuffer<int> columns;
    DeviceBuffer<double> values,dx,dy;
    CudaCsrWorkspace(const CsrMatrix& A,std::size_t begin,std::size_t end):
        rows(A.rows),first(begin),last(end),offsets(A.offsets.size()),columns(A.columns.size()),
        values(A.values.size()),dx(A.rows),dy(A.rows) {
        checked(cudaMemcpy(offsets.data,A.offsets.data(),A.offsets.size()*sizeof(std::size_t),cudaMemcpyHostToDevice));
        checked(cudaMemcpy(columns.data,A.columns.data(),A.columns.size()*sizeof(int),cudaMemcpyHostToDevice));
        checked(cudaMemcpy(values.data,A.values.data(),A.values.size()*sizeof(double),cudaMemcpyHostToDevice));
    }
    std::vector<double> apply(std::span<const double> x) {
        std::vector<double> y(rows);
        if(first==last)return y;
        checked(cudaMemcpy(dx.data,x.data(),x.size()*sizeof(double),cudaMemcpyHostToDevice));
        csr_kernel<<<static_cast<unsigned>((last-first+255)/256),256>>>(first,last,offsets.data,columns.data,values.data,dx.data,dy.data);
        checked(cudaGetLastError());
        checked(cudaMemcpy(y.data()+first,dy.data+first,(last-first)*sizeof(double),cudaMemcpyDeviceToHost));
        return y;
    }
};
}
bool cuda_runtime_available() { int count{}; return cudaGetDeviceCount(&count)==cudaSuccess && count>0; }
std::function<std::vector<double>(std::span<const double>)> cuda_csr_operator(const CsrMatrix& A,std::size_t first,std::size_t last) {
    if(!cuda_runtime_available())throw std::runtime_error("CUDA device is unavailable; no CPU fallback");
    auto op=std::make_shared<CudaCsrWorkspace>(A,first,last);
    return [op](std::span<const double> x){return op->apply(x);};
}
}
