#include "raikou/chemistry.h"
#include "raikou/chemistry_device.h"
#include "raikou/chemistry_distributed.h"
#include "chemistry_energy.h"
#include "chemistry_geometry.h"
#include "json_collective.h"

#include <algorithm>
#include <cctype>
#include <cmath>
#include <cstdlib>
#include <limits>
#include <set>
#include <stdexcept>
#include <utility>

namespace raikou::chemistry {
namespace {
constexpr double elementary_charge = 1.602176634e-19;
constexpr double kelvin_per_eV = 11604.518121550082;
constexpr double atomic_mass_kg = 1.66053906892e-27;
constexpr double electron_mass_kg = 9.1093837139e-31;

[[noreturn]] void fail(const std::string& message) {
    throw std::invalid_argument("chemistry: " + message);
}

bool finite(double value) { return std::isfinite(value); }

double derived_mass(const Species& species) {
    const std::map<std::string, double> masses{
        {"H", 1.008}, {"D", 2.01410177812}, {"He", 4.002602},
        {"C", 12.011}, {"N", 14.007}, {"O", 15.999}, {"Ar", 39.948},
        {"F", 18.998403162}, {"Na", 22.98976928}, {"Cl", 35.45}};
    double result = -static_cast<double>(species.charge) * electron_mass_kg;
    for (const auto& [element, count] : species.elements) {
        const auto found = masses.find(element);
        if (found == masses.end()) {
            fail("mass_kg must be supplied for element " + element);
        }
        result += found->second * static_cast<double>(count) * atomic_mass_kg;
    }
    return result;
}

std::string kind_name(RateKind kind) {
    switch (kind) {
    case RateKind::Constant: return "constant";
    case RateKind::Arrhenius: return "arrhenius";
    case RateKind::ElectronTemperatureTable: return "electron_temperature_table";
    case RateKind::ElectronEedf: return "electron_eedf";
    case RateKind::Expression: return "expression";
    case RateKind::Parameter: return "parameter";
    }
    fail("unknown rate kind");
}

RateKind parse_kind(const std::string& value) {
    if (value == "constant") return RateKind::Constant;
    if (value == "arrhenius") return RateKind::Arrhenius;
    if (value == "electron_temperature_table") return RateKind::ElectronTemperatureTable;
    if (value == "electron_eedf") return RateKind::ElectronEedf;
    if (value == "expression") return RateKind::Expression;
    if (value == "parameter") return RateKind::Parameter;
    fail("unknown rate type: " + value);
}

// A closed scalar expression language. It intentionally has no variable
// assignment, indexing, file access, Python callbacks, or dynamic evaluation.
class Expression {
public:
    Expression(std::string_view formula, const std::map<std::string, double>& variables,
               bool syntax_only = false)
        : formula_(formula), variables_(variables), syntax_only_(syntax_only) {
        if (formula.empty() || formula.size() > 4096) fail("expression length must be 1..4096");
    }

    double evaluate() {
        const double result = sum();
        space();
        if (position_ != formula_.size()) fail("unexpected expression token at " + std::to_string(position_));
        if (!syntax_only_ && !finite(result)) fail("non-finite expression result");
        return result;
    }

private:
    std::string_view formula_;
    const std::map<std::string, double>& variables_;
    std::size_t position_ = 0;
    std::size_t depth_ = 0;
    bool syntax_only_ = false;

    void space() {
        while (position_ < formula_.size() && std::isspace(static_cast<unsigned char>(formula_[position_])) != 0) ++position_;
    }
    bool take(char token) {
        space();
        if (position_ < formula_.size() && formula_[position_] == token) { ++position_; return true; }
        return false;
    }
    double sum() {
        double value = product();
        for (;;) {
            if (take('+')) value += product();
            else if (take('-')) value -= product();
            else return value;
        }
    }
    double product() {
        double value = power();
        for (;;) {
            if (take('*')) value *= power();
            else if (take('/')) { const double divisor = power(); value = syntax_only_ ? 1.0 : value / divisor; }
            else return value;
        }
    }
    double power() {
        const double value = unary();
        if (take('^')) {
            if (++depth_ > 64) fail("expression nesting exceeds 64");
            const double exponent = power();
            --depth_;
            return syntax_only_ ? 1.0 : std::pow(value, exponent);
        }
        return value;
    }
    double unary() {
        if (++depth_ > 64) fail("expression nesting exceeds 64");
        double result = 0.0;
        if (take('+')) result = unary();
        else if (take('-')) result = -unary();
        else result = primary();
        --depth_;
        return result;
    }
    double primary() {
        space();
        if (take('(')) {
            const double value = sum();
            if (!take(')')) fail("expression requires closing parenthesis");
            return value;
        }
        if (position_ >= formula_.size()) fail("incomplete expression");
        const unsigned char first = static_cast<unsigned char>(formula_[position_]);
        if (std::isdigit(first) != 0 || formula_[position_] == '.') {
            const std::string remaining(formula_.substr(position_));
            char* end = nullptr;
            const double value = std::strtod(remaining.c_str(), &end);
            if (end == remaining.c_str() || !finite(value)) fail("invalid expression number");
            position_ += static_cast<std::size_t>(end - remaining.c_str());
            return value;
        }
        if (std::isalpha(first) == 0 && formula_[position_] != '_') fail("invalid expression token");
        const std::size_t start = position_++;
        while (position_ < formula_.size()) {
            const unsigned char character = static_cast<unsigned char>(formula_[position_]);
            if (std::isalnum(character) == 0 && formula_[position_] != '_') break;
            ++position_;
        }
        const std::string name(formula_.substr(start, position_ - start));
        if (!take('(')) {
            const auto found = variables_.find(name);
            if (found != variables_.end()) return found->second;
            if (syntax_only_) return 1.0;
            fail("unknown expression variable: " + name);
        }
        const double first_argument = sum();
        if (take(',')) {
            const double second_argument = sum();
            if (!take(')')) fail("function requires closing parenthesis");
            if (name == "pow") return syntax_only_ ? 1.0 : std::pow(first_argument, second_argument);
            if (name == "min") return std::min(first_argument, second_argument);
            if (name == "max") return std::max(first_argument, second_argument);
            fail("unknown binary function: " + name);
        }
        if (!take(')')) fail("function requires closing parenthesis");
        if (name == "exp") return syntax_only_ ? 1.0 : std::exp(first_argument);
        if (name == "log") return syntax_only_ ? 1.0 : std::log(first_argument);
        if (name == "sqrt") return syntax_only_ ? 1.0 : std::sqrt(first_argument);
        if (name == "abs") return std::abs(first_argument);
        fail("unknown unary function: " + name);
    }
};

double temperature(const RateLaw& law, const Environment& environment) {
    if (law.temperature == "gas") return environment.gas_temperature_K;
    if (law.temperature == "liquid") return environment.liquid_temperature_K;
    if (law.temperature == "electron") return environment.electron_temperature_eV * kelvin_per_eV;
    fail("unknown temperature selector: " + law.temperature);
}

std::string external_key(const Reaction& reaction) {
    return reaction.rate.key.empty() ? reaction.collision_label : reaction.rate.key;
}

double coefficient(const Reaction& reaction, const Environment& environment) {
    const auto& law = reaction.rate;
    const double thermal = temperature(law, environment);
    if ((law.minimum_temperature_K > 0.0 && thermal < law.minimum_temperature_K) ||
        (law.maximum_temperature_K > 0.0 && thermal > law.maximum_temperature_K)) {
        fail("reaction " + reaction.id + " is outside its temperature validity range");
    }
    double result = 0.0;
    switch (law.kind) {
    case RateKind::Constant:
        result = law.A;
        break;
    case RateKind::Arrhenius:
        if (!(thermal > 0.0)) fail("Arrhenius temperature must be positive");
        result = law.A * std::pow(thermal / law.reference_temperature_K, law.exponent) *
                 std::exp(-law.activation_temperature_K / thermal);
        break;
    case RateKind::ElectronTemperatureTable: {
        const double energy = environment.electron_temperature_eV;
        if (energy < law.temperatures_eV.front() || energy > law.temperatures_eV.back()) {
            fail("reaction " + reaction.id + " is outside its electron-temperature table");
        }
        const auto upper = std::lower_bound(law.temperatures_eV.begin(), law.temperatures_eV.end(), energy);
        const auto index = static_cast<std::size_t>(upper - law.temperatures_eV.begin());
        if (index == 0 || *upper == energy) result = law.coefficients[index];
        else {
            const double fraction = (energy - law.temperatures_eV[index - 1]) /
                                    (law.temperatures_eV[index] - law.temperatures_eV[index - 1]);
            result = law.coefficients[index - 1] + fraction * (law.coefficients[index] - law.coefficients[index - 1]);
        }
        break;
    }
    case RateKind::ElectronEedf: {
        const std::string key = external_key(reaction);
        const auto found = environment.electron_rates.find(key);
        if (found == environment.electron_rates.end()) fail("missing EEDF rate coefficient: " + key);
        result = found->second;
        break;
    }
    case RateKind::Parameter: {
        const auto found = environment.parameters.find(law.key);
        if (found == environment.parameters.end()) fail("missing rate parameter: " + law.key);
        result = found->second;
        break;
    }
    case RateKind::Expression: {
        auto variables = environment.parameters;
        for (const auto& [name, value] : law.constants) variables[name] = value;
        variables["Tgas_K"] = environment.gas_temperature_K;
        variables["Tliquid_K"] = environment.liquid_temperature_K;
        variables["Te_eV"] = environment.electron_temperature_eV;
        variables["Te_K"] = environment.electron_temperature_eV * kelvin_per_eV;
        variables["pi"] = 3.14159265358979323846;
        result = Expression(law.expression, variables).evaluate();
        break;
    }
    }
    if (!finite(result) || result < 0.0) fail("invalid rate coefficient for reaction " + reaction.id);
    return result;
}

std::vector<Term> terms_from_json(const Json& input, const Mechanism& mechanism) {
    if (!input.is_object()) fail("reaction terms must be an object of species:coefficient");
    std::vector<Term> result;
    for (const auto& [name, count] : input.items()) result.push_back({mechanism.species_index(name), count.get<double>()});
    return result;
}

Json terms_to_json(const std::vector<Term>& terms, const Mechanism& mechanism) {
    Json result = Json::object();
    for (const auto& term : terms) result[mechanism.species.at(term.species).id] = term.coefficient;
    return result;
}

State parse_state(const Json& value, const Mechanism& mechanism) {
    State result;
    result.densities_m3.resize(mechanism.species.size(), 0.0);
    const Json& densities = value.contains("densities_m3") ? value.at("densities_m3") : value;
    if (densities.is_array()) result.densities_m3 = densities.get<std::vector<double>>();
    else if (densities.is_object()) {
        for (const auto& [name, density] : densities.items()) result.densities_m3[mechanism.species_index(name)] = density.get<double>();
    } else fail("densities_m3 must be a species mapping or vector");
    return result;
}

Json state_json(const State& state, const Mechanism& mechanism) {
    Json densities = Json::object();
    for (std::size_t i = 0; i < mechanism.species.size(); ++i) densities[mechanism.species[i].id] = state.densities_m3[i];
    return {{"densities_m3", std::move(densities)}};
}

Environment parse_environment(const Json& value) {
    Environment result;
    result.gas_temperature_K = value.value("gas_temperature_K", result.gas_temperature_K);
    result.electron_temperature_eV = value.value("electron_temperature_eV", result.electron_temperature_eV);
    result.liquid_temperature_K = value.value("liquid_temperature_K", result.liquid_temperature_K);
    result.electron_rates = value.value("electron_rates", result.electron_rates);
    result.parameters = value.value("parameters", result.parameters);
    result.phase_volumes_m3 = value.value("phase_volumes_m3", result.phase_volumes_m3);
    result.interface_areas_m2 = value.value("interface_areas_m2", result.interface_areas_m2);
    return result;
}

void validate_environment_impl(const Environment& environment) {
    if (!finite(environment.gas_temperature_K) || environment.gas_temperature_K <= 0.0 ||
        !finite(environment.liquid_temperature_K) || environment.liquid_temperature_K <= 0.0 ||
        !finite(environment.electron_temperature_eV) || environment.electron_temperature_eV < 0.0) {
        fail("temperatures must be finite and positive (electron temperature may be zero)");
    }
    const auto positive_map = [](const std::map<std::string, double>& values, const std::string& label) {
        for (const auto& [name, value] : values) if (!finite(value) || value <= 0.0) fail(label + " must be positive: " + name);
    };
    positive_map(environment.phase_volumes_m3, "phase volume");
    positive_map(environment.interface_areas_m2, "interface area");
    for (const auto& [name, value] : environment.parameters) if (!finite(value)) fail("non-finite parameter: " + name);
    for (const auto& [name, value] : environment.electron_rates) if (!finite(value) || value < 0.0) fail("invalid electron rate: " + name);
}

double phase_volume(const std::string& phase, const Environment& environment, bool required) {
    const auto found = environment.phase_volumes_m3.find(phase);
    if (found != environment.phase_volumes_m3.end()) return found->second;
    if (required) fail("cross-phase reaction requires phase_volumes_m3." + phase);
    return 1.0;
}

Evaluation evaluate_validated(const Mechanism& mechanism, const State& state, const Environment& environment) {
    const std::size_t count = mechanism.species.size();
    if (state.densities_m3.size() != count) fail("state density vector has the wrong size");
    for (std::size_t i = 0; i < count; ++i) {
        if (!finite(state.densities_m3[i])) fail("non-finite density: " + mechanism.species[i].id);
        if (mechanism.species[i].nonnegative && state.densities_m3[i] < 0.0) fail("negative density: " + mechanism.species[i].id);
    }
    Evaluation result;
    result.production_rates_m3_s.assign(count, 0.0);
    result.jacobian_row_major.assign(count * count, 0.0);
    result.reaction_rates_m3_s.reserve(mechanism.reactions.size());
    result.rate_coefficients.reserve(mechanism.reactions.size());
    for (const auto& reaction : mechanism.reactions) {
        const auto required_volumes = detail::required_phase_volumes(reaction, mechanism);
        for (const auto& phase : required_volumes) (void)phase_volume(phase, environment, true);
        const bool cross_phase = !required_volumes.empty();
        double measure = 1.0;
        if (reaction.basis_interface.empty()) measure = phase_volume(reaction.basis_phase, environment, cross_phase);
        else {
            const auto area = environment.interface_areas_m2.find(reaction.basis_interface);
            if (area == environment.interface_areas_m2.end()) fail("missing interface area: " + reaction.basis_interface);
            measure = area->second;
        }
        const double k = coefficient(reaction, environment);
        const auto& orders = reaction.explicit_orders ? reaction.orders : reaction.reactants;
        double extent = k;
        for (const auto& order : orders) extent *= std::pow(state.densities_m3[order.species], order.coefficient);
        if (!finite(extent)) fail("non-finite reaction progress: " + reaction.id);
        result.rate_coefficients.push_back(k);
        result.reaction_rates_m3_s.push_back(extent);
        std::vector<double> derivative(count, 0.0);
        for (const auto& differentiated : orders) {
            if (differentiated.coefficient == 0.0) continue;
            double value = k * differentiated.coefficient;
            for (const auto& order : orders) {
                const double exponent = order.coefficient - (order.species == differentiated.species ? 1.0 : 0.0);
                if (exponent != 0.0) value *= std::pow(state.densities_m3[order.species], exponent);
            }
            if (!finite(value)) fail("singular rate derivative: " + reaction.id);
            derivative[differentiated.species] += value;
        }
        const auto add_terms = [&](const std::vector<Term>& terms, double sign) {
            for (const auto& term : terms) {
                const double volume = phase_volume(mechanism.species[term.species].phase, environment, cross_phase);
                const double factor = sign * term.coefficient * measure / volume;
                result.production_rates_m3_s[term.species] += factor * extent;
                for (std::size_t j = 0; j < count; ++j) result.jacobian_row_major[term.species * count + j] += factor * derivative[j];
            }
        };
        add_terms(reaction.reactants, -1.0);
        add_terms(reaction.products, 1.0);
        for (const auto& [reservoir, energy] : reaction.energy_eV_per_event) {
            const auto key = detail::energy_reservoir_key(reaction, reservoir);
            const auto phase = key.substr(0, key.find('/'));
            result.energy_sources_W_m3[key] += energy * elementary_charge * extent * measure / phase_volume(phase, environment, cross_phase);
        }
    }
    for (const double value : result.production_rates_m3_s) if (!finite(value)) fail("production rate overflow");
    for (const double value : result.jacobian_row_major) if (!finite(value)) fail("Jacobian overflow");
    for (const auto& [name, value] : result.energy_sources_W_m3) if (!finite(value)) fail("energy source overflow: " + name);
    return result;
}

std::vector<double> solve_dense(std::vector<double> matrix, std::vector<double> rhs) {
    const std::size_t count = rhs.size();
    for (std::size_t column = 0; column < count; ++column) {
        std::size_t pivot = column;
        for (std::size_t row = column + 1; row < count; ++row) {
            if (std::abs(matrix[row * count + column]) > std::abs(matrix[pivot * count + column])) pivot = row;
        }
        const double diagonal = matrix[pivot * count + column];
        if (!finite(diagonal) || std::abs(diagonal) < std::numeric_limits<double>::min()) fail("singular implicit chemistry Jacobian");
        if (pivot != column) {
            for (std::size_t j = column; j < count; ++j) std::swap(matrix[pivot * count + j], matrix[column * count + j]);
            std::swap(rhs[pivot], rhs[column]);
        }
        for (std::size_t row = column + 1; row < count; ++row) {
            const double factor = matrix[row * count + column] / matrix[column * count + column];
            matrix[row * count + column] = 0.0;
            for (std::size_t j = column + 1; j < count; ++j) matrix[row * count + j] -= factor * matrix[column * count + j];
            rhs[row] -= factor * rhs[column];
        }
    }
    std::vector<double> result(count, 0.0);
    for (std::size_t reverse = count; reverse > 0; --reverse) {
        const std::size_t row = reverse - 1;
        double value = rhs[row];
        for (std::size_t j = row + 1; j < count; ++j) value -= matrix[row * count + j] * result[j];
        result[row] = value / matrix[row * count + row];
        if (!finite(result[row])) fail("non-finite implicit chemistry correction");
    }
    return result;
}

std::vector<double> solve_linear(std::vector<double> matrix, std::vector<double> rhs,
                                 const AdvanceOptions& options) {
    const std::size_t count = rhs.size();
    if (!options.execution.mpi && options.execution.device == "cpu" &&
        options.execution.threads <= 1 && count < 64) return solve_dense(std::move(matrix), std::move(rhs));
    backend::CsrMatrix csr;
    csr.rows = count;
    csr.offsets.push_back(0);
    for (std::size_t row = 0; row < count; ++row) {
        for (std::size_t column = 0; column < count; ++column) {
            const double value = matrix[row * count + column];
            if (value != 0.0) {
                csr.columns.push_back(static_cast<int>(column));
                csr.values.push_back(value);
            }
        }
        csr.offsets.push_back(csr.values.size());
    }
    const auto result = backend::solve_csr(csr, rhs, options.execution);
    if (!result.converged) fail("implicit chemistry linear solve did not converge");
    return result.solution;
}

bool nonnegative(const State& state, const std::vector<bool>& mask) {
    for (std::size_t i = 0; i < mask.size(); ++i) if (!finite(state.densities_m3[i]) || (mask[i] && state.densities_m3[i] < 0.0)) return false;
    return true;
}

double residual(const State& start, const State& trial, const Evaluation& evaluation, double dt,
                const AdvanceOptions& options, std::vector<double>* values = nullptr) {
    double norm = 0.0;
    if (values != nullptr) values->resize(start.densities_m3.size());
    for (std::size_t i = 0; i < start.densities_m3.size(); ++i) {
        const double value = trial.densities_m3[i] - start.densities_m3[i] - dt * evaluation.production_rates_m3_s[i];
        const double scale = options.absolute_tolerance_m3 + options.relative_tolerance *
                             std::max(std::abs(start.densities_m3[i]), std::abs(trial.densities_m3[i]));
        norm = std::max(norm, std::abs(value) / scale);
        if (values != nullptr) (*values)[i] = value;
    }
    return norm;
}

bool implicit_step(const Mechanism& mechanism, const State& start, const Environment& environment,
                   double dt, const AdvanceOptions& options, const std::vector<bool>& mask,
                   State& output, Evaluation& final_evaluation) {
    output = start;
    const std::size_t count = start.densities_m3.size();
    for (std::size_t iteration = 0; iteration < options.maximum_newton_iterations; ++iteration) {
        const Evaluation evaluation = evaluate_validated(mechanism, output, environment);
        std::vector<double> values;
        const double norm = residual(start, output, evaluation, dt, options, &values);
        if (norm <= 0.01) { final_evaluation = evaluation; return true; }
        std::vector<double> matrix(count * count, 0.0);
        std::vector<double> scale(count, 0.0);
        for (std::size_t i = 0; i < count; ++i) scale[i] = options.absolute_tolerance_m3 + options.relative_tolerance *
            std::max(std::abs(start.densities_m3[i]), std::abs(output.densities_m3[i]));
        for (std::size_t i = 0; i < count; ++i) {
            values[i] = -values[i] / scale[i];
            for (std::size_t j = 0; j < count; ++j) {
                matrix[i * count + j] = ((i == j ? 1.0 : 0.0) - dt * evaluation.jacobian_row_major[i * count + j]) * scale[j] / scale[i];
            }
        }
        auto correction = solve_linear(std::move(matrix), std::move(values), options);
        for (std::size_t i = 0; i < count; ++i) correction[i] *= scale[i];
        double alpha = 1.0;
        bool accepted = false;
        for (std::size_t search = 0; search < 40; ++search) {
            State candidate = output;
            for (std::size_t i = 0; i < count; ++i) candidate.densities_m3[i] += alpha * correction[i];
            if (nonnegative(candidate, mask)) {
                const auto candidate_evaluation = evaluate_validated(mechanism, candidate, environment);
                if (residual(start, candidate, candidate_evaluation, dt, options) < norm) {
                    output = std::move(candidate);
                    accepted = true;
                    break;
                }
            }
            alpha *= 0.5;
        }
        if (!accepted) return false;
    }
    return false;
}

void require_valid(const Mechanism& mechanism) {
    const auto errors = mechanism.validate();
    if (!errors.empty()) fail(errors.front());
}

} // namespace

std::size_t Mechanism::species_index(std::string_view id_value) const {
    for (std::size_t i = 0; i < species.size(); ++i) if (species[i].id == id_value) return i;
    fail("unknown species: " + std::string(id_value));
}

Mechanism Mechanism::from_json(const Json& value) {
    if (!value.is_object()) fail("mechanism must be an object");
    if (value.value("schema_version", 1) != 1) fail("unsupported mechanism schema_version");
    Mechanism result;
    result.id = value.value("id", "unnamed");
    result.status = value.value("status", "research");
    result.provenance = value.value("provenance", Json::array());
    result.coverage = value.value("coverage", Json::object());
    for (const auto& item : value.at("species")) {
        Species species;
        species.id = item.at("id").get<std::string>();
        species.phase = item.value("phase", "gas");
        species.elements = item.value("elements", std::map<std::string, int>{});
        species.charge = item.value("charge", 0);
        species.nonnegative = item.value("nonnegative", true);
        species.mass_kg = item.contains("mass_kg") ? item.at("mass_kg").get<double>() : derived_mass(species);
        result.species.push_back(std::move(species));
    }
    for (const auto& item : value.at("reactions")) {
        Reaction reaction;
        reaction.id = item.at("id").get<std::string>();
        reaction.reactants = terms_from_json(item.at("reactants"), result);
        reaction.products = terms_from_json(item.at("products"), result);
        reaction.explicit_orders = item.contains("orders");
        if (reaction.explicit_orders) reaction.orders = terms_from_json(item.at("orders"), result);
        reaction.collision_label = item.value("collision_label", "");
        reaction.basis_interface = item.value("basis_interface", "");
        const std::string default_phase = !reaction.reactants.empty() ? result.species[reaction.reactants.front().species].phase :
                                          (!reaction.products.empty() ? result.species[reaction.products.front().species].phase : "gas");
        reaction.basis_phase = item.value("basis_phase", default_phase);
        reaction.energy_eV_per_event = item.value("energy_eV_per_event", std::map<std::string, double>{});
        reaction.check_energy_balance = item.contains("external_energy_eV_per_event");
        reaction.external_energy_eV_per_event = item.value("external_energy_eV_per_event", 0.0);
        reaction.source = item.value("source", "");
        reaction.status = item.value("status", "research");
        reaction.metadata = item.value("metadata", Json::object());
        const auto& law = item.at("rate");
        reaction.rate.kind = parse_kind(law.at("type").get<std::string>());
        reaction.rate.A = (reaction.rate.kind == RateKind::Constant || reaction.rate.kind == RateKind::Arrhenius)
            ? law.at("A").get<double>() : law.value("A", 0.0);
        reaction.rate.exponent = law.value("exponent", 0.0);
        reaction.rate.activation_temperature_K = law.value("activation_temperature_K", 0.0);
        reaction.rate.reference_temperature_K = law.value("reference_temperature_K", 1.0);
        reaction.rate.temperature = law.value("temperature", "gas");
        reaction.rate.temperatures_eV = law.value("temperatures_eV", std::vector<double>{});
        reaction.rate.coefficients = law.value("coefficients", std::vector<double>{});
        reaction.rate.key = law.value("key", "");
        reaction.rate.expression = law.value("expression", "");
        reaction.rate.constants = law.value("constants", std::map<std::string, double>{});
        reaction.rate.minimum_temperature_K = law.value("minimum_temperature_K", 0.0);
        reaction.rate.maximum_temperature_K = law.value("maximum_temperature_K", 0.0);
        result.reactions.push_back(std::move(reaction));
    }
    require_valid(result);
    return result;
}

Json Mechanism::to_json() const {
    require_valid(*this);
    Json output{{"schema_version", 1}, {"id", id}, {"status", status}, {"provenance", provenance}, {"coverage", coverage},
                {"species", Json::array()}, {"reactions", Json::array()}};
    for (const auto& item : species) output["species"].push_back({{"id", item.id}, {"phase", item.phase}, {"elements", item.elements},
        {"charge", item.charge}, {"mass_kg", item.mass_kg}, {"nonnegative", item.nonnegative}});
    for (const auto& item : reactions) {
        const auto& law = item.rate;
        Json rate{{"type", kind_name(law.kind)}, {"A", law.A}, {"exponent", law.exponent},
            {"activation_temperature_K", law.activation_temperature_K}, {"reference_temperature_K", law.reference_temperature_K},
            {"temperature", law.temperature}, {"temperatures_eV", law.temperatures_eV}, {"coefficients", law.coefficients},
            {"key", law.key}, {"expression", law.expression}, {"constants", law.constants},
            {"minimum_temperature_K", law.minimum_temperature_K}, {"maximum_temperature_K", law.maximum_temperature_K}};
        Json reaction{{"id", item.id}, {"reactants", terms_to_json(item.reactants, *this)}, {"products", terms_to_json(item.products, *this)},
            {"rate", std::move(rate)}, {"collision_label", item.collision_label}, {"basis_phase", item.basis_phase},
            {"basis_interface", item.basis_interface}, {"energy_eV_per_event", item.energy_eV_per_event}, {"source", item.source}, {"status", item.status}, {"metadata", item.metadata}};
        if (item.explicit_orders) reaction["orders"] = terms_to_json(item.orders, *this);
        if (item.check_energy_balance) reaction["external_energy_eV_per_event"] = item.external_energy_eV_per_event;
        output["reactions"].push_back(std::move(reaction));
    }
    return output;
}

std::vector<std::string> Mechanism::validate() const {
    std::vector<std::string> errors;
    std::set<std::string> names;
    if (species.empty()) errors.push_back("mechanism must contain species");
    if (species.size() > 4096) errors.push_back("mechanism exceeds 4096 species");
    for (const auto& item : species) {
        if (item.id.empty() || !names.insert(item.id).second) errors.push_back("empty or duplicate species id: " + item.id);
        if (item.phase.empty()) errors.push_back("species phase must not be empty: " + item.id);
        if (!finite(item.mass_kg) || item.mass_kg <= 0.0) errors.push_back("invalid species mass: " + item.id);
        if (item.elements.empty() && item.charge != -1) errors.push_back("only electrons may have no elements: " + item.id);
        for (const auto& [element, count] : item.elements) if (element.empty() || count <= 0) errors.push_back("invalid element count: " + item.id);
    }
    names.clear();
    for (const auto& reaction : reactions) {
        if (reaction.id.empty() || !names.insert(reaction.id).second) errors.push_back("empty or duplicate reaction id: " + reaction.id);
        if (reaction.reactants.empty() && reaction.products.empty()) errors.push_back("reaction has no species: " + reaction.id);
        std::map<std::string, double> balance;
        double charge = 0.0;
        const auto check_terms = [&](const std::vector<Term>& terms, double sign, bool order) {
            std::set<std::size_t> unique;
            for (const auto& term : terms) {
                if (term.species >= species.size()) { errors.push_back("invalid species index in " + reaction.id); continue; }
                if (!unique.insert(term.species).second) errors.push_back("duplicate species term in " + reaction.id);
                if (!finite(term.coefficient) || term.coefficient < 0.0 || (!order && term.coefficient == 0.0)) errors.push_back("invalid stoichiometry/order in " + reaction.id);
                if (order && term.coefficient > 0.0 && term.coefficient < 1.0) errors.push_back("orders between zero and one have a singular zero-density Jacobian: " + reaction.id);
                if (!order) {
                    for (const auto& [element, count] : species[term.species].elements) balance[element] += sign * term.coefficient * static_cast<double>(count);
                    charge += sign * term.coefficient * static_cast<double>(species[term.species].charge);
                }
            }
        };
        check_terms(reaction.reactants, -1.0, false);
        check_terms(reaction.products, 1.0, false);
        check_terms(reaction.orders, 0.0, true);
        if (!reaction.explicit_orders) for (const auto& term : reaction.reactants) {
            if (term.coefficient > 0.0 && term.coefficient < 1.0) errors.push_back("fractional reactant order has a singular zero-density Jacobian: " + reaction.id);
        }
        for (const auto& [element, value] : balance) if (std::abs(value) > 1.0e-10) errors.push_back("element " + element + " is not conserved by " + reaction.id);
        if (std::abs(charge) > 1.0e-10) errors.push_back("charge is not conserved by " + reaction.id);
        const auto& law = reaction.rate;
        switch (law.kind) {
        case RateKind::Constant: case RateKind::Arrhenius: case RateKind::ElectronTemperatureTable:
        case RateKind::ElectronEedf: case RateKind::Expression: case RateKind::Parameter: break;
        default: errors.push_back("unknown rate kind: " + reaction.id); break;
        }
        if (law.temperature != "gas" && law.temperature != "liquid" && law.temperature != "electron") errors.push_back("invalid temperature selector: " + reaction.id);
        if (!finite(law.minimum_temperature_K) || !finite(law.maximum_temperature_K) || law.minimum_temperature_K < 0.0 ||
            law.maximum_temperature_K < 0.0 || (law.maximum_temperature_K > 0.0 && law.minimum_temperature_K > law.maximum_temperature_K)) errors.push_back("invalid temperature validity range: " + reaction.id);
        if (!finite(law.A) || law.A < 0.0 || !finite(law.exponent) || !finite(law.activation_temperature_K) ||
            !finite(law.reference_temperature_K) || law.reference_temperature_K <= 0.0) errors.push_back("invalid rate parameters: " + reaction.id);
        if (law.kind == RateKind::ElectronEedf && external_key(reaction).empty()) errors.push_back("electron rate requires key or collision_label: " + reaction.id);
        if (law.kind == RateKind::ElectronEedf && !reaction.collision_label.empty() && !law.key.empty() && law.key != reaction.collision_label) errors.push_back("EEDF key differs from collision_label: " + reaction.id);
        if (law.kind == RateKind::Parameter && law.key.empty()) errors.push_back("parameter rate requires key: " + reaction.id);
        if (law.kind == RateKind::ElectronTemperatureTable) {
            if (law.temperatures_eV.size() < 2 || law.temperatures_eV.size() != law.coefficients.size()) errors.push_back("electron rate table requires matching arrays of length >= 2: " + reaction.id);
            for (std::size_t i = 0; i < law.temperatures_eV.size(); ++i) {
                if (!finite(law.temperatures_eV[i]) || law.temperatures_eV[i] < 0.0 || (i > 0 && law.temperatures_eV[i] <= law.temperatures_eV[i - 1])) errors.push_back("electron table temperatures must increase: " + reaction.id);
            }
            for (const double value : law.coefficients) if (!finite(value) || value < 0.0) errors.push_back("invalid electron table rate: " + reaction.id);
        }
        for (const auto& [name, value] : law.constants) if (name.empty() || !finite(value)) errors.push_back("invalid expression constant: " + reaction.id);
        if (law.kind == RateKind::Expression) {
            try { static_cast<void>(Expression(law.expression, law.constants, true).evaluate()); }
            catch (const std::exception& exception) { errors.push_back(reaction.id + ": " + exception.what()); }
        }
        double energy_sum = 0.0;
        for (const auto& [name, value] : reaction.energy_eV_per_event) {
            if (name.empty() || !finite(value)) errors.push_back("invalid reaction energy partition: " + reaction.id);
            energy_sum += value;
        }
        if (!finite(reaction.external_energy_eV_per_event)) errors.push_back("invalid external energy: " + reaction.id);
        if (reaction.check_energy_balance && std::abs(energy_sum - reaction.external_energy_eV_per_event) >
            1.0e-10 * std::max(1.0, std::abs(energy_sum))) errors.push_back("energy partitions do not balance: " + reaction.id);
    }
    return errors;
}

void validate_environment(const Environment& environment) { validate_environment_impl(environment); }
double rate_coefficient(const Reaction& reaction,const Environment& environment) { return coefficient(reaction,environment); }

Evaluation evaluate(const Mechanism& mechanism, const State& state, const Environment& environment) {
    require_valid(mechanism);
    validate_environment(environment);
    return evaluate_validated(mechanism, state, environment);
}

AdvanceResult advance(const Mechanism& mechanism, const State& state, const Environment& environment,
                      double interval_s, const AdvanceOptions& options) {
    AdvanceResult result;
    result.state = state;
    try {
        if(options.execution.mpi){
            const auto partition=backend::distributed_partition(static_cast<backend::GlobalIndex>(mechanism.species.size()),options.execution);
            backend::DistributedHalo control(partition,{},options.execution);
            control.collective_require(state.densities_m3.size()!=mechanism.species.size()?"state density vector has the wrong size":"");
            DistributedState owned;owned.partition=partition;std::string error;
            try{owned.densities_m3.assign(state.densities_m3.begin()+static_cast<std::ptrdiff_t>(partition.row_begin),
                state.densities_m3.begin()+static_cast<std::ptrdiff_t>(partition.row_begin+partition.local_rows));}
            catch(const std::exception& exception){error=exception.what();}
            control.collective_require(error);
            const auto advanced=advance_distributed(mechanism,owned,environment,interval_s,options);
            result.success=advanced.success;result.advanced_time_s=advanced.advanced_time_s;result.accepted_steps=advanced.accepted_steps;
            result.rejected_steps=advanced.rejected_steps;result.message=advanced.message;result.integrated_energy_J_m3=advanced.integrated_energy_J_m3;
            if(result.success)result.state.densities_m3=backend::gather_distributed(control,advanced.state.densities_m3);
            return result;
        }
        require_valid(mechanism);
        validate_environment(environment);
        if (!finite(interval_s) || interval_s < 0.0) fail("advance interval must be finite and nonnegative");
        if (!finite(options.relative_tolerance) || options.relative_tolerance <= 0.0 || !finite(options.absolute_tolerance_m3) ||
            options.absolute_tolerance_m3 <= 0.0 || !finite(options.minimum_step_s) || options.minimum_step_s <= 0.0 ||
            !finite(options.maximum_step_s) || options.maximum_step_s < 0.0 || options.maximum_steps == 0 || options.maximum_newton_iterations == 0) fail("invalid advance options");
        if(options.execution.device!="cpu"&&options.execution.device!="cuda")fail("unknown chemistry execution device");
        if(options.execution.device=="cuda"&&!options.execution.mpi)
            return advance_cuda_batch(mechanism,std::span<const State>(&state,1),std::span<const Environment>(&environment,1),interval_s,options).cells.front();
        auto mask = options.nonnegative;
        if (mask.empty()) for (const auto& item : mechanism.species) mask.push_back(item.nonnegative);
        if (mask.size() != mechanism.species.size()) fail("nonnegative mask must match the species count");
        // A per-call positivity override also controls trial-state admission.
        Mechanism local = mechanism;
        for (std::size_t i = 0; i < local.species.size(); ++i) local.species[i].nonnegative = mask[i];
        static_cast<void>(evaluate_validated(local, state, environment));
        if (!nonnegative(state, mask)) fail("initial state violates positivity constraints");
        State current = state;
        double time = 0.0;
        double step = options.maximum_step_s > 0.0 ? std::min(interval_s, options.maximum_step_s) : interval_s;
        std::map<std::string, double> energy;
        while (time < interval_s) {
            if (result.accepted_steps + result.rejected_steps >= options.maximum_steps) fail("chemistry step budget exhausted; state rolled back");
            const double remaining = interval_s - time;
            step = std::min(step, remaining);
            if (!(step > 0.0) || time + step == time || (step < options.minimum_step_s && remaining > options.minimum_step_s)) fail("chemistry minimum step reached; state rolled back");
            State full;
            State half;
            State two_half;
            Evaluation full_evaluation;
            Evaluation half_evaluation;
            Evaluation final_evaluation;
            bool solved = false;
            try {
                solved = implicit_step(local, current, environment, step, options, mask, full, full_evaluation);
                if (solved) solved = implicit_step(local, current, environment, step * 0.5, options, mask, half, half_evaluation);
                if (solved) solved = implicit_step(local, half, environment, step * 0.5, options, mask, two_half, final_evaluation);
            } catch (const std::invalid_argument&) {
                // Initial-state/configuration errors were checked above. A
                // failed nonlinear trial may be recoverable at a smaller step.
                solved = false;
            }
            double error = std::numeric_limits<double>::infinity();
            if (solved) {
                error = 0.0;
                for (std::size_t i = 0; i < current.densities_m3.size(); ++i) {
                    const double scale = options.absolute_tolerance_m3 + options.relative_tolerance *
                        std::max(std::abs(current.densities_m3[i]), std::abs(two_half.densities_m3[i]));
                    error = std::max(error, std::abs(two_half.densities_m3[i] - full.densities_m3[i]) / scale);
                }
            }
            if (!solved || error > 1.0 || !finite(error)) {
                ++result.rejected_steps;
                if (step <= options.minimum_step_s) fail("chemistry minimum step reached; state rolled back");
                step = std::max(options.minimum_step_s, step *
                    (finite(error) && error > 0.0 ? std::clamp(0.9 / std::sqrt(error), 0.1, 0.5) : 0.5));
                continue;
            }
            for (const auto& [name, value] : half_evaluation.energy_sources_W_m3) energy[name] += value * (step * 0.5);
            for (const auto& [name, value] : final_evaluation.energy_sources_W_m3) energy[name] += value * (step * 0.5);
            for (const auto& [name, value] : energy) {
                if (!finite(value)) fail("integrated energy overflow: " + name + "; state rolled back");
            }
            current = std::move(two_half);
            time += step;
            ++result.accepted_steps;
            step = std::max(options.minimum_step_s, step *
                (error > 0.0 ? std::clamp(0.9 / std::sqrt(error), 0.5, 2.0) : 2.0));
            if (options.maximum_step_s > 0.0) step = std::min(step, options.maximum_step_s);
        }
        result.success = true;
        result.state = std::move(current);
        result.advanced_time_s = interval_s;
        result.integrated_energy_J_m3 = std::move(energy);
        result.message = "completed";
    } catch (const std::exception& exception) {
        result.success = false;
        result.state = state;
        result.advanced_time_s = 0.0;
        result.integrated_energy_J_m3.clear();
        result.message = exception.what();
    }
    return result;
}

Json coverage_report(const Mechanism& mechanism, const Environment& environment) {
    require_valid(mechanism);
    Json missing_eedf = Json::array();
    Json missing_parameters = Json::array();
    Json unpartitioned_energy = Json::array();
    Json rate_errors = Json::array();
    Json phases = Json::array();
    std::set<std::string> seen;
    for (const auto& item : mechanism.species) if (seen.insert(item.phase).second) phases.push_back(item.phase);
    for (const auto& reaction : mechanism.reactions) {
        if (reaction.rate.kind == RateKind::ElectronEedf && environment.electron_rates.count(external_key(reaction)) == 0) missing_eedf.push_back(external_key(reaction));
        if (reaction.rate.kind == RateKind::Parameter && environment.parameters.count(reaction.rate.key) == 0) missing_parameters.push_back(reaction.rate.key);
        if (!reaction.check_energy_balance) unpartitioned_energy.push_back(reaction.id);
        try { static_cast<void>(coefficient(reaction, environment)); }
        catch (const std::exception& exception) { rate_errors.push_back({{"reaction", reaction.id}, {"message", exception.what()}}); }
    }
    return {{"mechanism_id", mechanism.id}, {"status", mechanism.status}, {"phases", std::move(phases)},
        {"species_count", mechanism.species.size()}, {"reaction_count", mechanism.reactions.size()},
        {"missing_eedf_rates", missing_eedf}, {"missing_parameters", missing_parameters},
        {"unchecked_energy_reactions", unpartitioned_energy},
        {"rate_errors", rate_errors}, {"rates_ready", rate_errors.empty()}, {"coverage", mechanism.coverage}, {"provenance", mechanism.provenance}};
}

Json validate_mechanism(const Json& value) {
    try {
        const Mechanism mechanism = Mechanism::from_json(value);
        return {{"valid", true}, {"errors", Json::array()}, {"coverage", coverage_report(mechanism)}};
    } catch (const std::exception& exception) {
        return {{"valid", false}, {"errors", Json::array({exception.what()})}};
    }
}

Json evaluate_json(const Json& request) {
    const Mechanism mechanism = Mechanism::from_json(request.at("mechanism"));
    const State state = parse_state(request.at("state"), mechanism);
    const Environment environment = parse_environment(request.value("environment", Json::object()));
    const auto execution=request.value("execution",Json::object());
    const auto device=execution.value("device",std::string("cpu"));
    if(execution.value("mpi",false))throw std::invalid_argument("chemistry.evaluate is local; distribute batches or use chemistry.advance for collective solves");
    if(device!="cpu"&&device!="cuda")throw std::invalid_argument("unknown chemistry execution device");
    const auto result = device=="cuda"?evaluate_cuda_batch(mechanism,std::span<const State>(&state,1),std::span<const Environment>(&environment,1),execution.value("cuda_device",-1)).cells.front():evaluate(mechanism,state,environment);
    Json sources = Json::object();
    Json rates = Json::object();
    for (std::size_t i = 0; i < mechanism.species.size(); ++i) sources[mechanism.species[i].id] = result.production_rates_m3_s[i];
    for (std::size_t i = 0; i < mechanism.reactions.size(); ++i) rates[mechanism.reactions[i].id] =
        {{"coefficient_SI", result.rate_coefficients[i]}, {"progress_per_basis_s", result.reaction_rates_m3_s[i]}};
    return {{"mechanism_id", mechanism.id}, {"production_rates_m3_s", std::move(sources)}, {"reactions", std::move(rates)},
        {"jacobian_row_major", result.jacobian_row_major}, {"species_order", [&]() { std::vector<std::string> names; for (const auto& item : mechanism.species) names.push_back(item.id); return names; }()},
        {"energy_sources_W_m3", result.energy_sources_W_m3}, {"coverage", coverage_report(mechanism, environment)}};
}

namespace {
AdvanceOptions advance_options(const Json& request) {
    AdvanceOptions options;
    const auto setup = request.value("options", Json::object());
    options.relative_tolerance = setup.value("relative_tolerance", options.relative_tolerance);
    options.absolute_tolerance_m3 = setup.value("absolute_tolerance_m3", options.absolute_tolerance_m3);
    options.minimum_step_s = setup.value("minimum_step_s", options.minimum_step_s);
    options.maximum_step_s = setup.value("maximum_step_s", options.maximum_step_s);
    options.maximum_steps = setup.value("maximum_steps", options.maximum_steps);
    options.maximum_newton_iterations = setup.value("maximum_newton_iterations", options.maximum_newton_iterations);
    options.nonnegative = setup.value("nonnegative", options.nonnegative);
    const auto execution = request.value("execution", setup.value("execution", Json::object()));
    options.execution.device = execution.value("device", options.execution.device);
    options.execution.mpi = execution.value("mpi", options.execution.mpi);
    options.execution.threads = execution.value("threads", options.execution.threads);
    options.execution.communicator_f = execution.value("communicator_f", options.execution.communicator_f);
    options.execution.tolerance = execution.value("tolerance", options.execution.tolerance);
    options.execution.max_iterations = execution.value("max_iterations", options.execution.max_iterations);
    options.execution.restart = execution.value("restart", options.execution.restart);
    options.execution.preconditioner = execution.value("preconditioner", options.execution.preconditioner);
    options.execution.cuda_device = execution.value("cuda_device", options.execution.cuda_device);
    return options;
}
Json advance_result_json(const AdvanceResult& result,const Mechanism& mechanism){
    return {{"success", result.success}, {"state", state_json(result.state, mechanism)}, {"advanced_time_s", result.advanced_time_s},
        {"accepted_steps", result.accepted_steps}, {"rejected_steps", result.rejected_steps}, {"message", result.message},
        {"integrated_energy_J_m3", result.integrated_energy_J_m3}};
}
Json transfer_json(const backend::DeviceTransferMetrics& metrics){
    return {{"host_to_device_bytes",metrics.host_to_device_bytes},{"device_to_host_bytes",metrics.device_to_host_bytes},
        {"allocated_bytes",metrics.allocated_bytes}};
}
struct BatchInput {std::vector<State> states;std::vector<Environment> environments;};
BatchInput batch_input(const Json& request,const Mechanism& mechanism){
    const auto& cells=request.at("cells");
    if(!cells.is_array()||cells.empty())throw std::invalid_argument("chemistry batch cells must be a nonempty array");
    BatchInput input;
    const bool per_cell=std::any_of(cells.begin(),cells.end(),[](const Json& cell){return cell.contains("environment");});
    if(!per_cell)input.environments.push_back(parse_environment(request.value("environment",Json::object())));
    for(const auto& cell:cells){
        input.states.push_back(parse_state(cell.at("state"),mechanism));
        if(per_cell)input.environments.push_back(parse_environment(cell.value("environment",request.value("environment",Json::object()))));
    }return input;
}
DistributedState distributed_state(const Json& request,const Mechanism& mechanism,const backend::DistributedHalo& control){
    const auto partition=backend::balanced_partition(static_cast<backend::GlobalIndex>(mechanism.species.size()),control.rank(),control.ranks());
    const auto& input=request.at("state");DistributedState result;
    result.densities_m3=input.at("densities_m3").get<std::vector<double>>();
    result.partition={input.value("global_rows",partition.global_rows),input.value("row_begin",partition.row_begin),result.densities_m3.size()};
    return result;
}
Json distributed_state_json(const DistributedState& state){
    return {{"global_rows",state.partition.global_rows},{"row_begin",state.partition.row_begin},{"densities_m3",state.densities_m3}};
}
struct DistributedInput {
    Mechanism mechanism;
    AdvanceOptions options;
    DistributedState state;
    Environment environment;
    double interval{};
};
DistributedInput distributed_input(const Json& request,bool advancing){
    DistributedInput input;
    const auto config=request.contains("execution")?request.at("execution"):
        request.value("options",Json::object()).value("execution",Json::object());
    raikou::detail::parse_collectively(config,[&](const backend::DistributedHalo& control){
        input.mechanism=Mechanism::from_json(request.at("mechanism"));
        input.options=advance_options(request);
        input.state=distributed_state(request,input.mechanism,control);
        input.environment=parse_environment(request.value("environment",Json::object()));
        if(advancing)input.interval=request.contains("dt_s")?request.at("dt_s").get<double>():request.at("interval_s").get<double>();
    });
    return input;
}
}
Json advance_json(const Json& request) {
    Json defaults = Json::object();
    const Json* execution = &defaults;
    if (request.contains("execution")) execution = &request.at("execution");
    else if (request.contains("options") && request.at("options").is_object() && request.at("options").contains("execution"))
        execution = &request.at("options").at("execution");
    Mechanism mechanism;
    State state;
    Environment environment;
    AdvanceOptions options;
    double interval = 0;
    const auto control = raikou::detail::parse_collectively(*execution, [&](const backend::DistributedHalo&) {
        mechanism = Mechanism::from_json(request.at("mechanism"));
        state = parse_state(request.at("state"), mechanism);
        environment = parse_environment(request.value("environment", Json::object()));
        options = advance_options(request);
        interval = request.contains("dt_s") ? request.at("dt_s").get<double>() : request.at("interval_s").get<double>();
    });
    (void)control;
    const auto result = advance(mechanism, state, environment, interval, options);
    auto response=advance_result_json(result,mechanism);
    response["execution"]={{"device", options.execution.device}, {"mpi", options.execution.mpi},
            {"threads", options.execution.threads}, {"acceleration", options.execution.device=="cuda"&&!options.execution.mpi?
                "device-resident reaction, Jacobian, Newton and adaptive time integration":
                (options.execution.mpi?"owned species, sparse reaction/Jacobian assembly and distributed Newton":"Newton linear operator; CPU rate assembly")}};
    response["coverage"]=coverage_report(mechanism,environment);return response;
}
Json evaluate_batch_json(const Json& request){
    const auto mechanism=Mechanism::from_json(request.at("mechanism"));const auto input=batch_input(request,mechanism);
    const auto options=advance_options(request);
    if(options.execution.mpi)throw std::invalid_argument("independent chemistry batch cannot issue MPI collectives; use batch.execute to partition cell groups");
    std::vector<Evaluation> results(input.states.size());backend::DeviceTransferMetrics transfers;
    if(options.execution.device=="cuda"){
        auto batch=evaluate_cuda_batch(mechanism,input.states,input.environments,options.execution.cuda_device);results=std::move(batch.cells);transfers=batch.transfers;
    }else if(options.execution.device=="cpu")backend::parallel_for(results.size(),options.execution.threads,[&](std::size_t c){results[c]=evaluate(mechanism,input.states[c],input.environments[input.environments.size()==1?0:c]);});
    else throw std::invalid_argument("unknown chemistry execution device");
    Json cells=Json::array();
    for(const auto& result:results)cells.push_back({{"production_rates_m3_s",result.production_rates_m3_s},
        {"jacobian_row_major",result.jacobian_row_major},{"reaction_rates_per_basis_s",result.reaction_rates_m3_s},
        {"rate_coefficients_SI",result.rate_coefficients},{"energy_sources_W_m3",result.energy_sources_W_m3}});
    std::vector<std::string> species,reactions;for(const auto& s:mechanism.species)species.push_back(s.id);for(const auto& r:mechanism.reactions)reactions.push_back(r.id);
    return {{"cells",cells},{"species_order",species},{"reaction_order",reactions},{"device",options.execution.device},{"transfers",transfer_json(transfers)}};
}
Json advance_batch_json(const Json& request){
    const auto mechanism=Mechanism::from_json(request.at("mechanism"));const auto input=batch_input(request,mechanism);
    auto options=advance_options(request);
    if(options.execution.mpi)throw std::invalid_argument("independent chemistry batch cannot issue MPI collectives; use batch.execute to partition cell groups");
    const double interval=request.contains("dt_s")?request.at("dt_s").get<double>():request.at("interval_s").get<double>();
    std::vector<AdvanceResult> results(input.states.size());backend::DeviceTransferMetrics transfers;
    if(options.execution.device=="cuda"){
        auto batch=advance_cuda_batch(mechanism,input.states,input.environments,interval,options);results=std::move(batch.cells);transfers=batch.transfers;
    }else if(options.execution.device=="cpu"){
        const auto workers=options.execution.threads;options.execution.threads=1;
        backend::parallel_for(results.size(),workers,[&](std::size_t c){results[c]=advance(mechanism,input.states[c],input.environments[input.environments.size()==1?0:c],interval,options);});
    }else throw std::invalid_argument("unknown chemistry execution device");
    Json cells=Json::array();std::size_t completed=0;
    for(const auto& result:results){cells.push_back(advance_result_json(result,mechanism));if(result.success)++completed;}
    return {{"cells",cells},{"completed_cells",completed},{"success",completed==results.size()},
        {"device",options.execution.device},{"transfers",transfer_json(transfers)}};
}
Json evaluate_distributed_json(const Json& request){
    const auto input=distributed_input(request,false);const auto& state=input.state;
    const auto result=evaluate_distributed(input.mechanism,state,input.environment,input.options.execution);
    return {{"global_rows",state.partition.global_rows},{"row_begin",state.partition.row_begin},
        {"production_rates_m3_s",result.production_rates_m3_s},{"ghost_species",result.ghost_species},
        {"energy_sources_W_m3",result.energy_sources_W_m3},{"jacobian",{{"global_rows",result.jacobian.global_rows},
            {"row_begin",result.jacobian.row_begin},{"offsets",result.jacobian.offsets},
            {"columns",result.jacobian.columns},{"values",result.jacobian.values}}}};
}
Json advance_distributed_json(const Json& request){
    const auto input=distributed_input(request,true);
    const auto result=advance_distributed(input.mechanism,input.state,input.environment,input.interval,input.options);
    return {{"success",result.success},{"state",distributed_state_json(result.state)},{"advanced_time_s",result.advanced_time_s},
        {"accepted_steps",result.accepted_steps},{"rejected_steps",result.rejected_steps},{"message",result.message},
        {"integrated_energy_J_m3",result.integrated_energy_J_m3},{"ghost_species",result.ghost_species}};
}

} // namespace raikou::chemistry
