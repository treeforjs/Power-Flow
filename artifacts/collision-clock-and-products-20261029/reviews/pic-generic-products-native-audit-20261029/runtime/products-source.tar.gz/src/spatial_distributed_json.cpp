#include "raikou/spatial_distributed.h"
#include "raikou/spherical_harmonics.h"
#include "json_collective.h"
#include "thermal_temperature.h"
#include "legendre_admissibility.h"
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <map>
#include <set>
#include <stdexcept>

namespace raikou::spatial {
namespace {
constexpr const char* representation="owned_cell_dof_v1";
[[noreturn]] void invalid(const std::string& message){throw std::invalid_argument("owned spatial JSON: "+message);}
void require(bool value,const std::string& message){if(!value)invalid(message);}
void finite_values(std::span<const double> values,const std::string& name,bool nonnegative=false,bool positive=false){
    for(double value:values)require(std::isfinite(value)&&(!nonnegative||value>=0)&&(!positive||value>0),"invalid "+name);
}
Json definition(Json request){for(const auto* key:{"checkpoint","local_initial","time","solver","execution"})request.erase(key);return request;}
void agree(const backend::DistributedHalo& control,const Json& value,const std::string& name){
    std::uint64_t hash=1469598103934665603ULL;
    for(unsigned char byte:value.dump()){hash^=byte;hash*=1099511628211ULL;}
    bool equal=true;
    for(unsigned shift:{0u,32u}){const double part=static_cast<double>((hash>>shift)&0xffffffffULL);if(control.global_max(part)!=-control.global_max(-part))equal=false;}
    control.collective_require(equal?"":"ranks disagree on "+name);
}
std::vector<std::string> thermal_names(const Problem& model){
    std::vector<std::string> result;if(!model.thermal.enabled)return result;
    if(model.thermal.phases.empty())result.emplace_back();else for(const auto& [phase,field]:model.thermal.phases){(void)field;result.push_back(phase);}return result;
}
void scalar_initials(const Json& request){
    for(const auto& [id,value]:request.at("initial_densities_m3").items())require(value.is_number(),"shared initial density must be scalar for "+id+"; use local_initial.densities_m3 for owned arrays");
    if(request.contains("thermal")){
        const auto& thermal=request.at("thermal");
        if(thermal.contains("initial_temperature_K"))require(thermal.at("initial_temperature_K").is_number(),"shared initial temperature must be scalar; use local_initial.temperature_K");
        if(thermal.contains("phases"))for(const auto& [phase,field]:thermal.at("phases").items())
            if(field.contains("initial_temperature_K"))require(field.at("initial_temperature_K").is_number(),"shared phase temperature must be scalar for "+phase);
    }
    if(request.contains("radiation"))for(const auto& group:request.at("radiation"))if(group.contains("initial_density_m3"))require(group.at("initial_density_m3").is_number(),"shared initial photons must be scalar; use local_initial.photon_densities_m3");
    for(const auto* key:{"potential_V","densities_m3","temperature_K","phase_temperatures_K","photon_densities_m3","owned_values","spherical_electrons","electrons"})
        require(!request.contains(key),"global prognostic field '"+std::string(key)+"' is forbidden; use local_initial or a local checkpoint");
}
Json legendre_json(const kinetics::EedfState& state){
    return {{"representation","axisymmetric_legendre_fixed_direction"},{"time_s",state.time_s},
        {"grid",{{"cells",state.grid.cells},{"max_energy_ev",state.grid.max_energy_ev},{"power",state.grid.power},{"legendre_terms",state.grid.legendre_terms}}},
        {"density_modes",state.density_modes}};
}
kinetics::EedfState read_legendre(const Json& value){
    require(value.at("representation")=="axisymmetric_legendre_fixed_direction","unsupported local Legendre representation");
    kinetics::EedfState state;state.grid=kinetics::eedf_grid_from_json(value.at("grid"));state.time_s=value.at("time_s").get<double>();
    require(state.time_s>=0&&std::isfinite(state.time_s),"invalid local Legendre clock");
    state.density_modes=value.at("density_modes").get<std::vector<double>>();finite_values(state.density_modes,"local Legendre modes");
    (void)state.electron_density_m3(); // validates grid and packed state shape
    const auto stride=static_cast<std::size_t>(state.grid.legendre_terms);
    require(kinetics::detail::legendre_isotropic_nonnegative(state.density_modes,static_cast<std::size_t>(state.grid.cells),stride),"local Legendre F0 must be nonnegative within numerical tolerance");
    require(kinetics::detail::legendre_padding_zero(state.density_modes,static_cast<std::size_t>(state.grid.cells),stride),"local Legendre padding must be zero");
    return state;
}
DistributedState read_state(const Json& value){
    require(value.at("representation")==representation,"checkpoint state has unsupported ownership representation");
    DistributedState state;state.time_s=value.at("time_s").get<double>();require(state.time_s>=0&&std::isfinite(state.time_s),"invalid checkpoint clock");
    state.rows.global_rows=value.at("global_rows").get<backend::GlobalIndex>();state.rows.row_begin=value.at("row_begin").get<backend::GlobalIndex>();
    state.rows.local_rows=value.at("local_rows").get<std::size_t>();state.cells={value.at("cell_begin").get<std::size_t>(),value.at("cell_count").get<std::size_t>()};
    state.owned_values=value.at("owned_values").get<std::vector<double>>();require(state.owned_values.size()==state.rows.local_rows,"checkpoint owned value count differs from local_rows");finite_values(state.owned_values,"checkpoint owned values");
    for(const auto& angular:value.at("spherical_electrons"))state.spherical_electrons.push_back(kinetics::spherical_state_from_json(angular));
    if(value.contains("electrons"))for(const auto& axial:value.at("electrons"))state.electrons.push_back(read_legendre(axial));
    require(state.electrons.empty()||state.spherical_electrons.empty(),"checkpoint cannot own two electron representations");
    return state;
}
Json state_json(const DistributedState& state){
    Json electrons=Json::array();for(const auto& angular:state.spherical_electrons)electrons.push_back(kinetics::spherical_state_to_json(angular));
    Json axial=Json::array();for(const auto& entry:state.electrons)axial.push_back(legendre_json(entry));
    return {{"representation",representation},{"time_s",state.time_s},{"global_rows",state.rows.global_rows},{"row_begin",state.rows.row_begin},{"local_rows",state.rows.local_rows},
        {"cell_begin",state.cells.begin},{"cell_count",state.cells.count},{"owned_values",state.owned_values},{"spherical_electrons",electrons},{"electrons",axial}};
}
DistributedCheckpoint read_checkpoint(const Json& value,const Json& expected,std::size_t species){
    require(value.at("schema_version")==1&&value.at("representation")==representation,"unsupported owned checkpoint schema");
    require(value.at("definition")==expected,"checkpoint physical definition differs from request");
    DistributedCheckpoint cp;cp.state=read_state(value.at("state"));cp.previous_state=read_state(value.at("previous_state"));
    cp.previous_step_s=value.at("previous_step_s").get<double>();cp.next_step_s=value.at("next_step_s").get<double>();cp.accepted_steps=value.at("accepted_steps").get<std::size_t>();
    require(cp.previous_step_s>=0&&std::isfinite(cp.previous_step_s)&&cp.next_step_s>0&&std::isfinite(cp.next_step_s),"invalid checkpoint time-step history");
    cp.local_boundary_counts=value.at("local_boundary_counts").get<std::vector<double>>();cp.previous_local_boundary_counts=value.at("previous_local_boundary_counts").get<std::vector<double>>();
    require(cp.local_boundary_counts.size()==species&&cp.previous_local_boundary_counts.size()==species,"checkpoint boundary ledgers differ from species count");
    finite_values(cp.local_boundary_counts,"checkpoint boundary ledger");finite_values(cp.previous_local_boundary_counts,"checkpoint previous boundary ledger");
    cp.local_energy_integrals_J=value.at("local_energy_integrals_J").get<std::map<std::string,double>>();cp.previous_local_energy_integrals_J=value.at("previous_local_energy_integrals_J").get<std::map<std::string,double>>();
    for(const auto* ledger:{&cp.local_energy_integrals_J,&cp.previous_local_energy_integrals_J})for(const auto& [name,power]:*ledger){(void)name;require(std::isfinite(power),"nonfinite checkpoint energy ledger");}
    return cp;
}
Json checkpoint_json(const DistributedCheckpoint& cp,const Json& physical){
    return {{"schema_version",1},{"representation",representation},{"definition",physical},{"state",state_json(cp.state)},{"previous_state",state_json(cp.previous_state)},
        {"previous_step_s",cp.previous_step_s},{"next_step_s",cp.next_step_s},{"accepted_steps",cp.accepted_steps},{"local_boundary_counts",cp.local_boundary_counts},
        {"previous_local_boundary_counts",cp.previous_local_boundary_counts},{"local_energy_integrals_J",cp.local_energy_integrals_J},{"previous_local_energy_integrals_J",cp.previous_local_energy_integrals_J}};
}
struct InitialData {
    partition::CellInterval cells;
    std::map<std::size_t,std::vector<double>> densities,temperatures,photons;
    std::vector<double> potential;
};
std::vector<double> owned_array(const Json& value,std::size_t count,const std::string& name,bool nonnegative=false,bool positive=false){
    require(value.is_array(),name+" must be an owned array");auto values=value.get<std::vector<double>>();require(values.size()==count,name+" must contain exactly cell_count entries");finite_values(values,name,nonnegative,positive);return values;
}
InitialData read_initial(const Json& request,const Problem& model,partition::CellInterval cells,const std::vector<std::string>& phases){
    InitialData data;data.cells=cells;if(!request.contains("local_initial"))return data;
    const auto& value=request.at("local_initial");
    const std::set<std::string> allowed{"cell_begin","cell_count","densities_m3","temperature_K","phase_temperatures_K","photon_densities_m3","potential_V"};
    for(const auto& [key,item]:value.items()){(void)item;require(allowed.contains(key),"unknown local_initial field "+key);}
    if(value.contains("densities_m3")){
        require(value.at("densities_m3").is_object(),"local densities must map species IDs to owned arrays");
        for(const auto& [id,field]:value.at("densities_m3").items()){const auto species=model.mechanism.species_index(id);data.densities[species]=owned_array(field,cells.count,"local density "+id,model.mechanism.species[species].nonnegative);}
    }
    if(value.contains("temperature_K")){require(phases.size()==1&&phases[0].empty(),"local temperature_K requires the common thermal equation");data.temperatures[0]=owned_array(value.at("temperature_K"),cells.count,"local temperature",false,true);}
    if(value.contains("phase_temperatures_K")){
        require(value.at("phase_temperatures_K").is_object(),"phase temperatures must map phase names to owned arrays");
        for(const auto& [phase,field]:value.at("phase_temperatures_K").items()){const auto found=std::find(phases.begin(),phases.end(),phase);require(!phase.empty()&&found!=phases.end(),"unknown local thermal phase "+phase);data.temperatures[static_cast<std::size_t>(found-phases.begin())]=owned_array(field,cells.count,"local temperature "+phase,false,true);}
    }
    if(value.contains("photon_densities_m3")){
        require(value.at("photon_densities_m3").is_object(),"local photons must map group IDs to owned arrays");
        for(const auto& [id,field]:value.at("photon_densities_m3").items()){const auto found=std::find_if(model.radiation.begin(),model.radiation.end(),[&](const auto& group){return group.id==id;});require(found!=model.radiation.end(),"unknown local photon group "+id);data.photons[static_cast<std::size_t>(found-model.radiation.begin())]=owned_array(field,cells.count,"local photons "+id,true);}
    }
    if(value.contains("potential_V"))data.potential=owned_array(value.at("potential_V"),cells.count,"local potential");
    return data;
}
void validate_layout_state(const DistributedState& state,const partition::DofLayout& layout){
    const auto cells=layout.owned_cells();const auto rows=layout.row_partition();
    require(state.cells.begin==cells.begin&&state.cells.count==cells.count,"checkpoint cell ownership differs from this rank");
    require(state.rows.global_rows==rows.global_rows&&state.rows.row_begin==rows.row_begin&&state.rows.local_rows==rows.local_rows&&state.owned_values.size()==rows.local_rows,"checkpoint DOF ownership differs from physical model");
}
Json sample_json(const Sample& value){return {{"time_s",value.time_s},{"driven_voltage_V",value.driven_voltage_V},{"source_current_A",value.source_current_A},{"gas_charge_C",value.gas_charge_C},
    {"surface_charge_C",value.surface_charge_C},{"field_energy_J",value.field_energy_J},{"electric_work_W",value.electric_work_W},{"thermal_energy_J",value.thermal_energy_J},{"radiation_energy_J",value.radiation_energy_J},
    {"electron_energy_J",value.electron_energy_J},{"nonlinear_residual",value.nonlinear_residual},{"temporal_error",value.temporal_error},{"bdf_order",value.order},{"newton_iterations",value.newton_iterations}};}
}

Json solve_distributed_json(const Json& request){
    // Match the physical parser's solver -> execution precedence for the two
    // bootstrap control fields, including a partial execution override.
    Json execution=Json::object();
    for(const auto* source:{"solver","execution"})if(request.contains(source)&&request.at(source).is_object())
        for(const auto* key:{"mpi","communicator_f"})if(request.at(source).contains(key))execution[key]=request.at(source).at(key);
    auto model=std::make_shared<Problem>();mesh::Geometry geometry;DistributedProblem problem;
    std::vector<std::string> phases;InitialData initial;Json physical;
    const auto control=detail::parse_collectively(execution,[&](const backend::DistributedHalo& team){
        require(request.is_object(),"request must be an object");scalar_initials(request);
        require(!(request.contains("checkpoint")&&request.contains("local_initial")),"choose local_initial or checkpoint for the owned state");
        *model=problem_from_json(request,false);geometry=mesh::geometry(model->mesh);phases=thermal_names(*model);physical=definition(request);
        const auto balanced=backend::balanced_partition(static_cast<backend::GlobalIndex>(geometry.volume.size()),team.rank(),team.ranks());
        partition::CellInterval cells{static_cast<std::size_t>(balanced.row_begin),balanced.local_rows};
        if(request.contains("checkpoint")){
            problem.checkpoint=read_checkpoint(request.at("checkpoint"),physical,model->mechanism.species.size());cells=problem.checkpoint->state.cells;
        }else if(request.contains("local_initial")){
            cells={request.at("local_initial").at("cell_begin").get<std::size_t>(),request.at("local_initial").at("cell_count").get<std::size_t>()};
        }
        require(cells.begin<=geometry.volume.size()&&cells.count<=geometry.volume.size()-cells.begin,"local cell interval exceeds geometry");
        problem.owned_cells=cells;initial=read_initial(request,*model,cells,phases);
    });
    Json common=request;for(const auto* key:{"local_initial","checkpoint","execution"})common.erase(key);
    if(common.contains("solver")){common["solver"].erase("cuda_device");common["solver"].erase("threads");}
    common["restart"]=request.contains("checkpoint");agree(control,common,"shared physical/time/solver metadata");
    if(problem.checkpoint){const auto& cp=*problem.checkpoint;agree(control,Json{cp.state.time_s,cp.previous_state.time_s,cp.previous_step_s,cp.next_step_s,cp.accepted_steps},"checkpoint clocks and time-step history");}
    backend::ExecutionOptions options;options.mpi=model->options.mpi;options.communicator_f=model->options.communicator_f;options.device=model->options.device;options.threads=model->options.threads;options.cuda_device=model->options.cuda_device;
    std::vector<unsigned char> dielectric(geometry.walls.size(),0);
    for(std::size_t w=0;w<geometry.walls.size();++w)dielectric[w]=model->boundaries[static_cast<std::size_t>(geometry.walls[w].side)].kind==BoundaryKind::Dielectric&&geometry.walls[w].area>0?1:0;
    partition::DofLayout layout(geometry,model->mechanism.species.size(),model->radiation.size(),phases.size(),dielectric,model->circuit.enabled&&model->circuit.series_resistance_ohm>0,options,problem.owned_cells);
    std::string setup_error;
    try{
        if(problem.checkpoint){validate_layout_state(problem.checkpoint->state,layout);validate_layout_state(problem.checkpoint->previous_state,layout);}
        const auto storage=std::make_shared<InitialData>(std::move(initial));
        const auto local_index=[storage](std::size_t cell){require(cell>=storage->cells.begin&&cell-storage->cells.begin<storage->cells.count,"initializer called for a nonowned cell");return cell-storage->cells.begin;};
        problem.initial.density=[storage,model,local_index](std::size_t cell,std::size_t species){
            const auto owned=local_index(cell);const auto found=storage->densities.find(species);
            const auto fraction=model->phase_fractions.find(model->mechanism.species.at(species).phase);
            const bool absent=fraction!=model->phase_fractions.end()&&fraction->second.at(fraction->second.size()==1?0:cell)==0;
            if(found!=storage->densities.end()){const double value=found->second.at(owned);require(!absent||value==0,"nonzero local density in an absent phase");return value;}
            return absent?0:model->initial_densities_m3.at(species);
        };
        problem.initial.temperature=[storage,model,phases,local_index](std::size_t cell,std::size_t field){
            const auto owned=local_index(cell);const auto found=storage->temperatures.find(field);if(found!=storage->temperatures.end())return found->second.at(owned);
            const auto& phase=phases.at(field);const auto& values=phase.empty()?model->thermal.initial_temperature_K:model->thermal.phases.at(phase).initial_temperature_K;
            if(!values.empty())return values.at(0);
            return thermal::detail::initial_temperature(model->environment,phase);
        };
        problem.initial.photon=[storage,model,local_index](std::size_t cell,std::size_t group){const auto owned=local_index(cell);const auto found=storage->photons.find(group);if(found!=storage->photons.end())return found->second.at(owned);const auto& values=model->radiation.at(group).initial_density_m3;return values.empty()?0:values[0];};
        if(!storage->potential.empty())problem.initial.potential=[storage,local_index](std::size_t cell){return storage->potential.at(local_index(cell));};
        problem.model=model;
    }catch(const std::exception& error){setup_error=error.what();}
    control.collective_require(setup_error);
    const auto result=solve_distributed(problem);
    Json output;std::string output_error;
    try{
        validate_layout_state(result.state,layout);
        Json densities=Json::object(),potential=Json::array(),temperatures=Json::array(),phase_temperatures=Json::object(),photons=Json::object(),walls=Json::array();
        const auto value=[&](backend::GlobalIndex global){require(layout.owns_dof(global),"attempted to serialize a nonowned value");return result.state.owned_values.at(static_cast<std::size_t>(global-result.state.rows.row_begin));};
        const auto cells=layout.owned_cells();
        for(std::size_t species=0;species<model->mechanism.species.size();++species){Json values=Json::array();for(std::size_t c=cells.begin;c<cells.begin+cells.count;++c)values.push_back(value(layout.cell_dof(c,species)));densities[model->mechanism.species[species].id]=std::move(values);}
        for(std::size_t c=cells.begin;c<cells.begin+cells.count;++c)potential.push_back(value(layout.cell_dof(c,layout.phi_component())));
        for(std::size_t field=0;field<phases.size();++field){Json values=Json::array();for(std::size_t c=cells.begin;c<cells.begin+cells.count;++c)values.push_back(value(layout.cell_dof(c,layout.thermal_component(field))));if(phases[field].empty())temperatures=std::move(values);else phase_temperatures[phases[field]]=std::move(values);}
        for(std::size_t group=0;group<model->radiation.size();++group){Json values=Json::array();for(std::size_t c=cells.begin;c<cells.begin+cells.count;++c)values.push_back(value(layout.cell_dof(c,layout.photon_component(group))));photons[model->radiation[group].id]=std::move(values);}
        for(std::size_t w=0;w<geometry.walls.size();++w)if(layout.is_dielectric(w)&&layout.owns_dof(layout.sigma_dof(w)))walls.push_back({{"wall_index",w},{"surface_charge_C_m2",value(layout.sigma_dof(w))},{"dielectric_potential_V",value(layout.dielectric_dof(w))}});
        Json counts=Json::object(),collected=Json::object(),history=Json::array();
        require(result.particle_counts.size()==model->mechanism.species.size()&&result.particles_collected_at_boundaries.size()==model->mechanism.species.size(),"reduced particle diagnostics differ from species count");
        for(std::size_t s=0;s<model->mechanism.species.size();++s){counts[model->mechanism.species[s].id]=result.particle_counts[s];collected[model->mechanism.species[s].id]=result.particles_collected_at_boundaries[s];}
        for(const auto& sample:result.samples)history.push_back(sample_json(sample));
        output={{"success",result.success},{"message",result.message},{"time_s",result.state.time_s},{"accepted_steps",result.accepted_steps},{"rejected_steps",result.rejected_steps},
            {"cell_begin",cells.begin},{"cell_count",cells.count},{"state",state_json(result.state)},{"densities_m3",densities},{"potential_V",potential},{"temperature_K",temperatures},{"phase_temperatures_K",phase_temperatures},{"photon_densities_m3",photons},{"dielectric_walls",walls},
            {"particle_counts",counts},{"particles_collected_at_boundaries",collected},{"chemical_energy_integrals_J",result.chemical_energy_integrals_J},{"history",history},{"checkpoint",checkpoint_json(result.checkpoint,physical)},
            {"storage",{{"local_unknowns",result.local_unknowns},{"halo_unknowns",result.halo_unknowns},{"local_kinetic_unknowns",result.local_kinetic_unknowns},{"kinetic_halo_unknowns",result.kinetic_halo_unknowns},{"peak_local_matrix_entries",result.peak_local_matrix_entries},{"peak_local_state_entries",result.peak_local_state_entries}}},
            {"execution_scope","owned cell DOFs and full angular states; dependency halos; no global solution gather"}};
        if(layout.circuit_dof()!=partition::no_dof&&layout.owns_dof(layout.circuit_dof()))output["owned_circuit"]={{"global_dof",layout.circuit_dof()},{"driven_voltage_V",value(layout.circuit_dof())}};
    }catch(const std::exception& error){output_error=error.what();}
    control.collective_require(output_error);return output;
}
} // namespace raikou::spatial
