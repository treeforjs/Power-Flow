#include "raikou/spherical_harmonics.h"
#include "eedf_operators.h"
#include <algorithm>
#include <cmath>
#include <limits>
#include <numbers>
#include <stdexcept>

namespace raikou::kinetics {
namespace {
[[noreturn]] void invalid(const std::string& text) { throw std::invalid_argument("spherical EEDF: " + text); }
constexpr double electron_charge = 1.602176634e-19, electron_mass = 9.1093837015e-31;
double magnitude(const Vector3& v) { return std::hypot(v[0], v[1], v[2]); }
void validate_terms(int terms) { if (terms < 1 || terms > 30) invalid("angular terms must be between 1 and 30"); }
double face(const EedfGrid& grid, std::size_t i) {
    return grid.max_energy_ev * std::pow(static_cast<double>(i) / grid.cells, grid.power);
}
double centre(const EedfGrid& grid, std::size_t i) { return 0.5 * (face(grid, i) + face(grid, i + 1)); }
double weight(const EedfGrid& grid, std::size_t i) {
    return 2.0 / 3 * (std::pow(face(grid, i + 1), 1.5) - std::pow(face(grid, i), 1.5));
}
std::size_t legacy_slot(int degree, int terms) {
    return degree % 2 == 0 ? static_cast<std::size_t>(degree / 2) : static_cast<std::size_t>((terms + 1) / 2 + (degree - 1) / 2);
}
void validate_rotation(const AngularRotation& rotation) {
    const auto& r = rotation.matrix;
    for (double value : r) if (!std::isfinite(value)) invalid("rotation entries must be finite");
    for (std::size_t i = 0; i < 3; ++i) for (std::size_t j = 0; j < 3; ++j) {
        double value = 0;
        for (std::size_t k = 0; k < 3; ++k) value += r[k * 3 + i] * r[k * 3 + j];
        if (std::abs(value - (i == j ? 1.0 : 0.0)) > 1e-10) invalid("rotation must be orthogonal");
    }
    const double determinant = r[0] * (r[4] * r[8] - r[5] * r[7]) - r[1] * (r[3] * r[8] - r[5] * r[6]) + r[2] * (r[3] * r[7] - r[4] * r[6]);
    if (std::abs(determinant - 1) > 1e-10) invalid("rotation must be proper (determinant +1)");
}
std::pair<std::vector<double>, std::vector<double>> gauss_legendre(int count) {
    std::vector<double> nodes(static_cast<std::size_t>(count)), weights(nodes.size());
    for (int root = 0; root < (count + 1) / 2; ++root) {
        double x = std::cos(std::numbers::pi * (root + 0.75) / (count + 0.5)), derivative = 0;
        for (int iteration = 0; iteration < 40; ++iteration) {
            double p = 1, previous = 0;
            for (int degree = 1; degree <= count; ++degree) {
                const double next = ((2 * degree - 1) * x * p - (degree - 1) * previous) / degree;
                previous = p; p = next;
            }
            derivative = count * (x * p - previous) / (x * x - 1);
            const double change = p / derivative;
            x -= change;
            if (std::abs(change) < 4 * std::numeric_limits<double>::epsilon()) break;
        }
        const double w = 2 / ((1 - x * x) * derivative * derivative);
        nodes[static_cast<std::size_t>(root)] = -x;
        nodes[static_cast<std::size_t>(count - 1 - root)] = x;
        weights[static_cast<std::size_t>(root)] = w;
        weights[static_cast<std::size_t>(count - 1 - root)] = w;
    }
    return {std::move(nodes), std::move(weights)};
}
} // namespace

std::size_t spherical_index(int degree, int order) {
    if (degree < 0 || degree >= 30 || order < -degree || order > degree) invalid("invalid harmonic degree/order");
    return static_cast<std::size_t>(degree * degree + degree + order);
}
Vector3 rotate_vector(const AngularRotation& rotation, const Vector3& vector) {
    Vector3 result{};
    for (std::size_t row = 0; row < 3; ++row) for (std::size_t column = 0; column < 3; ++column)
        result[row] += rotation.matrix[row * 3 + column] * vector[column];
    return result;
}
AngularRotation axis_angle_rotation(const Vector3& axis, double angle_rad) {
    const double norm = magnitude(axis);
    if (!(norm > 0 && std::isfinite(norm) && std::isfinite(angle_rad))) invalid("rotation axis and angle must be finite, with nonzero axis");
    const double x = axis[0] / norm, y = axis[1] / norm, z = axis[2] / norm, c = std::cos(angle_rad), s = std::sin(angle_rad), d = 1 - c;
    return {{c + x*x*d, x*y*d - z*s, x*z*d + y*s,
             y*x*d + z*s, c + y*y*d, y*z*d - x*s,
             z*x*d - y*s, z*y*d + x*s, c + z*z*d}};
}
AngularRotation rotation_to_axis(const Vector3& axis) {
    const double norm = magnitude(axis);
    if (!(norm > 0 && std::isfinite(norm))) invalid("field axis must be finite and nonzero");
    const double nx = axis[0] / norm, ny = axis[1] / norm, nz = axis[2] / norm;
    if (nz < -1 + 1e-14) return {{1, 0, 0, 0, -1, 0, 0, 0, -1}};
    const double w = std::sqrt((1 + nz) / 2), x = -ny / (2 * w), y = nx / (2 * w);
    return {{1 - 2*y*y, 2*x*y, 2*y*w,
             2*x*y, 1 - 2*x*x, -2*x*w,
             -2*y*w, 2*x*w, 1 - 2*(x*x + y*y)}};
}
AngularRotation inverse_rotation(const AngularRotation& rotation) {
    validate_rotation(rotation);
    AngularRotation result;
    for (std::size_t i = 0; i < 3; ++i) for (std::size_t j = 0; j < 3; ++j) result.matrix[i * 3 + j] = rotation.matrix[j * 3 + i];
    return result;
}
AngularRotation compose_rotations(const AngularRotation& left, const AngularRotation& right) {
    validate_rotation(left); validate_rotation(right);
    AngularRotation result; result.matrix.fill(0);
    for (std::size_t i = 0; i < 3; ++i) for (std::size_t j = 0; j < 3; ++j) for (std::size_t k = 0; k < 3; ++k)
        result.matrix[i * 3 + j] += left.matrix[i * 3 + k] * right.matrix[k * 3 + j];
    return result;
}

std::vector<double> real_spherical_harmonics(int terms, const Vector3& direction) {
    validate_terms(terms);
    const double norm = magnitude(direction);
    if (!(norm > 0 && std::isfinite(norm))) invalid("angular direction must be finite and nonzero");
    const double z = std::clamp(direction[2] / norm, -1.0, 1.0), radial = std::hypot(direction[0], direction[1]);
    const double sine = std::sqrt(std::max(0.0, 1 - z*z));
    const double cphi = radial > 0 ? direction[0] / radial : 1, sphi = radial > 0 ? direction[1] / radial : 0;
    std::vector<double> result(static_cast<std::size_t>(terms * terms), 0.0);
    double pmm = 1, cm = 1, sm = 0;
    for (int m = 0; m < terms; ++m) {
        if (m > 0) {
            pmm *= (2 * m - 1) * sine;
            const double next_c = cm * cphi - sm * sphi;
            sm = sm * cphi + cm * sphi; cm = next_c;
        }
        double previous = 0, p = pmm;
        for (int l = m; l < terms; ++l) {
            if (l > m) {
                const double next = ((2*l - 1) * z * p - (l + m - 1) * previous) / (l - m);
                previous = p; p = next;
            }
            const double normalization = std::sqrt((2*l + 1) * (m == 0 ? 1.0 : 2.0) *
                std::exp(std::lgamma(l - m + 1.0) - std::lgamma(l + m + 1.0)));
            result[spherical_index(l, m)] = normalization * p * cm;
            if (m > 0) result[spherical_index(l, -m)] = normalization * p * sm;
        }
    }
    return result;
}

std::vector<AngularNode> spherical_quadrature(int terms, int polar_points, int azimuthal_points) {
    validate_terms(terms);
    const int nz = polar_points > 0 ? polar_points : terms + 1, np = azimuthal_points > 0 ? azimuthal_points : 2 * terms + 1;
    if (nz < terms || np < 2 * terms - 1) invalid("angular quadrature under-resolves retained harmonics");
    const auto [z, weights] = gauss_legendre(nz);
    std::vector<AngularNode> nodes;
    nodes.reserve(static_cast<std::size_t>(nz * np));
    for (int i = 0; i < nz; ++i) for (int j = 0; j < np; ++j) {
        const double phi = 2 * std::numbers::pi * j / np, radial = std::sqrt(std::max(0.0, 1 - z[static_cast<std::size_t>(i)] * z[static_cast<std::size_t>(i)]));
        const Vector3 direction{radial * std::cos(phi), radial * std::sin(phi), z[static_cast<std::size_t>(i)]};
        nodes.push_back({direction, weights[static_cast<std::size_t>(i)] / (2 * np), real_spherical_harmonics(terms, direction)});
    }
    return nodes;
}

void SphericalEedfState::validate() const {
    if (grid.cells < 16 || grid.cells > 6000 || grid.legendre_terms < 2 || grid.legendre_terms > 30 ||
        !(grid.max_energy_ev > 0 && std::isfinite(grid.max_energy_ev)) || !(grid.power >= 1 && grid.power <= 4)) invalid("invalid energy/angular grid");
    if (!(time_s >= 0 && std::isfinite(time_s))) invalid("invalid state time");
    const auto stride = static_cast<std::size_t>(grid.legendre_terms * grid.legendre_terms);
    if (density_modes.size() != static_cast<std::size_t>(grid.cells) * stride) invalid("full angular mode count differs from grid");
    for (double value : density_modes) if (!std::isfinite(value)) invalid("angular modes must be finite");
    const auto last = static_cast<std::size_t>(grid.cells - 1) * stride;
    for (int l = 1; l < grid.legendre_terms; l += 2) for (int m = -l; m <= l; ++m)
        if (density_modes[last + spherical_index(l, m)] != 0) invalid("odd-mode boundary padding must be zero");
}
double SphericalEedfState::electron_density_m3() const {
    validate();
    const auto stride = static_cast<std::size_t>(grid.legendre_terms * grid.legendre_terms);
    double value = 0;
    for (std::size_t i = 0; i < static_cast<std::size_t>(grid.cells); ++i) value += weight(grid, i) * density_modes[i * stride];
    return value;
}
double SphericalEedfState::electron_energy_ev_m3() const {
    validate();
    const auto stride = static_cast<std::size_t>(grid.legendre_terms * grid.legendre_terms);
    double value = 0;
    for (std::size_t i = 0; i < static_cast<std::size_t>(grid.cells); ++i) value += centre(grid, i) * weight(grid, i) * density_modes[i * stride];
    return value;
}
double SphericalEedfState::mean_energy_ev() const {
    const double density = electron_density_m3();
    if (!(density > 0)) invalid("positive electron density is required for mean energy");
    return electron_energy_ev_m3() / density;
}
Vector3 SphericalEedfState::particle_flux_m2_s() const {
    validate();
    Vector3 result{};
    const auto stride = static_cast<std::size_t>(grid.legendre_terms * grid.legendre_terms);
    const double gamma = std::sqrt(2 * electron_charge / electron_mass) / std::sqrt(3.0);
    for (std::size_t k = 1; k < static_cast<std::size_t>(grid.cells); ++k) {
        const double value = gamma * face(grid, k) * (centre(grid, k) - centre(grid, k - 1));
        const auto slot = (k - 1) * stride;
        result[0] += value * density_modes[slot + spherical_index(1, 1)];
        result[1] += value * density_modes[slot + spherical_index(1, -1)];
        result[2] += value * density_modes[slot + spherical_index(1, 0)];
    }
    return result;
}
Vector3 SphericalEedfState::energy_flux_ev_m2_s() const {
    validate();
    Vector3 result{};
    const auto stride = static_cast<std::size_t>(grid.legendre_terms * grid.legendre_terms);
    const double gamma = std::sqrt(2 * electron_charge / electron_mass) / std::sqrt(3.0);
    for (std::size_t k = 1; k < static_cast<std::size_t>(grid.cells); ++k) {
        const double energy = face(grid, k), value = gamma * energy * energy * (centre(grid, k) - centre(grid, k - 1));
        const auto slot = (k - 1) * stride;
        result[0] += value * density_modes[slot + spherical_index(1, 1)];
        result[1] += value * density_modes[slot + spherical_index(1, -1)];
        result[2] += value * density_modes[slot + spherical_index(1, 0)];
    }
    return result;
}

HarmonicRotation::HarmonicRotation(int terms, const AngularRotation& rotation) : terms_(terms) {
    validate_terms(terms); validate_rotation(rotation);
    offsets_.push_back(0);
    for (int l = 0; l < terms; ++l) offsets_.push_back(offsets_.back() + static_cast<std::size_t>((2*l + 1)*(2*l + 1)));
    blocks_.assign(offsets_.back(), 0);
    if (rotation.matrix == AngularRotation{}.matrix) {
        for (int l = 0; l < terms; ++l) for (int m = 0; m < 2*l + 1; ++m)
            blocks_[offsets_[static_cast<std::size_t>(l)] + static_cast<std::size_t>(m * (2*l + 1) + m)] = 1;
        return;
    }
    const auto inverse = inverse_rotation(rotation);
    // Exact polynomial quadrature for each fixed-degree rotation block. NIST DLMF
    // 14.30 defines the harmonics; this real basis is a normalized phase convention.
    for (const auto& node : spherical_quadrature(terms)) {
        const auto transformed = real_spherical_harmonics(terms, rotate_vector(inverse, node.direction));
        for (int l = 1; l < terms; ++l) for (int m = -l; m <= l; ++m) for (int order = -l; order <= l; ++order)
            blocks_[offsets_[static_cast<std::size_t>(l)] + static_cast<std::size_t>((m + l) * (2*l + 1) + order + l)] +=
                node.weight * node.basis[spherical_index(l, m)] * transformed[spherical_index(l, order)];
    }
    blocks_[0] = 1;
}
void HarmonicRotation::apply(std::span<const double> input_modes, std::span<double> output_modes) const {
    const auto count = static_cast<std::size_t>(terms_ * terms_);
    if (input_modes.size() != count || output_modes.size() != count || input_modes.data() == output_modes.data())
        invalid("harmonic rotation requires distinct vectors of terms squared modes");
    output_modes[0] = input_modes[0];
    for (int l = 1; l < terms_; ++l) for (int m = -l; m <= l; ++m) {
        double value = 0;
        for (int order = -l; order <= l; ++order)
            value += blocks_[offsets_[static_cast<std::size_t>(l)] + static_cast<std::size_t>((m + l) * (2*l + 1) + order + l)] * input_modes[spherical_index(l, order)];
        output_modes[spherical_index(l, m)] = value;
    }
}
SphericalEedfState rotate_spherical_eedf(const SphericalEedfState& state, const AngularRotation& rotation) {
    state.validate(); validate_rotation(rotation);
    if (rotation.matrix == AngularRotation{}.matrix) return state;
    const int terms = state.grid.legendre_terms;
    const HarmonicRotation transform(terms, rotation);
    SphericalEedfState result = state;
    const auto stride = static_cast<std::size_t>(terms * terms);
    backend::parallel_for(static_cast<std::size_t>(state.grid.cells), 0, [&](std::size_t i) {
        const auto start = i * stride;
        transform.apply(std::span<const double>(state.density_modes).subspan(start, stride), std::span<double>(result.density_modes).subspan(start, stride));
    });
    return result;
}

SphericalEedfState spherical_from_legendre(const EedfState& state, const Vector3& symmetry_axis) {
    (void)state.electron_density_m3();
    SphericalEedfState result;
    result.grid = state.grid; result.time_s = state.time_s;
    const int terms = state.grid.legendre_terms;
    const auto stride = static_cast<std::size_t>(terms * terms);
    result.density_modes.assign(static_cast<std::size_t>(state.grid.cells) * stride, 0);
    for (std::size_t i = 0; i < static_cast<std::size_t>(state.grid.cells); ++i) for (int l = 0; l < terms; ++l)
        result.density_modes[i * stride + spherical_index(l, 0)] = state.density_modes[i * static_cast<std::size_t>(terms) + legacy_slot(l, terms)] / std::sqrt(2*l + 1.0);
    return rotate_spherical_eedf(result, rotation_to_axis(symmetry_axis));
}
EedfState legendre_from_spherical(const SphericalEedfState& state, const Vector3& symmetry_axis, double angular_tolerance) {
    if (!(angular_tolerance >= 0 && std::isfinite(angular_tolerance))) invalid("angular tolerance must be finite and nonnegative");
    const auto aligned = rotate_spherical_eedf(state, inverse_rotation(rotation_to_axis(symmetry_axis)));
    const int terms = state.grid.legendre_terms;
    const auto stride = static_cast<std::size_t>(terms * terms);
    double largest = 0, discarded = 0;
    for (std::size_t i = 0; i < static_cast<std::size_t>(state.grid.cells); ++i) for (int l = 0; l < terms; ++l) for (int m = -l; m <= l; ++m) {
        const double value = std::abs(aligned.density_modes[i * stride + spherical_index(l, m)]);
        largest = std::max(largest, value);
        if (m != 0) discarded = std::max(discarded, value);
    }
    if (discarded > angular_tolerance * std::max(largest, 1e-300)) invalid("conversion to Legendre would discard azimuthal modes");
    EedfState result;
    result.grid = state.grid; result.time_s = state.time_s;
    result.density_modes.assign(static_cast<std::size_t>(state.grid.cells * terms), 0);
    for (std::size_t i = 0; i < static_cast<std::size_t>(state.grid.cells); ++i) for (int l = 0; l < terms; ++l)
        result.density_modes[i * static_cast<std::size_t>(terms) + legacy_slot(l, terms)] = aligned.density_modes[i * stride + spherical_index(l, 0)] * std::sqrt(2*l + 1.0);
    return result;
}

SphericalEedfEvaluation evaluate_spherical_eedf(const std::vector<CollisionProcess>& processes, const EedfConditions& conditions,
    const SphericalEedfState& state, const Vector3& electric_field_V_m) {
    state.validate();
    const double field = magnitude(electric_field_V_m), density = state.electron_density_m3();
    if (!std::isfinite(field)) invalid("electric field must be finite");
    if (!(density > 0)) invalid("positive electron density is required for collision evaluation");
    if (!(conditions.gas_density_m3 > 0 && std::isfinite(conditions.gas_density_m3))) invalid("reference gas density must be finite and positive");
    const Vector3 acceleration_axis{-electric_field_V_m[0], -electric_field_V_m[1], -electric_field_V_m[2]};
    const auto rotation = field > 0 ? rotation_to_axis(acceleration_axis) : AngularRotation{};
    const auto aligned = rotate_spherical_eedf(state, inverse_rotation(rotation));
    const int terms = state.grid.legendre_terms;
    const auto stride = static_cast<std::size_t>(terms * terms), radial_size = static_cast<std::size_t>(state.grid.cells);
    std::vector<double> isotropic(radial_size * static_cast<std::size_t>(terms), 0);
    for (std::size_t i = 0; i < radial_size; ++i) for (int l = 0; l < terms; ++l)
        isotropic[i * static_cast<std::size_t>(terms) + legacy_slot(l, terms)] =
            aligned.density_modes[i * stride + spherical_index(l, 0)] * std::sqrt(2*l + 1.0) / density;
    auto local_conditions = conditions;
    local_conditions.reduced_field_td = field / conditions.gas_density_m3 / 1e-21;
    local_conditions.electron_fraction = density / conditions.gas_density_m3;
    SphericalEedfEvaluation result;
    auto derivative = aligned;
    derivative.density_modes.assign(aligned.density_modes.size(), 0);
    for (int m = 0; m < terms; ++m) for (int sign : {-1, 1}) {
        if (m == 0 && sign == -1) continue;
        std::vector<double> packed(radial_size * static_cast<std::size_t>(terms), 0);
        for (std::size_t i = 0; i < radial_size; ++i) for (int l = m; l < terms; ++l)
            packed[i * static_cast<std::size_t>(terms) + legacy_slot(l, terms)] =
                aligned.density_modes[i * stride + spherical_index(l, sign*m)] * (m == 0 ? std::sqrt(2*l + 1.0) : 1.0);
        auto evaluation = detail::evaluate_azimuthal_rhs(processes, local_conditions, state.grid, m, packed, isotropic);
        if (m == 0) result.swarm = std::move(evaluation.swarm);
        for (std::size_t i = 0; i < radial_size; ++i) for (int l = m; l < terms; ++l)
            derivative.density_modes[i * stride + spherical_index(l, sign*m)] =
                evaluation.rates[i * static_cast<std::size_t>(terms) + legacy_slot(l, terms)] / (m == 0 ? std::sqrt(2*l + 1.0) : 1.0);
    }
    derivative = rotate_spherical_eedf(derivative, rotation);
    result.electron_production_m3_s = derivative.electron_density_m3();
    result.electron_energy_rate_ev_m3_s = derivative.electron_energy_ev_m3();
    result.density_mode_rates = std::move(derivative.density_modes);
    return result;
}

SphericalEedfStepResult advance_spherical_eedf(const std::vector<CollisionProcess>& processes, const EedfConditions& conditions,
    const SphericalEedfState& initial, const Vector3& electric_field_V_m, double dt_s) {
    initial.validate();
    const double field = magnitude(electric_field_V_m);
    if (!std::isfinite(field)) invalid("electric field must be finite");
    if (!(conditions.gas_density_m3 > 0 && std::isfinite(conditions.gas_density_m3))) invalid("reference gas density must be finite and positive");
    const Vector3 acceleration_axis{-electric_field_V_m[0], -electric_field_V_m[1], -electric_field_V_m[2]};
    const auto rotation = field > 0 ? rotation_to_axis(acceleration_axis) : AngularRotation{};
    const auto aligned = rotate_spherical_eedf(initial, inverse_rotation(rotation));
    const int terms = initial.grid.legendre_terms;
    const auto stride = static_cast<std::size_t>(terms * terms), radial_size = static_cast<std::size_t>(initial.grid.cells);
    EedfState m0;
    m0.grid = initial.grid; m0.time_s = initial.time_s; m0.density_modes.assign(radial_size * static_cast<std::size_t>(terms), 0);
    for (std::size_t i = 0; i < radial_size; ++i) for (int l = 0; l < terms; ++l)
        m0.density_modes[i * static_cast<std::size_t>(terms) + legacy_slot(l, terms)] = aligned.density_modes[i * stride + spherical_index(l, 0)] * std::sqrt(2*l + 1.0);
    auto local_conditions = conditions;
    local_conditions.reduced_field_td = field / conditions.gas_density_m3 / 1e-21;
    const auto longitudinal = advance_eedf(processes, local_conditions, m0, dt_s);
    SphericalEedfStepResult result;
    result.state = aligned; result.state.time_s += dt_s;
    result.swarm = longitudinal.swarm; result.nonlinear_iterations = longitudinal.nonlinear_iterations;
    result.linear_residual = longitudinal.linear_residual; result.energy_balance_relative = longitudinal.energy_balance_relative;
    const double density = longitudinal.state.electron_density_m3();
    std::vector<double> isotropic = longitudinal.state.density_modes;
    for (double& value : isotropic) value /= density;
    local_conditions.electron_fraction = density / conditions.gas_density_m3;
    for (std::size_t i = 0; i < radial_size; ++i) for (int l = 0; l < terms; ++l)
        result.state.density_modes[i * stride + spherical_index(l, 0)] = longitudinal.state.density_modes[i * static_cast<std::size_t>(terms) + legacy_slot(l, terms)] / std::sqrt(2*l + 1.0);
    for (int m = 1; m < terms; ++m) for (int sign : {-1, 1}) {
        std::vector<double> packed(radial_size * static_cast<std::size_t>(terms), 0);
        bool nonzero = false;
        for (std::size_t i = 0; i < radial_size; ++i) for (int l = m; l < terms; ++l) {
            const double value = aligned.density_modes[i * stride + spherical_index(l, sign*m)];
            packed[i * static_cast<std::size_t>(terms) + legacy_slot(l, terms)] = value;
            nonzero = nonzero || value != 0;
        }
        if (!nonzero) continue;
        const auto step = detail::advance_azimuthal_eedf(processes, local_conditions, initial.grid, m, packed, isotropic, dt_s);
        result.linear_residual = std::max(result.linear_residual, step.linear_residual);
        for (std::size_t i = 0; i < radial_size; ++i) for (int l = m; l < terms; ++l)
            result.state.density_modes[i * stride + spherical_index(l, sign*m)] = step.modes[i * static_cast<std::size_t>(terms) + legacy_slot(l, terms)];
    }
    result.state = rotate_spherical_eedf(result.state, rotation);
    result.flux_velocity_m_s = result.state.particle_flux_m2_s();
    for (double& value : result.flux_velocity_m_s) value /= density;
    return result;
}
} // namespace raikou::kinetics
