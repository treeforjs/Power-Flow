#include "raikou/distributed.h"
#include "raikou/device.h"
#include "raikou/device_distributed.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <limits>
#include <map>
#include <mutex>
#include <stdexcept>
#include <utility>

namespace raikou::backend {
namespace {
std::string vector_error(std::span<const double> values, std::size_t count) {
    if (values.size() != count) return "distributed vector size does not match local rows";
    for (const double value : values) if (!std::isfinite(value)) return "non-finite distributed vector entry";
    return {};
}
template<class Action> void local_phase(const DistributedHalo& halo, Action&& action) {
    std::string error;
    try { action(); }
    catch (const std::exception& exception) { error = exception.what(); }
    catch (...) { error = "unknown failure in local distributed work"; }
    halo.collective_require(error);
}
double norm(const DistributedHalo& halo, std::span<const double> values) {
    double scale = 0;
    for (const double value : values) scale = std::max(scale, std::abs(value));
    scale = halo.global_max(scale);
    if (scale == 0) return 0;
    double local = 0;
    for (const double value : values) { const double normalized = value / scale; local += normalized * normalized; }
    const double result = scale * std::sqrt(halo.global_sum(local));
    if (!std::isfinite(result)) throw std::runtime_error("distributed norm overflow");
    return result;
}
double dot(const DistributedHalo& halo, std::span<const double> left, std::span<const double> right) {
    long double local = 0;
    for (std::size_t index = 0; index < left.size(); ++index)
        local += static_cast<long double>(left[index]) * static_cast<long double>(right[index]);
    return halo.global_sum(static_cast<double>(local));
}
class LocalPreconditioner {
    std::vector<std::map<std::size_t, double>> factors_;
    std::vector<double> diagonal_;
    bool ilu_;
public:
    LocalPreconditioner(const DistributedCsrMatrix& matrix, const std::string& kind)
        : diagonal_(matrix.local_rows(), 0.0), ilu_(kind == "block_ilu0") {
        if (kind != "jacobi" && kind != "block_ilu0") throw std::invalid_argument("distributed preconditioner must be jacobi or block_ilu0");
        if (ilu_) factors_.resize(matrix.local_rows());
        for (std::size_t row = 0; row < matrix.local_rows(); ++row) {
            for (auto entry = matrix.offsets[row]; entry < matrix.offsets[row + 1]; ++entry) {
                const auto column = matrix.columns[entry];
                if (column == matrix.row_begin + row) diagonal_[row] += matrix.values[entry];
                if (ilu_ && column >= matrix.row_begin && column < matrix.row_begin + matrix.local_rows())
                    factors_[row][static_cast<std::size_t>(column - matrix.row_begin)] += matrix.values[entry];
            }
            if (!std::isfinite(diagonal_[row])) throw std::runtime_error("distributed diagonal overflow");
            // A subnormal diagonal has an unrepresentable reciprocal. Leave
            // that row unscaled; the projected solve still retains its units.
            if (!ilu_ && std::abs(diagonal_[row]) < std::numeric_limits<double>::min()) diagonal_[row] = 1.0;
        }
        if (!ilu_) return;
        for (std::size_t row = 0; row < factors_.size(); ++row) {
            auto& entries = factors_[row];
            for (auto lower = entries.begin(); lower != entries.end() && lower->first < row; ++lower) {
                const auto column = lower->first;
                const auto pivot = factors_[column].find(column);
                if (pivot == factors_[column].end() || pivot->second == 0.0 || !std::isfinite(pivot->second))
                    throw std::runtime_error("rank-local ILU(0) encountered a zero pivot; choose jacobi or repair the local block");
                lower->second /= pivot->second;
                if (!std::isfinite(lower->second)) throw std::runtime_error("rank-local ILU(0) factor overflow");
                for (auto upper = factors_[column].upper_bound(column); upper != factors_[column].end(); ++upper) {
                    const auto found = entries.find(upper->first);
                    if (found != entries.end()) {
                        found->second -= lower->second * upper->second;
                        if (!std::isfinite(found->second)) throw std::runtime_error("rank-local ILU(0) factor overflow");
                    }
                }
            }
            const auto diagonal = entries.find(row);
            if (diagonal == entries.end() || diagonal->second == 0.0 || !std::isfinite(diagonal->second))
                throw std::runtime_error("rank-local ILU(0) requires a nonsingular local diagonal block");
        }
    }
    std::vector<double> apply(std::span<const double> input) const {
        std::vector<double> result(input.begin(), input.end());
        if (!ilu_) {
            for (std::size_t row = 0; row < result.size(); ++row) result[row] /= diagonal_[row];
        } else {
            for (std::size_t row = 0; row < result.size(); ++row)
                for (auto entry = factors_[row].begin(); entry != factors_[row].end() && entry->first < row; ++entry)
                    result[row] -= entry->second * result[entry->first];
            for (std::size_t row = result.size(); row-- > 0;) {
                for (auto entry = factors_[row].upper_bound(row); entry != factors_[row].end(); ++entry)
                    result[row] -= entry->second * result[entry->first];
                result[row] /= factors_[row].at(row);
            }
        }
        for (const double value : result) if (!std::isfinite(value)) throw std::runtime_error("distributed preconditioner overflow");
        return result;
    }
};
}

struct DistributedLinearOperator::Impl {
    DistributedCsrMatrix matrix;
    ExecutionOptions options;
    DistributedHalo halo;
    std::vector<int> compact_columns;
    mutable std::recursive_mutex mutex;
    mutable std::unique_ptr<DeviceExecutor> device;
    mutable std::unique_ptr<DeviceVector> device_input, device_output;

    Impl(DistributedCsrMatrix input, const ExecutionOptions& configuration)
        : matrix(std::move(input)), options(configuration), halo(matrix.partition(), matrix.columns, configuration) {
        local_phase(halo, [&] {
            matrix.validate_local();
            if (!(options.tolerance > 0 && std::isfinite(options.tolerance)) || options.max_iterations <= 0 || options.restart <= 0)
                throw std::invalid_argument("invalid distributed Krylov solver controls");
            if (options.device != "cpu" && options.device != "cuda") throw std::invalid_argument("distributed device must be cpu or cuda");
            if (options.preconditioner != "jacobi" && options.preconditioner != "block_ilu0")
                throw std::invalid_argument("distributed preconditioner must be jacobi or block_ilu0");
            if (options.device == "cuda" && !cuda_available()) throw std::runtime_error("distributed CUDA backend is unavailable");
            if (matrix.local_rows() + halo.layout().ghost_global_ids.size() > static_cast<std::size_t>(std::numeric_limits<int>::max()))
                throw std::invalid_argument("compact local and ghost column count exceeds supported index range");
            compact_columns.reserve(matrix.columns.size());
            for (const auto column : matrix.columns) compact_columns.push_back(static_cast<int>(halo.compact_index(column)));
        });
        const std::array<double, 5> controls{options.tolerance, static_cast<double>(options.max_iterations),
            static_cast<double>(options.restart), options.device == "cuda" ? 1.0 : 0.0,
            options.preconditioner == "block_ilu0" ? 1.0 : 0.0};
        for (const auto value : controls) {
            const double maximum = halo.global_max(value), minimum = -halo.global_max(-value);
            halo.collective_require(maximum != minimum ? "ranks supplied different distributed Krylov controls or devices" : "");
        }
    }
    CompactCsrView compact() const noexcept {
        return {matrix.local_rows(), matrix.local_rows() + halo.layout().ghost_global_ids.size(),
            matrix.offsets, compact_columns, matrix.values};
    }
    std::vector<double> apply(std::span<const double> local) const {
        halo.collective_require(vector_error(local, matrix.local_rows()));
        const auto ghosts = halo.exchange(local);
        std::vector<double> result;
        local_phase(halo, [&] {
            std::vector<double> extended;
            extended.reserve(local.size() + ghosts.size());
            extended.insert(extended.end(), local.begin(), local.end());
            extended.insert(extended.end(), ghosts.begin(), ghosts.end());
            if (options.device == "cuda") {
                if (!device) {
                    const auto view = compact();
                    device = make_cuda_executor({view.rows, view.input_columns, view.offsets, view.columns, view.values}, options.cuda_device);
                    device_input = device->allocate(view.input_columns);
                    device_output = device->allocate(view.rows);
                }
                device->upload(extended, *device_input);
                device->apply(*device_input, *device_output);
                result = device->download(*device_output);
            } else {
                result.assign(matrix.local_rows(), 0.0);
                parallel_for(matrix.local_rows(), options.threads, [&](std::size_t row) {
                    double value = 0;
                    for (auto entry = matrix.offsets[row]; entry < matrix.offsets[row + 1]; ++entry)
                        value += matrix.values[entry] * extended[static_cast<std::size_t>(compact_columns[entry])];
                    result[row] = value;
                });
            }
            const auto error = vector_error(result, matrix.local_rows());
            if (!error.empty()) throw std::runtime_error(error);
        });
        return result;
    }
};

DistributedLinearOperator::DistributedLinearOperator(DistributedCsrMatrix matrix, const ExecutionOptions& options)
    : impl_(std::make_shared<Impl>(std::move(matrix), options)) {}
const DistributedCsrMatrix& DistributedLinearOperator::matrix() const noexcept { return impl_->matrix; }
CompactCsrView DistributedLinearOperator::compact_matrix() const noexcept { return impl_->compact(); }
const DistributedHalo& DistributedLinearOperator::halo() const noexcept { return impl_->halo; }
const ExecutionOptions& DistributedLinearOperator::options() const noexcept { return impl_->options; }
std::vector<double> DistributedLinearOperator::apply(std::span<const double> local) const {
    std::lock_guard lock(impl_->mutex);
    return impl_->apply(local);
}
DistributedLinearResult DistributedLinearOperator::solve(std::span<const double> rhs) const {
    std::lock_guard lock(impl_->mutex);
    if (impl_->options.device == "cuda") return solve_distributed_cuda(*this, rhs);
    return solve_distributed_matrix_free(impl_->halo, impl_->matrix,
        [this](std::span<const double> values) { return impl_->apply(values); }, rhs, impl_->options);
}
DistributedLinearResult solve_distributed_matrix_free(const DistributedHalo& h, const DistributedCsrMatrix& matrix,
    const CsrOperator& callback, std::span<const double> rhs, const ExecutionOptions& o) {
    const auto p = h.partition();
    h.collective_require(vector_error(rhs, p.local_rows));
    local_phase(h, [&] {
        matrix.validate_local();
        if (matrix.row_begin != p.row_begin || matrix.local_rows() != p.local_rows || matrix.global_rows != p.global_rows)
            throw std::invalid_argument("matrix-free preconditioner ownership differs from halo");
        if (o.device != "cpu" || !callback || !(o.tolerance > 0 && std::isfinite(o.tolerance)) || o.restart <= 0 || o.max_iterations <= 0)
            throw std::invalid_argument("invalid CPU matrix-free solver controls/callback");
    });
    for (const double value : {o.tolerance, static_cast<double>(o.restart), static_cast<double>(o.max_iterations)})
        h.collective_require(h.global_max(value) != -h.global_max(-value) ? "matrix-free ranks supplied different solver controls" : "");
    const auto apply = [&](std::span<const double> values) {
        std::vector<double> output;
        local_phase(h, [&] { output = callback(values); });
        h.collective_require(vector_error(output, p.local_rows));
        return output;
    };
    const auto restart = static_cast<std::size_t>(std::min<GlobalIndex>(static_cast<GlobalIndex>(o.restart), p.global_rows));
    DistributedLinearResult result;
    result.row_begin = p.row_begin; result.global_rows = p.global_rows;
    std::vector<double> b, residual, product;
    std::vector<std::vector<double>> basis, preconditioned;
    std::unique_ptr<LocalPreconditioner> preconditioner;
    local_phase(h, [&] {
        preconditioner = std::make_unique<LocalPreconditioner>(matrix, o.preconditioner);
        result.local_solution.assign(p.local_rows, 0.0);
        b.assign(rhs.begin(), rhs.end()); residual.resize(p.local_rows);
        basis.assign(restart + 1, std::vector<double>(p.local_rows));
        preconditioned.assign(restart, std::vector<double>(p.local_rows));
        result.local_working_vector_entries = (2 * restart + 7) * p.local_rows +
            2 * h.layout().ghost_global_ids.size() + h.layout().send_local_indices.size();
    });
    const double magnitude = norm(h, b);
    if (magnitude == 0) { result.converged = true; return result; }
    while (result.iterations < o.max_iterations) {
        product = apply(result.local_solution);
        local_phase(h, [&] { for (std::size_t row = 0; row < p.local_rows; ++row) residual[row] = b[row] - product[row]; });
        const double beta = norm(h, residual);
        result.residual = beta;
        if (beta / magnitude <= o.tolerance) { result.converged = true; break; }
        local_phase(h, [&] { for (std::size_t row = 0; row < p.local_rows; ++row) basis[0][row] = residual[row] / beta; });
        std::vector<std::vector<double>> hessenberg;
        std::vector<double> cosine, sine, g;
        local_phase(h, [&] {
            hessenberg.assign(restart + 1, std::vector<double>(restart));
            cosine.resize(restart); sine.resize(restart); g.assign(restart + 1, 0.0);
        });
        g[0] = beta;
        std::size_t count = 0;
        for (std::size_t column = 0; column < restart && result.iterations < o.max_iterations; ++column) {
            local_phase(h, [&] { preconditioned[column] = preconditioner->apply(basis[column]); });
            auto work = apply(preconditioned[column]);
            for (int pass = 0; pass < 2; ++pass) {
                for (std::size_t previous = 0; previous <= column; ++previous) {
                    const double coefficient = dot(h, work, basis[previous]);
                    hessenberg[previous][column] += coefficient;
                    local_phase(h, [&] {
                        for (std::size_t row = 0; row < p.local_rows; ++row) work[row] -= coefficient * basis[previous][row];
                    });
                }
            }
            hessenberg[column + 1][column] = norm(h, work);
            const bool breakdown = hessenberg[column + 1][column] == 0.0;
            if (!breakdown) local_phase(h, [&] {
                for (std::size_t row = 0; row < p.local_rows; ++row)
                    basis[column + 1][row] = work[row] / hessenberg[column + 1][column];
            });
            for (std::size_t previous = 0; previous < column; ++previous) {
                const double upper = hessenberg[previous][column], lower = hessenberg[previous + 1][column];
                hessenberg[previous][column] = cosine[previous] * upper + sine[previous] * lower;
                hessenberg[previous + 1][column] = -sine[previous] * upper + cosine[previous] * lower;
            }
            const double diagonal = std::hypot(hessenberg[column][column], hessenberg[column + 1][column]);
            cosine[column] = diagonal > 0 ? hessenberg[column][column] / diagonal : 1.0;
            sine[column] = diagonal > 0 ? hessenberg[column + 1][column] / diagonal : 0.0;
            hessenberg[column][column] = diagonal; hessenberg[column + 1][column] = 0.0;
            g[column + 1] = -sine[column] * g[column]; g[column] *= cosine[column];
            ++result.iterations; count = column + 1;
            if (std::abs(g[column + 1]) / magnitude <= o.tolerance || breakdown) break;
        }
        std::vector<double> coefficients;
        local_phase(h, [&] { coefficients.resize(count); });
        bool singular = false;
        for (std::size_t row = count; row-- > 0;) {
            double value = g[row];
            for (std::size_t column = row + 1; column < count; ++column) value -= hessenberg[row][column] * coefficients[column];
            if (hessenberg[row][row] == 0.0) { singular = true; break; }
            coefficients[row] = value / hessenberg[row][row];
            if (!std::isfinite(coefficients[row])) { singular = true; break; }
        }
        if (singular) break;
        local_phase(h, [&] {
            for (std::size_t column = 0; column < count; ++column)
                for (std::size_t row = 0; row < p.local_rows; ++row)
                    result.local_solution[row] += coefficients[column] * preconditioned[column][row];
            const auto error = vector_error(result.local_solution, p.local_rows);
            if (!error.empty()) throw std::runtime_error(error);
        });
    }
    product = apply(result.local_solution);
    local_phase(h, [&] { for (std::size_t row = 0; row < p.local_rows; ++row) residual[row] = b[row] - product[row]; });
    result.residual = norm(h, residual);
    result.converged = result.residual / magnitude <= o.tolerance;
    local_phase(h, [&] {
        if (!std::isfinite(result.residual)) throw std::runtime_error("distributed residual overflow");
        const auto error = vector_error(result.local_solution, p.local_rows);
        if (!error.empty()) throw std::runtime_error(error);
    });
    return result;
}
DistributedLinearResult solve_distributed(DistributedCsrMatrix matrix, std::span<const double> rhs, const ExecutionOptions& options) {
    return DistributedLinearOperator(std::move(matrix), options).solve(rhs);
}
}
