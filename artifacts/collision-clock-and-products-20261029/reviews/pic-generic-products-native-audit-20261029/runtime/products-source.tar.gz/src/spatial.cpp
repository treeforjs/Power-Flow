#include "raikou/spatial.h"
#include "raikou/backend.h"
#include "raikou/sparse_direct.h"
#include "raikou/spatial_mesh.h"
#include "raikou/spatial_boundary.h"
#include "raikou/spatial_interface.h"
#include "raikou/spatial_distributed.h"
#include "raikou/kinetic_rz.h"
#include "raikou/adaptive_time.h"
#include "thermal_temperature.h"
#include "chemistry_energy.h"
#include "json_collective.h"
#include "legendre_admissibility.h"
#include <algorithm>
#include <cmath>
#include <limits>
#include <map>
#include <memory>
#include <mutex>
#include <numbers>
#include <numeric>
#include <optional>
#include <set>
#include <stdexcept>
#include <tuple>
#include <utility>

namespace raikou::spatial {
namespace {
constexpr double qe = 1.602176634e-19;
constexpr double eps0 = 8.8541878128e-12;
[[noreturn]] void bad(const std::string& s) { throw std::invalid_argument("spatial: " + s); }
void require(bool value, const std::string& s) { if (!value) bad(s); }
bool finite(double x) { return std::isfinite(x); }
using Point = std::array<double, 3>;
Point subtract(const Point& a, const Point& b) { return {a[0] - b[0], a[1] - b[1], a[2] - b[2]}; }
double dot(const Point& a, const Point& b) { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; }
double length(const Point& a) { return std::sqrt(dot(a, a)); }
struct Face { std::size_t a, b; double area, distance; Point normal{}; std::size_t index = 0; };
struct Wall { std::size_t cell; int side; double area, distance; int surface = -1; Point normal{}; std::size_t index = 0; };
struct Geometry {
    std::vector<double> volume;
    std::vector<Face> faces;
    std::vector<Wall> walls;
    std::size_t surfaces = 0;
    mesh::Geometry native;
};
Geometry geometry(const Mesh& input) {
    Geometry g; g.native = mesh::geometry(input); g.volume = g.native.volume;
    for (std::size_t k = 0; k < g.native.faces.size(); ++k) { const auto& f = g.native.faces[k]; g.faces.push_back({f.a, f.b, f.area, f.normal_distance, f.normal, k}); }
    for (std::size_t k = 0; k < g.native.walls.size(); ++k) { const auto& f = g.native.walls[k]; g.walls.push_back({f.cell, f.side, f.area, f.normal_distance, -1, f.normal, k}); }
    return g;
}
double epsilon(const Problem& p, std::size_t c) { return p.permittivity_F_m.empty() ? eps0 : p.permittivity_F_m[p.permittivity_F_m.size() == 1 ? 0 : c]; }
double harmonic(double a, double b) { return 2 * a * b / (a + b); }
double value_at(const std::vector<double>& values, std::size_t cell, double fallback = 0) { return values.empty() ? fallback : values[values.size() == 1 ? 0 : cell]; }
double derivative_b(double x) {
    if (std::abs(x) < 1e-4) return -0.5 + x / 6 - x * x * x / 180;
    if (x > 50) return (1 - x) * std::exp(-x);
    if (x < -50) return -1;
    const double em = std::expm1(x);
    return (em - x * (em + 1)) / (em * em);
}
struct Flux { double value = 0, left = 0, right = 0, phi = 0; };
Flux flux(double na, double nb, double pa, double pb, double d, int z, const Transport& t) {
    Flux f;
    const double drift = static_cast<double>(z) * t.mobility_m2_V_s * (pa - pb) / d;
    if (t.diffusion_m2_s == 0) {
        f.left = std::max(drift, 0.0); f.right = std::min(drift, 0.0);
        f.value = f.left * na + f.right * nb;
        f.phi = static_cast<double>(z) * t.mobility_m2_V_s / d * (drift >= 0 ? na : nb);
        return f;
    }
    const double P = static_cast<double>(z) * t.mobility_m2_V_s * (pa - pb) / t.diffusion_m2_s;
    f.left = t.diffusion_m2_s / d * bernoulli(-P);
    f.right = -t.diffusion_m2_s / d * bernoulli(P);
    f.value = f.left * na + f.right * nb;
    f.phi = -static_cast<double>(z) * t.mobility_m2_V_s / d * (na * derivative_b(-P) + nb * derivative_b(P));
    return f;
}
struct WallPotential { double value, cell_derivative, surface_derivative, backing_derivative; double unknown_derivative = 0; };
WallPotential wall_potential(const Problem& p, const Wall& w, const State& state) {
    const auto& b = p.boundaries[static_cast<std::size_t>(w.side)];
    const double backing = p.circuit.enabled && p.circuit.driven_side == w.side ? state.driven_voltage_V : b.potential_V;
    if (b.kind == BoundaryKind::Electrode) return {backing, 0, 0, 1};
    if (b.kind == BoundaryKind::Insulating || w.surface < 0) return {state.potential_V[w.cell], 1, 0, 0};
    const double k = epsilon(p, w.cell) / w.distance, C = b.capacitance_F_m2;
    const double sigma = state.surface_charge_C_m2[static_cast<std::size_t>(w.surface)];
    if (!state.dielectric_potential_V.empty()) return {state.dielectric_potential_V[static_cast<std::size_t>(w.surface)], 0, 0, 0, 1};
    return {(k * state.potential_V[w.cell] + C * backing + sigma) / (k + C), k / (k + C), 1 / (k + C), C / (k + C)};
}
// A host that walks a run in many solves (a new source voltage each) would otherwise solve the same local field table
// every time; the swarms depend only on the closure as requested, so one table per distinct closure is kept.
kinetics::SteadyEedfTable cached_table(const Problem& p) {
    static std::mutex mutex;
    static std::map<std::string, std::shared_ptr<const kinetics::SteadyEedfTable>> tables;
    {
        std::lock_guard lock(mutex);
        const auto found = p.electron_table_key.empty() ? tables.end() : tables.find(p.electron_table_key);
        if (found != tables.end()) return *found->second;
    }
    auto table = std::make_shared<const kinetics::SteadyEedfTable>(kinetics::SteadyEedfTable::build(
        p.electron_closure->processes, p.electron_table_conditions, p.electron_table_reduced_fields_td, p.electron_closure->grid));
    std::lock_guard lock(mutex);
    if (!p.electron_table_key.empty()) {
        if (tables.size() >= 16) tables.clear();
        tables.emplace(p.electron_table_key, table);
    }
    return *table;
}
struct System {
    const Problem& p;
    Geometry g;
    std::size_t nc, ns, nv, ng;
    double domain_volume;
    bool circuit_unknown;
    std::vector<double> scales;
    std::map<std::string, std::vector<double>> phase_fractions;
    std::vector<chemistry::Mechanism> cell_mechanisms;
    std::vector<std::string> thermal_phases;
    std::vector<Thermal::Phase> thermal_models;
    mesh::FluxStencils electrostatic_stencils;
    std::vector<double> interior_permittivity;
    std::vector<double> interior_ohmic_conductivity, ohmic_heat_fraction_a;
    std::optional<std::pair<std::size_t, std::size_t>> heavy_pair; // neutral, ion
    std::map<std::string, mesh::FluxStencils> material_stencils;
    std::map<std::string, mesh::FluxStencils> thermal_stencils;
    std::vector<mesh::FluxStencils> photon_stencils;
    std::optional<kinetics::KineticMesh> kinetic_mesh;
    std::vector<int> kinetic_face_wall; // wall index, -1 interior, -2-face phase contact
    std::vector<std::optional<kinetics::SphericalEedfState>> emission_templates;
    std::vector<double> emission_energy_eV;
    // Each cell's last steady Boltzmann solve, which its next solve starts from (eedf_warm_start).
    mutable std::vector<kinetics::SteadyEedfReuse> eedf_reuse;
    // The local field approximation's swarms, solved once for the whole run.
    std::optional<kinetics::SteadyEedfTable> eedf_table;
    explicit System(const Problem& problem) : p(problem), g(geometry(problem.mesh)), nc(g.volume.size()), ns(p.mechanism.species.size()), nv(0), ng(p.radiation.size()), domain_volume(std::accumulate(g.volume.begin(), g.volume.end(), 0.)), circuit_unknown(p.circuit.enabled && p.circuit.series_resistance_ohm > 0) {
        require(ns > 0, "mechanism must contain species");
        require(p.transport.size() == ns, "transport must contain one entry per species");
        require(p.initial_densities_m3.size() == nc * ns, "initial densities must be cell-major with one value per species");
        require(p.permittivity_F_m.empty() || p.permittivity_F_m.size() == 1 || p.permittivity_F_m.size() == nc, "permittivity must have one value or one per cell");
        for (double e : p.permittivity_F_m) require(e > 0 && finite(e), "permittivity must be finite and positive");
        for (const auto& t : p.transport) require(t.mobility_m2_V_s >= 0 && finite(t.mobility_m2_V_s) && t.diffusion_m2_s >= 0 && finite(t.diffusion_m2_s), "transport coefficients must be finite and nonnegative");
        for (double n : p.initial_densities_m3) require(n >= 0 && finite(n), "initial density must be finite and nonnegative");
        const auto errors = p.mechanism.validate();
        if (!errors.empty()) bad("invalid mechanism: " + errors.front());
        for (const auto& species : p.mechanism.species) phase_fractions.emplace(species.phase, std::vector<double>(nc, 0));
        if (!p.phase_fractions.empty()) {
            for (auto& [phase, fractions] : phase_fractions) {
                const auto at = p.phase_fractions.find(phase); require(at != p.phase_fractions.end() && (at->second.size() == 1 || at->second.size() == nc), "phase_fractions needs scalar or per-cell data for every phase");
                for (std::size_t c = 0; c < nc; ++c) { fractions[c] = value_at(at->second, c); require(fractions[c] >= 0 && fractions[c] <= 1 && finite(fractions[c]), "phase fractions must lie in [0,1]"); }
            }
            for (const auto& [phase, values] : p.phase_fractions) { (void)values; require(phase_fractions.contains(phase), "phase_fractions names an unknown phase: " + phase); }
            for (std::size_t c = 0; c < nc; ++c) { double sum = 0; for (const auto& [phase, fractions] : phase_fractions) { (void)phase; sum += fractions[c]; } require(std::abs(sum - 1) <= 1e-12, "cell phase fractions must sum to one"); }
        } else if (phase_fractions.size() == 1) std::fill(phase_fractions.begin()->second.begin(), phase_fractions.begin()->second.end(), 1);
        else {
            double total = 0;
            for (auto& [phase, fractions] : phase_fractions) {
                const auto at = p.environment.phase_volumes_m3.find(phase);
                require(at != p.environment.phase_volumes_m3.end() && at->second > 0 && finite(at->second), "multiphase spatial cells require positive phase_volumes_m3 for every species phase");
                std::fill(fractions.begin(), fractions.end(), at->second); total += at->second;
            }
            require(total > 0 && finite(total), "invalid phase volume sum");
            for (auto& [phase, fractions] : phase_fractions) { (void)phase; for (auto& fraction : fractions) fraction /= total; }
        }
        if (p.electrical) {
            require(!p.options.mpi, "background Ohmic conduction currently requires serial spatial.solve");
            const auto& e = *p.electrical;
            require(phase_fractions.contains(e.phase), "electrical.phase must name a material phase");
            for (const auto* values : {&e.ohmic_conductivity_S_m, &e.initial_ohmic_charge_C_m3})
                require(values->empty() || values->size() == 1 || values->size() == nc, "electrical fields must be scalar or per-cell");
            require(!e.ohmic_conductivity_S_m.empty(), "electrical requires ohmic_conductivity_S_m");
            for (double sigma : e.ohmic_conductivity_S_m) require(sigma >= 0 && finite(sigma), "Ohmic conductivity must be finite and nonnegative");
            for (double charge : e.initial_ohmic_charge_C_m3) require(finite(charge), "Ohmic charge must be finite");
            for (std::size_t s = 0; s < ns; ++s) if (p.mechanism.species[s].phase == e.phase && p.mechanism.species[s].charge != 0) {
                require(p.transport[s].mobility_m2_V_s == 0 && p.transport[s].diffusion_m2_s == 0 &&
                        (!p.electron_closure || p.electron_closure->electron_species != p.mechanism.species[s].id),
                        "electrical.phase cannot also own charged drift-diffusion carriers");
            }
            for (std::size_t c = 0; c < nc; ++c)
                require(phase_fractions.at(e.phase)[c] > 0 || (value_at(e.ohmic_conductivity_S_m, c) == 0 && value_at(e.initial_ohmic_charge_C_m3, c) == 0),
                        "absent electrical phase cannot own conductivity or charge");
            for (const auto& f : g.native.faces) {
                const double sa = value_at(e.ohmic_conductivity_S_m, f.a), sb = value_at(e.ohmic_conductivity_S_m, f.b);
                const double da = dot(subtract(f.center, g.native.centers[f.a]), f.normal), db = dot(subtract(g.native.centers[f.b], f.center), f.normal);
                const double resistance = sa > 0 && sb > 0 ? da / sa + db / sb : 0;
                interior_ohmic_conductivity.push_back(resistance > 0 ? (da + db) / resistance : 0);
                ohmic_heat_fraction_a.push_back(resistance > 0 ? (da / sa) / resistance : .5);
            }
        }
        if (p.heavy_barycentric_pair) {
            require(!p.options.mpi, "heavy_barycentric_pair currently requires serial spatial.solve");
            require(p.steady_electrons(), "heavy_barycentric_pair kinetic frame transformation currently supports steady electron closures only");
            const auto neutral = p.mechanism.species_index(p.heavy_barycentric_pair->neutral), ion = p.mechanism.species_index(p.heavy_barycentric_pair->ion);
            const auto& n = p.mechanism.species[neutral]; const auto& i = p.mechanism.species[ion];
            constexpr double electron_mass = 9.1093837139e-31;
            require(neutral != ion && n.phase == i.phase && n.charge == 0 && i.charge != 0 && !n.elements.empty() && n.elements == i.elements,
                    "heavy_barycentric_pair requires a neutral/ion pair with identical nuclei in one phase");
            require(std::min(std::abs(n.mass_kg - i.mass_kg), std::abs(n.mass_kg - i.mass_kg - i.charge * electron_mass)) <= 1e-10 * n.mass_kg,
                    "heavy_barycentric_pair requires equal heavy molecular masses (electron mass neglected)");
            require(p.transport[neutral].mobility_m2_V_s == 0 && p.transport[neutral].diffusion_m2_s == 0,
                    "heavy_barycentric_pair neutral transport is supplied solely by the barycentric counterflux");
            require(!p.electron_closure || (p.electron_closure->electron_species != n.id && p.electron_closure->electron_species != i.id),
                    "heavy_barycentric_pair heavy species cannot own the electron closure");
            for (std::size_t s = 0; s < ns; ++s) if (s != neutral && s != ion && p.mechanism.species[s].phase == n.phase) {
                const auto& other = p.mechanism.species[s];
                require(other.elements.empty() && other.charge == -1 && std::abs(other.mass_kg - electron_mass) <= 1e-6 * electron_mass,
                        "heavy_barycentric_pair supports only the two heavy species and electrons in its phase");
            }
            for (const auto& reaction : p.mechanism.reactions) {
                double change = 0, magnitude = 0;
                for (const auto& term : reaction.reactants) if (term.species == neutral || term.species == ion) { change -= term.coefficient; magnitude += term.coefficient; }
                for (const auto& term : reaction.products) if (term.species == neutral || term.species == ion) { change += term.coefficient; magnitude += term.coefficient; }
                require(std::abs(change) <= 1e-12 * magnitude, "heavy_barycentric_pair chemistry must preserve local total heavy-particle count");
            }
            for (const auto& wall : g.walls)
                require(!p.boundaries[static_cast<std::size_t>(wall.side)].absorbing || phase_fractions.at(n.phase)[wall.cell] == 0,
                        "heavy_barycentric_pair cannot touch an absorbing boundary without a wall mass-recycling model");
            heavy_pair = std::pair{neutral, ion};
        }
        std::set<std::string> face_reaction_ids;
        for (const auto& binding : p.face_reactions) {
            require(binding.phase_a != binding.phase_b && phase_fractions.contains(binding.phase_a) && phase_fractions.contains(binding.phase_b), "face reaction needs two distinct known phases");
            require(face_reaction_ids.insert(binding.reaction_id).second, "duplicate face reaction binding");
            const auto it = std::find_if(p.mechanism.reactions.begin(), p.mechanism.reactions.end(), [&](const auto& reaction) { return reaction.id == binding.reaction_id; });
            require(it != p.mechanism.reactions.end() && !it->basis_interface.empty(), "face reaction must bind an authored interface-area reaction");
            for (const auto* terms : {&it->reactants, &it->products, &it->orders}) for (const auto& term : *terms) { const auto& phase = p.mechanism.species[term.species].phase; require(phase == binding.phase_a || phase == binding.phase_b, "face reaction contains a third phase without a surface-state owner"); }
            require(binding.electrical_work_to_phase.empty() || binding.electrical_work_to_phase == binding.phase_a || binding.electrical_work_to_phase == binding.phase_b, "electrical interface work must name one participating phase");
        }
        cell_mechanisms.assign(nc, p.mechanism);
        for (std::size_t c = 0; c < nc; ++c) {
            auto& reactions = cell_mechanisms[c].reactions;
            reactions.erase(std::remove_if(reactions.begin(), reactions.end(), [&](const auto& reaction) {
                if (face_reaction_ids.contains(reaction.id)) return true;
                for (const auto* terms : {&reaction.reactants, &reaction.products, &reaction.orders}) for (const auto& term : *terms) if (phase_fraction(term.species, c) == 0) return true;
                return false;
            }), reactions.end());
            for (std::size_t s = 0; s < ns; ++s) require(phase_fraction(s, c) > 0 || p.initial_densities_m3[c * ns + s] == 0, "absent-phase initial density must be zero");
        }
        if (p.electron_closure && p.electron_mode == "local_field_table") eedf_table = cached_table(p);
        if (p.electron_closure && !p.steady_electrons()) {
            if (p.electron_mode == "transient_boltzmann") { require(!p.options.bdf2, "transient_boltzmann requires time.bdf2=false because the local kinetic operator uses backward Euler"); require(std::abs(length(p.electron_field_axis) - 1) < 1e-10, "fixed_field_axis must be a unit vector"); }
            require(p.initial_electron_mean_energy_eV > 0 && finite(p.initial_electron_mean_energy_eV), "transient kinetics requires positive initial_mean_energy_eV");
            const auto electron = p.mechanism.species_index(p.electron_closure->electron_species);
            require(p.transport[electron].mobility_m2_V_s == 0 && p.transport[electron].diffusion_m2_s == 0, "transient kinetic moments own electron transport; fluid electron mobility/diffusion must be zero");
            require(p.electron_closure->strict_event_mapping, "transient kinetics requires strict_event_mapping=true");
            for (const auto& reaction : p.mechanism.reactions) {
                double change = 0;
                for (const auto& term : reaction.products) if (term.species == electron) change += term.coefficient;
                for (const auto& term : reaction.reactants) if (term.species == electron) change -= term.coefficient;
                require(change == 0 || reaction.rate.kind == chemistry::RateKind::ElectronEedf, "electron number changes require a mapped kinetic collision operator: " + reaction.id);
                for (const auto& [key, energy] : reaction.energy_eV_per_event) {
                    const auto name = chemistry::detail::energy_reservoir_key(reaction, key);
                    require(energy == 0 || (name != "gas/electron" && name != "gas/electrons") || reaction.rate.kind == chemistry::RateKind::ElectronEedf, "electron energy transfers require a mapped kinetic distribution operator: " + reaction.id);
                }
            }
        }
        bool anchor = false;
        for (auto& w : g.walls) {
            const auto& b = p.boundaries[static_cast<std::size_t>(w.side)];
            require(finite(b.potential_V) && finite(b.initial_surface_charge_C_m2) && b.capacitance_F_m2 >= 0 && finite(b.capacitance_F_m2), "invalid boundary data");
            if (w.area > 0 && (b.kind == BoundaryKind::Electrode || (b.kind == BoundaryKind::Dielectric && b.capacitance_F_m2 > 0))) anchor = true;
            if (b.kind == BoundaryKind::Dielectric && w.area > 0) w.surface = static_cast<int>(g.surfaces++);
            require(b.kind != BoundaryKind::Insulating || !b.absorbing, "absorbing insulating walls require dielectric surface-charge ownership");
            require(b.kinetic_electrons == "auto" || b.kinetic_electrons == "absorbing" || b.kinetic_electrons == "specular" || b.kinetic_electrons == "prescribed_incoming" || b.kinetic_electrons == "secondary_emission", "unknown kinetic electron wall kind");
            require(b.kinetic_electrons != "prescribed_incoming" || b.incoming_electrons.has_value(), "prescribed incoming electrons require a full spherical distribution");
            require(b.kind != BoundaryKind::Insulating || (b.kinetic_electrons != "absorbing" && b.kinetic_electrons != "prescribed_incoming"), "kinetic electron exchange requires a boundary charge owner");
            std::set<std::string> sheath_species;
            for (const auto& sheath : b.sheaths) {
                const auto index = p.mechanism.species_index(sheath.species); const auto& species = p.mechanism.species[index];
                require(b.absorbing && b.kind != BoundaryKind::Insulating, "sheath closure requires an absorbing charged boundary owner");
                require(sheath_species.insert(sheath.species).second, "duplicate sheath species");
                require((sheath.model == "maxwellian" || sheath.model == "bohm" || sheath.model == "drift") && species.mass_kg > 0 && finite(species.mass_kg) && (sheath.model == "drift" ? sheath.temperature_eV >= 0 : sheath.temperature_eV > 0) && finite(sheath.temperature_eV) && sheath.transmission >= 0 && sheath.transmission <= 1 && finite(sheath.transmission), "invalid authored sheath closure");
                if (sheath.model == "bohm") require(species.charge > 0 && sheath.electron_temperature_eV > 0 && finite(sheath.electron_temperature_eV), "Bohm closure requires positive ions and an authored electron temperature");
                require(!(p.electron_closure && !p.steady_electrons() && index == p.mechanism.species_index(p.electron_closure->electron_species)), "kinetic electrons use distribution boundary flux; a second fluid sheath closure would double count");
            }
            std::set<std::pair<std::string, std::string>> emission_channels;
            for (const auto& emission : b.secondary_emission) {
                const auto& ion = p.mechanism.species[p.mechanism.species_index(emission.incident_species)]; const auto& electron = p.mechanism.species[p.mechanism.species_index(emission.emitted_species)];
                require(b.absorbing && b.kind != BoundaryKind::Insulating && ion.charge > 0 && electron.charge == -1 && electron.elements.empty() && ion.phase == "gas" && electron.phase == "gas", "secondary emission requires gas-ion incidence, gas electrons and a boundary charge owner");
                require(emission.yield >= 0 && finite(emission.yield) && emission_channels.emplace(emission.incident_species, emission.emitted_species).second, "invalid or duplicate secondary emission yield");
                if (p.electron_closure && !p.steady_electrons()) require(p.electron_mode == "transient_spherical" && b.kinetic_electrons == "secondary_emission" && b.incoming_electrons && emission.emitted_species == p.electron_closure->electron_species, "kinetic secondary emission requires spherical transport and a full authored incoming template");
                else require(b.secondary_energy_eV > 0 && finite(b.secondary_energy_eV), "fluid secondary emission requires authored secondary_energy_eV");
            }
            require(b.kinetic_electrons != "secondary_emission" || (!b.secondary_emission.empty() && b.incoming_electrons.has_value() && p.electron_mode == "transient_spherical"), "secondary electron wall needs yields and a full incoming distribution in spherical mode");
        }
        require(anchor, "Poisson requires an electrode or capacitively anchored dielectric boundary");
        std::vector<mesh::BoundaryCondition> electrostatic_conditions;
        for (const auto& wall : g.walls) electrostatic_conditions.push_back(p.boundaries[static_cast<std::size_t>(wall.side)].kind == BoundaryKind::Insulating ? mesh::BoundaryCondition::Neumann : mesh::BoundaryCondition::Dirichlet);
        electrostatic_stencils = mesh::normal_derivatives(g.native, electrostatic_conditions);
        std::vector<mesh::BoundaryCondition> material_conditions;
        for (const auto& wall : g.walls) material_conditions.push_back(p.boundaries[static_cast<std::size_t>(wall.side)].absorbing ? mesh::BoundaryCondition::Dirichlet : mesh::BoundaryCondition::Neumann);
        for (const auto& [phase, fractions] : phase_fractions) material_stencils[phase] = mesh::normal_derivatives_active(g.native, material_conditions, fractions);
        for (const auto& face : g.native.faces) { const double da = dot(subtract(face.center, g.native.centers[face.a]), face.normal), db = dot(subtract(g.native.centers[face.b], face.center), face.normal); interior_permittivity.push_back((da + db) / (da / epsilon(p, face.a) + db / epsilon(p, face.b))); }
        const auto& o = p.options;
        require(finite(o.time_step_s) && o.time_step_s > 0 && finite(o.minimum_time_step_s) && o.minimum_time_step_s > 0 && o.minimum_time_step_s <= o.time_step_s, "invalid timestep limits");
        require(finite(o.end_time_s) && o.end_time_s >= 0 && o.maximum_steps > 0 && o.maximum_newton_iterations > 0, "invalid time or iteration limit");
        for (double tolerance : {o.relative_tolerance, o.absolute_density_tolerance_m3, o.potential_tolerance_V, o.surface_charge_tolerance_C_m2, o.circuit_charge_tolerance_C}) require(tolerance > 0 && finite(tolerance), "solver tolerances must be finite and positive");
        for (double tolerance : {o.temporal_relative_tolerance, o.temporal_density_tolerance_m3, o.temporal_temperature_tolerance_K, o.temporal_potential_tolerance_V, o.temporal_surface_charge_tolerance_C_m2}) require(tolerance > 0 && finite(tolerance), "temporal tolerances must be finite and positive");
        require((o.preconditioner == "auto" || o.preconditioner == "jacobi" || o.preconditioner == "block_ilu0") && o.linear_restart > 0 && o.linear_max_iterations > 0, "invalid linear solver options");
        require(o.nonorthogonal_correction_limiter >= 0 && finite(o.nonorthogonal_correction_limiter), "invalid nonorthogonal correction limiter");
        if (p.circuit.enabled) {
            require(p.circuit.driven_side >= 0 && p.circuit.driven_side < 2 * p.mesh.dimension, "invalid circuit side");
            require(p.boundaries[static_cast<std::size_t>(p.circuit.driven_side)].kind != BoundaryKind::Insulating, "circuit side must be electrode or dielectric");
            require(p.circuit.series_resistance_ohm >= 0 && finite(p.circuit.series_resistance_ohm) && p.circuit.external_capacitance_F >= 0 && finite(p.circuit.external_capacitance_F) && finite(p.circuit.source_voltage_V) && finite(p.circuit.initial_voltage_V), "invalid circuit values");
        }
        const auto validate_field = [&](const std::vector<double>& values, bool positive, const std::string& name) {
            require(values.empty() || values.size() == 1 || values.size() == nc, name + " must be scalar or one per cell");
            for (double v : values) require(finite(v) && (positive ? v > 0 : v >= 0), "invalid " + name);
        };
        if (p.thermal.enabled) {
            require(!thermal::detail::has_liquid_alias_collision(p.thermal.phases), "liquid and aqueous share one liquid_temperature_K; select only one thermal phase name");
            if (p.thermal.phases.empty()) {
                thermal_phases.push_back(""); thermal_models.push_back({p.thermal.heat_capacity_J_m3_K, p.thermal.conductivity_W_m_K, p.thermal.initial_temperature_K, p.thermal.heating_W_m3, p.thermal.heat_reservoirs});
            } else {
                require(p.thermal.heat_capacity_J_m3_K.empty() && p.thermal.heat_reservoirs.empty(), "choose common or separate phase thermal equations");
                for (const auto& [phase, model] : p.thermal.phases) { require(phase_fractions.contains(phase), "thermal phase is absent from mechanism"); thermal_phases.push_back(phase); thermal_models.push_back(model); }
            }
        } else require(p.thermal.phases.empty(), "phase thermal equations require thermal.enabled");
        for (const auto& exchange : p.interface_heat_transfer) require(exchange.phase_a != exchange.phase_b && p.thermal.phases.contains(exchange.phase_a) && p.thermal.phases.contains(exchange.phase_b) && exchange.conductance_W_m2_K >= 0 && finite(exchange.conductance_W_m2_K), "interface heat transfer needs two separate thermal phase owners and nonnegative conductance");
        const std::vector<mesh::BoundaryCondition> adiabatic(g.walls.size(), mesh::BoundaryCondition::Neumann);
        for (const auto& phase : thermal_phases) thermal_stencils[phase] = phase.empty() ? mesh::normal_derivatives(g.native, adiabatic) : mesh::normal_derivatives_active(g.native, adiabatic, phase_fractions.at(phase));
        if (p.thermal.enabled) {
            for (std::size_t k = 0; k < thermal_models.size(); ++k) {
                const auto& model = thermal_models[k]; require(!model.heat_capacity_J_m3_K.empty(), "thermal model needs heat capacity");
                validate_field(model.heat_capacity_J_m3_K, true, "heat capacity"); validate_field(model.conductivity_W_m_K, false, "thermal conductivity"); validate_field(model.initial_temperature_K, true, "initial temperature");
                require(model.heating_W_m3.empty() || model.heating_W_m3.size() == 1 || model.heating_W_m3.size() == nc, "heating field size mismatch");
                for (double h : model.heating_W_m3) require(finite(h), "nonfinite heating");
                std::set<std::string> unique;
                for (const auto& name : model.heat_reservoirs) { require(unique.insert(name).second, "duplicate thermal reservoir"); require(thermal_phases[k].empty() || name.starts_with(thermal_phases[k] + "/"), "thermal reservoir belongs to a different phase"); }
            }
            std::set<std::string> selected;
            for (const auto& id : p.thermal.joule_species) { (void)p.mechanism.species_index(id); require(selected.insert(id).second, "duplicate Joule heating species"); }
            selected.clear();
            std::set<std::string> authored_reservoirs;
            for (const auto& reaction : p.mechanism.reactions) for (const auto& [key, energy] : reaction.energy_eV_per_event) { (void)energy; authored_reservoirs.insert(chemistry::detail::energy_reservoir_key(reaction, key)); }
            for (const auto& model : thermal_models) for (const auto& name : model.heat_reservoirs) {
                require(selected.insert(name).second, "duplicate thermal reservoir");
                require(authored_reservoirs.contains(name), "thermal reservoir is absent from mechanism energy partitions: " + name);
                if (p.electron_closure && !p.steady_electrons()) require(name != "gas/electron" && name != "gas/electrons", "transient electron energy is owned by kinetic moments");
            }
            require(!p.thermal.use_eedf_elastic_heating || p.electron_closure.has_value(), "EEDF elastic heating requires electron_closure");
            if (p.thermal.use_eedf_elastic_heating && selected.contains("gas/translation")) {
                for (const auto& reaction : p.mechanism.reactions) {
                    double transfer = 0;
                    for (const auto& [key, energy] : reaction.energy_eV_per_event) if ((chemistry::detail::energy_reservoir_key(reaction, key)) == "gas/translation") transfer += energy;
                    if (transfer == 0 || reaction.collision_label.empty()) continue;
                    for (const auto& process : p.electron_closure->processes) require(reaction.collision_label != process.label || (process.kind != kinetics::CollisionKind::Elastic && process.kind != kinetics::CollisionKind::Effective), "the same labelled elastic transfer cannot heat through chemistry and EEDF together");
                }
            }
        }
        std::map<std::string, bool> photon_ids, bound_reactions;
        std::set<std::string> photon_reservoirs, photon_rate_keys;
        for (const auto& group : p.radiation) {
            std::vector<mesh::BoundaryCondition> photon_conditions; for (const auto& wall : g.walls) photon_conditions.push_back(group.escaping_sides[static_cast<std::size_t>(wall.side)] ? mesh::BoundaryCondition::Dirichlet : mesh::BoundaryCondition::Neumann);
            photon_stencils.push_back(mesh::normal_derivatives(g.native, photon_conditions));
            require(!group.id.empty() && photon_ids.emplace(group.id, true).second, "radiation group IDs must be unique");
            require(group.photon_energy_eV > 0 && finite(group.photon_energy_eV) && group.speed_m_s > 0 && finite(group.speed_m_s) && group.diffusion_m2_s >= 0 && finite(group.diffusion_m2_s) && group.absorption_m1 >= 0 && finite(group.absorption_m1), "invalid radiation coefficients");
            require(p.thermal.phases.empty() || group.absorption_m1 == 0, "separate thermal phases require phase-resolved photon absorption coefficients");
            for (const auto& [phase, opacity] : group.absorption_m1_by_phase) require(phase_fractions.contains(phase) && opacity >= 0 && finite(opacity), "invalid phase-resolved photon absorption");
            require(group.energy_reservoir.empty() || photon_reservoirs.insert(group.energy_reservoir).second, "radiation groups cannot share an energy reservoir");
            for (const auto& model : thermal_models) require(std::find(model.heat_reservoirs.begin(), model.heat_reservoirs.end(), group.energy_reservoir) == model.heat_reservoirs.end(), "a radiation reservoir cannot also feed thermal energy");
            validate_field(group.initial_density_m3, false, "initial photon density"); validate_field(group.emission_W_m3, false, "radiative emission");
            for (const auto& absorber : group.absorbers) {
                require(absorber.cross_section_m2 > 0 && finite(absorber.cross_section_m2) && bound_reactions.emplace(absorber.reaction_id, true).second, "invalid or duplicate photon reaction binding");
                const auto found = std::find_if(p.mechanism.reactions.begin(), p.mechanism.reactions.end(), [&](const auto& r) { return r.id == absorber.reaction_id; });
                require(found != p.mechanism.reactions.end() && found->rate.kind == chemistry::RateKind::Parameter, "photon absorber must bind a parameter-rate reaction");
                require(photon_rate_keys.insert(found->rate.key).second, "photon reactions require distinct parameter rate keys");
                double debit = 0; bool has_debit = false;
                for (const auto& [key, energy] : found->energy_eV_per_event) if (chemistry::detail::energy_reservoir_key(*found, key) == group.energy_reservoir) { debit += energy; has_debit = true; }
                require(has_debit && std::abs(debit + group.photon_energy_eV) <= 1e-10 * group.photon_energy_eV, "bound photoreaction must debit exactly one photon from its radiation energy reservoir");
            }
        }
        nv = surface_base() + 2 * g.surfaces + (circuit_unknown ? 1 : 0);
        require(nv <= static_cast<std::size_t>(std::numeric_limits<int>::max()), "too many unknowns");
        scales.assign(nv, 1);
        double phi_scale = 1;
        for (const auto& b : p.boundaries) phi_scale = std::max(phi_scale, std::abs(b.potential_V));
        if (p.circuit.enabled) phi_scale = std::max({phi_scale, std::abs(p.circuit.source_voltage_V), std::abs(p.circuit.initial_voltage_V)});
        for (std::size_t s = 0; s < ns; ++s) {
            double nscale = std::max(1.0, o.absolute_density_tolerance_m3 / o.relative_tolerance);
            for (std::size_t c = 0; c < nc; ++c) nscale = std::max(nscale, p.initial_densities_m3[c * ns + s]);
            for (std::size_t c = 0; c < nc; ++c) scales[c * ns + s] = nscale;
        }
        for (std::size_t c = 0; c < nc; ++c) scales[pi(c)] = phi_scale;
        for (std::size_t c = 0; c < nc; ++c) {
            for (std::size_t k = 0; k < thermal_models.size(); ++k) scales[ti(c, k)] = std::max(1.0, initial_temperature(k, c));
            for (std::size_t r = 0; r < ng; ++r) scales[ri(c, r)] = std::max(1.0, value_at(p.radiation[r].initial_density_m3, c));
        }
        for (const auto& w : g.walls) if (w.surface >= 0) scales[si(w)] = std::max({1e-12, std::abs(p.boundaries[static_cast<std::size_t>(w.side)].initial_surface_charge_C_m2), epsilon(p, w.cell) * phi_scale / w.distance});
        for (const auto& w : g.walls) if (w.surface >= 0) scales[bi(w)] = phi_scale;
        if (circuit_unknown) scales[vi()] = phi_scale;
        if (p.electron_closure && p.electron_mode == "transient_spherical") {
            std::vector<double> volumes(nc), areas(g.faces.size()); std::vector<kinetics::SpatialKineticBoundary> walls; std::map<std::size_t, kinetics::SpatialKineticBoundary> contacts;
            auto native = g.native;
            for (std::size_t c = 0; c < nc; ++c) volumes[c] = g.volume[c] * phase_fractions.at("gas")[c];
            for (const auto& face : g.faces) {
                const double af = phase_fractions.at("gas")[face.a], bf = phase_fractions.at("gas")[face.b];
                areas[face.index] = face.area * (af > 0 && bf > 0 ? harmonic(af, bf) : std::max(af, bf));
                if (af > 0 && bf > 0 && areas[face.index] > 0) kinetic_face_wall.push_back(-1);
                else if ((af > 0) != (bf > 0)) kinetic_face_wall.push_back(-2 - static_cast<int>(face.index));
            }
            for (const auto& [face, contact] : p.electron_phase_contacts) {
                require(face < g.faces.size(), "kinetic phase contact index is outside mesh"); contacts[face] = contact.boundary;
                if (contact.boundary.kind != kinetics::KineticWall::Specular) {
                    require(!contact.absorbed_species.empty(), "nonreflecting kinetic phase contact requires an absorbed_species charge owner"); const auto species = p.mechanism.species_index(contact.absorbed_species);
                    require(p.mechanism.species[species].charge == -1 && p.mechanism.species[species].elements.empty() && p.mechanism.species[species].phase != "gas", "kinetic phase contact owner must be a non-gas electron species");
                    const auto& f = g.faces[face]; const auto owner = volumes[f.a] == 0 ? f.a : f.b; require(phase_fraction(species, owner) > 0, "contact electron owner is absent from receiving cell");
                }
            }
            for (const auto& wall : g.walls) {
                const auto& boundary = p.boundaries[static_cast<std::size_t>(wall.side)]; const std::string kind = boundary.kinetic_electrons == "auto" ? (boundary.absorbing ? "absorbing" : "specular") : boundary.kinetic_electrons;
                walls.push_back({kind == "specular" ? kinetics::KineticWall::Specular : (kind == "absorbing" || kind == "secondary_emission") ? kinetics::KineticWall::Absorbing : kinetics::KineticWall::PrescribedIncoming, kind == "secondary_emission" ? std::nullopt : boundary.incoming_electrons});
                native.walls[wall.index].area *= phase_fractions.at("gas")[wall.cell];
                if (volumes[wall.cell] > 0 && native.walls[wall.index].area > 0) kinetic_face_wall.push_back(static_cast<int>(wall.index));
            }
            kinetic_mesh = kinetics::make_kinetic_mesh(native, volumes, areas, walls, contacts);
            require(kinetic_face_wall.size() == kinetic_mesh->faces.size(), "kinetic face ownership mapping mismatch");
            emission_templates.resize(kinetic_mesh->faces.size()); emission_energy_eV.resize(kinetic_mesh->faces.size());
            for (std::size_t f = 0; f < kinetic_face_wall.size(); ++f) if (kinetic_face_wall[f] >= 0) {
                const auto& wall = g.walls[static_cast<std::size_t>(kinetic_face_wall[f])]; const auto& boundary = p.boundaries[static_cast<std::size_t>(wall.side)];
                if (boundary.kinetic_electrons != "secondary_emission") continue;
                auto incoming = *boundary.incoming_electrons; incoming.validate(); const auto& grid = p.electron_closure->grid;
                require(incoming.grid.cells == grid.cells && incoming.grid.legendre_terms == grid.legendre_terms && incoming.grid.max_energy_ev == grid.max_energy_ev && incoming.grid.power == grid.power, "secondary incoming template grid differs");
                const auto normalized = ::raikou::spatial::boundary::normalize_incoming(incoming, kinetic_mesh->faces[f].normal);
                emission_energy_eV[f] = normalized.mean_incoming_energy_eV;
                emission_templates[f] = normalized.per_unit_number_flux;
            }
        }
        require(p.electron_phase_contacts.empty() || (p.electron_closure && p.electron_mode == "transient_spherical"), "electron phase-contact distributions require transient_spherical");
    }
    std::size_t pi(std::size_t c) const { return nc * ns + c; }
    std::size_t ri(std::size_t c, std::size_t r) const { return nc * (ns + 1) + c * ng + r; }
    std::size_t ti(std::size_t c, std::size_t k = 0) const { return nc * (ns + 1 + ng + k) + c; }
    std::size_t surface_base() const { return nc * (ns + 1 + ng + thermal_models.size()); }
    std::size_t si(const Wall& w) const { return surface_base() + static_cast<std::size_t>(w.surface); }
    std::size_t bi(const Wall& w) const { return surface_base() + g.surfaces + static_cast<std::size_t>(w.surface); }
    std::size_t vi() const { return nv - 1; }
    double phase_fraction(std::size_t species, std::size_t cell) const { return phase_fractions.at(p.mechanism.species[species].phase)[cell]; }
    double reservoir_fraction(const std::string& key, std::size_t cell) const { const auto at = phase_fractions.find(key.substr(0, key.find('/'))); return at == phase_fractions.end() ? 1 : at->second[cell]; }
    double aperture(std::size_t species, const Face& face) const { const double a = phase_fraction(species, face.a), b = phase_fraction(species, face.b); return a > 0 && b > 0 ? harmonic(a, b) : 0; }
    double thermal_fraction(std::size_t k, std::size_t cell) const { return thermal_phases[k].empty() ? 1 : phase_fractions.at(thermal_phases[k])[cell]; }
    double opacity(const RadiationGroup& group, std::size_t cell) const { double value = group.absorption_m1; for (const auto& [phase, coefficient] : group.absorption_m1_by_phase) value += coefficient * phase_fractions.at(phase)[cell]; return value; }
    double temperature(const State& state, std::size_t k, std::size_t cell) const { return thermal_phases[k].empty() ? state.temperature_K[cell] : state.phase_temperatures_K.at(thermal_phases[k])[cell]; }
    double initial_temperature(std::size_t k, std::size_t cell) const { return value_at(thermal_models[k].initial_temperature_K, cell, thermal::detail::initial_temperature(p.environment, thermal_phases[k])); }
    void temperatures(State& state) const { for (std::size_t k = 0; k < thermal_models.size(); ++k) { auto& values = thermal_phases[k].empty() ? state.temperature_K : state.phase_temperatures_K[thermal_phases[k]]; values.resize(nc); for (std::size_t c = 0; c < nc; ++c) values[c] = initial_temperature(k, c); } }
    void environment_temperatures(chemistry::Environment& env, const State& state, std::size_t c) const { for (std::size_t k = 0; k < thermal_models.size(); ++k) { const double T = temperature(state, k, c); require(T > 0 && finite(T), "phase temperature must remain positive"); if (thermal_phases[k].empty() || thermal_phases[k] == "gas") env.gas_temperature_K = T; if (thermal_phases[k].empty() || thermal_phases[k] == "aqueous" || thermal_phases[k] == "liquid") env.liquid_temperature_K = T; } }
    std::vector<double> wall_values(const State& state) const { std::vector<double> values(g.walls.size()); for (const auto& wall : g.walls) values[wall.index] = wall_potential(p, wall, state).value; return values; }
    State unpack(const std::vector<double>& x, double time) const {
        State st; st.time_s = time;
        st.densities_m3.resize(nc * ns); st.potential_V.resize(nc); st.surface_charge_C_m2.resize(g.surfaces); st.dielectric_potential_V.resize(g.surfaces);
        for (std::size_t q = 0; q < nc * ns; ++q) st.densities_m3[q] = x[q] * scales[q];
        for (std::size_t c = 0; c < nc; ++c) st.potential_V[c] = x[pi(c)] * scales[pi(c)];
        st.photon_densities_m3.resize(nc * ng); temperatures(st);
        for (std::size_t c = 0; c < nc; ++c) { for (std::size_t k = 0; k < thermal_models.size(); ++k) { auto& values = thermal_phases[k].empty() ? st.temperature_K : st.phase_temperatures_K[thermal_phases[k]]; values[c] = x[ti(c, k)] * scales[ti(c, k)]; } for (std::size_t r = 0; r < ng; ++r) st.photon_densities_m3[c * ng + r] = x[ri(c, r)] * scales[ri(c, r)]; }
        for (std::size_t k = 0; k < g.surfaces; ++k) st.surface_charge_C_m2[k] = x[surface_base() + k] * scales[surface_base() + k];
        for (std::size_t k = 0; k < g.surfaces; ++k) st.dielectric_potential_V[k] = x[surface_base() + g.surfaces + k] * scales[surface_base() + g.surfaces + k];
        st.driven_voltage_V = circuit_unknown ? x[vi()] * scales[vi()] : p.circuit.source_voltage_V;
        return st;
    }
    std::vector<double> pack(const State& st) const {
        std::vector<double> x(nv);
        for (std::size_t q = 0; q < nc * ns; ++q) x[q] = st.densities_m3[q] / scales[q];
        for (std::size_t c = 0; c < nc; ++c) x[pi(c)] = st.potential_V[c] / scales[pi(c)];
        for (std::size_t c = 0; c < nc; ++c) { for (std::size_t k = 0; k < thermal_models.size(); ++k) x[ti(c, k)] = temperature(st, k, c) / scales[ti(c, k)]; for (std::size_t r = 0; r < ng; ++r) x[ri(c, r)] = st.photon_densities_m3[c * ng + r] / scales[ri(c, r)]; }
        for (std::size_t k = 0; k < g.surfaces; ++k) x[surface_base() + k] = st.surface_charge_C_m2[k] / scales[surface_base() + k];
        for (std::size_t k = 0; k < g.surfaces; ++k) x[surface_base() + g.surfaces + k] = st.dielectric_potential_V[k] / scales[surface_base() + g.surfaces + k];
        if (circuit_unknown) x[vi()] = st.driven_voltage_V / scales[vi()];
        return x;
    }
    double electrode_charge(const State& st, int side) const {
        double Q = 0;
        const auto values = wall_values(st);
        for (const auto& w : g.walls) if (w.side == side) {
            const auto& b = p.boundaries[static_cast<std::size_t>(side)];
            const auto wp = wall_potential(p, w, st);
            if (b.kind == BoundaryKind::Electrode) Q += epsilon(p, w.cell) * w.area * electrostatic_stencils.boundary[w.index].evaluate(st.potential_V, values);
            if (b.kind == BoundaryKind::Dielectric) {
                const double backing = p.circuit.enabled && side == p.circuit.driven_side ? st.driven_voltage_V : b.potential_V;
                Q += b.capacitance_F_m2 * w.area * (backing - wp.value);
            }
        }
        return Q;
    }
};
std::vector<Point> electric_fields(const System& sys, const State& state) {
    const auto walls = sys.wall_values(state);
    std::vector<Point> fields(sys.nc);
    for (std::size_t c = 0; c < sys.nc; ++c) for (std::size_t d = 0; d < 3; ++d)
        fields[c][d] = -sys.electrostatic_stencils.cell_gradients[c][d].evaluate(state.potential_V, walls);
    return fields;
}
using Rows = std::vector<std::map<int, double>>;
void add(Rows& a, std::size_t row, std::size_t col, double v) { if (v != 0) a[row][static_cast<int>(col)] += v; }
struct PotentialForm { double value = 0; std::map<std::size_t, double> derivatives; };
PotentialForm potential_form(const System& sys, const State& state, const mesh::ScalarStencil& stencil) {
    PotentialForm form;
    for (auto [cell, coefficient] : stencil.cells) { form.value += coefficient * state.potential_V[cell]; form.derivatives[sys.pi(cell)] += coefficient; }
    for (auto [index, coefficient] : stencil.boundaries) {
        const auto& wall = sys.g.walls[index]; const auto& boundary = sys.p.boundaries[static_cast<std::size_t>(wall.side)];
        form.value += coefficient * wall_potential(sys.p, wall, state).value;
        if (boundary.kind == BoundaryKind::Dielectric) form.derivatives[sys.bi(wall)] += coefficient;
        else if (sys.circuit_unknown && wall.side == sys.p.circuit.driven_side && boundary.kind == BoundaryKind::Electrode) form.derivatives[sys.vi()] += coefficient;
    }
    return form;
}
void add_form(Rows& rows, std::size_t row, const PotentialForm& form, double coefficient) { for (auto [column, derivative] : form.derivatives) add(rows, row, column, coefficient * derivative); }
PotentialForm density_gradient(const System& sys, const State& state, const mesh::ScalarStencil& stencil, std::size_t species) {
    PotentialForm form;
    for (auto [cell, coefficient] : stencil.cells) { const auto index = cell * sys.ns + species; form.value += coefficient * state.densities_m3[index]; form.derivatives[index] += coefficient; }
    // Absorbing material slots prescribe zero exterior density; reflecting
    // slots have exactly zero coefficients in their Neumann reconstruction.
    return form;
}
PotentialForm material_flux(const System& sys, const State& state, std::size_t species, const Transport& transport,
    std::size_t a, std::optional<std::size_t> b, double distance, const mesh::ScalarStencil& density_stencil,
    const mesh::ScalarStencil& potential_stencil) {
    const auto ia = a * sys.ns + species; const double na = state.densities_m3[ia], nb = b ? state.densities_m3[*b * sys.ns + species] : 0;
    const auto gradient = potential_form(sys, state, potential_stencil); const auto density = density_gradient(sys, state, density_stencil, species);
    const auto base = flux(na, nb, -distance * gradient.value, 0, distance, sys.p.mechanism.species[species].charge, transport);
    PotentialForm correction; correction.value = -transport.diffusion_m2_s * (density.value - (nb - na) / distance);
    correction.derivatives[ia] = -transport.diffusion_m2_s / distance;
    if (b) correction.derivatives[*b * sys.ns + species] = transport.diffusion_m2_s / distance;
    for (auto [column, derivative] : density.derivatives) correction.derivatives[column] -= transport.diffusion_m2_s * derivative;
    if (b && sys.p.options.nonorthogonal_correction_limiter > 0) {
        const double bound_coefficient = sys.p.options.nonorthogonal_correction_limiter * transport.diffusion_m2_s / distance;
        const double bound = bound_coefficient * std::min(na, nb);
        if (bound == 0 || std::abs(correction.value) > bound) {
            const double sign = correction.value > 0 ? 1 : correction.value < 0 ? -1 : 0;
            correction.value = sign * bound; correction.derivatives.clear(); if (bound > 0) correction.derivatives[na < nb ? ia : *b * sys.ns + species] = sign * bound_coefficient;
        }
    }
    PotentialForm result; result.value = base.value + correction.value;
    result.derivatives = correction.derivatives; result.derivatives[ia] += base.left;
    if (b) result.derivatives[*b * sys.ns + species] += base.right;
    for (auto [column, derivative] : gradient.derivatives) result.derivatives[column] -= distance * base.phi * derivative;
    if (!b && result.value < 0) { result.value = 0; result.derivatives.clear(); }
    return result;
}
PotentialForm barycentric_ion_flux(const System& sys, const State& state, const PotentialForm& raw, std::size_t a, std::size_t b) {
    const auto [neutral, ion] = *sys.heavy_pair;
    const auto donor = raw.value > 0 ? b : a; // upwind for the opposite frame-shift velocity
    const double nn = state.densities_m3[donor * sys.ns + neutral];
    const double ni = state.densities_m3[donor * sys.ns + ion];
    const double total = nn + ni;
    if (total == 0) return {}; // no heavy inventory and no pair-creating chemistry
    require(total > 0 && finite(total), "invalid barycentric heavy face density");
    // Equal heavy masses. Upwind the frame advection in direction -j_raw,
    // using one donor for neutral, ion and electrons. The neutral receives the
    // ion's exact opposite. At j_raw=0, retain the a-donor one-sided Jacobian.
    const double neutral_fraction = nn / total;
    PotentialForm result; result.value = neutral_fraction * raw.value;
    for (const auto& [column, derivative] : raw.derivatives) result.derivatives[column] = neutral_fraction * derivative;
    result.derivatives[donor * sys.ns + neutral] += raw.value * (1 - neutral_fraction) / total;
    result.derivatives[donor * sys.ns + ion] -= raw.value * neutral_fraction / total;
    return result;
}
PotentialForm barycentric_electron_flux(const System& sys, const State& state, PotentialForm raw_electron, const PotentialForm& raw_ion,
                                       std::size_t electron, std::size_t a, std::size_t b) {
    const auto [neutral, ion] = *sys.heavy_pair;
    const auto donor = raw_ion.value > 0 ? b : a;
    const double heavy = state.densities_m3[donor * sys.ns + neutral] + state.densities_m3[donor * sys.ns + ion], electrons = state.densities_m3[donor * sys.ns + electron];
    if (heavy == 0) { require(electrons == 0, "barycentric electron transport requires a heavy material owner"); return raw_electron; }
    require(heavy > 0 && finite(heavy) && finite(electrons), "invalid barycentric electron face composition");
    const double ratio = electrons / heavy;
    raw_electron.value -= ratio * raw_ion.value;
    for (auto [column, derivative] : raw_ion.derivatives) raw_electron.derivatives[column] -= ratio * derivative;
    raw_electron.derivatives[donor * sys.ns + electron] -= raw_ion.value / heavy;
    for (auto s : {neutral, ion}) raw_electron.derivatives[donor * sys.ns + s] += raw_ion.value * ratio / heavy;
    return raw_electron;
}
PotentialForm wall_flux(const System& sys, const State& state, const Wall& wall, std::size_t species, const Transport& transport) {
    const auto& boundary = sys.p.boundaries[static_cast<std::size_t>(wall.side)];
    const auto& descriptor = sys.p.mechanism.species[species];
    const auto at = std::find_if(boundary.sheaths.begin(), boundary.sheaths.end(), [&](const auto& closure) { return closure.species == descriptor.id; });
    if (at == boundary.sheaths.end()) return material_flux(sys, state, species, transport, wall.cell, std::nullopt, wall.distance, sys.material_stencils.at(descriptor.phase).boundary[wall.index], sys.electrostatic_stencils.boundary[wall.index]);
    if (at->model == "drift") {
        // The cell density leaves with its drift toward the wall (none when the field drives it
        // away) and its one-way thermal speed: no zero-density wall to diffuse back into.
        const auto row = wall.cell * sys.ns + species; const double n = state.densities_m3[row];
        const auto gradient = potential_form(sys, state, sys.electrostatic_stencils.boundary[wall.index]);
        const auto drift = flux(n, 0, -wall.distance * gradient.value, 0, wall.distance, descriptor.charge, Transport{transport.mobility_m2_V_s, 0});
        const double thermal = ::raikou::spatial::boundary::drift_thermal_speed(*at, descriptor, transport);
        PotentialForm result; result.value = drift.value + thermal * n; result.derivatives[row] = drift.left + thermal;
        for (auto [column, derivative] : gradient.derivatives) result.derivatives[column] -= wall.distance * drift.phi * derivative;
        return result;
    }
    const auto row = wall.cell * sys.ns + species; const double n = state.densities_m3[row]; const auto wp = wall_potential(sys.p, wall, state);
    const auto evaluated = ::raikou::spatial::boundary::evaluate_sheath(*at, descriptor, n, state.potential_V[wall.cell], wp.value);
    PotentialForm result; result.value = evaluated.particles_m2_s; result.derivatives[row] = evaluated.density_derivative_m_s;
    result.derivatives[sys.pi(wall.cell)] += evaluated.cell_potential_derivative_m2_s_V;
    if (boundary.kind == BoundaryKind::Dielectric) result.derivatives[sys.bi(wall)] += evaluated.wall_potential_derivative_m2_s_V;
    else if (sys.circuit_unknown && wall.side == sys.p.circuit.driven_side) result.derivatives[sys.vi()] += evaluated.wall_potential_derivative_m2_s_V;
    return result;
}
PotentialForm emission_flux(const System& sys, const State& state, const Wall& wall, std::size_t emitted, std::span<const Transport> transport) {
    PotentialForm result;
    for (const auto& emission : sys.p.boundaries[static_cast<std::size_t>(wall.side)].secondary_emission) if (sys.p.mechanism.species_index(emission.emitted_species) == emitted) {
        const auto ion = sys.p.mechanism.species_index(emission.incident_species);
        const auto incident = wall_flux(sys, state, wall, ion, transport[wall.cell * sys.ns + ion]);
        result.value += emission.yield * incident.value;
        for (auto [column, derivative] : incident.derivatives) result.derivatives[column] += emission.yield * derivative;
    }
    return result;
}
template<class Value, class Index> PotentialForm scalar_form(const mesh::ScalarStencil& stencil, Value value, Index index) {
    PotentialForm form; for (auto [cell, coefficient] : stencil.cells) { form.value += coefficient * value(cell); form.derivatives[index(cell)] += coefficient; } return form;
}
double face_conductivity(const System& sys, const Face& face, double a, double b) {
    if (a == 0 || b == 0) return 0;
    const auto& native = sys.g.native.faces[face.index]; const double da = dot(subtract(native.center, sys.g.native.centers[face.a]), native.normal), db = face.distance - da;
    return face.distance / (da / a + db / b);
}
PotentialForm diffusion_flux(const PotentialForm& gradient, double coefficient, double distance,
    std::size_t ia, double na, std::size_t ib, double nb, double limiter) {
    const double base_coefficient = coefficient / distance, base = base_coefficient * (na - nb);
    PotentialForm correction; correction.value = -coefficient * gradient.value - base;
    for (auto [column, derivative] : gradient.derivatives) correction.derivatives[column] = -coefficient * derivative;
    correction.derivatives[ia] -= base_coefficient; correction.derivatives[ib] += base_coefficient;
    const double bound_coefficient = limiter * base_coefficient, bound = bound_coefficient * std::min(na, nb);
    if (limiter > 0 && (bound == 0 || std::abs(correction.value) > bound)) {
        const double sign = correction.value > 0 ? 1 : correction.value < 0 ? -1 : 0;
        correction.value = sign * bound; correction.derivatives.clear(); if (bound > 0) correction.derivatives[na < nb ? ia : ib] = sign * bound_coefficient;
    }
    PotentialForm result; result.value = base + correction.value; result.derivatives = std::move(correction.derivatives); result.derivatives[ia] += base_coefficient; result.derivatives[ib] -= base_coefficient;
    return result;
}
backend::CsrMatrix csr(const Rows& rows) {
    backend::CsrMatrix a; a.rows = rows.size(); a.offsets.push_back(0);
    for (const auto& row : rows) {
        for (auto [column, value] : row) { a.columns.push_back(column); a.values.push_back(value); }
        a.offsets.push_back(a.values.size());
    }
    return a;
}
struct Assembly {
    std::vector<double> residual;
    Rows jacobian;
    double norm = 0, electric_power = 0, circuit_current = 0;
    std::vector<double> collected_rates;
    std::map<std::string, double> chemical_powers;
    std::vector<kinetics::EedfState> electrons;
    std::vector<kinetics::SphericalEedfState> spherical_electrons;
    std::vector<double> kinetic_particle_flux, kinetic_energy_flux;
    std::vector<double> ohmic_charge, ohmic_power_W;
    double ohmic_work_W = 0, ohmic_collected_current_A = 0, ohmic_terminal_current_A = 0;
    double ohmic_reconstructed_work_W = 0;
    double barycentric_frame_work_W = 0;
    double collisional_heavy_heating_W = 0;
    std::vector<std::vector<double>> thermal_power_W, thermal_step_residual_bound_J;
};
struct Weights { double a0 = 1, a1 = 1, a2 = 0; int order = 1; };
Weights weights(double dt, double previous_dt, bool second) {
    if (!second) return {};
    const double r = dt / previous_dt;
    return {(1 + 2 * r) / (1 + r), 1 + r, r * r / (1 + r), 2};
}
void photon_parameters(const Problem& p, chemistry::Environment& env, const std::vector<double>& photons) {
    for (std::size_t r = 0; r < p.radiation.size(); ++r) {
        require(photons[r] >= 0 && finite(photons[r]), "negative or nonfinite photon density");
        for (const auto& absorber : p.radiation[r].absorbers) {
            const auto reaction = std::find_if(p.mechanism.reactions.begin(), p.mechanism.reactions.end(), [&](const auto& value) { return value.id == absorber.reaction_id; });
            env.parameters[reaction->rate.key] = p.radiation[r].speed_m_s * absorber.cross_section_m2 * photons[r];
        }
    }
}
Assembly assemble(const System& sys, const State& st, const State& old, const State& older, double dt, const Weights& w) {
    const auto& p = sys.p;
    Assembly a; a.residual.assign(sys.nv, 0); a.jacobian.resize(sys.nv); a.collected_rates.assign(sys.ns, 0);
    a.thermal_power_W.assign(sys.thermal_models.size(), std::vector<double>(sys.nc, 0));
    a.thermal_step_residual_bound_J = a.thermal_power_W;
    if (p.electrical) {
        a.ohmic_charge.resize(sys.nc); a.ohmic_power_W.assign(sys.nc, 0);
        for (std::size_t c = 0; c < sys.nc; ++c) {
            a.ohmic_charge[c] = (w.a1 * old.ohmic_charge_C_m3[c] - w.a2 * older.ohmic_charge_C_m3[c]) / w.a0;
            a.residual[sys.pi(c)] -= a.ohmic_charge[c] * sys.g.volume[c];
        }
    }
    std::vector<double> phi_diagonal(sys.nc, 0);
    std::vector<chemistry::Evaluation> chem(sys.nc);
    std::vector<Transport> local_transport(sys.nc * sys.ns);
    std::vector<std::map<std::string, double>> kinetic_powers(sys.nc);
    std::vector<chemistry::Environment> environments(sys.nc);
    const bool transient = p.electron_closure && p.electron_mode == "transient_boltzmann";
    const bool spherical = p.electron_closure && p.electron_mode == "transient_spherical";
    const bool kinetic = transient || spherical;
    if (transient) a.electrons.resize(sys.nc);
    const auto fields = p.electron_closure || p.electrical ? electric_fields(sys, st) : std::vector<Point>{};
    if (p.electrical) for (std::size_t c = 0; c < sys.nc; ++c)
        a.ohmic_reconstructed_work_W += value_at(p.electrical->ohmic_conductivity_S_m, c) * dot(fields[c], fields[c]) * sys.g.volume[c];
    std::vector<chemistry::State> local_states(sys.nc);
    backend::parallel_for(sys.nc, p.options.threads, [&](std::size_t c) {
        auto& local = local_states[c];
        local.densities_m3.assign(st.densities_m3.begin() + static_cast<std::ptrdiff_t>(c * sys.ns), st.densities_m3.begin() + static_cast<std::ptrdiff_t>((c + 1) * sys.ns));
        std::copy(p.transport.begin(), p.transport.end(), local_transport.begin() + static_cast<std::ptrdiff_t>(c * sys.ns));
        auto& environment = environments[c]; environment = p.environment; environment.phase_volumes_m3.clear();
        for (const auto& [phase, fractions] : sys.phase_fractions) if (fractions[c] > 0) environment.phase_volumes_m3[phase] = fractions[c] * sys.g.volume[c];
        for (auto& [name, area] : environment.interface_areas_m2) { (void)name; area *= sys.g.volume[c] / sys.domain_volume; }
        sys.environment_temperatures(environment, st, c);
        std::vector<double> photons(sys.ng); for (std::size_t r = 0; r < sys.ng; ++r) photons[r] = st.photon_densities_m3[c * sys.ng + r];
        photon_parameters(p, environment, photons);
    });
    std::vector<kinetics::ElectronFeedback> spherical_feedback;
    if (spherical) {
        std::vector<kinetics::SpatialKineticCell> cells(sys.nc);
        for (std::size_t c = 0; c < sys.nc; ++c) {
            cells[c].candidate_state = local_states[c]; cells[c].environment = environments[c]; cells[c].electric_field_V_m = p.mesh.axisymmetric ? Point{fields[c][0], 0, fields[c][1]} : fields[c];
            if (sys.phase_fractions.at("gas")[c] > 0) { cells[c].mechanism = &sys.cell_mechanisms[c]; cells[c].coupling = &*p.electron_closure; }
        }
        kinetics::SpatialKineticOptions options; options.grid = p.electron_closure->grid; options.dt_s = dt; options.a0 = w.a0; options.a1 = w.a1; options.a2 = w.a2;
        options.relative_tolerance = std::min(1e-9, .1 * p.options.relative_tolerance);
        options.maximum_newton_iterations = static_cast<int>(p.options.maximum_newton_iterations);
        options.execution.device = p.options.device; options.execution.cuda_device = p.options.cuda_device; options.execution.threads = p.options.threads;
        // This is the replicated compatibility entry point. The rank-local
        // runtime uses advance_distributed_spatial_kinetics with owned cells.
        options.execution.mpi = false;
        if (p.mesh.axisymmetric) options.inverse_radius_m1 = kinetics::rz_geometry(p.mesh).inverse_radius_m1;
        auto kinetic_mesh = *sys.kinetic_mesh;
        const auto electron = p.mechanism.species_index(p.electron_closure->electron_species);
        for (std::size_t f = 0; f < sys.emission_templates.size(); ++f) if (sys.emission_templates[f]) {
            const auto& wall = sys.g.walls[static_cast<std::size_t>(sys.kinetic_face_wall[f])];
            const double gamma = emission_flux(sys, st, wall, electron, local_transport).value;
            auto incoming = *sys.emission_templates[f]; incoming.time_s = st.time_s;
            for (auto& mode : incoming.density_modes) mode *= gamma;
            kinetic_mesh.faces[f].wall = kinetics::KineticWall::PrescribedIncoming; kinetic_mesh.faces[f].incoming = std::move(incoming);
            a.chemical_powers["Boundary/secondary_energy_supply"] += kinetic_mesh.faces[f].area_m2 * gamma * qe * sys.emission_energy_eV[f];
        }
        const auto result = kinetics::advance_spatial_kinetics(kinetic_mesh, cells, old.spherical_electrons, options, older.spherical_electrons);
        a.spherical_electrons = result.states; spherical_feedback = result.feedback;
        a.kinetic_particle_flux.assign(sys.kinetic_mesh->faces.size(), 0); a.kinetic_energy_flux.assign(sys.kinetic_mesh->faces.size(), 0);
        for (std::size_t f = 0; f < result.face_global_ids.size(); ++f) { a.kinetic_particle_flux[result.face_global_ids[f]] = result.face_particle_flux_m2_s[f]; a.kinetic_energy_flux[result.face_global_ids[f]] = result.face_energy_flux_ev_m2_s[f]; }
    }
    const bool tabulated = p.electron_closure && p.electron_mode == "local_field_table";
    const bool reuse = p.electron_closure && !transient && !spherical && !tabulated && p.options.eedf_warm_start;
    if (reuse && sys.eedf_reuse.size() != sys.nc) sys.eedf_reuse.assign(sys.nc, kinetics::SteadyEedfReuse{{}, false});  // the closure uses no gradient terms
    backend::parallel_for(sys.nc, p.options.threads, [&](std::size_t c) {
        auto& environment = environments[c]; const auto& local = local_states[c];
        if (p.electron_closure && sys.phase_fractions.at("gas")[c] > 0) {
            auto coupling = *p.electron_closure;
            coupling.conditions.execution.mpi = false; coupling.conditions.execution.threads = 1; coupling.conditions.execution.device = p.options.device; coupling.conditions.execution.cuda_device = p.options.cuda_device;
            kinetics::ElectronFeedback feedback;
            if (spherical) feedback = spherical_feedback[c];
            else if (transient) {
                const double magnitude = length(fields[c]), longitudinal = dot(fields[c], p.electron_field_axis);
                const auto transverse = subtract(fields[c], {longitudinal * p.electron_field_axis[0], longitudinal * p.electron_field_axis[1], longitudinal * p.electron_field_axis[2]});
                require(longitudinal >= -1e-8 * std::max(1., magnitude) && length(transverse) <= 1e-8 * std::max(1., magnitude), "local Legendre field rotated or reversed; use transient_spherical");
                const auto step = kinetics::advance_electron_feedback(sys.cell_mechanisms[c], local, environment, magnitude, coupling, old.electrons.at(c), dt);
                feedback = step.feedback; a.electrons[c] = step.kinetic_step.state;
            } else if (tabulated) {
                feedback = kinetics::evaluate_electron_feedback(sys.cell_mechanisms[c], local, environment, length(fields[c]), coupling, *sys.eedf_table);
            } else {
                feedback = reuse ? kinetics::evaluate_electron_feedback(sys.cell_mechanisms[c], local, environment, length(fields[c]), coupling, sys.eedf_reuse[c])
                                 : kinetics::evaluate_electron_feedback(sys.cell_mechanisms[c], local, environment, length(fields[c]), coupling);
                require(feedback.swarm.converged, "local steady Boltzmann solve did not converge");
            }
            environment = feedback.environment;
            const auto electron = p.mechanism.species_index(p.electron_closure->electron_species);
            if (!kinetic) local_transport[c * sys.ns + electron] = {feedback.mobility_m2_V_s, feedback.diffusion_m2_s};
            kinetic_powers[c] = feedback.collision_energy_sources_W_m3;
        }
        if (transient && sys.phase_fractions.at("gas")[c] == 0) { a.electrons[c] = old.electrons.at(c); a.electrons[c].time_s += dt; }
        chem[c] = chemistry::evaluate(sys.cell_mechanisms[c], local, environment);
    });
    std::vector<bool> joule(sys.ns, false);
    for (const auto& name : p.thermal.joule_species) joule[p.mechanism.species_index(name)] = true;
    for (std::size_t c = 0; c < sys.nc; ++c) {
        for (std::size_t s = 0; s < sys.ns; ++s) {
            const auto row = c * sys.ns + s;
            const bool kinetic_electron = kinetic && s == p.mechanism.species_index(p.electron_closure->electron_species);
            if (sys.phase_fraction(s, c) == 0) {
                a.residual[row] = st.densities_m3[row]; add(a.jacobian, row, row, 1);
            } else if (kinetic_electron) {
                a.residual[row] = st.densities_m3[row] - (spherical ? a.spherical_electrons[c].electron_density_m3() : a.electrons[c].electron_density_m3());
                add(a.jacobian, row, row, 1);
            } else {
                a.residual[row] = w.a0 * st.densities_m3[row] - w.a1 * old.densities_m3[row] + w.a2 * older.densities_m3[row] - dt * chem[c].production_rates_m3_s[s];
                add(a.jacobian, row, row, w.a0);
                for (std::size_t t = 0; t < sys.ns; ++t) add(a.jacobian, row, c * sys.ns + t, -dt * chem[c].jacobian_row_major[s * sys.ns + t]);
            }
            const double q = qe * static_cast<double>(p.mechanism.species[s].charge);
            a.residual[sys.pi(c)] -= q * st.densities_m3[row] * sys.g.volume[c] * sys.phase_fraction(s, c);
            add(a.jacobian, sys.pi(c), row, -q * sys.g.volume[c] * sys.phase_fraction(s, c));
        }
        for (const auto& [name, power] : chem[c].energy_sources_W_m3) a.chemical_powers[name] += power * sys.g.volume[c] * sys.reservoir_fraction(name, c);
        // These are diagnostic operator moments, never added a second time to
        // the chemistry reservoir partitions.
        for (const auto& [name, power] : kinetic_powers[c]) {
            const double cell_power = power * sys.g.volume[c] * sys.phase_fractions.at("gas")[c];
            a.chemical_powers["EEDF/operator/" + name] += cell_power;
            if (kinetic && name == "electrons/field") a.electric_power += cell_power;
        }
        for (std::size_t r = 0; r < sys.ng; ++r) {
            const auto& group = p.radiation[r];
            a.chemical_powers["Radiation/emission/" + group.id] += value_at(group.emission_W_m3, c) * sys.g.volume[c];
            a.chemical_powers["Radiation/background_absorption/" + group.id] += group.speed_m_s * sys.opacity(group, c) * st.photon_densities_m3[c * sys.ng + r] * qe * group.photon_energy_eV * sys.g.volume[c];
        }
        if (p.thermal.enabled || sys.ng > 0) {
            const auto nt = sys.thermal_models.size();
            if (sys.heavy_pair) for (std::size_t k = 0; k < nt; ++k) if (sys.thermal_phases[k].empty() || sys.thermal_phases[k] == p.mechanism.species[sys.heavy_pair->first].phase) {
                for (const auto& name : sys.thermal_models[k].heat_reservoirs) {
                    const auto at = chem[c].energy_sources_W_m3.find(name);
                    if (at != chem[c].energy_sources_W_m3.end()) a.collisional_heavy_heating_W += at->second * sys.reservoir_fraction(name, c) * sys.g.volume[c];
                }
                if (p.thermal.use_eedf_elastic_heating) {
                    const auto at = kinetic_powers[c].find("gas/translation");
                    if (at != kinetic_powers[c].end()) a.collisional_heavy_heating_W += at->second * sys.reservoir_fraction("gas/translation", c) * sys.g.volume[c];
                }
            }
            std::vector<double> photons(sys.ng); for (std::size_t r = 0; r < sys.ng; ++r) photons[r] = st.photon_densities_m3[c * sys.ng + r];
            const auto source_values = [&](const chemistry::Evaluation& evaluation, const std::vector<double>& photon_values) {
                std::vector<double> sources(nt + sys.ng);
                for (std::size_t k = 0; k < nt; ++k) {
                    const auto& model = sys.thermal_models[k]; sources[k] = value_at(model.heating_W_m3, c) * sys.thermal_fraction(k, c);
                    for (const auto& name : model.heat_reservoirs) { const auto at = evaluation.energy_sources_W_m3.find(name); if (at != evaluation.energy_sources_W_m3.end()) sources[k] += at->second * sys.reservoir_fraction(name, c); }
                    if (p.thermal.use_eedf_elastic_heating && (sys.thermal_phases[k].empty() || sys.thermal_phases[k] == "gas")) { const auto at = kinetic_powers[c].find("gas/translation"); if (at != kinetic_powers[c].end()) sources[k] += at->second * sys.reservoir_fraction("gas/translation", c); }
                }
                for (std::size_t r = 0; r < sys.ng; ++r) {
                    const auto& group = p.radiation[r]; const double quantum = qe * group.photon_energy_eV;
                    double power = value_at(group.emission_W_m3, c);
                    const auto at = evaluation.energy_sources_W_m3.find(group.energy_reservoir); if (at != evaluation.energy_sources_W_m3.end()) power += at->second * sys.reservoir_fraction(group.energy_reservoir, c);
                    const double absorbed = group.speed_m_s * sys.opacity(group, c) * photon_values[r];
                    sources[nt + r] = power / quantum - absorbed;
                    for (std::size_t k = 0; k < nt; ++k) {
                        if (sys.thermal_phases[k].empty()) sources[k] += absorbed * quantum;
                        else if (group.absorption_m1_by_phase.contains(sys.thermal_phases[k])) sources[k] += group.speed_m_s * group.absorption_m1_by_phase.at(sys.thermal_phases[k]) * sys.thermal_fraction(k, c) * photon_values[r] * quantum;
                    }
                }
                return sources;
            };
            const auto sources = source_values(chem[c], photons);
            for (std::size_t k = 0; k < nt; ++k) {
                const double fraction = sys.thermal_fraction(k, c), capacity = value_at(sys.thermal_models[k].heat_capacity_J_m3_K, c) * fraction;
                const auto row = sys.ti(c, k);
                a.thermal_power_W[k][c] = sources[k] * sys.g.volume[c];
                if (fraction == 0) { a.residual[row] = sys.temperature(st, k, c) - sys.temperature(old, k, c); add(a.jacobian, row, row, 1); }
                else { a.residual[row] = capacity * (w.a0 * sys.temperature(st, k, c) - w.a1 * sys.temperature(old, k, c) + w.a2 * sys.temperature(older, k, c)) - dt * sources[k]; add(a.jacobian, row, row, w.a0 * capacity); }
            }
            for (std::size_t r = 0; r < sys.ng; ++r) {
                const auto at = c * sys.ng + r;
                a.residual[sys.ri(c, r)] = w.a0 * photons[r] - w.a1 * old.photon_densities_m3[at] + w.a2 * older.photon_densities_m3[at] - dt * sources[nt + r];
                add(a.jacobian, sys.ri(c, r), sys.ri(c, r), w.a0);
            }
            chemistry::State local; local.densities_m3.assign(st.densities_m3.begin() + static_cast<std::ptrdiff_t>(c * sys.ns), st.densities_m3.begin() + static_cast<std::ptrdiff_t>((c + 1) * sys.ns));
            // Only the energy partitions need numerical concentration tangents;
            // the particle-production block above uses the analytic Jacobian.
            for (std::size_t s = 0; s < sys.ns; ++s) {
                auto perturbed = local; const double h = std::max(1e-3, std::abs(local.densities_m3[s]) * 1e-6); perturbed.densities_m3[s] += h;
                const auto e = chemistry::evaluate(sys.cell_mechanisms[c], perturbed, environments[c]); const auto v = source_values(e, photons);
                for (std::size_t k = 0; k < nt; ++k) if (sys.thermal_fraction(k, c) > 0) add(a.jacobian, sys.ti(c, k), c * sys.ns + s, -dt * (v[k] - sources[k]) / h);
                for (std::size_t r = 0; r < sys.ng; ++r) add(a.jacobian, sys.ri(c, r), c * sys.ns + s, -dt * (v[nt + r] - sources[nt + r]) / h);
            }
            for (std::size_t k = 0; k < nt; ++k) {
                if (sys.thermal_fraction(k, c) == 0) continue;
                std::optional<chemistry::Evaluation> shifted;
                double h = std::max(1e-4, sys.temperature(st, k, c) * 1e-6);
                for (int shrink = 0; shrink < 8 && !shifted; ++shrink) {
                    for (double direction : {1., -1.}) {
                        auto env = environments[c];
                        if (sys.thermal_phases[k].empty() || sys.thermal_phases[k] == "gas") env.gas_temperature_K += direction * h;
                        if (sys.thermal_phases[k].empty() || sys.thermal_phases[k] == "aqueous" || sys.thermal_phases[k] == "liquid") env.liquid_temperature_K += direction * h;
                        if (env.gas_temperature_K <= 0 || env.liquid_temperature_K <= 0) continue;
                        try { shifted = chemistry::evaluate(sys.cell_mechanisms[c], local, env); h *= direction; break; }
                        catch (const std::invalid_argument&) { /* use an admissible one-sided tangent */ }
                    }
                    if (!shifted) h *= .5;
                }
                // An isolated allowed temperature has no neighbourhood derivative.
                // Freeze its material tangent; the unperturbed residual still decides acceptance.
                if (shifted) {
                    const auto& e = *shifted; const auto v = source_values(e, photons);
                    for (std::size_t s = 0; s < sys.ns; ++s) if (!kinetic || s != p.mechanism.species_index(p.electron_closure->electron_species)) add(a.jacobian, c * sys.ns + s, sys.ti(c, k), -dt * (e.production_rates_m3_s[s] - chem[c].production_rates_m3_s[s]) / h);
                    for (std::size_t t = 0; t < nt; ++t) if (sys.thermal_fraction(t, c) > 0) add(a.jacobian, sys.ti(c, t), sys.ti(c, k), -dt * (v[t] - sources[t]) / h);
                    for (std::size_t r = 0; r < sys.ng; ++r) add(a.jacobian, sys.ri(c, r), sys.ti(c, k), -dt * (v[nt + r] - sources[nt + r]) / h);
                }
            }
            for (std::size_t group = 0; group < sys.ng; ++group) {
                auto perturbed = photons; const double h = std::max(1e-3, photons[group] * 1e-6); perturbed[group] += h;
                auto env = environments[c]; photon_parameters(p, env, perturbed);
                const auto e = chemistry::evaluate(sys.cell_mechanisms[c], local, env); const auto v = source_values(e, perturbed);
                for (std::size_t s = 0; s < sys.ns; ++s) if (!kinetic || s != p.mechanism.species_index(p.electron_closure->electron_species)) add(a.jacobian, c * sys.ns + s, sys.ri(c, group), -dt * (e.production_rates_m3_s[s] - chem[c].production_rates_m3_s[s]) / h);
                for (std::size_t k = 0; k < nt; ++k) if (sys.thermal_fraction(k, c) > 0) add(a.jacobian, sys.ti(c, k), sys.ri(c, group), -dt * (v[k] - sources[k]) / h);
                for (std::size_t r = 0; r < sys.ng; ++r) add(a.jacobian, sys.ri(c, r), sys.ri(c, group), -dt * (v[nt + r] - sources[nt + r]) / h);
            }
        }
    }
    for (const auto& f : sys.g.faces) {
        for (const auto& exchange : p.interface_heat_transfer) {
            std::size_t ca = f.a, cb = f.b; const auto& fa = sys.phase_fractions.at(exchange.phase_a); const auto& fb = sys.phase_fractions.at(exchange.phase_b);
            if (fa[ca] == 0 && fb[cb] == 0) std::swap(ca, cb);
            if (!(fa[ca] > 0 && fb[cb] > 0 && fb[ca] == 0 && fa[cb] == 0)) continue;
            const auto ka = static_cast<std::size_t>(std::find(sys.thermal_phases.begin(), sys.thermal_phases.end(), exchange.phase_a) - sys.thermal_phases.begin()), kb = static_cast<std::size_t>(std::find(sys.thermal_phases.begin(), sys.thermal_phases.end(), exchange.phase_b) - sys.thermal_phases.begin());
            const double conductance = exchange.conductance_W_m2_K * f.area, power = conductance * (sys.temperature(st, ka, ca) - sys.temperature(st, kb, cb));
            a.residual[sys.ti(ca, ka)] += dt * power / sys.g.volume[ca]; a.residual[sys.ti(cb, kb)] -= dt * power / sys.g.volume[cb];
            a.thermal_power_W[ka][ca] -= power; a.thermal_power_W[kb][cb] += power;
            for (auto [cell, phase, sign] : {std::tuple{ca, ka, 1.}, std::tuple{cb, kb, -1.}}) { add(a.jacobian, sys.ti(cell, phase), sys.ti(ca, ka), sign * dt * conductance / sys.g.volume[cell]); add(a.jacobian, sys.ti(cell, phase), sys.ti(cb, kb), -sign * dt * conductance / sys.g.volume[cell]); }
            a.chemical_powers["Interface/heat_transfer/" + exchange.phase_a + "->" + exchange.phase_b] += power;
        }
        for (const auto& binding : p.face_reactions) {
            std::size_t ca = f.a, cb = f.b;
            const auto& fa = sys.phase_fractions.at(binding.phase_a); const auto& fb = sys.phase_fractions.at(binding.phase_b);
            if (fa[ca] == 0 && fb[cb] == 0) std::swap(ca, cb);
            if (!(fa[ca] > 0 && fb[cb] > 0 && fb[ca] == 0 && fa[cb] == 0)) continue;
            const auto reaction = std::find_if(p.mechanism.reactions.begin(), p.mechanism.reactions.end(), [&](const auto& value) { return value.id == binding.reaction_id; });
            chemistry::State local; local.densities_m3.assign(sys.ns, 0);
            const auto owner = [&](std::size_t s) { return p.mechanism.species[s].phase == binding.phase_a ? ca : cb; };
            for (std::size_t s = 0; s < sys.ns; ++s) if (p.mechanism.species[s].phase == binding.phase_a || p.mechanism.species[s].phase == binding.phase_b) local.densities_m3[s] = st.densities_m3[owner(s) * sys.ns + s];
            auto env = environments[ca]; env.phase_volumes_m3 = {{binding.phase_a, fa[ca] * sys.g.volume[ca]}, {binding.phase_b, fb[cb] * sys.g.volume[cb]}}; env.interface_areas_m2[reaction->basis_interface] = f.area;
            for (std::size_t k = 0; k < sys.thermal_models.size(); ++k) {
                if (sys.thermal_phases[k].empty() || sys.thermal_phases[k] == "gas") env.gas_temperature_K = sys.temperature(st, k, binding.phase_a == "gas" ? ca : cb);
                if (sys.thermal_phases[k].empty() || sys.thermal_phases[k] == "aqueous" || sys.thermal_phases[k] == "liquid") env.liquid_temperature_K = sys.temperature(st, k, binding.phase_a == "gas" ? cb : ca);
            }
            const auto exchanged = phase_interface::evaluate_reaction(p.mechanism, binding, local, env, f.area, st.potential_V[ca], st.potential_V[cb]);
            const auto& evaluation = exchanged.own_volume_sources;
            for (std::size_t s = 0; s < sys.ns; ++s) {
                const auto& phase = p.mechanism.species[s].phase; if (phase != binding.phase_a && phase != binding.phase_b) continue;
                const auto row = owner(s) * sys.ns + s; a.residual[row] -= dt * evaluation.production_rates_m3_s[s];
                for (std::size_t t = 0; t < sys.ns; ++t) if (p.mechanism.species[t].phase == binding.phase_a || p.mechanism.species[t].phase == binding.phase_b) add(a.jacobian, row, owner(t) * sys.ns + t, -dt * evaluation.jacobian_row_major[s * sys.ns + t]);
            }
            const double electrical_power = exchanged.electric_power_W;
            a.electric_power += electrical_power;
            a.chemical_powers["Interface/electric_work/" + binding.reaction_id] += electrical_power;
            for (const auto& [name, power] : evaluation.energy_sources_W_m3) {
                const auto phase = name.substr(0, name.find('/')); const auto cell = phase == binding.phase_a ? ca : cb;
                require(env.phase_volumes_m3.contains(phase), "face reaction energy must have an owner in one participating phase");
                const double total_power = power * env.phase_volumes_m3.at(phase); a.chemical_powers[name] += total_power;
                for (std::size_t k = 0; k < sys.thermal_models.size(); ++k) if (std::find(sys.thermal_models[k].heat_reservoirs.begin(), sys.thermal_models[k].heat_reservoirs.end(), name) != sys.thermal_models[k].heat_reservoirs.end()) {
                    a.residual[sys.ti(cell, k)] -= dt * total_power / sys.g.volume[cell];
                    a.thermal_power_W[k][cell] += total_power;
                }
                for (std::size_t r = 0; r < sys.ng; ++r) if (p.radiation[r].energy_reservoir == name) a.residual[sys.ri(cell, r)] -= dt * total_power / (sys.g.volume[cell] * qe * p.radiation[r].photon_energy_eV);
            }
            if (p.thermal.enabled && !binding.electrical_work_to_phase.empty()) { const auto cell = binding.electrical_work_to_phase == binding.phase_a ? ca : cb; for (std::size_t k = 0; k < sys.thermal_models.size(); ++k) if (sys.thermal_phases[k].empty() || sys.thermal_phases[k] == binding.electrical_work_to_phase) {
                a.residual[sys.ti(cell, k)] -= dt * electrical_power / sys.g.volume[cell];
                a.thermal_power_W[k][cell] += electrical_power;
            } }
        }
        const auto potential_gradient = potential_form(sys, st, sys.electrostatic_stencils.interior[f.index]);
        const double electric_coefficient = sys.interior_permittivity[f.index] * f.area;
        const double electro = -electric_coefficient * potential_gradient.value;
        a.residual[sys.pi(f.a)] += electro; a.residual[sys.pi(f.b)] -= electro;
        add_form(a.jacobian, sys.pi(f.a), potential_gradient, -electric_coefficient); add_form(a.jacobian, sys.pi(f.b), potential_gradient, electric_coefficient);
        if (p.electrical) {
            const double coefficient = sys.interior_ohmic_conductivity[f.index] * f.area;
            const double current = -coefficient * potential_gradient.value, factor = dt / w.a0;
            // Eliminate rho_Ohm through its BDF continuity equation, retaining the
            // identical oriented face current in both Gauss rows and charge states.
            a.residual[sys.pi(f.a)] += factor * current; a.residual[sys.pi(f.b)] -= factor * current;
            add_form(a.jacobian, sys.pi(f.a), potential_gradient, -factor * coefficient);
            add_form(a.jacobian, sys.pi(f.b), potential_gradient, factor * coefficient);
            a.ohmic_charge[f.a] -= factor * current / sys.g.volume[f.a];
            a.ohmic_charge[f.b] += factor * current / sys.g.volume[f.b];
            // Conservative face work uses the actual terminal potential drop.
            // Its resistance partition sends the host each material's share once.
            const double power = current * (st.potential_V[f.a] - st.potential_V[f.b]);
            const double fraction = sys.ohmic_heat_fraction_a[f.index];
            a.ohmic_power_W[f.a] += fraction * power; a.ohmic_power_W[f.b] += (1 - fraction) * power;
            a.ohmic_work_W += power;
        }
        for (auto cell : {f.a, f.b}) { const auto at = potential_gradient.derivatives.find(sys.pi(cell)); if (at != potential_gradient.derivatives.end()) phi_diagonal[cell] += std::abs(electric_coefficient * at->second); }
        PotentialForm pair_raw_ion;
        if (sys.heavy_pair && sys.aperture(sys.heavy_pair->second, f) > 0) {
            const auto ion = sys.heavy_pair->second; const auto& ta = local_transport[f.a * sys.ns + ion]; const auto& tb = local_transport[f.b * sys.ns + ion];
            const Transport transport{.5 * (ta.mobility_m2_V_s + tb.mobility_m2_V_s), .5 * (ta.diffusion_m2_s + tb.diffusion_m2_s)};
            pair_raw_ion = material_flux(sys, st, ion, transport, f.a, f.b, f.distance,
                sys.material_stencils.at(p.mechanism.species[ion].phase).interior[f.index], sys.electrostatic_stencils.interior[f.index]);
        }
        for (std::size_t s = 0; s < sys.ns; ++s) {
            if (sys.heavy_pair && s == sys.heavy_pair->first) continue;
            const auto ia = f.a * sys.ns + s, ib = f.b * sys.ns + s;
            const double aperture = sys.aperture(s, f);
            if (aperture == 0) continue;
            const auto& ta = local_transport[ia]; const auto& tb = local_transport[ib];
            const Transport transport{0.5 * (ta.mobility_m2_V_s + tb.mobility_m2_V_s), 0.5 * (ta.diffusion_m2_s + tb.diffusion_m2_s)};
            const auto& density_stencil = sys.material_stencils.at(p.mechanism.species[s].phase).interior[f.index];
            const bool paired_ion = sys.heavy_pair && s == sys.heavy_pair->second;
            auto j = paired_ion ? pair_raw_ion : material_flux(sys, st, s, transport, f.a, f.b, f.distance, density_stencil, sys.electrostatic_stencils.interior[f.index]);
            const double raw_value = j.value;
            if (paired_ion) j = barycentric_ion_flux(sys, st, j, f.a, f.b);
            else if (sys.heavy_pair && p.mechanism.species[s].phase == p.mechanism.species[sys.heavy_pair->first].phase)
                j = barycentric_electron_flux(sys, st, std::move(j), pair_raw_ion, s, f.a, f.b);
            const double ca = dt * f.area * aperture / (sys.g.volume[f.a] * sys.phase_fraction(s, f.a)), cb = dt * f.area * aperture / (sys.g.volume[f.b] * sys.phase_fraction(s, f.b));
            a.residual[ia] += ca * j.value; a.residual[ib] -= cb * j.value;
            add_form(a.jacobian, ia, j, ca); add_form(a.jacobian, ib, j, -cb);
            if (paired_ion) {
                const auto na = f.a * sys.ns + sys.heavy_pair->first, nb = f.b * sys.ns + sys.heavy_pair->first;
                a.residual[na] -= ca * j.value; a.residual[nb] += cb * j.value;
                add_form(a.jacobian, na, j, -ca); add_form(a.jacobian, nb, j, cb);
            }
            const double charge_area = qe * static_cast<double>(p.mechanism.species[s].charge) * f.area * aperture;
            const double drop = -f.distance * potential_gradient.value, work = charge_area * j.value * drop;
            a.electric_power += work;
            if (sys.heavy_pair) a.barycentric_frame_work_W += charge_area * (j.value - raw_value) * drop;
            if (p.thermal.enabled && joule[s]) {
                for (auto cell : {f.a, f.b}) for (std::size_t k = 0; k < sys.thermal_models.size(); ++k) if (sys.thermal_phases[k].empty() || sys.thermal_phases[k] == p.mechanism.species[s].phase) {
                    const double factor = -0.5 * dt / sys.g.volume[cell]; const auto row = sys.ti(cell, k);
                    a.residual[row] += factor * work;
                    a.thermal_power_W[k][cell] += 0.5 * work;
                    add_form(a.jacobian, row, j, factor * charge_area * drop);
                    add_form(a.jacobian, row, potential_gradient, -factor * charge_area * j.value * f.distance);
                }
            }
        }
        for (std::size_t k = 0; k < sys.thermal_models.size(); ++k) {
            const double ka = value_at(sys.thermal_models[k].conductivity_W_m_K, f.a), kb = value_at(sys.thermal_models[k].conductivity_W_m_K, f.b);
            const double af = sys.thermal_fraction(k, f.a), bf = sys.thermal_fraction(k, f.b), aperture = af > 0 && bf > 0 ? harmonic(af, bf) : 0;
            const double conductivity = face_conductivity(sys, f, ka, kb), area = f.area * aperture;
            const auto gradient = scalar_form(sys.thermal_stencils.at(sys.thermal_phases[k]).interior[f.index], [&](std::size_t c) { return sys.temperature(st, k, c); }, [&](std::size_t c) { return sys.ti(c, k); });
            const auto heat_flux = diffusion_flux(gradient, conductivity, f.distance, sys.ti(f.a, k), sys.temperature(st, k, f.a), sys.ti(f.b, k), sys.temperature(st, k, f.b), p.options.nonorthogonal_correction_limiter);
            for (auto [cell, other] : {std::pair{f.a, f.b}, std::pair{f.b, f.a}}) {
                (void)other; const double K = (cell == f.a ? 1 : -1) * dt * area / sys.g.volume[cell]; a.residual[sys.ti(cell, k)] += K * heat_flux.value; add_form(a.jacobian, sys.ti(cell, k), heat_flux, K);
                a.thermal_power_W[k][cell] -= (cell == f.a ? 1 : -1) * area * heat_flux.value;
            }
        }
        for (std::size_t r = 0; r < sys.ng; ++r) {
            const auto gradient = scalar_form(sys.photon_stencils[r].interior[f.index], [&](std::size_t c) { return st.photon_densities_m3[c * sys.ng + r]; }, [&](std::size_t c) { return sys.ri(c, r); });
            const auto photon_flux = diffusion_flux(gradient, p.radiation[r].diffusion_m2_s, f.distance, sys.ri(f.a, r), st.photon_densities_m3[f.a * sys.ng + r], sys.ri(f.b, r), st.photon_densities_m3[f.b * sys.ng + r], p.options.nonorthogonal_correction_limiter);
            for (auto [cell, other] : {std::pair{f.a, f.b}, std::pair{f.b, f.a}}) {
                (void)other; const double K = (cell == f.a ? 1 : -1) * dt * f.area / sys.g.volume[cell]; a.residual[sys.ri(cell, r)] += K * photon_flux.value; add_form(a.jacobian, sys.ri(cell, r), photon_flux, K);
            }
        }
    }
    double circuit_Q = 0, circuit_Ipart = 0;
    if (spherical) {
        const auto electron = p.mechanism.species_index(p.electron_closure->electron_species);
        for (std::size_t f = 0; f < sys.kinetic_face_wall.size(); ++f) {
            const int owner = sys.kinetic_face_wall[f]; if (owner == -1) continue;
            const auto& face = sys.kinetic_mesh->faces[f]; const double particles = face.area_m2 * a.kinetic_particle_flux[f], energy = face.area_m2 * qe * a.kinetic_energy_flux[f];
            if (owner >= 0) {
                const auto& wall = sys.g.walls[static_cast<std::size_t>(owner)]; const auto& boundary = p.boundaries[static_cast<std::size_t>(wall.side)];
                if (wall.surface >= 0) a.residual[sys.si(wall)] += dt * qe * particles / wall.area;
                if (p.circuit.enabled && wall.side == p.circuit.driven_side && boundary.kind == BoundaryKind::Electrode) circuit_Ipart -= qe * particles;
                a.collected_rates[electron] += particles;
                a.chemical_powers["EEDF/boundary_energy"] += energy;
            } else {
                const auto native_face = static_cast<std::size_t>(-2 - owner); const auto& contact = p.electron_phase_contacts.at(native_face); const auto& physical_face = sys.g.faces[native_face];
                const auto receiving_cell = face.left == physical_face.a ? physical_face.b : physical_face.a;
                if (!contact.absorbed_species.empty()) {
                    const auto species = p.mechanism.species_index(contact.absorbed_species); a.residual[receiving_cell * sys.ns + species] -= dt * particles / (sys.g.volume[receiving_cell] * sys.phase_fraction(species, receiving_cell));
                }
                a.chemical_powers["EEDF/phase_contact_energy"] += energy;
                if (!contact.energy_to_phase.empty()) {
                    bool assigned = false;
                    for (std::size_t k = 0; k < sys.thermal_models.size(); ++k) if (sys.thermal_phases[k].empty() || sys.thermal_phases[k] == contact.energy_to_phase) {
                        const auto receiving = sys.reservoir_fraction(contact.energy_to_phase + "/", receiving_cell) > 0 ? receiving_cell : face.left;
                        require(sys.reservoir_fraction(contact.energy_to_phase + "/", receiving) > 0, "kinetic contact heat phase has no material owner");
                        a.residual[sys.ti(receiving, k)] -= dt * energy / sys.g.volume[receiving]; assigned = true;
                        a.thermal_power_W[k][receiving] += energy;
                    }
                    require(assigned, "kinetic contact energy_to_phase requires a thermal equation");
                }
            }
        }
    }
    for (const auto& f : sys.g.walls) {
        if (f.area == 0) continue;
        const auto& b = p.boundaries[static_cast<std::size_t>(f.side)];
        const auto wp = wall_potential(p, f, st);
        const auto pc = sys.pi(f.cell);
        const bool driven = sys.circuit_unknown && f.side == p.circuit.driven_side;
        for (std::size_t r = 0; r < sys.ng; ++r) if (p.radiation[r].escaping_sides[static_cast<std::size_t>(f.side)]) {
            const auto gradient = scalar_form(sys.photon_stencils[r].boundary[f.index], [&](std::size_t c) { return st.photon_densities_m3[c * sys.ng + r]; }, [&](std::size_t c) { return sys.ri(c, r); });
            if (gradient.value > 0) continue; // A passive zero-density wall cannot inject photons.
            const double K = -dt * p.radiation[r].diffusion_m2_s * f.area / sys.g.volume[f.cell];
            a.residual[sys.ri(f.cell, r)] += K * gradient.value; add_form(a.jacobian, sys.ri(f.cell, r), gradient, K);
            a.chemical_powers["Radiation/escaped/" + p.radiation[r].id] -= p.radiation[r].diffusion_m2_s * f.area * gradient.value * qe * p.radiation[r].photon_energy_eV;
        }
        if (b.kind != BoundaryKind::Insulating) {
            const auto gradient = potential_form(sys, st, sys.electrostatic_stencils.boundary[f.index]);
            const double coefficient = epsilon(p, f.cell) * f.area;
            a.residual[pc] -= coefficient * gradient.value; add_form(a.jacobian, pc, gradient, -coefficient);
            const auto diagonal = gradient.derivatives.find(pc); if (diagonal != gradient.derivatives.end()) phi_diagonal[f.cell] += std::abs(coefficient * diagonal->second);
            if (f.surface >= 0) {
                const auto row = sys.bi(f); const double backing = p.circuit.enabled && f.side == p.circuit.driven_side ? st.driven_voltage_V : b.potential_V;
                a.residual[row] = epsilon(p, f.cell) * gradient.value + b.capacitance_F_m2 * (wp.value - backing) - st.surface_charge_C_m2[static_cast<std::size_t>(f.surface)];
                add_form(a.jacobian, row, gradient, epsilon(p, f.cell)); add(a.jacobian, row, row, b.capacitance_F_m2); add(a.jacobian, row, sys.si(f), -1);
                if (driven) add(a.jacobian, row, sys.vi(), -b.capacitance_F_m2);
            }
            if (driven) {
                if (b.kind == BoundaryKind::Electrode) { circuit_Q += coefficient * gradient.value; add_form(a.jacobian, sys.vi(), gradient, w.a0 * coefficient); }
                else { const double C = b.capacitance_F_m2 * f.area; circuit_Q += C * (st.driven_voltage_V - wp.value); add(a.jacobian, sys.vi(), sys.vi(), w.a0 * C); add(a.jacobian, sys.vi(), sys.bi(f), -w.a0 * C); }
            }
            if (p.electrical) {
                const double conductance = value_at(p.electrical->ohmic_conductivity_S_m, f.cell) * f.area;
                const double current = -conductance * gradient.value, factor = dt / w.a0;
                a.residual[pc] += factor * current; add_form(a.jacobian, pc, gradient, -factor * conductance);
                a.ohmic_charge[f.cell] -= factor * current / sys.g.volume[f.cell];
                if (f.surface >= 0) {
                    a.residual[sys.si(f)] -= dt * current / f.area;
                    add_form(a.jacobian, sys.si(f), gradient, dt * conductance / f.area);
                } else {
                    a.ohmic_collected_current_A += current;
                    if (p.circuit.enabled && f.side == p.circuit.driven_side) {
                        circuit_Ipart += current; a.ohmic_terminal_current_A -= current;
                        if (driven) add_form(a.jacobian, sys.vi(), gradient, dt * conductance);
                    }
                }
                const double power = current * (st.potential_V[f.cell] - wp.value);
                a.ohmic_power_W[f.cell] += power; a.ohmic_work_W += power;
            }
        }
        if (f.surface >= 0) {
            const auto k = static_cast<std::size_t>(f.surface), row = sys.si(f);
            a.residual[row] += w.a0 * st.surface_charge_C_m2[k] - w.a1 * old.surface_charge_C_m2[k] + w.a2 * older.surface_charge_C_m2[k];
            add(a.jacobian, row, row, w.a0);
        }
        if (!b.absorbing) continue;
        for (std::size_t s = 0; s < sys.ns; ++s) {
            const auto row = f.cell * sys.ns + s;
            if (sys.phase_fraction(s, f.cell) == 0) continue;
            const double q = qe * static_cast<double>(p.mechanism.species[s].charge);
            auto j = wall_flux(sys, st, f, s, local_transport[row]);
            if (!(kinetic && s == p.mechanism.species_index(p.electron_closure->electron_species))) {
                const auto emitted = emission_flux(sys, st, f, s, local_transport);
                j.value -= emitted.value; for (auto [column, derivative] : emitted.derivatives) j.derivatives[column] -= derivative;
                a.chemical_powers["Boundary/secondary_energy_supply"] += f.area * sys.phase_fraction(s, f.cell) * emitted.value * qe * b.secondary_energy_eV;
            }
            const double K = dt * f.area / sys.g.volume[f.cell];
            a.residual[row] += K * j.value; add_form(a.jacobian, row, j, K);
            const double charge_area = q * f.area * sys.phase_fraction(s, f.cell);
            if (f.surface >= 0) {
                const double factor = -dt * q * sys.phase_fraction(s, f.cell);
                a.residual[sys.si(f)] += factor * j.value; add_form(a.jacobian, sys.si(f), j, factor);
            }
            a.collected_rates[s] += f.area * sys.phase_fraction(s, f.cell) * j.value;
            if (p.circuit.enabled && f.side == p.circuit.driven_side && b.kind == BoundaryKind::Electrode) {
                circuit_Ipart += charge_area * j.value;
                if (driven) add_form(a.jacobian, sys.vi(), j, -dt * charge_area);
            }
            const auto normal_gradient = potential_form(sys, st, sys.electrostatic_stencils.boundary[f.index]);
            const double drop = -f.distance * normal_gradient.value;
            a.electric_power += charge_area * j.value * drop;
            if (p.thermal.enabled && joule[s]) for (std::size_t k = 0; k < sys.thermal_models.size(); ++k) if (sys.thermal_phases[k].empty() || sys.thermal_phases[k] == p.mechanism.species[s].phase) {
                const auto tr = sys.ti(f.cell, k); const double factor = -dt * charge_area / sys.g.volume[f.cell];
                a.residual[tr] += factor * j.value * drop;
                a.thermal_power_W[k][f.cell] += charge_area * j.value * drop;
                add_form(a.jacobian, tr, j, factor * drop);
                add_form(a.jacobian, tr, normal_gradient, -factor * j.value * f.distance);
            }
        }
    }
    if (sys.circuit_unknown) {
        const auto& ci = p.circuit;
        const double oldQ = sys.electrode_charge(old, ci.driven_side), olderQ = sys.electrode_charge(older, ci.driven_side);
        a.circuit_current = (ci.source_voltage_V - st.driven_voltage_V) / ci.series_resistance_ohm;
        a.residual[sys.vi()] = w.a0 * circuit_Q - w.a1 * oldQ + w.a2 * olderQ + ci.external_capacitance_F * (w.a0 * st.driven_voltage_V - w.a1 * old.driven_voltage_V + w.a2 * older.driven_voltage_V) - dt * circuit_Ipart - dt * a.circuit_current;
        add(a.jacobian, sys.vi(), sys.vi(), w.a0 * ci.external_capacitance_F + dt / ci.series_resistance_ohm);
    } else if (p.circuit.enabled) {
        const auto& ci = p.circuit;
        const double charge = sys.electrode_charge(st, ci.driven_side), old_charge = sys.electrode_charge(old, ci.driven_side), older_charge = sys.electrode_charge(older, ci.driven_side);
        // The ideal source holds V constant, including across accepted histories.
        a.circuit_current = (w.a0 * (charge - old_charge) + w.a2 * (older_charge - old_charge)) / dt - circuit_Ipart;
    }
    if (p.circuit.enabled) {
        a.chemical_powers["Electrical/source_power"] = p.circuit.source_voltage_V * a.circuit_current;
        a.chemical_powers["Electrical/resistor_loss"] = p.circuit.series_resistance_ohm * a.circuit_current * a.circuit_current;
    }
    a.chemical_powers["Electrical/particle_work"] = a.electric_power;
    if (p.heavy_barycentric_pair) {
        a.chemical_powers["Electrical/barycentric_frame_work"] = a.barycentric_frame_work_W;
        a.chemical_powers["Electrical/neutral_frame_particle_work"] = a.electric_power - a.barycentric_frame_work_W;
        a.chemical_powers["Thermal/collisional_heavy_heating"] = a.collisional_heavy_heating_W;
    }
    if (p.electrical) a.chemical_powers["Electrical/ohmic_work"] = a.ohmic_work_W;
    if (p.electrical) a.chemical_powers["Electrical/ohmic_field_reconstruction_work"] = a.ohmic_reconstructed_work_W;
    if (!sys.thermal_models.empty()) {
        double total = 0;
        for (std::size_t k = 0; k < sys.thermal_models.size(); ++k) for (std::size_t c = 0; c < sys.nc; ++c) {
            total += a.thermal_power_W[k][c];
            const double capacity = value_at(sys.thermal_models[k].heat_capacity_J_m3_K, c) * sys.thermal_fraction(k, c);
            const double baseline = std::abs(w.a0 * sys.temperature(st, k, c)) + std::abs(w.a1 * sys.temperature(old, k, c)) + std::abs(w.a2 * sys.temperature(older, k, c));
            a.thermal_step_residual_bound_J[k][c] = sys.thermal_fraction(k, c) == 0 ? 0 :
                sys.g.volume[c] * (std::abs(a.residual[sys.ti(c, k)]) + 8 * std::numeric_limits<double>::epsilon() * capacity * baseline);
        }
        a.chemical_powers["Thermal/net_energy"] = total;
    }
    std::vector<double> denominator(sys.nv, 1);
    for (std::size_t q = 0; q < sys.nc * sys.ns; ++q) denominator[q] = p.options.absolute_density_tolerance_m3 + p.options.relative_tolerance * std::max(std::abs(st.densities_m3[q]), std::abs(old.densities_m3[q]));
    for (std::size_t c = 0; c < sys.nc; ++c) denominator[sys.pi(c)] = std::max(phi_diagonal[c], eps0 * 1e-20) * p.options.potential_tolerance_V;
    for (std::size_t c = 0; c < sys.nc; ++c) {
        for (std::size_t k = 0; k < sys.thermal_models.size(); ++k) denominator[sys.ti(c, k)] = (sys.thermal_fraction(k, c) == 0 ? 1 : value_at(sys.thermal_models[k].heat_capacity_J_m3_K, c) * sys.thermal_fraction(k, c)) * (1e-7 + p.options.relative_tolerance * std::max(sys.temperature(st, k, c), sys.temperature(old, k, c)));
        for (std::size_t r = 0; r < sys.ng; ++r) denominator[sys.ri(c, r)] = p.options.absolute_density_tolerance_m3 + p.options.relative_tolerance * std::max(st.photon_densities_m3[c * sys.ng + r], old.photon_densities_m3[c * sys.ng + r]);
    }
    for (const auto& f : sys.g.walls) if (f.surface >= 0) denominator[sys.si(f)] = p.options.surface_charge_tolerance_C_m2 + p.options.relative_tolerance * std::abs(st.surface_charge_C_m2[static_cast<std::size_t>(f.surface)]);
    for (const auto& f : sys.g.walls) if (f.surface >= 0) denominator[sys.bi(f)] = (epsilon(p, f.cell) / f.distance + p.boundaries[static_cast<std::size_t>(f.side)].capacitance_F_m2) * p.options.potential_tolerance_V;
    if (sys.circuit_unknown) denominator[sys.vi()] = p.options.circuit_charge_tolerance_C + p.options.relative_tolerance * std::max({std::abs(circuit_Q), std::abs(p.circuit.external_capacitance_F * st.driven_voltage_V), std::abs(dt * a.circuit_current)});
    for (std::size_t r = 0; r < sys.nv; ++r) {
        a.residual[r] /= denominator[r];
        require(finite(a.residual[r]), "nonfinite residual");
        a.norm = std::max(a.norm, std::abs(a.residual[r]));
        for (auto& [col, value] : a.jacobian[r]) value *= sys.scales[static_cast<std::size_t>(col)] / denominator[r];
    }
    return a;
}
Sample sample(const System& sys, const State& st, const Assembly* a, const Weights& w, std::size_t iterations) {
    Sample s; s.time_s = st.time_s; s.driven_voltage_V = st.driven_voltage_V; s.order = w.order; s.newton_iterations = iterations;
    if (a) { s.source_current_A = a->circuit_current; s.electric_work_W = a->electric_power + a->ohmic_work_W; s.nonlinear_residual = a->norm;
        s.ohmic_work_W = a->ohmic_work_W; s.ohmic_terminal_current_A = a->ohmic_terminal_current_A;
        s.ohmic_reconstructed_work_W = a->ohmic_reconstructed_work_W; }
    if (a && sys.p.heavy_barycentric_pair) { s.barycentric_frame_work_W = a->barycentric_frame_work_W; s.neutral_frame_particle_work_W = a->electric_power - a->barycentric_frame_work_W; s.collisional_heavy_heating_W = a->collisional_heavy_heating_W; }
    if (sys.p.electrical) for (std::size_t c = 0; c < sys.nc; ++c) s.ohmic_charge_C += st.ohmic_charge_C_m3[c] * sys.g.volume[c];
    for (std::size_t c = 0; c < sys.nc; ++c)
        for (std::size_t k = 0; k < sys.ns; ++k) s.gas_charge_C += qe * static_cast<double>(sys.p.mechanism.species[k].charge) * st.densities_m3[c * sys.ns + k] * sys.g.volume[c] * sys.phase_fraction(k, c);
    for (std::size_t c = 0; c < sys.nc; ++c) {
        for (std::size_t k = 0; k < sys.thermal_models.size(); ++k) s.thermal_energy_J += value_at(sys.thermal_models[k].heat_capacity_J_m3_K, c) * sys.temperature(st, k, c) * sys.g.volume[c] * sys.thermal_fraction(k, c);
        for (std::size_t r = 0; r < sys.ng; ++r) s.radiation_energy_J += qe * sys.p.radiation[r].photon_energy_eV * st.photon_densities_m3[c * sys.ng + r] * sys.g.volume[c];
        if (!st.electrons.empty()) s.electron_energy_J += qe * st.electrons[c].electron_energy_ev_m3() * sys.g.volume[c] * sys.reservoir_fraction("gas/electrons", c);
        if (!st.spherical_electrons.empty()) s.electron_energy_J += qe * st.spherical_electrons[c].electron_energy_ev_m3() * sys.g.volume[c] * sys.reservoir_fraction("gas/electrons", c);
    }
    const auto fields = electric_fields(sys, st);
    for (std::size_t c = 0; c < sys.nc; ++c) s.field_energy_J += .5 * epsilon(sys.p, c) * sys.g.volume[c] * dot(fields[c], fields[c]);
    for (const auto& f : sys.g.walls) {
        const auto& b = sys.p.boundaries[static_cast<std::size_t>(f.side)];
        if (f.surface >= 0) s.surface_charge_C += f.area * st.surface_charge_C_m2[static_cast<std::size_t>(f.surface)];
        if (b.kind == BoundaryKind::Insulating) continue;
        const auto wp = wall_potential(sys.p, f, st);
        if (b.kind == BoundaryKind::Dielectric) {
            const double backing = sys.p.circuit.enabled && f.side == sys.p.circuit.driven_side ? st.driven_voltage_V : b.potential_V;
            s.field_energy_J += 0.5 * b.capacitance_F_m2 * f.area * (wp.value - backing) * (wp.value - backing);
        }
    }
    return s;
}
// A voltage change can make the old-field coupled Newton direction deplete
// particles before the circuit potential develops, damping every unknown.
// Start from a field/circuit block prediction at fixed particles, temperatures
// and surface charge. This only changes the initial iterate: the full residual,
// positivity and temporal-error acceptance tests below still apply. Conducting
// boundaries make this block a linearization, not a separate physical step.
void predict_field_circuit(const System& sys, const State& old, const State& older,
                           double dt, const Weights& w, std::vector<double>& x) {
    if (!sys.circuit_unknown) return;
    try {
        const auto initial = sys.unpack(x, old.time_s + dt);
        const auto a = assemble(sys, initial, old, older, dt, w);
        std::vector<std::size_t> fields;
        for (std::size_t c = 0; c < sys.nc; ++c) fields.push_back(sys.pi(c));
        for (std::size_t k = 0; k < sys.g.surfaces; ++k)
            fields.push_back(sys.surface_base() + sys.g.surfaces + k);
        fields.push_back(sys.vi());
        std::vector<int> slots(sys.nv, -1);
        for (std::size_t i = 0; i < fields.size(); ++i) slots[fields[i]] = static_cast<int>(i);
        Rows block(fields.size());
        std::vector<double> rhs(fields.size());
        double norm = 0;
        for (std::size_t i = 0; i < fields.size(); ++i) {
            rhs[i] = -a.residual[fields[i]];
            norm = std::max(norm, std::abs(rhs[i]));
            for (const auto& [column, value] : a.jacobian[fields[i]]) {
                const int local = slots[static_cast<std::size_t>(column)];
                if (local >= 0) block[i][local] = value;
            }
        }
        if (norm <= 1) return;
        std::vector<double> delta;
        if (sys.p.options.linear_solver == "direct") {
            auto solved = backend::solve_sparse_direct(csr(block), rhs);
            if (!solved.solved) return;
            delta = std::move(solved.solution);
        } else {
            const auto& requested = sys.p.options;
            backend::ExecutionOptions options;
            options.device = requested.device; options.threads = requested.threads;
            options.mpi = requested.mpi; options.communicator_f = requested.communicator_f;
            options.cuda_device = requested.cuda_device; options.tolerance = 1e-11;
            options.preconditioner = requested.preconditioner == "auto" ? "block_ilu0" : requested.preconditioner;
            options.restart = requested.linear_restart; options.max_iterations = requested.linear_max_iterations;
            auto solved = backend::solve_csr(csr(block), rhs, options);
            if (!solved.converged) return;
            delta = std::move(solved.solution);
        }
        if (delta.size() != fields.size()) return;
        for (std::size_t i = 0; i < fields.size(); ++i)
            if (!finite(x[fields[i]] + delta[i])) return;
        for (std::size_t i = 0; i < fields.size(); ++i) x[fields[i]] += delta[i];
    } catch (const std::exception&) {
        // A failed optional prediction leaves the original iterate for Newton.
    }
}

struct StepAttempt {
    bool accepted = false;
    State state;
    Assembly assembly;
    std::size_t iterations = 0;
    std::string failure;
};
StepAttempt attempt_step(const System& sys, const State& st, const State& older, double dt, const Weights& w) {
    const auto& problem = sys.p;
    std::vector<double> x = sys.pack(st);
    bool accepted = false;
    Assembly accepted_assembly;
    State trial;
    std::size_t iterations = 0;
    std::string failure = "Newton iteration limit";
    // The line search assembles at the iterate it accepts; that assembly is the next iteration's.
    std::optional<Assembly> accepted_trial;
    try {
        predict_field_circuit(sys, st, older, dt, w, x);
        for (; iterations < problem.options.maximum_newton_iterations; ++iterations) {
            trial = sys.unpack(x, st.time_s + dt);
            auto a = accepted_trial ? std::move(*accepted_trial) : assemble(sys, trial, st, older, dt, w);
            accepted_trial.reset();
            if (a.norm <= 1) { accepted = true; accepted_assembly = std::move(a); break; }
            std::vector<double> rhs(a.residual.size());
            for (std::size_t k = 0; k < rhs.size(); ++k) rhs[k] = -a.residual[k];
            backend::ExecutionOptions options; options.device = problem.options.device; options.threads = problem.options.threads; options.mpi = problem.options.mpi; options.communicator_f = problem.options.communicator_f; options.tolerance = 1e-11; options.max_iterations = 4000;
            options.cuda_device = problem.options.cuda_device;
        options.preconditioner = problem.options.preconditioner == "auto" ? "block_ilu0" : problem.options.preconditioner;
            options.restart = problem.options.linear_restart; options.max_iterations = problem.options.linear_max_iterations;
            backend::LinearResult linear;
            if (problem.options.linear_solver == "direct") {
                auto direct = backend::solve_sparse_direct(csr(a.jacobian), rhs);
                if (!direct.solved) { failure = "Newton direct solve failed: " + direct.message; break; }
                linear.solution = std::move(direct.solution); linear.converged = true;
            } else linear = backend::solve_csr(csr(a.jacobian), rhs, options);
            if (!linear.converged) { failure = "Newton linear solve did not converge"; break; }
            double step = 1;
            for (std::size_t k = 0; k < sys.nc * sys.ns; ++k) {
                if (x[k] * sys.scales[k] > problem.options.absolute_density_tolerance_m3 && linear.solution[k] < 0 && x[k] + linear.solution[k] < 0) step = std::min(step, 0.99 * x[k] / -linear.solution[k]);
            }
            for (std::size_t c = 0; c < sys.nc; ++c) {
                const auto limit = [&](std::size_t k) { if (linear.solution[k] < 0 && x[k] + linear.solution[k] <= 0) step = std::min(step, .99 * x[k] / -linear.solution[k]); };
                for (std::size_t k = 0; k < sys.thermal_models.size(); ++k) limit(sys.ti(c, k));
                for (std::size_t r = 0; r < sys.ng; ++r) { const auto k = sys.ri(c, r); if (x[k] * sys.scales[k] > problem.options.absolute_density_tolerance_m3) limit(k); }
            }
            bool improved = false;
            for (int ls = 0; ls < 24 && step > 1e-14; ++ls) {
                auto candidate = x;
                for (std::size_t k = 0; k < x.size(); ++k) candidate[k] += step * linear.solution[k];
                // Project only constrained variables; the full residual at
                // this nonnegative trial still gates acceptance.
                for (std::size_t k = 0; k < sys.nc * sys.ns; ++k) candidate[k] = std::max(0., candidate[k]);
                for (std::size_t c = 0; c < sys.nc; ++c) for (std::size_t r = 0; r < sys.ng; ++r) candidate[sys.ri(c, r)] = std::max(0., candidate[sys.ri(c, r)]);
                const auto next = sys.unpack(candidate, st.time_s + dt);
                try {
                    auto b = assemble(sys, next, st, older, dt, w);
                    if (b.norm <= 1 || b.norm < a.norm * (1 - 1e-4 * step)) { x = std::move(candidate); accepted_trial = std::move(b); improved = true; break; }
                } catch (const std::invalid_argument&) { /* inadmissible trial: backtrack */ }
                step *= 0.5;
            }
            if (!improved) { failure = "positive Newton line search failed"; break; }
        }
    } catch (const std::exception& e) { failure = e.what(); }
    if (accepted) {
        if (problem.electrical) {
            double scale = 0; for (double power : accepted_assembly.ohmic_power_W) scale += std::abs(power);
            for (double power : accepted_assembly.ohmic_power_W) if (power < -1e-12 * scale) {
                accepted = false; failure = "Ohmic mesh validity limit: multipoint face work gives negative material-cell dissipation; refine or use an energy-positive spatial discretization"; break;
            }
        }
        if (problem.electrical) trial.ohmic_charge_C_m3 = accepted_assembly.ohmic_charge;
        if (!accepted_assembly.electrons.empty()) trial.electrons = accepted_assembly.electrons;
        if (!accepted_assembly.spherical_electrons.empty()) trial.spherical_electrons = accepted_assembly.spherical_electrons;
    }
    return {accepted, std::move(trial), std::move(accepted_assembly), iterations, failure};
}
double temporal_error(const System& sys, const State& full, const State& refined, int order, double ratio) {
    const auto& o = sys.p.options;
    auto a = sys.pack(full), b = sys.pack(refined);
    std::vector<double> atol(sys.nv, o.temporal_density_tolerance_m3);
    for (std::size_t c = 0; c < sys.nc; ++c) {
        atol[sys.pi(c)] = o.temporal_potential_tolerance_V;
        for (std::size_t k = 0; k < sys.thermal_models.size(); ++k) atol[sys.ti(c, k)] = o.temporal_temperature_tolerance_K;
    }
    for (const auto& wall : sys.g.walls) if (wall.surface >= 0) { atol[sys.si(wall)] = o.temporal_surface_charge_tolerance_C_m2; atol[sys.bi(wall)] = o.temporal_potential_tolerance_V; }
    if (sys.circuit_unknown) atol[sys.vi()] = o.temporal_potential_tolerance_V;
    for (std::size_t q = 0; q < sys.nv; ++q) atol[q] /= sys.scales[q];
    // Control every retained angular coefficient, including signed m modes.
    // A shared cell-density scale prevents a vanishing coefficient from forcing
    // infinite refinement while its absolute contribution is below density atol.
    const auto append_electrons = [&](const auto& left, const auto& right) {
        require(left.size() == right.size(), "temporal electron state shape mismatch");
        for (std::size_t c = 0; c < left.size(); ++c) {
            const auto& u = left[c].density_modes; const auto& v = right[c].density_modes;
            require(u.size() == v.size(), "temporal angular state shape mismatch");
            const double density = std::max({left[c].electron_density_m3(), right[c].electron_density_m3(), o.temporal_density_tolerance_m3});
            double peak = 0; for (std::size_t q = 0; q < u.size(); ++q) peak = std::max({peak, std::abs(u[q]), std::abs(v[q])});
            const double scale = std::max(peak, std::numeric_limits<double>::min());
            for (std::size_t q = 0; q < u.size(); ++q) {
                a.push_back(u[q] / scale); b.push_back(v[q] / scale);
                atol.push_back(o.temporal_density_tolerance_m3 / density);
            }
            a.push_back(left[c].electron_energy_ev_m3() / density);
            b.push_back(right[c].electron_energy_ev_m3() / density);
            atol.push_back(o.temporal_density_tolerance_m3 / density);
        }
    };
    append_electrons(full.electrons, refined.electrons);
    append_electrons(full.spherical_electrons, refined.spherical_electrons);
    if (sys.p.electrical) for (std::size_t c = 0; c < sys.nc; ++c) {
        a.push_back(full.ohmic_charge_C_m3[c]); b.push_back(refined.ohmic_charge_C_m3[c]);
        atol.push_back(qe * o.temporal_density_tolerance_m3);
    }
    return time::estimate_error(a, b, atol, o.temporal_relative_tolerance, order, ratio).normalized_error;
}
} // namespace

double bernoulli(double x) {
    require(finite(x), "nonfinite Bernoulli argument");
    if (std::abs(x) < 1e-4) { const double x2 = x * x; return 1 - x / 2 + x2 / 12 - x2 * x2 / 720; }
    if (x > 50) return x * std::exp(-x);
    if (x < -50) return -x;
    return x / std::expm1(x);
}
double scharfetter_gummel_flux(double na, double nb, double pa, double pb, double d, int z, const Transport& t) {
    require(na >= 0 && nb >= 0 && finite(na) && finite(nb) && finite(pa) && finite(pb) && d > 0 && finite(d), "invalid face state");
    require(t.mobility_m2_V_s >= 0 && t.diffusion_m2_s >= 0 && finite(t.mobility_m2_V_s) && finite(t.diffusion_m2_s), "invalid transport");
    return flux(na, nb, pa, pb, d, z, t).value;
}
std::vector<double> cell_volumes(const Mesh& mesh) { return geometry(mesh).volume; }

namespace {
struct ElectrostaticState { std::vector<double> potential, dielectric; };
ElectrostaticState solve_electrostatic(const Problem& p, const System& sys, const std::vector<double>& rho, const std::vector<double>& sigma, double drive) {
    require(rho.size() == sys.nc, "charge density size mismatch");
    require(sigma.empty() || sigma.size() == sys.g.surfaces, "surface charge size mismatch");
    std::vector<mesh::EllipticBoundary> boundaries;
    for (const auto& wall : sys.g.walls) {
        const auto& b = p.boundaries[static_cast<std::size_t>(wall.side)];
        mesh::EllipticBoundary data;
        data.kind = b.kind == BoundaryKind::Electrode ? mesh::EllipticBoundaryKind::Dirichlet : b.kind == BoundaryKind::Dielectric ? mesh::EllipticBoundaryKind::Robin : mesh::EllipticBoundaryKind::Neumann;
        data.value = p.circuit.enabled && wall.side == p.circuit.driven_side ? drive : b.potential_V;
        data.capacitance = b.capacitance_F_m2;
        if (wall.surface >= 0) data.source = sigma.empty() ? b.initial_surface_charge_C_m2 : sigma[static_cast<std::size_t>(wall.surface)];
        boundaries.push_back(data);
    }
    const auto coefficients = p.permittivity_F_m.empty() ? std::vector<double>{eps0} : p.permittivity_F_m;
    auto system = mesh::assemble_elliptic(sys.g.native, coefficients, rho, boundaries);
    for (std::size_t row = 0; row < system.matrix.rows; ++row) {
        double scale = 0;
        for (auto at = system.matrix.offsets[row]; at < system.matrix.offsets[row + 1]; ++at) scale = std::max(scale, std::abs(system.matrix.values[at]));
        require(scale > 0 && finite(scale), "unanchored Poisson row");
        system.rhs[row] /= scale;
        for (auto at = system.matrix.offsets[row]; at < system.matrix.offsets[row + 1]; ++at) system.matrix.values[at] /= scale;
    }
    backend::ExecutionOptions options; options.device = p.options.device; options.threads = p.options.threads; options.mpi = p.options.mpi; options.communicator_f = p.options.communicator_f; options.tolerance = 1e-12;
    options.cuda_device = p.options.cuda_device;
    options.preconditioner = p.options.preconditioner == "auto" ? "block_ilu0" : p.options.preconditioner;
    options.restart = p.options.linear_restart; options.max_iterations = p.options.linear_max_iterations;
    backend::LinearResult solution;
    if (p.options.linear_solver == "direct") {
        require(!p.options.mpi, "Poisson direct solve requires serial execution");
        require(backend::sparse_direct_available(), "Poisson direct solve needs a Raikou build with Eigen 3");
        auto direct = backend::solve_sparse_direct(system.matrix, system.rhs);
        if (!direct.solved) throw std::runtime_error("spatial: Poisson direct solve failed: " + direct.message);
        solution.solution = std::move(direct.solution); solution.converged = true;
    } else solution = backend::solve_csr(system.matrix, system.rhs, options);
    if (!solution.converged) throw std::runtime_error("spatial: initial Poisson solve did not converge");
    ElectrostaticState state; state.potential.assign(solution.solution.begin(), solution.solution.begin() + static_cast<std::ptrdiff_t>(sys.nc)); state.dielectric.resize(sys.g.surfaces);
    for (const auto& wall : sys.g.walls) if (wall.surface >= 0) state.dielectric[static_cast<std::size_t>(wall.surface)] = solution.solution[static_cast<std::size_t>(system.robin_wall_dofs[wall.index])];
    return state;
}
} // namespace
std::vector<double> solve_poisson(const Problem& p, const std::vector<double>& rho, const std::vector<double>& sigma, double drive) {
    const System sys(p); return solve_electrostatic(p, sys, rho, sigma, drive).potential;
}

Result solve(const Problem& problem) {
    require(!problem.electrical || !problem.options.mpi, "background Ohmic conduction currently requires serial spatial.solve");
    require(!problem.heavy_barycentric_pair || !problem.options.mpi, "heavy_barycentric_pair currently requires serial spatial.solve");
    if (problem.options.mpi) return solve_mpi_compat(problem);
    System sys(problem);
    Result result;
    State st; st.densities_m3 = problem.initial_densities_m3; st.surface_charge_C_m2.resize(sys.g.surfaces);
    if (problem.electrical) { st.ohmic_charge_C_m3.resize(sys.nc); for (std::size_t c = 0; c < sys.nc; ++c) st.ohmic_charge_C_m3[c] = value_at(problem.electrical->initial_ohmic_charge_C_m3, c); }
    st.photon_densities_m3.resize(sys.nc * sys.ng); sys.temperatures(st);
    for (std::size_t c = 0; c < sys.nc; ++c) {
        for (std::size_t r = 0; r < sys.ng; ++r) st.photon_densities_m3[c * sys.ng + r] = value_at(problem.radiation[r].initial_density_m3, c);
    }
    st.driven_voltage_V = sys.circuit_unknown ? problem.circuit.initial_voltage_V : problem.circuit.source_voltage_V;
    for (const auto& f : sys.g.walls) if (f.surface >= 0) st.surface_charge_C_m2[static_cast<std::size_t>(f.surface)] = problem.boundaries[static_cast<std::size_t>(f.side)].initial_surface_charge_C_m2;
    State older;
    std::vector<double> collected(sys.ns, 0), collected_prev(sys.ns, 0);
    std::map<std::string, double> energy, energy_prev;
    std::vector<double> ohmic_heat(problem.electrical ? sys.nc : 0, 0), ohmic_heat_prev = ohmic_heat;
    double ohmic_collected = 0, ohmic_collected_prev = 0;
    std::map<std::string, std::vector<double>> thermal_energy, thermal_bound;
    for (const auto& phase : sys.thermal_phases) {
        thermal_energy[phase].assign(sys.nc, 0); thermal_bound[phase].assign(sys.nc, 0);
    }
    auto thermal_energy_prev = thermal_energy, thermal_bound_prev = thermal_bound;
    const bool thermal_available = !problem.initial_checkpoint || problem.initial_checkpoint->thermal_energy_ledger_available;
    const auto bounded_step = [&](double proposal) { return std::clamp(proposal, problem.options.minimum_time_step_s, problem.options.time_step_s); };
    double dt = problem.options.time_step_s, previous_dt = 0;
    if (problem.initial_checkpoint) {
        const auto& cp = *problem.initial_checkpoint;
        const auto validate_state = [&](const State& value) {
            require(value.time_s >= 0 && finite(value.time_s) && finite(value.driven_voltage_V), "invalid checkpoint clock or voltage");
            require(value.densities_m3.size() == sys.nc * sys.ns && value.potential_V.size() == sys.nc && value.surface_charge_C_m2.size() == sys.g.surfaces && value.photon_densities_m3.size() == sys.nc * sys.ng && value.temperature_K.size() == (!sys.thermal_phases.empty() && sys.thermal_phases[0].empty() ? sys.nc : 0), "checkpoint state shape mismatch");
            for (const auto& phase : sys.thermal_phases) if (!phase.empty()) { require(value.phase_temperatures_K.contains(phase) && value.phase_temperatures_K.at(phase).size() == sys.nc, "checkpoint phase temperature shape mismatch"); for (double T : value.phase_temperatures_K.at(phase)) require(T > 0 && finite(T), "invalid checkpoint phase temperature"); }
            for (double n : value.densities_m3) require(n >= 0 && finite(n), "invalid checkpoint density");
            for (double n : value.photon_densities_m3) require(n >= 0 && finite(n), "invalid checkpoint photon density");
            for (double t : value.temperature_K) require(t > 0 && finite(t), "invalid checkpoint temperature");
            for (double v : value.potential_V) require(finite(v), "invalid checkpoint potential");
            for (double v : value.surface_charge_C_m2) require(finite(v), "invalid checkpoint surface charge");
            require(value.dielectric_potential_V.size() == sys.g.surfaces, "checkpoint dielectric potential shape mismatch");
            for (double v : value.dielectric_potential_V) require(finite(v), "invalid checkpoint dielectric potential");
            require(value.ohmic_charge_C_m3.size() == (problem.electrical ? sys.nc : 0), "checkpoint Ohmic charge shape mismatch");
            for (double v : value.ohmic_charge_C_m3) require(finite(v), "invalid checkpoint Ohmic charge");
            if (problem.electrical) for (std::size_t c = 0; c < sys.nc; ++c)
                require(sys.phase_fractions.at(problem.electrical->phase)[c] > 0 || value.ohmic_charge_C_m3[c] == 0, "checkpoint absent electrical phase cannot own charge");
        };
        validate_state(cp.state); validate_state(cp.previous_state);
        require(cp.boundary_counts.size() == sys.ns && cp.previous_boundary_counts.size() == sys.ns, "checkpoint ledger shape mismatch");
        require(cp.next_step_s > 0 && finite(cp.next_step_s), "checkpoint next timestep must be finite and positive");
        for (const auto* ledger : {&cp.boundary_counts, &cp.previous_boundary_counts}) for (double count : *ledger) require(finite(count), "invalid checkpoint boundary ledger");
        for (const auto* ledger : {&cp.energy_integrals_J, &cp.previous_energy_integrals_J}) for (const auto& [name, value] : *ledger) { (void)name; require(finite(value), "invalid checkpoint energy ledger"); }
        if (cp.accepted_steps > 0) require(cp.previous_step_s > 0 && finite(cp.previous_step_s) && std::abs(cp.state.time_s - cp.previous_state.time_s - cp.previous_step_s) <= 1e-10 * cp.previous_step_s, "checkpoint BDF history clock mismatch");
        // Early v1 serial checkpoints recorded the initial proposal here even
        // when no step was accepted. Equal clocks identify that harmless
        // legacy form; retain no BDF history and export its canonical zero.
        else require(cp.previous_step_s >= 0 && finite(cp.previous_step_s) && cp.state.time_s == cp.previous_state.time_s, "zero-step checkpoint has inconsistent previous history");
        require(cp.state.time_s <= problem.options.end_time_s * (1 + 1e-12), "checkpoint is later than requested end time");
        st = cp.state; older = cp.previous_state; result.accepted_steps = cp.accepted_steps;
        collected = cp.boundary_counts; collected_prev = cp.previous_boundary_counts; energy = cp.energy_integrals_J; energy_prev = cp.previous_energy_integrals_J;
        require(cp.ohmic_heating_J.size() == ohmic_heat.size() && cp.previous_ohmic_heating_J.size() == ohmic_heat.size(), "checkpoint Ohmic heat history shape mismatch");
        for (const auto* values : {&cp.ohmic_heating_J, &cp.previous_ohmic_heating_J}) for (double value : *values) require(finite(value), "invalid checkpoint Ohmic heat");
        require(finite(cp.ohmic_boundary_charge_C) && finite(cp.previous_ohmic_boundary_charge_C), "invalid checkpoint Ohmic boundary charge");
        ohmic_heat = cp.ohmic_heating_J; ohmic_heat_prev = cp.previous_ohmic_heating_J;
        ohmic_collected = cp.ohmic_boundary_charge_C; ohmic_collected_prev = cp.previous_ohmic_boundary_charge_C;
        const auto validate_thermal_ledger = [&](const auto& ledger, bool nonnegative) {
            require(ledger.size() == sys.thermal_phases.size(), "checkpoint thermal ledger phase ownership mismatch");
            for (std::size_t k = 0; k < sys.thermal_phases.size(); ++k) {
                const auto& phase = sys.thermal_phases[k];
                require(ledger.contains(phase) && ledger.at(phase).size() == sys.nc, "checkpoint thermal ledger cell shape mismatch");
                for (std::size_t c = 0; c < sys.nc; ++c) {
                    const double value = ledger.at(phase)[c];
                    require(finite(value) && (!nonnegative || value >= 0), "invalid checkpoint thermal energy ledger");
                    require(sys.thermal_fraction(k, c) > 0 || value == 0, "checkpoint absent thermal phase cannot own energy");
                }
            }
        };
        if (thermal_available) {
            validate_thermal_ledger(cp.thermal_energy_integrals_J, false);
            validate_thermal_ledger(cp.previous_thermal_energy_integrals_J, false);
            validate_thermal_ledger(cp.thermal_energy_residual_bound_J, true);
            validate_thermal_ledger(cp.previous_thermal_energy_residual_bound_J, true);
            for (const auto& phase : sys.thermal_phases) for (std::size_t c = 0; c < sys.nc; ++c)
                require(cp.thermal_energy_residual_bound_J.at(phase)[c] >= cp.previous_thermal_energy_residual_bound_J.at(phase)[c],
                        "checkpoint thermal residual bound history must be monotone");
        } else {
            require(cp.thermal_energy_integrals_J.empty() && cp.previous_thermal_energy_integrals_J.empty()
                && cp.thermal_energy_residual_bound_J.empty() && cp.previous_thermal_energy_residual_bound_J.empty(),
                "unavailable checkpoint thermal history must not contain partial ledgers");
            energy.erase("Thermal/net_energy"); energy_prev.erase("Thermal/net_energy");
        }
        thermal_energy = cp.thermal_energy_integrals_J; thermal_energy_prev = cp.previous_thermal_energy_integrals_J;
        thermal_bound = cp.thermal_energy_residual_bound_J; thermal_bound_prev = cp.previous_thermal_energy_residual_bound_J;
        if (cp.accepted_steps > 0) previous_dt = cp.previous_step_s;
        dt = bounded_step(cp.next_step_s);
    }
    std::vector<double> rho(sys.nc, 0);
    for (std::size_t c = 0; c < sys.nc; ++c) for (std::size_t s = 0; s < sys.ns; ++s) rho[c] += qe * static_cast<double>(problem.mechanism.species[s].charge) * st.densities_m3[c * sys.ns + s] * sys.phase_fraction(s, c);
    if (problem.electrical) for (std::size_t c = 0; c < sys.nc; ++c) rho[c] += st.ohmic_charge_C_m3[c];
    const auto poisson = solve_electrostatic(problem, sys, rho, st.surface_charge_C_m2, st.driven_voltage_V);
    if (problem.initial_checkpoint) {
        for (std::size_t c = 0; c < sys.nc; ++c) require(std::abs(st.potential_V[c] - poisson.potential[c]) <= 20 * problem.options.potential_tolerance_V, "checkpoint potential is inconsistent with charge or boundary data");
        require(st.dielectric_potential_V.size() == poisson.dielectric.size(), "checkpoint dielectric potential shape mismatch");
        for (std::size_t k = 0; k < poisson.dielectric.size(); ++k) require(std::abs(st.dielectric_potential_V[k] - poisson.dielectric[k]) <= 20 * problem.options.potential_tolerance_V, "checkpoint dielectric potential is inconsistent with charge");
    } else { st.potential_V = poisson.potential; st.dielectric_potential_V = poisson.dielectric; older = st; }
    if (problem.initial_checkpoint) {
        std::fill(rho.begin(), rho.end(), 0);
        for (std::size_t c = 0; c < sys.nc; ++c) for (std::size_t s = 0; s < sys.ns; ++s) rho[c] += qe * static_cast<double>(problem.mechanism.species[s].charge) * older.densities_m3[c * sys.ns + s] * sys.phase_fraction(s, c);
        if (problem.electrical) for (std::size_t c = 0; c < sys.nc; ++c) rho[c] += older.ohmic_charge_C_m3[c];
        const auto previous_poisson = solve_electrostatic(problem, sys, rho, older.surface_charge_C_m2, older.driven_voltage_V);
        for (std::size_t c = 0; c < sys.nc; ++c) require(std::abs(older.potential_V[c] - previous_poisson.potential[c]) <= 20 * problem.options.potential_tolerance_V, "checkpoint previous potential is inconsistent with its charge or boundary data");
        require(older.dielectric_potential_V.size() == previous_poisson.dielectric.size(), "checkpoint previous dielectric potential shape mismatch");
        for (std::size_t k = 0; k < previous_poisson.dielectric.size(); ++k) require(std::abs(older.dielectric_potential_V[k] - previous_poisson.dielectric[k]) <= 20 * problem.options.potential_tolerance_V, "checkpoint previous dielectric potential is inconsistent with charge");
    }
    if (problem.electron_closure && problem.electron_mode == "transient_boltzmann" && !problem.initial_checkpoint) {
        const auto electron = problem.mechanism.species_index(problem.electron_closure->electron_species);
        for (std::size_t c = 0; c < sys.nc; ++c) {
            if (sys.phase_fraction(electron, c) > 0) st.electrons.push_back(kinetics::maxwellian_eedf(st.densities_m3[c * sys.ns + electron], problem.initial_electron_mean_energy_eV, problem.electron_closure->grid));
            else { kinetics::EedfState electrons; electrons.grid = problem.electron_closure->grid; electrons.density_modes.assign(static_cast<std::size_t>(electrons.grid.cells) * static_cast<std::size_t>(electrons.grid.legendre_terms), 0); st.electrons.push_back(std::move(electrons)); }
        }
        older = st;
    }
    if (problem.electron_closure && problem.electron_mode == "transient_spherical" && !problem.initial_checkpoint) {
        const auto electron = problem.mechanism.species_index(problem.electron_closure->electron_species);
        for (std::size_t c = 0; c < sys.nc; ++c) {
            if (sys.phase_fraction(electron, c) > 0) st.spherical_electrons.push_back(kinetics::spherical_from_legendre(kinetics::maxwellian_eedf(st.densities_m3[c * sys.ns + electron], problem.initial_electron_mean_energy_eV, problem.electron_closure->grid)));
            else { kinetics::SphericalEedfState electrons; electrons.grid = problem.electron_closure->grid; electrons.density_modes.assign(static_cast<std::size_t>(electrons.grid.cells) * static_cast<std::size_t>(electrons.grid.legendre_terms * electrons.grid.legendre_terms), 0); st.spherical_electrons.push_back(std::move(electrons)); }
        }
        older = st;
    }
    if (problem.electron_closure && problem.electron_mode == "transient_spherical") {
        const auto validate_spherical = [&](const State& state) {
            require(state.spherical_electrons.size() == sys.nc && state.electrons.empty(), "spherical restart requires all L^2 modes and cannot project a Legendre slice");
            const auto electron = problem.mechanism.species_index(problem.electron_closure->electron_species);
            for (std::size_t c = 0; c < sys.nc; ++c) {
                const auto& e = state.spherical_electrons[c]; e.validate(); const auto& grid = problem.electron_closure->grid;
                require(e.grid.cells == grid.cells && e.grid.legendre_terms == grid.legendre_terms && e.grid.power == grid.power && e.grid.max_energy_ev == grid.max_energy_ev, "checkpoint spherical kinetic grid differs");
                require(std::abs(e.time_s - state.time_s) <= 1e-12 * std::max(1e-30, state.time_s), "checkpoint spherical/spatial clocks differ");
                const auto stride = static_cast<std::size_t>(grid.legendre_terms * grid.legendre_terms);
                for (std::size_t slot = 0; slot < static_cast<std::size_t>(grid.cells); ++slot) require(e.density_modes[slot * stride] >= 0, "checkpoint spherical F00 must be nonnegative in every energy cell");
                require(e.electron_energy_ev_m3() >= 0 && finite(e.electron_energy_ev_m3()), "checkpoint spherical electron energy is invalid");
                const double ne = state.densities_m3[c * sys.ns + electron]; require(std::abs(e.electron_density_m3() - ne) <= problem.options.absolute_density_tolerance_m3 + problem.options.relative_tolerance * ne, "checkpoint spherical electron count differs from F00 moment");
            }
        }; validate_spherical(st); validate_spherical(older);
    }
    if (problem.electron_closure && problem.electron_mode == "transient_boltzmann") {
        const auto validate_electrons = [&](const State& state) {
            require(state.electrons.size() == sys.nc, "checkpoint needs a full kinetic state for every cell");
            const auto electron = problem.mechanism.species_index(problem.electron_closure->electron_species);
            for (std::size_t c = 0; c < sys.nc; ++c) {
                const auto& e = state.electrons[c]; const auto& grid = problem.electron_closure->grid;
                require(e.grid.cells == grid.cells && e.grid.legendre_terms == grid.legendre_terms && e.grid.power == grid.power && e.grid.max_energy_ev == grid.max_energy_ev, "checkpoint kinetic grid differs from mechanism");
                require(std::abs(e.time_s - state.time_s) <= 1e-12 * std::max(1e-30, state.time_s), "checkpoint kinetic and spatial clocks differ");
                const double ne = state.densities_m3[c * sys.ns + electron];
                require(std::abs(e.electron_density_m3() - ne) <= problem.options.absolute_density_tolerance_m3 + problem.options.relative_tolerance * ne, "checkpoint electron count differs from kinetic moment");
                require(e.electron_energy_ev_m3() >= 0 && finite(e.electron_energy_ev_m3()), "checkpoint electron energy is invalid");
                for (double mode : e.density_modes) require(finite(mode), "checkpoint contains a nonfinite kinetic mode");
                const auto stride = static_cast<std::size_t>(grid.legendre_terms);
                require(kinetics::detail::legendre_isotropic_nonnegative(e.density_modes, static_cast<std::size_t>(grid.cells), stride), "checkpoint F0 must be nonnegative within numerical tolerance");
                require(kinetics::detail::legendre_padding_zero(e.density_modes, static_cast<std::size_t>(grid.cells), stride), "checkpoint Legendre padding must be zero");
            }
        };
        validate_electrons(st); validate_electrons(older);
    }
    result.samples.push_back(sample(sys, st, nullptr, {}, 0));
    for (std::size_t attempt = 0; attempt < problem.options.maximum_steps && st.time_s < problem.options.end_time_s * (1 - 1e-12); ++attempt) {
        dt = std::min(bounded_step(dt), problem.options.end_time_s - st.time_s);
        if (!(dt > 0)) break;
        const Weights w = weights(dt, previous_dt, problem.options.bdf2 && result.accepted_steps > 0 && dt / previous_dt <= 2.4);
        auto candidate = attempt_step(sys, st, older, dt, w);
        double error = 0;
        if (candidate.accepted && problem.options.adaptive_time) {
            auto half = attempt_step(sys, st, older, dt / 2, weights(dt / 2, previous_dt, w.order == 2));
            if (half.accepted) {
                auto refined = attempt_step(sys, half.state, st, dt / 2, weights(dt / 2, dt / 2, w.order == 2));
                if (refined.accepted) error = temporal_error(sys, candidate.state, refined.state, w.order, w.order == 1 ? 1 : dt / previous_dt);
                else { error = std::numeric_limits<double>::infinity(); candidate.failure = "temporal refinement solve failed: " + refined.failure; }
            } else { error = std::numeric_limits<double>::infinity(); candidate.failure = "temporal half-step solve failed: " + half.failure; }
            if (error > 1) { candidate.accepted = false; if (finite(error)) candidate.failure = "temporal truncation error exceeds tolerance"; }
        }
        bool accepted = candidate.accepted;
        auto& accepted_assembly = candidate.assembly;
        auto& trial = candidate.state;
        const auto iterations = candidate.iterations;
        const auto& failure = candidate.failure;
        if (!accepted) {
            ++result.rejected_steps;
            if (failure.find("Ohmic mesh validity limit:") != std::string::npos) { result.message = failure; break; }
            if (dt <= problem.options.minimum_time_step_s * (1 + 1e-12)) { result.message = failure; break; }
            const double factor = error > 1 ? time::recommended_factor(error, w.order, false) : .5;
            dt = std::max(problem.options.minimum_time_step_s, factor * dt);
            continue; // st and its accepted history remain unchanged.
        }
        for (std::size_t s = 0; s < sys.ns; ++s) {
            const double next = (w.a1 * collected[s] - w.a2 * collected_prev[s] + dt * accepted_assembly.collected_rates[s]) / w.a0;
            collected_prev[s] = collected[s]; collected[s] = next;
        }
        std::set<std::string> energy_keys;
        if (!thermal_available) accepted_assembly.chemical_powers.erase("Thermal/net_energy");
        for (const auto* ledger : {&energy, &energy_prev, &accepted_assembly.chemical_powers})
            for (const auto& [name, value] : *ledger) { (void)value; energy_keys.insert(name); }
        std::map<std::string, double> next_energy;
        for (const auto& name : energy_keys) next_energy[name] = (w.a1 * energy[name] - w.a2 * energy_prev[name] + dt * accepted_assembly.chemical_powers[name]) / w.a0;
        energy_prev = std::move(energy); energy = std::move(next_energy);
        if (thermal_available) for (std::size_t k = 0; k < sys.thermal_phases.size(); ++k) {
            const auto& phase = sys.thermal_phases[k];
            for (std::size_t c = 0; c < sys.nc; ++c) {
                const double next = (w.a1 * thermal_energy[phase][c] - w.a2 * thermal_energy_prev[phase][c]
                                     + dt * accepted_assembly.thermal_power_W[k][c]) / w.a0;
                // Since a1=a0+a2, thermal storage error obeys the zero-stable
                // first-difference recurrence a0*de_new=a2*de_old+residual.
                // Bounding whole states with |a1| and |a2| would create
                // artificial exponential growth. Directed rounding keeps the
                // saved monotone bound differences conservative as well.
                const auto upward = [](double value) { return value == 0 ? 0 : std::nextafter(value, std::numeric_limits<double>::infinity()); };
                const double previous_increment = upward(thermal_bound[phase][c] - thermal_bound_prev[phase][c]);
                const double ledger_roundoff = 8 * std::numeric_limits<double>::epsilon() *
                    (std::abs(w.a1 * thermal_energy[phase][c]) + std::abs(w.a2 * thermal_energy_prev[phase][c])
                     + std::abs(dt * accepted_assembly.thermal_power_W[k][c]));
                const double increment = upward((std::abs(w.a2) * previous_increment
                    + accepted_assembly.thermal_step_residual_bound_J[k][c] + ledger_roundoff) / std::abs(w.a0)
                    * (1 + 8 * std::numeric_limits<double>::epsilon()));
                const double bound = upward(thermal_bound[phase][c] + increment);
                require(finite(next) && finite(bound), "thermal energy ledger overflow");
                thermal_energy_prev[phase][c] = thermal_energy[phase][c]; thermal_energy[phase][c] = next;
                thermal_bound_prev[phase][c] = thermal_bound[phase][c]; thermal_bound[phase][c] = bound;
            }
        }
        if (problem.electrical) {
            for (std::size_t c = 0; c < sys.nc; ++c) {
                const double next = (w.a1 * ohmic_heat[c] - w.a2 * ohmic_heat_prev[c] + dt * accepted_assembly.ohmic_power_W[c]) / w.a0;
                ohmic_heat_prev[c] = ohmic_heat[c]; ohmic_heat[c] = next;
            }
            const double next = (w.a1 * ohmic_collected - w.a2 * ohmic_collected_prev + dt * accepted_assembly.ohmic_collected_current_A) / w.a0;
            ohmic_collected_prev = ohmic_collected; ohmic_collected = next;
            result.ohmic_heating_W_m3.resize(sys.nc);
            for (std::size_t c = 0; c < sys.nc; ++c) result.ohmic_heating_W_m3[c] = accepted_assembly.ohmic_power_W[c] / sys.g.volume[c];
        }
        if (!accepted_assembly.electrons.empty()) trial.electrons = accepted_assembly.electrons;
        if (!accepted_assembly.spherical_electrons.empty()) trial.spherical_electrons = accepted_assembly.spherical_electrons;
        older = st; st = std::move(trial); previous_dt = dt;
        ++result.accepted_steps;
        result.samples.push_back(sample(sys, st, &accepted_assembly, w, iterations));
        result.samples.back().temporal_error = error;
        const double factor = problem.options.adaptive_time ? time::recommended_factor(error, w.order, true) : 1.5;
        dt = bounded_step(factor * dt);
    }
    result.success = st.time_s >= problem.options.end_time_s * (1 - 1e-12);
    if (result.message.empty()) result.message = result.success ? "completed" : "step limit";
    result.checkpoint = {st, older, previous_dt, dt, result.accepted_steps, collected, collected_prev, energy, energy_prev,
                         ohmic_heat, ohmic_heat_prev, ohmic_collected, ohmic_collected_prev,
                         thermal_energy, thermal_energy_prev, thermal_bound, thermal_bound_prev, thermal_available};
    result.thermal_energy_integrals_J = thermal_energy; result.thermal_energy_residual_bound_J = thermal_bound;
    result.ohmic_heating_J = ohmic_heat; result.ohmic_charge_collected_at_boundaries_C = ohmic_collected;
    result.state = std::move(st); result.particle_counts.assign(sys.ns, 0);
    for (std::size_t c = 0; c < sys.nc; ++c) for (std::size_t s = 0; s < sys.ns; ++s) result.particle_counts[s] += result.state.densities_m3[c * sys.ns + s] * sys.g.volume[c] * sys.phase_fraction(s, c);
    result.particles_collected_at_boundaries = std::move(collected); result.chemical_energy_integrals_J = std::move(energy);
    return result;
}

namespace {
Json spherical_state_json(const kinetics::SphericalEedfState& state) {
    return kinetics::spherical_state_to_json(state);
}
kinetics::SphericalEedfState read_spherical(const Json& value) {
    if (value.contains("representation")) return kinetics::spherical_state_from_json(value);
    require(value.at("basis") == "real_spherical_v1" && value.at("staggering") == "even_cell_odd_face_v1", "unsupported angular basis/staggering; lossy projections are forbidden");
    kinetics::SphericalEedfState state; state.grid = kinetics::eedf_grid_from_json(value.at("grid")); state.time_s = value.value("time_s", 0.); state.density_modes = value.at("density_modes").get<std::vector<double>>(); state.validate(); return state;
}
Json state_json(const State& state) {
    Json electrons = Json::array();
    for (const auto& e : state.electrons) electrons.push_back({{"time_s", e.time_s}, {"density_modes", e.density_modes}, {"grid", {{"cells", e.grid.cells}, {"max_energy_ev", e.grid.max_energy_ev}, {"power", e.grid.power}, {"legendre_terms", e.grid.legendre_terms}}}});
    Json spherical = Json::array(); for (const auto& e : state.spherical_electrons) spherical.push_back(spherical_state_json(e));
    return {{"time_s", state.time_s}, {"densities_m3", state.densities_m3}, {"potential_V", state.potential_V}, {"surface_charge_C_m2", state.surface_charge_C_m2}, {"dielectric_potential_V", state.dielectric_potential_V}, {"driven_voltage_V", state.driven_voltage_V}, {"temperature_K", state.temperature_K}, {"phase_temperatures_K", state.phase_temperatures_K}, {"photon_densities_m3", state.photon_densities_m3}, {"electrons", electrons}, {"spherical_electrons", spherical}, {"ohmic_charge_C_m3", state.ohmic_charge_C_m3}};
}
State read_state(const Json& j) {
    State state; state.time_s = j.at("time_s").get<double>(); state.densities_m3 = j.at("densities_m3").get<std::vector<double>>(); state.potential_V = j.at("potential_V").get<std::vector<double>>();
    state.surface_charge_C_m2 = j.at("surface_charge_C_m2").get<std::vector<double>>(); state.driven_voltage_V = j.at("driven_voltage_V").get<double>();
    state.dielectric_potential_V = j.value("dielectric_potential_V", std::vector<double>{});
    state.temperature_K = j.value("temperature_K", std::vector<double>{}); state.photon_densities_m3 = j.value("photon_densities_m3", std::vector<double>{});
    state.phase_temperatures_K = j.value("phase_temperatures_K", std::map<std::string, std::vector<double>>{});
    state.ohmic_charge_C_m3 = j.value("ohmic_charge_C_m3", std::vector<double>{});
    if (j.contains("electrons")) for (const auto& item : j.at("electrons")) { kinetics::EedfState e; e.time_s = item.at("time_s").get<double>(); e.grid = kinetics::eedf_grid_from_json(item.at("grid")); e.density_modes = item.at("density_modes").get<std::vector<double>>(); state.electrons.push_back(std::move(e)); }
    if (j.contains("spherical_electrons")) for (const auto& item : j.at("spherical_electrons")) state.spherical_electrons.push_back(read_spherical(item));
    require(state.electrons.empty() || state.spherical_electrons.empty(), "checkpoint cannot own two independent electron distributions");
    return state;
}
Json execution_controls(const Json& request) {
    Json controls = Json::object();
    for (const auto* section : {"solver", "execution"})
        if (request.contains(section) && request.at(section).is_object())
            for (const auto* key : {"mpi", "communicator_f"})
                if (request.at(section).contains(key)) controls[key] = request.at(section).at(key);
    return controls;
}
Json checkpoint_definition(Json request) { for (const auto* key : {"checkpoint", "time", "solver", "execution"}) request.erase(key); return request; }
Json checkpoint_json(const Checkpoint& cp, const Json& request) {
    return {{"schema_version", 3}, {"definition", checkpoint_definition(request)}, {"state", state_json(cp.state)}, {"previous_state", state_json(cp.previous_state)}, {"previous_step_s", cp.previous_step_s}, {"next_step_s", cp.next_step_s}, {"accepted_steps", cp.accepted_steps}, {"boundary_counts", cp.boundary_counts}, {"previous_boundary_counts", cp.previous_boundary_counts}, {"energy_integrals_J", cp.energy_integrals_J}, {"previous_energy_integrals_J", cp.previous_energy_integrals_J}, {"ohmic_heating_J", cp.ohmic_heating_J}, {"previous_ohmic_heating_J", cp.previous_ohmic_heating_J}, {"ohmic_boundary_charge_C", cp.ohmic_boundary_charge_C}, {"previous_ohmic_boundary_charge_C", cp.previous_ohmic_boundary_charge_C},
            {"thermal_energy_integrals_J", cp.thermal_energy_integrals_J}, {"previous_thermal_energy_integrals_J", cp.previous_thermal_energy_integrals_J},
            {"thermal_energy_residual_bound_J", cp.thermal_energy_residual_bound_J}, {"previous_thermal_energy_residual_bound_J", cp.previous_thermal_energy_residual_bound_J},
            {"thermal_energy_ledger_available", cp.thermal_energy_ledger_available}};
}
} // namespace

Problem problem_from_json(const Json& j, bool expand_initial_state) {
    require(j.is_object(), "request must be an object");
    Problem p; p.mechanism = chemistry::Mechanism::from_json(j.at("mechanism"));
    const auto& mesh = j.at("mesh");
    const std::string type = mesh.value("type", "structured");
    require(type == "structured" || type == "unstructured", "unknown mesh type");
    p.mesh.dimension = mesh.value("dimension", 2); p.mesh.axisymmetric = mesh.value("axisymmetric", false);
    if (type == "structured") { p.mesh.shape = mesh.at("shape").get<std::array<std::size_t, 3>>(); p.mesh.extent_m = mesh.at("extent_m").get<std::array<double, 3>>(); }
    else {
        p.mesh.extent_m[2] = mesh.value("depth_m", 1.0);
        p.mesh.nodes_m = mesh.at("nodes_m").get<std::vector<std::array<double, 3>>>();
        for (const auto& c : mesh.at("cells")) p.mesh.cells.push_back({c.at("type").get<std::string>(), c.at("nodes").get<std::vector<std::size_t>>()});
        for (const auto& b : mesh.at("boundary_faces")) p.mesh.boundary_faces.push_back({b.at("nodes").get<std::vector<std::size_t>>(), b.at("side").get<int>()});
    }
    const auto nc = geometry(p.mesh).volume.size(), ns = p.mechanism.species.size();
    if (j.contains("phase_fractions")) for (const auto& [phase, values] : j.at("phase_fractions").items()) { auto field = values.is_number() ? std::vector<double>{values.get<double>()} : values.get<std::vector<double>>(); require(field.size() == 1 || field.size() == nc, "phase fraction field size mismatch"); p.phase_fractions[phase] = std::move(field); }
    if (j.contains("face_reactions")) for (const auto& item : j.at("face_reactions")) p.face_reactions.push_back({item.at("reaction_id").get<std::string>(), item.value("phase_a", "gas"), item.value("phase_b", "aqueous"), item.value("electrical_work_to_phase", "")});
    if (j.contains("interface_heat_transfer")) for (const auto& item : j.at("interface_heat_transfer")) p.interface_heat_transfer.push_back({item.value("phase_a", "gas"), item.value("phase_b", "aqueous"), item.at("conductance_W_m2_K").get<double>()});
    p.transport.resize(ns); p.initial_densities_m3.assign(expand_initial_state ? nc * ns : ns, 0);
    const auto& transports = j.at("transport");
    require(transports.is_object(), "transport must map species IDs to coefficients");
    const auto& initial = j.at("initial_densities_m3");
    require(initial.is_object(), "initial_densities_m3 must map species IDs to density fields");
    for (const auto& [id, value] : transports.items()) { (void)value; (void)p.mechanism.species_index(id); }
    for (const auto& [id, value] : initial.items()) { (void)value; (void)p.mechanism.species_index(id); }
    for (std::size_t s = 0; s < ns; ++s) {
        const auto& id = p.mechanism.species[s].id;
        if (transports.contains(id)) { const auto& t = transports.at(id); p.transport[s] = {t.value("mobility_m2_V_s", 0.0), t.value("diffusion_m2_s", 0.0)}; }
        if (initial.contains(id)) {
            const auto& n = initial.at(id);
            if (n.is_number()) { if (expand_initial_state) for (std::size_t c = 0; c < nc; ++c) p.initial_densities_m3[c * ns + s] = n.get<double>(); else p.initial_densities_m3[s] = n.get<double>(); }
            else { require(n.size() == nc, "initial density field size mismatch for " + id); if (expand_initial_state) for (std::size_t c = 0; c < nc; ++c) p.initial_densities_m3[c * ns + s] = n[c].get<double>(); }
        }
        if (expand_initial_state && p.phase_fractions.contains(p.mechanism.species[s].phase)) for (std::size_t c = 0; c < nc; ++c) if (value_at(p.phase_fractions.at(p.mechanism.species[s].phase), c) == 0) p.initial_densities_m3[c * ns + s] = 0;
    }
    if (j.contains("permittivity_F_m")) {
        const auto& e = j.at("permittivity_F_m"); p.permittivity_F_m = e.is_number() ? std::vector<double>{e.get<double>()} : e.get<std::vector<double>>();
    }
    const std::array<std::string, 6> side_names{"xmin", "xmax", "ymin", "ymax", "zmin", "zmax"};
    if (j.contains("boundaries")) for (const auto& [name, value] : j.at("boundaries").items()) { (void)value; require(std::find(side_names.begin(), side_names.end(), name) != side_names.end(), "unknown boundary side: " + name); }
    if (j.contains("boundaries")) for (std::size_t k = 0; k < side_names.size(); ++k) if (j.at("boundaries").contains(side_names[k])) {
        const auto& b = j.at("boundaries").at(side_names[k]); auto& out = p.boundaries[k];
        const std::string kind = b.value("kind", "insulating");
        require(kind == "insulating" || kind == "electrode" || kind == "dielectric", "unknown boundary kind");
        out.kind = kind == "electrode" ? BoundaryKind::Electrode : kind == "dielectric" ? BoundaryKind::Dielectric : BoundaryKind::Insulating;
        out.potential_V = b.value("potential_V", 0.0); out.absorbing = b.value("absorbing", false);
        out.capacitance_F_m2 = b.value("capacitance_F_m2", 0.0); out.initial_surface_charge_C_m2 = b.value("initial_surface_charge_C_m2", 0.0);
        if (b.contains("sheaths")) for (const auto& closure : b.at("sheaths")) out.sheaths.push_back({closure.at("species").get<std::string>(), closure.value("model", "maxwellian"), closure.value("temperature_eV", 0.), closure.value("electron_temperature_eV", 0.), closure.value("transmission", 1.)});
        if (b.contains("secondary_emission")) for (const auto& emission : b.at("secondary_emission")) out.secondary_emission.push_back({emission.at("incident_species").get<std::string>(), emission.at("emitted_species").get<std::string>(), emission.at("yield").get<double>()});
        out.secondary_energy_eV = b.value("secondary_energy_eV", 0.);
        if (b.contains("electron_boundary")) { const auto& kinetic = b.at("electron_boundary"); out.kinetic_electrons = kinetic.at("kind").get<std::string>(); if (kinetic.contains("incoming")) out.incoming_electrons = read_spherical(kinetic.at("incoming")); }
    }
    if (j.contains("circuit")) {
        const auto& c = j.at("circuit"); p.circuit.enabled = true;
        const std::string side = c.value("driven_side", "xmax"); const auto at = std::find(side_names.begin(), side_names.end(), side);
        require(at != side_names.end(), "unknown circuit driven_side"); p.circuit.driven_side = static_cast<int>(at - side_names.begin());
        p.circuit.source_voltage_V = c.at("source_voltage_V").get<double>(); p.circuit.initial_voltage_V = c.value("initial_voltage_V", p.circuit.source_voltage_V);
        p.circuit.series_resistance_ohm = c.value("series_resistance_ohm", 0.0); p.circuit.external_capacitance_F = c.value("external_capacitance_F", 0.0);
    }
    if (j.contains("environment")) {
        const auto& e = j.at("environment"); p.environment.gas_temperature_K = e.value("gas_temperature_K", 300.0); p.environment.liquid_temperature_K = e.value("liquid_temperature_K", 300.0);
        p.environment.electron_temperature_eV = e.value("electron_temperature_eV", 1.0);
        if (e.contains("electron_rates")) p.environment.electron_rates = e.at("electron_rates").get<std::map<std::string, double>>();
        if (e.contains("parameters")) p.environment.parameters = e.at("parameters").get<std::map<std::string, double>>();
        if (e.contains("phase_volumes_m3")) p.environment.phase_volumes_m3 = e.at("phase_volumes_m3").get<std::map<std::string, double>>();
        if (e.contains("interface_areas_m2")) p.environment.interface_areas_m2 = e.at("interface_areas_m2").get<std::map<std::string, double>>();
    }
    const auto field = [](const Json& value) { return value.is_number() ? std::vector<double>{value.get<double>()} : value.get<std::vector<double>>(); };
    if (j.contains("electrical")) {
        const auto& e = j.at("electrical"); require(e.is_object(), "electrical must be an object");
        for (const auto& [key, value] : e.items()) { (void)value; require(key == "phase" || key == "ohmic_conductivity_S_m" || key == "initial_ohmic_charge_C_m3", "unknown electrical key: " + key); }
        Electrical model; model.phase = e.at("phase").get<std::string>();
        model.ohmic_conductivity_S_m = field(e.at("ohmic_conductivity_S_m"));
        if (e.contains("initial_ohmic_charge_C_m3")) model.initial_ohmic_charge_C_m3 = field(e.at("initial_ohmic_charge_C_m3"));
        p.electrical = std::move(model);
    }
    if (j.contains("heavy_barycentric_pair")) {
        const auto& pair = j.at("heavy_barycentric_pair"); require(pair.is_object(), "heavy_barycentric_pair must be an object");
        for (const auto& [key, value] : pair.items()) { (void)value; require(key == "neutral" || key == "ion", "unknown heavy_barycentric_pair key: " + key); }
        p.heavy_barycentric_pair = HeavyBarycentricPair{pair.at("neutral").get<std::string>(), pair.at("ion").get<std::string>()};
    }
    if (j.contains("thermal")) {
        const auto& t = j.at("thermal"); p.thermal.enabled = true;
        if (t.contains("phases")) for (const auto& [phase, values] : t.at("phases").items()) {
            Thermal::Phase model; model.heat_capacity_J_m3_K = field(values.at("heat_capacity_J_m3_K"));
            if (values.contains("conductivity_W_m_K")) model.conductivity_W_m_K = field(values.at("conductivity_W_m_K"));
            if (values.contains("initial_temperature_K")) model.initial_temperature_K = field(values.at("initial_temperature_K"));
            if (values.contains("heating_W_m3")) model.heating_W_m3 = field(values.at("heating_W_m3"));
            model.heat_reservoirs = values.value("heat_reservoirs", std::vector<std::string>{}); p.thermal.phases[phase] = std::move(model);
        }
        if (t.contains("heat_capacity_J_m3_K")) p.thermal.heat_capacity_J_m3_K = field(t.at("heat_capacity_J_m3_K"));
        if (t.contains("conductivity_W_m_K")) p.thermal.conductivity_W_m_K = field(t.at("conductivity_W_m_K"));
        if (t.contains("initial_temperature_K")) p.thermal.initial_temperature_K = field(t.at("initial_temperature_K"));
        if (t.contains("heating_W_m3")) p.thermal.heating_W_m3 = field(t.at("heating_W_m3"));
        p.thermal.heat_reservoirs = t.value("heat_reservoirs", std::vector<std::string>{}); p.thermal.joule_species = t.value("joule_species", std::vector<std::string>{});
        p.thermal.use_eedf_elastic_heating = t.value("use_eedf_elastic_heating", false);
    }
    if (j.contains("radiation")) for (const auto& item : j.at("radiation")) {
        RadiationGroup group; group.id = item.at("id").get<std::string>(); group.photon_energy_eV = item.at("photon_energy_eV").get<double>();
        group.speed_m_s = item.value("speed_m_s", 299792458.0); group.diffusion_m2_s = item.value("diffusion_m2_s", 0.0); group.absorption_m1 = item.value("absorption_m1", 0.0);
        group.absorption_m1_by_phase = item.value("absorption_m1_by_phase", std::map<std::string, double>{});
        group.energy_reservoir = item.value("energy_reservoir", "gas/radiation/" + group.id);
        if (item.contains("initial_density_m3")) group.initial_density_m3 = field(item.at("initial_density_m3"));
        if (item.contains("emission_W_m3")) group.emission_W_m3 = field(item.at("emission_W_m3"));
        if (item.contains("absorbers")) for (const auto& v : item.at("absorbers")) group.absorbers.push_back({v.at("reaction_id").get<std::string>(), v.at("cross_section_m2").get<double>()});
        if (item.contains("escaping_sides")) for (const auto& side : item.at("escaping_sides")) { const int k = side.get<int>(); require(k >= 0 && k < 6, "invalid radiation escape side"); group.escaping_sides[static_cast<std::size_t>(k)] = true; }
        p.radiation.push_back(std::move(group));
    }
    if (j.contains("electron_closure")) {
        const auto& e = j.at("electron_closure"); p.electron_mode = e.value("mode", "steady_boltzmann");
        require(p.electron_mode == "steady_boltzmann" || p.electron_mode == "local_field_table" || p.electron_mode == "transient_boltzmann" || p.electron_mode == "transient_spherical", "unknown electron_closure mode");
        p.electron_closure = kinetics::ElectronCoupling::from_json(e);
        if (!p.steady_electrons()) p.initial_electron_mean_energy_eV = e.at("initial_mean_energy_eV").get<double>();
        if (p.electron_mode == "local_field_table") {
            p.electron_table_reduced_fields_td = e.at("reduced_fields_td").get<std::vector<double>>();
            const auto& t = e.at("table_conditions");
            p.electron_table_conditions = p.electron_closure->conditions;
            p.electron_table_conditions.gas_temperature_k = t.at("gas_temperature_K").get<double>();
            p.electron_table_conditions.gas_density_m3 = t.value("gas_density_m3", p.electron_table_conditions.gas_density_m3);
            p.electron_table_conditions.fractions = t.at("fractions").get<std::map<std::string, double>>();
            p.electron_table_key = e.dump();
        }
        if (p.electron_mode == "transient_boltzmann") p.electron_field_axis = e.at("fixed_field_axis").get<std::array<double, 3>>();
    }
    if (j.contains("electron_phase_contacts")) for (const auto& item : j.at("electron_phase_contacts")) {
        KineticPhaseContact contact; const auto kind = item.at("kind").get<std::string>(); require(kind == "absorbing" || kind == "specular" || kind == "prescribed_incoming", "unknown phase contact kinetic boundary"); contact.boundary.kind = kind == "absorbing" ? kinetics::KineticWall::Absorbing : kind == "specular" ? kinetics::KineticWall::Specular : kinetics::KineticWall::PrescribedIncoming;
        if (item.contains("incoming")) contact.boundary.incoming = read_spherical(item.at("incoming"));
        contact.absorbed_species = item.value("absorbed_species", ""); contact.energy_to_phase = item.value("energy_to_phase", "");
        require(p.electron_phase_contacts.emplace(item.at("face_index").get<std::size_t>(), std::move(contact)).second, "duplicate electron phase contact face");
    }
    if (j.contains("time")) {
        const auto& t = j.at("time"); p.options.time_step_s = t.at("time_step_s").get<double>(); p.options.end_time_s = t.at("end_time_s").get<double>(); p.options.minimum_time_step_s = t.value("minimum_time_step_s", std::min(1e-18, p.options.time_step_s)); p.options.bdf2 = t.value("bdf2", true);
        p.options.adaptive_time = t.value("adaptive", true); p.options.temporal_relative_tolerance = t.value("relative_tolerance", 1e-3);
        p.options.temporal_density_tolerance_m3 = t.value("absolute_density_tolerance_m3", 1.0); p.options.temporal_temperature_tolerance_K = t.value("temperature_tolerance_K", 1e-3);
        p.options.temporal_potential_tolerance_V = t.value("potential_tolerance_V", 1e-5); p.options.temporal_surface_charge_tolerance_C_m2 = t.value("surface_charge_tolerance_C_m2", 1e-12);
    }
    if (j.contains("solver")) {
        const auto& s = j.at("solver"); p.options.threads = s.value("threads", std::size_t{1}); p.options.device = s.value("device", "cpu");
        p.options.cuda_device = s.value("cuda_device", -1);
        p.options.preconditioner = s.value("preconditioner", "auto"); p.options.linear_restart = s.value("linear_restart", 40); p.options.linear_max_iterations = s.value("linear_max_iterations", 4000);
        p.options.nonorthogonal_correction_limiter = s.value("nonorthogonal_correction_limiter", 2.0);
        p.options.linear_solver = s.value("linear_solver", std::string("krylov"));
        require(p.options.linear_solver == "krylov" || p.options.linear_solver == "direct", "solver.linear_solver must be krylov or direct");
        require(p.options.linear_solver != "direct" || backend::sparse_direct_available(), "solver.linear_solver direct needs a Raikou build with Eigen 3");
        p.options.eedf_warm_start = s.value("eedf_warm_start", true);
        p.options.relative_tolerance = s.value("relative_tolerance", 1e-8); p.options.absolute_density_tolerance_m3 = s.value("absolute_density_tolerance_m3", 1.0); p.options.potential_tolerance_V = s.value("potential_tolerance_V", 1e-8);
        p.options.maximum_newton_iterations = s.value("maximum_newton_iterations", std::size_t{30}); p.options.maximum_steps = s.value("maximum_steps", std::size_t{100000});
    }
    if (j.contains("execution")) {
        const auto& e = j.at("execution"); p.options.device = e.value("device", p.options.device); p.options.threads = e.value("threads", p.options.threads);
        p.options.cuda_device = e.value("cuda_device", p.options.cuda_device);
        p.options.preconditioner = e.value("preconditioner", p.options.preconditioner);
    }
    const auto controls = execution_controls(j);
    p.options.mpi = controls.value("mpi", false); p.options.communicator_f = controls.value("communicator_f", -1);
    require(p.options.linear_solver != "direct" || !p.options.mpi, "solver.linear_solver direct is serial; MPI solves use krylov");
    if (expand_initial_state && j.contains("checkpoint")) {
        const auto& c = j.at("checkpoint"); require(c.at("schema_version") == 1 || c.at("schema_version") == 2 || c.at("schema_version") == 3, "unsupported checkpoint version");
        require(c.at("definition") == checkpoint_definition(j), "checkpoint model definition differs from request");
        Checkpoint cp; cp.state = read_state(c.at("state")); cp.previous_state = read_state(c.at("previous_state")); cp.previous_step_s = c.at("previous_step_s").get<double>(); cp.next_step_s = c.at("next_step_s").get<double>(); cp.accepted_steps = c.at("accepted_steps").get<std::size_t>();
        cp.boundary_counts = c.at("boundary_counts").get<std::vector<double>>(); cp.previous_boundary_counts = c.at("previous_boundary_counts").get<std::vector<double>>();
        cp.energy_integrals_J = c.at("energy_integrals_J").get<std::map<std::string, double>>(); cp.previous_energy_integrals_J = c.at("previous_energy_integrals_J").get<std::map<std::string, double>>();
        cp.ohmic_heating_J = c.value("ohmic_heating_J", std::vector<double>{}); cp.previous_ohmic_heating_J = c.value("previous_ohmic_heating_J", std::vector<double>{});
        if (p.electrical) require(c.contains("ohmic_boundary_charge_C") && c.contains("previous_ohmic_boundary_charge_C"), "checkpoint lacks Ohmic charge ledger");
        cp.ohmic_boundary_charge_C = c.value("ohmic_boundary_charge_C", 0.); cp.previous_ohmic_boundary_charge_C = c.value("previous_ohmic_boundary_charge_C", 0.);
        const bool thermal_fields = c.contains("thermal_energy_integrals_J") && c.contains("previous_thermal_energy_integrals_J")
            && c.contains("thermal_energy_residual_bound_J") && c.contains("previous_thermal_energy_residual_bound_J");
        const bool legacy_unavailable = c.at("schema_version").get<int>() < 3 && p.thermal.enabled && !thermal_fields;
        cp.thermal_energy_ledger_available = c.value("thermal_energy_ledger_available", !legacy_unavailable);
        if (p.thermal.enabled && !p.options.mpi && cp.thermal_energy_ledger_available) require(c.contains("thermal_energy_integrals_J") && c.contains("previous_thermal_energy_integrals_J")
            && c.contains("thermal_energy_residual_bound_J") && c.contains("previous_thermal_energy_residual_bound_J"),
            "checkpoint lacks integrated thermal source history; it cannot be reconstructed from temperature");
        using ThermalLedger = std::map<std::string, std::vector<double>>;
        cp.thermal_energy_integrals_J = c.value("thermal_energy_integrals_J", ThermalLedger{});
        cp.previous_thermal_energy_integrals_J = c.value("previous_thermal_energy_integrals_J", ThermalLedger{});
        cp.thermal_energy_residual_bound_J = c.value("thermal_energy_residual_bound_J", ThermalLedger{});
        cp.previous_thermal_energy_residual_bound_J = c.value("previous_thermal_energy_residual_bound_J", ThermalLedger{});
        p.initial_checkpoint = std::move(cp);
    }
    return p;
}
namespace {
std::vector<double> bulk_free_charge(const System& sys, const State& state) {
    std::vector<double> charge(sys.nc, 0);
    for (std::size_t c = 0; c < sys.nc; ++c) {
        for (std::size_t s = 0; s < sys.ns; ++s)
            charge[c] += qe * sys.p.mechanism.species[s].charge * state.densities_m3[c * sys.ns + s] * sys.phase_fraction(s, c);
        if (sys.p.electrical) charge[c] += state.ohmic_charge_C_m3[c];
    }
    return charge;
}
double terminal_voltage(const Problem& p, const State& st, int side) {
    return p.circuit.enabled && side == p.circuit.driven_side ? st.driven_voltage_V : p.boundaries[static_cast<std::size_t>(side)].potential_V;
}
double terminal_charge(const System& sys, const State& st, int side) {
    double charge = sys.electrode_charge(st, side);
    if (sys.p.circuit.enabled && side == sys.p.circuit.driven_side) charge += sys.p.circuit.external_capacitance_F * st.driven_voltage_V;
    return charge;
}
double discrete_field_energy(const System& sys, const State& st) {
    const auto charge = bulk_free_charge(sys, st);
    double energy = 0;
    for (std::size_t c = 0; c < sys.nc; ++c) energy += .5 * charge[c] * st.potential_V[c] * sys.g.volume[c];
    for (const auto& wall : sys.g.walls) if (wall.surface >= 0)
        energy += .5 * st.surface_charge_C_m2[static_cast<std::size_t>(wall.surface)] * st.dielectric_potential_V[static_cast<std::size_t>(wall.surface)] * wall.area;
    for (int side = 0; side < 6; ++side) energy += .5 * terminal_voltage(sys.p, st, side) * sys.electrode_charge(st, side);
    return energy;
}
double external_energy(const Problem& p, const State& st) { return p.circuit.enabled ? .5 * p.circuit.external_capacitance_F * st.driven_voltage_V * st.driven_voltage_V : 0.; }
State project_field(const Problem& p, State state, double retained_terminal_charge) {
    const System sys(p); const auto rho = bulk_free_charge(sys, state);
    const auto at_voltage = [&](double voltage) {
        State out = state; out.driven_voltage_V = voltage;
        auto field = solve_electrostatic(p, sys, rho, state.surface_charge_C_m2, voltage);
        out.potential_V = std::move(field.potential); out.dielectric_potential_V = std::move(field.dielectric); return out;
    };
    if (!sys.circuit_unknown) return at_voltage(p.circuit.source_voltage_V);
    const auto zero = at_voltage(0), one = at_voltage(1);
    const double q0 = terminal_charge(sys, zero, p.circuit.driven_side), capacitance = terminal_charge(sys, one, p.circuit.driven_side) - q0;
    require(capacitance > 0 && finite(capacitance), "reconfigure requires positive terminal differential capacitance");
    auto out = at_voltage((retained_terminal_charge - q0) / capacitance);
    const double residual = terminal_charge(sys, out, p.circuit.driven_side) - retained_terminal_charge;
    require(std::abs(residual) <= 1e-9 * std::max(std::abs(retained_terminal_charge), std::abs(q0)) + 1e-28, "reconfigure terminal charge constraint did not converge");
    return out;
}
double source_impulse_work(const System& before, const State& a, const System& after, const State& b) {
    double work = 0;
    for (int side = 0; side < 6; ++side) {
        if (after.p.boundaries[static_cast<std::size_t>(side)].kind == BoundaryKind::Insulating) continue;
        if (after.circuit_unknown && side == after.p.circuit.driven_side) continue; // finite R cannot deliver an impulse
        work += .5 * (terminal_voltage(before.p, a, side) + terminal_voltage(after.p, b, side)) *
                (terminal_charge(after, b, side) - terminal_charge(before, a, side));
    }
    return work;
}
} // namespace

Json reconfigure_json(const Json& request) {
    require(request.is_object(), "reconfigure request must be an object");
    for (const auto& [key, value] : request.items()) { (void)value; require(key == "previous_problem" || key == "checkpoint" || key == "problem" || key == "operation", "unknown reconfigure key: " + key); }
    if (request.contains("operation")) require(request.at("operation") == "spatial.reconfigure", "reconfigure operation tag differs");
    const auto& authored_old = request.at("previous_problem"); const auto& authored_new = request.at("problem");
    require(!authored_new.contains("checkpoint"), "reconfigure problem must not contain a checkpoint");
    require(authored_old.at("mesh") == authored_new.at("mesh"), "reconfigure does not change mesh geometry or topology");
    require(authored_old.at("mechanism") == authored_new.at("mechanism"), "reconfigure cannot change the species/reaction mechanism");
    require(authored_old.value("heavy_barycentric_pair", Json{}) == authored_new.value("heavy_barycentric_pair", Json{}), "reconfigure cannot change the heavy transport reference frame");
    Json old_request = authored_old; old_request["checkpoint"] = request.at("checkpoint");
    auto old_problem = problem_from_json(old_request); auto new_problem = problem_from_json(authored_new);
    old_problem.options.end_time_s = old_problem.initial_checkpoint->state.time_s;
    require(!old_problem.options.mpi && !new_problem.options.mpi, "spatial.reconfigure currently requires serial root-rank execution");
    require(old_problem.steady_electrons() && new_problem.steady_electrons(), "transient EEDF reconfiguration requires a conservative angular-distribution remap");
    require(old_problem.radiation.empty() && new_problem.radiation.empty(), "radiation reconfiguration requires an explicit photon-state remap");
    require(old_problem.electrical.has_value() == new_problem.electrical.has_value(), "reconfigure cannot add/remove the Ohmic charge owner");
    if (old_problem.electrical) require(old_problem.electrical->phase == new_problem.electrical->phase, "reconfigure cannot change Ohmic charge ownership");
    require(old_problem.circuit.enabled == new_problem.circuit.enabled && old_problem.circuit.driven_side == new_problem.circuit.driven_side &&
            old_problem.circuit.series_resistance_ohm == new_problem.circuit.series_resistance_ohm && old_problem.circuit.external_capacitance_F == new_problem.circuit.external_capacitance_F,
            "reconfigure cannot replace the external circuit");
    for (std::size_t side = 0; side < 6; ++side)
        require(old_problem.boundaries[side].kind == new_problem.boundaries[side].kind && old_problem.boundaries[side].capacitance_F_m2 == new_problem.boundaries[side].capacitance_F_m2,
                "reconfigure cannot change boundary charge ownership or backing capacitance");
    // Validate and recover the accepted old state without advancing its clock.
    const auto old_result = solve(old_problem); require(old_result.success, "invalid old reconfigure state: " + old_result.message);
    auto initial_problem = new_problem; initial_problem.options.end_time_s = 0;
    auto fresh = solve(initial_problem); require(fresh.success, "invalid new reconfigure state: " + fresh.message);
    const System old_sys(old_problem), new_sys(new_problem); const auto& old_state = old_result.state;
    auto seed = fresh.state; seed.surface_charge_C_m2 = old_state.surface_charge_C_m2;
    for (std::size_t s = 0; s < old_sys.ns; ++s) if (old_problem.mechanism.species[s].charge != 0) {
        double a = 0, b = 0;
        for (std::size_t c = 0; c < old_sys.nc; ++c) { a += old_state.densities_m3[c * old_sys.ns + s] * old_sys.phase_fraction(s, c) * old_sys.g.volume[c]; b += seed.densities_m3[c * new_sys.ns + s] * new_sys.phase_fraction(s, c) * new_sys.g.volume[c]; }
        require(std::abs(a - b) <= 1e-10 * std::max(std::abs(a), std::abs(b)) + 1e-12, "reconfigure must conserve each charged-species inventory; use a physical source step for creation/loss");
    }
    double old_ohmic = 0, new_ohmic = 0, charge_scale = 0;
    if (new_problem.electrical) for (std::size_t c = 0; c < old_sys.nc; ++c) {
        const double a = old_state.ohmic_charge_C_m3[c] * old_sys.g.volume[c], b = seed.ohmic_charge_C_m3[c] * new_sys.g.volume[c];
        old_ohmic += a; new_ohmic += b; charge_scale += std::abs(a) + std::abs(b);
    }
    require(std::abs(new_ohmic - old_ohmic) <= 1e-10 * charge_scale + 1e-30, "reconfigure must conserve host-advected Ohmic charge");
    const double retained_charge = old_problem.circuit.enabled ? terminal_charge(old_sys, old_state, old_problem.circuit.driven_side) : 0;
    // Defined work path: charge advection at old epsilon/terminal settings, then
    // polarization at fixed advected charge, then an affine ideal-voltage switch.
    auto adv_problem = new_problem; adv_problem.permittivity_F_m = old_problem.permittivity_F_m; adv_problem.boundaries = old_problem.boundaries; adv_problem.circuit = old_problem.circuit;
    auto pol_problem = new_problem; pol_problem.boundaries = old_problem.boundaries; pol_problem.circuit = old_problem.circuit;
    const System adv_sys(adv_problem), pol_sys(pol_problem);
    const auto adv_state = project_field(adv_problem, seed, retained_charge);
    const auto pol_state = project_field(pol_problem, seed, retained_charge);
    const auto final_state = project_field(new_problem, seed, retained_charge);
    const double u0 = discrete_field_energy(old_sys, old_state), u1 = discrete_field_energy(adv_sys, adv_state), u2 = discrete_field_energy(pol_sys, pol_state), u3 = discrete_field_energy(new_sys, final_state);
    const double c0 = external_energy(old_problem, old_state), c1 = external_energy(adv_problem, adv_state), c2 = external_energy(pol_problem, pol_state), c3 = external_energy(new_problem, final_state);
    const double w1 = source_impulse_work(old_sys, old_state, adv_sys, adv_state), w2 = source_impulse_work(adv_sys, adv_state, pol_sys, pol_state), w3 = source_impulse_work(pol_sys, pol_state, new_sys, final_state);
    const double advection = u1 + c1 - u0 - c0 - w1, polarization = u2 + c2 - u1 - c1 - w2;
    Json terminal_impulses = Json::array();
    for (int side = 0; side < 6; ++side) terminal_impulses.push_back(terminal_charge(new_sys, final_state, side) - terminal_charge(old_sys, old_state, side));
    fresh.checkpoint.state = final_state; fresh.checkpoint.previous_state = final_state;
    const double source_charge = new_problem.circuit.enabled ? terminal_impulses[static_cast<std::size_t>(new_problem.circuit.driven_side)].get<double>() : 0.;
    return {{"success", true}, {"time_s", 0.}, {"potential_V", final_state.potential_V}, {"driven_voltage_V", final_state.driven_voltage_V},
        {"ohmic_charge_C_m3", final_state.ohmic_charge_C_m3}, {"checkpoint", checkpoint_json(fresh.checkpoint, authored_new)},
        {"audit", {{"energy_convention", "discrete Gauss face energy, including dielectric backing capacitance"},
            {"work_path", "charge advection at old permittivity, material polarization, affine ideal-voltage switch"},
            {"field_energy_before_J", u0}, {"field_energy_after_J", u3}, {"field_energy_change_J", u3-u0},
            {"external_capacitor_energy_change_J", c3-c0}, {"source_charge_impulse_C", source_charge}, {"terminal_charge_impulses_C", terminal_impulses},
            {"source_work_impulse_J", w1+w2+w3}, {"charge_advection_work_J", advection}, {"material_polarization_work_J", polarization},
            {"material_work_J", advection+polarization}, {"ideal_voltage_switch_work_J", w3}, {"energy_balance_residual_J", u3+c3-u2-c2-w3},
            {"ohmic_charge_before_C", old_ohmic}, {"ohmic_charge_after_C", new_ohmic}, {"joule_heat_impulse_J", 0.}, {"per_cell_material_work_available", false},
            {"host_work_convention", "positive material_work_J is work supplied by host mechanics to the electrical field; host must resolve its opposite"}}}};
}

Json solve_json(const Json& request) {
    Problem p;
    const auto control = ::raikou::detail::parse_collectively(execution_controls(request), [&](const auto&) { p = problem_from_json(request); });
    (void)control;
    const auto r = solve(p);
    Json densities = Json::object(), counts = Json::object(), collected = Json::object();
    for (std::size_t s = 0; s < p.mechanism.species.size(); ++s) {
        std::vector<double> n; for (std::size_t c = 0; c < r.state.potential_V.size(); ++c) n.push_back(r.state.densities_m3[c * p.mechanism.species.size() + s]);
        const auto& id = p.mechanism.species[s].id; densities[id] = n; counts[id] = r.particle_counts[s]; collected[id] = r.particles_collected_at_boundaries[s];
    }
    Json history = Json::array();
    for (const auto& s : r.samples) history.push_back({{"time_s", s.time_s}, {"driven_voltage_V", s.driven_voltage_V}, {"source_current_A", s.source_current_A}, {"gas_charge_C", s.gas_charge_C}, {"surface_charge_C", s.surface_charge_C}, {"field_energy_J", s.field_energy_J}, {"electric_work_W", s.electric_work_W}, {"thermal_energy_J", s.thermal_energy_J}, {"radiation_energy_J", s.radiation_energy_J}, {"electron_energy_J", s.electron_energy_J}, {"nonlinear_residual", s.nonlinear_residual}, {"temporal_error", s.temporal_error}, {"bdf_order", s.order}, {"newton_iterations", s.newton_iterations}});
    Json photons = Json::object(); for (std::size_t g = 0; g < p.radiation.size(); ++g) { std::vector<double> values; for (std::size_t c = 0; c < r.state.potential_V.size(); ++c) values.push_back(r.state.photon_densities_m3[c * p.radiation.size() + g]); photons[p.radiation[g].id] = values; }
    if (p.electrical) for (std::size_t i = 0; i < r.samples.size(); ++i) {
        history[i]["ohmic_charge_C"] = r.samples[i].ohmic_charge_C;
        history[i]["ohmic_work_W"] = r.samples[i].ohmic_work_W;
        history[i]["ohmic_terminal_current_A"] = r.samples[i].ohmic_terminal_current_A;
        history[i]["ohmic_reconstructed_work_W"] = r.samples[i].ohmic_reconstructed_work_W;
        history[i]["ohmic_work_discrepancy_W"] = r.samples[i].ohmic_work_W - r.samples[i].ohmic_reconstructed_work_W;
    }
    if (p.heavy_barycentric_pair) for (std::size_t i = 0; i < r.samples.size(); ++i) {
        history[i]["barycentric_frame_work_W"] = r.samples[i].barycentric_frame_work_W;
        history[i]["neutral_frame_particle_work_W"] = r.samples[i].neutral_frame_particle_work_W;
        history[i]["collisional_heavy_heating_W"] = r.samples[i].collisional_heavy_heating_W;
        history[i]["particle_field_minus_collisional_heating_W"] = r.samples[i].neutral_frame_particle_work_W + r.samples[i].barycentric_frame_work_W - r.samples[i].collisional_heavy_heating_W;
    }
    const std::string electron_model = !p.electron_closure ? "prescribed coefficients and electron temperature" : p.electron_mode == "transient_spherical" ? "full spherical L-squared implicit collision, electric-field acceleration and conservative spatial streaming" : p.electron_mode == "transient_boltzmann" ? "full Legendre local transient kinetic elimination, fixed field axis, zero spatial electron transport" : p.electron_mode == "local_field_table" ? "local field approximation: steady Boltzmann rates and transport tabulated in E/N once, read at each cell's E/N every nonlinear residual" : "steady Boltzmann rates and transport updated each nonlinear residual";
    return Json{
        {"success", r.success}, {"message", r.message}, {"time_s", r.state.time_s},
        {"accepted_steps", r.accepted_steps}, {"rejected_steps", r.rejected_steps},
        {"densities_m3", densities}, {"potential_V", r.state.potential_V},
        {"surface_charge_C_m2", r.state.surface_charge_C_m2}, {"temperature_K", r.state.temperature_K},
        {"ohmic_charge_C_m3", r.state.ohmic_charge_C_m3}, {"ohmic_heating_J", r.ohmic_heating_J}, {"ohmic_heating_W_m3", r.ohmic_heating_W_m3},
        {"ohmic_charge_collected_at_boundaries_C", r.ohmic_charge_collected_at_boundaries_C},
        {"thermal_energy_integrals_J", r.thermal_energy_integrals_J}, {"thermal_energy_residual_bound_J", r.thermal_energy_residual_bound_J},
        {"thermal_energy_ledger", {{"available", r.checkpoint.thermal_energy_ledger_available}, {"units", "J per physical mesh cell"},
            {"ownership", "thermal model phase name; empty key denotes common temperature"},
            {"origin", "cumulative from initialization or reconfigure; restart retains current and previous BDF histories"},
            {"unavailable_reason", r.checkpoint.thermal_energy_ledger_available ? "" : "history includes an advance on a backend without per-cell thermal source integration"},
            {"residual_bound", "accepted unscaled residual and arithmetic roundoff propagated by the absolute BDF first-difference recurrence"}}},
        {"dielectric_potential_V", r.state.dielectric_potential_V},
        {"phase_temperatures_K", r.state.phase_temperatures_K}, {"photon_densities_m3", photons},
        {"electron_states", state_json(r.state).at("electrons")}, {"particle_counts", counts},
        {"spherical_electron_states", state_json(r.state).at("spherical_electrons")},
        {"particles_collected_at_boundaries", collected}, {"chemical_energy_integrals_J", r.chemical_energy_integrals_J},
        {"history", history}, {"checkpoint", checkpoint_json(r.checkpoint, request)},
        {"model", {
            {"mesh", p.mesh.cells.empty() ? "structured finite volume" : "convex supplied-cell conservative multipoint finite volume"},
            {"transport", "Scharfetter-Gummel"},
            {"heavy_transport", p.heavy_barycentric_pair ? "equal-heavy-mass neutral-to-barycentric transform of ion, neutral counterflux and electron number flux; electron mass neglected" : "independent authored species transport"},
            {"time_integration", p.options.bdf2 ? "BDF1 startup / variable-step BDF2" : "backward Euler"},
            {"temporal_error_control", p.options.adaptive_time ? "full-step versus two-half-step defect; transactional rejection" : "fixed maximum timestep; nonlinear-failure reduction only"},
            {"electron_closure", electron_model},
            {"thermal_closure", !p.thermal.enabled ? "prescribed gas/liquid temperatures" : p.thermal.phases.empty() ? "common heavy temperature" : "separate phase temperatures with authored interface heat transfer"},
            {"radiation_transport", p.radiation.empty() ? "disabled" : "configured multigroup photon diffusion; no angular transport"},
            {"phase_geometry", p.phase_fractions.empty() ? "uniform static volume fractions" : "per-cell static material fractions and sharp interfaces"}
        }}
    };
}
} // namespace raikou::spatial
