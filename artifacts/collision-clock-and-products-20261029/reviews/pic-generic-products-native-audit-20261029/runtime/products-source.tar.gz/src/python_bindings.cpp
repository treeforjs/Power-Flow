#include "raikou/runtime.h"
#include "raikou/backend.h"
#include <pybind11/pybind11.h>
namespace py=pybind11;
PYBIND11_MODULE(_core,m) {
    m.doc()="Raikou native C++ plasma runtime";
    m.def("execute",[](const std::string& operation,const std::string& request) {
        py::gil_scoped_release release;
        return raikou::execute(operation,raikou::Json::parse(request)).dump();
    },py::arg("operation"),py::arg("request")="{}");
    m.def("capabilities",[] { return raikou::backend::capabilities_json().dump(); });
}
