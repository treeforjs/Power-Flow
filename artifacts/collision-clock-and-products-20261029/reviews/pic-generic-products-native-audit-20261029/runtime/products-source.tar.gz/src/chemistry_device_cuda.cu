#include "chemistry_device_internal.h"
#include <cuda_runtime.h>
#include <math_constants.h>
#include <algorithm>
#include <cmath>
#include <limits>
#include <stdexcept>

namespace raikou::chemistry::detail {
namespace {
constexpr unsigned threads=256;
void checked(cudaError_t status){if(status!=cudaSuccess)throw std::runtime_error(cudaGetErrorString(status));}
struct Stream {
    cudaStream_t value{};
    int device{};
    std::size_t upload{},download{},allocated{};
    explicit Stream(int requested){
        int count=0;checked(cudaGetDeviceCount(&count));if(!count)throw std::runtime_error("CUDA chemistry has no device");
        if(requested < -1||requested>=count)throw std::invalid_argument("CUDA chemistry device ordinal is unavailable");
        if(requested>=0)checked(cudaSetDevice(requested));checked(cudaGetDevice(&device));
        checked(cudaStreamCreateWithFlags(&value,cudaStreamNonBlocking));
    }
    ~Stream(){cudaSetDevice(device);cudaStreamDestroy(value);}
};
template<class T>struct Buffer {
    Stream* stream;T* data{};std::size_t length;
    Buffer(Stream& owner,std::size_t n):stream(&owner),length(n){
        if(std::max(std::size_t{1},n)>std::numeric_limits<std::size_t>::max()/sizeof(T))throw std::invalid_argument("CUDA chemistry allocation overflow");
        checked(cudaMalloc(reinterpret_cast<void**>(&data),std::max(std::size_t{1},n)*sizeof(T)));owner.allocated+=std::max(std::size_t{1},n)*sizeof(T);
    }
    Buffer(Stream& owner,const std::vector<T>& values):Buffer(owner,values.size()){
        if(length){checked(cudaMemcpyAsync(data,values.data(),length*sizeof(T),cudaMemcpyHostToDevice,owner.value));owner.upload+=length*sizeof(T);}
    }
    ~Buffer(){cudaFree(data);}
    Buffer(const Buffer&)=delete;Buffer& operator=(const Buffer&)=delete;
    std::vector<T> read(){
        std::vector<T> result(length);if(length){checked(cudaMemcpyAsync(result.data(),data,length*sizeof(T),cudaMemcpyDeviceToHost,stream->value));stream->download+=length*sizeof(T);}
        checked(cudaStreamSynchronize(stream->value));return result;
    }
};
struct Network {
    std::size_t species,reactions,phases,energies,orders;
    const int *order_offsets,*order_species,*species_phase,*energy_phase;
    const double *order_power,*stoichiometry,*energy_per_event,*coefficients,*measures,*volumes;
    const unsigned char* nonnegative;
};
struct DeviceNetwork {
    Stream stream;
    Buffer<int> order_offsets,order_species,species_phase,energy_phase;
    Buffer<double> order_power,stoichiometry,energy_per_event,coefficients,measures,volumes,initial;
    Buffer<unsigned char> nonnegative;
    Network view;
    explicit DeviceNetwork(const PackedNetwork& n):stream(n.cuda_device),order_offsets(stream,n.order_offsets),order_species(stream,n.order_species),
        species_phase(stream,n.species_phase),energy_phase(stream,n.energy_phase),order_power(stream,n.order_power),
        stoichiometry(stream,n.stoichiometry),energy_per_event(stream,n.energy_per_event_J),coefficients(stream,n.coefficients),
        measures(stream,n.measures),volumes(stream,n.volumes),initial(stream,n.densities),nonnegative(stream,n.nonnegative),
        view{n.species,n.reactions,n.phases,n.energies,n.order_species.size(),order_offsets.data,order_species.data,species_phase.data,energy_phase.data,
             order_power.data,stoichiometry.data,energy_per_event.data,coefficients.data,measures.data,volumes.data,nonnegative.data}{
        checked(cudaStreamSynchronize(stream.value));
    }
    backend::DeviceTransferMetrics metrics()const{return {stream.upload,stream.download,stream.allocated};}
};
__device__ double block_max(double value,double* scratch){
    scratch[threadIdx.x]=value;__syncthreads();
    for(unsigned stride=threads/2;stride;stride/=2){if(threadIdx.x<stride)scratch[threadIdx.x]=fmax(scratch[threadIdx.x],scratch[threadIdx.x+stride]);__syncthreads();}
    const double result=scratch[0];__syncthreads();return result;
}
__device__ double block_sum(double value,double* scratch){
    scratch[threadIdx.x]=value;__syncthreads();
    for(unsigned stride=threads/2;stride;stride/=2){if(threadIdx.x<stride)scratch[threadIdx.x]+=scratch[threadIdx.x+stride];__syncthreads();}
    const double result=scratch[0];__syncthreads();return result;
}
// All threads in one cell's block enter this routine. Rate coefficients and
// phase measures are prescribed inputs; every state-dependent product and
// derivative is computed on the device.
__device__ bool evaluate_cell(Network n,std::size_t cell,const double* y,double* rates,double* derivatives,
                             double* source,double* jacobian,double* energy,bool need_jacobian,int* invalid){
    if(threadIdx.x==0)*invalid=0;__syncthreads();
    for(std::size_t r=threadIdx.x;r<n.reactions;r+=threads){
        double value=n.coefficients[cell*n.reactions+r];
        for(int k=n.order_offsets[r];k<n.order_offsets[r+1];++k)value*=pow(y[n.order_species[k]],n.order_power[k]);
        rates[r]=value;if(!isfinite(value))atomicExch(invalid,1);
        if(need_jacobian)for(int k=n.order_offsets[r];k<n.order_offsets[r+1];++k){
            double derivative=n.coefficients[cell*n.reactions+r]*n.order_power[k];
            if(n.order_power[k]==0)derivative=0;
            else for(int j=n.order_offsets[r];j<n.order_offsets[r+1];++j){
                const double power=n.order_power[j]-(j==k?1.0:0.0);if(power!=0)derivative*=pow(y[n.order_species[j]],power);
            }
            derivatives[k]=derivative;if(!isfinite(derivative))atomicExch(invalid,1);
        }
    }
    __syncthreads();
    for(std::size_t i=threadIdx.x;i<n.species;i+=threads){
        double sum=0;const double volume=n.volumes[cell*n.phases+static_cast<std::size_t>(n.species_phase[i])];
        for(std::size_t r=0;r<n.reactions;++r){
            const double factor=n.stoichiometry[r*n.species+i]*n.measures[cell*n.reactions+r]/volume;
            sum+=factor*rates[r];
        }
        source[i]=sum;if(!isfinite(sum))atomicExch(invalid,1);
    }
    if(need_jacobian)for(std::size_t entry=threadIdx.x;entry<n.species*n.species;entry+=threads){
        const auto row=entry/n.species,column=entry%n.species;double sum=0;
        const double volume=n.volumes[cell*n.phases+static_cast<std::size_t>(n.species_phase[row])];
        for(std::size_t r=0;r<n.reactions;++r){
            const double factor=n.stoichiometry[r*n.species+row]*n.measures[cell*n.reactions+r]/volume;if(factor==0)continue;
            for(int k=n.order_offsets[r];k<n.order_offsets[r+1];++k)if(static_cast<std::size_t>(n.order_species[k])==column)sum+=factor*derivatives[k];
        }
        jacobian[entry]=sum;if(!isfinite(sum))atomicExch(invalid,1);
    }
    for(std::size_t k=threadIdx.x;k<n.energies;k+=threads){
        double sum=0;const double volume=n.volumes[cell*n.phases+static_cast<std::size_t>(n.energy_phase[k])];
        for(std::size_t r=0;r<n.reactions;++r)sum+=n.energy_per_event[r*n.energies+k]*rates[r]*n.measures[cell*n.reactions+r]/volume;
        energy[k]=sum;if(!isfinite(sum))atomicExch(invalid,1);
    }
    __syncthreads();return *invalid==0;
}
__global__ void evaluate_kernel(Network n,const double* states,double* rates,double* derivatives,double* sources,double* jacobian,double* energies,int* status){
    __shared__ int invalid;const auto cell=static_cast<std::size_t>(blockIdx.x);
    const bool valid=evaluate_cell(n,cell,states+cell*n.species,rates+cell*n.reactions,derivatives+cell*n.orders,
        sources+cell*n.species,jacobian+cell*n.species*n.species,energies+cell*n.energies,true,&invalid);
    if(threadIdx.x==0)status[cell]=valid?0:1;
}
struct Control {double norm,alpha,pivot;int invalid,pivot_row,accepted;};
struct Work {
    double *full,*half,*twice,*trial,*correction,*scale,*source,*matrix,*rates,*derivatives,*energy,*half_energy;
};
__device__ double residual_norm(Network n,const double* start,const double* y,const double* source,double dt,
                               double relative,double absolute,double* scratch){
    double result=0;for(std::size_t i=threadIdx.x;i<n.species;i+=threads){
        const double value=fabs(y[i]-start[i]-dt*source[i])/(absolute+relative*fmax(fabs(start[i]),fabs(y[i])));
        result=fmax(result,isfinite(value)?value:CUDART_INF);
    }return block_max(result,scratch);
}
__device__ bool implicit_step(Network n,std::size_t cell,const double* start,double* out,double dt,
                              double relative,double absolute,std::size_t iterations,Work w,Control* c,double* scratch){
    for(std::size_t i=threadIdx.x;i<n.species;i+=threads)out[i]=start[i];__syncthreads();
    for(std::size_t iteration=0;iteration<iterations;++iteration){
        if(!evaluate_cell(n,cell,out,w.rates,w.derivatives,w.source,w.matrix,w.energy,true,&c->invalid))return false;
        const double norm=residual_norm(n,start,out,w.source,dt,relative,absolute,scratch);
        if(norm<=0.01)return true;
        for(std::size_t i=threadIdx.x;i<n.species;i+=threads){
            w.scale[i]=absolute+relative*fmax(fabs(start[i]),fabs(out[i]));
            w.correction[i]=-(out[i]-start[i]-dt*w.source[i])/w.scale[i];
        }__syncthreads();
        for(std::size_t entry=threadIdx.x;entry<n.species*n.species;entry+=threads){
            const auto row=entry/n.species,col=entry%n.species;
            w.matrix[entry]=((row==col?1.0:0.0)-dt*w.matrix[entry])*w.scale[col]/w.scale[row];
        }__syncthreads();
        for(std::size_t column=0;column<n.species;++column){
            if(threadIdx.x==0){
                c->pivot_row=static_cast<int>(column);double largest=fabs(w.matrix[column*n.species+column]);
                for(std::size_t row=column+1;row<n.species;++row)if(fabs(w.matrix[row*n.species+column])>largest){largest=fabs(w.matrix[row*n.species+column]);c->pivot_row=static_cast<int>(row);}
                c->invalid=(!isfinite(largest)||largest<2.2250738585072014e-308)?1:0;
            }__syncthreads();if(c->invalid)return false;
            const auto pivot=static_cast<std::size_t>(c->pivot_row);
            if(pivot!=column){
                for(std::size_t j=threadIdx.x;j<n.species;j+=threads){const double value=w.matrix[column*n.species+j];w.matrix[column*n.species+j]=w.matrix[pivot*n.species+j];w.matrix[pivot*n.species+j]=value;}
                if(threadIdx.x==0){const double value=w.correction[column];w.correction[column]=w.correction[pivot];w.correction[pivot]=value;}
            }__syncthreads();
            const double diagonal=w.matrix[column*n.species+column];
            for(std::size_t entry=threadIdx.x;entry<n.species*n.species;entry+=threads){
                const auto row=entry/n.species,col=entry%n.species;
                if(row>column&&col>column)w.matrix[entry]-=(w.matrix[row*n.species+column]/diagonal)*w.matrix[column*n.species+col];
            }
            for(std::size_t row=column+1+threadIdx.x;row<n.species;row+=threads)w.correction[row]-=(w.matrix[row*n.species+column]/diagonal)*w.correction[column];
            __syncthreads();
            for(std::size_t row=column+1+threadIdx.x;row<n.species;row+=threads)w.matrix[row*n.species+column]=0;
            __syncthreads();
        }
        for(std::size_t row=n.species;row-- >0;){
            double partial=0;for(std::size_t col=row+1+threadIdx.x;col<n.species;col+=threads)partial+=w.matrix[row*n.species+col]*w.correction[col];
            const double sum=block_sum(partial,scratch);
            if(threadIdx.x==0)w.correction[row]=(w.correction[row]-sum)/w.matrix[row*n.species+row];__syncthreads();
        }
        for(std::size_t i=threadIdx.x;i<n.species;i+=threads)w.correction[i]*=w.scale[i];__syncthreads();
        if(threadIdx.x==0){c->alpha=1;c->accepted=0;}__syncthreads();
        for(unsigned search=0;search<40;++search){
            if(threadIdx.x==0)c->invalid=0;__syncthreads();
            for(std::size_t i=threadIdx.x;i<n.species;i+=threads){w.trial[i]=out[i]+c->alpha*w.correction[i];if(!isfinite(w.trial[i])||(n.nonnegative[i]&&w.trial[i]<0))atomicExch(&c->invalid,1);}
            __syncthreads();
            if(!c->invalid&&evaluate_cell(n,cell,w.trial,w.rates,w.derivatives,w.source,w.matrix,w.energy,false,&c->invalid)){
                const double trial_norm=residual_norm(n,start,w.trial,w.source,dt,relative,absolute,scratch);
                if(trial_norm<norm){for(std::size_t i=threadIdx.x;i<n.species;i+=threads)out[i]=w.trial[i];if(threadIdx.x==0)c->accepted=1;}
            }__syncthreads();if(c->accepted)break;
            if(threadIdx.x==0)c->alpha*=0.5;__syncthreads();
        }if(!c->accepted)return false;
    }return false;
}
struct Options {double relative,absolute,minimum,maximum,interval;std::size_t maximum_steps,newton;};
__global__ void attempt_kernel(Network n,double* states,CellProgress* progress,double* integrals,Work all,Options options,int* active){
    __shared__ Control control;__shared__ double scratch[threads];
    const auto cell=static_cast<std::size_t>(blockIdx.x);auto& p=progress[cell];
    if(p.code||p.time>=options.interval)return;
    if(threadIdx.x==0){
        if(p.accepted+p.rejected>=options.maximum_steps)p.code=1;
        const double remaining=options.interval-p.time;p.step=fmin(p.step,remaining);
        if(!(p.step>0)||p.time+p.step==p.time||(p.step<options.minimum&&remaining>options.minimum))p.code=2;
    }__syncthreads();if(p.code)return;
    Work w=all;
    w.full+=cell*n.species;w.half+=cell*n.species;w.twice+=cell*n.species;w.trial+=cell*n.species;
    w.correction+=cell*n.species;w.scale+=cell*n.species;w.source+=cell*n.species;w.matrix+=cell*n.species*n.species;
    w.rates+=cell*n.reactions;w.derivatives+=cell*n.orders;w.energy+=cell*n.energies;w.half_energy+=cell*n.energies;
    double* current=states+cell*n.species;
    const double dt=p.step;
    bool solved=implicit_step(n,cell,current,w.full,dt,options.relative,options.absolute,options.newton,w,&control,scratch);
    if(solved)solved=implicit_step(n,cell,current,w.half,dt*0.5,options.relative,options.absolute,options.newton,w,&control,scratch);
    if(solved){for(std::size_t k=threadIdx.x;k<n.energies;k+=threads)w.half_energy[k]=w.energy[k];__syncthreads();
        solved=implicit_step(n,cell,w.half,w.twice,dt*0.5,options.relative,options.absolute,options.newton,w,&control,scratch);}
    double error=CUDART_INF;
    if(solved){double value=0;for(std::size_t i=threadIdx.x;i<n.species;i+=threads){
        const double scaled=fabs(w.twice[i]-w.full[i])/(options.absolute+options.relative*fmax(fabs(current[i]),fabs(w.twice[i])));value=fmax(value,isfinite(scaled)?scaled:CUDART_INF);}
        error=block_max(value,scratch);
    }
    if(!solved||!isfinite(error)||error>1){
        if(threadIdx.x==0){
            ++p.rejected;
            if(p.step<=options.minimum)p.code=2;
            else p.step=fmax(options.minimum,p.step*(isfinite(error)&&error>0?fmin(0.5,fmax(0.1,0.9/sqrt(error))):0.5));
        }
    }else{
        if(threadIdx.x==0)control.invalid=0;__syncthreads();
        for(std::size_t i=threadIdx.x;i<n.species;i+=threads)current[i]=w.twice[i];
        for(std::size_t k=threadIdx.x;k<n.energies;k+=threads){integrals[cell*n.energies+k]+=0.5*dt*(w.half_energy[k]+w.energy[k]);if(!isfinite(integrals[cell*n.energies+k]))atomicExch(&control.invalid,1);}
        __syncthreads();if(threadIdx.x==0){
            if(control.invalid)p.code=3;
            else{p.time+=dt;++p.accepted;p.step=fmax(options.minimum,p.step*(error>0?fmin(2.0,fmax(0.5,0.9/sqrt(error))):2.0));if(options.maximum>0)p.step=fmin(p.step,options.maximum);}
        }
    }__syncthreads();if(threadIdx.x==0&&!p.code&&p.time<options.interval)atomicExch(active,1);
}
void launch_check(Stream& stream){checked(cudaGetLastError());checked(cudaStreamSynchronize(stream.value));}
}
PackedEvaluation evaluate_cuda_impl(const PackedNetwork& p){
    if(p.cells>std::numeric_limits<unsigned>::max())throw std::invalid_argument("CUDA chemistry cell count exceeds grid range");
    DeviceNetwork n(p);Buffer<double> rates(n.stream,p.cells*p.reactions),derivatives(n.stream,p.cells*p.order_species.size()),
        sources(n.stream,p.cells*p.species),jacobian(n.stream,p.cells*p.species*p.species),energy(n.stream,p.cells*p.energies);
    Buffer<int> status(n.stream,p.cells);
    evaluate_kernel<<<static_cast<unsigned>(p.cells),threads,0,n.stream.value>>>(n.view,n.initial.data,rates.data,derivatives.data,sources.data,jacobian.data,energy.data,status.data);
    launch_check(n.stream);const auto codes=status.read();
    if(std::any_of(codes.begin(),codes.end(),[](int code){return code!=0;}))throw std::runtime_error("nonfinite CUDA chemistry reaction or derivative");
    PackedEvaluation result;result.sources=sources.read();result.jacobians=jacobian.read();result.progress=rates.read();result.energy=energy.read();result.transfers=n.metrics();return result;
}
PackedAdvance advance_cuda_impl(const PackedNetwork& p,double interval,const AdvanceOptions& options){
    if(p.cells>std::numeric_limits<unsigned>::max())throw std::invalid_argument("CUDA chemistry cell count exceeds grid range");
    DeviceNetwork n(p);
    const auto values=p.cells*p.species;
    Buffer<double> full(n.stream,values),half(n.stream,values),twice(n.stream,values),trial(n.stream,values),
        correction(n.stream,values),scale(n.stream,values),source(n.stream,values),matrix(n.stream,values*p.species),rates(n.stream,p.cells*p.reactions),
        derivatives(n.stream,p.cells*p.order_species.size()),energy(n.stream,p.cells*p.energies),half_energy(n.stream,p.cells*p.energies),integrals(n.stream,p.cells*p.energies);
    std::vector<CellProgress> initial(p.cells);for(auto& cell:initial)cell.step=options.maximum_step_s>0?std::min(interval,options.maximum_step_s):interval;
    Buffer<CellProgress> progress(n.stream,initial);Buffer<int> active(n.stream,1),initial_status(n.stream,p.cells);
    evaluate_kernel<<<static_cast<unsigned>(p.cells),threads,0,n.stream.value>>>(n.view,n.initial.data,rates.data,derivatives.data,source.data,matrix.data,energy.data,initial_status.data);
    launch_check(n.stream);
    const auto initial_codes=initial_status.read();
    for(std::size_t cell=0;cell<p.cells;++cell)if(initial_codes[cell])initial[cell].code=3;
    // Initial validation is per-cell; one invalid cell cannot cancel valid neighbors.
    checked(cudaMemcpyAsync(progress.data,initial.data(),p.cells*sizeof(CellProgress),cudaMemcpyHostToDevice,n.stream.value));n.stream.upload+=p.cells*sizeof(CellProgress);
    if(p.energies)checked(cudaMemsetAsync(integrals.data,0,p.cells*p.energies*sizeof(double),n.stream.value));
    Work work{full.data,half.data,twice.data,trial.data,correction.data,scale.data,source.data,matrix.data,rates.data,derivatives.data,energy.data,half_energy.data};
    Options settings{options.relative_tolerance,options.absolute_tolerance_m3,options.minimum_step_s,options.maximum_step_s,interval,options.maximum_steps,options.maximum_newton_iterations};
    int pending=1;
    while(pending){
        checked(cudaMemsetAsync(active.data,0,sizeof(int),n.stream.value));
        attempt_kernel<<<static_cast<unsigned>(p.cells),threads,0,n.stream.value>>>(n.view,n.initial.data,progress.data,integrals.data,work,settings,active.data);
        checked(cudaGetLastError());checked(cudaMemcpyAsync(&pending,active.data,sizeof(int),cudaMemcpyDeviceToHost,n.stream.value));n.stream.download+=sizeof(int);checked(cudaStreamSynchronize(n.stream.value));
    }
    PackedAdvance result;result.densities=n.initial.read();result.energies=integrals.read();result.progress=progress.read();result.transfers=n.metrics();return result;
}
} // namespace raikou::chemistry::detail
