#include "raikou/electron_boltzmann.h"
#include "raikou/eedf_distributed.h"
#include "eedf_operators.h"
#include "eedf_local_assembly.h"
#include <algorithm>
#include <array>
#include <bit>
#include <cmath>
#include <cstdint>
#include <limits>
#include <numbers>
#include <sstream>
#include <stdexcept>

namespace raikou::kinetics {
namespace {
constexpr double kCharge = 1.602176634e-19;  // C
constexpr double kMass = 9.1093837015e-31;   // kg
constexpr double kEps0 = 8.8541878128e-12;   // F/m
constexpr double kBoltzmann = 1.380649e-23;  // J/K
constexpr double kTd = 1e-21;                // V m^2
const double kGamma = std::sqrt(2 * kCharge / kMass);  // m/s per sqrt(eV)

[[noreturn]] void bad(const std::string& what) { throw std::invalid_argument("EEDF: " + what); }

// A cross section linear between its points, zero below the first and constant past the last.
struct Table {
    const std::vector<double>* e{nullptr};
    const std::vector<double>* s{nullptr};
    mutable std::size_t hint{0};  // the last interval used: assembly walks energies in order
    [[nodiscard]] std::size_t interval(double x) const {  // E[k] <= x < E[k + 1], E.front() <= x < E.back()
        const auto& E = *e;
        std::size_t k = hint < E.size() - 1 ? hint : 0;
        if (E[k] <= x) {
            for (int step = 0; step < 4; ++step, ++k)
                if (x < E[k + 1]) return hint = k;
        }
        return hint = static_cast<std::size_t>(std::upper_bound(E.begin(), E.end(), x) - E.begin()) - 1;
    }
    [[nodiscard]] double at(double x) const {
        const auto& E = *e;
        const auto& S = *s;
        if (x < E.front()) return 0.0;
        if (x >= E.back()) return S.back();
        const auto k = interval(x);
        return S[k] + (S[k + 1] - S[k]) * (x - E[k]) / (E[k + 1] - E[k]);
    }
    // Exact integral of x sigma(x) over [a, b].
    [[nodiscard]] double eps_integral(double a, double b) const {
        const auto& E = *e;
        const auto& S = *s;
        if (!(b > a)) return 0.0;
        double total = 0;
        a = std::max(a, E.front());
        if (!(b > a)) return 0.0;
        if (b > E.back()) {
            const double lo = std::max(a, E.back());
            total += S.back() * (b * b - lo * lo) / 2;
            b = E.back();
            if (!(b > a)) return total;
        }
        for (auto k = interval(a); k + 1 < E.size() && E[k] < b; ++k) {
            const double lo = std::max(a, E[k]), hi = std::min(b, E[k + 1]);
            if (!(hi > lo)) continue;
            const double m = (S[k + 1] - S[k]) / (E[k + 1] - E[k]), c = S[k] - m * E[k];
            total += c * (hi * hi - lo * lo) / 2 + m * (hi * hi * hi - lo * lo * lo) / 3;
        }
        return total;
    }
};

// g_l = sigma_l / sigma_0 = Q_l(a) / Q_0(a) for the angular form 1 / (a - cos chi), a > 1.
void legendre_ratios(double a, int terms, double* g) {
    g[0] = 1;
    if (terms <= 1) return;
    if (!(a > 1) || !std::isfinite(a)) {  // a -> infinity: isotropic
        for (int l = 1; l < terms; ++l) g[l] = 0;
        return;
    }
    const double q0 = 0.5 * std::log((a + 1) / (a - 1));
    if (a - 1 < 1e-6) {  // strongly forward: Q_l = Q_0 - H_l + O((a-1) log)
        double harmonic = 0;
        for (int l = 1; l < terms; ++l) {
            harmonic += 1.0 / l;
            g[l] = std::max(0.0, 1 - harmonic / q0);
        }
        return;
    }
    // Close to 1 the forward recurrence (l+1) Q_{l+1} = (2l+1) a Q_l - l Q_{l-1} loses little
    // (to 1e-11 for a < 1.05 and l < 30); further out the ratios
    // r_l = Q_l / Q_{l-1} come from the recurrence run downward, which then starts close by.
    if (a < 1.05) {
        double qm = q0, q = a * q0 - 1;
        g[1] = q / q0;
        for (int l = 1; l + 1 < terms; ++l) {
            const double next = ((2 * l + 1) * a * q - l * qm) / (l + 1);
            qm = q;
            q = next;
            g[l + 1] = std::max(q / q0, 0.0);
        }
        return;
    }
    // The downward recurrence forgets its starting error by x^2 per step, x = a - sqrt(a^2 - 1):
    // 80 / -ln(x^2) steps take it below 1e-17.
    const double x2 = std::pow(1 / (a * (1 + std::sqrt(1 - 1 / (a * a)))), 2);
    const int start = terms + 10 + static_cast<int>(40 / -std::log(x2));
    double r[32] = {};
    double next = 0;
    for (int l = start; l >= 1; --l) {
        next = l / ((2 * l + 1) * a - (l + 1) * next);
        if (l < terms) r[l] = next;
    }
    for (int l = 1; l < terms; ++l) g[l] = g[l - 1] * r[l];
}
// The screened form whose momentum transfer ratio sigma_m / sigma_0 is `ratio`.
double screening_for(double ratio) {
    if (!(ratio < 1 - 1e-9)) return std::numeric_limits<double>::infinity();
    if (!(ratio > 1e-12)) ratio = 1e-12;
    // 1 - g_1(a) increases with a; bisect on log(a - 1).
    double lo = std::log(1e-14), hi = std::log(1e9);
    for (int it = 0; it < 200; ++it) {
        const double mid = 0.5 * (lo + hi), a = 1 + std::exp(mid);
        const double g1 = a - 1 / (0.5 * std::log((a + 1) / (a - 1)));
        ((1 - g1) < ratio ? lo : hi) = mid;
    }
    return 1 + std::exp(0.5 * (lo + hi));
}

struct Grid {
    int n{0};
    std::vector<double> e, c, h, d;   // faces, centres, cell widths, dual widths (c_k - c_{k-1}, k = 1..n-1)
    std::vector<double> m12, m32;     // integral of sqrt(e) and e^1.5 over each cell
    std::vector<double> dual_m12;     // integral of sqrt(e) over each dual cell
    std::vector<double> dual_b;       // dual partition boundaries: c_0 .. c_{n-1}
};
Grid make_grid(const EedfGrid& g) {
    if (g.cells < 16 || g.cells > 6000) bad("cells must be between 16 and 6000");
    if (!(g.max_energy_ev > 0 && std::isfinite(g.max_energy_ev))) bad("the maximum energy must be positive");
    if (!(g.power >= 1 && g.power <= 4)) bad("the grid power must be between 1 and 4");
    Grid G;
    G.n = g.cells;
    const auto n = static_cast<std::size_t>(g.cells);
    G.e.resize(n + 1);
    for (std::size_t k = 0; k <= n; ++k) G.e[k] = g.max_energy_ev * std::pow(static_cast<double>(k) / static_cast<double>(n), g.power);
    G.c.resize(n); G.h.resize(n); G.m12.resize(n); G.m32.resize(n);
    for (std::size_t i = 0; i < n; ++i) {
        G.c[i] = 0.5 * (G.e[i] + G.e[i + 1]);
        G.h[i] = G.e[i + 1] - G.e[i];
        G.m12[i] = (2.0 / 3) * (std::pow(G.e[i + 1], 1.5) - std::pow(G.e[i], 1.5));
        G.m32[i] = (2.0 / 5) * (std::pow(G.e[i + 1], 2.5) - std::pow(G.e[i], 2.5));
    }
    G.d.assign(n + 1, 0.0);
    G.dual_m12.assign(n + 1, 0.0);
    for (std::size_t k = 1; k < n; ++k) {
        G.d[k] = G.c[k] - G.c[k - 1];
        G.dual_m12[k] = (2.0 / 3) * (std::pow(G.c[k], 1.5) - std::pow(G.c[k - 1], 1.5));
    }
    G.dual_b = G.c;
    return G;
}

// One process as the solver uses it.
struct Active {
    const CollisionProcess* p{nullptr};
    double x{0};       // forward target fraction
    double xs{0};      // product fraction (superelastic)
    Table table;
    std::vector<double> loss;      // per cell: integral of e sigma (forward)
    std::vector<double> sloss;     // per cell: superelastic, w * integral over cell+u of e' sigma(e')
};

// The in-scattering of one process for one Legendre index over a partition b (m = b.size() - 1
// control volumes): electrons in source volume j at energy s land at d(s) = (s - shift) / scale,
// `mult` of them, at the rate weight(s0, s1) over a source sub-interval cut where landings cross
// volume boundaries; sink(dest, j, value). Each piece lands in the one volume holding it, so a jump
// and its superelastic reverse connect the same pair of volumes with mirrored weights, and a
// Maxwellian at the gas temperature balances them exactly (detailed balance). A jump far below
// the cell width moves the fraction u / h of the cell's electrons one cell down: on average the
// energy loss u, the continuous-approximation limit. Landings outside the partition go to its ends.
template <class Weight, class Sink>
void scatter(const std::vector<double>& b, double shift, double scale, double mult, const Weight& weight, const Sink& sink) {
    const auto m = b.size() - 1;
    const auto dest = [&](double s) { return (s - shift) / scale; };
    // Landing energies only increase with the source energy, so both searches walk forward.
    std::size_t at = 0;
    const auto volume = [&](double energy) -> std::size_t {
        if (energy <= b.front()) return 0;
        if (energy >= b.back()) return m - 1;
        while (at + 1 < m && b[at + 1] <= energy) ++at;
        return at;
    };
    std::vector<double> cuts;
    auto boundary = b.begin();
    for (std::size_t j = 0; j < m; ++j) {
        const double s0 = b[j], s1 = b[j + 1];
        const double d0 = dest(s0), d1 = dest(s1);
        if (d1 <= 0 && shift >= 0) continue;  // every landing below zero energy: no collision
        cuts.assign(1, s0);
        while (boundary != b.end() && *boundary <= d0) ++boundary;
        for (auto it = boundary; it != b.end() && *it < d1; ++it) cuts.push_back(*it * scale + shift);
        cuts.push_back(s1);
        for (std::size_t q = 0; q + 1 < cuts.size(); ++q) {
            const double lo = cuts[q], hi = cuts[q + 1];
            if (!(hi > lo)) continue;
            const double w = weight(lo, hi);
            if (w == 0) continue;
            sink(volume(dest(0.5 * (lo + hi))), j, mult * w);
        }
    }
}

// Sparse matrix in CSR form.
struct Csr {
    std::size_t n{0};
    std::vector<std::size_t> start;
    std::vector<std::uint32_t> col;
    std::vector<double> val;
};
struct Triplets {
    std::vector<std::uint64_t> key;
    std::vector<double> val;
    std::size_t first_row{0}, last_row{std::numeric_limits<std::size_t>::max()};
    void add(std::size_t r, std::size_t c, double v) {
        if (v == 0 || r < first_row || r >= last_row) return;
        key.push_back((static_cast<std::uint64_t>(r) << 32) | static_cast<std::uint64_t>(c));
        val.push_back(v);
    }
    void append(const Triplets& other) {
        key.insert(key.end(), other.key.begin(), other.key.end());
        val.insert(val.end(), other.val.begin(), other.val.end());
    }
    // Bucketed by row, then each (short) row sorted by column, duplicates summed.
    [[nodiscard]] Csr compress(std::size_t n) const {
        std::vector<std::size_t> count(n + 1, 0);
        for (const auto k : key) ++count[static_cast<std::size_t>(k >> 32) + 1];
        for (std::size_t r = 0; r < n; ++r) count[r + 1] += count[r];
        std::vector<std::pair<std::uint32_t, double>> entry(key.size());
        {
            std::vector<std::size_t> fill(count.begin(), count.end() - 1);
            for (std::size_t i = 0; i < key.size(); ++i)
                entry[fill[static_cast<std::size_t>(key[i] >> 32)]++] = {static_cast<std::uint32_t>(key[i] & 0xffffffffu), val[i]};
        }
        Csr m;
        m.n = n;
        m.start.assign(n + 1, 0);
        m.col.reserve(entry.size());
        m.val.reserve(entry.size());
        for (std::size_t r = 0; r < n; ++r) {
            const auto first = entry.begin() + static_cast<std::ptrdiff_t>(count[r]), last = entry.begin() + static_cast<std::ptrdiff_t>(count[r + 1]);
            std::sort(first, last, [](const auto& a, const auto& b) { return a.first < b.first; });
            for (auto it = first; it != last; ++it) {
                if (it != first && it->first == m.col.back()) { m.val.back() += it->second; continue; }
                m.col.push_back(it->first);
                m.val.push_back(it->second);
            }
            m.start[r + 1] = m.col.size();
        }
        return m;
    }
    [[nodiscard]] backend::DistributedCsrMatrix compress_local(backend::RowPartition partition) const {
        backend::DistributedCsrMatrix result{partition.global_rows, partition.row_begin, {0}, {}, {}};
        std::vector<std::map<backend::GlobalIndex, double>> rows(partition.local_rows);
        for (std::size_t entry = 0; entry < key.size(); ++entry) {
            const auto row = static_cast<std::size_t>(key[entry] >> 32);
            rows[row - static_cast<std::size_t>(partition.row_begin)][key[entry] & 0xffffffffu] += val[entry];
        }
        for (const auto& row : rows) {
            for (const auto& [column, value] : row) if (value != 0) { result.columns.push_back(column); result.values.push_back(value); }
            result.offsets.push_back(result.values.size());
        }
        return result;
    }
};

// Banded LU with partial pivoting (the multi-term blocks are not diagonally dominant), lower
// bandwidth w; row interchanges widen the upper band to 2w.
struct Banded {
    std::size_t n{0}, w{0};
    std::vector<double> a;  // row r, column c (r - w <= c <= r + 2w) at a[r * (3w + 1) + (c + w - r)]
    std::vector<std::size_t> pivot;
    void reset(std::size_t size, std::size_t width) {
        n = size; w = width;
        a.assign(n * (3 * w + 1), 0.0);
        pivot.assign(n, 0);
    }
    double& at(std::size_t r, std::size_t c) { return a[r * (3 * w + 1) + (c + w - r)]; }
    void factor() {
        for (std::size_t k = 0; k < n; ++k) {
            const std::size_t rmax = std::min(n - 1, k + w), cmax = std::min(n - 1, k + 2 * w);
            std::size_t best = k;
            for (std::size_t r = k + 1; r <= rmax; ++r)
                if (std::abs(at(r, k)) > std::abs(at(best, k))) best = r;
            pivot[k] = best;
            if (best != k)
                for (std::size_t c = k; c <= cmax; ++c) std::swap(at(k, c), at(best, c));
            double p = at(k, k);
            if (std::abs(p) < 1e-300) p = at(k, k) = 1e-300;
            for (std::size_t r = k + 1; r <= rmax; ++r) {
                double& l = at(r, k);
                if (l == 0) continue;
                l /= p;
                for (std::size_t c = k + 1; c <= cmax; ++c) at(r, c) -= l * at(k, c);
            }
        }
    }
    void solve(std::vector<double>& x) {
        for (std::size_t k = 0; k < n; ++k) {
            if (pivot[k] != k) std::swap(x[k], x[pivot[k]]);
            const std::size_t rmax = std::min(n - 1, k + w);
            for (std::size_t r = k + 1; r <= rmax; ++r) x[r] -= at(r, k) * x[k];
        }
        for (std::size_t r = n; r-- > 0;) {
            const std::size_t cmax = std::min(n - 1, r + 2 * w);
            for (std::size_t c = r + 1; c <= cmax; ++c) x[r] -= at(r, c) * x[c];
            x[r] /= at(r, r);
        }
    }
};

// Right-preconditioned restarted GMRES; returns the final relative residual.
template <class Apply, class Precondition>
double gmres(const Apply& apply, const Precondition& precondition, const std::vector<double>& b, std::vector<double>& x, double tol,
             int restart, int max_iterations) {
    const std::size_t n = b.size();
    const auto norm = [](const std::vector<double>& v) { double s = 0; for (double q : v) s += q * q; return std::sqrt(s); };
    const double bnorm = std::max(norm(b), 1e-300);
    // The Krylov basis grows as it is used: most solves converge in far fewer than `restart` steps.
    std::vector<std::vector<double>> V(1, std::vector<double>(n)), Z;
    V.reserve(static_cast<std::size_t>(restart) + 1); Z.reserve(static_cast<std::size_t>(restart));
    std::vector<double> H(static_cast<std::size_t>((restart + 1) * restart)), cs(static_cast<std::size_t>(restart)), sn(static_cast<std::size_t>(restart)),
        g(static_cast<std::size_t>(restart) + 1), w(n);
    const auto h = [&](int i, int j) -> double& { return H[static_cast<std::size_t>(i * restart + j)]; };
    double rel = 1;
    int done = 0;
    while (done < max_iterations) {
        apply(x, w);
        for (std::size_t i = 0; i < n; ++i) V[0][i] = b[i] - w[i];
        double beta = norm(V[0]);
        rel = beta / bnorm;
        if (rel < tol) return rel;
        for (auto& q : V[0]) q /= beta;
        std::fill(g.begin(), g.end(), 0.0);
        g[0] = beta;
        int k = 0;
        for (; k < restart && done < max_iterations; ++k, ++done) {
            const auto uk = static_cast<std::size_t>(k);
            if (Z.size() <= uk) Z.push_back(V[uk]); else Z[uk] = V[uk];
            precondition(Z[uk]);
            apply(Z[uk], w);
            for (int i = 0; i <= k; ++i) {
                const auto& v = V[static_cast<std::size_t>(i)];
                double dot = 0;
                for (std::size_t q = 0; q < n; ++q) dot += w[q] * v[q];
                h(i, k) = dot;
                for (std::size_t q = 0; q < n; ++q) w[q] -= dot * v[q];
            }
            const double hn = norm(w);
            h(k + 1, k) = hn;
            if (V.size() <= uk + 1) V.emplace_back(n);
            if (hn > 0) for (std::size_t q = 0; q < n; ++q) V[uk + 1][q] = w[q] / hn;
            for (int i = 0; i < k; ++i) {
                const double t = cs[static_cast<std::size_t>(i)] * h(i, k) + sn[static_cast<std::size_t>(i)] * h(i + 1, k);
                h(i + 1, k) = -sn[static_cast<std::size_t>(i)] * h(i, k) + cs[static_cast<std::size_t>(i)] * h(i + 1, k);
                h(i, k) = t;
            }
            const double den = std::hypot(h(k, k), h(k + 1, k));
            cs[uk] = den > 0 ? h(k, k) / den : 1;
            sn[uk] = den > 0 ? h(k + 1, k) / den : 0;
            h(k, k) = den;
            h(k + 1, k) = 0;
            g[uk + 1] = -sn[uk] * g[uk];
            g[uk] = cs[uk] * g[uk];
            rel = std::abs(g[uk + 1]) / bnorm;
            if (rel < tol || hn == 0) { ++k; ++done; break; }
        }
        // Back substitution and update.
        std::vector<double> y(static_cast<std::size_t>(k));
        for (int i = k - 1; i >= 0; --i) {
            double s = g[static_cast<std::size_t>(i)];
            for (int j = i + 1; j < k; ++j) s -= h(i, j) * y[static_cast<std::size_t>(j)];
            y[static_cast<std::size_t>(i)] = s / h(i, i);
        }
        for (int j = 0; j < k; ++j)
            for (std::size_t q = 0; q < n; ++q) x[q] += y[static_cast<std::size_t>(j)] * Z[static_cast<std::size_t>(j)][q];
        if (rel < tol) break;
    }
    apply(x, w);
    double r = 0;
    for (std::size_t i = 0; i < n; ++i) r += (b[i] - w[i]) * (b[i] - w[i]);
    return std::sqrt(r) / bnorm;
}

CollisionProcess::Group group_of(const CollisionProcess& p) {
    if (p.group != CollisionProcess::Group::Automatic) return p.group;
    if (p.threshold_ev < 0.05) return CollisionProcess::Group::Rotational;
    if (p.threshold_ev < 2) return CollisionProcess::Group::Vibrational;
    return CollisionProcess::Group::Electronic;
}

double bernoulli(double z) {  // z / (e^z - 1)
    if (std::abs(z) < 1e-6) return 1 - z / 2;
    if (z > 700) return 0.0;
    return z / std::expm1(z);
}
// Recoil and electron-electron flux between cells k-1 and k: G = W F - D F'.
struct FluxCoefficients { double lower{0}, upper{0}; };  // G = lower F_{k-1} - upper F_k
FluxCoefficients sg(double W, double D, double d) {
    if (D <= std::abs(W) * d * 1e-12) return W > 0 ? FluxCoefficients{W, 0.0} : FluxCoefficients{0.0, -W};
    const double z = W * d / D;
    return {D / d * bernoulli(-z), D / d * bernoulli(z)};
}

} // namespace

std::vector<CollisionProcess> read_lxcat(const std::string& text) {
    std::istringstream in(text);
    std::vector<CollisionProcess> out;
    std::string line;
    const auto trim = [](std::string s) {
        s.erase(0, s.find_first_not_of(" \t\r"));
        s.erase(s.find_last_not_of(" \t\r") + 1);
        return s;
    };
    while (std::getline(in, line)) {
        const auto key = trim(line);
        CollisionProcess p;
        if (key == "ELASTIC") p.kind = CollisionKind::Elastic;
        else if (key == "EFFECTIVE") p.kind = CollisionKind::Effective;
        else if (key == "EXCITATION") p.kind = CollisionKind::Excitation;
        else if (key == "IONIZATION") p.kind = CollisionKind::Ionization;
        else if (key == "ATTACHMENT") p.kind = CollisionKind::Attachment;
        else if (key == "RECOMBINATION") p.kind = CollisionKind::Recombination;
        else continue;
        std::string species;
        if (!std::getline(in, species)) bad("truncated " + key + " block");
        species = trim(species);
        const bool both = species.find("<->") != std::string::npos;
        const auto arrow = species.find(both ? "<->" : "->");
        p.target = trim(species.substr(0, arrow));
        if (arrow != std::string::npos) p.product = trim(species.substr(arrow + (both ? 3 : 2)));
        p.label = key + " " + species;
        if (p.kind != CollisionKind::Attachment && p.kind != CollisionKind::Recombination) {
            std::string param;
            if (!std::getline(in, param)) bad("truncated " + key + " block");
            std::istringstream ps(param);
            double v = 0, w = 0;
            if (!(ps >> v)) bad("missing parameter for " + p.label);
            if (p.kind == CollisionKind::Elastic || p.kind == CollisionKind::Effective) p.mass_ratio = v;
            else {
                p.threshold_ev = v;
                if (ps >> w && both) p.weight_ratio = w;
            }
        }
        // Header lines up to the first dashed line; then the table up to the next.
        bool table = false;
        while (std::getline(in, line)) {
            const auto t = trim(line);
            if (t.rfind("-----", 0) == 0) {
                if (table) break;
                table = true;
                continue;
            }
            if (!table) {
                if (t.rfind("PROCESS:", 0) == 0) p.label = trim(t.substr(8));
                continue;
            }
            std::istringstream row(t);
            double x = 0, y = 0;
            if (!(row >> x >> y)) bad("bad table row '" + t + "' in " + p.label);
            p.energy_ev.push_back(x);
            p.cross_section_m2.push_back(y);
        }
        if (p.energy_ev.size() < 2) bad("table too short in " + p.label);
        out.push_back(std::move(p));
    }
    return out;
}

namespace {
struct AzimuthalContext {
    int order{0};
    const std::vector<double>* initial_modes{nullptr};
    const std::vector<double>* isotropic_modes{nullptr};
    detail::AzimuthalStep* result{nullptr};
    bool evaluate_rhs{false};
    SwarmResult* summary{nullptr};
};
// The swarm sweep, or (with bs) the time-dependent breakdown at the source voltage's field.
std::vector<SwarmResult> solve_impl(const std::vector<CollisionProcess>& processes, const EedfConditions& cond, const std::vector<double>& fields_td,
                                    const EedfGrid& grid_spec, const BreakdownSetup* bs, BreakdownResult* br,
                                    const EedfState* initial = nullptr, double dt_s = 0, EedfStepResult* step_result = nullptr,
                                    const AzimuthalContext* azimuthal = nullptr, detail::LocalEedfAssembly* local_assembly = nullptr,
                                    SteadyEedfReuse* reuse = nullptr) {
    const bool transient = bs != nullptr;
    const Grid G = make_grid(grid_spec);
    const int L = grid_spec.legendre_terms;
    if (L < 2 || L > 30) bad("legendre_terms must be between 2 and 30");
    if (fields_td.empty()) bad("no E/N given");
    for (double td : fields_td)
        if (!(td >= 0 && std::isfinite(td))) bad("E/N must be non-negative");
    if (!(cond.gas_temperature_k >= 0 && std::isfinite(cond.gas_temperature_k))) bad("the gas temperature must be finite and non-negative");
    if (!(cond.electron_fraction >= 0 && std::isfinite(cond.electron_fraction))) bad("the electron fraction must be finite and non-negative");
    if (!(cond.gas_density_m3 > 0 && std::isfinite(cond.gas_density_m3))) bad("the gas density must be finite and positive");
    if (!std::isfinite(cond.ion_fraction) || (cond.ion_fraction < 0 && cond.ion_fraction != -1)) bad("the ion fraction must be -1 or non-negative");
    for (const auto& [target, value] : cond.fractions)
        if (!(value >= 0 && std::isfinite(value))) bad("invalid population for " + target);
    double EN = 0;  // the reduced field being solved, V m^2
    const double kT = kBoltzmann * cond.gas_temperature_k / kCharge;  // eV
    const auto n = static_cast<std::size_t>(G.n);
    const auto fraction = [&](const std::string& s) {
        const auto it = cond.fractions.find(s);
        return it == cond.fractions.end() ? 0.0 : it->second;
    };

    // Active processes and their per-cell rate integrals.
    std::vector<Active> act;
    for (const auto& p : processes) {
        if (p.energy_ev.size() != p.cross_section_m2.size() || p.energy_ev.size() < 2) bad("cross section table mismatch in " + p.label);
        if (p.target.empty()) bad("a collision process needs a target");
        if (!(p.mass_ratio >= 0 && std::isfinite(p.mass_ratio)) || !(p.threshold_ev >= 0 && std::isfinite(p.threshold_ev)) ||
            !(p.weight_ratio >= 0 && std::isfinite(p.weight_ratio))) bad("invalid process parameter in " + p.label);
        if (!p.integral_cross_section_m2.empty() && p.integral_cross_section_m2.size() != p.energy_ev.size()) bad("integral cross section table mismatch in " + p.label);
        for (std::size_t i = 0; i < p.energy_ev.size(); ++i) {
            if (!(p.energy_ev[i] >= 0 && std::isfinite(p.energy_ev[i])) ||
                !(p.cross_section_m2[i] >= 0 && std::isfinite(p.cross_section_m2[i]))) bad("invalid cross section in " + p.label);
            if (!p.integral_cross_section_m2.empty() && !(p.integral_cross_section_m2[i] >= 0 && std::isfinite(p.integral_cross_section_m2[i]))) bad("invalid integral cross section in " + p.label);
        }
        for (std::size_t i = 1; i < p.energy_ev.size(); ++i)
            if (!(p.energy_ev[i] > p.energy_ev[i - 1])) bad("energies must increase in " + p.label);
        Active a;
        a.p = &p;
        a.x = fraction(p.target);
        a.xs = (p.kind == CollisionKind::Excitation && p.weight_ratio > 0 && !p.product.empty()) ? fraction(p.product) : 0.0;
        a.table = {&p.energy_ev, &p.cross_section_m2};
        a.loss.resize(n);
        for (std::size_t i = 0; i < n; ++i) a.loss[i] = a.table.eps_integral(G.e[i], G.e[i + 1]);
        if (p.kind == CollisionKind::Excitation && p.weight_ratio > 0 && !p.product.empty()) {
            a.sloss.resize(n);
            const double u = p.threshold_ev;
            for (std::size_t i = 0; i < n; ++i) a.sloss[i] = p.weight_ratio * a.table.eps_integral(G.e[i] + u, G.e[i + 1] + u);
        }
        act.push_back(std::move(a));
    }
    if (act.empty() || std::none_of(act.begin(), act.end(), [](const Active& a) { return a.x > 0 || a.xs > 0; }))
        bad("no process has a target with a non-zero fraction");
    // In a breakdown the ions recombining are the ions made: each recombination process takes
    // its share of the positive ion density (its given fraction's share, or equal shares).
    std::vector<double> recombination_share(act.size(), 0.0);
    if (transient) {
        double given = 0, count = 0;
        for (const auto& a : act)
            if (a.p->kind == CollisionKind::Recombination) { given += a.x; ++count; }
        for (std::size_t q = 0; q < act.size(); ++q)
            if (act[q].p->kind == CollisionKind::Recombination) recombination_share[q] = given > 0 ? act[q].x / given : 1 / count;
    }

    // Elastic recoil sigma_e = sum x 2 (m/M) sigma_m(elastic part), and the elastic part of each
    // target's momentum transfer (EFFECTIVE minus that target's inelastic processes).
    std::map<std::string, std::vector<const Active*>> inelastic_of;
    for (const auto& a : act)
        if (a.p->kind != CollisionKind::Elastic && a.p->kind != CollisionKind::Effective && a.x > 0) inelastic_of[a.p->target].push_back(&a);
    const auto elastic_momentum = [&](const Active& a, double energy) {
        double s = a.table.at(energy);
        if (a.p->kind == CollisionKind::Effective)
            for (const auto* q : inelastic_of[a.p->target]) s -= q->table.at(energy);
        return std::max(s, 0.0);
    };
    const auto recoil = [&](double energy) {
        double s = 0;
        for (const auto& a : act)
            if ((a.p->kind == CollisionKind::Elastic || a.p->kind == CollisionKind::Effective) && a.x > 0)
                s += a.x * 2 * a.p->mass_ratio * elastic_momentum(a, energy);
        return s;
    };
    std::vector<double> recoil_face(n + 1, 0.0);
    for (std::size_t k = 1; k < n; ++k) recoil_face[k] = recoil(G.e[k]);

    // Unknowns: per cell i a block of the even l at cell i and the odd l at face i+1.
    const int ne = (L + 1) / 2, no = L / 2;
    const std::size_t B = static_cast<std::size_t>(ne + no), N = n * B;
    if (local_assembly && (local_assembly->partition.global_rows != N || local_assembly->partition.row_begin % B != 0 ||
        local_assembly->partition.local_rows % B != 0 || local_assembly->partition.row_begin > N ||
        local_assembly->partition.local_rows > N - local_assembly->partition.row_begin || local_assembly->azimuthal_order < 0 ||
        local_assembly->azimuthal_order >= L)) bad("local EEDF assembly requires a cell-aligned mode partition");
    const auto even = [&](int l, std::size_t i) { return i * B + static_cast<std::size_t>(l / 2); };
    const auto odd = [&](int l, std::size_t k) { return (k - 1) * B + static_cast<std::size_t>(ne + (l - 1) / 2); };  // k = 1..n-1

    // One process's collision operator for index l on the partition `part` (cells for even l,
    // the dual cells for odd l): diag(v, value) and move(dest, src, value).
    std::vector<double> gl(static_cast<std::size_t>(L));
    const auto process_operator = [&](const Active& a, int l, const std::vector<double>& part, const auto& diag, const auto& move) {
        const auto& p = *a.p;
        const std::size_t m = part.size() - 1;
        const double u = p.threshold_ev;
        const auto vol_eps_sigma = [&](std::size_t v, double shift) { return a.table.eps_integral(part[v] + shift, part[v + 1] + shift); };
        if (p.kind == CollisionKind::Elastic || p.kind == CollisionKind::Effective) {
            if (l == 0 || a.x <= 0) return;  // l = 0 recoil is the flux term
            // Elastic loss for l >= 1: sigma_0 (1 - g_l) with the elastic part of the momentum transfer
            // sigma_m = sigma_0 (1 - g_1); isotropic unless screened.
            const bool effective = p.kind == CollisionKind::Effective;
            for (std::size_t v = 0; v < m; ++v) {
                const double lo = part[v], hi = part[v + 1], mid = 0.5 * (lo + hi);
                const double total = a.table.at(mid), sm = elastic_momentum(a, mid);
                if (!(sm > 0)) continue;
                double factor = effective ? sm / total : 1.0;  // the elastic share of the tabulated value
                if (p.angular == CollisionProcess::Angular::Screened && !p.integral_cross_section_m2.empty() && l >= 2) {
                    const Table integral{&p.energy_ev, &p.integral_cross_section_m2};
                    const double s0 = std::max(integral.at(mid), sm);
                    legendre_ratios(screening_for(sm / s0), l + 1, gl.data());
                    factor *= s0 * (1 - gl[static_cast<std::size_t>(l)]) / sm;
                }
                diag(v, -kGamma * a.x * vol_eps_sigma(v, 0.0) * factor);
            }
            return;
        }
        const bool born = p.angular == CollisionProcess::Angular::BornDipole;
        if (a.x > 0) {
            for (std::size_t v = 0; v < m; ++v) diag(v, -kGamma * a.x * vol_eps_sigma(v, 0.0));
            if (p.kind == CollisionKind::Excitation && (l == 0 || born)) {
                const auto weight = [&](double lo, double hi) {
                    double w = a.table.eps_integral(lo, hi);
                    if (l > 0 && w != 0) {
                        const double s = 0.5 * (lo + hi);
                        legendre_ratios(s > u ? (2 * s - u) / (2 * std::sqrt(s * (s - u))) : 1e300, l + 1, gl.data());
                        w *= gl[static_cast<std::size_t>(l)];
                    }
                    return kGamma * a.x * w;
                };
                scatter(part, u, 1.0, 1.0, weight, move);
            } else if (p.kind == CollisionKind::Ionization && l == 0) {
                const auto weight = [&](double lo, double hi) { return kGamma * a.x * a.table.eps_integral(lo, hi); };
                if (cond.sharing == IonizationSharing::Equal) scatter(part, u, 2.0, 2.0, weight, move);
                else {
                    scatter(part, u, 1.0, 1.0, weight, move);
                    for (std::size_t v = 0; v < m; ++v) move(0, v, kGamma * a.x * vol_eps_sigma(v, 0.0));
                }
            }
        }
        // Superelastic: from the product state, up by u, sigma_s(e) e = w (e + u) sigma(e + u).
        if (a.xs > 0) {
            const double w0 = p.weight_ratio;
            for (std::size_t v = 0; v < m; ++v) diag(v, -kGamma * a.xs * w0 * vol_eps_sigma(v, u));
            if (l == 0 || born) {
                const auto weight = [&](double lo, double hi) {
                    double w = w0 * a.table.eps_integral(lo + u, hi + u);
                    if (l > 0 && w != 0) {
                        const double s = 0.5 * (lo + hi);
                        legendre_ratios(s > 0 ? (2 * s + u) / (2 * std::sqrt(s * (s + u))) : 1e300, l + 1, gl.data());
                        w *= gl[static_cast<std::size_t>(l)];
                    }
                    return kGamma * a.xs * w;
                };
                scatter(part, -u, 1.0, 1.0, weight, move);
            }
        }
    };

    // The fixed part of the operator for the harmonics P_l^m (m = 0 for the swarm and the
    // longitudinal gradient, m = 1 for the transverse gradient): collisions in every l >= m and the
    // field coupling; unknowns with l < m, and odd l at face n, are identity (padding) rows.
    struct Operator {
        Csr A;
        std::vector<bool> padding;
        std::function<std::vector<double>(std::span<const double>)> parallel_apply;
    };
    // Electron and positive ion fractions (they change during a breakdown).
    double xe_now = cond.electron_fraction, xi_now = cond.ion_fraction >= 0 ? cond.ion_fraction : cond.electron_fraction;
    // The collision part depends on neither E/N nor m, so a sweep assembles it once per l.
    std::vector<Triplets> collisions(static_cast<std::size_t>(L));
    std::vector<char> assembled(static_cast<std::size_t>(L), 0);
    const auto collisions_for = [&](int l) -> const Triplets& {
        Triplets& T = collisions[static_cast<std::size_t>(l)];
        if (assembled[static_cast<std::size_t>(l)]) return T;
        assembled[static_cast<std::size_t>(l)] = 1;
        const bool is_even = l % 2 == 0;
        const auto& part = is_even ? G.e : G.dual_b;
        const std::size_t m = part.size() - 1;
        const auto row = [&](std::size_t v) { return is_even ? even(l, v) : odd(l, v + 1); };
        if (local_assembly) {
            T.first_row = static_cast<std::size_t>(local_assembly->partition.row_begin);
            T.last_row = T.first_row + local_assembly->partition.local_rows;
            for (const auto& a : act) {
                if (a.p->kind == CollisionKind::Recombination) continue;
                process_operator(a, l, part, [&](std::size_t v, double value) { T.add(row(v), row(v), value); },
                    [&](std::size_t d, std::size_t j, double value) { T.add(row(d), row(j), value); });
            }
            return T;
        }
        // Hundreds of rotational processes land near their source: accumulate every move in a
        // dense block (or, on fine grids, the near ones in a band and the long jumps as entries).
        const bool dense = m <= 2000;
        constexpr std::size_t kBand = 8;
        const std::size_t width = dense ? m : 2 * kBand + 1;
        std::vector<double> block(m * width, 0.0);
        const auto at = [&](std::size_t d, std::size_t j) -> double* {
            if (dense) return &block[d * m + j];
            if (d + kBand >= j && j + kBand >= d) return &block[d * width + (j + kBand - d)];
            return nullptr;
        };
        for (const auto& a : act) {
            if (a.p->kind == CollisionKind::Recombination) continue;  // scales with the ion density: added per assembly
            process_operator(a, l, part, [&](std::size_t v, double value) { *at(v, v) += value; },
                             [&](std::size_t d, std::size_t j, double value) {
                                 if (double* q = at(d, j)) *q += value;
                                 else T.add(row(d), row(j), value);
                             });
        }
        for (std::size_t d = 0; d < m; ++d)
            for (std::size_t q = 0; q < width; ++q) {
                const double value = block[d * width + q];
                if (value == 0) continue;
                if (dense) T.add(row(d), row(q), value);
                else if (d + q >= kBand && d + q - kBand < m) T.add(row(d), row(d + q - kBand), value);
            }
        return T;
    };
    const auto assemble = [&](int mh) {
    Triplets T;
    if (local_assembly) {
        T.first_row = static_cast<std::size_t>(local_assembly->partition.row_begin);
        T.last_row = T.first_row + local_assembly->partition.local_rows;
    }
    for (int l = mh; l < L; ++l) {
        T.append(collisions_for(l));
        const bool is_even = l % 2 == 0;
        const auto& part = is_even ? G.e : G.dual_b;
        const std::size_t m = part.size() - 1;
        const auto row = [&](std::size_t v) { return is_even ? even(l, v) : odd(l, v + 1); };
        // Recombination: a loss in every l at the current ion density.
        for (const auto& a : act)
            if (a.p->kind == CollisionKind::Recombination && a.x > 0)
                process_operator(a, l, part, [&](std::size_t v, double value) { T.add(row(v), row(v), value); }, [](std::size_t, std::size_t, double) {});
        // Lorentz pitch-angle scattering has eigenvalue l(l+1)/2 relative to
        // the l=1 momentum-transfer rate. xi_now already includes ion charge squared.
        if (l >= 1 && xi_now > 0 && xe_now > 0) {
            // Coulomb logarithm at the temperature of a 1 eV-mean distribution is refined below by
            // the e-e update; momentum transfer uses a fixed log for the linear operator.
            const double ne_m3 = xe_now * cond.gas_density_m3, te = 1.0;
            const double debye = std::sqrt(kEps0 * te / (ne_m3 * kCharge));
            const double lnl = std::max(1.0, std::log(12 * std::numbers::pi * ne_m3 * debye * debye * debye));
            for (std::size_t v = 0; v < m; ++v) {
                const double mid = 0.5 * (part[v] + part[v + 1]);
                const double b0 = kCharge / (8 * std::numbers::pi * kEps0 * std::max(mid, 1e-6));
                const double sigma = 4 * std::numbers::pi * b0 * b0 * lnl * (0.5 * l * (l + 1));
                T.add(row(v), row(v), -kGamma * xi_now * sigma * mid * (part[v + 1] - part[v]));
            }
        }
    }
    // Field coupling, each row scaled by gamma e w: -(gamma e w)(E/N)[(l-m)/(2l-1) (F_{l-1}' - ...)
    // + (l+1+m)/(2l+3) (F_{l+1}' + ...)].
    for (int l = mh; l < L; ++l) {
        const double down = azimuthal && azimuthal->order > 0 ? (l > mh ? std::sqrt(static_cast<double>(l*l - mh*mh) / ((2*l - 1.0) * (2*l + 1.0))) : 0.0) :
            static_cast<double>(l - mh) / (2 * l - 1);
        const double up = azimuthal && azimuthal->order > 0 ? std::sqrt(static_cast<double>((l + 1)*(l + 1) - mh*mh) / ((2*l + 1.0) * (2*l + 3.0))) :
            static_cast<double>(l + 1 + mh) / (2 * l + 3);
        if (l == 0) {
            if (L > 1)
                for (std::size_t i = 0; i < n; ++i) {
                    const double s = kGamma / 3 * EN;
                    if (i + 1 < n) T.add(even(0, i), odd(1, i + 1), -s * G.e[i + 1]);
                    if (i >= 1) T.add(even(0, i), odd(1, i), s * G.e[i]);
                }
            continue;
        }
        if (l % 2 == 1) {
            for (std::size_t k = 1; k < n; ++k) {
                const double eps = G.e[k], w = G.d[k], s = -kGamma * eps * w * EN;
                // Linear interpolation from the centres k-1, k to the face.
                const double t = (eps - G.c[k - 1]) / w, lo_w = 1 - t, hi_w = t;
                const auto couple = [&](int lp, double coef, double shift) {
                    // coef * (F' + shift / e * F) for the even lp
                    T.add(odd(l, k), even(lp, k), s * coef * (1 / w + shift / eps * hi_w));
                    T.add(odd(l, k), even(lp, k - 1), s * coef * (-1 / w + shift / eps * lo_w));
                };
                if (down != 0) couple(l - 1, down, -(l - 1) / 2.0);
                if (l + 1 < L) couple(l + 1, up, (l + 2) / 2.0);
            }
        } else {
            for (std::size_t i = 0; i < n; ++i) {
                const double eps = G.c[i], w = G.h[i], s = -kGamma * eps * w * EN;
                const auto couple = [&](int lp, double coef, double shift) {
                    if (i + 1 < n) T.add(even(l, i), odd(lp, i + 1), s * coef * (1 / w + shift / eps * 0.5));
                    if (i >= 1) T.add(even(l, i), odd(lp, i), s * coef * (-1 / w + shift / eps * 0.5));
                };
                if (down != 0) couple(l - 1, down, -(l - 1) / 2.0);
                if (l + 1 < L) couple(l + 1, up, (l + 2) / 2.0);
            }
        }
    }
    if (local_assembly) {
        const auto p = local_assembly->partition;
        local_assembly->padding.assign(p.local_rows, 0);
        local_assembly->mass.assign(p.local_rows, 0);
        for (std::size_t row = 0; row < p.local_rows; ++row) {
            const auto global = static_cast<std::size_t>(p.row_begin) + row, cell = global / B, mode = global % B;
            const bool is_even = mode < static_cast<std::size_t>(ne);
            const int l = is_even ? static_cast<int>(2 * mode) : static_cast<int>(2 * (mode - static_cast<std::size_t>(ne)) + 1);
            const bool padding = l < mh || (!is_even && cell + 1 == n);
            local_assembly->padding[row] = static_cast<unsigned char>(padding);
            local_assembly->mass[row] = is_even ? G.m12[cell] : G.dual_m12[cell + 1];
            if (padding) T.add(global, global, 1);
        }
        local_assembly->collision = T.compress_local(p);
        return Operator{};
    }
    Operator op;
    op.padding.assign(N, false);
    for (int l = 1; l < L; l += 2) op.padding[(n - 1) * B + static_cast<std::size_t>(ne + (l - 1) / 2)] = true;
    for (int l = 0; l < mh; ++l) {
        if (l % 2 == 0) for (std::size_t i = 0; i < n; ++i) op.padding[even(l, i)] = true;
        else for (std::size_t k = 1; k < n; ++k) op.padding[odd(l, k)] = true;
    }
    for (std::size_t r = 0; r < N; ++r) if (op.padding[r]) T.add(r, r, 1.0);
    op.A = T.compress(N);
    if (cond.execution.mpi || cond.execution.device != "cpu" || cond.execution.threads != 1) {
        backend::CsrMatrix matrix;
        matrix.rows = N; matrix.offsets = op.A.start; matrix.values = op.A.val;
        matrix.columns.reserve(op.A.col.size());
        for (const auto column : op.A.col) matrix.columns.push_back(static_cast<int>(column));
        op.parallel_apply = backend::make_csr_operator(matrix, cond.execution);
    }
    return op;
    };
    // Each process's l = 0 energy moment per source cell, for the budget: what it adds to the
    // energy of the distribution per unit F in each cell.
    std::vector<std::vector<double>> energy_weight(act.size(), std::vector<double>(n, 0.0));
    for (std::size_t q = 0; q < act.size(); ++q) {
        const auto kind = act[q].p->kind;
        if (kind == CollisionKind::Elastic || kind == CollisionKind::Effective) continue;
        auto& w = energy_weight[q];
        Active unit = act[q];  // recombination per unit ion fraction (scaled by it in the budget)
        if (kind == CollisionKind::Recombination) unit.x = 1;
        process_operator(unit, 0, G.e, [&](std::size_t v, double value) { w[v] += G.c[v] * value; },
                         [&](std::size_t d, std::size_t j, double value) { w[j] += G.c[d] * value; });
    }
    if (local_assembly) {
        EN = fields_td.front() * kTd;
        (void)assemble(local_assembly->azimuthal_order);
        local_assembly->faces = G.e; local_assembly->centres = G.c; local_assembly->widths = G.h;
        local_assembly->dual_widths = G.d; local_assembly->m12 = G.m12; local_assembly->m32 = G.m32;
        local_assembly->dual_m12 = G.dual_m12; local_assembly->recoil_face = recoil_face;
        const auto first = static_cast<std::size_t>(local_assembly->partition.row_begin) / B;
        const auto count = local_assembly->partition.local_rows / B;
        local_assembly->momentum.assign(count, 0);
        for (std::size_t q = 0; q < act.size(); ++q) {
            const auto& a = act[q];
            detail::EedfProcessQuadrature weights; weights.process = q; weights.target_fraction = a.x; weights.product_fraction = a.xs;
            for (std::size_t i = first; i < first + count; ++i) {
                weights.loss.push_back(a.loss[i]);
                weights.superelastic_loss.push_back(a.sloss.empty() ? 0 : a.sloss[i]);
                weights.energy_change.push_back(energy_weight[q][i]);
                const double e = G.c[i];
                double momentum = 0;
                if (a.x > 0) momentum += a.x * (a.p->kind == CollisionKind::Elastic || a.p->kind == CollisionKind::Effective ? elastic_momentum(a, e) : a.table.at(e));
                if (a.xs > 0) momentum += a.xs * a.p->weight_ratio * (e + a.p->threshold_ev) / e * a.table.at(e + a.p->threshold_ev);
                local_assembly->momentum[i - first] += momentum;
            }
            local_assembly->processes.push_back(std::move(weights));
        }
        return {};
    }
    std::vector<SwarmResult> results;
    std::vector<double> x;
    for (const double field_td : fields_td) {
    EN = field_td * kTd;
    Operator swarm_op = assemble(azimuthal ? azimuthal->order : 0);
    const Csr& A = swarm_op.A;

    // Growth weights: integral of sqrt(e) over each unknown's control volume (gamma e w rows).
    std::vector<double> growth_w(N, 0.0);
    for (std::size_t i = 0; i < n; ++i)
        for (int l = 0; l < L; l += 2) growth_w[even(l, i)] = G.m12[i];
    for (std::size_t k = 1; k < n; ++k)
        for (int l = 1; l < L; l += 2) growth_w[odd(l, k)] = G.dual_m12[k];

    // Initial state: the previous field's solution, or a Maxwellian of mean energy max(1.5 kT, 1 eV).
    std::vector<double> x_old;
    if (x.empty()) {
        x.assign(N, 0.0);
        const double te = std::max(kT, 2.0 / 3);
        double norm = 0;
        for (std::size_t i = 0; i < n; ++i) { x[even(0, i)] = std::exp(-G.c[i] / te); norm += x[even(0, i)] * G.m12[i]; }
        for (std::size_t i = 0; i < n; ++i) x[even(0, i)] /= norm;
    }
    if (initial) {
        x = initial->density_modes;
        const double density = initial->electron_density_m3();
        for (auto& value : x) value /= density;
    }
    if (azimuthal) x = *azimuthal->isotropic_modes;
    // A steady solve can continue from a converged distribution (SteadyEedfReuse).
    const bool continued = reuse && reuse->modes.size() == N && results.empty();
    if (continued) x = reuse->modes;

    const double& xe = xe_now;
    // Diagonal entries of the fixed operator, and the field's effective energy diffusion at each
    // face, (gamma / 3)(E/N)^2 e / sigma_total, read from the l = 1 rows.
    const auto diagonal = [&](std::size_t r) {
        for (std::size_t q = A.start[r]; q < A.start[r + 1]; ++q)
            if (A.col[q] == r) return std::abs(A.val[q]);
        return 0.0;
    };
    std::vector<double> field_diffusion(n + 1, 0.0);
    const auto refresh_field_diffusion = [&] {
        if (L > 1)
            for (std::size_t k = 1; k < n; ++k)
                field_diffusion[k] = (kGamma / 3 * EN * G.e[k]) * (kGamma * G.e[k] * G.d[k] * EN) / std::max(diagonal(odd(1, k)), 1e-300);
    };
    refresh_field_diffusion();
    std::vector<FluxCoefficients> flux(n + 1);  // elastic recoil: G = lower F_{k-1} - upper F_k
    // Electron-electron collisions in the symmetric Landau form of the Rosenbluth flux,
    //   G(e) = 2 a x_e  integral du min(u, e)^1.5 [F(e) F'(u) - F(u) F'(e)],
    // equal to -3 a x_e I_0 F - 2 a x_e (I_1 + e^1.5 J_1) F'. On the faces, with any face value
    // F~ used in both places, the sum of d_k G_k vanishes exactly: electron-electron collisions
    // exchange energy and never create or destroy it. F~ is upwinded as Scharfetter-Gummel would
    // with the previous iterate's drift and diffusion. The flux is bilinear, so Newton is exact.
    double a_ee = 0;
    std::vector<double> theta(n + 1, 0.5), s_slope(n + 1, 0.0), s_value(n + 1, 0.0), face_value(n + 1, 0.0), slope(n + 1, 0.0);
    // S(X)_k = sum over faces q of min(e_q, e_k)^1.5 X_q d_q.
    std::vector<double> e15(n + 1);
    for (std::size_t k = 0; k <= n; ++k) e15[k] = std::pow(G.e[k], 1.5);
    const auto landau_sum = [&](const std::vector<double>& X, std::vector<double>& S) {
        double below = 0, above = 0;
        for (std::size_t q = 1; q < n; ++q) above += X[q] * G.d[q];
        for (std::size_t k = 1; k < n; ++k) {
            S[k] = below + e15[k] * above;
            below += e15[k] * X[k] * G.d[k];
            above -= X[k] * G.d[k];
        }
    };
    const auto faces = [&](const std::vector<double>& v, std::vector<double>& value, std::vector<double>& d) {
        for (std::size_t k = 1; k < n; ++k) {
            value[k] = theta[k] * v[even(0, k - 1)] + (1 - theta[k]) * v[even(0, k)];
            d[k] = (v[even(0, k)] - v[even(0, k - 1)]) / G.d[k];
        }
    };
    // Face values are upwinded as Scharfetter-Gummel would for the total drift (recoil and
    // electron-electron) against the total diffusion (thermal recoil, the field and
    // electron-electron), so they are central, and second order, wherever diffusion dominates.
    const auto update_faces = [&](const std::vector<double>& s) {
        a_ee = 0;
        if (xe > 0) {
            double mean = 0, norm = 0;
            for (std::size_t i = 0; i < n; ++i) {
                mean += std::max(s[even(0, i)], 0.0) * G.m32[i];
                norm += std::max(s[even(0, i)], 0.0) * G.m12[i];
            }
            const double te = std::max(2.0 / 3 * mean / std::max(norm, 1e-300), 1e-3), ne_m3 = xe * cond.gas_density_m3;
            const double debye = std::sqrt(kEps0 * te / (ne_m3 * kCharge));
            const double lnl = std::max(1.0, std::log(12 * std::numbers::pi * ne_m3 * debye * debye * debye));
            a_ee = 2 * xe * kCharge * kCharge * kGamma * lnl / (24 * std::numbers::pi * kEps0 * kEps0);
            faces(s, face_value, slope);
            landau_sum(slope, s_slope);
            landau_sum(face_value, s_value);
        }
        for (std::size_t k = 1; k < n; ++k) {
            const double eps = G.e[k];
            const double Wr = -kGamma * eps * eps * recoil_face[k], Dr = kGamma * kT * eps * eps * recoil_face[k];
            const double W = Wr + a_ee * s_slope[k], D = std::max(Dr + field_diffusion[k] + std::max(a_ee * s_value[k], 0.0), 1e-300);
            const auto c = sg(W, D, G.d[k]);
            theta[k] = std::abs(W) * G.d[k] > 1e-8 * D ? std::clamp((c.lower - D / G.d[k]) / W, 0.0, 1.0) : 0.5;
            flux[k] = {Wr * theta[k] + Dr / G.d[k], Dr / G.d[k] - Wr * (1 - theta[k])};
        }
        if (a_ee > 0) {
            faces(s, face_value, slope);
            landau_sum(slope, s_slope);
            landau_sum(face_value, s_value);
        }
    };
    // Adds to r the linearised flux divergence at v: G(F, v) + G(v, F); with v = F it is 2 G(F).
    std::vector<double> v_value(n + 1, 0.0), v_slope(n + 1, 0.0), sv_value(n + 1, 0.0), sv_slope(n + 1, 0.0);
    const auto ee_apply = [&](const std::vector<double>& v, std::vector<double>& r, double scale) {
        if (!(a_ee > 0)) return;
        faces(v, v_value, v_slope);
        landau_sum(v_value, sv_value);
        landau_sum(v_slope, sv_slope);
        for (std::size_t k = 1; k < n; ++k) {
            const double g = scale * a_ee * (v_value[k] * s_slope[k] - v_slope[k] * s_value[k] + face_value[k] * sv_slope[k] - slope[k] * sv_value[k]);
            r[even(0, k - 1)] += g;
            r[even(0, k)] -= g;
        }
    };

    const auto rates = [&](const std::vector<double>& s, const Active& a, bool super) {
        const auto& w = super ? a.sloss : a.loss;
        double r = 0;
        for (std::size_t i = 0; i < n; ++i) r += w[i] * s[even(0, i)];
        return kGamma * r;
    };
    const auto net_growth = [&](const std::vector<double>& s) {
        if (!cond.temporal_growth) return 0.0;
        double nu = 0;
        for (const auto& a : act) {
            if (a.x <= 0) continue;
            if (a.p->kind == CollisionKind::Ionization) nu += a.x * rates(s, a, false);
            else if (a.p->kind == CollisionKind::Attachment || a.p->kind == CollisionKind::Recombination) nu -= a.x * rates(s, a, false);
        }
        return nu;
    };

    double nu = net_growth(x);
    update_faces(x);
    // K = P/dtau - (A + flux + growth); apply and the banded preconditioner. The pseudo time step
    // starts at the fastest l = 0 relaxation (collisions, recoil and the field's effective energy
    // diffusion) and grows to many times the slowest.
    double tau_scale = 0;
    {
        double worst = 0;
        for (std::size_t i = 0; i < n; ++i) {
            double rate = diagonal(even(0, i));
            for (std::size_t k : {i, i + 1})
                if (k >= 1 && k < n) rate += flux[k].lower + flux[k].upper + field_diffusion[k] / G.d[k];
            worst = std::max(worst, rate / G.m12[i]);
        }
        tau_scale = worst > 0 ? 1 / worst : 1.0;
    }
    // r = K v for an operator: the fixed part, growth, and for m = 0 the l = 0 recoil and the
    // linearised electron-electron fluxes; plus the pseudo-time term on the l = 0 rows.
    const auto apply_op = [&](const Operator& op, bool l0, double inv_dtau, const std::vector<double>& v, std::vector<double>& r) {
        std::vector<double> product;
        if (op.parallel_apply) product = op.parallel_apply(v);
        for (std::size_t row = 0; row < N; ++row) {
            double s = 0;
            if (op.parallel_apply) s = product[row];
            else for (std::size_t q = op.A.start[row]; q < op.A.start[row + 1]; ++q) s += op.A.val[q] * v[op.A.col[q]];
            r[row] = op.padding[row] ? s : -s + nu * growth_w[row] * v[row];
        }
        if (!l0) return;
        for (std::size_t i = 0; i < n; ++i) {
            const auto row = even(0, i);
            double g = 0;  // K gets +(G_{i+1} - G_i)
            if (i + 1 < n) g += flux[i + 1].lower * v[even(0, i)] - flux[i + 1].upper * v[even(0, i + 1)];
            if (i >= 1) g -= flux[i].lower * v[even(0, i - 1)] - flux[i].upper * v[even(0, i)];
            r[row] += g + inv_dtau * G.m12[i] * v[row];
        }
        ee_apply(v, r, 1.0);
    };
    // Certify the actual linear solve by normwise backward error using an absolute-operator
    // bound. Inverse iteration's
    // RHS vanishes with the pseudo-time shift, making an RHS-relative residual ill-scaled
    // near the null eigenvector even for a solution accurate to machine precision.
    const auto linear_backward_error = [&](const Operator& op, bool l0, double inv_dtau,
                                           const std::vector<double>& rhs, const std::vector<double>& solution) {
        std::vector<double> applied(N), bound(N, 0.0);
        apply_op(op, l0, inv_dtau, solution, applied);
        for (std::size_t row = 0; row < N; ++row) {
            bound[row] = std::abs(rhs[row]);
            for (std::size_t q = op.A.start[row]; q < op.A.start[row + 1]; ++q)
                bound[row] += std::abs(op.A.val[q] * solution[op.A.col[q]]);
            if (!op.padding[row]) bound[row] += std::abs(nu * growth_w[row] * solution[row]);
        }
        if (l0) {
            for (std::size_t i = 0; i < n; ++i) bound[even(0, i)] += std::abs(inv_dtau * G.m12[i] * solution[even(0, i)]);
            std::vector<double> values(n + 1, 0.0), slopes(n + 1, 0.0), sum_values(n + 1, 0.0), sum_slopes(n + 1, 0.0);
            for (std::size_t k = 1; k < n; ++k) {
                const double lower = std::abs(solution[even(0, k - 1)]), upper = std::abs(solution[even(0, k)]);
                const double recoil_bound = std::abs(flux[k].lower) * lower + std::abs(flux[k].upper) * upper;
                bound[even(0, k - 1)] += recoil_bound;
                bound[even(0, k)] += recoil_bound;
                values[k] = std::abs(theta[k]) * lower + std::abs(1 - theta[k]) * upper;
                slopes[k] = (lower + upper) / G.d[k];
            }
            if (a_ee > 0) {
                landau_sum(values, sum_values);
                landau_sum(slopes, sum_slopes);
                for (std::size_t k = 1; k < n; ++k) {
                    const double ee_bound = a_ee * (values[k] * std::abs(s_slope[k]) + slopes[k] * std::abs(s_value[k]) +
                        std::abs(face_value[k]) * sum_slopes[k] + std::abs(slope[k]) * sum_values[k]);
                    bound[even(0, k - 1)] += ee_bound;
                    bound[even(0, k)] += ee_bound;
                }
            }
        }
        double residual = 0, scale = 0;
        for (std::size_t row = 0; row < N; ++row) {
            residual = std::max(residual, std::abs(applied[row] - rhs[row]));
            scale = std::max(scale, bound[row]);
        }
        return residual / std::max(scale, 1e-300);
    };
    // Its banded part, factored.
    const std::size_t bw = std::min<std::size_t>(N - 1, 3 * B + 2);
    const auto precondition_op = [&](const Operator& op, bool l0, double inv_dtau, Banded& P) {
        P.reset(N, bw);
        for (std::size_t row = 0; row < N; ++row) {
            for (std::size_t q = op.A.start[row]; q < op.A.start[row + 1]; ++q) {
                const std::size_t c = op.A.col[q];
                if ((c > row ? c - row : row - c) <= bw) P.at(row, c) += op.padding[row] ? op.A.val[q] : -op.A.val[q];
            }
            if (!op.padding[row]) P.at(row, row) += nu * growth_w[row];
        }
        if (l0) {
            for (std::size_t i = 0; i < n; ++i) {
                const auto row = even(0, i);
                if (i + 1 < n) { P.at(row, row) += flux[i + 1].lower; P.at(row, even(0, i + 1)) -= flux[i + 1].upper; }
                if (i >= 1) { P.at(row, even(0, i - 1)) -= flux[i].lower; P.at(row, row) += flux[i].upper; }
                P.at(row, row) += inv_dtau * G.m12[i];
            }
            if (a_ee > 0)  // the frozen-coefficient (local) part of the electron-electron flux
                for (std::size_t k = 1; k < n; ++k) {
                    const double lower = a_ee * (theta[k] * s_slope[k] + s_value[k] / G.d[k]);
                    const double upper = a_ee * ((1 - theta[k]) * s_slope[k] - s_value[k] / G.d[k]);
                    const auto r0 = even(0, k - 1), r1 = even(0, k);
                    P.at(r0, r0) += lower; P.at(r0, r1) += upper;
                    P.at(r1, r0) -= lower; P.at(r1, r1) -= upper;
                }
        }
        P.factor();
    };

    // Results and the energy budget for the distribution x (normalised) at the current field.
    std::vector<double> momentum_cells;
    // For the budget alone (each accepted transient step): the per-cell weights summed over the
    // processes of each channel once, so a step costs one pass per channel rather than per process.
    enum WeightChannel { kRotW, kVibW, kElecW, kIonW, kAttW, kSuperW, kIonRateW, kAttRateW, kChannelsW };
    std::vector<std::vector<double>> channel_weight;
    const auto summarize = [&](SwarmResult& out, bool per_process = true) {
        // Results.
        out.energy_ev = G.c;
        out.eepf.resize(n);
        for (std::size_t i = 0; i < n; ++i) out.eepf[i] = x[even(0, i)];
        for (std::size_t i = 0; i < n; ++i) out.mean_energy_ev += x[even(0, i)] * G.m32[i];
        double w = 0;
        for (std::size_t k = 1; k < n; ++k) w += G.e[k] * x[odd(1, k)] * G.d[k];
        w *= kGamma / 3;
        out.drift_velocity_m_s = w;
        out.mobility_n = EN > 0 ? w / EN : 0.0;
        {
            // Two-term-style flux diffusion from the l = 1 momentum transfer (an estimate beyond two terms).
            // The momentum transfer summed over processes depends only on the grid: tabulated once,
            // with recombination (whose ion fraction can change between calls) added each time.
            const auto momentum = [&](const Active& a, double e) {
                double sm = 0;
                if (a.x > 0) sm += a.x * (a.p->kind == CollisionKind::Elastic || a.p->kind == CollisionKind::Effective ? elastic_momentum(a, e) : a.table.at(e));
                if (a.xs > 0) sm += a.xs * a.p->weight_ratio * (e + a.p->threshold_ev) / e * a.table.at(e + a.p->threshold_ev);
                return sm;
            };
            if (momentum_cells.empty()) {
                momentum_cells.assign(n, 0.0);
                for (const auto& a : act)
                    if (a.p->kind != CollisionKind::Recombination)
                        for (std::size_t i = 0; i < n; ++i) momentum_cells[i] += momentum(a, G.c[i]);
            }
            double dn = 0;
            for (std::size_t i = 0; i < n; ++i) {
                double sm = momentum_cells[i];
                for (const auto& a : act)
                    if (a.p->kind == CollisionKind::Recombination) sm += momentum(a, G.c[i]);
                sm += nu / (kGamma * std::sqrt(G.c[i]));
                if (sm > 0) dn += G.c[i] / sm * x[even(0, i)] * G.h[i];
            }
            out.diffusion_n = kGamma / 3 * dn;
        }
        out.net_rate_m3_s = nu;

        // Energy budget from the discrete operator: each channel's energy moment.
        EnergyBudget& bud = out.budget;
        std::vector<double> f0(n);
        for (std::size_t i = 0; i < n; ++i) f0[i] = x[even(0, i)];
        for (std::size_t k = 1; k < n; ++k) bud.field += kGamma / 3 * EN * G.e[k] * x[odd(1, k)] * G.d[k];
        {
            // Recoil, and electron-electron exchange (zero to rounding by construction).
            double rec = 0, ee = 0;
            for (std::size_t k = 1; k < n; ++k) {
                rec += (flux[k].lower * f0[k - 1] - flux[k].upper * f0[k]) * G.d[k];
                if (a_ee > 0) ee += a_ee * (face_value[k] * s_slope[k] - slope[k] * s_value[k]) * G.d[k];
            }
            bud.elastic = -rec;
            bud.electron_electron = -ee;
        }
        double gross = 0;
        if (!per_process) {
            if (channel_weight.empty()) {
                channel_weight.assign(kChannelsW, std::vector<double>(n, 0.0));
                for (const auto& a : act) {
                    const auto& p = *a.p;
                    if (p.kind == CollisionKind::Elastic || p.kind == CollisionKind::Effective || p.kind == CollisionKind::Recombination) continue;
                    const auto& weight = energy_weight[static_cast<std::size_t>(&a - act.data())];
                    int c = kElecW;
                    if (p.kind == CollisionKind::Attachment) c = kAttW;
                    else if (p.kind == CollisionKind::Ionization) c = kIonW;
                    else if (group_of(p) == CollisionProcess::Group::Rotational) c = kRotW;
                    else if (group_of(p) == CollisionProcess::Group::Vibrational) c = kVibW;
                    for (std::size_t i = 0; i < n; ++i) {
                        channel_weight[static_cast<std::size_t>(c)][i] -= weight[i];
                        if (p.kind == CollisionKind::Excitation && a.xs > 0) channel_weight[kSuperW][i] += p.threshold_ev * a.xs * kGamma * a.sloss[i];
                        if (p.kind == CollisionKind::Ionization && a.x > 0) channel_weight[kIonRateW][i] += a.x * kGamma * a.loss[i];
                        if (p.kind == CollisionKind::Attachment && a.x > 0) channel_weight[kAttRateW][i] += a.x * kGamma * a.loss[i];
                    }
                }
            }
            std::array<double, kChannelsW> sum{};
            for (std::size_t c = 0; c < kChannelsW; ++c)
                for (std::size_t i = 0; i < n; ++i) sum[c] += channel_weight[c][i] * f0[i];
            bud.rotational = sum[kRotW];
            bud.vibrational = sum[kVibW];
            bud.electronic = sum[kElecW];
            bud.ionization = sum[kIonW];
            bud.attachment = sum[kAttW];
            bud.superelastic_gain = sum[kSuperW];
            out.ionization_rate_m3_s = sum[kIonRateW];
            out.attachment_rate_m3_s = sum[kAttRateW];
        }
        for (const auto& a : act) {
            const auto& p = *a.p;
            if (p.kind == CollisionKind::Elastic || p.kind == CollisionKind::Effective) continue;
            if (!per_process && p.kind != CollisionKind::Recombination) continue;
            ProcessRate pr;
            pr.label = p.label;
            pr.kind = p.kind;
            pr.target = p.target;
            pr.fraction = a.x;
            pr.rate_m3_s = rates(x, a, false);
            pr.superelastic_rate_m3_s = a.sloss.empty() ? 0.0 : rates(x, a, true);
            // The energy moment of this process's discrete l = 0 operator, so the budget closes to the
            // solver tolerance: sum over cells of c_v times what the process adds to cell v.
            double energy_change = 0;
            const auto& weight = energy_weight[static_cast<std::size_t>(&a - act.data())];
            for (std::size_t i = 0; i < n; ++i) energy_change += weight[i] * f0[i];
            if (p.kind == CollisionKind::Recombination) energy_change *= a.x;
            pr.power_ev_m3_s = -energy_change;
            if (p.kind == CollisionKind::Attachment) bud.attachment += pr.power_ev_m3_s;
            else if (p.kind == CollisionKind::Recombination) bud.recombination += pr.power_ev_m3_s;
            else if (p.kind == CollisionKind::Ionization) bud.ionization += pr.power_ev_m3_s;
            else {
                switch (group_of(p)) {
                    case CollisionProcess::Group::Rotational: bud.rotational += pr.power_ev_m3_s; break;
                    case CollisionProcess::Group::Vibrational: bud.vibrational += pr.power_ev_m3_s; break;
                    default: bud.electronic += pr.power_ev_m3_s; break;
                }
                bud.superelastic_gain += p.threshold_ev * a.xs * pr.superelastic_rate_m3_s;
            }
            if (p.kind == CollisionKind::Ionization) out.ionization_rate_m3_s += a.x * pr.rate_m3_s;
            if (p.kind == CollisionKind::Attachment) out.attachment_rate_m3_s += a.x * pr.rate_m3_s;
            if (p.kind == CollisionKind::Recombination) out.recombination_rate_m3_s += a.x * pr.rate_m3_s;
            gross = std::max(gross, p.threshold_ev * a.x * pr.rate_m3_s);
            out.rates.push_back(pr);
        }
        if (cond.temporal_growth)
            for (std::size_t i = 0; i < n; ++i) bud.growth += nu * G.c[i] * G.m12[i] * f0[i];
        const double spent = bud.elastic + bud.rotational + bud.vibrational + bud.electronic + bud.ionization + bud.attachment + bud.recombination +
                             bud.growth + bud.electron_electron;
        // Relative to the largest gross energy flow: the field input, recoil, or the forward and
        // reverse inelastic exchanges (which can nearly cancel near equilibrium).
        const double scale = std::max({std::abs(bud.field), std::abs(bud.elastic), gross, std::abs(bud.attachment), std::abs(bud.recombination), 1e-300});
        bud.residual = (bud.field - spent) / scale;
        if (w > 0) {
            out.alpha_n_m2 = out.ionization_rate_m3_s / w;
            out.eta_n_m2 = out.attachment_rate_m3_s / w;
        }
    };

    if (azimuthal) {
        if (azimuthal->evaluate_rhs) {
            nu = 0;
            swarm_op = assemble(azimuthal->order);
            // A continuous residual must be a deterministic function of its
            // distribution, independent of how often it was called. Close the
            // nonlinear Landau face weights instead of retaining the initial
            // central-weight guess from this invocation.
            for (int face_iteration = 0; face_iteration < 60; ++face_iteration) {
                const auto previous_theta = theta;
                update_faces(x);
                double change = 0;
                for (std::size_t k = 1; k < n; ++k) change = std::max(change, std::abs(theta[k] - previous_theta[k]));
                if (change < 1e-12 || a_ee == 0) break;
                if (face_iteration == 59) bad("continuous EEDF Landau face weights failed to converge");
            }
            std::vector<double> angular_rates(N);
            apply_op(swarm_op, azimuthal->order == 0, 0.0, *azimuthal->initial_modes, angular_rates);
            for (double& value : angular_rates) value *= -cond.gas_density_m3;
            if (azimuthal->order == 0) ee_apply(*azimuthal->initial_modes, angular_rates, 0.5 * cond.gas_density_m3);
            for (std::size_t row = 0; row < N; ++row)
                angular_rates[row] = swarm_op.padding[row] ? 0.0 : angular_rates[row] / growth_w[row];
            azimuthal->result->modes = std::move(angular_rates);
            if (azimuthal->summary) {
                azimuthal->summary->converged = true;
                summarize(*azimuthal->summary);
                azimuthal->summary->net_rate_m3_s = azimuthal->summary->ionization_rate_m3_s -
                    azimuthal->summary->attachment_rate_m3_s - azimuthal->summary->recombination_rate_m3_s;
            }
            return {};
        }
        const double inv = 1 / (cond.gas_density_m3 * dt_s);
        nu = inv;
        swarm_op = assemble(azimuthal->order);
        std::vector<double> rhs(N), solution = *azimuthal->initial_modes;
        for (std::size_t row = 0; row < N; ++row)
            rhs[row] = swarm_op.padding[row] ? 0.0 : inv * growth_w[row] * solution[row];
        Banded P;
        precondition_op(swarm_op, false, 0.0, P);
        (void)gmres([&](const std::vector<double>& value, std::vector<double>& product) { apply_op(swarm_op, false, 0.0, value, product); },
                    [&](std::vector<double>& value) { P.solve(value); }, rhs, solution, 1e-12, 120, 1200);
        const double residual = linear_backward_error(swarm_op, false, 0.0, rhs, solution);
        if (!(residual <= 1e-9 && std::isfinite(residual))) bad("azimuthal transient linear solve failed");
        for (double value : solution) if (!std::isfinite(value)) bad("non-finite azimuthal transient mode");
        azimuthal->result->modes = std::move(solution);
        azimuthal->result->linear_residual = residual;
        return {};
    }

    if (initial) {
        // Frozen heavy-species populations are supplied by the outer coupled iterate. Rebuild
        // on each call, so newly populated states and actual recombining ions are never lost.
        const double density0 = initial->electron_density_m3();
        const double inv = 1 / (cond.gas_density_m3 * dt_s);
        const std::vector<double> history = x;
        std::vector<double> iterate = x, rhs(N), candidate(N);
        Banded P;
        bool settled = false;
        double relative = 0;
        int iterations = 0;
        for (int iteration = 0; iteration < 30; ++iteration) {
            double density_ratio = 0;
            for (std::size_t i = 0; i < n; ++i) density_ratio += iterate[even(0, i)] * G.m12[i];
            if (!(density_ratio > 0 && std::isfinite(density_ratio))) bad("invalid transient electron density; reduce the timestep");
            std::vector<double> normalized = iterate;
            for (auto& value : normalized) value /= density_ratio;
            xe_now = density0 * density_ratio / cond.gas_density_m3;
            if (cond.ion_fraction < 0) xi_now = xe_now;
            nu = inv;
            swarm_op = assemble(0);
            refresh_field_diffusion();
            // The Landau term is bilinear in the normalized shape and scales with density.
            update_faces(normalized);
            // In the linearization unknowns are relative to density0, so one factor of the
            // iterate must carry the inverse density ratio.
            if (a_ee > 0) a_ee /= density_ratio;
            faces(iterate, face_value, slope);
            landau_sum(slope, s_slope);
            landau_sum(face_value, s_value);
            precondition_op(swarm_op, true, 0.0, P);
            for (std::size_t r = 0; r < N; ++r) rhs[r] = swarm_op.padding[r] ? 0.0 : inv * growth_w[r] * history[r];
            ee_apply(iterate, rhs, 0.5);
            candidate = iterate;
            (void)gmres([&](const std::vector<double>& v, std::vector<double>& r) { apply_op(swarm_op, true, 0.0, v, r); },
                             [&](std::vector<double>& v) { P.solve(v); }, rhs, candidate, 1e-12, 120, 1000);
            relative = linear_backward_error(swarm_op, true, 0.0, rhs, candidate);
            if (!(relative <= 1e-9 && std::isfinite(relative))) bad("transient GMRES failed; reduce the timestep");
            double change = 0, magnitude = 0;
            for (std::size_t r = 0; r < N; ++r) {
                if (!std::isfinite(candidate[r])) bad("non-finite transient mode; reduce the timestep");
                change = std::max(change, std::abs(candidate[r] - iterate[r]));
                magnitude = std::max(magnitude, std::abs(candidate[r]));
            }
            iterate = candidate;
            iterations = iteration + 1;
            if (change <= 1e-9 * std::max(magnitude, 1e-300)) { settled = true; break; }
        }
        if (!settled) bad("transient nonlinear iteration failed; reduce the timestep");
        double norm = 0, peak = 0;
        for (std::size_t i = 0; i < n; ++i) {
            norm += iterate[even(0, i)] * G.m12[i];
            peak = std::max(peak, std::abs(iterate[even(0, i)]));
        }
        if (!(norm > 0 && std::isfinite(norm))) bad("non-positive transient density; reduce the timestep");
        for (std::size_t i = 0; i < n; ++i)
            if (iterate[even(0, i)] < -1e-10 * peak) bad("negative transient distribution; reduce the timestep");
        EedfStepResult result;
        result.state = *initial;
        result.state.time_s += dt_s;
        result.state.density_modes = iterate;
        for (auto& value : result.state.density_modes) value *= density0;
        x = iterate;
        for (auto& value : x) value /= norm;
        xe_now = density0 * norm / cond.gas_density_m3;
        nu = 0;
        update_faces(x);
        result.swarm.converged = true;
        result.swarm.iterations = iterations;
        summarize(result.swarm);
        result.swarm.net_rate_m3_s = result.swarm.ionization_rate_m3_s - result.swarm.attachment_rate_m3_s - result.swarm.recombination_rate_m3_s;
        result.nonlinear_iterations = iterations;
        result.linear_residual = relative;
        const auto& budget = result.swarm.budget;
        const double losses = budget.elastic + budget.rotational + budget.vibrational + budget.electronic +
                              budget.ionization + budget.attachment + budget.recombination + budget.electron_electron;
        const double change = result.state.electron_energy_ev_m3() - initial->electron_energy_ev_m3();
        const double field_work = dt_s * cond.gas_density_m3 * result.state.electron_density_m3() * budget.field;
        const double collision_loss = dt_s * cond.gas_density_m3 * result.state.electron_density_m3() * losses;
        result.energy_balance_relative = (field_work - collision_loss - change) /
            std::max({std::abs(field_work), std::abs(collision_loss), std::abs(change), 1e-300});
        *step_result = std::move(result);
        return {};
    }

    if (transient) {
        // Time-dependent breakdown: BDF2 in t on every Legendre term of the distribution (at low
        // pressure momentum relaxes on the time scale of the breakdown itself), on the ions and
        // on the circuit. Inside each step the couplings (drift loss, ion densities, gap
        // voltage) are iterated, the drift velocity by secant steps.
        const BreakdownSetup& setup = *bs;
        BreakdownResult& res = *br;
        const double Ngas = cond.gas_density_m3, gap = setup.gap_m, area = setup.area_m2, V0 = setup.voltage_v;
        const double C = kEps0 * area / gap, R = setup.series_resistance_ohm, volume = area * gap;
        const bool ideal = !(R > 0);
        const double eV = kCharge;
        // Seed and secondary electrons: a Maxwellian of the given mean, normalised.
        std::vector<double> seed(N, 0.0);
        {
            const double te = 2.0 / 3 * setup.seed_mean_energy_ev;
            double norm = 0;
            for (std::size_t i = 0; i < n; ++i) { seed[even(0, i)] = std::exp(-G.c[i] / te); norm += seed[even(0, i)] * G.m12[i]; }
            for (std::size_t i = 0; i < n; ++i) seed[even(0, i)] /= norm;
        }
        const auto norm_of = [&](const std::vector<double>& v) {
            double s = 0;
            for (std::size_t i = 0; i < n; ++i) s += v[even(0, i)] * G.m12[i];
            return s;
        };
        const auto energy_of = [&](const std::vector<double>& v) {  // the energy moment the operator conserves
            double s = 0;
            for (std::size_t i = 0; i < n; ++i) s += G.c[i] * v[even(0, i)] * G.m12[i];
            return s;
        };
        const auto drift_of = [&](const std::vector<double>& v) {
            double s = 0;
            for (std::size_t k = 1; k < n; ++k) s += G.e[k] * v[odd(1, k)] * G.d[k];
            return kGamma / 3 * s;
        };
        const auto rate_sum = [&](const std::vector<double>& v, CollisionKind kind, bool per_ion) {
            double s = 0;
            for (std::size_t q = 0; q < act.size(); ++q)
                if (act[q].p->kind == kind) s += (per_ion ? recombination_share[q] : act[q].x) * rates(v, act[q], false);
            return s;
        };
        // Cumulative channels in eV per m^3 (electrons) or J (circuit), stepped with the same
        // BDF2 weights as the distribution so the books close: now and one step back.
        enum Channel { kField, kElastic, kRot, kVib, kElec, kIon, kAtt, kRec, kEe, kSuper, kAnode, kSecondary, kIonJoule,
                       kSource, kResistor, kGap, kChannels };
        std::array<double, kChannels> book{}, book_prev{};
        double U = setup.seed_density_m3 * energy_of(seed), U_prev = U;
        const double U0 = U;
        // State now and one step back: shape (normalised), densities, voltage.
        std::vector<double> shape = seed, shape_prev = seed;
        double n_e = setup.seed_density_m3, n_e_prev = n_e, np = 0, np_prev = 0, nm = 0, nm_prev = 0, V = V0, V_prev = V0;
        double W = 0;
        double t = 0, dt = tau_scale / Ngas, dt_prev = dt;
        const double dt_min = dt * 1e-6;
        bool first = true;
        int next_output = 0;
        Banded PT;
        std::vector<double> rhs(N), y(N);
        const auto sample = [&](double kion, double katt, double current) {
            BreakdownSample b;
            b.time_s = t;
            b.gap_voltage_v = V;
            b.reduced_field_td = V / (gap * Ngas) / kTd;
            b.electron_density_m3 = n_e;
            b.positive_ion_density_m3 = np;
            b.negative_ion_density_m3 = nm;
            b.current_a = current;
            double mean = 0;
            for (std::size_t i = 0; i < n; ++i) mean += shape[even(0, i)] * G.m32[i];
            b.mean_energy_ev = mean;
            b.drift_velocity_m_s = W;
            b.ionization_rate_m3_s = kion;
            b.attachment_rate_m3_s = katt;
            res.samples.push_back(b);
        };
        const double ion_drift_n = setup.ion_mobility_n;
        sample(0, 0, 0);
        next_output = 1;
        res.stop = "step limit";
        while (res.steps < setup.max_steps) {
            if (t >= setup.end_time_s * (1 - 1e-12)) { res.stop = "end time"; break; }
            dt = std::min(dt, setup.end_time_s - t);
            const double omega = first ? 0.0 : dt / dt_prev;
            const double c0 = first ? 1.0 : (1 + 2 * omega) / (1 + omega), c1 = first ? 1.0 : 1 + omega, c2 = first ? 0.0 : omega * omega / (1 + omega);
            const double dtau = Ngas * dt;
            // History in units of the current density: y = f / n_e.
            std::vector<double> hist(N);
            for (std::size_t r = 0; r < N; ++r) hist[r] = c1 * shape[r] - c2 * shape_prev[r] * (n_e_prev / n_e);
            std::vector<double> Y = shape;
            double Vg = V, npg = np, nmg = nm, Wg = W > 0 ? W : drift_of(shape);
            double kion = 0, katt = 0, krec = 0, current = 0, Wi = 0;
            bool converged = false;
            xe_now = n_e / Ngas;
            double w_in_prev = 0, g_prev = 0;
            double nu_drift = 0;
            for (int k = 0; k < 16; ++k) {
                EN = Vg / (gap * Ngas);
                xi_now = npg / Ngas;
                for (std::size_t q = 0; q < act.size(); ++q)
                    if (act[q].p->kind == CollisionKind::Recombination) act[q].x = xi_now * recombination_share[q];
                nu_drift = setup.drift_loss ? std::max(Wg, 0.0) / (gap * Ngas) : 0.0;
                // The time derivative rides on the growth term: rate + c0 / dtau on every row.
                const double inv = c0 / dtau;
                nu = nu_drift + inv;
                swarm_op = assemble(0);
                refresh_field_diffusion();
                update_faces(Y);
                precondition_op(swarm_op, true, 0.0, PT);
                Wi = ion_drift_n * EN;
                const double secondary = setup.secondary_yield * npg * Wi / gap / (Ngas * n_e);  // per tau, per electron now
                std::fill(rhs.begin(), rhs.end(), 0.0);
                for (std::size_t r = 0; r < N; ++r) rhs[r] = swarm_op.padding[r] ? 0.0 : growth_w[r] * hist[r] / dtau;
                for (std::size_t i = 0; i < n; ++i) rhs[even(0, i)] += G.m12[i] * secondary * seed[even(0, i)];
                ee_apply(Y, rhs, 0.5);
                y = Y;
                (void)gmres([&](const std::vector<double>& v, std::vector<double>& r) { apply_op(swarm_op, true, 0.0, v, r); },
                            [&](std::vector<double>& v) { PT.solve(v); }, rhs, y, 1e-13, 120, 600);
                const double linear_residual = linear_backward_error(swarm_op, true, 0.0, rhs, y);
                if (!(linear_residual <= 1e-9 && std::isfinite(linear_residual))) break;
                const double norm = norm_of(y);
                if (!(norm > 0) || !std::isfinite(norm)) break;
                std::vector<double> hat(y);
                for (auto& q : hat) q /= norm;
                const double n_e_new = n_e * norm;
                const double Wnew = drift_of(hat);
                kion = rate_sum(hat, CollisionKind::Ionization, false);
                katt = rate_sum(hat, CollisionKind::Attachment, false);
                krec = rate_sum(hat, CollisionKind::Recombination, true);
                const double np_new = (c1 * np - c2 * np_prev + dt * Ngas * n_e_new * kion) / (c0 + dt * (Wi / gap + krec * n_e_new));
                const double nm_new = (c1 * nm - c2 * nm_prev + dt * Ngas * n_e_new * katt) / (c0 + dt * Wi / gap);
                current = eV * area * (n_e_new * Wnew + (np_new + nm_new) * Wi);
                double V_new = V0;
                if (!ideal) {
                    const double conductance = Vg > 0 ? current / Vg : 0.0;
                    V_new = (C * (c1 * V - c2 * V_prev) / dt + V0 / R) / (C * c0 / dt + 1 / R + conductance);
                }
                double change = 0, size = 0;
                for (std::size_t r = 0; r < N; ++r) { change = std::max(change, std::abs(y[r] - Y[r])); size = std::max(size, std::abs(y[r])); }
                const bool settled = k > 0 && std::abs(V_new - Vg) <= 1e-10 * V0 && change <= 1e-8 * size && std::abs(Wnew - Wg) <= 1e-8 * std::abs(Wnew) &&
                                     std::abs(np_new - npg) <= 1e-8 * std::max(np_new, 1.0);
                Y = y;
                Vg = V_new; npg = np_new; nmg = nm_new;
                // The drift loss depends on the drift it produces: secant steps on W.
                const double g = Wnew - Wg;
                double w_next = Wnew;
                if (k >= 1 && g != g_prev && std::abs(Wg - w_in_prev) > 0) w_next = Wg - g * (Wg - w_in_prev) / (g - g_prev);
                w_in_prev = Wg;
                g_prev = g;
                Wg = w_next;
                if (settled) { converged = true; Wg = Wnew; break; }
            }
            const double norm = norm_of(Y);
            const double n_e_new = n_e * norm;
            std::vector<double> hat(Y);
            for (auto& q : hat) q /= (norm > 0 ? norm : 1.0);
            double mean_old = 0, mean_new = 0;
            for (std::size_t i = 0; i < n; ++i) { mean_old += shape[even(0, i)] * G.m32[i]; mean_new += hat[even(0, i)] * G.m32[i]; }
            // Step size: changes per step of about 0.05 in ln n_e, 0.25% of the source voltage and
            // 2.5% in mean energy (times step_tolerance); BDF2's error goes as their square, about
            // 0.1% in the breakdown time at the default.
            const double tol = setup.step_tolerance;
            const double ratio = std::max({std::abs(std::log(n_e_new / n_e)) / (0.05 * tol), std::abs(Vg - V) / V0 / (0.0025 * tol),
                                           std::abs(mean_new - mean_old) / std::max(mean_old, 1e-3) / (0.025 * tol)});
            if (!converged || !(norm > 0 && std::isfinite(norm)) || !(ratio <= 3)) {
                if (!(dt > dt_min)) bad("breakdown failed at the minimum timestep; no step was accepted");
                dt *= converged ? std::clamp(0.8 / std::sqrt(ratio), 0.1, 0.5) : 0.25;
                dt = std::max(dt, dt_min);
                ++res.rejected_steps;
                continue;
            }
            // Accept: the energy channels at the new state, with the coefficients the solve used.
            nu = nu_drift;
            x = hat;
            xe_now = n_e_new / Ngas;
            update_faces(x);
            SwarmResult o;
            summarize(o, false);
            const auto& b = o.budget;
            const double per = Ngas * n_e_new;  // budget (per electron per N) to eV/(m^3 s)
            std::array<double, kChannels> rate{};
            rate[kField] = per * b.field;
            rate[kElastic] = per * b.elastic;
            rate[kRot] = per * b.rotational;
            rate[kVib] = per * b.vibrational;
            rate[kElec] = per * b.electronic;
            rate[kIon] = per * b.ionization;
            rate[kAtt] = per * b.attachment;
            rate[kRec] = per * b.recombination;
            rate[kEe] = per * b.electron_electron;
            rate[kSuper] = per * b.superelastic_gain;
            rate[kAnode] = nu * Ngas * n_e_new * energy_of(hat);
            rate[kSecondary] = setup.secondary_yield * npg * Wi / gap * energy_of(seed);
            rate[kIonJoule] = (npg + nmg) * Wi * EN * Ngas;  // eV/(m^3 s): e n W_i E
            const double I_source = ideal ? current : (V0 - Vg) / R;
            rate[kSource] = V0 * I_source;
            rate[kResistor] = ideal ? 0.0 : (V0 - Vg) * (V0 - Vg) / R;
            rate[kGap] = Vg * current;
            for (int c = 0; c < kChannels; ++c) {
                const double next = (c1 * book[c] - c2 * book_prev[c] + dt * rate[c]) / c0;
                book_prev[c] = book[c];
                book[c] = next;
            }
            U_prev = U;
            U = n_e_new * energy_of(hat);
            shape_prev = shape; shape = hat;
            n_e_prev = n_e; n_e = n_e_new;
            np_prev = np; np = npg;
            nm_prev = nm; nm = nmg;
            V_prev = V; V = Vg;
            W = Wg;
            t += dt;
            dt_prev = dt;
            first = false;
            ++res.steps;
            if (res.breakdown_time_s < 0 && !ideal && V < 0.9 * V0)  // where the step crossed 90%, linearly
                res.breakdown_time_s = t - dt * (0.9 * V0 - V) / std::max(V_prev - V, 1e-300);
            const bool collapsed = !ideal && V < setup.collapse_fraction * V0;
            const bool done = collapsed || t >= setup.end_time_s * (1 - 1e-12);
            // Samples at the output times, and whenever the electron density has grown by a
            // quarter decade or the gap voltage moved 1% since the last one.
            const auto& last = res.samples.back();
            const bool moved = std::abs(std::log10(n_e / last.electron_density_m3)) >= 0.25 || std::abs(V - last.gap_voltage_v) >= 0.01 * V0;
            if (done || moved || t >= setup.end_time_s * next_output / setup.outputs) {
                sample(kion, katt, current);
                while (next_output <= setup.outputs && t >= setup.end_time_s * next_output / setup.outputs) ++next_output;
            }
            if (collapsed) { res.stop = "collapse"; break; }
            dt *= std::clamp(0.9 / std::max(ratio, 1e-12), 0.5, 1.5);
            dt = std::max(dt, dt_min);
        }
        // The books, in joules.
        auto& e = res.energy;
        const double J = eV * volume;
        e.electron_field_work = J * book[kField];
        e.elastic = J * book[kElastic];
        e.rotational = J * book[kRot];
        e.vibrational = J * book[kVib];
        e.electronic = J * book[kElec];
        e.ionization = J * book[kIon];
        e.attachment = J * book[kAtt];
        e.recombination = J * book[kRec];
        e.electron_electron = J * book[kEe];
        e.superelastic_gain = J * book[kSuper];
        e.anode_loss = J * book[kAnode];
        e.secondary_input = J * book[kSecondary];
        e.electron_energy_change = J * (U - U0);
        e.ion_joule = J * book[kIonJoule];
        e.source = book[kSource];
        e.resistor = book[kResistor];
        e.gap = book[kGap];
        e.capacitor_change = 0.5 * C * (V * V - V0 * V0);
        const double spent = e.elastic + e.rotational + e.vibrational + e.electronic + e.ionization + e.attachment + e.recombination +
                             e.electron_electron + e.anode_loss - e.secondary_input + e.electron_energy_change;
        const double escale = std::max({std::abs(e.electron_field_work), std::abs(e.elastic), std::abs(e.rotational) + std::abs(e.superelastic_gain),
                                        std::abs(e.anode_loss), std::abs(e.electron_energy_change), 1e-300});
        e.electron_residual = (e.electron_field_work - spent) / escale;
        e.gap_residual = (e.gap - e.electron_field_work - e.ion_joule) / std::max({std::abs(e.gap), std::abs(e.electron_field_work), 1e-300});
        e.circuit_residual = (e.source - e.resistor - e.capacitor_change - e.gap) /
                             std::max({std::abs(e.source), std::abs(e.capacitor_change), std::abs(e.gap), 1e-300});
        res.energy_ev = G.c;
        res.eepf.resize(n);
        for (std::size_t i = 0; i < n; ++i) res.eepf[i] = shape[even(0, i)];
        (void)U_prev;
        return {};
    }
    SwarmResult out;
    // A continued solve starts at the pseudo time step a cold one converges at. A continuation that
    // has not converged in 20 iterations gives way to the cold solve.
    double dtau = continued ? tau_scale * 1e9 : tau_scale;
    Banded P;
    for (int it = 0; it < (continued ? 20 : 400); ++it) {
        const double inv_dtau = 1 / dtau;
        const auto apply = [&](const std::vector<double>& v, std::vector<double>& r) { apply_op(swarm_op, true, inv_dtau, v, r); };
        precondition_op(swarm_op, true, inv_dtau, P);
        std::vector<double> rhs(N, 0.0);
        for (std::size_t i = 0; i < n; ++i) rhs[even(0, i)] = inv_dtau * G.m12[i] * x[even(0, i)];
        ee_apply(x, rhs, 0.5);  // Newton: G_lin(x_new) - G(x)
        x_old = x;
        std::vector<double> sol = x;
        if (a_ee > 0) {
            // Electron-electron collisions make the equation quadratic in F, so the Newton step has to
            // keep the normalisation itself: rescaling its solution afterwards would rescale their
            // strength, and at large pseudo steps that scale is left free, so the iteration settles
            // on a wrong distribution. The bordered system [K Px; c 0][F; sigma] = [rhs; 1] holds
            // sum sqrt(e) F_0 = 1, sigma being the step's eigenvalue along Px, which rescaling
            // absorbs when the equation is linear.
            const double row = 1 / (tau_scale * 1e6);  // the constraint row, weighted as the gradient solves weight theirs
            std::vector<double> R(N, 0.0), y(N + 1, 0.0), bordered(N + 1, 0.0), part(N), product(N);
            for (std::size_t i = 0; i < n; ++i) R[even(0, i)] = G.m12[i] * x[even(0, i)];
            std::copy(rhs.begin(), rhs.end(), bordered.begin());
            bordered[N] = row;
            std::copy(x.begin(), x.end(), y.begin());
            const auto apply_bordered = [&](const std::vector<double>& v, std::vector<double>& r) {
                std::copy(v.begin(), v.begin() + static_cast<std::ptrdiff_t>(N), part.begin());
                apply_op(swarm_op, true, inv_dtau, part, product);
                double c = 0;
                for (std::size_t i = 0; i < n; ++i) c += G.m12[i] * v[even(0, i)];
                for (std::size_t q = 0; q < N; ++q) r[q] = product[q] + v[N] * R[q];
                r[N] = row * c;
            };
            // Block elimination with the banded factor preconditions the border too: with z = P^-1 R,
            // [u; sigma] = [P^-1 r - sigma z; (c P^-1 r - s / row) / (c z)] solves the system exactly for K = P.
            std::vector<double> z = R;
            P.solve(z);
            double cz = 0;
            for (std::size_t i = 0; i < n; ++i) cz += G.m12[i] * z[even(0, i)];
            const auto precondition_bordered = [&](std::vector<double>& v) {
                std::copy(v.begin(), v.begin() + static_cast<std::ptrdiff_t>(N), part.begin());
                P.solve(part);
                double c = 0;
                for (std::size_t i = 0; i < n; ++i) c += G.m12[i] * part[even(0, i)];
                const double sigma = (c - v[N] / row) / cz;
                for (std::size_t q = 0; q < N; ++q) v[q] = part[q] - sigma * z[q];
                v[N] = sigma;
            };
            (void)gmres(apply_bordered, precondition_bordered, bordered, y, 1e-12, 120, 600);
            sol.assign(y.begin(), y.begin() + static_cast<std::ptrdiff_t>(N));
            for (std::size_t q = 0; q < N; ++q) rhs[q] -= y[N] * R[q];  // the system sol solves
        } else (void)gmres(apply, [&](std::vector<double>& v) { P.solve(v); }, rhs, sol, 1e-12, 120, 600);
        const double linear_residual = linear_backward_error(swarm_op, true, inv_dtau, rhs, sol);
        if (!(linear_residual <= 1e-9 && std::isfinite(linear_residual))) {
            std::ostringstream message;
            message << "steady GMRES failed (relative residual " << linear_residual << ", iteration " << it << ", field " << field_td << " Td)";
            bad(message.str());
        }
        double norm = 0;
        for (std::size_t i = 0; i < n; ++i) norm += sol[even(0, i)] * G.m12[i];
        if (!(std::abs(norm) > 0) || !std::isfinite(norm)) bad("the solve failed");
        for (auto& q : sol) q /= norm;
        x = sol;
        double change = 0, peak = 0;
        for (std::size_t i = 0; i < n; ++i) {
            change = std::max(change, std::abs(x[even(0, i)] - x_old[even(0, i)]));
            peak = std::max(peak, std::abs(x[even(0, i)]));
        }
        const double nu_new = net_growth(x);
        const double nu_change = std::abs(nu_new - nu);
        nu = nu_new;
        update_faces(x);
        out.iterations = it + 1;
        if (dtau >= tau_scale * 1e9 && change < 1e-10 * peak && nu_change <= 1e-8 * std::max(std::abs(nu), 1e-30)) { out.converged = true; break; }
        dtau = std::min(dtau * 10, tau_scale * 1e15);
    }

    if (!out.converged) bad("steady inverse iteration did not converge");
    if (reuse) reuse->modes = x;
    // Density-gradient (hydrodynamic) terms: with f = n F - (dn/dz) F^L - (dn/dx) F^T, and G = N F^L,
    //   K G + W_b sqrt(e) w F = gamma e w [l/(2l-1) F_{l-1} + (l+1)/(2l+3) F_{l+1}],  sum sqrt(e) G_0 = 0,
    // with the swarm operator K (singular: the bulk drift W_b is the bordering unknown), and, for
    // the m = 1 harmonics, K^1 G^T = gamma e w [F_{l-1}/(2l-1) - F_{l+1}/(2l+3)]. The flux diffusion
    // coefficients are N D = (gamma / 3) integral e G_1.
    if (EN > 0 && (!reuse || reuse->gradient_terms)) {
        // The streaming source for harmonic m; l = 0 rows split each face's flux between its cells.
        const auto source = [&](int mh) {
            std::vector<double> S(N, 0.0);
            for (int l = mh; l < L; ++l) {
                const double down = mh == 0 ? static_cast<double>(l) / (2 * l - 1) : 1.0 / (2 * l - 1);
                const double up = mh == 0 ? static_cast<double>(l + 1) / (2 * l + 3) : -1.0 / (2 * l + 3);
                if (l % 2 == 0) {
                    for (std::size_t i = 0; i < n; ++i) {
                        const auto face = [&](int lp, std::size_t k) { return (lp < L && k >= 1 && k < n) ? x[odd(lp, k)] : 0.0; };
                        if (l == 0) {
                            S[even(0, i)] = kGamma / 3 * (G.e[i + 1] * face(1, i + 1) * (G.e[i + 1] - G.c[i]) + G.e[i] * face(1, i) * (G.c[i] - G.e[i]));
                            continue;
                        }
                        double v = 0;
                        if (l >= 1) v += down * 0.5 * (face(l - 1, i) + face(l - 1, i + 1));
                        v += up * 0.5 * (face(l + 1, i) + face(l + 1, i + 1));
                        S[even(l, i)] = kGamma * G.c[i] * G.h[i] * v;
                    }
                } else {
                    for (std::size_t k = 1; k < n; ++k) {
                        const double t = (G.e[k] - G.c[k - 1]) / G.d[k];
                        const auto centre = [&](int lp) { return lp < L ? (1 - t) * x[even(lp, k - 1)] + t * x[even(lp, k)] : 0.0; };
                        S[odd(l, k)] = kGamma * G.e[k] * G.d[k] * (down * centre(l - 1) + up * centre(l + 1));
                    }
                }
            }
            return S;
        };
        const double shift = 1 / (tau_scale * 1e6);  // keeps the preconditioner of the singular K regular
        // Longitudinal: the bordered system [K R; c 0][G; W_b] = [S; 0].
        {
            std::vector<double> R(N, 0.0), S = source(0), y(N + 1, 0.0), rhs(N + 1, 0.0);
            for (std::size_t r = 0; r < N; ++r) R[r] = swarm_op.padding[r] ? 0.0 : growth_w[r] * x[r];
            std::copy(S.begin(), S.end(), rhs.begin());
            std::vector<double> tmp(N);
            const auto apply = [&](const std::vector<double>& v, std::vector<double>& r) {
                std::copy(v.begin(), v.begin() + static_cast<std::ptrdiff_t>(N), tmp.begin());
                std::vector<double> kv(N);
                apply_op(swarm_op, true, 0.0, tmp, kv);
                double c = 0;
                for (std::size_t i = 0; i < n; ++i) c += G.m12[i] * v[even(0, i)];
                for (std::size_t q = 0; q < N; ++q) r[q] = kv[q] + v[N] * R[q];
                r[N] = shift * c;  // scaled like the preconditioned null direction
            };
            precondition_op(swarm_op, true, shift, P);
            const auto prec = [&](std::vector<double>& v) {
                std::copy(v.begin(), v.begin() + static_cast<std::ptrdiff_t>(N), tmp.begin());
                P.solve(tmp);
                std::copy(tmp.begin(), tmp.end(), v.begin());
            };
            const double res = gmres(apply, prec, rhs, y, 1e-11, 80, 2000);
            std::vector<double> gradient(y.begin(), y.begin() + static_cast<std::ptrdiff_t>(N)), adjusted_rhs = S;
            for (std::size_t row = 0; row < N; ++row) adjusted_rhs[row] -= y[N] * R[row];
            const double certified = linear_backward_error(swarm_op, true, 0.0, adjusted_rhs, gradient);
            if (!(certified <= 1e-9 && std::isfinite(certified) && std::isfinite(res))) bad("longitudinal gradient GMRES failed");
            double dl = 0;
            for (std::size_t k = 1; k < n; ++k) dl += G.e[k] * y[odd(1, k)] * G.d[k];
            out.longitudinal_diffusion_n = kGamma / 3 * dl;
            out.bulk_drift_velocity_m_s = y[N];
            out.gradient_residual = res;
        }
        // Transverse.
        if (L > 1) {
            const Operator op1 = assemble(1);
            std::vector<double> S = source(1), y(N, 0.0);
            precondition_op(op1, false, 0.0, P);
            const double res = gmres([&](const std::vector<double>& v, std::vector<double>& r) { apply_op(op1, false, 0.0, v, r); },
                                     [&](std::vector<double>& v) { P.solve(v); }, S, y, 1e-11, 80, 2000);
            const double certified = linear_backward_error(op1, false, 0.0, S, y);
            if (!(certified <= 1e-9 && std::isfinite(certified) && std::isfinite(res))) bad("transverse gradient GMRES failed");
            double dt = 0;
            for (std::size_t k = 1; k < n; ++k) dt += G.e[k] * y[odd(1, k)] * G.d[k];
            out.transverse_diffusion_n = kGamma / 3 * dt;
            out.gradient_residual = std::max(out.gradient_residual, res);
        }
    }

    summarize(out);
    results.push_back(std::move(out));
    }
    return results;
}

} // namespace

namespace {
Grid state_grid(const EedfState& state) {
    const Grid G = make_grid(state.grid);
    if (state.grid.legendre_terms < 2 || state.grid.legendre_terms > 30) bad("legendre_terms must be between 2 and 30");
    if (state.density_modes.size() != static_cast<std::size_t>(state.grid.cells) * static_cast<std::size_t>(state.grid.legendre_terms))
        bad("transient mode count does not match its grid");
    if (!(state.time_s >= 0 && std::isfinite(state.time_s))) bad("transient time must be finite and non-negative");
    for (double value : state.density_modes) if (!std::isfinite(value)) bad("transient modes must be finite");
    return G;
}
} // namespace

double EedfState::electron_density_m3() const {
    const Grid G = state_grid(*this);
    double density = 0;
    for (std::size_t i = 0; i < G.c.size(); ++i) density += density_modes[i * static_cast<std::size_t>(grid.legendre_terms)] * G.m12[i];
    return density;
}

double EedfState::electron_energy_ev_m3() const {
    const Grid G = state_grid(*this);
    double energy = 0;
    for (std::size_t i = 0; i < G.c.size(); ++i) energy += G.c[i] * density_modes[i * static_cast<std::size_t>(grid.legendre_terms)] * G.m12[i];
    return energy;
}

double EedfState::mean_energy_ev() const {
    const double density = electron_density_m3();
    if (!(density > 0)) bad("mean energy needs a positive electron density");
    return electron_energy_ev_m3() / density;
}

EedfState maxwellian_eedf(double density_m3, double mean_energy_ev, const EedfGrid& grid) {
    if (!(density_m3 > 0 && std::isfinite(density_m3)) || !(mean_energy_ev > 0 && std::isfinite(mean_energy_ev)))
        bad("the initial density and mean energy must be finite and positive");
    const Grid G = make_grid(grid);
    if (grid.legendre_terms < 2 || grid.legendre_terms > 30) bad("legendre_terms must be between 2 and 30");
    EedfState state;
    state.grid = grid;
    state.density_modes.assign(static_cast<std::size_t>(grid.cells) * static_cast<std::size_t>(grid.legendre_terms), 0.0);
    double density = 0;
    for (std::size_t i = 0; i < G.c.size(); ++i) {
        const auto index = i * static_cast<std::size_t>(grid.legendre_terms);
        state.density_modes[index] = std::exp(-G.c[i] / (2.0 / 3 * mean_energy_ev));
        density += state.density_modes[index] * G.m12[i];
    }
    if (!(density > 0 && std::isfinite(density))) bad("initial Maxwellian is unresolved on the energy grid");
    for (auto& value : state.density_modes) value *= density_m3 / density;
    return state;
}

namespace {
template<class Action> void legacy_owned_phase(const backend::DistributedHalo& halo, Action action) {
    std::string error;
    try { action(); } catch (const std::exception& exception) { error = exception.what(); }
    catch (...) { error = "unknown legacy EEDF boundary failure"; }
    halo.collective_require(error);
}
void legacy_owned_same(const backend::DistributedHalo& halo, std::span<const double> values) {
    std::uint64_t hash = 14695981039346656037ull;
    for (double value : values) { hash ^= std::bit_cast<std::uint64_t>(value); hash *= 1099511628211ull; }
    hash ^= static_cast<std::uint64_t>(values.size());
    for (int shift : {0, 32}) {
        const auto part = static_cast<double>((hash >> shift) & 0xffffffffull);
        halo.collective_require(halo.global_max(part) != -halo.global_max(-part) ? "legacy EEDF ranks supplied different replicated input" : "");
    }
}
SwarmResult gather_owned_swarm(SwarmResult swarm, const EedfGrid& grid, backend::RowPartition rows,
                               const backend::ExecutionOptions& execution) {
    const auto stride = static_cast<std::size_t>(grid.legendre_terms);
    const backend::RowPartition cells{static_cast<backend::GlobalIndex>(grid.cells), rows.row_begin / stride, rows.local_rows / stride};
    backend::DistributedHalo boundary(cells, {}, execution);
    swarm.energy_ev = backend::gather_distributed(boundary, swarm.energy_ev);
    swarm.eepf = backend::gather_distributed(boundary, swarm.eepf);
    return swarm;
}
}

EedfStepResult advance_eedf(const std::vector<CollisionProcess>& processes, const EedfConditions& conditions,
                           const EedfState& initial, double dt_s) {
    if (conditions.execution.mpi) {
        const auto partition = distributed_eedf_partition(initial.grid, conditions.execution);
        backend::DistributedHalo boundary(partition, {}, conditions.execution);
        DistributedEedfState owned{initial.grid, partition, initial.time_s, {}};
        legacy_owned_phase(boundary, [&] {
            if (initial.density_modes.size() != partition.global_rows) bad("transient mode count does not match its grid");
            for (double value : initial.density_modes) if (!std::isfinite(value)) bad("transient modes must be finite");
            owned.density_modes.assign(initial.density_modes.begin() + static_cast<std::ptrdiff_t>(partition.row_begin),
                initial.density_modes.begin() + static_cast<std::ptrdiff_t>(partition.row_begin + partition.local_rows));
        });
        legacy_owned_same(boundary, initial.density_modes);
        auto local = advance_eedf_distributed(processes, conditions, owned, dt_s);
        EedfStepResult result;
        result.state = {initial.grid, local.state.time_s, backend::gather_distributed(boundary, local.state.density_modes)};
        result.swarm = gather_owned_swarm(std::move(local.swarm), initial.grid, partition, conditions.execution);
        result.nonlinear_iterations = local.nonlinear_iterations; result.linear_residual = local.linear_residual;
        result.energy_balance_relative = local.energy_balance_relative;
        return result;
    }
    if (!(dt_s > 0 && std::isfinite(dt_s))) bad("the transient timestep must be finite and positive");
    const double density = initial.electron_density_m3();
    if (!(density > 0 && std::isfinite(density))) bad("the transient state needs a positive electron density");
    (void)initial.electron_energy_ev_m3();
    const auto stride = static_cast<std::size_t>(initial.grid.legendre_terms);
    const auto even_count = static_cast<std::size_t>((initial.grid.legendre_terms + 1) / 2);
    const auto last = static_cast<std::size_t>(initial.grid.cells - 1) * stride;
    for (std::size_t index = even_count; index < stride; ++index)
        if (initial.density_modes[last + index] != 0) bad("transient boundary padding modes must be zero");
    double peak = 0;
    for (std::size_t cell = 0; cell < static_cast<std::size_t>(initial.grid.cells); ++cell)
        peak = std::max(peak, std::abs(initial.density_modes[cell * stride]));
    for (std::size_t cell = 0; cell < static_cast<std::size_t>(initial.grid.cells); ++cell)
        if (initial.density_modes[cell * stride] < -1e-10 * peak) bad("the initial isotropic distribution must be non-negative within numerical tolerance");
    EedfConditions c = conditions;
    c.electron_fraction = density / c.gas_density_m3;
    c.temporal_growth = false;
    EedfStepResult result;
    (void)solve_impl(processes, c, {c.reduced_field_td}, initial.grid, nullptr, nullptr, &initial, dt_s, &result);
    return result;
}

detail::LocalEedfAssembly detail::assemble_local_eedf(const std::vector<CollisionProcess>& processes,
    const EedfConditions& conditions, const EedfGrid& grid, backend::RowPartition partition, int azimuthal_order, bool normalized_real_harmonics) {
    LocalEedfAssembly output; output.partition = partition; output.azimuthal_order = azimuthal_order;
    AzimuthalContext context; context.order = azimuthal_order;
    (void)solve_impl(processes, conditions, {conditions.reduced_field_td}, grid, nullptr, nullptr, nullptr, 0, nullptr,
        normalized_real_harmonics && azimuthal_order > 0 ? &context : nullptr, &output);
    return output;
}

detail::AzimuthalStep detail::advance_azimuthal_eedf(const std::vector<CollisionProcess>& processes,
    const EedfConditions& conditions, const EedfGrid& grid, int azimuthal_order,
    const std::vector<double>& initial_modes, const std::vector<double>& isotropic_modes, double dt_s) {
    if (!(dt_s > 0 && std::isfinite(dt_s))) bad("azimuthal timestep must be finite and positive");
    if (azimuthal_order < 1 || azimuthal_order >= grid.legendre_terms) bad("azimuthal order is outside the angular expansion");
    const auto expected = static_cast<std::size_t>(grid.cells) * static_cast<std::size_t>(grid.legendre_terms);
    if (initial_modes.size() != expected || isotropic_modes.size() != expected) bad("azimuthal state layout mismatch");
    auto local_conditions = conditions; local_conditions.temporal_growth = false;
    AzimuthalStep result;
    const AzimuthalContext context{azimuthal_order, &initial_modes, &isotropic_modes, &result};
    (void)solve_impl(processes, local_conditions, {local_conditions.reduced_field_td}, grid, nullptr, nullptr, nullptr, dt_s, nullptr, &context);
    return result;
}

detail::AzimuthalEvaluation detail::evaluate_azimuthal_rhs(const std::vector<CollisionProcess>& processes,
    const EedfConditions& conditions, const EedfGrid& grid, int azimuthal_order,
    const std::vector<double>& modes, const std::vector<double>& isotropic_modes) {
    if (azimuthal_order < 0 || azimuthal_order >= grid.legendre_terms) bad("invalid RHS azimuthal order");
    const auto expected = static_cast<std::size_t>(grid.cells) * static_cast<std::size_t>(grid.legendre_terms);
    if (modes.size() != expected || isotropic_modes.size() != expected) bad("azimuthal RHS state layout mismatch");
    auto local_conditions = conditions; local_conditions.temporal_growth = false;
    AzimuthalStep evaluated;
    AzimuthalEvaluation result;
    const AzimuthalContext context{azimuthal_order, &modes, &isotropic_modes, &evaluated, true, azimuthal_order == 0 ? &result.swarm : nullptr};
    (void)solve_impl(processes, local_conditions, {local_conditions.reduced_field_td}, grid, nullptr, nullptr, nullptr, 0, nullptr, &context);
    result.rates = std::move(evaluated.modes);
    return result;
}

std::vector<SwarmResult> solve_eedf_sweep(const std::vector<CollisionProcess>& processes, const EedfConditions& conditions,
                                          const std::vector<double>& reduced_fields_td, const EedfGrid& grid) {
    if (conditions.execution.mpi) {
        const auto partition = distributed_eedf_partition(grid, conditions.execution);
        backend::DistributedHalo boundary(partition, {}, conditions.execution);
        std::vector<SwarmResult> result;
        legacy_owned_phase(boundary, [&] {
            if (reduced_fields_td.empty()) bad("no E/N given");
            for (double field : reduced_fields_td) if (!(field >= 0 && std::isfinite(field))) bad("E/N must be finite and nonnegative");
            result.reserve(reduced_fields_td.size());
        });
        legacy_owned_same(boundary, reduced_fields_td);
        for (double field : reduced_fields_td) {
            auto local_conditions = conditions; local_conditions.reduced_field_td = field;
            auto local = solve_eedf_distributed(processes, local_conditions, grid);
            result.push_back(gather_owned_swarm(std::move(local.swarm), grid, partition, conditions.execution));
        }
        return result;
    }
    return solve_impl(processes, conditions, reduced_fields_td, grid, nullptr, nullptr);
}

BreakdownResult solve_breakdown(const std::vector<CollisionProcess>& processes, const EedfConditions& conditions, const BreakdownSetup& setup,
                                const EedfGrid& grid) {
    if (!(setup.gap_m > 0 && std::isfinite(setup.gap_m))) bad("the gap must be positive");
    if (!(setup.area_m2 > 0 && std::isfinite(setup.area_m2))) bad("the electrode area must be positive");
    if (!(setup.voltage_v > 0 && std::isfinite(setup.voltage_v))) bad("the source voltage must be positive");
    if (!(setup.series_resistance_ohm >= 0 && std::isfinite(setup.series_resistance_ohm))) bad("the series resistance must be finite and non-negative");
    if (!(setup.seed_density_m3 > 0 && std::isfinite(setup.seed_density_m3)) || !(setup.seed_mean_energy_ev > 0 && std::isfinite(setup.seed_mean_energy_ev))) bad("the seed density and mean energy must be finite and positive");
    if (!(setup.ion_mobility_n >= 0 && std::isfinite(setup.ion_mobility_n))) bad("the ion mobility must be finite and non-negative");
    if (!(setup.secondary_yield >= 0 && setup.secondary_yield < 1)) bad("the secondary yield must be from 0 to below 1");
    if (!(setup.end_time_s > 0 && std::isfinite(setup.end_time_s))) bad("the end time must be positive");
    if (setup.outputs < 1 || setup.outputs > 100000 || setup.max_steps < 1) bad("outputs must be 1 to 100000 and max_steps at least 1");
    if (!(setup.collapse_fraction > 0 && setup.collapse_fraction < 1)) bad("the collapse fraction must be between 0 and 1");
    if (!(setup.step_tolerance > 0 && setup.step_tolerance <= 10)) bad("the step tolerance must be above 0 and at most 10");
    if (!(conditions.gas_density_m3 > 0)) bad("the gas density must be positive");
    EedfConditions c = conditions;
    c.temporal_growth = false;
    c.electron_fraction = setup.seed_density_m3 / conditions.gas_density_m3;
    c.ion_fraction = 0;
    BreakdownResult result;
    (void)solve_impl(processes, c, {setup.voltage_v / (setup.gap_m * conditions.gas_density_m3) / kTd}, grid, &setup, &result);
    if (result.stop == "step limit") bad("fixed-composition circuit breakdown exceeded its step limit");
    return result;
}

SwarmResult solve_eedf(const std::vector<CollisionProcess>& processes, const EedfConditions& conditions, const EedfGrid& grid) {
    return solve_eedf_sweep(processes, conditions, {conditions.reduced_field_td}, grid).front();
}

SwarmResult solve_eedf(const std::vector<CollisionProcess>& processes, const EedfConditions& conditions, const EedfGrid& grid,
                       SteadyEedfReuse& reuse) {
    if (conditions.execution.mpi) { reuse.modes.clear(); return solve_eedf(processes, conditions, grid); }
    if (!reuse.modes.empty()) {
        try { return solve_impl(processes, conditions, {conditions.reduced_field_td}, grid, nullptr, nullptr, nullptr, 0, nullptr, nullptr, nullptr, &reuse).front(); }
        catch (const std::invalid_argument&) { reuse.modes.clear(); }  // too far from the last state: solve it cold
    }
    return solve_impl(processes, conditions, {conditions.reduced_field_td}, grid, nullptr, nullptr, nullptr, 0, nullptr, nullptr, nullptr, &reuse).front();
}

SteadyTownsend steady_townsend(const SwarmResult& r) {
    const double w = r.bulk_drift_velocity_m_s > 0 ? r.bulk_drift_velocity_m_s : r.drift_velocity_m_s;
    const double gain = r.ionization_rate_m3_s, loss = r.attachment_rate_m3_s + r.recombination_rate_m3_s, net = gain - loss;
    if (!(w > 0)) return {};
    const double dl = r.longitudinal_diffusion_n, disc = w * w - 4 * dl * net;
    const double effective = dl > 0 && disc >= 0 ? (w - std::sqrt(disc)) / (2 * dl) : net / w;
    const double scale = net != 0 ? effective / (net / w) : 1.0;  // the same correction for both parts
    return {scale * gain / w, scale * loss / w};
}

} // namespace raikou::kinetics
