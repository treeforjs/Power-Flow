#pragma once
#include "raikou/distributed.h"
#include "raikou/json.h"
#include <exception>
#include <string>
#include <utility>

namespace raikou::detail {
// All ranks must agree on the valid MPI/communicator control fields before
// entering a JSON operation. Remaining input may fail locally; propagate that
// failure before any rank enters the numerical collectives.
template<class Parse>
backend::DistributedHalo parse_collectively(const Json& execution, Parse&& parse) {
    backend::ExecutionOptions control;
    control.mpi = execution.value("mpi", false);
    control.communicator_f = execution.value("communicator_f", -1);
    backend::DistributedHalo halo(backend::distributed_partition(1, control), {}, control);
    std::string error;
    try { std::forward<Parse>(parse)(halo); }
    catch (const std::exception& exception) { error = exception.what(); }
    catch (...) { error = "unknown collective input parsing failure"; }
    halo.collective_require(error);
    return halo;
}
}
