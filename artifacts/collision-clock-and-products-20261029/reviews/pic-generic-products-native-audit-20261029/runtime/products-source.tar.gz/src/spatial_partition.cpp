#include "raikou/spatial_partition.h"
#include <algorithm>
#include <cmath>
#include <set>
#include <stdexcept>

namespace raikou::spatial::partition {
namespace {
[[noreturn]] void invalid(const std::string& message) { throw std::invalid_argument("spatial partition: " + message); }
void require(bool value, const std::string& message) { if (!value) invalid(message); }
template<class Action> void collective(const backend::DistributedHalo& halo, Action&& action) {
    std::string error;
    try { action(); } catch (const std::exception& exception) { error = exception.what(); }
    catch (...) { error = "unknown local spatial partition failure"; }
    halo.collective_require(error);
}
GlobalIndex checked_add(GlobalIndex a, GlobalIndex b) {
    require(b <= no_dof - a, "global DOF count overflow"); return a + b;
}
std::string vector_error(std::span<const double> values, std::size_t count) {
    if (values.size() != count) return "owned value count differs from local rows";
    for (double value : values) if (!std::isfinite(value)) return "nonfinite owned value";
    return {};
}
} // namespace

DofLayout::DofLayout(const mesh::Geometry& g, std::size_t ns, std::size_t ng, std::size_t nt,
    std::span<const unsigned char> dielectric, bool circuit, const backend::ExecutionOptions& options,
    std::optional<CellInterval> custom) : species_(ns), photons_(ng), thermal_(nt), options_(options) {
    const auto balanced = backend::distributed_partition(static_cast<GlobalIndex>(g.volume.size()), options);
    backend::DistributedHalo control(balanced, {}, options);
    collective(control, [&] {
        require(g.volume.size() == g.centers.size(), "geometry cell arrays differ");
        require(ns > 0 && ns < std::numeric_limits<std::size_t>::max(), "species count must be positive");
        require(ng <= std::numeric_limits<std::size_t>::max() - ns - 1, "component count overflow");
        require(nt <= std::numeric_limits<std::size_t>::max() - ns - 1 - ng, "component count overflow");
        components_ = ns + 1 + ng + nt;
        require(dielectric.empty() || dielectric.size() == g.walls.size(), "dielectric mask must have one entry per wall");
        offsets_.assign(g.volume.size() + 1, 0); sigma_.assign(g.walls.size(), no_dof);
        std::vector<std::size_t> wall_counts(g.volume.size());
        for (std::size_t w = 0; w < g.walls.size(); ++w) {
            require(g.walls[w].cell < g.volume.size(), "wall cell index is outside the mesh");
            if (!dielectric.empty() && dielectric[w]) ++wall_counts[g.walls[w].cell];
        }
        for (std::size_t c = 0; c < g.volume.size(); ++c) {
            require(static_cast<GlobalIndex>(wall_counts[c]) <= no_dof / 2, "wall DOF count overflow");
            GlobalIndex count = checked_add(static_cast<GlobalIndex>(components_), static_cast<GlobalIndex>(wall_counts[c]) * 2);
            if (circuit && c + 1 == g.volume.size()) count = checked_add(count, 1);
            offsets_[c + 1] = checked_add(offsets_[c], count);
            wall_counts[c] = 0;
        }
        require(offsets_.back() < no_dof, "DOF sentinel collides with global count");
        for (std::size_t w = 0; w < g.walls.size(); ++w) if (!dielectric.empty() && dielectric[w]) {
            const auto c = g.walls[w].cell;
            sigma_[w] = offsets_[c] + components_ + 2 * static_cast<GlobalIndex>(wall_counts[c]++);
        }
        if (circuit) circuit_ = offsets_.back() - 1;
        owned_ = custom.value_or(CellInterval{static_cast<std::size_t>(balanced.row_begin), balanced.local_rows});
        require(owned_.begin <= g.volume.size() && owned_.count <= g.volume.size() - owned_.begin, "owned cell interval exceeds the mesh");
        const auto count = offsets_[owned_.begin + owned_.count] - offsets_[owned_.begin];
        require(count <= std::numeric_limits<std::size_t>::max(), "owned row count exceeds addressable storage");
        rows_ = {offsets_.back(), offsets_[owned_.begin], static_cast<std::size_t>(count)};
    });
    // Check mapping metadata, not just its total: distinct wall ownership can
    // have the same global count while assigning different physical unknowns.
    std::uint64_t hash = 1469598103934665603ULL;
    const auto mix = [&](std::uint64_t value) {
        for (unsigned byte = 0; byte < 8; ++byte) { hash ^= (value >> (8 * byte)) & 255; hash *= 1099511628211ULL; }
    };
    mix(ns); mix(ng); mix(nt); mix(circuit ? 1 : 0); mix(g.volume.size()); mix(g.walls.size());
    for (std::size_t w = 0; w < g.walls.size(); ++w) { mix(g.walls[w].cell); mix(sigma_[w]); }
    bool same = true;
    for (unsigned shift : {0u, 32u}) {
        const double part = static_cast<double>((hash >> shift) & 0xffffffffULL);
        if (control.global_max(part) != -control.global_max(-part)) same = false;
    }
    control.collective_require(same ? "" : "ranks disagree on spatial DOF mapping metadata");
    ownership_.emplace(rows_, std::span<const GlobalIndex>{}, options);
}
std::size_t DofLayout::photon_component(std::size_t group) const { require(group < photons_, "photon component is outside the layout"); return species_ + 1 + group; }
std::size_t DofLayout::thermal_component(std::size_t field) const { require(field < thermal_, "thermal component is outside the layout"); return species_ + 1 + photons_ + field; }
GlobalIndex DofLayout::cell_begin(std::size_t cell) const { require(cell < cells(), "cell is outside the layout"); return offsets_[cell]; }
GlobalIndex DofLayout::cell_end(std::size_t cell) const { require(cell < cells(), "cell is outside the layout"); return offsets_[cell + 1]; }
GlobalIndex DofLayout::cell_dof(std::size_t cell, std::size_t component) const { require(component < components_, "component is outside the layout"); return cell_begin(cell) + component; }
bool DofLayout::is_dielectric(std::size_t wall) const { require(wall < sigma_.size(), "wall is outside the layout"); return sigma_[wall] != no_dof; }
GlobalIndex DofLayout::sigma_dof(std::size_t wall) const { require(is_dielectric(wall), "wall is not dielectric"); return sigma_[wall]; }
GlobalIndex DofLayout::dielectric_dof(std::size_t wall) const { return sigma_dof(wall) + 1; }
bool DofLayout::owns_cell(std::size_t cell) const noexcept { return cell >= owned_.begin && cell - owned_.begin < owned_.count; }
bool DofLayout::owns_dof(GlobalIndex dof) const noexcept { return dof >= rows_.row_begin && dof - rows_.row_begin < rows_.local_rows; }
backend::DistributedHalo DofLayout::make_halo(std::span<const GlobalIndex> requested) const {
    auto execution = options_; execution.communicator_f = control_halo().communicator_f();
    return backend::DistributedHalo(rows_, requested, execution);
}

std::vector<GlobalIndex> requested_ghost_ids(const DofLayout& layout, const mesh::Geometry& g,
    const StencilDependencies& dependencies, std::span<const GlobalIndex> extras) {
    std::vector<GlobalIndex> result;
    collective(layout.control_halo(), [&] {
        require(layout.cells() == g.volume.size(), "layout and ghost geometry dimensions differ");
        require(dependencies.cells.empty() || dependencies.cells.size() == layout.cells(), "cell stencil count differs");
        require(dependencies.faces.empty() || dependencies.faces.size() == g.faces.size(), "face stencil count differs");
        require(dependencies.walls.empty() || dependencies.walls.size() == g.walls.size(), "wall stencil count differs");
        require(dependencies.gradients.empty() || dependencies.gradients.size() == layout.cells(), "gradient stencil count differs");
        for (auto c : dependencies.components) require(c < layout.components(), "ghost component is outside the layout");
        std::set<GlobalIndex> ids;
        const auto add = [&](GlobalIndex id) { require(id < layout.row_partition().global_rows, "ghost ID is outside the layout"); if (!layout.owns_dof(id)) ids.insert(id); };
        const auto cell = [&](std::size_t c) {
            require(c < layout.cells(), "stencil cell is outside the layout");
            if (dependencies.components.empty()) for (std::size_t component = 0; component < layout.components(); ++component) add(layout.cell_dof(c, component));
            else for (auto component : dependencies.components) add(layout.cell_dof(c, component));
        };
        const auto stencil = [&](const mesh::ScalarStencil& s) {
            for (const auto& [c, coefficient] : s.cells) { require(std::isfinite(coefficient), "nonfinite cell stencil coefficient"); if (coefficient != 0) cell(c); }
            for (const auto& [w, coefficient] : s.boundaries) {
                require(w < g.walls.size() && std::isfinite(coefficient), "invalid boundary stencil coefficient/index");
                if (coefficient == 0) continue;
                if (layout.is_dielectric(w)) { add(layout.sigma_dof(w)); add(layout.dielectric_dof(w)); }
                if (layout.circuit_dof() != no_dof) add(layout.circuit_dof());
            }
        };
        const auto owned = layout.owned_cells();
        for (std::size_t c = owned.begin; c < owned.begin + owned.count; ++c) {
            if (!dependencies.cells.empty()) stencil(dependencies.cells[c]);
            if (!dependencies.gradients.empty()) for (const auto& s : dependencies.gradients[c]) stencil(s);
        }
        for (std::size_t f = 0; f < g.faces.size(); ++f) {
            const auto& face = g.faces[f];
            require(face.a < layout.cells() && face.b < layout.cells(), "face cell is outside the layout");
            if (!layout.owns_cell(face.a) && !layout.owns_cell(face.b)) continue;
            cell(face.a); cell(face.b);
            if (!dependencies.faces.empty()) stencil(dependencies.faces[f]);
        }
        for (std::size_t w = 0; w < g.walls.size(); ++w) {
            require(g.walls[w].cell < layout.cells(), "wall cell is outside the layout");
            if (layout.owns_cell(g.walls[w].cell) && !dependencies.walls.empty()) stencil(dependencies.walls[w]);
        }
        for (auto id : extras) add(id);
        result.assign(ids.begin(), ids.end());
    });
    return result;
}

OwnedValues::OwnedValues(backend::DistributedHalo halo, double initial) : halo_(std::move(halo)) {
    collective(halo_, [&] { require(std::isfinite(initial), "nonfinite initial owned value"); local_.assign(halo_.partition().local_rows, initial); });
}
OwnedValues::OwnedValues(backend::DistributedHalo halo, std::vector<double> values) : halo_(std::move(halo)), local_(std::move(values)) {
    halo_.collective_require(vector_error(local_, halo_.partition().local_rows));
}
void OwnedValues::exchange() { auto received = halo_.exchange(local_); ghosts_ = std::move(received); current_ = true; }
std::span<double> OwnedValues::local_values() { current_ = false; return local_; }
double OwnedValues::value(GlobalIndex id) const {
    const auto index = halo_.compact_index(id);
    if (index < local_.size()) return local_[index];
    if (!current_) throw std::logic_error("spatial partition: halo values are stale; exchange before reading ghosts");
    return ghosts_.at(index - local_.size());
}
std::size_t OwnedValues::exchange_working_entries_bound() const noexcept {
    return local_.size() + 2 * halo_.layout().ghost_global_ids.size() + halo_.layout().send_local_indices.size();
}

LocalAssembly::LocalAssembly(backend::DistributedHalo halo) : halo_(std::move(halo)) {
    collective(halo_, [&] { residual_.resize(halo_.partition().local_rows); rows_.resize(residual_.size()); });
}
std::optional<std::size_t> LocalAssembly::owned_row(GlobalIndex row) {
    if (finished_) { error_ = "assembly was already consumed"; return {}; }
    const auto partition = halo_.partition();
    if (row >= partition.global_rows) { error_ = "assembly row exceeds global count"; return {}; }
    if (row < partition.row_begin || row - partition.row_begin >= partition.local_rows) return {};
    return static_cast<std::size_t>(row - partition.row_begin);
}
void LocalAssembly::add_residual(GlobalIndex row, double value) {
    if (!error_.empty()) return;
    if (!std::isfinite(value)) { error_ = "nonfinite residual contribution"; return; }
    if (const auto local = owned_row(row)) {
        residual_[*local] += value;
        if (!std::isfinite(residual_[*local])) error_ = "local residual accumulation overflow";
    }
}
void LocalAssembly::add_matrix(GlobalIndex row, GlobalIndex column, double value) {
    if (!error_.empty()) return;
    if (column >= halo_.partition().global_rows || !std::isfinite(value)) { error_ = "invalid matrix column/coefficient"; return; }
    if (const auto local = owned_row(row)) {
        try {
            auto [entry, inserted] = rows_[*local].try_emplace(column, 0);
            if (inserted) ++entries_;
            entry->second += value;
            if (!std::isfinite(entry->second)) error_ = "local matrix accumulation overflow";
        } catch (const std::exception& exception) { error_ = exception.what(); }
    }
}
LocalSystem LocalAssembly::finish() {
    halo_.collective_require(error_);
    LocalSystem result;
    collective(halo_, [&] {
        require(!finished_, "assembly was already consumed");
        const auto partition = halo_.partition();
        result.matrix.global_rows = partition.global_rows; result.matrix.row_begin = partition.row_begin;
        result.matrix.offsets.reserve(rows_.size() + 1); result.matrix.offsets.push_back(0);
        for (const auto& row : rows_) {
            for (const auto& [column, coefficient] : row) if (coefficient != 0) { result.matrix.columns.push_back(column); result.matrix.values.push_back(coefficient); }
            result.matrix.offsets.push_back(result.matrix.values.size());
        }
        result.matrix.validate_local();
    });
    result.residual = std::move(residual_); rows_.clear(); entries_ = 0; finished_ = true;
    return result;
}
} // namespace raikou::spatial::partition
