#include "raikou/device.h"
#include <algorithm>
#include <cmath>
#include <stdexcept>

namespace raikou::backend {
#ifdef RAIKOU_HAS_CUDA
std::unique_ptr<DeviceExecutor> make_cuda_executor_impl(const DeviceCsrView&,int,const std::string&);
#endif
std::unique_ptr<DeviceExecutor> make_cuda_executor(const DeviceCsrView& matrix,int device_id,const std::string& preconditioner) {
    if(device_id < -1)throw std::invalid_argument("invalid CUDA device ordinal");
    if(preconditioner!="jacobi"&&preconditioner!="block_ilu0")throw std::invalid_argument("CUDA preconditioner must be jacobi or block_ilu0");
    if(matrix.rows==std::numeric_limits<std::size_t>::max() || matrix.columns<matrix.rows || matrix.offsets.size()!=matrix.rows+1 ||
       matrix.offsets.front()!=0 || matrix.offsets.back()!=matrix.values.size() ||
       matrix.indices.size()!=matrix.values.size())throw std::invalid_argument("invalid compact device CSR dimensions");
    for(std::size_t i=0;i<matrix.rows;++i)
        if(matrix.offsets[i]>matrix.offsets[i+1] || matrix.offsets[i+1]>matrix.values.size())
            throw std::invalid_argument("invalid compact device CSR offsets");
    for(std::size_t k=0;k<matrix.values.size();++k)
        if(matrix.indices[k]<0 || static_cast<std::size_t>(matrix.indices[k])>=matrix.columns || !std::isfinite(matrix.values[k]))
            throw std::invalid_argument("invalid compact device CSR entry");
#ifdef RAIKOU_HAS_CUDA
    return make_cuda_executor_impl(matrix,device_id,preconditioner);
#else
    throw std::runtime_error("CUDA device execution was not built; no CPU fallback");
#endif
}
ResidentLinearResult solve_cuda_resident(const CsrMatrix& matrix,std::span<const double> rhs,const ExecutionOptions& options) {
    matrix.validate();
    if(rhs.size()!=matrix.rows || !(options.tolerance>0) || !std::isfinite(options.tolerance) ||
       options.max_iterations<1 || options.restart<1 || options.mpi)
        throw std::invalid_argument("invalid resident CUDA solve options; MPI uses its distributed executor");
    for(double value:rhs)if(!std::isfinite(value))throw std::invalid_argument("nonfinite resident RHS");
    auto device=make_cuda_executor({matrix.rows,matrix.rows,matrix.offsets,matrix.columns,matrix.values},options.cuda_device,options.preconditioner);
    auto b=device->allocate(matrix.rows), x=device->allocate(matrix.rows), residual=device->allocate(matrix.rows), w=device->allocate(matrix.rows);
    device->upload(rhs,*b);device->fill(*x,0);
    ResidentLinearResult result;
    const double magnitude=device->norm(*b);
    if(magnitude==0){result.linear.solution.assign(matrix.rows,0);result.linear.converged=true;result.transfers=device->metrics();return result;}
    // Normalize Arnoldi vectors, but retain RHS units in the small least-squares
    // problem. Normalizing the entire RHS can make 1/A overflow even when b/A
    // is finite for a very small physical coefficient.
    const auto divide=[&](DeviceVector& vector,double denominator){
        if(denominator<std::numeric_limits<double>::min()){
            device->scale(1.0/std::numeric_limits<double>::min(),vector);
            device->scale(std::numeric_limits<double>::min()/denominator,vector);
        } else device->scale(1.0/denominator,vector);
    };
    const auto m=static_cast<std::size_t>(std::min(options.restart,static_cast<int>(matrix.rows)));
    std::vector<std::unique_ptr<DeviceVector>> basis,preconditioned;
    for(std::size_t i=0;i<=m;++i)basis.push_back(device->allocate(matrix.rows));
    for(std::size_t i=0;i<m;++i)preconditioned.push_back(device->allocate(matrix.rows));
    while(result.linear.iterations<options.max_iterations) {
        device->apply(*x,*residual);device->scale(-1,*residual);device->axpy(1,*b,*residual);
        const double beta=device->norm(*residual);
        result.linear.residual=beta;
        if(beta/magnitude<=options.tolerance){result.linear.converged=true;break;}
        device->copy(*residual,*basis[0]);divide(*basis[0],beta);
        std::vector<std::vector<double>> h(m+1,std::vector<double>(m));
        std::vector<double> cosine(m),sine(m),g(m+1);g[0]=beta;
        std::size_t count=0;
        for(std::size_t j=0;j<m && result.linear.iterations<options.max_iterations;++j) {
            device->precondition(*basis[j],*preconditioned[j]);device->apply(*preconditioned[j],*w);
            for(int pass=0;pass<2;++pass)for(std::size_t k=0;k<=j;++k){
                const double coefficient=device->dot(*w,*basis[k]);h[k][j]+=coefficient;device->axpy(-coefficient,*basis[k],*w);
            }
            h[j+1][j]=device->norm(*w);const bool breakdown=h[j+1][j]==0;
            if(!breakdown){device->copy(*w,*basis[j+1]);divide(*basis[j+1],h[j+1][j]);}
            for(std::size_t k=0;k<j;++k){const double a=h[k][j],c=h[k+1][j];h[k][j]=cosine[k]*a+sine[k]*c;h[k+1][j]=-sine[k]*a+cosine[k]*c;}
            const double diagonal=std::hypot(h[j][j],h[j+1][j]);
            cosine[j]=diagonal>0?h[j][j]/diagonal:1;sine[j]=diagonal>0?h[j+1][j]/diagonal:0;
            h[j][j]=diagonal;h[j+1][j]=0;g[j+1]=-sine[j]*g[j];g[j]*=cosine[j];
            ++result.linear.iterations;count=j+1;
            if(std::abs(g[j+1])/magnitude<=options.tolerance || breakdown)break;
        }
        std::vector<double> y(count);
        bool singular=false;
        for(std::size_t row=count;row-- >0;){
            double value=g[row];for(std::size_t col=row+1;col<count;++col)value-=h[row][col]*y[col];
            if(h[row][row]==0){singular=true;break;}y[row]=value/h[row][row];
            if(!std::isfinite(y[row])){singular=true;break;}
        }
        if(singular)break;
        for(std::size_t j=0;j<count;++j)device->axpy(y[j],*preconditioned[j],*x);
    }
    device->apply(*x,*residual);device->scale(-1,*residual);device->axpy(1,*b,*residual);
    result.linear.residual=device->norm(*residual);
    result.linear.converged=result.linear.residual/magnitude<=options.tolerance;
    result.linear.solution=device->download(*x);
    for(double value:result.linear.solution)if(!std::isfinite(value))throw std::runtime_error("resident CUDA solution overflow");
    result.transfers=device->metrics();return result;
}
} // namespace raikou::backend
