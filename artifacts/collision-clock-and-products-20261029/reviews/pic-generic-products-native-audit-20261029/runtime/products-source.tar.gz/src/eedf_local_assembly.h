#pragma once
#include "raikou/electron_boltzmann.h"
#include "raikou/distributed.h"

namespace raikou::kinetics::detail {
struct EedfProcessQuadrature {
    std::size_t process{};
    double target_fraction{}, product_fraction{};
    std::vector<double> loss, superelastic_loss, energy_change;
};
struct LocalEedfAssembly {
    backend::RowPartition partition;
    int azimuthal_order{};
    backend::DistributedCsrMatrix collision;
    std::vector<double> mass;
    std::vector<unsigned char> padding;
    // Static grid and collision coefficients; no distribution/state vectors.
    std::vector<double> faces, centres, widths, dual_widths, m12, m32, dual_m12, recoil_face;
    std::vector<double> momentum; // owned energy cells
    std::vector<EedfProcessQuadrature> processes;
};
[[nodiscard]] LocalEedfAssembly assemble_local_eedf(const std::vector<CollisionProcess>&,
    const EedfConditions&, const EedfGrid&, backend::RowPartition mode_rows, int azimuthal_order = 0,
    bool normalized_real_harmonics = false);
}
