#include "raikou/runtime.h"
#include "raikou/backend.h"
#include "raikou/distributed.h"
#include <fstream>
#include <iostream>
#include <iterator>
#include <stdexcept>
#include <string>
#include <utility>
namespace {
bool failed(const raikou::Json& value) {
    if(value.is_object()) {
        for(const auto* key:{"success","converged","valid","ok"})
            if(value.contains(key) && value.at(key).is_boolean() && !value.at(key).get<bool>())return true;
        for(const auto& item:value.items())if(failed(item.value()))return true;
    } else if(value.is_array())for(const auto& item:value)if(failed(item))return true;
    return false;
}
std::string rank_path(const std::string& prefix,int rank){return prefix+"."+std::to_string(rank)+".json";}
raikou::Json read_file(const std::string& path){
    std::ifstream input(path);if(!input)throw std::runtime_error("cannot read "+path);
    return raikou::Json::parse(std::istreambuf_iterator<char>(input),std::istreambuf_iterator<char>());
}
void enable_mpi(raikou::Json& request,std::string_view operation) {
    const raikou::Json* selected=nullptr;
    if(request.contains("execution"))selected=&request.at("execution");
    else {
        const auto nested_execution=[&](const raikou::Json& parent)->const raikou::Json* {
            return parent.is_object()&&parent.contains("execution")?&parent.at("execution"):nullptr;
        };
        if(operation=="chemistry.advance"||operation=="chemistry.evaluate_distributed"||operation=="chemistry.advance_distributed") {
            if(request.contains("options"))selected=nested_execution(request.at("options"));
        } else if(operation.starts_with("eedf.")||operation=="breakdown.solve") {
            if(request.contains("conditions"))selected=nested_execution(request.at("conditions"));
        } else if(operation=="coupled.advance"&&request.contains("electron_closure")) {
            const auto& closure=request.at("electron_closure");
            selected=nested_execution(closure);
            if(!selected&&closure.is_object()&&closure.contains("conditions"))selected=nested_execution(closure.at("conditions"));
        }
    }
    if(selected&&!selected->is_object())throw std::invalid_argument("execution settings must be a JSON object");
    // Preserve the effective operation settings; the launcher changes only MPI.
    auto execution=selected?*selected:raikou::Json::object();
    execution["mpi"]=true;
    request["execution"]=std::move(execution);
}
}
int main(int argc,char** argv) {
    try {
        if(argc<2 || std::string(argv[1])=="--help") {
            std::cout<<"Raikou native research runtime\nUsage: raikou-native OPERATION [--input FILE|-] [--mpi]\n"
                "  --rank-input PREFIX       Read PREFIX.<rank>.json instead of shared input\n"
                "  --rank-output PREFIX      Save every rank's result as PREFIX.<rank>.json\n"
                "  --checkpoint-prefix PREFIX Resume spatial checkpoints from rank result files\n"
                "Owned operations on multiple MPI ranks require --rank-output.\n"
                "Use capabilities for the complete operation list.\n";
            return 0;
        }
        std::string path,input_prefix,output_prefix,checkpoint_prefix;
        bool mpi=false;
        for(int i=2;i<argc;++i) {
            const std::string option=argv[i];
            if(option=="--mpi")mpi=true;
            else if(option=="--input" && i+1<argc) path=argv[++i];
            else if(option=="--rank-input" && i+1<argc)input_prefix=argv[++i];
            else if(option=="--rank-output" && i+1<argc)output_prefix=argv[++i];
            else if(option=="--checkpoint-prefix" && i+1<argc)checkpoint_prefix=argv[++i];
            else throw std::invalid_argument("unknown or incomplete option: "+option);
        }
        if(!path.empty()&&!input_prefix.empty())throw std::invalid_argument("choose --input or --rank-input");
        raikou::backend::Runtime runtime(mpi);
        const int rank=raikou::backend::mpi_rank(),ranks=raikou::backend::mpi_size();
        const std::string operation=argv[1];
        if(mpi&&ranks>1&&operation.ends_with("_distributed")&&output_prefix.empty())
            throw std::invalid_argument("owned MPI operations require --rank-output PREFIX to preserve every rank's state");
        raikou::backend::ExecutionOptions execution;execution.mpi=mpi;
        const raikou::backend::DistributedHalo control(raikou::backend::distributed_partition(1,execution),{},execution);
        raikou::Json input_status={{"ok",true},{"request",raikou::Json::object()}};
        if(rank==0&&input_prefix.empty()) {
            try {
                if(!path.empty()) {
                    if(path=="-")std::cin>>input_status["request"];
                    else input_status["request"]=read_file(path);
                }
            } catch(const std::exception& e){input_status={{"ok",false},{"error",e.what()}};}
        }
        if(mpi&&input_prefix.empty())input_status=raikou::backend::broadcast_json(input_status,0,execution);
        if(!input_status.at("ok").get<bool>())throw std::runtime_error(input_status.at("error").get<std::string>());
        auto request=input_status.at("request");
        std::string input_error;
        try{
            if(!input_prefix.empty())request=read_file(rank_path(input_prefix,rank));
            if(!request.is_object())throw std::invalid_argument("request must be a JSON object");
            if(!checkpoint_prefix.empty()){
                const auto checkpoint=read_file(rank_path(checkpoint_prefix,rank));
                request.erase("local_initial");
                request["checkpoint"]=checkpoint.contains("checkpoint")?checkpoint.at("checkpoint"):checkpoint;
            }
            if(mpi)enable_mpi(request,operation);
        }catch(const std::exception& error){input_error=error.what();}
        control.collective_require(input_error);
        const auto result=raikou::execute(operation,request);
        const bool any_failed=control.global_max(failed(result)?1.:0.)>0;
        if(output_prefix.empty()){
            if(rank==0)std::cout<<result.dump(2)<<'\n';
        }else{
            std::string output_error;
            try{
                const auto destination=rank_path(output_prefix,rank);
                std::ofstream output(destination);if(!output)throw std::runtime_error("cannot write "+destination);
                output<<result.dump(2)<<'\n';output.close();if(!output)throw std::runtime_error("failed writing "+destination);
            }catch(const std::exception& error){output_error=error.what();}
            control.collective_require(output_error);
            if(rank==0){raikou::Json files=raikou::Json::array();for(int r=0;r<ranks;++r)files.push_back(rank_path(output_prefix,r));
                std::cout<<raikou::Json{{"operation",operation},{"success",!any_failed},{"ranks",ranks},{"rank_outputs",files}}.dump(2)<<'\n';}
        }
        return any_failed?1:0;
    } catch(const std::exception& e) { std::cerr<<"raikou: "<<e.what()<<'\n';return 2; }
}
