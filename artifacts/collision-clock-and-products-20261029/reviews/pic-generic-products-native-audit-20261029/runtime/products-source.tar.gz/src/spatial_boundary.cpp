#include "raikou/spatial_boundary.h"
#include <algorithm>
#include <cmath>
#include <numbers>
#include <stdexcept>

namespace raikou::spatial::boundary {
namespace {
constexpr double qe = 1.602176634e-19;
void require(bool valid, const char* message) { if (!valid) throw std::invalid_argument(message); }
}
SheathFlux evaluate_sheath(const Boundary::Sheath& closure, const chemistry::Species& species,
    double density_m3, double cell_potential_V, double wall_potential_V) {
    require(density_m3 >= 0 && std::isfinite(density_m3) && std::isfinite(cell_potential_V) && std::isfinite(wall_potential_V), "spatial boundary: invalid sheath state");
    require((closure.model == "maxwellian" || closure.model == "bohm") && species.mass_kg > 0 && std::isfinite(species.mass_kg) && closure.temperature_eV > 0 && std::isfinite(closure.temperature_eV) && closure.transmission >= 0 && closure.transmission <= 1 && std::isfinite(closure.transmission), "spatial boundary: invalid authored sheath closure");
    const double z = static_cast<double>(species.charge), barrier = z * (wall_potential_V - cell_potential_V);
    double speed = 0;
    if (closure.model == "bohm") {
        require(species.charge > 0 && closure.electron_temperature_eV > 0 && std::isfinite(closure.electron_temperature_eV), "spatial boundary: Bohm closure requires positive ions and electron temperature");
        require(barrier <= 1e-10 * closure.temperature_eV, "spatial boundary: Bohm outflow at an ion-repelling wall is inadmissible");
        speed = closure.transmission * std::sqrt(qe * (z * closure.electron_temperature_eV + closure.temperature_eV) / species.mass_kg);
    } else speed = closure.transmission * std::sqrt(qe * closure.temperature_eV / (2 * std::numbers::pi * species.mass_kg)) * std::exp(-std::max(0., barrier) / closure.temperature_eV);
    SheathFlux result; result.particles_m2_s = density_m3 * speed; result.density_derivative_m_s = speed;
    if (closure.model == "maxwellian" && barrier > 0) {
        result.wall_potential_derivative_m2_s_V = -result.particles_m2_s * z / closure.temperature_eV;
        result.cell_potential_derivative_m2_s_V = -result.wall_potential_derivative_m2_s_V;
    }
    require(std::isfinite(result.particles_m2_s) && std::isfinite(result.density_derivative_m_s) && std::isfinite(result.wall_potential_derivative_m2_s_V), "spatial boundary: nonfinite sheath flux");
    return result;
}
double drift_thermal_speed(const Boundary::Sheath& closure, const chemistry::Species& species, const Transport& transport) {
    const double temperature_eV = closure.temperature_eV > 0 ? closure.temperature_eV : transport.mobility_m2_V_s > 0 ? transport.diffusion_m2_s / transport.mobility_m2_V_s : 0;
    require(closure.model == "drift" && species.mass_kg > 0 && std::isfinite(species.mass_kg) && closure.transmission >= 0 && closure.transmission <= 1, "spatial boundary: invalid drift closure");
    require(temperature_eV > 0 && std::isfinite(temperature_eV), "spatial boundary: drift closure needs temperature_eV or a positive local D/mu");
    return closure.transmission * std::sqrt(qe * temperature_eV / (2 * std::numbers::pi * species.mass_kg));
}
IncomingTemplate normalize_incoming(const kinetics::SphericalEedfState& authored,
    const kinetics::Vector3& outward_normal) {
    authored.validate();
    require(authored.electron_density_m3() > 0 && std::isfinite(authored.electron_density_m3()), "spatial boundary: secondary incoming template needs positive electron density");
    const auto stride = static_cast<std::size_t>(authored.grid.legendre_terms * authored.grid.legendre_terms);
    for (std::size_t slot = 0; slot < static_cast<std::size_t>(authored.grid.cells); ++slot)
        require(authored.density_modes[slot * stride] >= 0, "spatial boundary: secondary incoming template has negative F00");
    auto zero = authored; std::fill(zero.density_modes.begin(), zero.density_modes.end(), 0);
    kinetics::KineticFace probe; probe.normal = outward_normal; probe.wall = kinetics::KineticWall::PrescribedIncoming; probe.incoming = authored;
    const auto stream = kinetics::kinetic_streaming_rhs({{1}, {probe}}, {zero});
    const double inward = -stream.face_particle_flux_m2_s[0];
    require(inward > 0 && std::isfinite(inward), "spatial boundary: secondary template needs a positive incoming number flux");
    IncomingTemplate result; result.mean_incoming_energy_eV = -stream.face_energy_flux_ev_m2_s[0] / inward;
    require(result.mean_incoming_energy_eV >= 0 && std::isfinite(result.mean_incoming_energy_eV), "spatial boundary: invalid incoming energy flux");
    result.per_unit_number_flux = authored;
    for (auto& mode : result.per_unit_number_flux.density_modes) mode /= inward;
    return result;
}
} // namespace raikou::spatial::boundary
