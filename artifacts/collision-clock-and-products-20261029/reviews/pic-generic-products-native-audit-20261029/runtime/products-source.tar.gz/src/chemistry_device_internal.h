#pragma once
#include "raikou/chemistry_device.h"

namespace raikou::chemistry::detail {
struct PackedNetwork {
    int cuda_device{-1};
    std::size_t species{},reactions{},phases{},energies{},cells{};
    std::vector<int> order_offsets,order_species,species_phase,energy_phase;
    std::vector<double> order_power,stoichiometry,energy_per_event_J;
    std::vector<double> coefficients,measures,volumes,densities;
    std::vector<unsigned char> nonnegative;
    std::vector<std::string> energy_keys;
};
struct PackedEvaluation {
    std::vector<double> sources,jacobians,progress,energy;
    backend::DeviceTransferMetrics transfers;
};
struct CellProgress {
    int code{};
    std::size_t accepted{},rejected{};
    double time{},step{};
};
struct PackedAdvance {
    std::vector<double> densities,energies;
    std::vector<CellProgress> progress;
    backend::DeviceTransferMetrics transfers;
};
PackedEvaluation evaluate_cuda_impl(const PackedNetwork&);
PackedAdvance advance_cuda_impl(const PackedNetwork&,double,const AdvanceOptions&);
}
