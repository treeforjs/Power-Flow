# Raikou

Raikou is a standalone C++20 research runtime for plasma chemistry, electron kinetics,
collisional-radiative calculations and electrostatic breakdown. Python is its scripting
interface. Quark consumes the same native SDK and supplies geometry, meshes and visualization.

Version 1.0 provides coupled chemistry, full angular electron kinetics, Poisson fields,
dielectric charging, circuits, phase heat and multigroup photons in 2D, axisymmetric RZ
and 3D. It includes owned-state MPI execution and explicit CUDA backends. See
[scope and qualification](docs/status.md) when choosing a model or backend.

## Build

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release --parallel
ctest --test-dir build -C Release --output-on-failure
cmake --install build --config Release --prefix ./install
```

MSVC, GCC and a C++20 standard library are supported. Configure from a native compiler
environment on Windows. MPI and NVIDIA CUDA are explicit build options:

```sh
cmake -S . -B build-mpi -DRAIKOU_ENABLE_MPI=ON
cmake -S . -B build-cuda -DRAIKOU_ENABLE_CUDA=ON -DCMAKE_CUDA_ARCHITECTURES=86
```

Use an architecture matching the target GPU. MPI must supply headers, a library and a
launcher for the same implementation. No CUDA request silently falls back to CPU.

## Call the runtime

```sh
raikou-native capabilities
raikou-native chemistry.advance --input examples/aqueous_reference_advance.json
mpiexec -n 4 raikou-native linear.solve --input problem.json --mpi
mpiexec -n 4 raikou-native spatial.solve_distributed --input model.json --mpi --rank-output result
```

The native executable takes an operation and a JSON request. Requests and responses use
SI particle-number units (density in m^-3), with electron energies in eV. `--input -`
reads stdin. `capabilities` reports the compiled and available backends. The legacy
five-level hydrogen CLI remains available as `raikou` in the SDK.

```sh
python -m pip install .
python -m raikou capabilities
```

```python
import raikou
print(raikou.capabilities())
result = raikou.execute("linear.solve", {
    "matrix": {"rows": 2, "offsets": [0, 2, 4],
               "columns": [0, 1, 0, 1], "values": [2, -1, -1, 2]},
    "rhs": [1, 1], "execution": {"device": "cpu", "threads": 2}
})
assert result["converged"]
```

Python wheels build the native extension; they contain no alternate Python numerical
solver. A host using MPI owns MPI initialization, communicator lifetime and collective
call ordering. The native `--mpi` CLI initializes and finalizes MPI itself.

The C++ SDK exports `Raikou::raikou`, the C ABI exports `Raikou::c`, and the public JSON
entry points are `raikou::execute` and `raikou_execute_json`. Free C ABI output with
`raikou_free_string`. Typed interfaces are in `include/raikou`.

See [Python usage](docs/python.md), [local kinetic coupling](docs/coupling.md) and
[spatial input](docs/spatial.md) for callable functions and complete requests.
`batch.execute` partitions independent requests over MPI ranks and local worker threads;
individual jobs select their device and must not issue nested MPI collectives.

## Chemistry and data

`mechanisms/` contains source-cited N2/O2/H2O, aqueous-water and interface research
templates. Most reaction coefficients and electron cross sections must be supplied by
the user. A limited aqueous reference subset includes explicitly sourced coefficients.
Missing rate data fails explicitly. Coverage metadata distinguishes included channels,
required imports and unresolved closures. Gas electron cross sections do not define
aqueous-electron kinetics.

The newer Quark multi-term Boltzmann solver is imported with source hashes in
`provenance/eedf_import.json`. LXCat text imports are accepted; restricted cross-section
datasets are not redistributed here. Numerical tests establish implementation behavior,
not experimental validation of a plasma mechanism.

Quark can consume an installed SDK with `find_package(Raikou 1.0 CONFIG REQUIRED)` or
build a separate source checkout with `QUARK_RAIKOU_SOURCE_DIR`. Raikou does not depend
on Quark, MOOSE or a Zapdos subprocess.

Third-party notices and source ownership are recorded in [NOTICE](NOTICE).
The [v1 acceptance record](docs/v1-completion.md) documents numerical checks and
the [compatibility contract](docs/api-compatibility.md) covers the C ABI and restart data.
