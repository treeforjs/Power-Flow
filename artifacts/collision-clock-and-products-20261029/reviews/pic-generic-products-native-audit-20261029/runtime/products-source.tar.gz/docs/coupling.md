# Coupled local electron kinetics and chemistry

`coupled.advance` advances one spatially uniform cell with a shared backward-Euler
nonlinear solve. Species populations, every retained electron Legendre mode, and
requested gas/liquid temperatures converge before a state is returned. The electric
field magnitude is supplied by the caller; this operation does not solve Poisson or
electrode circuitry. The spatial solver has its own field and transport equations.

Run the manufactured numerical example from the repository root:

```sh
raikou-native coupled.advance --input examples/coupled_cell.json
mpiexec -n 2 raikou-native coupled.advance --input examples/coupled_cell.json --mpi
```

The cross sections and 2 eV ionization threshold in this example are deliberately
synthetic. They verify coupling behavior and must not be used as nitrogen data.

## State and reaction ownership

`electron_closure` supplies `processes` (or `lxcat_text`), `grid`, and the kinetic
`electron_species`. Its optional `gas_density_m3` sets the reference N; when omitted,
N is the current total gas heavy-particle density. Every residual evaluation rebuilds
target fractions from the current chemistry inventory. Initially absent ions and
excited states retain their collision channels and activate when populated.
The selected kinetic species must be element-free gas electrons with charge -1 and
the physical electron mass when supplied (within one part per million). Negative ions and additional
free-electron populations cannot stand in for gas electrons or heavy collision targets.

Collision labels bind to reactions with `rate.type="electron_eedf"`. Superelastic
reactions use `collision_label="<forward label>.reverse"`. Reactive targets map to
exactly one species, directly or through `targets:{"collision target":"species id"}`.
The bridge checks gas-volume basis, two-body reactants/orders, electron counts,
named excited-state products, and each channel's `n_e n_target k` event rate.
Resolved aggregate targets may be summed for elastic scattering; reactive aggregates
need explicit state-specific channels. Missing or contradictory bindings fail.

The electron density equation is replaced by the F0 number moment. Electron energy
is the discrete F0 energy moment. Chemistry never integrates either a second electron
collision source or a second electron energy equation. Reactions creating/removing
electrons without a kinetic collision operator are rejected in this operation.
Non-collision transfers into or out of `gas/electron` or `gas/electrons` energy
reservoirs are also rejected until a distribution source operator can represent them.
Distribution sources for photoionization, emission, or injection remain separate work.

Results contain `state`, the complete restartable `electrons` state, `environment`,
nonlinear convergence diagnostics, and separate operator/chemistry energy diagnostics.
For another step, copy these three state objects back into the request, remove
`initial_mean_energy_ev`, and retain the mechanism and collision configuration.
The initial chemistry electron count must agree with its kinetic number moment.
All caller-owned inputs remain unchanged when a nonlinear/linear solve fails.

## Phase temperatures and energy

Temperatures remain prescribed unless the caller supplies phase heat capacities in
J/(m3 K). No material heat capacities or empirical liquid closures are guessed:

```json
{
  "options": {
    "heat_capacity_J_m3_K": {"gas": 1000, "aqueous": 4000000},
    "thermal_reservoirs": {"gas": ["gas/heavy"], "aqueous": ["aqueous/heavy"]}
  }
}
```

These numbers illustrate input syntax, not calibrated properties. Gas elastic energy
transfer comes from the EEDF operator and is included once automatically. Selected
chemistry reservoir powers enter their own phase temperature equations. Internal
excitation/ionization reservoirs are not automatically converted into heat; explicit
reaction energy partitions describe their relaxation. `gas/electron` and
`liquid/electron` reservoirs cannot be selected for thermal equations. Any chemistry
electron-energy metadata is diagnostic; kinetic collision moments own electron energy.
Every selected chemistry reservoir must exist in a mechanism energy partition;
unknown names and duplicate entries fail. Authored heavy chemistry heat, including
`gas/translation`, adds once alongside the distinct automatic EEDF elastic transfer.
Cross-phase rates use the chemistry module's explicitly supplied phase volumes and
interface areas. Hydrated electrons remain liquid species with separate chemistry.
The shipped water mechanisms name that phase `aqueous`; use matching `aqueous/...`
reservoirs and `phase_volumes_m3.aqueous`. Both `liquid` and `aqueous` refer to
`environment.liquid_temperature_K`. Selecting both as separate thermal unknowns is
rejected because the environment currently stores one liquid temperature.

## Vector fields and spatial distribution transport

`SphericalEedfState` retains all `L*L` real spherical-harmonic coefficients about a
fixed laboratory basis. The spherical average normalization is `R00=1`,
`R11=sqrt(3)*x`, `R1,-1=sqrt(3)*y`, `R10=sqrt(3)*z`. Energy slots store even
degrees on energy cells and odd degrees on energy faces. A proper rotation mixes
only modes of the same degree, preserving this staggering and the exact F00
number/energy moments. Conversion back to an axisymmetric Legendre state rejects
any significant azimuthal modes. The convention is a real phase convention of the
[NIST DLMF spherical harmonics](https://dlmf.nist.gov/14.30).

`eedf.advance_spherical` and `eedf.evaluate_spherical` accept physical Cartesian
`electric_field_V_m` vectors. Electron acceleration follows `-E`. All azimuthal
modes survive a field-direction change. Restart metadata identifies the angular
basis and staggering; an axisymmetric slice cannot replace a full restart.

The typed `advance_spatial_kinetics` API solves vector-field acceleration,
collisions, and conservative distribution streaming in one implicit BE/BDF block.
`SpatialKineticCell` supplies the outer chemistry/temperature trial and field.
Electron feedback uses its solved distribution and updates every target population;
no steady EEDF is substituted. `KineticMesh` supplies physical gas volumes and face
areas, with specular, absorbing, or prescribed incoming kinetic walls. An absent
electron phase has zero distribution and explicit walls at gas/absent contacts.

The face operator uses half-range upwind spherical-harmonic fluxes and a shared
energy overlap with its mass adjoint. Interior number/energy fluxes are equal and
opposite, including unequal cell volumes. Cylindrical RZ adds the conservative
angular geometry term in the local `(radial, azimuthal, axial)` basis; the inverse
radius is the finite volume average `2*pi*meridional_area/physical_volume`, including
cells touching the axis. The geometric term has identically zero F00 rows.

## Parallel execution and scope

`execution.device` selects `cpu` or `cuda`; `threads`, `mpi`, and `communicator_f`
control native execution; `cuda_device` optionally selects a process-local device.
Embedded callers own MPI initialization/finalization.

`advance_distributed_spatial_kinetics` owns contiguous spatial cells. Prognostic
distributions, assembled sparse rows, and Krylov vectors remain rank-local;
neighboring distributions cross a dependency halo. Geometry and collision tables
may replicate. Production assembles frozen nonlinear collision, field, streaming,
and RZ coefficients on CPU, then uses native distributed CPU or resident CUDA
Krylov algebra. The returned converged vector crosses the device boundary for
physics evaluation; Krylov iterations do not copy the full vector to the host.
The optional matrix-free CPU Newton path is a separate verification reference.

The single-cell owned-energy API in `eedf_distributed.h`, also exposed by
`eedf.solve_distributed` and `eedf.advance_distributed`, partitions the energy/mode
rows of one large Legendre system and uses local Landau prefix/suffix reductions.
Legacy local `coupled.advance` and Legendre compatibility wrappers retain their
replicated layout and host kinetic solver. Select the owned interfaces when memory
scaling across ranks matters.

`coupled.advance` remains the spatially uniform Legendre compatibility operation.
Use full spherical spatial kinetics for arbitrary 2D/3D field directions and
distribution transport. Its finite angular expansion does not guarantee pointwise
positivity in velocity angle. Electron-electron collisions retain the imported
isotropic Landau closure. Electromagnetic waves and experimentally validated liquid
breakdown closures are not supplied by this local operation.

Numerical tests cover analytic angular relaxation, electron/ion event agreement,
evolving composition, phase energy balances, rollback, restart, and CPU/MPI/CUDA
agreement. Full angular tests also cover harmonic orthogonality/parity, rotation
composition/covariance, turned-field memory, exact CSR/RHS parity including Coulomb
terms, manufactured streaming gradients, closed/open boundary moment balances,
RZ equilibrium, one implicit collision/transport residual above explicit CFL, and
MPI empty ranks. Experimental mechanism validation remains separate.
