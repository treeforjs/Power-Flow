# Spatial plasma runtime

The `spatial.solve` operation advances cell-centred species densities, electrostatic potential, dielectric surface charge and an optional series RC circuit in one nonlinear system. Optional heavy temperature and photon groups participate in the same residual and acceptance decision. All inputs use SI particle-number units; densities are particles per cubic metre of the species' own phase.

## Run the manufactured cases

```sh
raikou-native spatial.solve --input examples/manufactured/spatial_2d.json
raikou-native spatial.solve --input examples/manufactured/spatial_3d.json
python -m raikou spatial.solve --input examples/manufactured/spatial_2d.json
mpiexec -n 2 raikou-native spatial.solve --mpi --input examples/manufactured/spatial_3d.json
```

The two examples configure synthetic ionization, drift/diffusion, heating and photon absorption. Their reaction and transport coefficients are manufactured numerical data. They demonstrate coupled execution and are not water, nitrogen or air calibration.

```python
import json
import raikou

with open("examples/manufactured/spatial_2d.json") as source:
    request = json.load(source)
result = raikou.execute("spatial.solve", request)
assert result["success"], result["message"]
# Continue with the entire accepted state, BDF history and diagnostic ledgers.
request["checkpoint"] = result["checkpoint"]
request["time"]["end_time_s"] = 2e-9
resumed = raikou.execute("spatial.solve", request)
assert resumed["success"], resumed["message"]
```

A checkpoint contains both accepted states, their timestep, dielectric/circuit values, temperatures, photons, kinetic modes when enabled, and integral histories. The physical request must match its saved definition. End time, timestep limits, tolerances and execution backend may change. Checkpoint fields are validated rather than silently repaired.

## Mesh and boundaries

Structured 2D uses `shape: [nx, ny, 1]` and `extent_m: [Lx, Ly, depth]`; depth is physical. Structured axisymmetric 2D sets `axisymmetric: true`, uses x=r and y=z, and integrates the full revolution. Cartesian 3D uses all three dimensions. Cell ordering is x fastest, then y, then z.

Supplied meshes accept `nodes_m`, `cells` of type tri3/quad4/tet4/hex8, and explicit `boundary_faces`. Each boundary face lists its node IDs and a side label 0..5 (xmin, xmax, ymin, ymax, zmin, zmax). Labels select boundary conditions; they need not describe the geometric normal. Supplied 2D meshes lie in the XY plane and use `depth_m`.

Supplied cells must be convex with planar faces and positive volume. True volume centroids and conservative least-squares multipoint corrections support nonorthogonal meshes, including obtuse simplices. One corrected face flux enters neighbouring cells with opposite signs. The electrostatic method is affine exact on homogeneous material patches. Face coefficients use normal-distance-weighted harmonic interpolation; the continuous-gradient correction does not guarantee exact transmission across skew discontinuous materials. Nonplanar hexahedral faces are rejected. Material/photon corrections use `solver.nonorthogonal_correction_limiter` (default 2; zero explicitly disables it).

Boundaries are reflecting `insulating`, fixed-potential `electrode`, or `dielectric` with a backing voltage, `capacitance_F_m2` and evolving `initial_surface_charge_C_m2`. Each dielectric face has an independent potential satisfying the conservative Robin condition. Set `absorbing: true` to collect particles on electrodes/dielectrics. Absorbing insulating boundaries are rejected because they have no charge owner. Poisson requires an electrode or capacitively anchored dielectric.

An absorbing wall may supply `sheaths`, each with `species`, `model`, `temperature_eV` and `transmission`. These temperatures are explicitly prescribed wall-closure parameters. `maxwellian` uses the half-Maxwellian number flux with an electrostatic repelling barrier. `bohm` additionally requires positive ions and `electron_temperature_eV`; an ion-repelling wall rejects that model's assumption. A second fluid sheath law for kinetic electrons is rejected because their distribution already owns the boundary flux. `drift` carries the wall cell's density out with its drift toward the wall (none when the field drives it away) plus `transmission` times the one-way thermal flux of a Maxwellian at `temperature_eV`, or at the local characteristic energy D/mu when `temperature_eV` is 0. Without a closure an absorbing wall holds the density at zero, so secondary electrons emitted where the field drives them away partly diffuse straight back, and the share returned grows as the wall cell shrinks; under `drift` with zero transmission every such electron enters the gas on any grid.

`secondary_emission` lists authored `{incident_species, emitted_species, yield}` channels. A nonnegative yield multiplies the actual incident gas-ion flux, and emitted gas electrons enter with negative outward flux. Plasma, surface charge, circuit current and collection ledgers use that same flux. Fluid electrons require explicit `secondary_energy_eV` for the external wall supply ledger. Spherical electrons instead use `electron_boundary.kind: "secondary_emission"` and a full authored `incoming` distribution. Its exact discrete incoming number flux normalizes the template, and its actual energy moment enters kinetic streaming. `Boundary/secondary_energy_supply` records wall-supplied energy rather than adding a second heat source. No material-dependent yield curve is invented.

An optional `circuit` specifies `driven_side`, `source_voltage_V`, `initial_voltage_V`, `series_resistance_ohm` and `external_capacitance_F`. The Poisson terminal charge supplies the gap capacitance; do not add the same capacitance again as an external capacitor. Zero resistance represents an ideal source.

## Background conduction and host material changes

Serial `spatial.solve` can additionally own a conducting material with
`electrical: {"phase": "rock", "ohmic_conductivity_S_m": [...],
"initial_ohmic_charge_C_m3": [...]}`. Both arrays accept a scalar; initial
charge defaults to zero. Conductivity is the effective bulk coefficient in S/m,
already including the host's phase weighting. The named phase must exist and
cannot also own charged drift-diffusion or kinetic carriers. An absent phase
cannot carry conductivity or Ohmic charge. A neutral material placeholder is
sufficient. MPI compatibility and owned distributed solves reject this extension
explicitly; the supported coupled path invokes one serial solve on its host root.

The additional signed bulk charge obeys the same BDF1/BDF2 continuity equation as
the time integrator. It is eliminated analytically into Gauss's law, with identical
oriented face currents updating both neighbours and the shared circuit. Interior
conductivity uses series normal resistances; dielectric currents accumulate on
the retained free surface charge. The timestep estimator includes Ohmic charge
with absolute tolerance `elementary_charge * absolute_density_tolerance_m3`.
There is one potential and one circuit, including displacement current.

The result and checkpoint state expose `ohmic_charge_C_m3`. Result
`ohmic_heating_J` is a per-cell cumulative integral for this solve/restart history;
`ohmic_heating_W_m3` is the final accepted step's instantaneous density (empty if
no step was accepted). `ohmic_charge_collected_at_boundaries_C` counts signed
charge leaving through electrodes, excluding charge retained on dielectrics.
The checkpoint retains both charge states and both heat/current integral histories.
The host deposits the **increment** of this heat integral into the conducting
material once. It is not also included in gas thermal sources. History reports
`ohmic_work_W`, `ohmic_terminal_current_A`, and `ohmic_charge_C`; chemical energy
ledgers distinguish `Electrical/ohmic_work` from `Electrical/particle_work`.

Heat is conservative face work `I * (phi_a - phi_b)`, partitioned by the two
normal resistances. On nonorthogonal cells the multipoint gradient and cell
potential difference need not have the same sign. A materially negative summed
material-cell dissipation triggers an explicit mesh-validity stop and preserves
the previous accepted state. No heat is clipped. This is a validity restriction,
not a proof that every supplied mesh has an energy-positive operator. The
independent positive reconstruction `sum(sigma * |E_cell|^2 * cell_volume)` is
reported as `history.ohmic_reconstructed_work_W`, and its difference from face
work as `ohmic_work_discrepancy_W`. Its integrated diagnostic is
`Electrical/ohmic_field_reconstruction_work`; it is never an additional heat
source. Hosts must include this discrepancy in mesh/outer-step acceptance and
convergence checks. The native regression includes a skew TRI3 conductivity layer.

For a zero-time host update use `spatial.reconfigure` (Python
`raikou.reconfigure_spatial`) with exactly:

```python
{"previous_problem": last_request, "checkpoint": last_result["checkpoint"],
 "problem": new_request}
```

The new request supplies remapped intrinsic gas densities, phase fractions,
permittivity and bulk solid Ohmic charge, plus updated conductivity and host
temperatures. Mesh/species identity and boundary/circuit charge ownership must
remain unchanged. Each charged-species inventory and the total Ohmic charge must
be preserved; this operation is not a chemical or charge-injection source. Full
angular/EEDF and photon remapping are not implemented and are rejected. Static
steady electron closures are supported. Surface free charge is retained.

The response contains `checkpoint`, `potential_V`, `driven_voltage_V`,
`ohmic_charge_C_m3` and `audit`. Local time, BDF order and cumulative heat/current
ledgers restart at zero for the new slice. The checkpoint definition matches the
new request exactly. For finite source resistance, driven electrode charge plus
external-capacitor charge is retained at zero elapsed time, even when the new
EMF differs. Ideal voltages instead deliver an explicitly reported displacement
charge/work impulse.

The audit follows a defined path: first charge advection at old permittivity and
terminal settings, then permittivity change at fixed advected charge, then an
affine ideal-voltage change. `source_work_impulse_J` uses fixed voltage times
charge change for the first two stages, and average old/new voltage times charge
change for the final stage. This defines a reversible voltage-ramp convention;
it does not invent unresolved switching-circuit dissipation. Field energy uses
the discrete Gauss pairing, including dielectric backing capacitance; it differs
from the legacy reconstructed-cell `history.field_energy_J` on general meshes.
External-capacitor energy is reported separately. `charge_advection_work_J` and
`material_polarization_work_J` sum to `material_work_J`, positive for work supplied
by host mechanics to the field. `energy_balance_residual_J` exposes the remaining
ideal-voltage-switch defect. `joule_heat_impulse_J` is zero. A unique per-cell
mechanical work partition is not claimed (`per_cell_material_work_available` is
false). The host must resolve the opposite material work through a mechanical
force/work adapter or stop; discarding it would violate the coupling's energy
accounting.

Validation on 2026-10-25: all 35 CTest cases passed, including local BDF/Gauss
charge balance, dielectric accumulation, joint drift-diffusion/Ohmic terminal
current, analytic RC charging, restart/rejection, forged-checkpoint ownership,
finite-R/ideal-V material updates and a skew TRI3 conductivity layer. A bounded
cross-project test also used the retained `single40_coarse.e` geometry (SHA-256
`151e0e1b9d6b52ce3412b656e0ee946bf00b7bfb987d9f3d13d85852a4b908b3`):
3,058 cells, 762 gas cells, insulating pore, rock conductivity `1e-5 S/m`,
rock permittivity `4 epsilon_0`, 10 V behind 20 ohm, and one `1e-10 s` step.
Zero-field and energized tests both accepted one step with no rejection. The
energized result had nonnegative cell heat, `9.907156300084034e-14 J` total
face work, `9.90858182037264e-14 J` reconstructed work (relative discrepancy
`1.44e-4`), and a global charge defect of `-2.35e-31 C`. This is a manufactured
conduction/geometry check, not plasma-breakdown or moving-fracture validation.

## Chemistry and electron closure

`heavy_barycentric_pair: {"neutral": "N2", "ion": "N2+"}` optionally
interprets authored drift/diffusion transport in the neutral reference frame and
transforms it to the host heavy-mass barycentre. It requires identical heavy
nuclei/molecular mass for the pair, neglects electron mass in the mass average,
and permits only these two heavy species plus electrons in their phase. Neutral
authored mobility/diffusion must be zero. Ion masses with their expected missing
electron mass are accepted and treated as the same heavy molecular mass.

At each face, let `N = n_neutral + n_ion`, with all intrinsic densities taken
from the same upwind donor in the frame-shift direction `-j_ion_raw`, and let
`u_c = j_ion_raw / N`. The corrected fluxes are
`j_ion = j_ion_raw - n_ion*u_c`, `j_neutral = -j_ion`, and
`j_e = j_e_raw - n_e*u_c` for each electron species. One aperture multiplies
all fluxes in this phase. The raw Scharfetter–Gummel flux and all composition
ratios are differentiated in the Newton Jacobian on the chosen upwind branch
(the first face cell is the one-sided donor at zero raw ion flux). This prevents
counterflow from drawing particles from a depleted receiving cell. Summing the two heavy
equations therefore preserves each cell's heavy count through BDF integration;
no neutral density is reconstructed or reset after transport. Every reaction
must preserve the pair's total heavy count. Absorbing contacts are rejected until
a wall mass-recycling model is supplied, and owned/MPI or transient kinetic
frame transforms are explicitly unsupported.

This is the common mass-average frame transformation; the electron number flux
must transform even when electron **mass** is neglected. Total current changes
by `-rho_q*u_c` and is invariant for a quasineutral face. This convention should
not be confused with Cantera IonFlow's separate convention that preserves
already-authored charged fluxes and adjusts neutral fluxes. See the primary
[Cantera governing equations](https://testing.cantera.org/stable/reference/onedim/governing-equations.html#diffusive-fluxes).

Electrical work and any explicitly selected Joule thermal sources use the
corrected currents. The steady local-field elastic/inelastic collision sources
remain unchanged. History exposes `neutral_frame_particle_work_W`,
`barycentric_frame_work_W` (corrected minus raw field work),
`collisional_heavy_heating_W` (the selected reaction/elastic heavy thermal
reservoirs), and `particle_field_minus_collisional_heating_W`. Integrated
diagnostics are `Electrical/neutral_frame_particle_work`,
`Electrical/barycentric_frame_work`, and `Thermal/collisional_heavy_heating`.
These diagnostics are not additional heat sources, and their difference need
not vanish when chemistry or untracked electron energy stores energy. The host
must retain that energy audit and its material/ionization validity limits; this
option does not supply a full multicomponent enthalpy-transport model or justify
extending a neutral-gas EEDF table to highly ionized conditions.

The followup native regression suite has 36 passing CTest cases. Independent
tests reconstruct ion/electron face balances and thermal work, verify the
`-rho_q*u_c` current change and quasineutral cancellation, and exercise BDF2
restart, balanced chemistry, counterflow depletion and active wall ownership.
A manufactured 1 ps step on the same 3,058-cell Exodus mesh, with heavy density
`2.4e25 m^-3`, ion fraction `1e-6`, fixed transport coefficients and conducting
rock, preserved every gas cell's heavy count to maximum relative error
`3.58e-16` with no rejected steps. It includes absorbing outer electrodes with
zero gas contact. This checks mesh/transport integration, not EEDF or moving-host
physics. The tested immutable native library SHA-256 is
`2c5cba12f7d9ca5280977783c01a48878d02f183700205e5942cd01f5a215530`.

Every species can have explicitly configured mobility and diffusion in `transport`; omitted species coefficients are zero. Internal face fluxes are conservative Scharfetter–Gummel fluxes. Evolving chemistry uses the compiled mechanism and its analytic concentration Jacobian.

With `electron_closure.mode: "steady_boltzmann"`, collision targets are rebuilt from the current named species and target aliases on every nonlinear trial. Boltzmann rates and electron transport are updated with the trial field magnitude and heavy temperature. A single collision label binds each EEDF reaction; `strict_event_mapping: true` rejects missing inelastic chemistry mappings. Chemistry owns electron number in this closure. Each cell's steady solve continues from that cell's last converged distribution (`solver.eedf_warm_start`, default true): it starts at the pseudo time step a cold solve converges at and falls back to the cold solve if it has not converged in 20 iterations. The closure reads only the isotropic transport and the rates, so the continued solve also leaves out the density-gradient (bulk) transport terms. On a 64-cell N2 gap this runs the closure 2.4 times faster with the same steps and fields equal to 5e-13; `false` restores the cold solve.

`electron_closure.mode: "local_field_table"` is the local field approximation used by fluid discharge codes such as Zapdos. Steady Boltzmann swarms are solved once, before the time loop, at the listed `reduced_fields_td` (strictly increasing, at least two) under `table_conditions` (`gas_temperature_K`, optional `gas_density_m3`, and the target `fractions`). Every nonlinear residual then reads each cell's rates, mobility, diffusion and energy loss at its own E/N, interpolated geometrically in log E/N (linearly where neighbouring values change sign) and clamped at the table's ends; ionization and attachment frequencies are rebuilt per unit density from the cell's own target fractions. The table does not follow the cell's composition or heavy temperature beyond that, and has no electron-electron collisions. Tables are cached in process by their definition (up to 16), so repeated solves with the same closure skip the sweep. On a 460-cell N2 mesh this replaces about 5 ms of steady solve per gas cell per step.

In both steady closures, an inelastic rate that is negative only by roundoff in the distribution's far tail (no larger in magnitude than 1e-12 of the largest rate in the cell) is set to zero and counted in the diagnostics; at zero field such rates reached -1e-43 and stopped the solve. Larger negative rates are still rejected.

The `transient_boltzmann` closure retains every density-weighted Legendre mode in each cell. Supply `fixed_field_axis` as a unit vector and `initial_mean_energy_eV`; use `time.bdf2: false` and `strict_event_mapping: true`. Local kinetic backward-Euler solves are eliminated inside each spatial nonlinear residual using the same immutable accepted old state. The kinetic F0 moment replaces the electron-number residual; the mapped collision source is not integrated twice. All modes commit only when the full spatial residual converges.

The local Legendre closure requires explicitly zero electron mobility/diffusion and rejects a rotated or reversed field. For general transient geometry, select `transient_spherical`. It retains every real spherical harmonic, with L-squared angular coefficients per energy slot. Collision, arbitrary vector-field acceleration and conservative spatial streaming enter one implicit kinetic block in Cartesian 2D/3D or cylindrical RZ. Supply positive `initial_mean_energy_eV`, zero fluid electron transport and strict event mapping. The F00 moment owns electron number, so mapped collision sources are not integrated twice. Electron-producing reactions outside a mapped collision or explicit distribution source operator are rejected.

Spherical checkpoints use the shared public `real_spherical_harmonics` format with exact basis and energy staggering metadata. Every m coefficient is retained in both BDF histories. F00 must be nonnegative in every energy cell; current and previous clocks, grids, density and energy moments are checked even when no further step is requested. Lossy projection to a Legendre slice is rejected. `electron_boundary` selects absorbing, specular or a full prescribed incoming distribution. `electron_phase_contacts` gives a sharp gas/aqueous face an explicit non-gas `absorbed_species` charge owner and optional receiving thermal phase.

## Phase and energy semantics

A single-phase mechanism fills each cell. `phase_fractions` maps every material phase to a scalar or per-cell field in [0,1], summing to one. Zero-volume phases have exactly zero populations. Without this map, multiple phases use uniform ratios from `environment.phase_volumes_m3`. Densities remain per own-phase volume, while charge and particle inventories include the phase fraction. Geometry is static; hydrodynamics, phase motion and an EOS are outside these equations. `environment.interface_areas_m2` specifies total domain subcell interface areas allocated by cell volume, preserving total area under refinement. Resolved sharp interfaces use `face_reactions` binding an existing authored interface-area reaction to two phases. Reactants are evaluated in their actual owner cells, with physical face area and receiving phase volume. No Henry coefficient or surface rate is invented.

The optional `thermal` equation evolves one common heavy temperature or separate models in `thermal.phases`. Each model supplies `heat_capacity_J_m3_K`, Fourier `conductivity_W_m_K`, `initial_temperature_K`, optional `heating_W_m3` and `heat_reservoirs`. Capacity and heating are per total cell volume for a common model, or own-phase volume for separate models. `interface_heat_transfer` supplies an explicit interphase conductance in W/(m2 K), with equal-and-opposite heat transfer. `heat_reservoirs` selects chemistry partitions; unknown names and duplicate owners reject. `joule_species` selects fluid currents heating the heavy reservoir; EEDF elastic heating is separately opt-in through `use_eedf_elastic_heating`. Independent heavy-reaction enthalpy can coexist with elastic heating. Exterior thermal walls are adiabatic.

Each optional `radiation` group evolves photon number with configured photon energy, speed, diffusion and background absorption. This is multigroup photon diffusion, not angular radiative transfer. Groups have distinct energy reservoirs. Closed photon boundaries are default; `escaping_sides` imposes zero exterior photon density. Background absorption deposits its photon energy in the heavy thermal equation when enabled. A group's `absorbers` binds parameter-rate reactions to cross sections: the local rate is speed × cross section × photon density. Each bound reaction must debit exactly one photon from that group's energy reservoir; its chemistry energy partition determines where the energy goes. Reservoirs cannot feed multiple photon groups or both photons and thermal energy.

Serial results expose `thermal_energy_integrals_J`, a map from thermal phase name to signed physical joules per mesh cell. The empty key `""` identifies the common-temperature model. This ledger integrates the actual assembled thermal sources and transfers with the accepted state's BDF weights, including selected Joule heating, chemistry, EEDF elastic heating, radiation absorption, Fourier flux and interface exchange. It remains nonzero for sources too small to resolve by subtracting baseline temperatures. The sum over all phases and cells matches the independently integrated `chemical_energy_integrals_J["Thermal/net_energy"]`; separately exported Ohmic material heat is not included again.

`thermal_energy_residual_bound_J` has the same ownership and shape. It bounds the difference between integrated thermal source energy and thermal storage change using the accepted unscaled residual and arithmetic roundoff. The bound propagates through the zero-stable BDF first-difference recurrence, with nonnegative increments. It is a numerical audit budget, not an additional energy source. Check `thermal_energy_ledger.available` before consuming these maps: a distributed thermal advance marks the cumulative history unavailable, and serial continuation preserves that status. Unavailable maps are empty and `Thermal/net_energy` is omitted rather than exporting a partial integral. A zero-step MPI initialization has known-zero histories; a no-step MPI restart preserves supplied histories.

Checkpoint schema 3 retains both current maps and their `previous_thermal_energy_integrals_J` / `previous_thermal_energy_residual_bound_J` histories, with `thermal_energy_ledger_available` recording availability across backend changes. Restart preserves the cumulative origin; `spatial.reconfigure` explicitly starts a new origin with all four maps zero. A host consuming an available restarted interval subtracts its checkpoint's cumulative source energy once. Schema 3 checkpoints claiming available history must contain all four valid maps; missing or partial histories are rejected. Legacy schema 1/2 thermal checkpoints without these histories can resume physical state with availability false, because temperature alone cannot reconstruct unresolved source energy. Nonthermal legacy checkpoints remain supported.

For separate temperatures, `absorption_m1_by_phase` assigns background photon absorption and heat to explicit thermal phases; ambiguous common opacity is rejected. History reports nonlinear residual and temporal error, particle/surface charge, field energy, total charged-particle electric work, heavy thermal energy, photon energy and kinetic electron energy. `gas_charge_C` is a legacy name for all material phases. Collection ledgers are signed, so emission or injection can give negative counts. Chemistry partitions, supplied wall/radiation/electrical powers and EEDF operator moments have distinct ledger names; operator diagnostics are not additional heat sources. Consistent material energy partitions must be authored explicitly.

## Time integration and execution

Backward Euler starts the fluid solve; variable-step BDF2 follows when enabled. By default `time.adaptive: true` compares a converged full step with two converged half steps, using the variable-BDF2 defect multiplier. Species, potential, temperatures, photons, surface charge, circuit voltage and all kinetic modes participate in error control. `time.time_step_s` is the maximum step. Temporal settings are separate from Newton tolerances: `time.relative_tolerance`, `absolute_density_tolerance_m3`, `temperature_tolerance_K`, `potential_tolerance_V` and `surface_charge_tolerance_C_m2`. Set `adaptive: false` to compare a prescribed discrete schedule. Rejected trials never mutate the accepted state, kinetic modes, ledgers or BDF history. A prefix rerun ending before the initial maximum timestep may take a different initial rejection sequence; an actual checkpoint retains the accepted schedule.

Newton uses scaled sparse systems and a positivity-preserving line search. EEDF material sensitivities are frozen in the linearization, while rates and kinetic distributions are recomputed for every full residual. Thermal derivatives use an admissible one-sided perturbation at a rate validity boundary. Nonlinear failure or excessive temporal error reduces the timestep. Reaching the minimum timestep or attempt limit returns `success: false` with the last accepted prefix. Accepted nonlinear residuals and normalized temporal errors are at most one under their declared tolerances.

`solver.linear_solver` selects the Newton, field-predictor and electrostatic initialization/reconfiguration solves: `"krylov"` (default) or `"direct"`, a sparse LU factorization (Eigen's SparseLU with COLAMD ordering) of the assembled system. The direct solver is serial and needs a build that found Eigen 3 at configure time; otherwise the request is rejected. On 2D unstructured meshes of a few thousand cells the Krylov iteration count grew roughly with the square of the cell count, and the direct solve was three times faster at 4242 cells.

`solver.preconditioner: "auto"` selects block ILU(0) on CPU and CUDA; explicit Jacobi remains available. Fluid outer-system storage counters and retained kinetic/kinetic-halo counters are reported separately. Compatibility checkpoints gather both accepted histories; direct owned APIs and rank-local CLI files avoid those output gathers.

Top-level `execution` overrides solver execution settings: `device: "cpu" | "cuda"`, `threads`, `mpi`, optional Fortran communicator `communicator_f` and process-local `cuda_device`. The launcher owns MPI lifetime with `--mpi`; embedding callers own lifetime and collective ordering. All ranks enter the same solve. With MPI, compatibility `spatial.solve` partitions its caller-supplied fields, runs owned assembly and gathers the final state. The typed and JSON `solve_distributed` interfaces retain owned state and sparse rows throughout, including thermal, photon, circuit and full angular kinetic coupling. Static geometry and model metadata can be replicated. CUDA keeps linear algebra resident on the device while physics assembly runs on the host; see [distributed execution](distributed.md) for the storage contract.
