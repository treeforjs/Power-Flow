# Partitioned linear algebra and chemistry

Include `raikou/distributed.h` for the C++ owned-row API. The embedding host
initializes MPI, then sets `ExecutionOptions::mpi=true` and optionally supplies
`MPI_Comm_c2f(comm)` in `communicator_f`. An operator duplicates this communicator;
release retained operators before finalizing MPI. Collective calls must have the
same order on every rank and run on an MPI-permitted host thread.

`distributed_partition(global_rows, options)` returns a balanced interval.
Applications can instead supply their own rank-ordered contiguous intervals,
including empty intervals. Together the intervals must cover `[0, global_rows)`.
`DistributedCsrMatrix` contains only that interval's rows; its column indices are
global IDs. Construct the matrix directly from local physics assembly:

```cpp
raikou::backend::DistributedCsrMatrix matrix;
matrix.global_rows = partition.global_rows;
matrix.row_begin = partition.row_begin;
matrix.offsets = local_row_offsets;
matrix.columns = global_column_ids;
matrix.values = local_coefficients;
raikou::backend::DistributedLinearOperator op(std::move(matrix), execution);
auto answer = op.solve(local_rhs);
// answer.local_solution contains partition.local_rows entries.
```

Setup replicates only rank ownership metadata. Each matvec sends requested
neighbor entries using nonblocking point-to-point MPI; it does not gather the
global vector. FGMRES stores local Krylov vectors and reduces scalar inner
products/norms. CPU preconditioners are `jacobi` and `block_ilu0`, the latter an
ILU(0) of each rank's owned diagonal block. CUDA uses resident local matrix,
Krylov vectors and Jacobi or block ILU(0) preconditioning, staging indexed halo buffers through
host memory for MPI. `cuda_device=-1` retains the caller's current device; an
explicit ordinal may differ per rank. Launchers may also set
`CUDA_VISIBLE_DEVICES` per rank.

CUDA ILU(0) factors and triangular dependency levels are prepared once on the
host when the matrix is created. Forward/back substitution stays on the GPU;
one resident block processes independent rows at each level without launching
a separate kernel per level. No solution or residual vector is transferred for
preconditioning. A singular owned block fails explicitly.

`DistributedHalo` supports application-owned state. Requested global IDs become
unique sorted ghosts; `compact_index(id)` maps owned entries first, then ghosts.
`exchange(local_values)` returns only ghosts. `global_sum`, `global_max`, and
`exclusive_sum` supply scalar moments and prefix sums. `collective_require`
propagates a rank's local validation failure before the next communication phase.
Applications must call it on every rank, passing an empty string on success.

The legacy `solve_csr` accepts replicated input for compatibility, partitions
its Newton/Krylov work, then gathers the final solution once. Its input arrays
remain the caller's responsibility. `make_csr_operator` also retains the legacy
full-vector signature, so each callback gathers its output. Use the owned-row
API to avoid those compatibility boundaries. `gather_distributed` is an explicit
final-result helper and is not called inside the typed solver.

Include `raikou/chemistry_distributed.h` for owned-species CR chemistry.
`DistributedState` pairs a row partition with only owned species densities,
using mechanism indices as global IDs. `evaluate_distributed` assembles owned
production rows and a sparse owned-row Jacobian from required reactant halos.
`advance_distributed` keeps state, residuals, scales, Jacobian rows and Newton
vectors local throughout adaptive implicit integration. Global scalar error
norms and line searches synchronize time steps. A failure returns every rank's
original local state, zero advanced time and no integrated energy, including
failures after earlier accepted steps. Reservoir energy sums use a unique owner
for each reaction to avoid counting it once per rank.

Static mechanism, species flags and environment metadata may be replicated.
Reaction ownership is co-located with a participating species to keep sparse
reaction chains' halos sparse. Reaction/rate assembly currently runs on the CPU;
`device="cuda"` selects resident distributed Newton linear solves. Independent
cell GPU chemistry has a separate resident batch implementation.

`tests/test_distributed.cpp` and `tests/test_distributed_chemistry.cpp` exercise
serial and 1/2/4-rank execution, empty ownership, sparse storage, asymmetric
validation failures, convergence, energy/inventory conservation and rollback.
MPI/CUDA variants exercise the same owned-row contracts when CUDA is built.

Include `raikou/eedf_distributed.h` for a single energy-grid EEDF distributed
over ranks. `distributed_eedf_partition` aligns intervals to complete energy
cells. `DistributedEedfState::density_modes` stores only that interval, in the
legacy even-then-odd Legendre packing. `freeze_eedf_operator` assembles local
collision/field rows plus recoil and one physical frozen Landau flux; it does
not construct or slice a global dense matrix. Landau integrals use scalar
prefix/suffix moments. Static grid/cross-section metadata is shared, while
distribution values and solve vectors remain local with dependency halos.

The JSON/Python operations `eedf.solve_distributed` and
`eedf.advance_distributed` return local mode arrays and global scalar swarm
diagnostics. Their `swarm.energy_ev` and `swarm.eepf` arrays contain only owned
energy cells. `state.row_begin` identifies the first global packed mode row;
`state.energy_cell_begin` identifies the first energy cell. Restart data must
declare schema version 1 and representation
`axisymmetric_legendre_owned_energy_cells`. The full spherical representation
uses a separate API. See `examples/distributed_eedf.py` for a two-step restart
without gathering the solution.

All ranks must enter the same operation with valid, consistent `mpi` and
`communicator_f` control fields. The owned JSON operations propagate remaining
parse/validation errors to all ranks before numerical collectives. Regression
tests exercise a malformed state, mechanism, thread count, and device value on
one rank, then verify that a later valid call succeeds on the communicator.

EEDF transient/steady collision and field solves use the selected CPU or resident
CUDA linear backend. Hydrodynamic gradient diffusion calculations currently use
the owned CPU matrix-free solver to retain the exact scalar-moment Landau
derivative and density constraint without a dense global matrix. This host work
is part of the declared hybrid CUDA execution scope.

## Owned spatial state

JSON decoding failures are synchronized before a numerical collective begins.
All participating callers must still provide valid, consistent MPI/communicator
bootstrap controls and invoke the same operation. Hosts must collectively
validate serialization before entering the native API: a Python serialization
exception or malformed raw C JSON can occur before the runtime can discover the
communicator. The API does not initialize MPI or infer another communicator
after an invalid bootstrap request.

`spatial.solve_distributed` (Python `solve_spatial_distributed`) and the typed
`spatial::solve_distributed` interface partition contiguous cells. Each cell's
species, potential, thermal and photon rows stay together. Dielectric face
unknowns follow their cell owner; the circuit unknown has one owner. Static
mesh and material metadata may be shared. Global diagnostics are scalar
reductions; the operation does not gather the evolving fields.

Shared `initial_densities_m3` values must be scalars. The optional
`local_initial` object supplies this rank's `cell_begin`, `cell_count`, and
owned arrays. `densities_m3` maps species IDs to arrays, `potential_V` is an
array, and `temperature_K` is the common-temperature array. For separate
thermal phases use `phase_temperatures_K`; for radiation use
`photon_densities_m3`, keyed by group ID. All arrays have exactly `cell_count`
entries. Intervals across ranks must cover the mesh once, without overlap.

The response contains named owned fields plus a raw state with representation
`owned_cell_dof_v1`, `global_rows`, `row_begin`, `local_rows`, `cell_begin`,
`cell_count`, `owned_values`, and full local `spherical_electrons`. The
`storage` object reports local/halo fluid unknowns, separate
`local_kinetic_unknowns` and `kinetic_halo_unknowns`, and peak local fluid
matrix/state entry counts. These counters describe numerical storage, not
total process memory or replicated static geometry. Only the circuit owner
receives `owned_circuit`.

For the owned spatial API, `accepted_steps` and `rejected_steps` count work
performed by the current call; `checkpoint.accepted_steps` retains the
cumulative accepted count used by BDF restart. The replicated compatibility
API preserves its cumulative `accepted_steps` convention.

To resume, remove `local_initial` and pass this rank's returned `checkpoint`.
The checkpoint includes current/previous BDF states, adaptive step history,
and local charge/energy ledgers. All ranks must resume together with the same
ownership and physical definition. Time/solver/execution settings are not part
of the immutable physical definition. Global prognostic arrays and incompatible
checkpoint representations fail explicitly.

The native CLI preserves owned results with per-rank files:

```sh
mpiexec -n 4 raikou-native spatial.solve_distributed --mpi --input model.json --rank-output step1
mpiexec -n 4 raikou-native spatial.solve_distributed --mpi --input longer-model.json --checkpoint-prefix step1 --rank-output step2
```

The first command writes `step1.0.json` through `step1.3.json` and prints a
small manifest. The second loads each rank's checkpoint and advances to the
new end time. `--rank-input PREFIX` instead reads complete rank-specific
requests from `PREFIX.<rank>.json`. File prefixes may contain paths; their
parent directories must exist. On multi-host MPI runs, make the required
files available on each rank's host. Owned operations on multiple ranks
require `--rank-output`; they cannot silently discard all but rank zero.

The owned path couples Poisson, species transport, chemistry, dielectric charge,
circuit voltage, phase temperatures, photons, authored face reactions and full
angular electron kinetics. It uses the same wall and interface laws as the
compatibility API. Kinetic modes and their BDF histories remain owned by their
cell; only boundary dependencies and scalar convergence measures communicate.
`spatial.solve` with MPI adapts replicated caller input to this solver and
gathers its final result for compatibility. Use `spatial.solve_distributed` to
avoid that replicated input/output contract.
