# Python API and JSON command line

Install a platform wheel with `python -m pip install path/to/raikou.whl`. To
build from this repository, run `python -m pip install .` with a C++20 compiler
and CMake 3.24 or newer available. The build backend installs its Python build
dependencies automatically. A source install compiles the native extension;
Python does not implement a separate numerical solver.

The default wheel builds CPU support. Build optional backends explicitly:

```sh
python -m pip install . --config-settings cmake.define.RAIKOU_ENABLE_MPI=ON
python -m pip install . --config-settings cmake.define.RAIKOU_ENABLE_CUDA=ON
```

These options require the corresponding native development toolchains and
runtime libraries. Inspect `raikou.capabilities()` to distinguish a backend
that was built from one currently available on the host.

## Python scripting

Use ordinary Python, dictionaries and functions. Every request is passed to the
native runtime through the packaged `raikou._core` extension. A source checkout
can instead load its JSON C ABI by setting `RAIKOU_LIBRARY` to the full path of
`raikou_c.dll`, `libraikou_c.so` or `libraikou_c.dylib`.

```python
import raikou

print(raikou.capabilities())
result = raikou.linear_solve(
    matrix={"rows": 2, "offsets": [0, 2, 4],
            "columns": [0, 1, 0, 1], "values": [4, 1, 1, 3]},
    rhs=[1, 2],
    execution={"device": "cpu", "threads": 1},
)
if not result["converged"]:
    raise RuntimeError(result)
print(result["solution"])
```

The explicit wrappers take a request dictionary, keyword fields, or both.
Duplicate fields are rejected. The generic `execute(operation, request)` uses
the same native operations:

| Python function | Native operation |
| --- | --- |
| `capabilities()` | `capabilities` |
| `execute_batch(jobs, execution=None)` | `batch.execute` |
| `linear_solve(...)` | `linear.solve` |
| `validate_mechanism(mechanism)` | `mechanism.validate` |
| `evaluate_chemistry(...)` | `chemistry.evaluate` |
| `advance_chemistry(...)` | `chemistry.advance` |
| `evaluate_chemistry_batch(...)` | `chemistry.evaluate_batch` |
| `advance_chemistry_batch(...)` | `chemistry.advance_batch` |
| `evaluate_chemistry_distributed(...)` | `chemistry.evaluate_distributed` |
| `advance_chemistry_distributed(...)` | `chemistry.advance_distributed` |
| `solve_eedf(...)` | `eedf.solve` |
| `advance_eedf(...)` | `eedf.advance` |
| `evaluate_spherical_eedf(...)` | `eedf.evaluate_spherical` |
| `advance_spherical_eedf(...)` | `eedf.advance_spherical` |
| `solve_eedf_distributed(...)` | `eedf.solve_distributed` |
| `advance_eedf_distributed(...)` | `eedf.advance_distributed` |
| `advance_coupled_cell(...)` | `coupled.advance` |
| `water_levels(...)` | `water.levels` |
| `solve_breakdown(...)` | `breakdown.solve` |
| `solve_spatial(...)` | `spatial.solve` |
| `solve_spatial_distributed(...)` | `spatial.solve_distributed` |

Native exceptions are exposed as `raikou.RaikouError`. Numerical failure fields
are preserved: inspect `success`, `converged`, `message` and solver diagnostics
where present. Mechanism validation returns `valid=False` with errors. A result
dictionary alone does not establish convergence or physical adequacy.

A chemistry batch shares one `mechanism` and takes `cells=[{"state": ...,
"environment": ...}, ...]`. An omitted cell environment uses the request's
common `environment`. `dt_s` and `options` apply to the whole batch. CPU batches
use `execution.threads`; CUDA batches retain cell densities, reaction progress,
Jacobians, Newton work and adaptive integration state on the GPU. Temperatures
and external coefficients are prescribed for each local interval. Results include
per-cell status and transfer-byte measurements. Failed cells roll back independently.
For distributed groups of independent cells, use these calls inside `batch.execute`
jobs; individual cell batches do not issue MPI collectives.

`execution.cuda_device` selects a process-local CUDA ordinal for resident chemistry
and linear solves. The default `-1` uses the caller's current device. MPI callers
may select different ordinals on different ranks, or use launcher-assigned
`CUDA_VISIBLE_DEVICES`. An unavailable ordinal fails rather than selecting another GPU.
The repository benchmark `tools/benchmark_chemistry.py` measures native cell batches
with CPU thread counts and CUDA; its conserved isomer network is manufactured.

For one large CR system, the distributed calls take `state.densities_m3` as a
rank-local array in global mechanism order. `state.row_begin` defaults to the balanced
partition for the supplied communicator; an explicit start allows another contiguous
partition. Ranks must cover all species once, in communicator order. The host initializes
MPI and calls the same operation collectively with the same mechanism, environment and
options. Use `execution.mpi=true` and optionally `communicator_f`. Each result retains
only local state/Jacobian rows and reports its row offset and halo size; it does not gather
a global state. The ordinary `advance_chemistry` MPI compatibility call accepts and returns
a global state, with partitioning and one final gather at the API boundary.

`examples/distributed_chemistry.py` demonstrates the owned-state call from `mpi4py`.
Use an MPI-enabled Raikou binary and a `mpi4py` build using the same MPI runtime,
then launch it with `mpiexec -n 4 python examples/distributed_chemistry.py`.
The example checks global conservation and gathers only small ownership diagnostics.

The wheel includes starter mechanisms and their provenance:

```python
print(raikou.available_mechanisms())
mechanism = raikou.load_mechanism("aqueous_reference_subset")
report = raikou.validate_mechanism(mechanism)
assert report["valid"], report["errors"]
```

`load_mechanism` reads packaged data. Review each starter's status, coverage and
missing rate requirements before simulating a particular material or experiment.
EEDF transient checkpoints retain every angular mode in the returned `state`;
pass that state to `advance_eedf(..., state=checkpoint, dt_s=...)` to continue.

Full-angular calls use the same collision/process inputs with a physical
`electric_field_V_m=[Ex,Ey,Ez]` vector. Omit the scalar `reduced_field_td` for these
calls. Initialize with `initial={"electron_density_m3": ..., "mean_energy_ev": ...}`
or pass the complete returned `state`. Checkpoints identify the real spherical
basis and retain `grid.cells * grid.legendre_terms**2` coefficients, so a changed
field direction does not erase azimuthal anisotropy. `evaluate_spherical_eedf`
returns the instantaneous full-mode RHS; `advance_spherical_eedf` advances it.
Legacy axial checkpoints and mismatched basis conventions are rejected by this API.

The legacy hydrogen API remains available: `PlasmaState`, `evaluate`, `rates`,
`FitPriors`, `fit_vuv_shot`, `SparkState`, `SparkConfig` and
`step_spark_discharge`. These models retain their separate physics assumptions.

## CLI

The installed `raikou` command and `python -m raikou` accept a native operation
followed by `--input FILE`. Use `--input -` for stdin, and `--pretty` to indent
the result. Numerical results go to stdout as JSON; command errors go to stderr
with a nonzero exit code.

Numerical/validation failures keep their JSON diagnostics on stdout and return
exit code 1, including failed jobs inside a batch. Invalid requests and loading
errors return exit code 2.

```sh
raikou --version
raikou capabilities --pretty
raikou water.levels --input water.json
raikou chemistry.advance --input examples/aqueous_reference_advance.json
python -m raikou eedf.solve --input examples/eedf_import.json
raikou spatial.solve --input examples/manufactured/spherical_kinetics_3d.json
```

`water.json` can contain `{"j_max":2}`. Legacy commands `evaluate`, `rates`,
`fit`, `step` and its alias `spark` accept the same JSON input option. Help and
version queries do not require loading a native library.

The 3D spherical example is a small manufactured elastic-transport control:
eight spatial cells and all nine real angular modes on each energy grid. Its
cross section is explicitly a numerical input, not a physical gas dataset.
Spatial output uses the same spherical state representation as the local
`evaluate_spherical_eedf` and `advance_spherical_eedf` functions. In an inactive
phase with zero electron density, `mean_energy_ev` is `null`; the zero density,
energy and full mode array remain available.

## MPI and external runtime libraries

Python bindings do not initialize MPI. An embedding host must initialize MPI
before passing `mpi: true` in the operation's native execution settings. A host
can pass its Fortran communicator handle using `communicator_f`. All collective
participants must call the native operation consistently. Loading an MPI-enabled
library alone does not enable distributed execution.

The separately installed native executable owns MPI initialization when launched
with `--mpi`, for example:

```sh
mpiexec -n 2 raikou-native linear.solve --input system.json --mpi
```

`--mpi` changes only MPI selection. It preserves the operation's effective
execution settings, including supported nested chemistry, EEDF and electron
closure settings. An explicitly supplied top-level `execution` object keeps
its precedence over those nested settings.

On Windows, put external dependency directories in `RAIKOU_DLL_DIRECTORIES`,
separated by semicolons. The loader also registers existing directories from
`PATH` and the packaged `raikou/lib` directory. For example:

```powershell
$env:RAIKOU_DLL_DIRECTORIES = 'C:/path/to/MPI/bin;C:/path/to/CUDA/bin'
```

When `mpi4py` loads MS-MPI from a nonstandard installation, also set
`MSMPI_BIN` to that MPI directory before importing `mpi4py.MPI`. Raikou's
loader settings do not configure another package's loader.

These loader settings locate libraries; they do not initialize MPI or request a
CUDA solve. An explicitly selected missing library raises an error without
silently choosing another installation.

## Build and installation checks

```sh
python -m pip wheel . --no-deps --wheel-dir dist
python tests/test_runtime_python.py --wheel dist/raikou-VERSION-PLATFORM.whl
```

The wheel smoke test creates a fresh virtual environment, installs only the
selected wheel, imports the compiled extension, checks the legacy C library and
console script, then runs the runtime numerical/CLI tests outside the source
directory. For a source build, set `RAIKOU_LIBRARY` and run
`python tests/test_runtime_python.py` and `python tests/test_python.py`.
