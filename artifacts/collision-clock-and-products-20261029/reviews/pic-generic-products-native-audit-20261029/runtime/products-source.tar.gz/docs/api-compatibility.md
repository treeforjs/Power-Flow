# API and binary compatibility

The C++ library, C ABI, Python package and native CLI use the same runtime and
version. Query `raikou_version()` or the `capabilities` operation to identify
the library actually loaded. Header version macros identify the SDK used when
compiling a caller.

The v1 C ABI preserves existing function signatures, status values and public
structure layouts within the 1.x series. Additive operations do not change an
existing structure's size. An incompatible native interface requires a new
entry point or a major version. ELF builds set the shared C library's major
SONAME; Windows builds use `raikou_c.dll`. A caller must free JSON output with
`raikou_free_string` from the same loaded library.

The C++ SDK is a static library. Build consumers with a compatible compiler,
standard library, build mode and dependency toolchain; rebuild them when
changing that toolchain or upgrading the SDK. C++ object layouts are not a
cross-compiler binary interface. `Raikou::raikou` carries its MPI/CUDA link
dependencies, while `Raikou::c` exposes the shared C ABI.

JSON operations retain their documented field units and representation names.
Restart data carries a schema version and the complete state needed by its
solver, including angular modes and time-step history. Unsupported schemas,
different physical definitions and lossy changes of electron representation
are rejected. Checkpoints are numerical state, not a promise that changing a
model or solver tolerance will reproduce a previous trajectory bit for bit.

Python functions and the CLI forward to native operations. They do not replace
a missing native solver or unavailable CUDA device. Inspect numerical
`success` or `converged` fields before accepting a result. Invalid requests
raise Python errors or return C status/error data; a failed physical solve
retains its available numerical diagnostics.

An embedding host owns MPI initialization, communicator lifetime and collective
call ordering. All ranks participating in an operation must supply valid,
consistent MPI control and compatible shared physical metadata. Owned APIs
accept local fields; compatibility APIs may accept replicated fields and
gather a final result. Release retained MPI objects before finalizing MPI.
The standalone `--mpi` executable manages initialization for its process.
