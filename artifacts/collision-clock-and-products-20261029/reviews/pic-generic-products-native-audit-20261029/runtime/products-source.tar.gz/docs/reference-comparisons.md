# Source-pinned reference comparisons

Raikou separates manufactured numerical tests, comparisons with another solver,
and experimental validation. None can substitute for the other two.

The [Zapdos verification paper](https://doi.org/10.1016/j.cpc.2023.108837) supplies
the context for the initial external reference. The repository manifest
`provenance/zapdos_reference.json` pins a specific upstream commit, input, material
tables, boundary operators and stored Exodus result. `tools/fetch_reference.py`
downloads these into an ignored cache and checks each Git blob digest. It does not
run downloaded code or include it in Raikou binaries. The upstream license is
downloaded alongside the data. Review its terms before redistributing the cache.

```sh
python tools/fetch_reference.py
python tools/verify_zapdos_poisson.py --output build-references/poisson-comparison.json
```

The comparison reader requires NumPy and SciPy, separately from runtime dependencies.
It reads the final RF snapshot, reconstructs upstream log-molar charge at Raikou cell
centers, and solves the resulting fixed-charge Poisson problem. It accounts explicitly
for the upstream normalized coordinate, kV output and rounded physical constants in
the pinned `include/base/Zapdos.h`. Reported errors compare the resulting voltage with
the upstream finite-element potential interpolant. The default finest-grid tolerance
is 0.1% relative L2. The upstream finite mesh limits this comparison's refinement;
manufactured solutions test formal convergence separately.

This verifies the electrostatic operator on a discharge-derived charge distribution.
It does not advance that discharge, compare its chemical kinetics or boundary current,
validate air/water chemistry, or establish agreement with an experiment. The manifest
retains that distinction until a matched coupled case is actually run.
