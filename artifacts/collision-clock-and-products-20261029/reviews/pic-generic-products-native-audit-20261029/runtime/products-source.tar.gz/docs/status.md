# V1 scope and numerical qualification

Raikou 1.0 is a standalone research runtime for coupled electrostatic plasma evolution.
Numerical qualification demonstrates solver behavior; it does not establish the
accuracy of a particular gas, liquid, or interface mechanism.

| Area | V1 implementation | Application responsibilities and limits |
|---|---|---|
| Interfaces | C++ typed APIs, versioned C JSON ABI, native CLI, Python extension and scripting facade; Windows/Linux SDK and wheel installation | Use matching MPI runtimes and compatible C++ toolchains |
| Chemistry | Arbitrary species, reactions and phases; analytic mass-action Jacobian; tabulated, Arrhenius, expression, EEDF and parameter rates; adaptive implicit integration; phase volume and interface area accounting | Physical mechanism data remain case-specific inputs |
| EEDF | Multi-term energy solver, nonlinear isotropic Landau collisions, owned energy-grid MPI state, full real spherical modes, vector fields, conservative implicit spatial streaming and cylindrical correction | Collision cross sections, angular/energy resolution and validity of the chosen closure |
| Spatial | Planar 2D, RZ and 3D; convex triangle/quad/tet/hex geometry; nonorthogonal Poisson and bounded transport; drift/diffusion, dielectric charge, circuit, phase temperatures, photons and sharp contacts | Static geometry; supplied material coefficients; affine exactness applies to homogeneous patches |
| Boundaries | Authored absorbing, reflecting and incoming distributions; Maxwellian/Bohm fluid closures; constant-yield secondary emission with discrete incoming-flux normalization | Material-dependent yields and incoming energy distributions |
| Restart | Full angular state, BDF history, adaptive controller state, model checks, boundary and energy ledgers; per-rank CLI checkpoints | Same ownership and physical definition when resuming an owned run |
| CPU | Explicit threads; reusable OS workers on Windows; bounded native workers on Linux | Thread count and MPI placement appropriate to the host |
| MPI | Owned sparse rows, local Krylov vectors, dependency halos, FGMRES/Jacobi/block ILU(0); owned CR, EEDF and fully coupled spatial state | Geometry/model metadata can be replicated; compatibility APIs retain global input/output |
| CUDA | Resident FP64 CSR, Krylov and triangular preconditioning; halo-only MPI staging; resident independent-cell chemistry integration | Coupled physics assembly runs on the CPU; distinct multi-GPU hardware was not available for qualification |
| Research data | Source-cited N2/O2/H2O, aqueous and interface templates; coverage reports; limited sourced aqueous coefficients; explicit errors for absent data | User-selected cross sections, rate data and experimental validation |

CUDA execution is hybrid. Independent-cell fixed-environment chemistry keeps
reaction evaluation, Jacobians, Newton updates and adaptive integration on the
device. Coupled EEDF and spatial assembly run on the CPU and send sparse linear
systems to resident GPU solvers. CUDA ILU(0) setup is on the host; its repeated
triangular application remains on the device. Selecting CUDA never silently
substitutes a CPU linear solve. `capabilities` describes these execution layers.

The owned MPI interfaces retain only local evolving fields, matrix rows and
vectors, plus necessary ghosts. Static geometry, mechanisms and cross-section
tables may be shared. Compatibility APIs accept replicated input and can gather
the final output. Use the owned APIs to avoid those input/output allocations.

The full spherical spatial mode retains every azimuthal coefficient when the
field rotates. The legacy Legendre mode has axial symmetry and its documented
fixed-axis restrictions. Spatial dimension and angular resolution are separate
choices. Multigroup photon diffusion is not an angular radiation solver.
Material properties and electron collision data are explicit inputs; the runtime
does not infer them from a species name. Quark retains geometry generation,
visualization, mechanics and fluid motion.

## Qualification

Tests cover analytic/manufactured Poisson refinement, Scharfetter-Gummel
equilibria, nonorthogonal meshes, particles and dielectric charge, circuit
coupling, reaction Jacobians, phase energy and photon accounting, angular
rotation and streaming, nonlinear Landau invariants, adaptive time accuracy,
transactional failure and restart equivalence. CPU, MPI rank-count and actual
CUDA comparisons exercise the same equations. A source-pinned Zapdos comparison
qualifies the fixed-charge Poisson operator; it does not validate a complete
discharge mechanism.

The [acceptance record](v1-completion.md) lists the release tests, reference
comparison, ownership measurements and package checks. Individual measurements
apply to their recorded build and hardware; they are not universal scaling claims.

Experimental validation and uncertainty depend on the imported mechanism and
application. Manufactured examples are labeled explicitly and supply no physical
validation. Full electromagnetic waves, MHD, cavitation hydrodynamics and a
universally validated aqueous breakdown closure are outside this runtime's
electrostatic/quasistatic scope.
