# Raikou 1.0 qualification record

Raikou v1 provides a standalone C++20 runtime with C, Python and JSON CLI
interfaces. Quark calls the same runtime in process. The coupled spatial path
includes chemistry, Poisson fields, dielectric surface charge, an external RC
circuit, phase temperatures, multigroup photons, authored interface reactions,
and full spherical-harmonic electron kinetics in Cartesian 2D/3D and cylindrical RZ.

## Numerical acceptance

The final Windows MSVC MPI/CUDA build passed all 102 CTests. The strict GCC
CPU build passed all 34 CTests. Installed Python wheels are checked separately
against the 26-test runtime/API suite in fresh environments.

The test suite exercises analytic reaction kinetics and Jacobians, conservative
phase and face accounting, Poisson/transport stencils on structured and convex
unstructured meshes, all angular modes and rotations, nonlinear Landau invariants,
wall emission, circuit charge, thermal/photon energy, adaptive rollback, and full
current/previous-state restart. Owned MPI tests use 1, 2 and 4 ranks, including empty
partitions, rank-asymmetric invalid inputs and recovery on the same communicator.
Actual CUDA tests include two MPI ranks sharing the available GPU.

Reproducible checks are included in the repository:

| Check | Command or test | Observed result |
|---|---|---|
| Coupled reaction/diffusion/Poisson refinement | `python tools/verify_spatial_refinement.py` | Spatial orders 1.99 and 2.00; BDF2 time orders 1.98 and 1.99; CPU, MPI4 CPU and MPI2 CUDA agree |
| Full angular temporal and streaming refinement | `raikou.kinetic_refinement` | Backward Euler order 0.99; BDF2 order 2.02; upwind spatial streaming order 1.00 |
| Coupled gas/aqueous contact, phase heat, photons and RC | `python tools/verify_coupled_interface.py` | Particle, charge, thermal and total-energy balances; both energy destinations and complete BDF restart |
| Source-pinned Zapdos Poisson comparison | `python tools/verify_zapdos_poisson.py --device cpu` (also `cuda`) | Relative L2 error 0.000333591 on 256 cells, below the 0.001 bound |
| External SDK consumers | `python tests/sdk/smoke.py --prefix <install>` | Pure C and C++ consumers, CLI, operation errors and packaged third-party licenses |
| Python package | `python tests/test_runtime_python.py` with `RAIKOU_TEST_INSTALLED=1` | Installed native extension, Python API, data packages and failure reporting |
| Quark integration | `ctest --test-dir build-raikou-integration -R quark.engine.raikou` | In-process 3D chemistry/Poisson dispatch and failed-result diagnostics |

The Zapdos reference is pinned at
`d76e0a2653b6d594cca444b79bd34d49f02b6a4a`; downloaded file hashes are checked.
This comparison freezes the reference charge and tests the electrostatic operator.
It does not compare a complete discharge trajectory. All manufactured tests above
use explicit synthetic coefficients and provide numerical verification only.

## Audit regression coverage

The audit repairs retain public signatures, physical units and checkpoint schemas.
The following regressions run inside the existing test targets, so the number of
CTest targets alone does not describe the added coverage.

| Finding | Corrected behavior | Regression coverage |
|---|---|---|
| R001 | Interpret reservoir aliases before kinetic energy guards and thermal selection; retain authored spelling | Chemistry CPU/device/distributed and coupled-cell tests |
| R002 | Quark provisions an immutable Raikou dependency in source and SDK workflows | Quark integration and adapter tests; authenticated hosted qualification requires `RAIKOU_READ_TOKEN` |
| R003 | Propagate malformed linear, batch and legacy JSON fields before numerical collectives | Serial, MPI 1/2/4, split communicators, same-communicator recovery, threaded jobs and CLI rank files |
| R004 | Electron-ion angular damping follows the harmonic degree | Independent per-degree/per-azimuth RHS, frozen operator and backward-Euler decay checks |
| R005 | Liquid thermal defaults use liquid temperature in every spatial path | Separate phase temperatures, explicit overrides and initial energy |
| R006 | Reject simultaneous liquid/aqueous thermal owners | Local, serial, owned and MPI compatibility validation |
| R007 | Campaign adapter preserves the selected installed Python package | Quark isolated-import regression with built and unavailable sibling packages |
| R008 | Validate transient and spherical chemistry using conserved electron temperature | Independent discrete-moment oracle and narrow valid/excluded rate tables |
| R009 | Nearly balanced electron sources use a gross-activity error budget | Reaction permutations, balanced/near-balanced sources and deliberate mapping errors |
| R010 | Restart respects a reduced maximum timestep | Analytic decay and BDF history across changed timestep bounds |
| R011 | Retry the legal minimum before reporting timestep exhaustion | Accepted minimum, rejected minimum, endpoint remainder and rejected-step counts |
| R012 | Advance inactive historical energy keys with zero current power | Skew photon escape, BE/BDF histories, restart and rejected trials |
| R013 | Ideal sources report terminal current and supplied energy | BE/BDF electrode/dielectric charge balances, external capacitance, rank-independent ledgers and finite-R controls |
| R014 | Nonfinite integrated CPU energy fails transactionally | Immediate/late overflow, original-state rollback and finite controls |
| R015 | CPU linear convergence remains relative at small scales | Subnormal RHS, small diagonals/Arnoldi values, zero RHS and independently recomputed residuals |

The follow-up audit adds these regression cases:

| Finding | Corrected behavior | Regression coverage |
|---|---|---|
| A301 | CLI `--mpi` preserves the effective nested execution settings | CPU thread selection, explicit top-level precedence and rejected backends in chemistry, EEDF and coupled commands |
| A302 | Chemistry retries and subsequent proposals respect the legal minimum | CPU, owned MPI and resident CUDA minimum/remainder acceptance, exhaustion and transactional rollback |
| A303 | Area kinetics and transfers between affected phases require receiving volumes | Independent area/volume source and Jacobian checks, volume-weighted energy conservation and missing-geometry rejection |
| A304 | Serial restart respects both current timestep bounds | Generated short-endpoint histories, raised minimum, BE/BDF decay recurrence and legal endpoint remainders |
| A305 | Initial checkpoints have canonical zero-step history across backends | Serial/MPI transitions, failed prefixes and normalization of historical zero-step checkpoints |
| A306 | Quark source installation and update can acquire the pinned dependency | Production CMake selection with local Git, legacy build regeneration, changed pins and explicit source/SDK overrides |
| A307 | Setup records dependency selectors while preserving explicit configuration arguments | Production install-recording and deleted-build recovery, refreshed cache values and deliberate overrides/unsets |
| A308 | Every kinetic restart validates isotropic modes and boundary padding | Current/previous state rejection plus admitted numerical tails through no-step restart and subsequent advance |

Quark's local source and installed-SDK checks do not establish that a hosted job
has authenticated access to the private dependency. Its CI credential and pin are
configured in Quark; the repair closure report records remote qualification
separately. Earlier artifact receipts remain associated with their original
source revision.

Existing checkpoints preserve their saved temperatures and energy histories.
These repairs do not reconstruct earlier incorrect ledgers or undo earlier
trajectories; rerun affected cases when generating corrected qualification data.

## Execution and ownership

Owned APIs keep evolving species/mode fields, sparse rows and Krylov vectors local,
with dependency halos and scalar collective reductions. Static mesh, mechanism and
collision metadata can be shared. Compatibility APIs accept replicated inputs and
gather final outputs. `examples/distributed_spatial.py` reports these storage counts;
they are numerical-array counts, not total process resident memory.

On a 512-cell 2D example (3072 fluid unknowns), four ranks own 768 unknowns each,
with 192 or 384 halo unknowns and 6424 or 6712 local matrix entries. No evolving
global solution is gathered by the owned operation. The CLI writes separate rank
files and resumes their local checkpoints with `--checkpoint-prefix`.

A manufactured 256-cell, eight-species batch on Windows with an AMD Ryzen 7 9850X3D
and NVIDIA RTX 3080 Ti
had median times of 2.05 s with one CPU thread, 0.54 s with four threads and 0.44 s
on CUDA (three measured repeats, including API/transfer overhead). These are case-
and hardware-specific observations, not general speedup guarantees. Reproduce with
`python tools/benchmark_chemistry.py --cells 256 --repeats 3 --device both`.

CUDA independent-cell chemistry keeps rates, Jacobians, Newton work and adaptation
on the device. Coupled spatial/EEDF assembly stays on the CPU, with resident CUDA
linear solves and preconditioning. MPI stages only requested halo entries through
host memory. A requested unavailable CUDA backend fails explicitly.

## Build and application limits

Qualification covers MSVC on Windows, GCC on Windows/Linux, CPU and MPI builds,
actual local CUDA hardware, installed SDKs and Python wheels. The CI workflow builds
Windows/Linux SDKs and wheels and Linux MPI/CUDA packages; hosted CUDA runners have
no GPU and skip hardware tests. Local GPU tests use one RTX 3080 Ti, not distinct
physical GPUs on multiple nodes.

N2/O2/H2O, aqueous and interface packs record sources, coverage and required imports.
Missing rates and collision data fail explicitly. Only explicitly sourced numerical
subsets are included. A particular material mechanism still requires data selection,
calibration, uncertainty assessment and experimental validation. No numerical test
here establishes a universally validated water or gas breakdown model.

The scope is electrostatic/quasistatic with static geometry. Quark retains CAD,
meshing, visualization, mechanics and fluid motion. Electromagnetic waves, MHD and
cavitation hydrodynamics are outside this release. Photon diffusion is multigroup,
not an angular radiation solver. See [scope](status.md), [input](spatial.md),
[distributed execution](distributed.md) and [compatibility](api-compatibility.md).
