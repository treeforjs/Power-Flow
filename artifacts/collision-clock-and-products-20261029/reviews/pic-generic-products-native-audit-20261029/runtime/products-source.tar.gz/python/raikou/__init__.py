"""Native Raikou chemistry, EEDF, breakdown and spatial plasma runtime.

Use ordinary Python mappings and functions for scripting. Numerical operations
run in C++; importing the package does not initialize MPI or load a backend.
The original five-level hydrogen and spark functions remain available.
"""

from ._native import (
    FitPriors,
    NativeLibraryError,
    PlasmaState,
    RaikouError,
    SparkConfig,
    SparkState,
    evaluate,
    fit_vuv_shot,
    native_version,
    rates,
    step_spark_discharge,
)

from ._runtime import (
    advance_chemistry, advance_coupled_cell, advance_eedf, capabilities, evaluate_chemistry, execute, execute_batch,
    linear_solve, solve_breakdown, solve_eedf, solve_spatial, reconfigure_spatial, validate_mechanism,
    water_levels,
    evaluate_chemistry_batch, advance_chemistry_batch,
    evaluate_chemistry_distributed, advance_chemistry_distributed,
    evaluate_spherical_eedf, advance_spherical_eedf,
    solve_eedf_distributed, advance_eedf_distributed, solve_spatial_distributed,
)
from ._data import available_mechanisms, load_mechanism

__version__ = "1.0.0"
__all__ = [
    "FitPriors", "NativeLibraryError", "PlasmaState", "RaikouError",
    "SparkConfig", "SparkState", "evaluate", "fit_vuv_shot", "native_version",
    "rates", "step_spark_discharge",
    "advance_chemistry", "advance_coupled_cell", "advance_eedf", "capabilities", "evaluate_chemistry",
    "execute", "execute_batch", "linear_solve", "solve_breakdown", "solve_eedf", "solve_spatial", "reconfigure_spatial",
    "validate_mechanism", "water_levels",
    "available_mechanisms", "load_mechanism",
    "evaluate_chemistry_batch", "advance_chemistry_batch",
    "evaluate_chemistry_distributed", "advance_chemistry_distributed",
    "evaluate_spherical_eedf", "advance_spherical_eedf",
    "solve_eedf_distributed", "advance_eedf_distributed", "solve_spatial_distributed",
]
