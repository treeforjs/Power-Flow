"""JSON requests from Python's CLI: raikou OPERATION --input FILE|- ."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import sys

from . import RaikouError, __version__, evaluate, execute, fit_vuv_shot, rates, step_spark_discharge
from ._runtime import OPERATIONS, _reject_constant


def _unique_object(pairs):
    value = {}
    for key, item in pairs:
        if key in value:
            raise ValueError(f"Duplicate JSON object key: {key}")
        value[key] = item
    return value


def _read_input(path):
    if path is None:
        return {}
    text = sys.stdin.read() if path == "-" else Path(path).read_text(encoding="utf-8-sig")
    value = json.loads(text, parse_constant=_reject_constant, object_pairs_hook=_unique_object)
    if not isinstance(value, dict):
        raise ValueError("JSON input must be an object")
    return value


def _failed(value):
    if isinstance(value, dict):
        if any(value.get(key) is False for key in ("success", "converged", "valid", "ok")):
            return True
        return any(_failed(item) for item in value.values())
    if isinstance(value, list):
        return any(_failed(item) for item in value)
    return False


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(
        description="Raikou native plasma runtime: JSON requests and results",
        epilog="MPI: use raikou-native OPERATION --mpi, or initialize MPI in the embedding Python host. "
               "This Python command does not initialize MPI.",
    )
    parser.add_argument("--version", action="version", version=__version__)
    commands = parser.add_subparsers(dest="command", required=True)
    legacy = {
        "evaluate": (evaluate, "evaluate the legacy five-level hydrogen CR model"),
        "rates": (rates, "calculate legacy hydrogen rate coefficients"),
        "fit": (fit_vuv_shot, "fit VUV line radiances with the legacy model"),
        "step": (step_spark_discharge, "advance the separate legacy spark channel model"),
    }
    for command in (*OPERATIONS, *legacy):
        subparser = commands.add_parser(
            command, aliases=["spark"] if command == "step" else [],
            help=legacy[command][1] if command in legacy else f"execute native {command}",
        )
        subparser.add_argument("--input", "-i", metavar="FILE", help="JSON file, or '-' for stdin; defaults to {}")
        subparser.add_argument("--library", metavar="PATH", help="select an explicit native Raikou shared library")
        subparser.add_argument("--pretty", action="store_true", help="indent output JSON")
    args = parser.parse_args(argv)
    try:
        if args.library:
            os.environ["RAIKOU_LIBRARY"] = args.library
        parameters = _read_input(args.input)
        command = "step" if args.command == "spark" else args.command
        result = legacy[command][0](**parameters) if command in legacy else execute(command, parameters)
        print(json.dumps(result, indent=2 if args.pretty else None, allow_nan=False))
        return 1 if _failed(result) else 0
    except (RaikouError, OSError, ValueError, TypeError, OverflowError) as error:
        print(f"raikou: {error}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
