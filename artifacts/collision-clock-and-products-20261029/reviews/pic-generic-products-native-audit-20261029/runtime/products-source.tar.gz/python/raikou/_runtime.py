"""Python requests for the native Raikou runtime; no numerical Python fallback."""

from __future__ import annotations

import ctypes as ct
import importlib
import json
import os
from typing import Any, Mapping

from ._native import NativeLibraryError, RaikouError, _library, _prepare_dll_directories


OPERATIONS = (
    "capabilities", "batch.execute", "linear.solve", "mechanism.validate", "chemistry.evaluate",
    "chemistry.advance", "chemistry.evaluate_batch", "chemistry.advance_batch",
    "chemistry.evaluate_distributed", "chemistry.advance_distributed", "eedf.solve", "eedf.advance",
    "eedf.evaluate_spherical", "eedf.advance_spherical", "coupled.advance", "water.levels",
    "eedf.solve_distributed", "eedf.advance_distributed",
    "breakdown.solve", "spatial.solve", "spatial.solve_distributed",
)


def _reject_constant(value):
    raise ValueError(f"JSON must use finite numbers; found {value}")


def _check_keys(value):
    if isinstance(value, dict):
        for key, item in value.items():
            if not isinstance(key, str):
                raise TypeError("Request object keys must be strings")
            _check_keys(item)
    elif isinstance(value, (list, tuple)):
        for item in value:
            _check_keys(item)


def _request(request, parameters=None):
    if request is not None and not isinstance(request, Mapping):
        raise TypeError("request must be a mapping or None")
    value = {} if request is None else dict(request)
    if parameters:
        duplicate = value.keys() & parameters.keys()
        if duplicate:
            raise TypeError("Duplicate request fields: " + ", ".join(sorted(duplicate)))
        value.update(parameters)
    _check_keys(value)
    return json.dumps(value, allow_nan=False, separators=(",", ":"))


def _extension():
    if os.environ.get("RAIKOU_LIBRARY"):
        return None
    _prepare_dll_directories()
    try:
        return importlib.import_module("raikou._core")
    except ModuleNotFoundError as error:
        if error.name == "raikou._core":
            return None
        raise NativeLibraryError(f"Cannot load the Raikou extension: {error}") from error
    except ImportError as error:
        raise NativeLibraryError(
            f"Cannot load the Raikou extension: {error}. On Windows, set "
            "RAIKOU_DLL_DIRECTORIES to required MPI/CUDA dependency directories."
        ) from error


def _execute_c(operation: str, request: str) -> Any:
    library = _library()
    try:
        function = library.raikou_execute_json
        release = library.raikou_free_string
    except AttributeError as error:
        raise NativeLibraryError("The selected library has no JSON runtime API; build Raikou 0.2 or newer") from error
    function.argtypes = [ct.c_char_p, ct.c_char_p, ct.POINTER(ct.c_void_p)]
    function.restype = ct.c_int
    release.argtypes = [ct.c_void_p]
    release.restype = None
    output = ct.c_void_p()
    status = function(operation.encode("utf-8"), request.encode("utf-8"), ct.byref(output))
    if not output:
        raise RaikouError(f"{operation}: native runtime returned no response (status {status})")
    try:
        envelope = json.loads(ct.string_at(output).decode("utf-8"), parse_constant=_reject_constant)
    finally:
        release(output)
    if not isinstance(envelope, dict):
        raise NativeLibraryError("The native JSON API returned an invalid response envelope")
    if status != 0 or envelope.get("ok") is not True:
        raise RaikouError(f"{operation}: {envelope.get('error', f'native status {status}')}")
    if "result" not in envelope:
        raise NativeLibraryError("The native JSON response has no result")
    return envelope["result"]


def execute(operation: str, request: Mapping[str, Any] | None = None, **parameters: Any) -> dict[str, Any]:
    """Execute a native operation with a JSON-compatible mapping.

    Request fields may also be keyword arguments. Native numerical status
    fields (success/converged) are returned unchanged: callers must inspect
    them before accepting a solution. No input is mutated.

    Python never initializes MPI. An embedding host must initialize MPI and use
    a library built with MPI before requesting execution.mpi/solver.mpi. The
    separate raikou-native command initializes MPI when invoked with --mpi.
    """
    if not isinstance(operation, str) or not operation.strip() or "\0" in operation:
        raise ValueError("operation must be a nonempty string without null characters")
    serialized = _request(request, parameters)
    core = _extension()
    if core is None:
        result = _execute_c(operation, serialized)
    else:
        try:
            response = core.execute(operation, serialized)
        except (RuntimeError, ValueError, IndexError, TypeError, OverflowError) as error:
            raise RaikouError(f"{operation}: {error}") from error
        result = json.loads(response, parse_constant=_reject_constant)
    if not isinstance(result, dict):
        raise NativeLibraryError(f"{operation}: native result must be a JSON object")
    return result


def capabilities() -> dict[str, Any]:
    """Report native version, supported operations and actual backend availability."""
    return execute("capabilities")


def execute_batch(jobs: list[Mapping[str, Any]], execution: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Run native jobs with stable indices and per-job result/error envelopes.

    Each job contains operation and optional request. Inspect each result's ok
    and numerical success/converged fields. Nested batches and MPI collectives
    inside individual jobs are unsupported; batch MPI still requires a host
    that has initialized MPI. Threads schedule independent native jobs.
    """
    request = {"jobs": jobs}
    if execution is not None:
        request["execution"] = execution
    return execute("batch.execute", request)


def linear_solve(request: Mapping[str, Any] | None = None, **parameters: Any) -> dict[str, Any]:
    """Solve CSR matrix/rhs with optional execution settings; inspect converged."""
    return execute("linear.solve", request, **parameters)


def validate_mechanism(mechanism: Mapping[str, Any]) -> dict[str, Any]:
    """Validate a mechanism; invalid input returns valid=False and native errors."""
    return execute("mechanism.validate", mechanism=mechanism)


def evaluate_chemistry(request: Mapping[str, Any] | None = None, **parameters: Any) -> dict[str, Any]:
    """Evaluate mechanism/state and optional environment; return rates and Jacobian."""
    return execute("chemistry.evaluate", request, **parameters)


def advance_chemistry(request: Mapping[str, Any] | None = None, **parameters: Any) -> dict[str, Any]:
    """Advance mechanism/state by dt_s with environment/options; inspect success."""
    return execute("chemistry.advance", request, **parameters)


def evaluate_chemistry_batch(request: Mapping[str, Any] | None = None, **parameters: Any) -> dict[str, Any]:
    """Evaluate cells sharing one mechanism on native CPU workers or the GPU."""
    return execute("chemistry.evaluate_batch", request, **parameters)


def advance_chemistry_batch(request: Mapping[str, Any] | None = None, **parameters: Any) -> dict[str, Any]:
    """Advance independent cells; inspect success and each cell's status.

    The GPU retains density, Jacobian and Newton state throughout the interval.
    Temperature and external rate inputs are prescribed per cell for the interval.
    """
    return execute("chemistry.advance_batch", request, **parameters)


def evaluate_chemistry_distributed(request: Mapping[str, Any] | None = None, **parameters: Any) -> dict[str, Any]:
    """Collectively evaluate owned species rows from a local density array."""
    return execute("chemistry.evaluate_distributed", request, **parameters)


def advance_chemistry_distributed(request: Mapping[str, Any] | None = None, **parameters: Any) -> dict[str, Any]:
    """Collectively advance one kinetic system with owned species and reactant halos.

    The host initializes MPI and supplies local state.densities_m3 arrays and optional
    state.row_begin on each rank. No global state is gathered by this operation.
    """
    return execute("chemistry.advance_distributed", request, **parameters)


def solve_eedf(request: Mapping[str, Any] | None = None, **parameters: Any) -> dict[str, Any]:
    """Solve EEDF from processes or lxcat_text, conditions and grid; inspect converged."""
    return execute("eedf.solve", request, **parameters)


def advance_eedf(request: Mapping[str, Any] | None = None, **parameters: Any) -> dict[str, Any]:
    """Advance EEDF modes by dt_s using initial data or a state checkpoint."""
    return execute("eedf.advance", request, **parameters)


def evaluate_spherical_eedf(request: Mapping[str, Any] | None = None, **parameters: Any) -> dict[str, Any]:
    """Evaluate full real angular-mode rates for a physical electric-field vector."""
    return execute("eedf.evaluate_spherical", request, **parameters)


def advance_spherical_eedf(request: Mapping[str, Any] | None = None, **parameters: Any) -> dict[str, Any]:
    """Advance all angular modes without resetting anisotropy as the field rotates."""
    return execute("eedf.advance_spherical", request, **parameters)


def solve_eedf_distributed(request: Mapping[str, Any] | None = None, **parameters: Any) -> dict[str, Any]:
    """Collectively solve one EEDF with local energy-cell state on each rank."""
    return execute("eedf.solve_distributed", request, **parameters)


def advance_eedf_distributed(request: Mapping[str, Any] | None = None, **parameters: Any) -> dict[str, Any]:
    """Collectively advance an EEDF; return only owned packed mode rows."""
    return execute("eedf.advance_distributed", request, **parameters)


def advance_coupled_cell(request: Mapping[str, Any] | None = None, **parameters: Any) -> dict[str, Any]:
    """Advance chemistry, kinetic electron moments and selected phase temperatures.

    Supply mechanism, state.densities_m3, electron_closure, field_magnitude_V_m
    and dt_s. Initialize with initial_mean_energy_ev or resume using the full
    returned electrons checkpoint, state and environment. Failed nonlinear
    trials raise RaikouError and do not mutate the supplied objects.
    """
    return execute("coupled.advance", request, **parameters)


def water_levels(request: Mapping[str, Any] | None = None, **parameters: Any) -> dict[str, Any]:
    """Generate native water rotational levels (for example j_max=2)."""
    return execute("water.levels", request, **parameters)


def solve_breakdown(request: Mapping[str, Any] | None = None, **parameters: Any) -> dict[str, Any]:
    """Solve the native EEDF/circuit breakdown model from collision data and setup."""
    return execute("breakdown.solve", request, **parameters)


def solve_spatial(request: Mapping[str, Any] | None = None, **parameters: Any) -> dict[str, Any]:
    """Solve a spatial chemistry/transport request; inspect solver diagnostics."""
    return execute("spatial.solve", request, **parameters)


def reconfigure_spatial(request: Mapping[str, Any] | None = None, **parameters: Any) -> dict[str, Any]:
    """Remap electrical material/charge state at zero time; inspect the work audit."""
    return execute("spatial.reconfigure", request, **parameters)


def solve_spatial_distributed(request: Mapping[str, Any] | None = None, **parameters: Any) -> dict[str, Any]:
    """Collectively solve with owned cell fields, local checkpoints and dependency halos.

    Shared initial fields are scalars. Use local_initial arrays to supply this
    rank's cells; subsequent calls use the returned local checkpoint. The host
    owns MPI initialization and communicator lifetime. Inspect success before
    accepting a solution. No global solution is gathered by this operation.
    """
    return execute("spatial.solve_distributed", request, **parameters)
