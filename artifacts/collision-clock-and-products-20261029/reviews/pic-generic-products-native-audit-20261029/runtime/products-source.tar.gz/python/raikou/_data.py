"""Access packaged starter mechanisms without depending on a repository checkout."""

from importlib.resources import files
import json
from pathlib import Path
import re


def _mechanisms():
    packaged = files("raikou").joinpath("mechanisms")
    if packaged.is_dir():
        return packaged
    source = Path(__file__).resolve().parents[2]
    if (source / "pyproject.toml").is_file() and (source / "mechanisms").is_dir():
        return source / "mechanisms"
    raise FileNotFoundError("Raikou starter mechanisms are missing; install a complete Raikou wheel")


def available_mechanisms() -> list[str]:
    """List packaged starter names. Their research/coverage status remains in each file."""
    return sorted(item.name[:-5] for item in _mechanisms().iterdir()
                  if item.name.endswith(".json") and item.is_file())


def load_mechanism(name: str) -> dict:
    """Read one packaged starter by name, optionally ending in .json.

    This loads data; use validate_mechanism and review coverage/provenance before
    simulation. It does not fill missing collision rates or alter the mechanism.
    """
    if not isinstance(name, str):
        raise TypeError("mechanism name must be a string")
    if not re.fullmatch(r"[A-Za-z0-9_-]+(?:\.json)?", name):
        raise ValueError("mechanism name must be a starter name without directory components")
    filename = name if name.endswith(".json") else name + ".json"
    path = _mechanisms().joinpath(filename)
    if not path.is_file():
        raise FileNotFoundError(f"Unknown Raikou starter mechanism: {name}")
    return json.loads(path.read_text(encoding="utf-8"))
