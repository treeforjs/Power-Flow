"""Standard-library-only bindings for raikou/c_api.h."""

from __future__ import annotations

import ctypes as ct
import ctypes.util
from dataclasses import asdict, dataclass, fields, replace
from functools import lru_cache
import os
from pathlib import Path
from typing import Any, Mapping


_dll_directory_handles = {}


def _prepare_dll_directories(extra=()):
    """Keep Windows dependency paths active without initializing MPI or CUDA.

    Hosts can select dependency directories using RAIKOU_DLL_DIRECTORIES,
    separated by os.pathsep. Python 3.8+ ignores PATH for extension loading,
    so existing PATH directories are also registered explicitly.
    """
    if os.name != "nt" or not hasattr(os, "add_dll_directory"):
        return
    package = Path(__file__).resolve().parent
    candidates = [package, package / "lib", *extra]
    candidates.extend(os.environ.get("RAIKOU_DLL_DIRECTORIES", "").split(os.pathsep))
    candidates.extend(os.environ.get("PATH", "").split(os.pathsep))
    for value in candidates:
        if not value:
            continue
        directory = Path(os.path.expandvars(os.path.expanduser(str(value)))).resolve()
        key = os.path.normcase(str(directory))
        if key not in _dll_directory_handles and directory.is_dir():
            try:
                _dll_directory_handles[key] = os.add_dll_directory(str(directory))
            except OSError:
                continue


class RaikouError(RuntimeError):
    """The native Raikou model could not complete a calculation."""


class NativeLibraryError(RaikouError):
    """A compatible native Raikou shared library could not be loaded."""


@dataclass
class PlasmaState:
    """CR input: eV, kelvin, densities in m^-3, path length in meters."""

    Te_eV: float = 2.5
    ne_m3: float = 1.0e19
    Tgas_K: float = 5000.0
    nH_ground_m3: float = 1.0e20
    nH2_m3: float = 5.0e19
    path_length_m: float = 5.0e-3


@dataclass
class FitPriors:
    """Positive lower and upper bounds for the native VUV fit."""

    min_Te_eV: float = 0.5
    max_Te_eV: float = 20.0
    min_ne_m3: float = 1.0e17
    max_ne_m3: float = 1.0e22
    min_nH_m3: float = 1.0e17
    max_nH_m3: float = 1.0e23
    min_nH2_m3: float = 1.0e17
    max_nH2_m3: float = 1.0e23


@dataclass
class SparkConfig:
    """Parameters for the separate phenomenological spark channel model."""

    peak_current: float = 20000.0
    pulse_duration_s: float = 5.0e-6
    initial_density: float = 1000.0
    plasma_conductivity: float = 2.5e4
    channel_length: float = 0.01


@dataclass
class SparkState:
    """Spark state in seconds, amperes, meters, pascals, kelvin and joules."""

    time_s: float = 0.0
    current_A: float = 0.0
    channel_radius_m: float = 1.0e-4
    pressure_Pa: float = 1.0e5
    temperature_K: float = 300.0
    deposited_energy_J: float = 0.0
    accumulated_action: float = 0.0


def _double_struct(name: str, model_type: type) -> type:
    return type(name, (ct.Structure,), {
        "_fields_": [(field.name, ct.c_double) for field in fields(model_type)],
    })


_PlasmaState = _double_struct("_PlasmaState", PlasmaState)
_FitPriors = _double_struct("_FitPriors", FitPriors)
_SparkConfig = _double_struct("_SparkConfig", SparkConfig)
_SparkState = _double_struct("_SparkState", SparkState)


class _RadianceResult(ct.Structure):
    _fields_ = [
        ("populations_m3", ct.c_double * 5),
        ("lyman_alpha_radiance_W_m2_sr", ct.c_double),
        ("lyman_beta_radiance_W_m2_sr", ct.c_double),
        ("balmer_alpha_radiance_W_m2_sr", ct.c_double),
        ("balmer_beta_radiance_W_m2_sr", ct.c_double),
        ("molecular_lyman_proxy_W_m2_sr", ct.c_double),
        ("tau_0_lyman_alpha", ct.c_double),
        ("escape_factor_lyman_alpha", ct.c_double),
        ("tau_0_lyman_beta", ct.c_double),
        ("escape_factor_lyman_beta", ct.c_double),
    ]


class _RateResult(ct.Structure):
    _fields_ = [
        ("excitation_m3_s", (ct.c_double * 5) * 5),
        ("deexcitation_m3_s", (ct.c_double * 5) * 5),
        ("ionization_m3_s", ct.c_double * 5),
        ("radiative_recombination_m3_s", ct.c_double * 5),
        ("three_body_recombination_m6_s", ct.c_double * 5),
        ("h2_dissociation_m3_s", ct.c_double * 5),
    ]


class _FitResult(ct.Structure):
    _fields_ = [
        ("Te_eV", ct.c_double), ("Te_err_eV", ct.c_double),
        ("ne_m3", ct.c_double), ("ne_err_m3", ct.c_double),
        ("nH_m3", ct.c_double), ("nH_err_m3", ct.c_double),
        ("nH2_m3", ct.c_double), ("nH2_err_m3", ct.c_double),
        ("tau_0_lyman_alpha", ct.c_double),
        ("escape_factor_lyman_alpha", ct.c_double),
        ("chi2_reduced", ct.c_double),
        ("converged", ct.c_int), ("iterations", ct.c_int),
    ]


def _library_candidates():
    """Prefer explicit selection, then package/build locations, then system."""
    explicit = os.environ.get("RAIKOU_LIBRARY")
    if explicit:
        yield os.path.expandvars(os.path.expanduser(explicit))
        return

    if os.name == "nt":
        names = ("raikou_c.dll", "libraikou_c.dll")
    elif os.sys.platform == "darwin":
        names = ("libraikou_c.dylib",)
    else:
        names = ("libraikou_c.so", "libraikou_c.so.0")

    package = Path(__file__).resolve().parent
    # Source tree: raikou/python/raikou/_native.py. In an installed package
    # these extra locations are harmless; package/lib remains the first choice.
    source = package.parent.parent
    repository = source.parent
    roots = [
        package / "lib", package / ".libs", package,
        source / "build-native", source / "build", source / "build-raikou",
        source / "install" / "bin", source / "install" / "lib",
        Path(os.sys.prefix) / "bin", Path(os.sys.prefix) / "lib",
        repository / "build-raikou",
        repository / "build" / "raikou", repository / "build",
    ]
    seen = set()
    for root in roots:
        for directory in (root, root / "Release", root / "Debug", root / "RelWithDebInfo"):
            for name in names:
                candidate = directory / name
                if candidate.is_file() and str(candidate) not in seen:
                    seen.add(str(candidate))
                    yield str(candidate)
    system = ctypes.util.find_library("raikou_c")
    if system and system not in seen:
        yield system


def _configure(lib):
    definitions = {
        "raikou_version": ([], ct.c_char_p),
        "raikou_last_error": ([], ct.c_char_p),
        "raikou_default_plasma_state": ([ct.POINTER(_PlasmaState)], ct.c_int),
        "raikou_default_fit_priors": ([ct.POINTER(_FitPriors)], ct.c_int),
        "raikou_default_spark_config": ([ct.POINTER(_SparkConfig)], ct.c_int),
        "raikou_default_spark_state": ([ct.POINTER(_SparkState)], ct.c_int),
        "raikou_evaluate": ([ct.POINTER(_PlasmaState), ct.POINTER(_RadianceResult)], ct.c_int),
        "raikou_rate_coefficients": ([ct.c_double, ct.POINTER(_RateResult)], ct.c_int),
        "raikou_fit_vuv_shot": ([ct.c_double] * 6 + [ct.POINTER(_FitPriors), ct.POINTER(_FitResult)], ct.c_int),
        "raikou_step_spark": ([ct.POINTER(_SparkState), ct.c_double, ct.POINTER(_SparkConfig), ct.POINTER(_SparkState)], ct.c_int),
    }
    for name, (argtypes, restype) in definitions.items():
        function = getattr(lib, name)
        function.argtypes = argtypes
        function.restype = restype
    return lib


@lru_cache(maxsize=1)
def _library():
    errors = []
    for candidate in _library_candidates():
        try:
            _prepare_dll_directories((Path(candidate).resolve().parent,))
            return _configure(ct.CDLL(candidate))
        except (OSError, AttributeError) as error:
            errors.append(f"{candidate}: {error}")
    detail = "\n" + "\n".join(errors) if errors else ""
    raise NativeLibraryError(
        "Cannot load the Raikou native library. Build it with "
        "'cmake -S . -B build-native' and "
        "'cmake --build build-native --config Release', then set "
        "RAIKOU_LIBRARY to the full path of raikou_c.dll (or libraikou_c.dll), libraikou_c.so, "
        "or libraikou_c.dylib before calling Raikou. Installing a wheel supplies "
        "the native library. On Windows, use RAIKOU_DLL_DIRECTORIES for external "
        "MPI/CUDA dependency directories." + detail
    )


def _check(lib, status: int):
    if status == 0:
        return
    message = lib.raikou_last_error()
    text = message.decode("utf-8", errors="replace") if message else f"Native error {status}"
    if status == 1:
        raise ValueError(text)
    raise RaikouError(text)


def _number(value, name: str) -> float:
    if isinstance(value, (str, bytes, bool)):
        raise TypeError(f"{name} must be a number")
    try:
        return float(value)
    except (TypeError, ValueError) as error:
        raise TypeError(f"{name} must be a number") from error
    except OverflowError as error:
        raise ValueError(f"{name} is outside the native numeric range") from error


def _input(value, model_type, native_type, default_function: str, updates=None):
    if value is None:
        native = native_type()
        lib = _library()
        _check(lib, getattr(lib, default_function)(ct.byref(native)))
        value = model_type(**{field.name: getattr(native, field.name) for field in fields(model_type)})
    elif isinstance(value, Mapping):
        value = model_type(**value)
    elif not isinstance(value, model_type):
        raise TypeError(f"Expected {model_type.__name__}, a mapping, or None")
    if updates:
        value = replace(value, **updates)
    return native_type(**{name: _number(number, name) for name, number in asdict(value).items()})


def _value(value):
    if isinstance(value, ct.Array):
        return [_value(item) for item in value]
    return value


def _result_dict(result) -> dict[str, Any]:
    output = {name: _value(getattr(result, name)) for name, _ in result._fields_}
    if "converged" in output:
        output["converged"] = bool(output["converged"])
    return output


def native_version() -> str:
    """Return the version of the loaded native library."""
    return _library().raikou_version().decode("utf-8")


def evaluate(state: PlasmaState | Mapping[str, float] | None = None, **parameters: float) -> dict[str, Any]:
    """Evaluate QSS populations, optical depths and radiances.

    Accept a PlasmaState or dictionary; keyword arguments override its fields.
    Radiances are W m^-2 sr^-1 and populations are m^-3. Omitted fields use the
    native defaults. No input object is mutated.
    """
    native = _input(state, PlasmaState, _PlasmaState, "raikou_default_plasma_state", parameters)
    result = _RadianceResult()
    lib = _library()
    _check(lib, lib.raikou_evaluate(ct.byref(native), ct.byref(result)))
    return _result_dict(result)


def rates(Te_eV: float = 2.5) -> dict[str, Any]:
    """Return native coefficients for n=1..5; matrices index [source-1][target-1].

    Units are m^3/s except three_body_recombination_m6_s (m^6/s).
    """
    result = _RateResult()
    lib = _library()
    _check(lib, lib.raikou_rate_coefficients(_number(Te_eV, "Te_eV"), ct.byref(result)))
    return _result_dict(result)


def fit_vuv_shot(
    measured_ly_alpha_radiance: float,
    measured_ly_alpha_sigma: float,
    measured_molecular_radiance: float,
    measured_molecular_sigma: float,
    path_length_m: float = 5.0e-3,
    fixed_Tgas_K: float = 5000.0,
    priors: FitPriors | Mapping[str, float] | None = None,
) -> dict[str, Any]:
    """Fit two VUV radiances with the native bounded, regularized objective.

    Radiances and their positive sigma inputs are W m^-2 sr^-1. This is an
    underdetermined four-parameter fit; its error fields are heuristic simplex
    estimates, not independently established statistical confidence intervals.
    """
    bounds = None if priors is None else _input(priors, FitPriors, _FitPriors, "raikou_default_fit_priors")
    result = _FitResult()
    lib = _library()
    _check(lib, lib.raikou_fit_vuv_shot(
        _number(measured_ly_alpha_radiance, "measured_ly_alpha_radiance"),
        _number(measured_ly_alpha_sigma, "measured_ly_alpha_sigma"),
        _number(measured_molecular_radiance, "measured_molecular_radiance"),
        _number(measured_molecular_sigma, "measured_molecular_sigma"),
        _number(path_length_m, "path_length_m"), _number(fixed_Tgas_K, "fixed_Tgas_K"),
        None if bounds is None else ct.byref(bounds), ct.byref(result),
    ))
    return _result_dict(result)


def step_spark_discharge(
    state: SparkState | Mapping[str, float] | None = None,
    dt_s: float = 1.0e-8,
    config: SparkConfig | Mapping[str, float] | None = None,
) -> dict[str, float]:
    """Advance the separate spark channel model by dt_s without mutating state.

    The returned dictionary can be passed as state for the next call. This
    phenomenological channel model is not automatically coupled to CR kinetics.
    """
    current = _input(state, SparkState, _SparkState, "raikou_default_spark_state")
    settings = _input(config, SparkConfig, _SparkConfig, "raikou_default_spark_config")
    result = _SparkState()
    lib = _library()
    _check(lib, lib.raikou_step_spark(ct.byref(current), _number(dt_s, "dt_s"), ct.byref(settings), ct.byref(result)))
    return _result_dict(result)
