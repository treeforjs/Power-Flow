#include "raikou/collision_data.h"
#include <iomanip>
#include <iostream>

int main(int argc,char** argv) {
    try {
        if (argc!=4) throw std::invalid_argument("Usage: h2o-collision-query DATASET CHANNEL ENERGY_eV");
        const auto dataset=raikou::kinetics::StrictCollisionDataset::read(argv[1]);
        const std::string input=argv[3];std::size_t consumed=0;const double e=std::stod(input,&consumed);
        if (consumed!=input.size()) throw std::invalid_argument("Invalid incident energy");
        const auto& channel=dataset.channel_metadata(argv[2]);
        const auto value=dataset.observable_value_SI(argv[2],e);
        const raikou::Json result={{"dataset_revision",dataset.metadata().at("id")},{"channel_id",argv[2]},
            {"incident_energy_eV",e},{"value",value},{"unit",channel.at("unit_SI")},
            {"observable",channel.at("observable")},{"source",channel.at("source")},
            {"full_fragmentation",false},{"time_evolution_performed",false}};
        std::cout<<std::setprecision(17)<<result.dump(2)<<'\n';return 0;
    } catch (const raikou::kinetics::CollisionCoverageError& e) {
        std::cerr<<e.what()<<'\n';return 78;
    } catch (const std::exception& e) { std::cerr<<e.what()<<'\n';return 1; }
}
