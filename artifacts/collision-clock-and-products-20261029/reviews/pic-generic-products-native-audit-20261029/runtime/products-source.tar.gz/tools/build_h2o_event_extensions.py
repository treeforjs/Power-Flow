#!/usr/bin/env python3
"""Add explicitly conditional differential physics without changing the v1 freeze."""
from pathlib import Path
import hashlib
import json

ROOT=Path(__file__).resolve().parents[1]
def main():
    path=ROOT/'data/collisions/h2o-gas-20261029.json';raw=path.read_bytes()
    locked=json.loads(path.with_name('h2o-gas-20261029.lock.json').read_text())
    assert hashlib.sha256(raw).hexdigest()==locked['dataset_sha256']
    data=json.loads(raw);data['id']='h2o-gas-20261029-events-v2'
    data['base_dataset_sha256']=locked['dataset_sha256']
    data['sources']['ram2010']=dict(url='https://arxiv.org/pdf/1007.5144',
        title='Dissociative Electron Attachment to Polyatomic Molecules - I: Water',
        authors=['N.Bhargava Ram','V.S.Prabhudesai','E.Krishnakumar'],
        pdf_sha256='b8d8290fa1d665720199575d62e3884520ac70472a4c29d598a7cafe0c30dbad',
        role='primary gas-phase VMI; Eq4/angular fit and TableIII OH vibrational fit at6.5eV')
    data['sources']['nist_OH']=dict(url='https://webbook.nist.gov/cgi/cbook.cgi?ID=C3352576&Mask=1000',
        role='NIST/Huber-Herzberg OH(X) constants and note22; Maillard,Chauville,Mantz JMolSpectrosc63,120(1976)',
        direct_archive='HTTP403; numerical binding verified on official web tool page, source snapshot retained externally')
    data['conditional_event_models'].append(dict(id='Hminus_Ram65_factorized_window_v1',
        channel='H2O:attachment_yield:Hminus',admission='explicit conditional near-anchor extension',
        data_support_eV=[6.25,6.75],empirical_anchor_eV=6.5,experimental_beam_resolution_eV=.5,
        products={'Hm':1,'OH_X_v':1},parent_debit=1,electron_capture=1,
        chemical_reference_gain_eV=4.35,source=['song2021','ram2010','nist_OH'],
        angular=dict(model='Ram2010_Eq4_B1_pd',a=1.,b=.31,phase_rad=3.139,
            frame='target-rest laboratory Hminus direction; exact inverse CM boost for each selected vibrational state',
            expression='I(mu)=(1-mu^2)*(A+B*mu^2+C*mu), A=2a^2+.96b^2, B=1.2b^2, C=4.2ab*cos(delta)',
            measure='I is differential intensity; sample I(mu)dmu and uniform azimuth, not uniform theta'),
        OH_vibrational_relative_intensities=[1.,.82,.57,.32,.25],
        OH_X_G_cm1_coefficients=[3737.761,-84.8813,.5409,-.02134,-.00113],
        OH_vibrational_energy_convention='(G(v+1/2)-G(1/2))*hc in eV; v0..4',
        h_c_eV_cm=1.2398419843320026e-4,
        mass_convention='M_OH(v)=M_H2O+me+(4.35eV+E_v)/c2-M_Hminus; host binds the same immutable species/state mass basis',
        kinematics='exact relativistic two-body breakup and CM boost; consumed electron, one Hminus and one OH(X,v), matched represented weights',
        assumptions=['hold6.5eV vibrational/angular fit only over explicitly selected6.25..6.75eV conditional window',
            'factorize energy-integrated angular fit and fitted vibrational populations; correlations unresolved',
            'reported v0..4 fit closes this reduced model; unobserved high-v tail not independently bounded',
            'OH rotational/spin-orbit structure and Gaussian instrumental widths unresolved; no extra rotational energy assigned',
            'external field action during transient anion lifetime omitted'],
        exclusions=['OH excited-electronic/three-body branches','no applicability at8.5 or12eV resonances','not a full attachment or breakdown mechanism']))
    out=ROOT/'data/collisions/h2o-gas-20261029-events.json';encoded=(json.dumps(data,indent=2,allow_nan=False)+'\n').encode()
    event_lock=out.with_name('h2o-gas-20261029-events.lock.json')
    if event_lock.exists():assert hashlib.sha256(encoded).hexdigest()==json.loads(event_lock.read_text())['dataset_sha256'],'Frozen event dataset drift'
    out.write_bytes(encoded)
    print(json.dumps(dict(path=str(out),sha256=hashlib.sha256(out.read_bytes()).hexdigest(),conditional_models=len(data['conditional_event_models']))))

if __name__=='__main__':main()
