#!/usr/bin/env bash
set -eu
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1
h2o_root=$(cd -- "$(dirname -- "$0")/.." && pwd)
exec taskset -c 7 nice -n 15 timeout 120s python3 "$h2o_root/tools/test_h2o_collision_events.py" "$@"
