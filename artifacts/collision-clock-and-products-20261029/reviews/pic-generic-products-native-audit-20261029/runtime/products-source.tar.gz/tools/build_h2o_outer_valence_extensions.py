#!/usr/bin/env python3
"""Explicit outer-three-orbital high-energy subset; never redistribute missing holes."""
from pathlib import Path
import copy
import hashlib
import json
ROOT=Path(__file__).resolve().parents[1]
def main():
    p=ROOT/'data/collisions/h2o-gas-20261029-dissociation.json';raw=p.read_bytes();base=hashlib.sha256(raw).hexdigest()
    assert base==json.loads(p.with_suffix('.lock.json').read_text())['dataset_sha256']
    data=json.loads(raw);data['id']='h2o-gas-20261029-outer3-v5';data['dissociation_v4_dataset_sha256']=base
    data['sources']['murakami2012']=dict(url='https://www.yorku.ca/marko/IonAtom/PRA85_052704.pdf',doi='10.1103/PhysRevA.85.052704',pdf_sha256='464c824d5003e127f8659a5a92ae1e268e12b4ecada16d3313c178cd21c9edf8',
        role='Primary theoretical application of high-energy single-vacancy branching, Eqs27-30; empirical lineage Tan etal ChemPhys29,299(1978), DOI10.1016/0301-0104(78)85080-0. Proton collision dynamics are NOT imported as electron-impact rates.')
    data['sources']['nist_fragment_IE']=dict(url='https://webbook.nist.gov/cgi/cbook.cgi?ID=C3352576&Mask=20',H_url='https://webbook.nist.gov/cgi/cbook.cgi?ID=C12385136&Mask=20',
        role='OH evaluatedIE13.017eV and H evaluatedIE13.59844eV; official pages inspected; factual numerical snapshot retained externally')
    template=next(p for p in data['channels'] if p['id']=='H2O:nist_BEB_valence')
    assert [o['label'] for o in template['orbitals']]==['2a1','1b2','3a1','1b1']
    entries=[('parent',[0,.08,1,1],{'e_g':2,'H2Op':1},12.621),
        ('OHp_H',[0,.70,0,0],{'e_g':2,'OHp_X_ground':1,'H_1s':1},5.1+13.017),
        ('Hp_OH',[0,.22,0,0],{'e_g':2,'Hp':1,'OH_X_v0':1},5.1+13.59844),
        ('unmapped_2a1',[1,0,0,0],None,None)]
    for name,weights,products,cost in entries:
        q=copy.deepcopy(template);q.update(id='H2O:conditional_outer3:'+name,source='murakami2012',support_eV=[1000.,10000.],zero_below_eV=None,orbital_weights=weights,
            observable='unmapped_ionization_hole' if products is None else 'conditional_exclusive_event_rate',
            exclusive_products=products,use='unmapped_rate_evidence' if products is None else 'explicit_conditional_model_only',
            source_locator='NIST four-orbitalBEB formula times Tan/Murakami outer3 weights; not measured fragment-event cross sections',
            lineage='NIST orbital rates + Murakami2012 Eqs27-29/Tan1978 high-energy single-vacancy branching; 2a1 deliberately unmapped',
            limitations=['BEB orbital rates approximate exclusive single-vacancy production','1..10keV domain is a selected asymptotic conditional comparison range, not a measured accuracy guarantee','do not sum with unweightedBEB, old parent/partial yields or another model of the same holes','no missing-rate redistribution or renormalization'])
        data['channels'].append(q)
        if products is not None:
            data['conditional_event_models'].append(dict(id='outer3_BEB_Tan_'+name+'_v1',channel=q['id'],data_support_eV=[1000.,10000.],products=products,parent_debit=1,electron_net_gain=1,
                chemical_reference_gain_eV=cost,fixed_fragmenting_hole_eV=None if name=='parent' else 19.83,
                assumptions=['outer3BEB rates approximate isolated single-vacancy production at high energy','1b1/3a1 parent branches1.0;1b2 parent/OHp/Hp branches.08/.70/.22; no2a1 branch sampled',
                    'ground final species; parent equal-energy back-to-backCM electron pair; fragment branches have equal-energy back-to-backCM electrons and fixed19.83eV virtual ion followed by isotropic ground-product breakup',
                    'not a measured joint secondary/angle/internal/recoil distribution'],
                exclusions=['positive unmapped2a1 rate retained','oxygen core, double/triple ionization and Auger omitted','not a complete8keV water mechanism']))
    data['outer3_fragment_ionization_eV']={'H':13.59844,'OH':13.017}
    data['outer3_completeness']=dict(complete=False,explicit_unmapped_rate='H2O:conditional_outer3:unmapped_2a1',
        core_1a1='not in original four-orbitalBEB; no automatic zero',multiple_ionization='not represented; no ion-yield fractions converted into event probabilities',
        overlap='alternative model of high-energy outer3 holes, never additive to fullBEB or overlapping measured parent/yield curves')
    out=p.with_name('h2o-gas-20261029-outer3.json');encoded=(json.dumps(data,indent=2,allow_nan=False)+'\n').encode()
    if out.with_suffix('.lock.json').exists():assert hashlib.sha256(encoded).hexdigest()==json.loads(out.with_suffix('.lock.json').read_text())['dataset_sha256'],'Frozen v5 drift'
    out.write_bytes(encoded);print(json.dumps(dict(path=str(out),sha256=hashlib.sha256(encoded).hexdigest())))
if __name__=='__main__':main()
