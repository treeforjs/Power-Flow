"""Measure the callable native chemistry batch, including JSON/transfer overhead.

This manufactured conserved network is a performance case, not plasma validation.
Run from an installed environment or set PYTHONPATH and RAIKOU_LIBRARY for a build.
"""
from __future__ import annotations

import argparse
import json
import platform
import statistics
import time

import raikou


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cells", type=int, default=512)
    parser.add_argument("--species", type=int, default=8)
    parser.add_argument("--threads", type=int, nargs="+", default=[1, 4])
    parser.add_argument("--repeats", type=int, default=3)
    parser.add_argument("--device", choices=["cpu", "cuda", "both"], default="both")
    parser.add_argument("--cuda-device", type=int, default=-1)
    args = parser.parse_args()
    if args.cells < 1 or args.species < 2 or args.repeats < 1 or any(n < 1 for n in args.threads):
        parser.error("positive cell/repeat/thread counts and at least two species are required")
    names = [f"X{i}" for i in range(args.species)]
    mechanism = {
        "id": "manufactured_conserved_chain", "status": "manufactured",
        "species": [{"id": name, "elements": {"N": 1}} for name in names],
        "reactions": [
            {"id": f"R{i}", "reactants": {names[i]: 1}, "products": {names[(i + 1) % len(names)]: 1},
             "rate": {"type": "constant", "A": 1000 + i * 10},
             "source": "manufactured performance benchmark"}
            for i in range(args.species)
        ],
    }
    request = {"mechanism": mechanism, "cells": [
        {"state": {"densities_m3": {name: float(j == 0) for j, name in enumerate(names)}}}
        for _ in range(args.cells)
    ], "dt_s": 0.001, "options": {"relative_tolerance": 1e-4, "absolute_tolerance_m3": 1e-9}}
    capabilities = raikou.capabilities()
    setups = []
    if args.device in ("cpu", "both"):
        setups += [{"device": "cpu", "threads": n} for n in args.threads]
    if args.device in ("cuda", "both"):
        if not capabilities["cuda"]:
            if args.device == "cuda":
                raise RuntimeError("CUDA is unavailable; benchmark will not substitute CPU execution")
        else:
            setups.append({"device": "cuda", "cuda_device": args.cuda_device})
    measurements = []
    for setup in setups:
        request["execution"] = setup
        # Warm the worker pool, runtime and device before timing.
        result = raikou.advance_chemistry_batch(request)
        elapsed = []
        for _ in range(args.repeats):
            start = time.perf_counter()
            result = raikou.advance_chemistry_batch(request)
            elapsed.append(time.perf_counter() - start)
        if not result["success"]:
            raise RuntimeError(result)
        conservation_error = max(abs(sum(cell["state"]["densities_m3"].values()) - 1) for cell in result["cells"])
        if conservation_error > 1e-10:
            raise RuntimeError(f"conserved inventory changed by {conservation_error}")
        median = statistics.median(elapsed)
        measurements.append({"execution": setup, "seconds": elapsed, "median_seconds": median,
                             "cells_per_second": args.cells / median, "max_inventory_error": conservation_error,
                             "transfers": result["transfers"]})
    print(json.dumps({"case": "manufactured; numerical throughput only", "platform": platform.platform(),
                      "cells": args.cells, "species": args.species, "capabilities": capabilities,
                      "measurements": measurements}, indent=2))


if __name__ == "__main__":
    main()
