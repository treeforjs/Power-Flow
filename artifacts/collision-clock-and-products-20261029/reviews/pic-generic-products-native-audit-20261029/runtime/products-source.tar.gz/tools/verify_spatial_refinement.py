"""Check the coupled owned reaction/diffusion/Poisson solver against an analytic mode.

The manufactured electron/positive-particle avalanche has equal diffusion and
zero mobility, so charge cancels and the solved potential is affine. Its density
is compared with the growing cosine solution for a constant neutral reservoir;
neutral depletion here is below 1e-14 relative, far below the measured errors.
This is numerical verification, not a gas mechanism or experimental reference.
"""
from __future__ import annotations

import argparse
import json
import math
import time

import raikou


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--distributed", action="store_true")
    parser.add_argument("--device", choices=("cpu", "cuda"), default="cpu")
    parser.add_argument("--cuda-device", type=int, default=-1)
    args = parser.parse_args()
    comm = None
    if args.distributed:
        from mpi4py import MPI
        comm = MPI.COMM_WORLD
    rank, ranks = (comm.rank, comm.size) if comm is not None else (0, 1)
    execution = {"device": args.device, "cuda_device": args.cuda_device, "threads": 1}
    if comm is not None:
        execution.update(mpi=True, communicator_f=comm.py2f())

    def error(nx, steps, diffusion, end, amplitude):
        begin, stop = nx * rank // ranks, nx * (rank + 1) // ranks
        sinc = math.sin(math.pi / (2 * nx)) / (math.pi / (2 * nx))
        initial = [1e6 * (1 + amplitude * sinc * math.cos(math.pi * (cell + 0.5) / nx))
                   for cell in range(begin, stop)]
        request = {
            "mechanism": {"id": "manufactured-charge-balanced-avalanche", "status": "manufactured",
                          "species": [{"id": "e", "charge": -1, "mass_kg": 9.1093837015e-31},
                                      {"id": "p", "charge": 1, "mass_kg": 1.67262192369e-27,
                                       "elements": {"X": 1}},
                                      {"id": "X", "charge": 0, "mass_kg": 1.67262192369e-27,
                                       "elements": {"X": 1}}],
                          "reactions": [{"id": "growth", "reactants": {"e": 1, "X": 1},
                                         "products": {"e": 2, "p": 1},
                                         "rate": {"type": "constant", "A": 2e-20},
                                         "source": "manufactured analytic control"}]},
            "mesh": {"dimension": 2, "shape": [nx, 1, 1], "extent_m": [1, 1, 1]},
            "initial_densities_m3": {"e": 0, "p": 0, "X": 1e20},
            "local_initial": {"cell_begin": begin, "cell_count": stop - begin,
                              "densities_m3": {"e": initial, "p": initial}},
            "transport": {name: {"diffusion_m2_s": diffusion} for name in ("e", "p")},
            "boundaries": {"xmin": {"kind": "electrode", "potential_V": 0},
                           "xmax": {"kind": "electrode", "potential_V": 1}},
            "time": {"time_step_s": end / steps, "end_time_s": end, "bdf2": True, "adaptive": False},
            "solver": {"relative_tolerance": 1e-11, "absolute_density_tolerance_m3": 1e-7,
                       "potential_tolerance_V": 1e-12, "preconditioner": "block_ilu0"},
            "execution": execution,
        }
        result = raikou.solve_spatial_distributed(request)
        if not result["success"]:
            raise AssertionError(result["message"])
        numerator, denominator, charge, potential = 0.0, 0.0, 0.0, 0.0
        for offset, actual in enumerate(result["densities_m3"]["e"]):
            cell = begin + offset
            exact = 1e6 * math.exp(2 * end) * (1 + amplitude * sinc * math.cos(math.pi * (cell + 0.5) / nx)
                                              * math.exp(-diffusion * math.pi**2 * end))
            numerator += (actual - exact)**2
            denominator += exact**2
            charge = max(charge, abs(actual - result["densities_m3"]["p"][offset]) / exact)
            potential = max(potential, abs(result["potential_V"][offset] - (cell + 0.5) / nx))
        if comm is not None:
            numerator = comm.allreduce(numerator, op=MPI.SUM)
            denominator = comm.allreduce(denominator, op=MPI.SUM)
            charge = comm.allreduce(charge, op=MPI.MAX)
            potential = comm.allreduce(potential, op=MPI.MAX)
        if charge > 1e-9 or potential > 1e-9:
            raise AssertionError(f"manufactured charge/potential invariants failed: {charge}, {potential}")
        return math.sqrt(numerator / denominator)

    started = time.perf_counter()
    spatial = [error(nx, 400, 0.1, 0.05, 0.25) for nx in (8, 16, 32)]
    temporal = [error(1, steps, 0, 0.25, 0) for steps in (8, 16, 32)]
    spatial_orders = [math.log(a / b, 2) for a, b in zip(spatial, spatial[1:])]
    temporal_orders = [math.log(a / b, 2) for a, b in zip(temporal, temporal[1:])]
    if min(spatial_orders + temporal_orders) < 1.7:
        raise AssertionError(f"second-order refinement failed: {spatial_orders}, {temporal_orders}")
    elapsed = time.perf_counter() - started
    if comm is not None:
        elapsed = comm.allreduce(elapsed, op=MPI.MAX)
    if rank == 0:
        print(json.dumps({"case": "manufactured coupled avalanche refinement", "execution": execution,
                          "relative_L2_spatial_errors": spatial, "spatial_orders": spatial_orders,
                          "relative_L2_time_errors": temporal, "time_orders": temporal_orders,
                          "wall_time_s": elapsed}, indent=2))


if __name__ == "__main__":
    main()
