#!/usr/bin/env python3
"""Preserve v1/v2; add the explicit OHminus ground/isotropic sensitivity model."""
from pathlib import Path
import hashlib
import json
ROOT=Path(__file__).resolve().parents[1]
def main():
    p=ROOT/'data/collisions/h2o-gas-20261029-events.json';raw=p.read_bytes()
    base_sha=hashlib.sha256(raw).hexdigest()
    assert base_sha==json.loads(p.with_suffix('.lock.json').read_text())['dataset_sha256']
    data=json.loads(raw);data['id']='h2o-gas-20261029-attachment-v3';data['event_v2_dataset_sha256']=base_sha
    data['sources']['melton1972']=dict(url='https://facts-plus.com/articles/discharge_physics/1972.Cross.Sections.and.Interpretation.of.Dissociative.Attachment.Reactions.Producing.OH-.O-.and.H-.in.H2O.pdf',
        pdf_sha256='fa314c819c0c14036434cb26437d5031d824d365c6d1fa9a5bf971d4d3ba2458',
        doi='10.1063/1.1678051',role='Primary low-pressure OHminus attachment identification; TableIII and pp4221/4224. Rate here is the already frozen Song/Rawat-renormalized curve, not the original Melton magnitude.')
    data['conditional_event_models'].append(dict(id='OHminus_ground_isotropic_CM_v1',channel='H2O:attachment_yield:OHminus',
        data_support_eV=[4.5,12.5],products={'OHm_X_v0':1,'H_1s':1},parent_debit=1,electron_capture=1,
        chemical_reference_gain_eV=3.27,source=['song2021','ram2010','melton1972'],
        differential_model='Ground-state OHminus+H with host-supplied isotropic CM axis; exact relativistic two-body breakup and target-rest lab boost',
        mass_convention='M_OHminus=M_H2O+me+3.27eV/c2-M_H; host must bind the same immutable state mass basis',
        assumptions=['all OHminus assigned ground vibration/rotation/electronic state; maximum-translational-energy conditional endpoint',
            'CM angular distribution isotropic; no measured angular calibration',
            'no reliability bound on review-renormalized OHminus magnitude; very weak and historically disputed channel'],
        exclusions=['not an experimental product energy spectrum','no high-energy zero outside supported curve','not a complete water mechanism']))
    out=p.with_name('h2o-gas-20261029-attachment.json');encoded=(json.dumps(data,indent=2,allow_nan=False)+'\n').encode()
    if out.with_suffix('.lock.json').exists():assert hashlib.sha256(encoded).hexdigest()==json.loads(out.with_suffix('.lock.json').read_text())['dataset_sha256'],'Frozen v3 drift'
    out.write_bytes(encoded)
    print(json.dumps(dict(path=str(out),sha256=hashlib.sha256(encoded).hexdigest())))
if __name__=='__main__':main()
