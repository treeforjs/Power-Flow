"""Fetch and verify the pinned Zapdos reference inputs without executing them."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import tempfile
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
LIMIT = 64 * 1024 * 1024


def git_blob_digest(data: bytes) -> str:
    return hashlib.sha1(b"blob " + str(len(data)).encode("ascii") + b"\0" + data).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--destination", type=Path, default=ROOT / "build-references" / "zapdos")
    args = parser.parse_args()
    manifest = json.loads((ROOT / "provenance" / "zapdos_reference.json").read_text(encoding="utf-8"))
    revision = manifest["revision"]
    if not re.fullmatch(r"[0-9a-f]{40}", revision):
        raise ValueError("reference revision must be an immutable commit SHA")
    destination = args.destination.resolve()
    destination.mkdir(parents=True, exist_ok=True)
    receipts = []
    for item in manifest["files"]:
        relative = PurePosixPath(item["path"])
        if relative.is_absolute() or any(part in (".", "..") for part in relative.parts):
            raise ValueError("invalid reference path")
        target = (destination / Path(*relative.parts)).resolve()
        if not target.is_relative_to(destination):
            raise ValueError("reference path leaves destination")
        url = "https://raw.githubusercontent.com/shannon-lab/zapdos/" + revision + "/" + relative.as_posix()
        if target.exists():
            data = target.read_bytes()
        else:
            with urllib.request.urlopen(url, timeout=60) as response:
                data = response.read(LIMIT + 1)
        if len(data) > LIMIT:
            raise ValueError("reference file exceeds download limit")
        if git_blob_digest(data) != item["git_blob_sha1"]:
            raise ValueError(f"reference checksum mismatch: {relative}")
        if not target.exists():
            target.parent.mkdir(parents=True, exist_ok=True)
            with tempfile.NamedTemporaryFile(dir=target.parent, delete=False) as temporary:
                temporary.write(data)
                staging = Path(temporary.name)
            try:
                staging.replace(target)
            finally:
                staging.unlink(missing_ok=True)
        receipts.append({"path": relative.as_posix(), "bytes": len(data),
                         "git_blob_sha1": git_blob_digest(data), "sha256": hashlib.sha256(data).hexdigest()})
    receipt = {"reference_id": manifest["id"], "revision": revision, "files": receipts,
               "qualification": "download integrity only; no Raikou comparison performed"}
    (destination / "download-receipt.json").write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()
