#!/usr/bin/env python3
"""Serial CPU-only data qualification; never runs an EEDF, chemistry, or PIC solver."""
import csv
import fcntl
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import time
from decimal import Decimal as D, getcontext

ROOT=Path(__file__).resolve().parents[1]
OUT=Path('/home/treefor/Documents/Codex/2026-10-28/we/outputs/h2o-collision-data-20261029')
LOCK=OUT.parent/'pic-profile/testing-core7.lock'

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def dump(path,value):path.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')
def run(args,log,expected=0,timeout=45):
    r=subprocess.run([str(x) for x in args],capture_output=True,text=True,timeout=timeout)
    log.write_text(r.stdout+r.stderr)
    if r.returncode!=expected:raise RuntimeError(f'Unexpected result{r.returncode}; see {log}')
    return r.stdout

def main():
    if os.sched_getaffinity(0)!={7} or os.getpriority(os.PRIO_PROCESS,0)!=15:raise RuntimeError('CPU7/nice15 required')
    lease=LOCK.open('a');fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    for key in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:
        if os.environ.get(key)!='1':raise RuntimeError('One thread required')
    OUT.mkdir(exist_ok=True);attempt=1
    while (OUT/f'attempt-{attempt:03d}').exists():attempt+=1
    out=OUT/f'attempt-{attempt:03d}';out.mkdir();began=time.monotonic()
    for p in [OUT/'source-documents/song-2021.pdf',OUT/'source-documents/munoz-2007.pdf']:
        if not p.exists():raise RuntimeError('Retained primary PDFs required')
    run(['python3',ROOT/'tools/build_h2o_collision_data.py'],out/'data-build.log')
    path=ROOT/'data/collisions/h2o-gas-20261029.json';data=json.loads(path.read_text())
    before=sha(path);by_id={p['id']:p for p in data['channels']}
    lock_path=ROOT/'data/collisions/h2o-gas-20261029.lock.json'
    if lock_path.exists():assert json.loads(lock_path.read_text())['dataset_sha256']==before,'Frozen dataset drift'
    for source,name in [('song2021','song-2021.pdf'),('munoz2007','munoz-2007.pdf')]:
        assert sha(OUT/'source-documents'/name)==data['sources'][source]['pdf_sha256']
    flags=['/usr/sbin/c++','-std=c++20','-O2','-Wall','-Wextra','-Wpedantic','-Werror','-I'+str(ROOT/'include')]
    run(flags+[ROOT/'tests/test_collision_data.cpp','-o',out/'test-collision-data'],out/'build-test.log')
    run(flags+[ROOT/'tools/h2o_collision_query.cpp','-o',out/'h2o-collision-query'],out/'build-query.log')
    native=json.loads(run([out/'test-collision-data',path],out/'native-tests.json'))
    assert native['passed']
    linkage=run(['ldd',out/'h2o-collision-query'],out/'linkage.txt')
    assert not any(s in linkage.lower() for s in ['cuda','cudss','nvml','nvidia','libmpi'])
    query=out/'h2o-collision-query'
    tail_results=[]
    for ident in ['H2O:munoz2007:elastic_integral','H2O:munoz2007:recommended_inelastic','H2O:munoz2007:stopping_energy_area','H2O:nist_BEB_valence']:
        tail_results.append(json.loads(run([query,path,ident,8084.470604111418],out/(ident.replace(':','_')+'.json'))))
    for ident in ['H2O:elastic_momentum','H2O:ion_yield:H2O+','H2O:attachment_yield:Hminus','H2O:neutral_OH_yield']:
        run([query,path,ident,8084.470604111418],out/(ident.replace(':','_')+'-coverage-error.txt'),expected=78)
    # Independent high-precision evaluation of the PUBLISHED analytic formula,
    # not a claim of experimental or CGI-value validation at8keV.
    getcontext().prec=60;pi=D('3.14159265358979323846264338327950288419716939937510582097494459')
    p=by_id['H2O:nist_BEB_valence'];oracle=[]
    for energy in ['13','20','50','100','1000','8084.470604111418','10000']:
        T=D(energy);total=D(0)
        for o in p['orbitals']:
            B=D(str(o['B_eV']));U=D(str(o['U_eV']));N=D(o['N']);Q=D(o['Q'])
            if T<=B:continue
            t=T/B;u=U/B;S=4*pi*D(str(p['bohr_radius_m']))**2*N*(D(str(p['rydberg_eV']))/B)**2
            total+=S/(t+u+1)*(Q*t.ln()/2*(1-1/t**2)+(2-Q)*(1-1/t-t.ln()/(t+1)))
        actual=json.loads(run([query,path,'H2O:nist_BEB_valence',energy],out/f'beb-{energy}.json'))['value']
        assert math.isclose(actual,float(total),rel_tol=2e-14)
        oracle.append(dict(energy_eV=energy,independent_decimal_formula_m2=str(total),native_m2=actual))
    dump(out/'beb-formula-checks.json',dict(passed=True,method='60-digit Decimal formula evaluation',
        independent_experimental_validation=False,NIST_CGI_retrieved=False,cases=oracle))
    assert sha(path)==before
    requirements=OUT.parent/'water-breakdown-tonight-20261029/coupling-port-requirements.json'
    original=Path('/home/treefor/projects/raikou')
    input_paths=[requirements,OUT/'source-acquisition.json',original/'include/raikou/electron_boltzmann.h',
        original/'include/raikou/electron_coupling.h',original/'src/electron_boltzmann.cpp',original/'mechanisms/h2o_research.json']
    summary=dict(status='numerical_dataset_and_strict_loader_qualified_not_full_fragmentation',
        dataset_revision=data['id'],dataset_sha256=before,channels=len(data['channels']),
        numeric_points=sum(len(p.get('values',[])) for p in data['channels']),native_checks=native,
        high_energy_observables=tail_results,BEB_formula_checks=len(oracle),
        full_fragmentation_ready=False,MCC_event_kernels_qualified=False,
        conditional_parent_kernel_conservation_tested=True,
        conditional_parent_kernel_data_domain_eV=[13.5,1000],
        conditional_parent_model_experimentally_calibrated=False,
        reduced_transport_domain_eV=data['reduced_model']['energy_domain_eV'],
        full_retained_8keV_population_admitted_for_reduced_model=False,
        CPU=7,nice=15,threads=1,testing_lease_held=True,wall_s=time.monotonic()-began,
        MPI_initialized=False,GPU_used=False,PIC_or_chemistry_evolution=False,
        input_sha256={str(p):sha(p) for p in input_paths})
    dump(out/'validation.json',summary)
    dump(OUT/'latest.json',dict(result_directory=str(out),dataset_sha256=before))
    dump(OUT/'validation.json',summary)
    dump(out/'seal.json',dict(files_sha256={str(p.relative_to(out)):sha(p) for p in sorted(out.rglob('*')) if p.is_file()},
        source_sha256={str(p.relative_to(ROOT)):sha(p) for p in [path,ROOT/'include/raikou/collision_data.h',ROOT/'include/raikou/h2o_conditional_parent.h',ROOT/'tests/test_collision_data.cpp',ROOT/'tools/build_h2o_collision_data.py',ROOT/'tools/h2o_collision_query.cpp',Path(__file__)]}))
    print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
