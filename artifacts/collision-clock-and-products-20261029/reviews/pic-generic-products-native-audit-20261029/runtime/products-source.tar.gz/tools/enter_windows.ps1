param([string]$CudaDirectory = $env:CUDA_PATH, [string]$CmakeDirectory = '', [string]$MpiDirectory = '')
$ErrorActionPreference='Stop'
$vswhere=Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio/Installer/vswhere.exe'
$vs=& $vswhere -latest -products '*' -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
$vcvars=Join-Path $vs 'VC/Auxiliary/Build/vcvars64.bat'
$environmentLines=& $env:ComSpec /d /s /c "call `"$vcvars`" >nul && set"
if($LASTEXITCODE -ne 0){throw 'Cannot load the native compiler environment'}
foreach($line in $environmentLines){if($line -match '^([^=]+)=(.*)$'){[Environment]::SetEnvironmentVariable($Matches[1],$Matches[2],'Process')}}
if($CmakeDirectory){$env:PATH=$CmakeDirectory + ';' + $env:PATH}
elseif(-not (Get-Command cmake -ErrorAction SilentlyContinue) -and (Test-Path 'C:/msys64/ucrt64/bin/cmake.exe')){
  $env:PATH='C:/msys64/ucrt64/bin;' + $env:PATH
}
if($CudaDirectory){
  $nvcc=Join-Path $CudaDirectory 'bin/nvcc.exe'
  if(-not (Test-Path -LiteralPath $nvcc)){throw "CUDA compiler not found: $nvcc"}
  $env:PATH=(Join-Path $CudaDirectory 'bin') + ';' + $env:PATH
  $env:CUDACXX=$nvcc
  $env:CUDA_PATH=$CudaDirectory
}
if($MpiDirectory){
  $env:PATH=$MpiDirectory + ';' + $env:PATH
  $env:RAIKOU_DLL_DIRECTORIES=$MpiDirectory
}
