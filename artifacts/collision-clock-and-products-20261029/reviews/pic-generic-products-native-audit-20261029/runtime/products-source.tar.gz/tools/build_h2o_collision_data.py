#!/usr/bin/env python3
"""Reproduce frozen factual transcriptions. Original PDFs remain outside git."""
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
A0=5.29177210903e-11
SOURCES={
 'song2021':dict(doi='10.1063/5.0035315',url='https://discovery.ucl.ac.uk/id/eprint/10128988/1/5.0035315.pdf',
   title='Cross Sections for Electron Collisions with H2O',pdf_sha256='d94ae0c73ab745a3e5b958d096f2c774b123b8257877e2d71911990e9b83b595',
   role='recommended numerical compilation; primary lineage retained per channel'),
 'munoz2007':dict(doi='10.1103/PhysRevA.76.052707',url='https://documenta.ciemat.es/bitstreams/5c6b9a12-3808-4937-8832-7f819b7957e5/download',
   title='Electron-scattering cross sections and stopping powers in H2O',pdf_sha256='3327cefd9a686013deaf73a2095c25f333fa058898cbe7e545a2c96813c77a55',
   role='primary gas-phase experiment and optical-potential calculations'),
 'nist_beb':dict(url='https://physics.nist.gov/cgi-bin/Ionization/table.pl?ionization=H2O',
   theory_url='https://physics.nist.gov/PhysRefData/Ionization/intro.html',
   primary_doi=['10.1103/PhysRevA.50.3954'],
   role='author-maintained orbital constants and nonrelativistic BEB formula; valence only; not branching'),
}
CHANNELS=[]
def rows(s):return [[float(v) if v!='-' else None for v in line.split()] for line in s.strip().splitlines()]
def channel(ident,kind,raw,scale=1e-20,source='song2021',table='',threshold=None,**kw):
    p=dict(id=ident,target='H2O',phase='gas',observable=kind,model='linear_table',
        energy_eV=[x[0] for x in raw],values=[x[1] for x in raw],ordinate_scale_to_SI=scale,unit_SI='m2',
        support_eV=[raw[0][0],raw[-1][0]],zero_below_eV=threshold,source=source,source_locator=table,
        outside_support='error',interpolation='linear_in_energy_and_ordinate',
        exclusive_products=None,event_energy_partition=None,collision_process_admission=None,
        use='observable_only',**kw)
    CHANNELS.append(p);return p

def build():
    channel('H2O:elastic_integral_song2021','elastic_integral',rows('''
0.1 987.8
0.2 533.1
0.3 368.1
0.4 282.1
0.5 229.0
0.6 193.0
0.7 166.9
0.8 147.2
0.9 131.7
1 119.3
2 63.1
4 36.2
6 28.6
10 20.8
20 13.6
30 10.1
40 7.90
50 6.62
60 5.37
70 4.72
80 4.13
90 3.60
100 3.43'''),table='Table3, printed9/PDF10',lineage='Song2021 Sec4.2; experimental/theoretical recommended elastic ICS; rotational resolution is source-dependent')
    momentum=rows('''
0.001 490 39000
0.002 420 19300
0.005 330 7530
0.01 267 3670
0.02 208 1770
0.05 127 665
0.1 76.0 284
0.2 40.7 126
0.3 27.0 75.9
0.5 15.1 40.7
1.0 6.60 17.8
1.4 4.90 12.3
1.7 4.30 10.3
2.0 4.05 9.11
2.5 4.10 7.89
3.0 4.30 7.33
3.5 4.47 6.95
4.0 4.66 6.72
5.0 5.05 6.61
6.0 6.88 6.88
8.0 8.04 -
10 8.37 -
15 8.05 -
20 6.31 -
30 4.04 -
50 2.00 -
70 1.48 -
100 1.01 -
200 0.464 -
300 0.296 -
400 0.208 -
500 0.156 -
700 0.093 -
1000 0.0515 -''')
    emt=channel('H2O:elastic_momentum','elastic_momentum_transfer',[[r[0],r[1]] for r in momentum],table='Table4, printed10/PDF11',
        lineage='Yousfi and Benabdessadok1996 JApplPhys80,6619; source recommendation extends to1000eV',
        rotation_included=False)
    emt['collision_process_admission']='elastic_momentum_only';emt['use']='reduced_transport'
    channel('H2O:effective_momentum','effective_momentum_transfer',[[r[0],r[2] if r[2] is not None else r[1]] for r in momentum],
        table='Table4, printed10/PDF11; caption explicitly equates TMT=EMT above6eV',rotation_included=True,
        lineage='Pack,Voshall,Phelps1962 and Ness,Robson1986; thermal/swarm effective quantity, not an elastic event cross section')
    channel('H2O:rotation_J000_to_J1_sum','rotational_excitation',rows('''0.0049290 .10004
0.0049810 1074.3
0.0051940 1290.8
0.0053590 1454.5
0.0064010 1969.1
0.010138 2158.5
0.016396 1933.3
0.052850 980.1
0.080280 744.1
0.11942 554.7
0.17764 413.5
0.25878 308.24
0.38495 225.59
0.56080 168.17
0.81690 123.08
1.0281 100.57
1.4977 73.6
2.1818 53.869
3.1783 38.708
4.6301 28.33
5.7060 24.015
9.6230 16.942
14.314 11.416
19.180 8.828
29.133 6.115
49.130 3.6236'''),table='Table5, printed12/PDF13, J0->J1 column',
        lineage='Faure,Gorfinkiel,Tennyson MNRAS347,323(2004); Song2021 recommended compilation/extension Sec5',
        target_state='ground rotational000',
        missing=['resolved final Ka,Kc energies/populations and prompt angular kernel','low onset gap','above49.13eV'],
        overlap_group='rotation_vs_effective_momentum')
    bend=rows('''0.198 0
0.26 2.15
0.5 1.162
1 0.441
2 0.166
4 0.17
5 0.193
6 0.26
8 0.313
10 0.312
15 0.212
20 0.144
30 0.0972
50 0.0458
100 0.0108''')
    p=channel('H2O:excite_v010','state_excitation',bend,table='Tables6/7, printed13/14, PDF14/15',threshold=.198,
        lineage='Song2021 recommended synthesis of measurements and R-matrix calculations, Sec6',state_products={'H2O_v010':1},
        energy_loss_eV=.198)
    p['exclusive_products']={'e_g':1,'H2O_v010':1};p['collision_process_admission']='one_way_bend';p['use']='reduced_transport'
    p['event_energy_partition']={'electron_loss_eV':.198,'internal_gain_eV':.198,'angular_distribution':'not supplied; reduced isotropic operator only'}
    stretch=rows('''0.453 0
0.53 4.44
0.875 0.81
1 0.389
2 0.323
4 0.428
5 0.567
6 0.745
8 0.799
10 0.643
15 0.226
20 0.0806
30 0.0245
50 0.0159
100 0.006''')
    channel('H2O:stretch_v100_plus_v001','lumped_state_excitation',stretch,table='Table7, printed14/PDF15',threshold=.453,
        lineage='Song2021 Sec6; unresolved symmetric100 and antisymmetric001 stretches',
        state_thresholds_eV={'H2O_v100':.453,'H2O_v001':.466},
        state_split_recommendation={'v100':.56,'v001':.44},
        missing=['onset shape; fixed theory-based split has no independent energy-dependent uncertainty','do not map entire sum to native H2O_v100'])
    for name,threshold,fraction in [('v100',.453,.56),('v001',.466,.44)]:
        channel('H2O:excite_'+name,'state_excitation',[[e,v*fraction] for e,v in stretch if e>=.53],
            table='Table7 and Fig13/main text, printed14/PDF15',threshold=threshold,
            lineage='Song2021 explicitly recommends symmetric/asymmetric0.56/0.44 split, from its theory ratio at3eV',
            energy_loss_eV=threshold,state_products={'H2O_'+name:1},
            assumptions=['constant theory-based split, not measured state-resolved branching','main text/caption assign symmetric56percent; plot legend has inconsistent asymmetric56percent wording'],
            missing=['threshold-to0.53eV gap','above100eV','differential angular kernel'])
    channel('H2O:electronic_A1B1','electronic_state_excitation',rows('''9 18.02
10 16.21
12 15.80
15 16.35
21.9 12.50
24.8 12.87
28.1 13.19
31.5 13.31
35.8 13.31
40.6 13.11
41.8 13.04
47.4 12.78
56.1 12.31
65.4 11.83
77.3 11.04
87.5 10.51
100.7 9.73
113.1 9.29
134.1 8.50
160.1 7.64
184.4 7.03
232.3 6.06
266.2 5.52
360.4 4.51
459.9 3.75
572 3.21
638.7 2.96
756.5 2.61
877.9 2.33
977.7 2.12'''),scale=1e-22,table='Tables8/9, printed15/16, PDF16/17',excitation_energy_eV=7.49,
        lineage='Ralphs etal2013 below17eV; BEf model above17eV; Matsui etal overlap; Song2021Sec7',
        missing=['7.49-9eV onset','prompt dissociation branching and internal/recoil/radiative partition','no extrapolation to10keV'],
        overlap_group='electronic_excitation_and_OH_observable_yields')
    channel('H2O:neutral_OH_yield','neutral_fragment_yield',rows('''10 .103
15 .330
20 .481
30 .893
50 1.30
75 1.44
100 1.41
150 1.36
200 1.20
250 1.09
300 .96'''),table='Table10, printed17/PDF18',threshold=5.10,
        lineage='Harb,Kedzierski,McConkey JCP115,5507(2001); review DEA normalization',
        uncertainty='caption40percent; nearby text36percent, discrepancy retained',
        overlap_group='electronic_excitation_and_OH_observable_yields',
        missing=['5.10-10eV gap','prompt OH state/cascade/recoil and exclusive reaction branching','above300eV'])
    ions=rows('''13.5 .025 - - - - - .025
15 .126 - - - - - .126
17.5 .272 .0013 - - - - .274
20 .411 .0145 - - - .0024 .428
22.5 .549 .0500 - - - .0091 .609
25 .652 .0855 .0022 - - .0207 .761
30 .815 .1600 .0037 - .00018 .0433 1.02
35 .958 .222 .0070 - .00039 .0759 1.26
40 1.05 .264 .0132 - .00057 .110 1.43
45 1.12 .300 .0207 - .00070 .145 1.59
50 1.18 .329 .0275 - .00065 .178 1.72
60 1.24 .364 .0394 - .00066 .235 1.88
70 1.27 .389 .0484 - .00069 .279 1.99
80 1.31 .409 .0594 - .00063 .317 2.09
90 1.31 .412 .0666 .0000800 .00078 .343 2.13
100 1.31 .418 .0695 .000194 .00075 .360 2.16
110 1.29 .415 .0738 .000460 .00073 .370 2.15
125 1.27 .412 .0763 .000690 .00064 .375 2.13
150 1.21 .393 .0752 .00116 .00077 .371 2.05
175 1.16 .381 .0731 .00178 .00071 .366 1.99
200 1.12 .363 .0707 .00179 .00054 .351 1.90
250 1.01 .334 .0634 .00195 .00050 .316 1.73
300 .921 .311 .0551 .00179 .00045 .284 1.57
400 .789 .266 .0434 .00134 .00040 .237 1.34
500 .696 .23 .0373 .00105 .00032 .198 1.16
600 .618 .203 .0313 .000960 .00029 .172 1.02
700 .555 .185 .0271 .000800 .00033 .149 .917
800 .502 .169 .0240 .000800 .00022 .135 .830
900 .465 .156 .0220 .000600 .00032 .120 .763
1000 .432 .143 .0194 .000660 .00024 .109 .705''')
    for col,(name,unc) in enumerate([('H2O+',6),('OH+',7),('O+',9),('O_atomic_2plus',7),('H2+',13),('H+',16),('total',6)],1):
        raw=[[r[0],r[col]] for r in ions if r[col] is not None]
        p=channel('H2O:ion_yield:'+name,'parent_ion_production' if col==1 else 'total_ionization_observable' if col==7 else 'partial_ion_yield',raw,
            table='Table12, printed20/PDF21',threshold=12.621 if col==1 else None,
            lineage='Straub etal JCP108,109(1998), DOI10.1063/1.475367; Lindsay/Mangan recommendation',
            uncertainty_percent=unc,isotope_proxy='D2O-based recommendation' if col in [1,2,3,5] else 'H2O',
            missing_cells_eV=[r[0] for r in ions if r[col] is None],
            multiplicity='ion-production yield; not exclusive branching; total is not a stable-parent cross section',
            missing=['appearance thresholds for fragment channels','exclusive neutral/coincident-ion products','secondary electron/internal/recoil energy distribution','above1000eV'])
        if col==1:
            p['exclusive_products']={'e_g':2,'H2Op':1}
            p['multiplicity']='one surviving singly charged intact parent per such event; no dissociative branches included'
    hminus=rows('''4.5 0
5 .06
5.5 .68
6 3.02
6.5 4.61
7 2.98
7.5 1.22
8 .94
8.5 1.26
9 1.12
9.5 .60
10 .26
10.5 .13
11 .11
11.5 .12
12 .08
12.5 .07
13 .05
13.5 .04
14 .02
14.5 .02
15 .01
15.5 .01
16 .01
16.5 .01
17.5 .01
18 .01
18.5 .01
19 .01
19.5 .02''')
    omin=rows('''4.5 .01
5 .03
5.5 .09
6 .10
6.5 .20
7 .31
7.5 .23
8 .24
8.5 .80
9 1.12
9.5 1.24
10 1.14
10.5 1.36
11 1.96
11.5 2.65
12 2.74
12.5 2.41
13 1.89
13.5 1.10
14 .56
14.5 .28
15 .26
15.5 .16
16 .11''')
    ohmin=rows('''4.5 .04
5 .19
5.5 .79
6 2.56
6.5 5.50
7 2.97
7.5 1.65
8 3.20
8.5 3.86
9 2.08
9.5 .96
10 1.71
10.5 3.19
11 3.93
11.5 3.79
12 1.92
12.5 .88''')
    for name,raw,scale,threshold in [('Hminus',hminus,1e-22,4.35),('Ominus',omin,1e-23,3.56),('OHminus',ohmin,1e-24,3.27)]:
        channel('H2O:attachment_yield:'+name,'attachment_anion_yield',raw,scale=scale,threshold=threshold,
            table='Table13, printed21/PDF22; different column units',
            lineage='Rawat etal JPhysB40,4625(2007), DOI10.1088/0953-4075/40/24/007' if name!='OHminus' else 'Melton JCP57,4218(1972), review-renormalized by Rawat Ominus peak',
            uncertainty='15percent for Hminus/Ominus; no reliable OHminus uncertainty',
            asymptotic_threshold_source='Haxton etal PRA75,012710(2007), Fig19; not resonance peak',
            missing=['threshold-to-first-point gap','neutral fragment/internal/recoil branching','above last point; no automatic high-energy zero'],
            branches_unresolved={'Hminus':['Hminus+OH(X)','Hminus+OH(excited)','Hminus+H+O'],
                'Ominus':['Ominus+H2','Ominus+H+H'],'OHminus':['OHminus+H internal states unresolved']}[name])
    munoz=rows('''1 107 - 356 463 - -
1.5 98.4 - 253 352 - -
2 90.4 - 199 289 - -
3 76.0 - 141 217 - -
4 64.2 - 110 174 - -
5 55.5 - 90.7 146 - -
7.5 47.1 .001 63.8 111 - -
10 42.4 .05 49.6 92.0 - -
15 35.7 1.77 34.7 72.2 - -
20 30.1 5.47 26.9 62.5 - -
30 22.2 11.4 18.7 52.3 - -
40 18.2 12.9 14.5 45.6 - -
50 15.6 13.1 11.9 40.6 6.65 36.6
75 11.9 12.4 8.24 32.5 7.95 30.7
100 9.77 11.4 6.35 27.5 8.26 26.4
150 7.42 9.73 4.40 21.5 7.72 21.2
200 6.11 8.50 2.39 18.0 6.93 17.9
300 4.65 6.84 2.34 13.8 5.74 14.1
400 3.83 5.75 1.80 11.4 4.88 11.6
500 3.28 5.00 1.46 9.74 4.29 9.66
750 2.45 3.78 1.01 7.24 3.16 7.09
1000 1.98 3.07 .775 5.82 2.54 5.66
1500 1.44 2.25 .533 4.22 1.83 4.12
2000 1.14 1.78 .408 3.33 1.45 3.29
3000 .814 1.26 .280 2.35 1.05 2.41
4000 .635 .987 .215 1.84 .845 1.92
5000 .523 .811 .174 1.51 .702 1.60
7500 .366 .566 .120 1.05 - -
10000 .284 .436 .0914 .811 - -''')
    for col,name,kind in [(1,'elastic_integral','elastic_integral'),(2,'inelastic_integral','aggregate_inelastic'),
        (3,'rotational_integral_300K','thermal_rotational_integral'),(4,'theory_total','total_scattering'),
        (5,'measured_ionization','gross_ionization_observable'),(6,'measured_total','total_scattering')]:
        channel('H2O:munoz2007:'+name,kind,[[r[0],r[col]] for r in munoz if r[col] is not None],scale=A0*A0,
            source='munoz2007',table='TableI, printed4/PDF4',lineage='primary optical-potential calculation' if col<5 else 'primary measurement',
            uncertainty='measured TCS5percent, ion-current observable7percent; theory not a measured uncertainty',
            limitations=['integral elastic is not momentum transfer','inelastic includes excitation/ionization and overlaps explicit channels',
                'rotational200eV printed2.39 gives total mismatch; preserve value, do not repair by inference'])
    stopping=rows('''7.5 84.0 .00001 .00497
10 78.8 .00054 .3425
15 68.0 .0245 18.53
20 59.6 .0876 75.84
30 47.9 .218 181.3
40 41.4 .283 245.8
50 36.6 .323 267.4
75 30.7 .381 298.9
100 26.4 .414 288.9
150 21.2 .451 260.1
200 17.9 .472 243.9
300 14.1 .494 206.4
400 11.6 .505 175.8
500 9.66 .513 149.8
750 7.09 .522 126.3
1000 5.66 .527 111.8
1500 4.12 .532 82.26
2000 3.29 .534 65.93
3000 2.41 .535 48.33
4000 1.92 .537 38.66
5000 1.60 .537 32.23
7500 1.16 .538 23.40
10000 .92 .537 18.52''')
    channel('H2O:munoz2007:recommended_total','total_scattering',[[r[0],r[1]] for r in stopping],scale=A0*A0,
        source='munoz2007',table='TableII, printed6/PDF6',lineage='primary recommended gas-phase totals',
        uncertainty='5-18percent low energy; approximately10percent5000-10000eV theory continuation',
        missing=['cannot decompose into exclusive event channels'])
    channel('H2O:munoz2007:recommended_inelastic','aggregate_inelastic',[[r[0],r[1]*r[2]] for r in stopping],scale=A0*A0,
        source='munoz2007',table='TableII total*mu, Eq3',lineage='derived exactly from primary TableII total and inelastic fraction',
        missing=['full energy-loss and product distribution; must not add to explicit ionization/excitation'])
    p=channel('H2O:munoz2007:stopping_energy_area','energy_loss_moment',[[r[0],r[3]] for r in stopping],
        scale=1e5*18.01528*1.66053906660e-27,source='munoz2007',table='TableII, This work column, printed6/PDF6',
        lineage='primary gas-phase mass stopping power; MeV cm2/g *1e5*molecule_mass_kg ->eV m2',
        uncertainty='15percent assigned by authors;10-5000eV loss spectra,7500/10000eV are source model continuation',
        missing=['differential event energy distribution; overlaps ALL explicit electronic losses'])
    p['unit_SI']='eV m2';p['molecular_mass_amu']=18.01528
    CHANNELS.append(dict(id='H2O:nist_BEB_valence',target='H2O',phase='gas',observable='valence_ionization_model',
        model='nist_BEB',unit_SI='m2',source='nist_beb',support_eV=[0,10000],zero_below_eV=12.61,
        orbitals=[dict(label=l,B_eV=b,U_eV=u,N=2,Q=1) for l,b,u in [('2a1',36.88,70.71),('1b2',19.83,48.36),('3a1',15.57,59.52),('1b1',12.61,61.91)]],
        bohr_radius_m=5.2918e-11,rydberg_eV=13.6057,outside_support='error',
        exclusive_products=None,event_energy_partition=None,collision_process_admission=None,use='observable_only',
        limitations=['eight valence electrons only; oxygen core omitted','not stable H2O+ branching or all-shell gross yield',
          'no double ionization or Auger multiplicity','nonrelativistic ceiling10keV is model support, not water accuracy validation',
          'NIST generic5-20percent accuracy statement only to~1keV','no H2O-specific secondary energy spectrum supplied']))
    data=dict(schema='raikou-strict-gas-collision-data-v1',id='h2o-gas-20261029-v1',phase='gas',target='H2O',
        sources=SOURCES,channels=CHANNELS,
        conditional_event_models=[dict(id='parent_ground_equal_pair_CM_v1',channel='H2O:ion_yield:H2O+',
            admission='explicit opt-in only; not a measured differential kernel',data_support_eV=[13.5,1000],
            products={'e_g':2,'H2Op':1},parent_debit=1,chemical_reference_gain_eV=12.621,
            target='stationary ground-state gas H2O; initially unexcited parent',
            final_state='ground intact H2O+; ignores actual parent-ion internal excitation',
            kinematics='exact relativistic CM boost; equal-energy back-to-back electron pair, ion at rest in CM; isotropic pair axis from host RNG',
            ion_mass_convention='M_ion=M_neutral-m_e+12.621eV/c^2; chemical reference ledger represents this mass defect, not a second heat source',
            limitations=['does not reproduce measured secondary spectrum/angles or vibrational branching','not eligible above1keV or in12.621-13.5eV table gap',
                'no dissociative/double/core ionization or neutral fragmentation','host owns RNG, macro splitting, inventory checks, atomic staging/restart/rollback'])],
        quarantine=[dict(id='H2O:O_1S_yield',reason='Song2021Table11 unit/text discrepancy factor100; no admission')],
        reduced_model=dict(id='ground_target_bend_and_momentum_only',energy_domain_eV=[.001,100],
            channels=['H2O:elastic_momentum','H2O:excite_v010'],
            meaning='supported reduced transport operator, not breakdown/fragmentation or a complete water swarm set',
            explicit_omissions=['rotation','stretching split','other electronic states','ionization','attachment','neutral dissociation','heavy/product reactions'],
            angular_approximation='momentum-transfer matched isotropic elastic and isotropic one-way bend; no DCS validation',
            gas_state='ground vibrational target; target rotational/thermal populations must be supplied separately'),
        full_fragmentation_ready=False,high_energy_complete_mechanism=False,
        electron_owner='PIC/MCC or Raikou F0, exclusively; rate queries perform no time evolution')
    dest=ROOT/'data/collisions/h2o-gas-20261029.json';dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_text(json.dumps(data,indent=2,allow_nan=False)+'\n')
    print(json.dumps(dict(path=str(dest),channels=len(CHANNELS),tabulated_points=sum(len(p.get('values',[])) for p in CHANNELS),sha256=hashlib.sha256(dest.read_bytes()).hexdigest())))

if __name__=='__main__':build()
