"""Check Raikou's Poisson operator against a pinned Zapdos discharge snapshot.

Requires the reference download plus numpy/scipy for Exodus reading. This is a
fixed-charge operator comparison, not a coupled-discharge or experimental validation.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
from scipy.io import netcdf_file
import raikou

ROOT = Path(__file__).resolve().parents[1]
QE_RAIKOU = 1.602176634e-19


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--reference", type=Path, default=ROOT / "build-references" / "zapdos")
    parser.add_argument("--cells", type=int, nargs="+", default=[32, 64, 128, 256])
    parser.add_argument("--device", choices=["cpu", "cuda"], default="cpu")
    parser.add_argument("--linear-restart", type=int, default=256)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--relative-tolerance", type=float, default=1e-3,
                        help="acceptance bound for the finest requested grid (default 0.1%%)")
    args = parser.parse_args()
    if any(n < 2 for n in args.cells) or args.linear_restart < 1 or not np.isfinite(args.relative_tolerance) or args.relative_tolerance <= 0:
        parser.error("each grid needs at least two cells")
    manifest = json.loads((ROOT / "provenance" / "zapdos_reference.json").read_text(encoding="utf-8"))
    entry = next(item for item in manifest["files"] if item["path"].endswith("metastables_out.e"))
    filename = args.reference / entry["path"]
    data = filename.read_bytes()
    digest = hashlib.sha1(b"blob " + str(len(data)).encode("ascii") + b"\0" + data).hexdigest()
    if digest != entry["git_blob_sha1"]:
        raise ValueError("Zapdos gold file does not match the pinned reference")
    with netcdf_file(filename, mmap=False) as source:
        names = [row.tobytes().split(b"\0", 1)[0].decode("ascii") for row in source.variables["name_nod_var"].data]
        x = source.variables["coordx"].data.copy()
        order = np.argsort(x)
        x = x[order]
        time = float(source.variables["time_whole"].data[-1])
        fields = {name: source.variables[f"vals_nod_var{i+1}"].data[-1].copy()[order] for i, name in enumerate(names)}
    # The pinned input uses a normalized [0,1] coordinate and dom0Scale=25.4e-3 m.
    # Its Zapdos.h constants are e=1.6e-19 C, N_A=6.02e23, eps0=8.85e-12 F/m.
    # Match its charge exactly despite Raikou using the current exact SI charge.
    length = 25.4e-3
    charge_equivalent_molar_factor = 1.6e-19 * 6.02e23 / QE_RAIKOU
    phi_reference = fields["potential"] * 1000  # upstream potential_units=kV
    measurements = []
    for count in args.cells:
        centers = (np.arange(count) + 0.5) / count
        expected = np.interp(centers, x, phi_reference)
        ion = charge_equivalent_molar_factor * np.exp(np.interp(centers, x, fields["Ar+"]))
        electron = charge_equivalent_molar_factor * np.exp(np.interp(centers, x, fields["em"]))
        request = {
            "mechanism": {"id": "zapdos_frozen_charge", "status": "operator-reference",
                          "species": [{"id": "Ar+", "elements": {"Ar": 1}, "charge": 1},
                                      {"id": "e", "charge": -1}], "reactions": []},
            "mesh": {"type": "structured", "dimension": 2, "shape": [count, 1, 1], "extent_m": [length, 1e-3, 1e-3]},
            "transport": {}, "initial_densities_m3": {"Ar+": ion.tolist(), "e": electron.tolist()},
            "permittivity_F_m": 8.85e-12,
            "boundaries": {"xmin": {"kind": "electrode", "potential_V": float(phi_reference[0])},
                           "xmax": {"kind": "electrode", "potential_V": float(phi_reference[-1])}},
            "time": {"time_step_s": 1e-10, "end_time_s": 0},
            "solver": {"device": args.device, "linear_restart": args.linear_restart},
        }
        result = raikou.solve_spatial(request)
        if not result["success"]:
            raise RuntimeError(result["message"])
        actual = np.asarray(result["potential_V"])
        error = actual - expected
        norm = max(float(np.linalg.norm(expected)), 1e-30)
        measurements.append({"cells": count, "relative_l2": float(np.linalg.norm(error) / norm),
                             "max_absolute_error_V": float(np.max(np.abs(error))),
                             "reference_range_V": [float(np.min(expected)), float(np.max(expected))]})
    report = {"reference_id": manifest["id"], "revision": manifest["revision"], "snapshot_time_s": time,
              "scope": "Poisson consistency for frozen upstream log-molar charge; not coupled-discharge validation",
              "device": args.device, "measurements": measurements,
              "relative_tolerance": args.relative_tolerance,
              "passed": max(measurements, key=lambda item: item["cells"])["relative_l2"] <= args.relative_tolerance}
    rendered = json.dumps(report, indent=2)
    if args.output:
        args.output.write_text(rendered + "\n", encoding="utf-8")
    print(rendered)
    if not report["passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
