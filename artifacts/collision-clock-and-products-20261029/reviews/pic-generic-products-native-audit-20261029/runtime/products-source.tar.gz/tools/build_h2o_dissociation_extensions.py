#!/usr/bin/env python3
"""Add a conditional prompt A1B1 event, keeping all prior frozen data intact."""
from pathlib import Path
import hashlib
import json
ROOT=Path(__file__).resolve().parents[1]
def main():
    p=ROOT/'data/collisions/h2o-gas-20261029-attachment.json';raw=p.read_bytes();base=hashlib.sha256(raw).hexdigest()
    assert base==json.loads(p.with_suffix('.lock.json').read_text())['dataset_sha256']
    data=json.loads(raw);data['id']='h2o-gas-20261029-dissociation-v4';data['attachment_v3_dataset_sha256']=base
    data['common_conditional_mass_basis']=dict(id='source_rounded_common_basis_v1',H2O_to_H_OH_eV=5.1,implied_H_electron_affinity_eV=.75,implied_OH_electron_affinity_eV=1.83,H2O_ionization_eV=12.621,
        interpretation='Internally consistent reduced-model species masses from rounded5.10/4.35/3.27eV references; implied affinities are not precision measurements. Do not mix with an independent species mass table or count chemical reference energy twice.')
    data['sources']['hargreaves2012']=dict(url='https://dydaktyka.fizyka.umk.pl/Karwasz/H2O/H2O/Elect_Hargreaves_12.pdf',doi='10.1088/0953-4075/45/20/201001',
        role='Primary electron-impact A1B1 dissociative excitation, pp1-3: impulsive OH+H products, broad energy-loss profile and forward-peaked singlet DCS. The fixed-loss/dipole/ground endpoint below is conditional, not a transcription of the measured DCS.')
    data['conditional_event_models'].append(dict(id='A1B1_fixed_loss_dipole_ground_v1',channel='H2O:electronic_A1B1',
        data_support_eV=[9.,977.7],products={'e_g':1,'H_1s':1,'OH_X_v0':1},parent_debit=1,electron_net_gain=0,
        fixed_excitation_eV=7.49,chemical_reference_gain_eV=5.1,source=['song2021','hargreaves2012'],
        angular_model='Born/dipole-shaped CM electron density proportional to1/(pi^2+pf^2-2pi*pf*mu); uniform azimuth; host isotropic excited-rest H direction',
        kinematics='exact two-body excitation e+H2O -> e+H2Ostar then prompt two-body H2Ostar -> H+OH, with exact Lorentz boosts; intermediate is not retained or separately heated',
        mass_convention='Mstar=M_H2O+7.49eV/c2; M_OH=M_H2O+5.10eV/c2-M_H; immutable common host state mass basis required',
        assumptions=['unit prompt H+OH(X) branching for the selected repulsive A1B1 molecular state',
            'fixed7.49eV energy-loss line replaces the broad source continuum; no measured differential loss spectrum claimed',
            'Born/dipole-shaped electron angle is approximate, especially near9eV; not the measured full angular table',
            'OH internal energy set tozero; isotropic breakup is a maximum-translation conditional endpoint; rotation/vibration/recoil correlations unresolved'],
        sensitivity=['compare other excitation-line losses/product internal-state choices under a separate version; do not tune against coupled results'],
        overlap_exclusions=['do not also sample the inclusive neutral OH yield or the same A1B1 excitation as another event','aggregate inelastic/stopping observables overlap this channel'],
        exclusions=['not complete neutral dissociation','no extrapolation beyond977.7eV','not a complete8keV water mechanism']))
    out=p.with_name('h2o-gas-20261029-dissociation.json');encoded=(json.dumps(data,indent=2,allow_nan=False)+'\n').encode()
    if out.with_suffix('.lock.json').exists():assert hashlib.sha256(encoded).hexdigest()==json.loads(out.with_suffix('.lock.json').read_text())['dataset_sha256'],'Frozen v4 drift'
    out.write_bytes(encoded);print(json.dumps(dict(path=str(out),sha256=hashlib.sha256(encoded).hexdigest())))
if __name__=='__main__':main()
