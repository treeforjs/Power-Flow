"""Qualify manufactured coupled electron/contact/thermal/photon/RC accounting.

Run serial, or use --distributed with a matching mpi4py/native MPI build.
This checks numerical ownership and conservation, not material calibration.
"""
from __future__ import annotations

import argparse
import copy
import json
import math
from pathlib import Path
import time

import raikou


def values(state):
    output = []
    for key in ("owned_values", "densities_m3", "potential_V", "surface_charge_C_m2",
                "dielectric_potential_V", "temperature_K", "photon_densities_m3"):
        output.extend(state.get(key, []))
    for phase in sorted(state.get("phase_temperatures_K", {})):
        output.extend(state["phase_temperatures_K"][phase])
    if "driven_voltage_V" in state:
        output.append(state["driven_voltage_V"])
    for key in ("spherical_electrons", "electrons"):
        for cell in state.get(key, []):
            output.extend(cell["density_modes"])
    return output


def relative_change(actual, expected):
    if len(actual) != len(expected):
        raise AssertionError("restart changed the local state shape")
    return max((abs(a - b) / max(1.0, abs(a), abs(b)) for a, b in zip(actual, expected)), default=0.0)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--distributed", action="store_true")
    parser.add_argument("--device", choices=("cpu", "cuda"), default="cpu")
    parser.add_argument("--cuda-device", type=int, default=-1)
    parser.add_argument("--threads", type=int, default=1)
    parser.add_argument("--contact-heat-phase", choices=("gas", "aqueous"), default="aqueous")
    args = parser.parse_args()
    if args.threads < 1:
        parser.error("threads must be positive")
    comm = None
    if args.distributed:
        from mpi4py import MPI
        comm = MPI.COMM_WORLD
    fixture = Path(__file__).resolve().parents[1] / "examples/manufactured/coupled_interface_2d.json"
    request = json.loads(fixture.read_text())
    request["electron_phase_contacts"][0]["energy_to_phase"] = args.contact_heat_phase
    request["execution"] = {"device": args.device, "cuda_device": args.cuda_device, "threads": args.threads}
    if comm is not None:
        request["execution"].update(mpi=True, communicator_f=comm.py2f())
    solve = raikou.solve_spatial_distributed if args.distributed else raikou.solve_spatial
    started = time.perf_counter()
    full = solve(request)
    if not full["success"]:
        raise RuntimeError(full["message"])
    split = copy.deepcopy(request)
    split["time"]["end_time_s"] *= 0.5
    prefix = solve(split)
    if not prefix["success"]:
        raise RuntimeError(prefix["message"])
    split["checkpoint"] = prefix["checkpoint"]
    split["time"]["end_time_s"] = request["time"]["end_time_s"]
    resumed = solve(split)
    if not resumed["success"]:
        raise RuntimeError(resumed["message"])
    restart_error = max(relative_change(values(resumed["checkpoint"][key]), values(full["checkpoint"][key]))
                        for key in ("state", "previous_state"))
    counts = full["particle_counts"]
    particle_error = abs(counts["e"] + counts["e_aq"] - 0.1) / 0.1
    first, last = full["history"][0], full["history"][-1]
    ledger = full["chemical_energy_integrals_J"]
    contact = ledger["EEDF/phase_contact_energy"]
    if not contact > 0 or not counts["e_aq"] > 0:
        raise AssertionError("the interface did not transfer electron number and energy")
    heat_change = last["thermal_energy_J"] - first["thermal_energy_J"]
    expected_heat = contact + ledger["EEDF/operator/gas/translation"] + ledger["Radiation/background_absorption/test_photons"]
    heat_error = abs(heat_change - expected_heat) / expected_heat
    total_change = heat_change + last["electron_energy_J"] - first["electron_energy_J"]
    total_change += last["radiation_energy_J"] - first["radiation_energy_J"]
    total_change -= ledger["EEDF/operator/electrons/field"]
    energy_error = abs(total_change) / contact
    charge_error = abs(last["gas_charge_C"] + last["surface_charge_C"]) / (1.602176634e-19 * 0.1)
    errors = [restart_error, particle_error, heat_error, energy_error, charge_error]
    if comm is not None:
        errors = [comm.allreduce(value, op=MPI.MAX) for value in errors]
        if comm.allreduce(full["cell_count"], op=MPI.SUM) != 2:
            raise AssertionError("owned cell intervals do not cover the mesh exactly once")
    if not all(math.isfinite(error) and error < 2e-6 for error in errors):
        raise AssertionError(f"coupled qualification exceeded tolerance: {errors}")
    if not abs(last["driven_voltage_V"]) > 0:
        raise AssertionError("the finite-resistance circuit did not respond")
    elapsed = time.perf_counter() - started
    layout = None
    if comm is not None:
        elapsed = comm.allreduce(elapsed, op=MPI.MAX)
        layout = comm.gather({"rank": comm.rank, "cell_count": full["cell_count"], **full["storage"]}, root=0)
    if comm is None or comm.rank == 0:
        print(json.dumps({"case": "manufactured coupled conservation and restart",
                          "contact_heat_phase": args.contact_heat_phase,
                          "version": raikou.capabilities()["version"], "execution": request["execution"],
                          "relative_errors": dict(zip(("restart", "particle", "heat", "energy", "charge"), errors)),
                          "contact_energy_J": contact, "wall_time_s": elapsed, "layout": layout}, indent=2))


if __name__ == "__main__":
    main()
