"""Ordinary Python scripting for Raikou's native runtime (pip install . first)."""

import json

import raikou


def main():
    print(json.dumps(raikou.capabilities(), indent=2))
    result = raikou.linear_solve(
        matrix={"rows": 2, "offsets": [0, 2, 4], "columns": [0, 1, 0, 1], "values": [4.0, 1.0, 1.0, 3.0]},
        rhs=[1.0, 2.0],
        execution={"device": "cpu", "threads": 1, "tolerance": 1e-12},
    )
    if not result["converged"]:
        raise RuntimeError(f"Linear solve failed: {result}")
    print("Solution:", result["solution"])
    print("Water rotational states:", len(raikou.water_levels(j_max=2)["levels"]))


if __name__ == "__main__":
    main()
