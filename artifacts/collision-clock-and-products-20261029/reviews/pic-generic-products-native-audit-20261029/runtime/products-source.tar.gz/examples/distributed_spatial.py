"""Advance owned 2D/3D cell fields and restart without gathering the solution.

    mpiexec -n 4 python examples/distributed_spatial.py --shape 16 8 1
    mpiexec -n 2 python examples/distributed_spatial.py --kinetic --device cuda

Requires matching MPI-enabled Raikou and mpi4py builds. All supplied collision
and reaction coefficients are manufactured numerical controls, not gas data.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
import time

from mpi4py import MPI
import raikou


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--kinetic", action="store_true", help="use full angular 3D electron kinetics")
    parser.add_argument("--shape", type=int, nargs=3, metavar=("NX", "NY", "NZ"))
    parser.add_argument("--device", choices=["cpu", "cuda"], default="cpu")
    parser.add_argument("--cuda-device", type=int, default=-1)
    parser.add_argument("--threads", type=int, default=1)
    parser.add_argument("--perturbation", type=float, default=0.1,
                        help="relative charged-density cosine amplitude in [0,1)")
    args = parser.parse_args()
    if args.threads < 1 or (args.shape and min(args.shape) < 1):
        parser.error("thread and mesh dimensions must be positive")
    if not 0 <= args.perturbation < 1:
        parser.error("perturbation must be in [0,1)")
    comm = MPI.COMM_WORLD
    fixture = "spherical_kinetics_3d.json" if args.kinetic else "spatial_2d.json"
    request = json.loads((Path(__file__).parent / "manufactured" / fixture).read_text())
    if args.shape:
        if not args.kinetic and args.shape[2] != 1:
            parser.error("the 2D fluid example requires NZ=1; use --kinetic for 3D")
        request["mesh"]["shape"] = args.shape
    count = 1
    for extent in request["mesh"]["shape"]:
        count *= extent
    begin = count * comm.rank // comm.size
    end = count * (comm.rank + 1) // comm.size
    # Explicit intervals and arrays are useful for Quark mesh/field adapters.
    # Shared constants could instead initialize these same owned cells.
    charges = {species["id"]: species.get("charge", 0) for species in request["mechanism"]["species"]}
    nx = request["mesh"]["shape"][0]
    request["local_initial"] = {
        "cell_begin": begin, "cell_count": end - begin,
        "densities_m3": {species: [value * (1 + args.perturbation * math.cos(2 * math.pi * ((cell % nx) + 0.5) / nx))
                                             if charges[species] else value for cell in range(begin, end)]
                         for species, value in request["initial_densities_m3"].items()},
    }
    request["execution"] = {"mpi": True, "communicator_f": comm.py2f(),
                            "device": args.device, "cuda_device": args.cuda_device,
                            "threads": args.threads}
    final_time = request["time"]["end_time_s"]
    request["time"]["end_time_s"] = 0.5 * final_time
    started = time.perf_counter()
    result = raikou.solve_spatial_distributed(request)
    if not result["success"]:
        raise RuntimeError(result["message"])
    request.pop("local_initial")
    request["checkpoint"] = result["checkpoint"]
    request["time"]["end_time_s"] = final_time
    result = raikou.solve_spatial_distributed(request)
    if not result["success"]:
        raise RuntimeError(result["message"])
    elapsed = comm.allreduce(time.perf_counter() - started, op=MPI.MAX)
    if result["cell_count"] != end - begin:
        raise RuntimeError("solver returned cells outside the rank's interval")
    # Gather only small ownership/performance records, never prognostic fields.
    layout = comm.gather({"rank": comm.rank, "cell_begin": begin,
                          "cell_count": end - begin, **result["storage"]}, root=0)
    if comm.rank == 0:
        print(json.dumps({"case": "manufactured numerical control",
                          "time_s": result["time_s"], "global_cells": count,
                          "particle_counts": result["particle_counts"],
                          "last_sample": result["history"][-1],
                          "layout": layout, "wall_time_s": elapsed}, indent=2))


if __name__ == "__main__":
    main()
