"""MPI-owned CR API example with a manufactured conserved isomer ring.

Run with an MPI-enabled Raikou build and mpi4py using the same MPI runtime:
    mpiexec -n 4 python examples/distributed_chemistry.py
This tests distribution/conservation, not a physical plasma mechanism.
"""
import argparse
import json
import time

from mpi4py import MPI
import raikou


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--species", type=int, default=64)
    parser.add_argument("--device", choices=["cpu", "cuda"], default="cpu")
    parser.add_argument("--cuda-device", type=int, default=-1)
    args = parser.parse_args()
    if args.species < 2:
        parser.error("at least two species are required")
    communicator = MPI.COMM_WORLD
    rank, ranks = communicator.rank, communicator.size
    quotient, remainder = divmod(args.species, ranks)
    count = quotient + int(rank < remainder)
    begin = rank * quotient + min(rank, remainder)
    names = [f"X{i}" for i in range(args.species)]
    mechanism = {
        "id": "manufactured_distributed_isomer_ring", "status": "manufactured",
        "species": [{"id": name, "elements": {"N": 1}} for name in names],
        "reactions": [{"id": f"R{i}", "reactants": {name: 1},
                       "products": {names[(i + 1) % len(names)]: 1},
                       "rate": {"type": "constant", "A": 2.0},
                       "source": "manufactured conservation example"}
                      for i, name in enumerate(names)],
    }
    local = [float(begin + i == 0) for i in range(count)]
    started = time.perf_counter()
    result = raikou.advance_chemistry_distributed(
        mechanism=mechanism, state={"row_begin": begin, "densities_m3": local}, dt_s=0.01,
        options={"relative_tolerance": 1e-6, "absolute_tolerance_m3": 1e-12},
        execution={"mpi": True, "communicator_f": communicator.py2f(), "device": args.device,
                   "cuda_device": args.cuda_device, "threads": 1},
    )
    if not communicator.allreduce(result["success"], op=MPI.LAND):
        raise RuntimeError(result["message"])
    elapsed = communicator.allreduce(time.perf_counter() - started, op=MPI.MAX)
    inventory = communicator.allreduce(sum(result["state"]["densities_m3"]), op=MPI.SUM)
    if abs(inventory - 1) > 1e-10:
        raise RuntimeError(f"inventory is not conserved: {inventory}")
    # Gather only tiny ownership diagnostics, never the numerical solution.
    layout = communicator.gather({"rank": rank, "row_begin": begin, "owned_species": count,
                                  "ghost_species": result["ghost_species"]}, root=0)
    if rank == 0:
        print(json.dumps({"success": True, "inventory": inventory, "layout": layout,
                          "advanced_time_s": result["advanced_time_s"], "wall_time_s": elapsed,
                          "accepted_steps": result["accepted_steps"], "rejected_steps": result["rejected_steps"]}, indent=2))


if __name__ == "__main__":
    main()
