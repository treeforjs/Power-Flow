"""One energy-grid EEDF distributed across MPI ranks.

Run with a matching MPI-enabled Raikou and mpi4py installation:
    mpiexec -n 4 python examples/distributed_eedf.py
Cross sections below are manufactured numerical inputs, not plasma data.
"""
import argparse
import json
import time

from mpi4py import MPI
import raikou


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--cells", type=int, default=256)
    parser.add_argument("--device", choices=["cpu", "cuda"], default="cpu")
    parser.add_argument("--cuda-device", type=int, default=-1)
    args = parser.parse_args()
    comm = MPI.COMM_WORLD
    request = {
        "processes": [{"kind": "elastic", "target": "X", "mass_ratio": 2e-5,
                       "energy_ev": [0, 1000], "cross_section_m2": [1e-19, 1e-19]}],
        "conditions": {"fractions": {"X": 1}, "reduced_field_td": 10,
                       "gas_density_m3": 1e20, "ion_fraction": 0},
        "grid": {"cells": args.cells, "max_energy_ev": 60, "legendre_terms": 4},
        "initial": {"electron_density_m3": 1e8, "mean_energy_ev": 1}, "dt_s": 1e-11,
        "execution": {"mpi": True, "communicator_f": comm.py2f(), "device": args.device,
                      "cuda_device": args.cuda_device, "tolerance": 1e-10},
    }
    started = time.perf_counter()
    result = raikou.advance_eedf_distributed(request)
    state = result["state"]
    if len(state["density_modes"]) > 4 * ((args.cells + comm.size - 1) // comm.size):
        raise RuntimeError("returned state exceeds local energy partition")
    # Restart uses only this rank's returned state, with no gathered solution.
    request.pop("initial")
    request["state"] = state
    result = raikou.advance_eedf_distributed(request)
    elapsed = comm.allreduce(time.perf_counter() - started, op=MPI.MAX)
    layout = comm.gather({"rank": comm.rank, "row_begin": state["row_begin"],
                         "owned_modes": len(state["density_modes"]),
                         "ghost_modes": result["ghost_modes"],
                         "local_matrix_entries": result["local_matrix_entries"]}, root=0)
    if comm.rank == 0:
        print(json.dumps({"time_s": result["state"]["time_s"], "layout": layout,
                          "mean_energy_ev": result["swarm"]["mean_energy_ev"],
                          "linear_backward_error": result["linear_backward_error"],
                          "energy_balance_relative": result["energy_balance_relative"],
                          "wall_time_s": elapsed}, indent=2))


if __name__ == "__main__":
    main()
