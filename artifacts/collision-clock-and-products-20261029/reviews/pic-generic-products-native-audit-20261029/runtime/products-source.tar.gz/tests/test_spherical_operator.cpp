#include "raikou/spherical_operator.h"
#include <algorithm>
#include <cmath>
#include <iostream>
#include <numbers>
#include <stdexcept>
namespace {
void coulomb_angular_eigenvalues(){
    using namespace raikou::kinetics;
    const EedfGrid grid{.cells=16,.max_energy_ev=16,.power=1,.legendre_terms=5};
    CollisionProcess elastic;elastic.kind=CollisionKind::Elastic;elastic.target="X";elastic.label="elastic";
    elastic.energy_ev={0,1000};elastic.cross_section_m2={0,0};
    auto state=spherical_from_legendre(maxwellian_eedf(1e8,1,grid));
    constexpr std::size_t stride=25;
    for(std::size_t i=0;i<16;++i)for(int l=1;l<5;++l)for(int m=-l;m<=l;++m)
        if(l%2==0||i+1<16)state.density_modes[i*stride+spherical_index(l,m)]=.01*state.density_modes[i*stride];
    EedfConditions conditions;conditions.gas_density_m3=1e20;conditions.fractions["X"]=1;conditions.ion_fraction=1e-4;
    const auto rhs=evaluate_spherical_eedf({elastic},conditions,state,{});
    const auto matrix=freeze_spherical_eedf_operator({elastic},conditions,state,{});
    const auto assembled=raikou::backend::csr_multiply(matrix,state.density_modes);
    const double charge=1.602176634e-19,mass=9.1093837015e-31,eps0=8.8541878128e-12;
    const double density=state.electron_density_m3(),debye=std::sqrt(eps0/(density*charge));
    const double logarithm=std::max(1.,std::log(12*std::numbers::pi*density*debye*debye*debye));
    const auto frequency=[&](std::size_t i,int l){
        const double lo=static_cast<double>(i)+(l%2?.5:0),hi=lo+1,mid=(lo+hi)/2;
        const double cell_mass=2./3*(std::pow(hi,1.5)-std::pow(lo,1.5));
        const double impact=charge/(8*std::numbers::pi*eps0*mid);
        return std::sqrt(2*charge/mass)*conditions.gas_density_m3*conditions.ion_fraction*
            4*std::numbers::pi*impact*impact*logarithm*(.5*l*(l+1))*mid/cell_mass;
    };
    const auto step=advance_spherical_eedf({elastic},conditions,state,{},1e-8);
    for(std::size_t i=0;i<16;++i)for(int l=1;l<5;++l)for(int m=-l;m<=l;++m){
        if(l%2!=0&&i+1==16)continue;
        const auto index=i*stride+spherical_index(l,m);const double nu=frequency(i,l);
        const double expected=-nu*state.density_modes[index];
        if(std::abs(rhs.density_mode_rates[index]-expected)>1e-11*std::abs(expected)||
            std::abs(assembled[index]-expected)>1e-11*std::abs(expected))
            throw std::runtime_error("Coulomb RHS and frozen operator must use each Lorentz angular eigenvalue");
        const double implicit=state.density_modes[index]/(1+1e-8*nu);
        if(std::abs(step.state.density_modes[index]-implicit)>1e-9*std::abs(implicit))
            throw std::runtime_error("Coulomb angular relaxation must match independent backward-Euler amplification");
    }
}
}
int main(){
    using namespace raikou::kinetics;
    try{
        coulomb_angular_eigenvalues();
        const EedfGrid grid{.cells=32,.max_energy_ev=20,.power=2,.legendre_terms=4};
        CollisionProcess elastic;elastic.kind=CollisionKind::Elastic;elastic.target="X";elastic.label="elastic";
        elastic.mass_ratio=9.1093837015e-31/(28*1.66053906660e-27);elastic.energy_ev={0,1000};elastic.cross_section_m2={1e-19,1e-19};
        EedfConditions conditions;conditions.gas_density_m3=1e20;conditions.fractions["X"]=1;conditions.ion_fraction=0;
        auto state=spherical_from_legendre(maxwellian_eedf(1e8,1,grid));
        for(std::size_t i=0;i<32;++i)for(int l=1;l<4;++l)for(int m=-l;m<=l;++m)if(l%2==0||i+1<32)
            state.density_modes[i*16+spherical_index(l,m)]=0.01*state.density_modes[i*16]*std::cos(static_cast<double>((i+1)*(l+m+1)));
        for(bool coulomb:{false,true}){
            if(coulomb){for(double& value:state.density_modes)value*=1e10;conditions.ion_fraction=state.electron_density_m3()/conditions.gas_density_m3;}
            const Vector3 field{2,-3,7};
            const auto exact=evaluate_spherical_eedf({elastic},conditions,state,field);
            const auto matrix=freeze_spherical_eedf_operator({elastic},conditions,state,field);
            const auto product=raikou::backend::csr_multiply(matrix,state.density_modes);
            double error=0,scale=0;std::size_t worst=0;
            for(std::size_t i=0;i<product.size();++i){if(std::abs(product[i]-exact.density_mode_rates[i])>error){error=std::abs(product[i]-exact.density_mode_rates[i]);worst=i;}scale=std::max(scale,std::abs(exact.density_mode_rates[i]));}
            if(error>2e-9*scale){std::cerr<<"coulomb="<<coulomb<<" row="<<worst<<" exact="<<exact.density_mode_rates[worst]<<" assembled="<<product[worst]<<" rel="<<error/scale<<'\n';throw std::runtime_error("frozen full angular operator/RHS mismatch");}
        }
        std::cout<<"frozen full angular operator qualification passed\n";return 0;
    }catch(const std::exception& error){std::cerr<<error.what()<<'\n';return 1;}
}
