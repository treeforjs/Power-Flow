#include "raikou/spatial.h"
#include "raikou/backend.h"
#include "raikou/spatial_mesh.h"
#include "raikou/spatial_boundary.h"
#include "raikou/spatial_interface.h"
#include <algorithm>
#include <cmath>
#include <iostream>
#include <numbers>
#include <stdexcept>
#include <string>

namespace {
using namespace raikou;
constexpr double eps0 = 8.8541878128e-12, qe = 1.602176634e-19;
std::string execution_device = "cpu";
bool execution_mpi = false;
void check(bool x, const std::string& message) { if (!x) throw std::runtime_error(message); }
void close(double x, double y, double tolerance, const std::string& message) {
    check(std::isfinite(x) && std::abs(x - y) <= tolerance, message + ": " + std::to_string(x) + " versus " + std::to_string(y));
}
spatial::Problem base(std::size_t nx, std::size_t ny = 1, std::size_t nz = 1) {
    spatial::Problem p;
    p.mesh.shape = {nx, ny, nz}; p.mesh.dimension = nz > 1 ? 3 : 2; p.mesh.extent_m = {1e-3, 2e-3, 1e-3};
    chemistry::Species neutral; neutral.id = "H"; neutral.elements = {{"H", 1}}; neutral.mass_kg = 1.6735575e-27;
    p.mechanism.id = "manufactured neutral"; p.mechanism.species.push_back(neutral);
    p.transport.resize(1); p.initial_densities_m3.assign(nx * ny * nz, 0);
    p.boundaries[0].kind = spatial::BoundaryKind::Electrode;
    p.boundaries[1].kind = spatial::BoundaryKind::Electrode;
    p.options.end_time_s = 0; p.options.threads = 2;
    p.options.device = execution_device; p.options.mpi = execution_mpi;
    p.options.adaptive_time = false; // These controls compare the stated discrete timestep.
    return p;
}
void test_flux() {
    close(spatial::bernoulli(0), 1, 1e-15, "Bernoulli origin");
    for (double x : {-100., -1., -1e-7, 1e-7, 1., 100.}) close(spatial::bernoulli(-x) - spatial::bernoulli(x), x, 1e-12 * (1 + std::abs(x)), "Bernoulli drift identity");
    spatial::Transport t{0.2, 0.01};
    const double j = spatial::scharfetter_gummel_flux(1e10, 3e10, 0.2, 0.5, .01, -1, t);
    const double reverse = spatial::scharfetter_gummel_flux(3e10, 1e10, .5, .2, .01, -1, t);
    close(j + reverse, 0, 1e-5, "face antisymmetry");
    const double ratio = std::exp((-1.0) * t.mobility_m2_V_s * (.2 - .5) / t.diffusion_m2_s);
    close(spatial::scharfetter_gummel_flux(1, ratio, .2, .5, 1, -1, t), 0, 1e-14, "discrete Boltzmann equilibrium");
    close(spatial::scharfetter_gummel_flux(2, 3, 1, 0, 1, 1, {2, 0}), 4, 1e-14, "zero diffusion upwinding");
}
void test_poisson() {
    for (const auto shape : {std::array<std::size_t, 3>{4, 3, 1}, std::array<std::size_t, 3>{3, 2, 2}}) {
        auto p = base(shape[0], shape[1], shape[2]); p.boundaries[1].potential_V = 7;
        const auto phi = spatial::solve_poisson(p, std::vector<double>(p.initial_densities_m3.size(), 0));
        for (std::size_t c = 0; c < phi.size(); ++c) close(phi[c], 7 * (static_cast<double>(c % shape[0]) + .5) / static_cast<double>(shape[0]), 1e-9, "linear 2D/3D potential");
    }
    double previous = 0;
    for (std::size_t nx : {4u, 8u, 16u}) {
        auto p = base(nx, 2);
        const double rho = 1e-6;
        const auto phi = spatial::solve_poisson(p, std::vector<double>(nx * 2, rho));
        double error = 0;
        for (std::size_t c = 0; c < phi.size(); ++c) { const double x = (static_cast<double>(c % nx) + .5) * .001 / static_cast<double>(nx); error = std::max(error, std::abs(phi[c] - rho / (2 * eps0) * x * (.001 - x))); }
        if (previous > 0) close(previous / error, 4, 1e-6, "second-order manufactured Poisson refinement");
        previous = error;
    }
    auto p = base(4, 3); p.mesh.axisymmetric = true;
    p.boundaries[0].kind = spatial::BoundaryKind::Insulating; p.boundaries[1].kind = spatial::BoundaryKind::Insulating;
    p.boundaries[2].kind = spatial::BoundaryKind::Electrode; p.boundaries[3].kind = spatial::BoundaryKind::Electrode; p.boundaries[3].potential_V = 5;
    const auto phi = spatial::solve_poisson(p, std::vector<double>(12, 0));
    for (std::size_t c = 0; c < phi.size(); ++c) close(phi[c], 5 * (static_cast<double>(c / 4) + .5) / 3, 1e-9, "axisymmetric axial potential");
    const auto volume = spatial::cell_volumes(p.mesh);
    double total = 0; for (double v : volume) total += v;
    close(total, std::numbers::pi * 1e-6 * .002, 1e-22, "axisymmetric physical volume");
}
void test_diffusion_conservation() {
    auto p = base(4, 3); p.options.end_time_s = .01; p.options.time_step_s = .001;
    p.transport[0].diffusion_m2_s = 1e-6;
    p.initial_densities_m3[5] = 1e12;
    const auto r = spatial::solve(p);
    check(r.success && r.accepted_steps >= 10, "diffusion run converges");
    const auto volume = spatial::cell_volumes(p.mesh);
    close(r.particle_counts[0], 1e12 * volume[5], 1e-5, "reflecting finite-volume particle conservation");
    check(r.state.densities_m3[5] < 1e12 && r.state.densities_m3[0] > 0, "diffusion evolves rather than returning seed");
    for (const auto& s : r.samples) check(s.nonlinear_residual <= 1, "reported Newton residual meets tolerance");
}
void test_supplied_meshes() {
    for (const std::string type : {"tri3", "quad4", "tet4", "hex8"}) {
        auto p = base(1); p.mesh.dimension = type == "tet4" || type == "hex8" ? 3 : 2;
        p.mesh.extent_m[2] = .002;
        if (type == "tri3") { p.mesh.nodes_m = {{{0, 0, 0}}, {{.001, 0, 0}}, {{.0005, std::sqrt(3.) * .0005, 0}}}; p.mesh.cells = {{type, {0, 1, 2}}}; p.mesh.boundary_faces = {{{0, 1}, 0}, {{1, 2}, 1}, {{2, 0}, 2}}; }
        if (type == "quad4") { p.mesh.nodes_m = {{{0, 0, 0}}, {{.001, 0, 0}}, {{.001, .001, 0}}, {{0, .001, 0}}}; p.mesh.cells = {{type, {0, 1, 2, 3}}}; p.mesh.boundary_faces = {{{0, 1}, 0}, {{1, 2}, 1}, {{2, 3}, 2}, {{3, 0}, 3}}; }
        if (type == "tet4") { p.mesh.nodes_m = {{{0, 0, 0}}, {{.001, 0, 0}}, {{.0005, std::sqrt(3.) * .0005, 0}}, {{.0005, std::sqrt(3.) / 6 * .001, std::sqrt(2. / 3) * .001}}}; p.mesh.cells = {{type, {0, 1, 2, 3}}}; p.mesh.boundary_faces = {{{0, 1, 2}, 0}, {{0, 1, 3}, 1}, {{0, 2, 3}, 2}, {{1, 2, 3}, 3}}; }
        if (type == "hex8") { p.mesh.nodes_m = {{{0, 0, 0}}, {{.001, 0, 0}}, {{.001, .001, 0}}, {{0, .001, 0}}, {{0, 0, .001}}, {{.001, 0, .001}}, {{.001, .001, .001}}, {{0, .001, .001}}}; p.mesh.cells = {{type, {0, 1, 2, 3, 4, 5, 6, 7}}}; p.mesh.boundary_faces = {{{0, 1, 2, 3}, 0}, {{4, 5, 6, 7}, 1}, {{0, 1, 5, 4}, 2}, {{1, 2, 6, 5}, 3}, {{2, 3, 7, 6}, 4}, {{3, 0, 4, 7}, 5}}; }
        for (auto& b : p.boundaries) { b.kind = spatial::BoundaryKind::Electrode; b.potential_V = 4; }
        const auto v = spatial::cell_volumes(p.mesh); check(v.size() == 1 && v[0] > 0, "supplied positive cell volume: " + type);
        const auto phi = spatial::solve_poisson(p, {0}); close(phi[0], 4, 1e-10, "constant supplied-cell Poisson: " + type);
    }
    auto pair = base(2); const double h = std::sqrt(3.) * .0005;
    pair.mesh.nodes_m = {{{0, 0, 0}}, {{.001, 0, 0}}, {{.0005, h, 0}}, {{.0005, -h, 0}}};
    pair.mesh.cells = {{"tri3", {0, 1, 2}}, {"tri3", {1, 0, 3}}};
    pair.mesh.boundary_faces = {{{1, 2}, 0}, {{2, 0}, 0}, {{0, 3}, 1}, {{3, 1}, 1}};
    pair.transport[0].diffusion_m2_s = 1e-4; pair.initial_densities_m3 = {1e10, 0};
    pair.options.end_time_s = 1e-4; pair.options.time_step_s = 1e-5;
    const auto result = spatial::solve(pair); check(result.success, "supplied two-triangle diffusion solve");
    check(result.state.densities_m3[0] < 1e10 && result.state.densities_m3[1] > 0, "shared supplied-face transport evolves");
    const auto v = spatial::cell_volumes(pair.mesh); close(result.particle_counts[0], 1e10 * v[0], 1e-6, "supplied-face conservation");
    auto skew = base(1); skew.mesh.nodes_m = {{{0, 0, 0}}, {{2, 0, 0}}, {{1.5, 1, 0}}, {{0, 1, 0}}}; skew.mesh.cells = {{"quad4", {0, 1, 2, 3}}}; skew.mesh.boundary_faces = {{{0, 1}, 0}, {{1, 2}, 1}, {{2, 3}, 2}, {{3, 0}, 3}};
    for (auto& boundary : skew.boundaries) boundary.kind = spatial::BoundaryKind::Electrode;
    skew.boundaries[0].potential_V = 1; skew.boundaries[1].potential_V = 1.75; skew.boundaries[2].potential_V = .75; skew.boundaries[3].potential_V = 0;
    close(spatial::solve_poisson(skew, {0})[0], 37. / 42, 1e-10, "skew quad affine potential at true volume centroid");
    skew.mesh.nodes_m = {{{0, 0, 0}}, {{2, 0, 0}}, {{.2, .1, 0}}}; skew.mesh.cells = {{"tri3", {0, 1, 2}}}; skew.mesh.boundary_faces = {{{0, 1}, 0}, {{1, 2}, 1}, {{2, 0}, 2}};
    skew.boundaries[0].potential_V = 0; skew.boundaries[1].potential_V = .05; skew.boundaries[2].potential_V = .05;
    close(spatial::solve_poisson(skew, {0})[0], .1 / 3, 1e-10, "obtuse triangle uses positive centroid geometry with affine flux correction");
}
spatial::Mesh skew_grid(const std::string& type, std::size_t n) {
    spatial::Mesh mesh; const bool solid = type == "tet4" || type == "hex8"; mesh.dimension = solid ? 3 : 2; mesh.extent_m[2] = .001;
    const auto stride = n + 1;
    for (std::size_t k = 0; k <= (solid ? n : 0); ++k) for (std::size_t j = 0; j <= n; ++j) for (std::size_t i = 0; i <= n; ++i) { const double x = static_cast<double>(i) / static_cast<double>(n), y = static_cast<double>(j) / static_cast<double>(n), z = static_cast<double>(k) / static_cast<double>(n); mesh.nodes_m.push_back({.001 * (x + .6 * y + .3 * z), .001 * (y + .2 * z), .001 * z}); }
    for (std::size_t k = 0; k < (solid ? n : 1); ++k) for (std::size_t j = 0; j < n; ++j) for (std::size_t i = 0; i < n; ++i) {
        const auto a = i + stride * (j + stride * k), b = a + 1, d = a + stride, c = d + 1;
        if (!solid) { if (type == "tri3") { mesh.cells.push_back({type, {a, b, c}}); mesh.cells.push_back({type, {a, c, d}}); } else mesh.cells.push_back({type, {a, b, c, d}}); }
        else { const auto e = a + stride * stride, f = e + 1, h = e + stride, g = h + 1; if (type == "hex8") mesh.cells.push_back({type, {a, b, c, d, e, f, g, h}}); else { mesh.cells.push_back({type, {a, b, c, g}}); mesh.cells.push_back({type, {a, c, d, g}}); mesh.cells.push_back({type, {a, d, h, g}}); mesh.cells.push_back({type, {a, h, e, g}}); mesh.cells.push_back({type, {a, e, f, g}}); mesh.cells.push_back({type, {a, f, b, g}}); } }
    }
    std::map<std::vector<std::size_t>, int> counts;
    for (const auto& cell : mesh.cells) {
        const auto& v = cell.nodes; std::vector<std::vector<std::size_t>> faces;
        if (!solid) for (std::size_t k = 0; k < v.size(); ++k) faces.push_back({v[k], v[(k + 1) % v.size()]});
        else if (type == "tet4") faces = {{v[0], v[1], v[2]}, {v[0], v[1], v[3]}, {v[0], v[2], v[3]}, {v[1], v[2], v[3]}};
        else faces = {{v[0], v[1], v[2], v[3]}, {v[4], v[5], v[6], v[7]}, {v[0], v[1], v[5], v[4]}, {v[1], v[2], v[6], v[5]}, {v[2], v[3], v[7], v[6]}, {v[3], v[0], v[4], v[7]}};
        for (auto face : faces) { std::sort(face.begin(), face.end()); ++counts[face]; }
    }
    for (const auto& [face, count] : counts) if (count == 1) mesh.boundary_faces.push_back({face, 0});
    return mesh;
}
void test_skew_transport() {
    for (const std::string type : {"tri3", "quad4", "tet4", "hex8"}) {
        auto p = base(1); p.mesh = skew_grid(type, 2); const auto nc = p.mesh.cells.size();
        p.initial_densities_m3.assign(nc, 0); p.initial_densities_m3[nc / 2] = 1e12; p.transport[0].diffusion_m2_s = 1e-5;
        p.options.time_step_s = 1e-6; p.options.end_time_s = 5e-6;
        p.options.maximum_steps = 1000; p.options.minimum_time_step_s = 1e-10;
        p.thermal.enabled = true; p.thermal.heat_capacity_J_m3_K = {1}; p.thermal.conductivity_W_m_K = {.001}; p.thermal.initial_temperature_K.assign(nc, 300); p.thermal.initial_temperature_K[nc / 2] = 400;
        spatial::RadiationGroup group; group.id = "diffusion"; group.photon_energy_eV = 2; group.diffusion_m2_s = 1e-5; group.initial_density_m3 = p.initial_densities_m3; p.radiation = {group};
        const auto volume = spatial::cell_volumes(p.mesh); const auto result = spatial::solve(p); check(result.success, "skew coupled conservative transport converges: " + type + " " + result.message);
        close(result.particle_counts[0] / (1e12 * volume[nc / 2]), 1, 1e-8, "skew species inventory conserves: " + type);
        close(result.samples.back().radiation_energy_J / result.samples.front().radiation_energy_J, 1, 1e-8, "skew photon inventory conserves: " + type);
        close(result.samples.back().thermal_energy_J / result.samples.front().thermal_energy_J, 1, 1e-9, "skew Fourier energy conserves: " + type);
        check(result.state.densities_m3[nc / 2] < 1e12 && result.state.temperature_K[nc / 2] < 400, "skew fluxes evolve state: " + type);
        for (double density : result.state.densities_m3) check(density >= 0, "skew bounded diffusion remains nonnegative: " + type);
        for (double photons : result.state.photon_densities_m3) check(photons >= 0, "skew photon diffusion remains nonnegative: " + type);
        p.radiation[0].escaping_sides[0] = true;
        const auto escaping = spatial::solve(p); check(escaping.success, "passive skew photon escape converges: " + type + " " + escaping.message);
        for (std::size_t k = 1; k < escaping.samples.size(); ++k) check(escaping.samples[k].radiation_energy_J <= escaping.samples[k - 1].radiation_energy_J * (1 + 1e-9), "passive skew photon walls cannot create radiation: " + type);
        close((escaping.samples.back().radiation_energy_J + escaping.chemical_energy_integrals_J.at("Radiation/escaped/diffusion")) / escaping.samples.front().radiation_energy_J, 1, 1e-8, "skew photon escape ledger closes the actual lost energy: " + type);
    }
}
spatial::Problem plasma() {
    auto p = base(3, 2);
    chemistry::Species e; e.id = "e"; e.charge = -1; e.mass_kg = 9.1093837015e-31;
    auto ion = p.mechanism.species[0]; ion.id = "H+"; ion.charge = 1;
    p.mechanism.species.push_back(e); p.mechanism.species.push_back(ion);
    chemistry::Reaction reaction; reaction.id = "manufactured ionization";
    reaction.reactants = {{0, 1}, {1, 1}}; reaction.products = {{1, 2}, {2, 1}};
    reaction.rate.A = 1e-13; reaction.source = "manufactured numerical test, no material calibration";
    p.mechanism.reactions.push_back(reaction);
    p.transport = {{0, 0}, {0.05, .001}, {.001, .0001}};
    p.initial_densities_m3.clear();
    for (std::size_t c = 0; c < 6; ++c) p.initial_densities_m3.insert(p.initial_densities_m3.end(), {1e20, 1e8, 1e8});
    p.boundaries[1].potential_V = 10;
    p.options.time_step_s = 1e-10; p.options.minimum_time_step_s = 1e-15; p.options.end_time_s = 1e-9;
    return p;
}
void test_reactive_breakdown() {
    auto p = plasma();
    const auto r = spatial::solve(p);
    check(r.success, "coupled ionization/SG/Poisson Newton converges: " + r.message);
    const double volume = 1e-3 * 2e-3 * 1e-3;
    check(r.particle_counts[1] > 1.005e8 * volume, "configured avalanche chemistry increases electron population");
    close(r.particle_counts[1], r.particle_counts[2], 1e-6, "ionization conserves net charge globally");
    close(r.particle_counts[0] + r.particle_counts[2], (1e20 + 1e8) * volume, 1e-2, "ionization conserves hydrogen nuclei");
    p.options.maximum_newton_iterations = 1; p.options.minimum_time_step_s = p.options.time_step_s;
    const auto failed = spatial::solve(p);
    check(!failed.success && failed.accepted_steps == 0 && failed.state.time_s == 0, "unconverged step fails and rolls back time");
    check(failed.state.densities_m3 == p.initial_densities_m3, "failed Newton step leaves original concentrations intact");
}
void test_surface_and_circuit() {
    auto p = plasma(); p.mechanism.reactions.clear(); p.boundaries[1].kind = spatial::BoundaryKind::Dielectric;
    p.boundaries[1].potential_V = 0; p.boundaries[1].capacitance_F_m2 = 1e-5; p.boundaries[1].absorbing = true;
    p.transport[1] = {0, .001}; p.transport[2] = {0, 0};
    p.options.time_step_s = 1e-8; p.options.end_time_s = 1e-7;
    const auto r = spatial::solve(p);
    check(r.success, "surface deposition Newton converges: " + r.message);
    check(r.samples.back().surface_charge_C < 0, "absorbed electrons charge dielectric negatively");
    close(r.samples.back().surface_charge_C + r.samples.back().gas_charge_C, 0, 1e-22, "surface and gas charge telescope");
    const double initial_electrons = 1e8 * 1e-3 * 2e-3 * 1e-3;
    close(r.particle_counts[1] + r.particles_collected_at_boundaries[1], initial_electrons, 1e-10, "dielectric collections retain a particle inventory ledger");
    auto capacitor = base(3, 2); capacitor.circuit.enabled = true; capacitor.circuit.source_voltage_V = 100;
    capacitor.circuit.initial_voltage_V = 0; capacitor.circuit.series_resistance_ohm = 1e9; capacitor.circuit.external_capacitance_F = 1e-12;
    capacitor.options.time_step_s = 1e-5; capacitor.options.end_time_s = 1e-5;
    const auto c = spatial::solve(capacitor);
    check(c.success, "implicit field/circuit solve converges: " + c.message);
    const double gapC = eps0 * (2e-3 * 1e-3) / 1e-3;
    const double expected = 100 * 1e-5 / (1e9 * (1e-12 + gapC) + 1e-5);
    close(c.state.driven_voltage_V, expected, 1e-8, "circuit includes Poisson terminal displacement capacitance exactly once");
    close(c.samples.back().field_energy_J, .5 * gapC * expected * expected, 1e-21, "field energy from conservative potential differences");
}
void test_boltzmann_feedback() {
    auto p = plasma(); p.mesh.shape = {1, 1, 1}; p.initial_densities_m3 = {1e22, 1e10, 1e10};
    p.boundaries[1].potential_V = 1; p.options.end_time_s = 1e-10; p.options.time_step_s = 1e-10;
    auto& reaction = p.mechanism.reactions[0]; reaction.rate.kind = chemistry::RateKind::ElectronEedf; reaction.rate.key = "manufactured-ionization"; reaction.collision_label = reaction.rate.key;
    kinetics::ElectronCoupling coupling; coupling.electron_species = "e"; coupling.strict_event_mapping = true;
    coupling.grid.cells = 32; coupling.grid.max_energy_ev = 5; coupling.grid.legendre_terms = 2;
    kinetics::CollisionProcess elastic; elastic.kind = kinetics::CollisionKind::Elastic; elastic.target = "H"; elastic.label = "elastic";
    elastic.mass_ratio = 9.1093837015e-31 / 1.6735575e-27; elastic.energy_ev = {.00001, 100}; elastic.cross_section_m2 = {1e-19, 1e-19};
    kinetics::CollisionProcess ionization; ionization.kind = kinetics::CollisionKind::Ionization; ionization.target = "H"; ionization.label = reaction.rate.key;
    ionization.threshold_ev = .01; ionization.energy_ev = {.01, .02, 100}; ionization.cross_section_m2 = {0, 1e-21, 1e-21};
    coupling.processes = {elastic, ionization}; p.electron_closure = coupling;
    const auto r = spatial::solve(p);
    check(r.success, "field/species/Boltzmann feedback residual converges: " + r.message);
    check(r.state.densities_m3[1] > 1e10, "mapped EEDF ionization changes chemistry");
    check(r.chemical_energy_integrals_J.contains("EEDF/operator/gas/ionization"), "EEDF operator moments exposed without duplicate chemistry heating");
    close(r.state.densities_m3[1], r.state.densities_m3[2], 1e-3, "mapped electron and ion production agree");
    auto product = p.mechanism.species[0]; product.id = "H_product"; p.mechanism.species.push_back(product); p.transport.resize(4); p.initial_densities_m3.push_back(0);
    chemistry::Reaction heavy; heavy.id = "distinct heavy relaxation"; heavy.reactants = {{0, 1}}; heavy.products = {{3, 1}}; heavy.rate.A = 1e8; heavy.energy_eV_per_event = {{"gas/translation", 1}, {"gas/internal", -1}}; heavy.check_energy_balance = true; p.mechanism.reactions.push_back(heavy);
    p.thermal.enabled = true; p.thermal.heat_capacity_J_m3_K = {1e3}; p.thermal.initial_temperature_K = {300}; p.thermal.heat_reservoirs = {"gas/translation"}; p.thermal.use_eedf_elastic_heating = true;
    const auto distinct = spatial::solve(p); check(distinct.success, "distinct heavy chemical translation and kinetic elastic heat may coexist: " + distinct.message);
    check(distinct.state.temperature_K[0] > 300, "both explicitly owned heating contributions evolve temperature");
}
// Each cell's steady Boltzmann solve continues from its last one (eedf_warm_start, the default):
// the same converged closure to the solve tolerance, so the run matches the cold-start run.
void test_boltzmann_warm_start() {
    auto p = plasma(); p.mesh.shape = {1, 4, 1}; p.initial_densities_m3.clear();
    for (std::size_t c = 0; c < 4; ++c) p.initial_densities_m3.insert(p.initial_densities_m3.end(), {1e22, 1e10 * static_cast<double>(c + 1), 1e10});
    p.boundaries[1].potential_V = 1; p.options.end_time_s = 3e-10; p.options.time_step_s = 1e-10;
    auto& reaction = p.mechanism.reactions[0]; reaction.rate.kind = chemistry::RateKind::ElectronEedf; reaction.rate.key = "manufactured-ionization"; reaction.collision_label = reaction.rate.key;
    kinetics::ElectronCoupling coupling; coupling.electron_species = "e"; coupling.strict_event_mapping = true;
    coupling.grid.cells = 32; coupling.grid.max_energy_ev = 5; coupling.grid.legendre_terms = 2;
    kinetics::CollisionProcess elastic; elastic.kind = kinetics::CollisionKind::Elastic; elastic.target = "H"; elastic.label = "elastic";
    elastic.mass_ratio = 9.1093837015e-31 / 1.6735575e-27; elastic.energy_ev = {.00001, 100}; elastic.cross_section_m2 = {1e-19, 1e-19};
    kinetics::CollisionProcess ionization; ionization.kind = kinetics::CollisionKind::Ionization; ionization.target = "H"; ionization.label = reaction.rate.key;
    ionization.threshold_ev = .01; ionization.energy_ev = {.01, .02, 100}; ionization.cross_section_m2 = {0, 1e-21, 1e-21};
    coupling.processes = {elastic, ionization}; p.electron_closure = coupling;
    const auto warm = spatial::solve(p);
    p.options.eedf_warm_start = false;
    const auto cold = spatial::solve(p);
    check(warm.success && cold.success && warm.accepted_steps == cold.accepted_steps, "warm and cold closures take the same steps: " + warm.message + cold.message);
    const auto scale = [](const std::vector<double>& v) { double m = 0; for (double q : v) m = std::max(m, std::abs(q)); return std::max(m, 1e-300); };
    for (std::size_t q = 0; q < warm.state.densities_m3.size(); ++q)
        close(warm.state.densities_m3[q] / scale(cold.state.densities_m3), cold.state.densities_m3[q] / scale(cold.state.densities_m3), 1e-10, "warm-started closure densities");
    for (std::size_t c = 0; c < warm.state.potential_V.size(); ++c)
        close(warm.state.potential_V[c] / scale(cold.state.potential_V), cold.state.potential_V[c] / scale(cold.state.potential_V), 1e-10, "warm-started closure potential");
}
void test_thermal_radiation() {
    auto p = base(3, 2);
    p.options.time_step_s = 1e-4; p.options.end_time_s = 1e-3;
    p.thermal.enabled = true; p.thermal.heat_capacity_J_m3_K = {2}; p.thermal.initial_temperature_K = {300}; p.thermal.heating_W_m3 = {100};
    const auto heated = spatial::solve(p); check(heated.success, "implicit heavy heating converges: " + heated.message);
    for (double T : heated.state.temperature_K) close(T, 300.05, 1e-7, "configured heat capacity closes temperature evolution");
    p = base(1); p.options.time_step_s = 1e-10; p.options.end_time_s = 1e-10;
    p.thermal.enabled = true; p.thermal.heat_capacity_J_m3_K = {1e-6}; p.thermal.initial_temperature_K = {300};
    spatial::RadiationGroup group; group.id = "test"; group.photon_energy_eV = 2; group.absorption_m1 = 10; group.initial_density_m3 = {1e15};
    p.radiation.push_back(group);
    const auto absorbed = spatial::solve(p); check(absorbed.success, "coupled radiation absorption and thermal solve: " + absorbed.message);
    const double photons = 1e15 / (1 + group.speed_m_s * group.absorption_m1 * p.options.time_step_s);
    close(absorbed.state.photon_densities_m3[0] / photons, 1, 1e-8, "implicit photon absorption");
    const double expected_temperature = 300 + (1e15 - photons) * 2 * qe / 1e-6;
    close(absorbed.state.temperature_K[0], expected_temperature, 1e-5, "absorbed photon energy heats heavy reservoir once");
    const auto& before = absorbed.samples.front(); const auto& after = absorbed.samples.back();
    close(after.thermal_energy_J + after.radiation_energy_J, before.thermal_energy_J + before.radiation_energy_J, 1e-20, "radiation/thermal total energy telescope");
    p = base(1); p.options.time_step_s = 1e-8; p.options.end_time_s = 1e-8;
    auto product = p.mechanism.species[0]; product.id = "H_product"; p.mechanism.species.push_back(product); p.transport.resize(2);
    p.initial_densities_m3 = {1e20, 0};
    chemistry::Reaction photo; photo.id = "manufactured-photoreaction"; photo.reactants = {{0, 1}}; photo.products = {{1, 1}};
    photo.rate.kind = chemistry::RateKind::Parameter; photo.rate.key = "photo_rate";
    photo.energy_eV_per_event = {{"gas/thermal", 2}, {"gas/radiation/test", -2}}; photo.check_energy_balance = true;
    p.mechanism.reactions.push_back(photo);
    p.thermal.enabled = true; p.thermal.heat_capacity_J_m3_K = {1}; p.thermal.initial_temperature_K = {300}; p.thermal.heat_reservoirs = {"gas/thermal"};
    group.absorption_m1 = 0; group.initial_density_m3 = {1e14}; group.energy_reservoir = "gas/radiation/test"; group.absorbers = {{photo.id, 1e-22}}; p.radiation = {group};
    const auto reacted = spatial::solve(p); check(reacted.success, "photon/chemistry/thermal Newton coupling: " + reacted.message);
    const double converted = reacted.state.densities_m3[1]; check(converted > 1e10, "photons cause actual species conversion");
    close((reacted.state.photon_densities_m3[0] + converted) / 1e14, 1, 1e-7, "one photon removed per photochemical event");
    close((reacted.state.densities_m3[0] + converted) / 1e20, 1, 1e-8, "photochemical nuclei conservation");
    close((reacted.samples.back().thermal_energy_J + reacted.samples.back().radiation_energy_J) / (reacted.samples.front().thermal_energy_J + reacted.samples.front().radiation_energy_J), 1, 1e-10, "photochemical radiative energy closes without duplicate heating");
}
void test_checkpoint() {
    auto p = plasma(); p.options.end_time_s = 1e-9;
    const auto full = spatial::solve(p); check(full.success, "full checkpoint reference run");
    p.options.end_time_s = 5e-10; const auto prefix = spatial::solve(p); check(prefix.success, "checkpoint prefix");
    p.options.end_time_s = 1e-9; p.initial_checkpoint = prefix.checkpoint;
    const auto resumed = spatial::solve(p); check(resumed.success, "BDF history checkpoint resumes: " + resumed.message);
    for (std::size_t k = 0; k < full.state.densities_m3.size(); ++k) close(resumed.state.densities_m3[k] / full.state.densities_m3[k], 1, 1e-9, "restart retains BDF concentration history");
    for (std::size_t k = 0; k < full.state.potential_V.size(); ++k) close(resumed.state.potential_V[k], full.state.potential_V[k], 1e-9, "restart field equivalence");
    p.initial_checkpoint->state.potential_V[0] += 1;
    bool rejected = false; try { (void)spatial::solve(p); } catch (const std::invalid_argument&) { rejected = true; }
    check(rejected, "inconsistent checkpoint potential rejected");
}
void test_checkpoint_time_bounds() {
    for (bool second_order : {false, true}) for (double prefix_minimum : {.02, .08}) {
        auto p = base(1); p.mesh.extent_m = {1, 1, 1};
        auto product = p.mechanism.species[0]; product.id = "H_product"; p.mechanism.species.push_back(product);
        p.transport.resize(2); p.initial_densities_m3 = {1e6, 0};
        chemistry::Reaction decay; decay.id = "bounded restart decay"; decay.reactants = {{0, 1}}; decay.products = {{1, 1}}; decay.rate.A = 10; p.mechanism.reactions.push_back(decay);
        p.options.time_step_s = .1; p.options.minimum_time_step_s = prefix_minimum; p.options.end_time_s = .14; p.options.bdf2 = second_order;
        p.options.relative_tolerance = 1e-11; p.options.absolute_density_tolerance_m3 = 1e-5;
        const auto prefix = spatial::solve(p); check(prefix.success, "short-endpoint checkpoint completes");
        check(prefix.checkpoint.next_step_s >= prefix_minimum && prefix.checkpoint.next_step_s <= .1, "saved next proposal respects both timestep bounds");
        close(prefix.checkpoint.previous_step_s, .04, 1e-14, "short endpoint retains its actual accepted BDF step");
        p.initial_checkpoint = prefix.checkpoint; p.options.minimum_time_step_s = .08; p.options.end_time_s = .29;
        const auto resumed = spatial::solve(p); check(resumed.success, "restart with a raised minimum step completes: " + resumed.message);
        check(resumed.samples.size() == 3, "bounded restart takes one legal step and one endpoint remainder");
        close(resumed.samples[1].time_s - resumed.samples[0].time_s, .08, 1e-14, "restored proposal is clamped before an ordinary accepted step");
        close(resumed.samples[2].time_s - resumed.samples[1].time_s, .07, 1e-14, "final endpoint may remain shorter than the minimum");
        double current = prefix.state.densities_m3[0], previous = prefix.checkpoint.previous_state.densities_m3[0], previous_step = .04;
        for (std::size_t i = 1; i < resumed.samples.size(); ++i) {
            const double step = resumed.samples[i].time_s - resumed.samples[i - 1].time_s, ratio = step / previous_step;
            const double a0 = second_order ? (1 + 2 * ratio) / (1 + ratio) : 1, a1 = second_order ? 1 + ratio : 1, a2 = second_order ? ratio * ratio / (1 + ratio) : 0;
            const double next = (a1 * current - a2 * previous) / (a0 + 10 * step);
            previous = current; current = next; previous_step = step;
        }
        close(resumed.state.densities_m3[0], current, 1e-4, "bounded BE/BDF restart follows the independent decay recurrence");
    }
    auto p = base(1); p.options.end_time_s = 0;
    const auto initialized = spatial::solve(p); check(initialized.success && initialized.accepted_steps == 0, "zero-step initialization completes");
    close(initialized.checkpoint.previous_step_s, 0, 0, "zero-step checkpoint contains no invented accepted timestep");
    p.initial_checkpoint = initialized.checkpoint;
    const auto unchanged = spatial::solve(p); check(unchanged.success, "zero-step checkpoint revalidates without advancement");
    p.initial_checkpoint->previous_step_s = p.options.time_step_s;
    const auto legacy = spatial::solve(p); check(legacy.success && legacy.checkpoint.previous_step_s == 0, "legacy zero-step proposal history remains readable and exports canonical zero");
    p.initial_checkpoint->previous_state.time_s += p.options.time_step_s;
    bool rejected = false; try { (void)spatial::solve(p); } catch (const std::invalid_argument&) { rejected = true; }
    check(rejected, "zero accepted steps reject inconsistent previous clocks");
}
void test_multiphase() {
    double previous_transfer = 0;
    for (std::size_t nx : {1u, 2u}) {
        auto p = base(nx); p.mesh.extent_m = {3, 1, 1};
        auto aqueous = p.mechanism.species[0]; aqueous.id = "H_aq"; aqueous.phase = "aqueous"; p.mechanism.species.push_back(aqueous);
        p.transport.resize(2); p.initial_densities_m3.clear();
        for (std::size_t c = 0; c < nx; ++c) p.initial_densities_m3.insert(p.initial_densities_m3.end(), {1e20, 0});
        chemistry::Reaction transfer; transfer.id = "manufactured gas/liquid transfer"; transfer.reactants = {{0, 1}}; transfer.products = {{1, 1}};
        transfer.basis_phase = "gas"; transfer.basis_interface = "water_surface"; transfer.rate.kind = chemistry::RateKind::Parameter; transfer.rate.key = "velocity_m_s";
        transfer.energy_eV_per_event = {{"gas/thermal", 1}, {"gas/internal", -1}}; transfer.check_energy_balance = true;
        p.mechanism.reactions.push_back(transfer);
        p.environment.parameters["velocity_m_s"] = .1; p.environment.phase_volumes_m3 = {{"gas", 1}, {"aqueous", 2}}; p.environment.interface_areas_m2 = {{"water_surface", .2}};
        p.options.time_step_s = .1; p.options.end_time_s = .1; p.options.bdf2 = false;
        p.thermal.enabled = true; p.thermal.heat_capacity_J_m3_K = {1}; p.thermal.initial_temperature_K = {300}; p.thermal.heat_reservoirs = {"gas/thermal"};
        const auto r = spatial::solve(p); check(r.success, "coupled gas/liquid transfer converges: " + r.message);
        const double expected = 1e20 * .002 / 1.002;
        close(r.particle_counts[0] + r.particle_counts[1], 1e20, 1e9, "unequal phase volumes conserve particle inventory");
        close(r.particle_counts[1] / expected, 1, 1e-8, "interface source uses total-domain area and own-phase volume");
        close(r.chemical_energy_integrals_J.at("gas/thermal"), r.particle_counts[1] * qe, 1e-9, "phase energy integrates physical event count");
        close(r.samples.back().thermal_energy_J - r.samples.front().thermal_energy_J, r.particle_counts[1] * qe, 1e-8, "phase-volume heat source closes total thermal energy");
        if (previous_transfer > 0) close(r.particle_counts[1] / previous_transfer, 1, 1e-10, "interface area does not duplicate under mesh refinement");
        previous_transfer = r.particle_counts[1];
    }
}
void test_sharp_interface() {
    auto p = base(2); p.mesh.extent_m = {3, 1, 1};
    auto aqueous = p.mechanism.species[0]; aqueous.id = "H_aq"; aqueous.phase = "aqueous"; p.mechanism.species.push_back(aqueous); p.transport.resize(2); p.transport[0].diffusion_m2_s = 1;
    p.phase_fractions = {{"gas", {1, 0}}, {"aqueous", {0, 1}}}; p.initial_densities_m3 = {1e20, 0, 0, 0};
    chemistry::Reaction reaction; reaction.id = "sharp-interface transfer"; reaction.reactants = {{0, 1}}; reaction.products = {{1, 1}}; reaction.basis_phase = "gas"; reaction.basis_interface = "water_surface"; reaction.rate.kind = chemistry::RateKind::Parameter; reaction.rate.key = "velocity_m_s";
    reaction.energy_eV_per_event = {{"gas/internal", -1}, {"aqueous/thermal", 1}}; reaction.check_energy_balance = true; p.mechanism.reactions = {reaction}; p.environment.parameters["velocity_m_s"] = .1;
    p.face_reactions = {{reaction.id, "gas", "aqueous", ""}};
    p.options.time_step_s = .1; p.options.end_time_s = .1; p.options.bdf2 = false;
    p.thermal.enabled = true; p.thermal.heat_capacity_J_m3_K = {1}; p.thermal.initial_temperature_K = {300}; p.thermal.heat_reservoirs = {"aqueous/thermal"};
    const auto result = spatial::solve(p); check(result.success, "sharp gas/aqueous face transfer converges: " + result.message);
    const double expected_remaining = 1e20 / (1 + .1 * .1 / 1.5), transferred = 1.5 * (1e20 - expected_remaining);
    close(result.state.densities_m3[0] / expected_remaining, 1, 1e-8, "face law uses actual area and gas cell volume");
    check(result.state.densities_m3[1] == 0 && result.state.densities_m3[2] == 0, "bulk diffusion cannot populate absent material phases");
    close((result.particle_counts[0] + result.particle_counts[1]) / 1.5e20, 1, 1e-9, "sharp interface transfer conserves nuclei");
    close(result.particle_counts[1] / transferred, 1, 1e-8, "interface reaction scatters aqueous particles to aqueous cell");
    close(result.samples.back().thermal_energy_J - result.samples.front().thermal_energy_J, transferred * qe, 1e-7, "sharp interface reaction heat has its aqueous cell owner");
    close(result.chemical_energy_integrals_J.at("gas/internal") + result.chemical_energy_integrals_J.at("aqueous/thermal"), 0, 1e-10, "interface energy ledger conserves authored transfer");
    p.thermal.heat_capacity_J_m3_K.clear(); p.thermal.initial_temperature_K.clear(); p.thermal.heat_reservoirs.clear();
    p.thermal.phases["gas"] = {{1}, {1}, {400}, {}, {}};
    p.thermal.phases["aqueous"] = {{2}, {1}, {300}, {}, {"aqueous/thermal"}};
    p.options.relative_tolerance = 1e-11;
    const auto separated = spatial::solve(p); check(separated.success, "sharp interface and separate gas/liquid temperatures converge: " + separated.message);
    close(separated.state.phase_temperatures_K.at("gas")[0], 400, 1e-10, "gas heat is not silently equilibrated with liquid");
    close(separated.state.phase_temperatures_K.at("aqueous")[1], 300 + transferred * qe / 3, 1e-7, "authored interface heat feeds aqueous heat capacity");
    close(separated.samples.back().thermal_energy_J - separated.samples.front().thermal_energy_J, transferred * qe, 1e-7, "separate phase energy sums conserve interfacial transfer");
    p.mechanism.reactions.clear(); p.face_reactions.clear(); p.thermal.phases["aqueous"].heat_reservoirs.clear(); p.interface_heat_transfer = {{"gas", "aqueous", 10}};
    const auto exchanged = spatial::solve(p); check(exchanged.success, "authored gas/liquid contact conductance converges");
    close(exchanged.samples.back().thermal_energy_J, exchanged.samples.front().thermal_energy_J, 1e-8, "contact heat transfer conserves combined phase energy");
    check(exchanged.state.phase_temperatures_K.at("gas")[0] < 400 && exchanged.state.phase_temperatures_K.at("aqueous")[1] > 300, "contact law actually exchanges heat between separate phases");
}
void test_phase_radiation_energy() {
    auto p = base(1); auto aqueous = p.mechanism.species[0]; aqueous.id = "H_aq"; aqueous.phase = "aqueous"; p.mechanism.species.push_back(aqueous); p.transport.resize(2); p.initial_densities_m3 = {0, 0};
    p.phase_fractions = {{"gas", {.25}}, {"aqueous", {.75}}}; p.options.time_step_s = 1e-10; p.options.end_time_s = 1e-10;
    p.thermal.enabled = true; p.thermal.phases["gas"] = {{1e-6}, {}, {300}, {}, {}}; p.thermal.phases["aqueous"] = {{2e-6}, {}, {300}, {}, {}};
    spatial::RadiationGroup group; group.id = "phase absorption"; group.photon_energy_eV = 2; group.absorption_m1_by_phase = {{"aqueous", 10}}; group.initial_density_m3 = {1e16}; p.radiation = {group};
    const auto result = spatial::solve(p); check(result.success, "phase-resolved photon absorption converges: " + result.message);
    close(result.state.phase_temperatures_K.at("gas")[0], 300, 1e-8, "liquid absorption does not heat gas");
    check(result.state.phase_temperatures_K.at("aqueous")[0] > 300, "authored aqueous opacity heats aqueous phase");
    const double expected_photons = 1e16 / (1 + 1e-10 * group.speed_m_s * 10 * .75);
    close(result.state.photon_densities_m3[0] / expected_photons, 1, 1e-8, "phase opacity includes physical path fraction");
    close(result.samples.back().thermal_energy_J + result.samples.back().radiation_energy_J, result.samples.front().thermal_energy_J + result.samples.front().radiation_energy_J, 1e-18, "separate phase photon/thermal energy conserves");
}
void test_transient_boltzmann() {
    auto p = plasma(); p.mesh.shape = {1, 1, 1}; p.initial_densities_m3 = {1e22, 1e10, 1e10}; p.transport.assign(3, {});
    p.boundaries[1].potential_V = 1; p.options.end_time_s = 2e-12; p.options.time_step_s = 1e-12; p.options.bdf2 = false;
    auto& reaction = p.mechanism.reactions[0]; reaction.rate.kind = chemistry::RateKind::ElectronEedf; reaction.rate.key = "transient-ionization"; reaction.collision_label = reaction.rate.key;
    kinetics::ElectronCoupling coupling; coupling.electron_species = "e"; coupling.strict_event_mapping = true;
    coupling.grid.cells = 32; coupling.grid.max_energy_ev = 5; coupling.grid.legendre_terms = 4;
    kinetics::CollisionProcess elastic; elastic.kind = kinetics::CollisionKind::Elastic; elastic.target = "H"; elastic.label = "elastic"; elastic.mass_ratio = 9.1093837015e-31 / 1.6735575e-27; elastic.energy_ev = {.00001, 100}; elastic.cross_section_m2 = {1e-19, 1e-19};
    kinetics::CollisionProcess ionization; ionization.kind = kinetics::CollisionKind::Ionization; ionization.target = "H"; ionization.label = reaction.rate.key; ionization.threshold_ev = .01; ionization.energy_ev = {.01, .02, 100}; ionization.cross_section_m2 = {0, 1e-21, 1e-21};
    coupling.processes = {elastic, ionization}; p.electron_closure = coupling; p.electron_mode = "transient_boltzmann"; p.electron_field_axis = {-1, 0, 0}; p.initial_electron_mean_energy_eV = 1;
    const auto full = spatial::solve(p); check(full.success, "coupled full-mode transient EEDF converges: " + full.message);
    check(full.state.electrons.size() == 1 && full.state.electrons[0].density_modes.size() == 128, "all transient Legendre modes retained in accepted state");
    close(full.state.electrons[0].electron_density_m3() / full.state.densities_m3[1], 1, 1e-8, "electron number exclusively owned by F0 moment");
    close(full.state.densities_m3[1] / full.state.densities_m3[2], 1, 1e-8, "transient electron and heavy ion events balance");
    check(full.state.densities_m3[1] > 1e10 && full.samples.back().electron_energy_J > 0, "transient chemistry and electron energy actually evolve");
    auto mixed = p; auto spectator = mixed.mechanism.species[0]; spectator.id = "H_aq"; spectator.phase = "aqueous"; mixed.mechanism.species.push_back(spectator);
    mixed.transport.push_back({}); mixed.initial_densities_m3.push_back(0); mixed.phase_fractions = {{"gas", {.25}}, {"aqueous", {.75}}};
    const auto quarter_gas = spatial::solve(mixed); check(quarter_gas.success, "mixed gas-volume kinetic power regression converges: " + quarter_gas.message);
    close(quarter_gas.chemical_energy_integrals_J.at("EEDF/operator/electrons/field") / full.chemical_energy_integrals_J.at("EEDF/operator/electrons/field"), .25, 1e-7, "every EEDF field-power label uses actual gas volume");
    close(quarter_gas.chemical_energy_integrals_J.at("Electrical/particle_work") / full.chemical_energy_integrals_J.at("Electrical/particle_work"), .25, 1e-7, "kinetic electrical work scales by gas fraction exactly once");
    close(quarter_gas.samples.back().electron_energy_J / full.samples.back().electron_energy_J, .25, 1e-7, "kinetic electron energy and operator power use the same phase volume");
    p.options.end_time_s = 1e-12; const auto prefix = spatial::solve(p); check(prefix.success, "transient checkpoint prefix");
    p.options.end_time_s = 2e-12; p.initial_checkpoint = prefix.checkpoint; const auto resumed = spatial::solve(p); check(resumed.success, "full-mode checkpoint restarts: " + resumed.message);
    for (std::size_t k = 0; k < 128; ++k) close(resumed.state.electrons[0].density_modes[k], full.state.electrons[0].density_modes[k], 1e-7 * std::max(1., std::abs(full.state.electrons[0].density_modes[k])), "kinetic checkpoint retains full angular state");
    auto no_step = p; no_step.options.end_time_s = prefix.state.time_s;
    const auto retained = spatial::solve(no_step); check(retained.success, "valid Legendre checkpoint revalidates without another step");
    for (bool previous : {false, true}) for (bool padding : {false, true}) {
        auto invalid = no_step;
        auto& state = previous ? invalid.initial_checkpoint->previous_state : invalid.initial_checkpoint->state;
        auto& electrons = state.electrons[0]; const auto& grid = electrons.grid;
        const auto stride = static_cast<std::size_t>(grid.legendre_terms), cells = static_cast<std::size_t>(grid.cells);
        const double density = electrons.electron_density_m3(), energy = electrons.electron_energy_ev_m3();
        if (padding) {
            electrons.density_modes[(cells - 1) * stride + stride - 1] = 1e6;
            close(electrons.electron_energy_ev_m3(), energy, 0, "padding corruption preserves the measured energy moment");
        } else {
            const auto cell = cells / 2;
            const auto face_energy = [&](std::size_t i) { return grid.max_energy_ev * std::pow(static_cast<double>(i) / static_cast<double>(cells), grid.power); };
            const auto weight = [&](std::size_t i) { return (2. / 3) * (std::pow(face_energy(i + 1), 1.5) - std::pow(face_energy(i), 1.5)); };
            const double original = electrons.density_modes[cell * stride]; check(original > 0, "isotropic corruption selects a populated energy cell");
            electrons.density_modes[cell * stride] = -original;
            electrons.density_modes[0] += 2 * original * weight(cell) / weight(0);
            check(electrons.electron_energy_ev_m3() > 0, "negative F0 corruption retains positive integrated energy");
        }
        close(electrons.electron_density_m3(), density, 1e-12 * density, "invalid kinetic modes preserve the fluid density moment");
        bool rejected = false; try { (void)spatial::solve(invalid); } catch (const std::invalid_argument&) { rejected = true; }
        check(rejected, padding ? "no-step restart rejects odd boundary padding in both histories" : "no-step restart rejects moment-preserving negative F0 in both histories");
    }
    auto tail_noise = p; tail_noise.options.mpi = false; tail_noise.options.end_time_s = 0; tail_noise.initial_checkpoint.reset();
    tail_noise.mechanism.reactions.clear(); tail_noise.electron_closure->processes = {elastic}; tail_noise.boundaries[1].potential_V = 0;
    const auto zero_field = spatial::solve(tail_noise); check(zero_field.success, "zero-field Legendre tail control initializes");
    tail_noise.initial_checkpoint = zero_field.checkpoint;
    for (auto* state : {&tail_noise.initial_checkpoint->state, &tail_noise.initial_checkpoint->previous_state}) {
        auto& electrons = state->electrons[0]; const auto& grid = electrons.grid;
        const auto cells = static_cast<std::size_t>(grid.cells), stride = static_cast<std::size_t>(grid.legendre_terms), last = (cells - 1) * stride;
        double peak = 0; for (std::size_t i = 0; i < cells; ++i) peak = std::max(peak, std::abs(electrons.density_modes[i * stride]));
        const auto face_energy = [&](std::size_t i) { return grid.max_energy_ev * std::pow(static_cast<double>(i) / static_cast<double>(cells), grid.power); };
        const auto weight = [&](std::size_t i) { return (2. / 3) * (std::pow(face_energy(i + 1), 1.5) - std::pow(face_energy(i), 1.5)); };
        const double next = -1e-12 * peak;
        electrons.density_modes[0] += (electrons.density_modes[last] - next) * weight(cells - 1) / weight(0);
        electrons.density_modes[last] = next;
    }
    check(spatial::solve(tail_noise).success, "no-step Legendre revalidation accepts the lower solver's numerical tail tolerance");
    tail_noise.options.end_time_s = 1e-12;
    const auto noisy_advance = spatial::solve(tail_noise);
    check(noisy_advance.success, "a tolerated roundoff tail remains admissible for actual transient advancement: " + noisy_advance.message);
    Json request{{"mechanism", p.mechanism.to_json()}, {"mesh", {{"shape", {1, 1, 1}}, {"extent_m", {.001, .002, .001}}}}, {"initial_densities_m3", {{"H", 1e22}, {"e", 1e10}, {"H+", 1e10}}}, {"transport", Json::object()},
        {"boundaries", {{"xmin", {{"kind", "electrode"}, {"potential_V", 0}}}, {"xmax", {{"kind", "electrode"}, {"potential_V", 1}}}}},
        {"time", {{"time_step_s", 1e-12}, {"end_time_s", 1e-12}, {"bdf2", false}, {"adaptive", false}}}, {"execution", {{"device", execution_device}, {"mpi", execution_mpi}, {"threads", 2}}},
        {"electron_closure", {{"mode", "transient_boltzmann"}, {"strict_event_mapping", true}, {"fixed_field_axis", {-1, 0, 0}}, {"initial_mean_energy_eV", 1},
            {"grid", {{"cells", 32}, {"max_energy_ev", 5}, {"legendre_terms", 4}}}, {"processes", Json::array({
                {{"kind", "elastic"}, {"label", "elastic"}, {"target", "H"}, {"mass_ratio", elastic.mass_ratio}, {"energy_ev", elastic.energy_ev}, {"cross_section_m2", elastic.cross_section_m2}},
                {{"kind", "ionization"}, {"label", reaction.rate.key}, {"target", "H"}, {"threshold_ev", .01}, {"energy_ev", ionization.energy_ev}, {"cross_section_m2", ionization.cross_section_m2}}})}}}};
    const auto json_prefix = spatial::solve_json(request); check(json_prefix.at("success").get<bool>(), "JSON transient kinetic request");
    request["checkpoint"] = json_prefix.at("checkpoint"); request["time"]["end_time_s"] = 2e-12;
    const auto json_resumed = spatial::solve_json(request); check(json_resumed.at("success").get<bool>(), "JSON full-mode kinetic checkpoint deserializes");
    close(json_resumed.at("electron_states")[0].at("density_modes")[0].get<double>(), full.state.electrons[0].density_modes[0], 1e-7 * std::abs(full.state.electrons[0].density_modes[0]), "JSON checkpoint retains kinetic shape");
    request.erase("checkpoint"); request["electron_closure"]["mode"] = "transient_spherical"; request["electron_closure"].erase("fixed_field_axis"); request["time"]["bdf2"] = true;
    const auto spherical_full = spatial::solve_json(request); check(spherical_full.at("success").get<bool>(), "full spherical collision/streaming spatial residual converges");
    const auto& angular = spherical_full.at("spherical_electron_states")[0]; check(angular.at("representation") == "real_spherical_harmonics" && angular.at("density_modes").size() == 512, "checkpoint retains every real m in L-squared storage");
    bool nonaxisymmetric = false; for (std::size_t q = 3; q < 512; q += 16) nonaxisymmetric = nonaxisymmetric || std::abs(angular.at("density_modes")[q].get<double>()) > 1e-10;
    check(nonaxisymmetric, "transverse laboratory-field acceleration creates non-axisymmetric m modes");
    request["time"]["end_time_s"] = 1e-12; const auto spherical_prefix = spatial::solve_json(request); request["time"]["end_time_s"] = 2e-12; request["checkpoint"] = spherical_prefix.at("checkpoint");
    const auto spherical_resumed = spatial::solve_json(request); check(spherical_resumed.at("success").get<bool>(), "full spherical BDF history restarts");
    for (std::size_t q = 0; q < 512; ++q) close(spherical_resumed.at("spherical_electron_states")[0].at("density_modes")[q].get<double>(), angular.at("density_modes")[q].get<double>(), 1e-7 * std::max(1., std::abs(angular.at("density_modes")[q].get<double>())), "restart preserves non-axisymmetric angular state");
    const double kinetic_work = spherical_full.at("chemical_energy_integrals_J").at("EEDF/operator/electrons/field").get<double>();
    check(kinetic_work != 0, "spherical field acceleration performs nonzero work");
    close(spherical_full.at("chemical_energy_integrals_J").at("Electrical/particle_work").get<double>(), kinetic_work, 1e-12 * std::abs(kinetic_work), "total charged-particle work includes kinetic field moment exactly once");
    for (const auto* history : {"state", "previous_state"}) {
        auto invalid = request; invalid["time"]["end_time_s"] = invalid["checkpoint"]["state"]["time_s"];
        auto& modes = invalid["checkpoint"][history]["spherical_electrons"][0]["density_modes"];
        modes[0] = -1;
        bool negative_rejected = false; try { (void)spatial::solve_json(invalid); } catch (const std::invalid_argument&) { negative_rejected = true; }
        check(negative_rejected, "no-step restart rejects a negative F00 in both BDF histories");
    }
    request["checkpoint"]["state"]["spherical_electrons"][0]["basis"] = "legendre_m0_v1";
    bool basis_rejected = false; try { (void)spatial::solve_json(request); } catch (const std::invalid_argument&) { basis_rejected = true; }
    check(basis_rejected, "lossy angular checkpoint projection rejects");
    p.initial_checkpoint.reset(); p.transport[1].diffusion_m2_s = 1;
    bool rejected = false; try { (void)spatial::solve(p); } catch (const std::invalid_argument&) { rejected = true; }
    check(rejected, "unavailable kinetic spatial transport is explicitly rejected");
}
void test_json_checkpoint_validation() {
    const auto p = base(2, 2);
    Json request{{"mechanism", p.mechanism.to_json()}, {"mesh", {{"shape", {2, 2, 1}}, {"extent_m", {.001, .002, .001}}}}, {"initial_densities_m3", {{"H", 1e20}}}, {"transport", Json::object()},
        {"boundaries", {{"xmin", {{"kind", "electrode"}, {"potential_V", 0}}}, {"xmax", {{"kind", "electrode"}, {"potential_V", 1}}}}},
        {"time", {{"time_step_s", 1e-5}, {"end_time_s", 2e-5}}}, {"execution", {{"device", execution_device}, {"threads", 2}, {"mpi", execution_mpi}}},
        {"thermal", {{"heat_capacity_J_m3_K", 1}, {"initial_temperature_K", 300}, {"heating_W_m3", 2}}}};
    const auto full = spatial::solve_json(request); check(full.at("success").get<bool>(), "spatial JSON request converges");
    request["time"]["end_time_s"] = 1e-5; const auto prefix = spatial::solve_json(request); request["time"]["end_time_s"] = 2e-5; request["checkpoint"] = prefix.at("checkpoint");
    const auto resumed = spatial::solve_json(request); check(resumed.at("success").get<bool>(), "JSON BDF checkpoint deserializes and resumes");
    check(full.at("temperature_K") == resumed.at("temperature_K"), "JSON restart retains thermal integration history");
    request["checkpoint"]["next_step_s"] = -1;
    bool rejected = false; try { (void)spatial::solve_json(request); } catch (const std::invalid_argument&) { rejected = true; }
    check(rejected, "nonpositive checkpoint timestep rejects before integration");
    request["checkpoint"] = prefix.at("checkpoint"); request["checkpoint"]["previous_state"]["potential_V"][0] = 20;
    rejected = false; try { (void)spatial::solve_json(request); } catch (const std::invalid_argument&) { rejected = true; }
    check(rejected, "tampered previous field rejects before BDF restart");
    auto duplicate = base(1); spatial::RadiationGroup group; group.id = "first"; group.photon_energy_eV = 2; group.energy_reservoir = "gas/radiation/shared"; duplicate.radiation.push_back(group); group.id = "second"; duplicate.radiation.push_back(group);
    rejected = false; try { (void)spatial::solve(duplicate); } catch (const std::invalid_argument&) { rejected = true; }
    check(rejected, "a chemical radiation reservoir cannot feed two groups");
}
void test_temperature_bounds() {
    for (const auto bounds : {std::pair{0., 300.}, std::pair{300., 400.}, std::pair{300., 300.}}) {
        auto p = base(1); auto product = p.mechanism.species[0]; product.id = "H_product"; p.mechanism.species.push_back(product); p.initial_densities_m3 = {1e10, 0}; p.transport.resize(2);
        chemistry::Reaction r; r.id = "bounded thermal rate"; r.reactants = {{0, 1}}; r.products = {{1, 1}}; r.rate.A = 1; r.rate.minimum_temperature_K = bounds.first; r.rate.maximum_temperature_K = bounds.second; p.mechanism.reactions.push_back(r);
        p.options.time_step_s = .01; p.options.end_time_s = .01;
        p.thermal.enabled = true; p.thermal.heat_capacity_J_m3_K = {1}; p.thermal.initial_temperature_K = {300};
        const auto result = spatial::solve(p); check(result.success, "valid rate-bound temperature does not fail a Jacobian perturbation: " + result.message);
        check(result.state.densities_m3[1] > 0, "bounded-temperature reaction advances");
        close(result.state.temperature_K[0], 300, 1e-10, "unheated bound temperature remains fixed");
    }
    auto p = base(1); p.thermal.enabled = true; p.thermal.heat_capacity_J_m3_K = {1}; p.thermal.heat_reservoirs = {"gas/typo"};
    bool rejected = false; try { (void)spatial::solve(p); } catch (const std::invalid_argument&) { rejected = true; }
    check(rejected, "unknown thermal reservoir cannot silently disappear");
}
void test_adaptive_time() {
    auto p = base(1);
    auto product = p.mechanism.species[0]; product.id = "H_product"; p.mechanism.species.push_back(product);
    p.initial_densities_m3 = {1e10, 0}; p.transport.resize(2);
    chemistry::Reaction reaction; reaction.id = "manufactured stiff decay"; reaction.reactants = {{0, 1}}; reaction.products = {{1, 1}}; reaction.rate.A = 100;
    p.mechanism.reactions.push_back(reaction); p.options.time_step_s = .01; p.options.end_time_s = .05; p.options.adaptive_time = true;
    p.options.temporal_relative_tolerance = 1e-3;
    const auto loose = spatial::solve(p); check(loose.success && loose.rejected_steps > 0, "temporal controller rejects inaccurate converged trials");
    p.options.temporal_relative_tolerance = 1e-5;
    const auto tight = spatial::solve(p); check(tight.success && tight.accepted_steps > loose.accepted_steps, "tighter temporal tolerance refines actual integration");
    const double exact = 1e10 * std::exp(-5.);
    check(std::abs(tight.state.densities_m3[0] - exact) < .3 * std::abs(loose.state.densities_m3[0] - exact), "temporal tolerance improves manufactured analytic decay accuracy");
    for (const auto& s : tight.samples) check(s.temporal_error <= 1 && s.nonlinear_residual <= 1, "accepted timestep satisfies nonlinear and temporal tests");
    close(tight.particle_counts[0] + tight.particle_counts[1], 1e10 * spatial::cell_volumes(p.mesh)[0], 1e-7, "rejected trials do not alter particle conservation");
    p.options.end_time_s = tight.samples[tight.samples.size() / 2].time_s;
    const auto prefix = spatial::solve(p); check(prefix.success, "adaptive checkpoint prefix");
    p.options.end_time_s = .05; p.initial_checkpoint = prefix.checkpoint;
    const auto resumed = spatial::solve(p); check(resumed.success, "adaptive checkpoint resumes accepted BDF history");
    close(resumed.state.densities_m3[0], tight.state.densities_m3[0], .01, "adaptive restart retains next timestep and full accepted history");
}
void test_authored_walls() {
    for (int charge : {-1, 1}) {
        chemistry::Species species; species.charge = charge; species.mass_kg = 1.6735575e-27;
        spatial::Boundary::Sheath closure; closure.temperature_eV = 1; closure.transmission = .5;
        const double potential = static_cast<double>(charge) * 2;
        const auto flux = spatial::boundary::evaluate_sheath(closure, species, 1e12, 0, potential);
        const auto plus = spatial::boundary::evaluate_sheath(closure, species, 1e12, 0, potential + 1e-6);
        const auto minus = spatial::boundary::evaluate_sheath(closure, species, 1e12, 0, potential - 1e-6);
        close((plus.particles_m2_s - minus.particles_m2_s) / (2e-6) / flux.wall_potential_derivative_m2_s_V, 1, 1e-8, "repelling electron/ion sheath potential derivatives match the actual flux");
        close(flux.cell_potential_derivative_m2_s_V + flux.wall_potential_derivative_m2_s_V, 0, 1e-12, "sheath flux is invariant under a potential gauge shift");
    }
    auto p = base(1); p.initial_densities_m3 = {1e12}; p.options.time_step_s = 1e-8; p.options.end_time_s = 1e-8; p.options.bdf2 = false;
    p.boundaries[1].absorbing = true; p.boundaries[1].sheaths.push_back({"H", "maxwellian", 1, 0, .5});
    const double speed = .5 * std::sqrt(qe / (2 * std::numbers::pi * p.mechanism.species[0].mass_kg));
    const auto neutral = spatial::solve(p); check(neutral.success, "authored Maxwellian boundary flux converges");
    close(neutral.state.densities_m3[0] / (1e12 / (1 + p.options.time_step_s * speed / .001)), 1, 1e-9, "Maxwellian wall reproduces analytic backward-Euler loss");
    p.boundaries[1].sheaths[0].model = "drift";  // a neutral has no drift: the same thermal loss
    const auto drifting = spatial::solve(p); check(drifting.success, "authored drift boundary flux converges");
    close(drifting.state.densities_m3[0] / neutral.state.densities_m3[0], 1, 1e-12, "drift closure keeps the one-way thermal loss");
    // Electrons emitted at a cathode that drives them away. With the drift closure none return, so
    // the electrons gained are the yield times the ions collected on any grid; a zero-density wall
    // takes back a share that grows as the wall cell shrinks.
    double zero_density_share = 1;
    for (const std::size_t nx : {4u, 16u}) {
        auto q = plasma(); q.mesh.shape = {nx, 1, 1}; q.mechanism.reactions.clear(); q.transport[1] = {.05, .05};
        q.initial_densities_m3.clear(); for (std::size_t c = 0; c < nx; ++c) q.initial_densities_m3.insert(q.initial_densities_m3.end(), {1e20, 0, 1e8});
        auto& cathode = q.boundaries[0]; cathode.absorbing = true; cathode.secondary_emission.push_back({"H+", "e", .2}); cathode.secondary_energy_eV = 3;
        const auto absorbed = spatial::solve(q); check(absorbed.success, "emission into a zero-density wall converges: " + absorbed.message);
        const double share = absorbed.particle_counts[1] / (.2 * absorbed.particles_collected_at_boundaries[2]);
        check(share < zero_density_share, "a zero-density wall takes back more emitted electrons on a finer grid");
        zero_density_share = share;
        cathode.sheaths.push_back({"e", "drift", 0, 0, 0});
        const auto escaped = spatial::solve(q); check(escaped.success, "emission through a drift closure converges: " + escaped.message);
        close(escaped.particle_counts[1] / (.2 * escaped.particles_collected_at_boundaries[2]), 1, 1e-8, "drift closure keeps every emitted electron the field drives away");
    }
    p = plasma(); p.mesh.shape = {1, 1, 1}; p.initial_densities_m3 = {1e20, 1e8, 1e8}; p.mechanism.reactions.clear(); p.transport.assign(3, {});
    p.options.time_step_s = 1e-8; p.options.end_time_s = 1e-8; p.options.bdf2 = false;
    auto& wall = p.boundaries[1]; wall.kind = spatial::BoundaryKind::Dielectric; wall.potential_V = 0; wall.capacitance_F_m2 = 1e-5; wall.absorbing = true;
    wall.sheaths.push_back({"H+", "maxwellian", 1, 0, .5}); wall.secondary_emission.push_back({"H+", "e", .2}); wall.secondary_energy_eV = 3;
    const auto emitted = spatial::solve(p); check(emitted.success, "authored ion-induced secondary source converges with surface charge: " + emitted.message);
    const double ne_added = emitted.state.densities_m3[1] - 1e8, ni_lost = 1e8 - emitted.state.densities_m3[2];
    close(ne_added / ni_lost, .2, 1e-8, "secondary yield multiplies actual incident ion flux");
    check(emitted.particles_collected_at_boundaries[1] < 0, "outgoing emitted electrons have a signed negative boundary count");
    close(emitted.samples.back().gas_charge_C + emitted.samples.back().surface_charge_C, 0, 1e-25, "emission and incident collection conserve plasma plus wall charge");
    close(emitted.chemical_energy_integrals_J.at("Boundary/secondary_energy_supply"), ne_added * spatial::cell_volumes(p.mesh)[0] * qe * 3, 1e-25, "authored wall energy supply is accounted once");
    wall.sheaths[0].model = "bohm"; wall.sheaths[0].electron_temperature_eV = 2; wall.potential_V = -10;
    const auto bohm = spatial::solve(p); check(bohm.success && bohm.state.densities_m3[2] < 1e8, "Bohm closure accepts an ion-attracting authored sheath");
    wall.potential_V = 10;
    const auto invalid = spatial::solve(p); check(!invalid.success && invalid.accepted_steps == 0 && invalid.state.time_s == 0, "Bohm model rejects an ion-repelling wall transactionally");
    wall.potential_V = 0; wall.sheaths[0].model = "maxwellian"; wall.kinetic_electrons = "secondary_emission";
    kinetics::ElectronCoupling closure; closure.strict_event_mapping = true; closure.grid.cells = 16; closure.grid.max_energy_ev = 10; closure.grid.legendre_terms = 2;
    kinetics::CollisionProcess elastic; elastic.kind = kinetics::CollisionKind::Elastic; elastic.target = "H"; elastic.label = "elastic"; elastic.mass_ratio = 9.1093837015e-31 / 1.6735575e-27; elastic.energy_ev = {.00001, 100}; elastic.cross_section_m2 = {1e-19, 1e-19}; closure.processes = {elastic};
    p.electron_closure = closure; p.electron_mode = "transient_spherical"; p.initial_electron_mean_energy_eV = 1; p.options.time_step_s = 1e-11; p.options.end_time_s = 1e-11;
    wall.incoming_electrons = kinetics::spherical_from_legendre(kinetics::maxwellian_eedf(1, 2, closure.grid));
    const auto kinetic = spatial::solve(p); check(kinetic.success, "full spherical secondary boundary flux couples incident ions to emitted distribution: " + kinetic.message);
    const double volume = spatial::cell_volumes(p.mesh)[0];
    close(kinetic.particle_counts[1] + kinetic.particles_collected_at_boundaries[1], 1e8 * volume, 1e-7, "kinetic secondary number flux is conservative");
    close(kinetic.samples.back().gas_charge_C + kinetic.samples.back().surface_charge_C, 0, 1e-24, "kinetic secondary boundary charge has one surface owner");
    check(kinetic.chemical_energy_integrals_J.at("Boundary/secondary_energy_supply") > 0, "full incoming distribution carries an explicit wall energy supply");
    wall.secondary_emission[0].yield = 0;
    const auto no_emission = spatial::solve(p); check(no_emission.success && no_emission.state.densities_m3[1] < kinetic.state.densities_m3[1], "authored nonzero kinetic yield actually increases electron inventory relative to absorbing wall");
    p.mesh.axisymmetric = true; p.boundaries[0].kind = spatial::BoundaryKind::Insulating;
    const auto rz = spatial::solve(p); check(rz.success && !rz.state.spherical_electrons.empty(), "RZ spherical wall mapping omits zero-area axis faces: " + rz.message);
    p.boundaries[0].kind = spatial::BoundaryKind::Dielectric; p.boundaries[0].capacitance_F_m2 = 1e-5; p.boundaries[0].potential_V = 100;
    const auto zero_area = spatial::solve(p); check(zero_area.success, "zero-area axis label creates no ghost boundary unknown: " + zero_area.message);
    check(zero_area.state.surface_charge_C_m2.size() == rz.state.surface_charge_C_m2.size(), "zero-area dielectric label adds no physical surface DOF");
    for (std::size_t c = 0; c < rz.state.potential_V.size(); ++c) close(zero_area.state.potential_V[c], rz.state.potential_V[c], 1e-10, "axis regularity ignores an absent wall's backing voltage");
}
void test_skew_dielectric_patch() {
    auto p = base(1); p.mesh.nodes_m = {{{0, 0, 0}}, {{2, 0, 0}}, {{1.5, 1, 0}}, {{0, 1, 0}}};
    p.mesh.cells = {{"quad4", {0, 1, 2, 3}}}; p.mesh.boundary_faces = {{{0, 1}, 0}, {{1, 2}, 1}, {{2, 3}, 2}, {{3, 0}, 3}}; p.mesh.extent_m[2] = 1;
    const auto geometry = spatial::mesh::geometry(p.mesh);
    for (const auto& wall : geometry.walls) {
        auto& boundary = p.boundaries[static_cast<std::size_t>(wall.side)]; boundary.kind = spatial::BoundaryKind::Dielectric; boundary.capacitance_F_m2 = 1e-8;
        boundary.initial_surface_charge_C_m2 = eps0 * wall.normal[0] + boundary.capacitance_F_m2 * wall.center[0];
    }
    p.options.time_step_s = 1e-8; p.options.end_time_s = 2e-8;
    const auto result = spatial::solve(p); check(result.success, "skew affine dielectric patch remains converged in the coupled runtime");
    close(result.state.potential_V[0], geometry.centers[0][0], 1e-9, "multipoint cell potential is affine exact with independent Robin unknowns");
    for (std::size_t w = 0; w < geometry.walls.size(); ++w) close(result.state.dielectric_potential_V[w], geometry.walls[w].center[0], 1e-9, "Robin face potential is affine exact on skew supplied cells");
    close(result.samples.back().field_energy_J, result.samples.front().field_energy_J, 1e-20, "steady skew dielectric field and backing-capacitor energy remain unchanged");
}
void test_interface_kernel() {
    chemistry::Mechanism mechanism; chemistry::Species gas; gas.id = "H+"; gas.charge = 1; gas.elements = {{"H", 1}}; gas.mass_kg = 1.6735575e-27;
    auto aqueous = gas; aqueous.id = "H+_aq"; aqueous.phase = "aqueous"; mechanism.species = {gas, aqueous};
    chemistry::Reaction reaction; reaction.id = "authored transfer"; reaction.reactants = {{0, 1}}; reaction.products = {{1, 1}}; reaction.basis_interface = "gas_water"; reaction.rate.A = .001;
    reaction.energy_eV_per_event = {{"gas/heat", -2}, {"aqueous/heat", 2}}; reaction.check_energy_balance = true; mechanism.reactions = {reaction};
    chemistry::Environment environment; environment.phase_volumes_m3 = {{"gas", 3}, {"aqueous", 7}};
    spatial::FaceReaction binding; binding.reaction_id = reaction.id;
    const auto a = spatial::phase_interface::evaluate_reaction(mechanism, binding, {{1e20, 0}}, environment, 2, 2, -1);
    close(a.particle_rates_s[0] / -2e17, 1, 1e-14, "shared interface kernel uses authored physical area");
    close(a.particle_rates_s[0] + a.particle_rates_s[1], 0, 1, "shared interface kernel conserves transferred particle count");
    close(a.own_volume_sources.production_rates_m3_s[0] * 3 + a.own_volume_sources.production_rates_m3_s[1] * 7, 0, 32, "unequal phase volume normalization conserves actual count");
    close(a.particle_jacobian_s_m3[0], -.002, 1e-17, "shared interface kernel retains analytic concentration tangent");
    close(a.energy_powers_W.at("gas/heat") + a.energy_powers_W.at("aqueous/heat"), 0, 1e-15, "authored interface energy partitions conserve");
    close(a.electric_power_W / (qe * 2e17 * 3), 1, 1e-14, "charge transfer electrical work follows owner-cell potentials");
    environment.phase_volumes_m3 = {{"gas", 1e200}, {"aqueous", 1e200}};
    const auto scaled = spatial::phase_interface::evaluate_reaction(mechanism, binding, {{1e20, 0}}, environment, 2, 2, -1);
    close(scaled.particle_rates_s[1], a.particle_rates_s[1], 1, "changing receiving volumes does not alter physical area-event count");
}

void test_thermal_defaults_and_aliases() {
    auto p = base(1); p.mesh.extent_m = {1, 1, 1};
    auto aqueous = p.mechanism.species[0]; aqueous.id = "H_aq"; aqueous.phase = "aqueous";
    p.mechanism.species.push_back(aqueous); p.transport.resize(2); p.initial_densities_m3 = {0, 0};
    p.phase_fractions = {{"gas", {.5}}, {"aqueous", {.5}}};
    p.environment.gas_temperature_K = 1000; p.environment.liquid_temperature_K = 300;
    p.thermal.enabled = true; p.thermal.phases["gas"].heat_capacity_J_m3_K = {1}; p.thermal.phases["aqueous"].heat_capacity_J_m3_K = {1};
    auto initial = spatial::solve(p); check(initial.success, initial.message);
    close(initial.state.phase_temperatures_K.at("gas")[0], 1000, 1e-10, "gas default follows gas environment");
    close(initial.state.phase_temperatures_K.at("aqueous")[0], 300, 1e-10, "aqueous default follows liquid environment");
    close(initial.samples.front().thermal_energy_J, 650, 1e-10, "phase defaults preserve initial energy");
    p.thermal.phases["aqueous"].initial_temperature_K = {350};
    p.thermal.phases["aqueous"].heating_W_m3 = {10};
    p.options.time_step_s = .01; p.options.end_time_s = .02;
    auto first = spatial::solve(p); check(first.success, first.message);
    p.initial_checkpoint = first.checkpoint; p.options.end_time_s = .04;
    auto resumed = spatial::solve(p); check(resumed.success, resumed.message);
    close(resumed.state.phase_temperatures_K.at("aqueous")[0], 350.4, 1e-8, "checkpoint retains evolved explicit phase temperature");
    auto liquid = aqueous; liquid.id = "H_liquid"; liquid.phase = "liquid";
    p.initial_checkpoint.reset(); p.options.end_time_s = 0; p.mechanism.species.push_back(liquid); p.transport.resize(3); p.initial_densities_m3 = {0, 0, 0};
    p.phase_fractions = {{"gas", {0}}, {"aqueous", {.5}}, {"liquid", {.5}}};
    p.thermal.phases["liquid"].heat_capacity_J_m3_K = {1};
    bool rejected = false; try { (void)spatial::solve(p); } catch (const std::exception&) { rejected = true; }
    check(rejected, "separate liquid and aqueous temperatures must reject their shared selector");
    p.thermal.phases.erase("aqueous"); p.thermal.phases.erase("gas");
    auto valid = spatial::solve(p); check(valid.success, valid.message);
    close(valid.state.phase_temperatures_K.at("liquid")[0], 300, 1e-10, "liquid alias alone keeps its liquid default");
}

void test_inactive_energy_history() {
    auto p = base(1); p.mesh.extent_m = {1, 1, 1};
    p.mesh.nodes_m = {{0,0,0},{1,0,0},{2,1,0},{1,1,0}};
    p.mesh.cells = {{"tri3",{0,1,2}},{"tri3",{0,2,3}}};
    p.mesh.boundary_faces = {{{0,1},0},{{1,2},1},{{2,3},2},{{3,0},3}};
    p.boundaries[1].kind = spatial::BoundaryKind::Insulating;
    auto aqueous = p.mechanism.species[0]; aqueous.id = "H_aq"; aqueous.phase = "aqueous";
    p.mechanism.species.push_back(aqueous); p.transport.resize(2); p.initial_densities_m3.assign(4,0);
    p.phase_fractions = {{"gas",{1,0}},{"aqueous",{0,1}}};
    spatial::RadiationGroup photons; photons.id = "g"; photons.photon_energy_eV = 1; photons.speed_m_s = 1;
    photons.diffusion_m2_s = 1; photons.initial_density_m3 = {1e12,1e12}; photons.absorption_m1_by_phase = {{"gas",1000}}; photons.escaping_sides[0] = true; p.radiation = {photons};
    p.options.relative_tolerance = 1e-11; p.options.absolute_density_tolerance_m3 = 1e-5;
    p.options.time_step_s = .001; p.options.end_time_s = .02;
    const auto full = spatial::solve(p); check(full.success, full.message);
    const auto balance = [&](const spatial::Result& r) { return r.samples.back().radiation_energy_J + r.chemical_energy_integrals_J.at("Radiation/escaped/g") + r.chemical_energy_integrals_J.at("Radiation/background_absorption/g"); };
    close(balance(full)/(qe*1e12), 1, 1e-9, "zero current escape power still advances its BDF energy history");
    close(full.chemical_energy_integrals_J.at("Radiation/escaped/g")/qe, 1.0692094048436478e9, 20, "escape integral keeps the zero-power BDF tail");
    p.options.end_time_s = .003; const auto prefix = spatial::solve(p); check(prefix.success, prefix.message);
    p.initial_checkpoint = prefix.checkpoint; p.options.end_time_s = .02;
    const auto resumed = spatial::solve(p); check(resumed.success, resumed.message);
    close(balance(resumed), balance(full), 1e-15, "restart preserves inactive energy histories");
    close(resumed.chemical_energy_integrals_J.at("Radiation/escaped/g"), full.chemical_energy_integrals_J.at("Radiation/escaped/g"), 1e-15, "restarted escape integral matches full run");
}

} // namespace
int main(int argc, char** argv) {
    for (int k = 1; k < argc; ++k) { if (std::string(argv[k]) == "--cuda") execution_device = "cuda"; if (std::string(argv[k]) == "--mpi") execution_mpi = true; }
    if (execution_device == "cuda" && !raikou::backend::cuda_available()) return 77;
    raikou::backend::Runtime runtime(execution_mpi);
    const auto run = [](const char* name, auto action) { try { action(); } catch (const std::exception& error) { throw std::runtime_error(std::string(name) + ": " + error.what()); } };
    try { run("test_checkpoint_time_bounds", test_checkpoint_time_bounds); run("test_thermal_defaults_and_aliases", test_thermal_defaults_and_aliases); run("test_inactive_energy_history", test_inactive_energy_history); run("test_flux", test_flux); run("test_poisson", test_poisson); run("test_diffusion_conservation", test_diffusion_conservation); run("test_supplied_meshes", test_supplied_meshes); run("test_skew_transport", test_skew_transport); run("test_reactive_breakdown", test_reactive_breakdown); run("test_surface_and_circuit", test_surface_and_circuit); run("test_boltzmann_feedback", test_boltzmann_feedback); run("test_boltzmann_warm_start", test_boltzmann_warm_start); run("test_thermal_radiation", test_thermal_radiation); run("test_checkpoint", test_checkpoint); run("test_multiphase", test_multiphase); run("test_sharp_interface", test_sharp_interface); run("test_phase_radiation_energy", test_phase_radiation_energy); run("test_transient_boltzmann", test_transient_boltzmann); run("test_json_checkpoint_validation", test_json_checkpoint_validation); run("test_temperature_bounds", test_temperature_bounds); run("test_adaptive_time", test_adaptive_time); run("test_authored_walls", test_authored_walls); run("test_skew_dielectric_patch", test_skew_dielectric_patch); run("test_interface_kernel", test_interface_kernel); std::cout << "spatial controls passed\n"; }
    catch (const std::exception& e) { std::cerr << e.what() << '\n'; return 1; }
}
