#include "raikou/h2o_neutral_dissociation.h"
#include "raikou/h2o_dea_kernel.h"
#include "raikou/h2o_two_body_attachment.h"
#include "raikou/h2o_common_mass_basis.h"
#include <functional>
#include <iostream>
int main(int argc,char** argv) {try {
    using namespace raikou::kinetics;
#ifndef RAIKOU_TEST_H2O_DISSOCIATION
#define RAIKOU_TEST_H2O_DISSOCIATION "data/collisions/h2o-gas-20261029-dissociation.json"
#endif
    const auto data=StrictCollisionDataset::read(argc==2?argv[1]:RAIKOU_TEST_H2O_DISSOCIATION);
    int checks=0;const auto check=[&](bool okay,const char* why) {++checks;if (!okay)throw std::runtime_error(why);};
    const auto rejects=[&](const std::function<void()>& f) {bool bad=false;try {f();}catch(const std::exception&) {bad=true;}check(bad,"Unadmitted dissociation accepted");};
    constexpr double e=1.602176634e-19,me=9.1093837139e-31,c=299792458.,u=1.66053906660e-27;
    const double M=18.01056468403*u,H=1.00782503223*u;const CollisionMomentum beam{.6,0,.8};
    const auto basis=conditional_water_mass_basis(data,M,H);
    const auto dea=conditional_hminus_Ram65_products(data,"Hminus_Ram65_factorized_window_v1",6.5,1,M,basis.Hminus_kg,beam,0.,.5,.5);
    const auto ohm=conditional_ohminus_ground_products(data,"OHminus_ground_isotropic_CM_v1",6.5,1,M,H,beam,{1,0,0});
    check(std::abs(dea.OH_state_mass_kg-basis.OH_X_v0_kg)<3e-15*basis.OH_X_v0_kg,"Shared OH ground mass across DEA and neutral dissociation");
    check(std::abs(ohm.anion_state_mass_kg-basis.OHminus_X_v0_kg)<3e-15*basis.OHminus_X_v0_kg,"Shared OHminus ground mass across references");
    const auto kinetic=[&](const CollisionMomentum& p,double m) {double p2=0;for (auto x:p)p2+=x*x;return p2/(m*(std::sqrt(1+p2/(m*m*c*c))+1));};
    for (const double E:{9.,12.,20.,100.,977.7}) for (const double w:{.125,1.,32.}) for (const double angle:{0.,.1,.5,.9,.999999}) {
        const auto p=conditional_A1B1_dissociation_products(data,"A1B1_fixed_loss_dipole_ground_v1",E,w,M,H,beam,angle,.31,{0,-1,0});
        const double K=E*e,p0=std::sqrt(K*(K+2*me*c*c))/c;
        for (int d=0;d<3;++d)check(std::abs(p.electron_momentum_kg_m_s[d]+p.H_momentum_kg_m_s[d]+p.OH_momentum_kg_m_s[d]-p0*beam[d])<5e-12*p0,"Three-product momentum closure");
        check(std::abs(kinetic(p.electron_momentum_kg_m_s,me)-p.electron_kinetic_J)<5e-12*K,"Electron on shell");
        check(std::abs(kinetic(p.H_momentum_kg_m_s,H)-p.H_kinetic_J)<5e-12*K,"H on shell");
        check(std::abs(kinetic(p.OH_momentum_kg_m_s,p.OH_state_mass_kg)-p.OH_kinetic_J)<5e-12*K,"OH on shell");
        check(std::abs(p.electron_kinetic_J+p.H_kinetic_J+p.OH_kinetic_J+p.chemical_reference_gain_J-K)<5e-12*K,"Kinetic/reference closure without double excitation heat");
        check(p.physical_weight_each==w&&p.internal_gain_J==0,"Matched weights and explicit ground endpoint");
        check(p.cross_section_m2==data.observable_value_SI("H2O:electronic_A1B1",E),"Excitation rate used once");
        check(p.intermediate_excitation_J==7.49*e&&p.chemical_reference_gain_J==5.1*e,"Frozen energy bindings");
        check(p.electron_CM_cosine>=-1&&p.electron_CM_cosine<=1,"Dipole angular support");
        if (angle==.5&&E>=100)check(p.electron_CM_cosine>.9,"Forward-peaked high-energy dipole endpoint");
    }
    const auto event=[&](std::string model,double E) {(void)conditional_A1B1_dissociation_products(data,model,E,1,M,H,beam,.5,.5,{1,0,0});};
    rejects([&]{event("",20);});rejects([&]{event("A1B1_fixed_loss_dipole_ground_v1",8.9);});
    rejects([&]{event("A1B1_fixed_loss_dipole_ground_v1",978);});rejects([&]{event("A1B1_fixed_loss_dipole_ground_v1",8084.47);});
    rejects([&]{data.require_MCC_event_kernel("H2O:neutral_OH_yield","A1B1_fixed_loss_dipole_ground_v1",20);});
    rejects([&]{data.require_MCC_event_kernel("H2O:munoz2007:recommended_inelastic","A1B1_fixed_loss_dipole_ground_v1",20);});
    std::cout<<"{\"passed\":true,\"checks\":"<<checks<<",\"physical_time_advanced\":0,\"GPU_used\":false}\n";return 0;
}catch(const std::exception& e) {std::cerr<<e.what()<<'\n';return 1;}}
