#include "raikou/spatial_kinetics.h"
#include "raikou/spatial_mesh.h"
#include <algorithm>
#include <cmath>
#include <iostream>
#include <stdexcept>

namespace {
using namespace raikou::kinetics;
void check(bool value,const std::string& message){if(!value)throw std::runtime_error(message);}
bool near(double a,double b,double tolerance){return std::abs(a-b)<=tolerance*std::max({std::abs(a),std::abs(b),1e-100});}
double difference(const std::vector<double>& a,const std::vector<double>& b){double error=0,scale=0;check(a.size()==b.size(),"vector dimensions");for(std::size_t i=0;i<a.size();++i){error=std::max(error,std::abs(a[i]-b[i]));scale=std::max(scale,std::abs(a[i]));}return error/std::max(scale,1e-300);}
raikou::chemistry::Mechanism mechanism(){
    raikou::chemistry::Mechanism value;value.id="manufactured elastic gas";
    value.species={{"X","gas",{{"X",1}},0,28*1.66053906660e-27,true},{"e","gas",{},-1,9.1093837015e-31,true}};return value;
}
ElectronCoupling coupling(const EedfGrid& grid,double sigma=1e-19){
    ElectronCoupling value;value.grid=grid;value.strict_event_mapping=true;value.conditions.ion_fraction=0;
    CollisionProcess p;p.kind=CollisionKind::Elastic;p.target="X";p.label="elastic";p.mass_ratio=9.1093837015e-31/(28*1.66053906660e-27);
    p.energy_ev={0,1000};p.cross_section_m2={sigma,sigma};value.processes={p};return value;
}
SpatialKineticCell cell(const raikou::chemistry::Mechanism& chemistry,const ElectronCoupling& kinetic,double heavy,double electron,Vector3 field={}){
    SpatialKineticCell value;value.mechanism=&chemistry;value.coupling=&kinetic;value.candidate_state.densities_m3={heavy,electron};value.electric_field_V_m=field;return value;
}
void local_parity(){
    const EedfGrid grid{.cells=16,.max_energy_ev=15,.power=2,.legendre_terms=3};
    const auto chemistry=mechanism();const auto kinetic=coupling(grid);
    const auto initial=spherical_from_legendre(maxwellian_eedf(1e8,1,grid));
    const auto trial=cell(chemistry,kinetic,1e20,1e8,{-3,2,-6});
    SpatialKineticOptions options;options.grid=grid;options.dt_s=1e-10;options.relative_tolerance=1e-10;
    auto conditions=coupled_eedf_conditions(chemistry,trial.candidate_state,trial.environment,std::sqrt(49.0),kinetic);
    const auto reference=advance_spherical_eedf(kinetic.processes,conditions,initial,trial.electric_field_V_m,options.dt_s);
    const auto result=advance_spatial_kinetics({{1},{}},std::vector{trial},std::vector{initial},options);
    check(difference(reference.state.density_modes,result.states[0].density_modes)<1e-8,"one-cell mesh kinetic elimination agrees with the full angular collision/field solve");
    check(result.feedback[0].collision_event_mapping_complete,"mesh feedback retains strict channel mapping");
    check(near(result.feedback[0].environment.electron_temperature_eV,2.0/3*result.states[0].mean_energy_ev(),1e-14),"full angular thermal closure uses the owned discrete electron energy moment");
    check(near(result.feedback[0].conditions.gas_density_m3,1e20,1e-14),"heavy trial inventory owns collision target density");
}
std::vector<SphericalEedfState> spatial_trial(bool mpi,bool cuda=false){
    using namespace raikou::backend;
    const EedfGrid grid{.cells=16,.max_energy_ev=15,.power=2,.legendre_terms=3};
    const auto chemistry=mechanism();const auto kinetic=coupling(grid);
    KineticMesh mesh{{1e-3,1.4e-3,0.8e-3},{{0,1,{1,0,0},1},{1,2,{0,1,0},1},{2,0,{0,0,1},1}}};
    std::vector<SphericalEedfState> old;
    std::vector<SpatialKineticCell> cells;
    for(std::size_t c=0;c<3;++c){old.push_back(spherical_from_legendre(maxwellian_eedf(1e8*(1+0.3*c),1+0.2*c,grid)));cells.push_back(cell(chemistry,kinetic,1e20*(1+0.2*c),old.back().electron_density_m3(),{-2,3,4}));}
    SpatialKineticOptions options;options.grid=grid;options.dt_s=3*kinetic_streaming_rhs(mesh,old).maximum_explicit_step_s;options.relative_tolerance=2e-9;options.execution.mpi=mpi;options.execution.threads=2;
    options.execution.device=cuda?"cuda":"cpu";
    SpatialKineticResult result;
    RowPartition owned{3,0,3};
    if(mpi){
        owned=distributed_partition(3,options.execution);
        const auto begin=static_cast<std::size_t>(owned.row_begin),end=begin+owned.local_rows;
        result=advance_distributed_spatial_kinetics(mesh,owned,std::span(cells).subspan(begin,end-begin),std::span(old).subspan(begin,end-begin),options);
        check(result.local_unknowns==owned.local_rows*144,"MPI kinetic solve stores only owned distributions");
        check(result.halo_unknowns<3*144 || owned.local_rows==0,"MPI kinetic halo contains only adjacent distributions");
    }else result=advance_spatial_kinetics(mesh,cells,old,options);
    std::vector<double> local;
    for(const auto& state:result.states)local.insert(local.end(),state.density_modes.begin(),state.density_modes.end());
    DistributedHalo gather({3*144,owned.row_begin*144,owned.local_rows*144},{},options.execution);
    const auto all=gather_distributed(gather,local);
    std::vector<SphericalEedfState> complete=old;
    for(std::size_t c=0;c<3;++c)complete[c].density_modes.assign(all.begin()+static_cast<std::ptrdiff_t>(c*144),all.begin()+static_cast<std::ptrdiff_t>((c+1)*144));
    double before=0,after=0;
    for(std::size_t c=0;c<3;++c){before+=mesh.cell_volumes_m3[c]*old[c].electron_density_m3();after+=mesh.cell_volumes_m3[c]*complete[c].electron_density_m3();}
    check(near(before,after,2e-10),"implicit collision plus streaming conserves total electron number above explicit CFL");
    const auto stream=kinetic_streaming_rhs(mesh,complete);
    double residual=0,scale=0;
    for(std::size_t c=0;c<3;++c){
        const auto conditions=coupled_eedf_conditions(chemistry,cells[c].candidate_state,cells[c].environment,std::sqrt(29.0),kinetic);
        const auto collision=evaluate_spherical_eedf(kinetic.processes,conditions,complete[c],cells[c].electric_field_V_m);
        for(std::size_t q=0;q<144;++q){const double change=complete[c].density_modes[q]-old[c].density_modes[q];residual=std::max(residual,std::abs(change-options.dt_s*(collision.density_mode_rates[q]+stream.density_mode_rates[c][q])));scale=std::max(scale,std::abs(old[c].density_modes[q]));}
    }
    check(residual<3e-9*scale,"collision and spatial transport satisfy one backward-Euler block without splitting");
    check(result.nonlinear_residual<3e-9,"mesh kinetic nonlinear residual is certified");
    check(result.linear_device==(cuda?"cuda":"cpu")&&result.krylov_iterations>0,"requested mesh kinetic device executes the implicit linear solve");
    return complete;
}
void cylindrical_equilibrium(){
    const EedfGrid grid{.cells=16,.max_energy_ev=15,.power=2,.legendre_terms=4};
    const auto chemistry=mechanism();const auto kinetic=coupling(grid,0);
    const auto initial=spherical_from_legendre(maxwellian_eedf(1e8,1,grid));
    const double pi=std::acos(-1.0);
    KineticMesh mesh{{3*pi},{{0,std::numeric_limits<std::size_t>::max(),{1,0,0},4*pi,KineticWall::PrescribedIncoming,initial},
        {0,std::numeric_limits<std::size_t>::max(),{-1,0,0},2*pi,KineticWall::PrescribedIncoming,initial},
        {0,std::numeric_limits<std::size_t>::max(),{0,0,1},3*pi,KineticWall::PrescribedIncoming,initial},
        {0,std::numeric_limits<std::size_t>::max(),{0,0,-1},3*pi,KineticWall::PrescribedIncoming,initial}}};
    SpatialKineticOptions options;options.grid=grid;options.dt_s=1e-8;options.inverse_radius_m1={2.0/3};
    const auto result=advance_spatial_kinetics(mesh,std::vector{cell(chemistry,kinetic,1e20,1e8)},std::vector{initial},options);
    check(difference(initial.density_modes,result.states[0].density_modes)<1e-12,"implicit cylindrical angular geometry cancels radial FV streaming for uniform isotropic gas");
}
void inactive_contacts(){
    raikou::spatial::mesh::Geometry geometry;geometry.volume={1,1};
    raikou::spatial::mesh::Face face;face.a=0;face.b=1;face.area=1;face.normal={1,0,0};geometry.faces={face};
    bool refused=false;
    try{(void)make_kinetic_mesh(geometry,std::vector{1.0,0.0},std::vector{1.0},{});}catch(const std::invalid_argument&){refused=true;}
    check(refused,"gas/liquid contact requires an authored kinetic wall");
    const auto mesh=make_kinetic_mesh(geometry,std::vector{1.0,0.0},std::vector{1.0},{},{{0,{KineticWall::Specular,{}}}});
    check(mesh.faces.size()==1&&mesh.faces[0].right==std::numeric_limits<std::size_t>::max(),"gas/liquid contact becomes a kinetic wall");
}
}
int main(int argc,char** argv){
    try{
        const std::string mode=argc>1?argv[1]:"";
        const bool mpi=mode=="--mpi"||mode=="--mpi-cuda",cuda=mode=="--cuda"||mode=="--mpi-cuda";
        raikou::backend::Runtime runtime(mpi);
        if(cuda&&!raikou::backend::cuda_available())return 77;
        local_parity();inactive_contacts();cylindrical_equilibrium();const auto result=spatial_trial(mpi,cuda);
        if(mpi||cuda){const auto reference=spatial_trial(false);for(std::size_t c=0;c<result.size();++c)check(difference(result[c].density_modes,reference[c].density_modes)<2e-9,"MPI/CUDA kinetic physical result equals serial CPU");}
        std::cout<<"implicit spatial kinetic qualification passed\n";return 0;
    }catch(const std::exception& error){std::cerr<<error.what()<<'\n';return 1;}
}
