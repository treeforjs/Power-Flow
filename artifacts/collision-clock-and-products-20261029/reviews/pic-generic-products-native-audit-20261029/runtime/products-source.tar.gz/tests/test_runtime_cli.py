"""Public native CLI contracts, including MPI's single stdin stream."""
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

CLI = str(Path(sys.argv.pop(1)).resolve())
MPI = sys.argv[1:]
sys.argv[1:] = []


class RuntimeCLI(unittest.TestCase):
    def run_request(self, operation, request, options=()):
        command = [*MPI, CLI, operation, "--input", "-", *options]
        if MPI:
            command.append("--mpi")
        return subprocess.run(command, input=json.dumps(request), text=True,
                              capture_output=True, timeout=30)

    def test_capabilities(self):
        result = self.run_request("capabilities", {})
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("coupled.advance", json.loads(result.stdout)["operations"])

    def test_linear_solve_stdin(self):
        result = self.run_request("linear.solve", {
            "matrix": {"rows": 2, "offsets": [0, 2, 4], "columns": [0, 1, 0, 1],
                       "values": [2, -1, -1, 2]}, "rhs": [1, 1]})
        self.assertEqual(result.returncode, 0, result.stderr)
        solution = json.loads(result.stdout)
        self.assertTrue(solution["converged"])
        for value in solution["solution"]:
            self.assertAlmostEqual(value, 1)

    def test_nonconvergence_is_not_success(self):
        result = self.run_request("linear.solve", {
            "matrix": {"rows": 1, "offsets": [0, 1], "columns": [0], "values": [0]},
            "rhs": [1]})
        self.assertNotEqual(result.returncode, 0)
        self.assertFalse(json.loads(result.stdout)["converged"])

    def test_nested_execution_settings_are_preserved(self):
        request = {
            "mechanism": {"id": "cli-execution", "species": [{"id": "H", "elements": {"H": 1}}], "reactions": []},
            "state": {"densities_m3": [1]}, "dt_s": 1e-6,
            "options": {"execution": {"device": "cpu", "threads": 2, "tolerance": 1e-12}},
        }
        result = self.run_request("chemistry.advance", request)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout)["execution"]["threads"], 2)
        # An explicit top-level object still replaces nested settings.
        request["options"]["execution"]["device"] = "unsupported-device"
        request["execution"] = {"device": "cpu", "threads": 3}
        result = self.run_request("chemistry.advance", request)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout)["execution"]["threads"], 3)

    def test_nested_execution_errors_are_not_overridden(self):
        chemistry = {
            "mechanism": {"id": "cli-execution-errors", "species": [{"id": "H", "elements": {"H": 1}}], "reactions": []},
            "state": {"densities_m3": [1]}, "dt_s": 1e-6,
            "options": {"execution": {"device": "unsupported-device"}},
        }
        electrons = {
            "processes": [{"kind": "elastic", "target": "X", "mass_ratio": 0.00002,
                           "energy_ev": [0, 1000], "cross_section_m2": [1e-19, 1e-19]}],
            "conditions": {"fractions": {"X": 1}, "gas_density_m3": 1e20,
                           "execution": {"device": "unsupported-device"}},
            "grid": {"cells": 16, "max_energy_ev": 10, "legendre_terms": 2},
        }
        root = Path(__file__).resolve().parents[1]
        coupled = json.loads((root / "examples/coupled_cell.json").read_text())
        coupled.pop("execution")
        coupled["electron_closure"]["execution"] = {"device": "unsupported-device"}
        cases = [("chemistry.advance", chemistry), ("eedf.solve", electrons), ("coupled.advance", coupled)]
        for operation, request in cases:
            with self.subTest(operation=operation):
                result = self.run_request(operation, request)
                self.assertNotEqual(result.returncode, 0, result.stdout)
                self.assertRegex((result.stderr + result.stdout).lower(), r"device|backend")

    def test_parse_error_terminates_all_ranks(self):
        command = [*MPI, CLI, "linear.solve", "--input", "-"]
        if MPI:
            command.append("--mpi")
        result = subprocess.run(command, input="{broken", text=True,
                                capture_output=True, timeout=30)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("parse", result.stderr.lower())

    @unittest.skipUnless(MPI, "requires an MPI launcher")
    def test_asymmetric_decoding_terminates_all_ranks(self):
        ranks = json.loads(self.run_request("capabilities", {}).stdout)["mpi_size"]
        linear = {"matrix": {"rows": 1, "offsets": [0, 1], "columns": [0], "values": [1]}, "rhs": [1]}
        batch = {"jobs": [{"operation": "capabilities", "request": {}}], "execution": {"threads": 2}}
        chemistry = {
            "mechanism": {"id": "cli-preflight", "species": [{"id": "H", "elements": {"H": 1}}], "reactions": []},
            "state": {"densities_m3": [1]}, "dt_s": 1e-6,
        }
        cases = [("linear.solve", linear, "matrix"), ("batch.execute", batch, "jobs"),
                 ("batch.execute", batch, "threads"), ("chemistry.advance", chemistry, "device")]
        with tempfile.TemporaryDirectory(prefix="raikou-cli-preflight-") as folder:
            prefix = str(Path(folder) / "request")
            for operation, valid, damage in cases:
                with self.subTest(operation=operation, damage=damage):
                    for rank in range(ranks):
                        request = json.loads(json.dumps(valid))
                        if rank + 1 == ranks:
                            if damage == "matrix":
                                request["matrix"]["rows"] = "bad"
                            elif damage == "jobs":
                                request.pop("jobs")
                            else:
                                request.setdefault("execution", {})[damage] = "bad" if damage == "threads" else 99
                        Path(f"{prefix}.{rank}.json").write_text(json.dumps(request), encoding="utf-8")
                    result = subprocess.run([*MPI, CLI, operation, "--rank-input", prefix, "--mpi"],
                                            text=True, capture_output=True, timeout=30)
                    self.assertNotEqual(result.returncode, 0, result.stdout)
                    self.assertIn("raikou:", result.stderr)
                    recovery = self.run_request(operation, valid)
                    self.assertEqual(recovery.returncode, 0, recovery.stderr)

    def test_owned_rank_files_and_restart(self):
        request = {
            "mechanism": {"id": "cli-owned", "species": [{"id": "H", "elements": {"H": 1}}], "reactions": []},
            "mesh": {"dimension": 2, "shape": [3, 1, 1], "extent_m": [1, 1, 1]},
            "initial_densities_m3": {"H": 1}, "transport": {},
            "boundaries": {"xmin": {"kind": "electrode", "potential_V": 0},
                           "xmax": {"kind": "electrode", "potential_V": 1}},
            "time": {"end_time_s": 0.001, "time_step_s": 0.001, "adaptive": False},
        }
        if MPI:
            refused = self.run_request("spatial.solve_distributed", request)
            self.assertNotEqual(refused.returncode, 0)
            self.assertIn("--rank-output", refused.stderr)
        with tempfile.TemporaryDirectory(prefix="raikou-cli-ranks-") as folder:
            first = str(Path(folder) / "first")
            completed = self.run_request("spatial.solve_distributed", request, ("--rank-output", first))
            self.assertEqual(completed.returncode, 0, completed.stderr)
            manifest = json.loads(completed.stdout)
            states = [json.loads(Path(path).read_text()) for path in manifest["rank_outputs"]]
            self.assertEqual(sum(state["cell_count"] for state in states), 3)
            self.assertTrue(all(state["state"]["representation"] == "owned_cell_dof_v1" for state in states))
            second = str(Path(folder) / "second")
            request["time"]["end_time_s"] = 0.002
            resumed = self.run_request("spatial.solve_distributed", request,
                                       ("--rank-output", second, "--checkpoint-prefix", first))
            self.assertEqual(resumed.returncode, 0, resumed.stderr)
            outputs = json.loads(resumed.stdout)["rank_outputs"]
            for path in outputs:
                self.assertAlmostEqual(json.loads(Path(path).read_text())["time_s"], 0.002)
            local = str(Path(folder) / "input")
            request["time"]["end_time_s"] = 0.003
            for rank, path in enumerate(outputs):
                rank_request = dict(request, checkpoint=json.loads(Path(path).read_text())["checkpoint"])
                Path(f"{local}.{rank}.json").write_text(json.dumps(rank_request))
            command = [*MPI, CLI, "spatial.solve_distributed", "--rank-input", local,
                       "--rank-output", str(Path(folder) / "third")]
            if MPI:
                command.append("--mpi")
            completed = subprocess.run(command, text=True, capture_output=True, timeout=30)
            self.assertEqual(completed.returncode, 0, completed.stderr)
            Path(f"{local}.0.json").write_text("{broken")
            failed = subprocess.run(command, text=True, capture_output=True, timeout=30)
            self.assertNotEqual(failed.returncode, 0)
            self.assertIn("parse", failed.stderr.lower())

    def test_shipped_examples(self):
        root = Path(__file__).resolve().parents[1]
        cases = [("chemistry.advance", "examples/aqueous_reference_advance.json"),
                 ("coupled.advance", "examples/coupled_cell.json"),
                 ("spatial.solve", "examples/manufactured/spatial_2d.json"),
                 ("spatial.solve", "examples/manufactured/spatial_3d.json")]
        for operation, path in cases:
            with self.subTest(path=path):
                request = json.loads((root / path).read_text(encoding="utf-8"))
                result = self.run_request(operation, request)
                self.assertEqual(result.returncode, 0, result.stderr + result.stdout[-1000:])
                response = json.loads(result.stdout)
                self.assertTrue(response.get("success", True), response.get("message"))
                if operation == "coupled.advance":
                    self.assertLessEqual(response["nonlinear_residual"], 1)


if __name__ == "__main__":
    unittest.main()
