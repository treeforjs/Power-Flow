#include "raikou/chemistry_distributed.h"
#include "chemistry_audit_cases.h"
#include <algorithm>
#include <cmath>
#include <iostream>
#include <limits>
#include <stdexcept>
namespace {
using namespace raikou;
void require(bool ok, const std::string& message) { if (!ok) throw std::runtime_error(message); }
chemistry::Mechanism mechanism(std::size_t n) {
    chemistry::Mechanism m; m.id = "owned-ring";
    for (std::size_t i = 0; i < n; ++i) m.species.push_back({"X" + std::to_string(i), "gas", {{"X", 1}}, 0, 1e-26, true});
    for (std::size_t i = 0; i < n; ++i) {
        chemistry::Reaction r; r.id = "r" + std::to_string(i);
        r.reactants = {{i, 1}, {(i + 1) % n, 1}}; r.products = {{(i + 1) % n, 2}};
        r.rate.A = 0.7 + 0.01 * static_cast<double>(i);
        r.energy_eV_per_event["thermal"] = 1; r.check_energy_balance = true; r.external_energy_eV_per_event = 1;
        m.reactions.push_back(std::move(r));
    }
    return m;
}
void case_run(std::size_t n, const backend::ExecutionOptions& execution) {
    auto m = mechanism(n);
    chemistry::State full;
    for (std::size_t i = 0; i < n; ++i) full.densities_m3.push_back(1 + 0.2 * std::sin(static_cast<double>(i)));
    const auto p = backend::distributed_partition(n, execution);
    chemistry::DistributedState state{p, {full.densities_m3.begin() + static_cast<std::ptrdiff_t>(p.row_begin), full.densities_m3.begin() + static_cast<std::ptrdiff_t>(p.row_begin + p.local_rows)}};
    const auto eval = chemistry::evaluate_distributed(m, state, {}, execution);
    const auto reference = chemistry::evaluate(m, full);
    require(eval.production_rates_m3_s.size() == p.local_rows && eval.jacobian.local_rows() == p.local_rows, "CR retained global rows/state");
    require(eval.jacobian.values.size() <= 3 * p.local_rows, "CR allocated dense/global Jacobian");
    require(eval.ghost_species <= std::min<std::size_t>(n - p.local_rows, 2), "nearest-neighbour CR has unnecessary halo replication");
    for (std::size_t row = 0; row < p.local_rows; ++row) {
        const auto global = static_cast<std::size_t>(p.row_begin) + row;
        require(std::abs(eval.production_rates_m3_s[row] - reference.production_rates_m3_s[global]) < 1e-12, "owned CR production differs");
        std::vector<double> sparse(n);
        for (auto entry = eval.jacobian.offsets[row]; entry < eval.jacobian.offsets[row + 1]; ++entry) sparse[static_cast<std::size_t>(eval.jacobian.columns[entry])] += eval.jacobian.values[entry];
        for (std::size_t col = 0; col < n; ++col) require(std::abs(sparse[col] - reference.jacobian_row_major[global * n + col]) < 1e-12, "owned CR Jacobian differs");
    }
    require(std::abs(eval.energy_sources_W_m3.at("gas/thermal") / reference.energy_sources_W_m3.at("gas/thermal") - 1) < 1e-12, "reaction energy double counted across ranks");
    chemistry::AdvanceOptions options; options.relative_tolerance = 1e-4; options.absolute_tolerance_m3 = 1e-8; options.execution = execution;
    const auto advanced = chemistry::advance_distributed(m, state, {}, 0.01, options);
    require(advanced.success, "owned CR advance failed: " + advanced.message);
    auto serial_options = options; serial_options.execution = {};
    const auto serial = chemistry::advance(m, full, {}, 0.01, serial_options);
    require(serial.success, "serial reference failed");
    backend::DistributedHalo control(p, {}, execution);
    const auto gathered = backend::gather_distributed(control, advanced.state.densities_m3);
    double initial_sum = 0, final_sum = 0;
    for (std::size_t i = 0; i < n; ++i) {
        require(std::abs(gathered[i] - serial.state.densities_m3[i]) < 1e-9, "owned CR advance differs from serial Newton");
        initial_sum += full.densities_m3[i]; final_sum += gathered[i];
    }
    require(std::abs(initial_sum - final_sum) < 1e-9, "partitioned CR does not conserve species inventory");
    require(std::abs(advanced.integrated_energy_J_m3.at("gas/thermal") / serial.integrated_energy_J_m3.at("gas/thermal") - 1) < 1e-9, "partitioned integrated energy differs");
    const auto failed = [&](const chemistry::Mechanism& model, const chemistry::DistributedState& initial, const chemistry::Environment& env, const chemistry::AdvanceOptions& o) {
        const auto result = chemistry::advance_distributed(model, initial, env, 0.01, o);
        require(!result.success && result.advanced_time_s == 0 && result.integrated_energy_J_m3.empty(), "distributed CR failure committed partial state");
        require(result.state.densities_m3.size() == initial.densities_m3.size(), "failed CR changed local shape");
        for (std::size_t i = 0; i < initial.densities_m3.size(); ++i)
            require(result.state.densities_m3[i] == initial.densities_m3[i] || (std::isnan(result.state.densities_m3[i]) && std::isnan(initial.densities_m3[i])), "distributed CR rollback changed original density");
    };
    auto bad = state; if (control.rank() == control.ranks() - 1 && !bad.densities_m3.empty()) bad.densities_m3[0] = std::numeric_limits<double>::quiet_NaN();
    failed(m, bad, {}, options);
    auto environment = chemistry::Environment{}; if (control.rank() == 0) environment.gas_temperature_K = -1;
    failed(m, state, environment, options);
    auto bad_options = options; if (control.rank() == 0) bad_options.maximum_steps = 0;
    failed(m, state, {}, bad_options);
    bad_options = options; bad_options.maximum_steps = 1; bad_options.maximum_step_s = 0.001;
    failed(m, state, {}, bad_options); // at least one accepted step before rollback
    if (control.ranks() > 1) {
        auto different = m; if (control.rank() == 0) different.reactions[0].rate.A += 1;
        failed(different, state, {}, options);
        bad_options = options; if (control.rank() == 0) bad_options.relative_tolerance *= 2;
        failed(m, state, {}, bad_options);
        auto wrong_partition = state; if (control.rank() == 0) wrong_partition.partition.global_rows += 1;
        failed(m, wrong_partition, {}, options);
    }
    require(chemistry::advance_distributed(m, state, {}, 0.01, options).success, "CR collective context did not recover after failures");
}
}
int main(int argc, char** argv) {
    try {
        bool mpi = false, cuda = false;
        for (int i = 1; i < argc; ++i) { const std::string arg(argv[i]); mpi |= arg == "--mpi"; cuda |= arg == "--cuda"; }
        backend::Runtime runtime(mpi);
        if (cuda && !backend::cuda_available()) return 77;
        backend::ExecutionOptions execution; execution.mpi = mpi; execution.device = cuda ? "cuda" : "cpu"; execution.tolerance = 1e-11;
        chemistry_audit::minimum_steps([&](const chemistry::Mechanism& m,const chemistry::State& full,double interval,const chemistry::AdvanceOptions& settings){
            const auto partition=backend::distributed_partition(m.species.size(),execution);
            chemistry::DistributedState owned{partition,{full.densities_m3.begin()+static_cast<std::ptrdiff_t>(partition.row_begin),
                full.densities_m3.begin()+static_cast<std::ptrdiff_t>(partition.row_begin+partition.local_rows)}};
            auto options=settings;options.execution=execution;
            const auto advanced=chemistry::advance_distributed(m,owned,{},interval,options);
            backend::DistributedHalo control(partition,{},execution);
            chemistry::AdvanceResult result;result.success=advanced.success;result.accepted_steps=advanced.accepted_steps;
            result.rejected_steps=advanced.rejected_steps;result.advanced_time_s=advanced.advanced_time_s;
            result.state.densities_m3=backend::gather_distributed(control,advanced.state.densities_m3);
            result.integrated_energy_J_m3=advanced.integrated_energy_J_m3;
            return result;
        });
        chemistry_audit::geometry([&](const chemistry::Mechanism& m,const chemistry::State& full,const chemistry::Environment& environment){
            const auto partition=backend::distributed_partition(m.species.size(),execution);
            chemistry::DistributedState owned{partition,{full.densities_m3.begin()+static_cast<std::ptrdiff_t>(partition.row_begin),
                full.densities_m3.begin()+static_cast<std::ptrdiff_t>(partition.row_begin+partition.local_rows)}};
            const auto evaluated=chemistry::evaluate_distributed(m,owned,environment,execution);
            backend::DistributedHalo control(partition,{},execution);
            chemistry::Evaluation result;result.production_rates_m3_s=backend::gather_distributed(control,evaluated.production_rates_m3_s);
            std::vector<double> local_rows(partition.local_rows*m.species.size());
            for(std::size_t row=0;row<partition.local_rows;++row)
                for(auto entry=evaluated.jacobian.offsets[row];entry<evaluated.jacobian.offsets[row+1];++entry)
                    local_rows[row*m.species.size()+static_cast<std::size_t>(evaluated.jacobian.columns[entry])]=evaluated.jacobian.values[entry];
            const backend::RowPartition entries{partition.global_rows*m.species.size(),partition.row_begin*m.species.size(),local_rows.size()};
            backend::DistributedHalo row_control(entries,{},execution);
            result.jacobian_row_major=backend::gather_distributed(row_control,local_rows);
            result.energy_sources_W_m3=evaluated.energy_sources_W_m3;
            return result;
        });
        case_run(64, execution); case_run(2, execution);
        if (backend::mpi_rank() == 0) std::cout << "owned chemistry production/Jacobian, Newton, energy, conservation and rollback passed\n";
        return 0;
    } catch (const std::exception& exception) { std::cerr << exception.what() << '\n'; return 1; }
}
