#include "physics/collisional_radiative_model.h"
#include "physics/spark_breakdown_solver.h"
#include "physics/spectrometer_calibration.h"
#include "physics/zapdos_plasma_inverter.h"
#include "raikou/raikou.h"

#include <iostream>
#include <stdexcept>
#include <type_traits>

static_assert(std::is_same_v<quark::physics::CollisionalRadiativeModel,
                             raikou::CollisionalRadiativeModel>);
static_assert(std::is_same_v<quark::physics::SparkBreakdownSolver,
                             raikou::SparkBreakdownSolver>);
static_assert(std::is_same_v<quark::physics::SpectrometerCalibration,
                             raikou::SpectrometerCalibration>);
static_assert(std::is_same_v<quark::physics::ZapdosPlasmaInverter,
                             raikou::ZapdosPlasmaInverter>);

int main() {
    try {
        const quark::physics::CollisionalRadiativeModel legacy;
        const raikou::CollisionalRadiativeModel standalone;
        const raikou::CollisionalRadiativeModel::PlasmaState state;
        const auto old_result = legacy.evaluate(state);
        const auto new_result = standalone.evaluate(state);
        if (old_result.populations_m3 != new_result.populations_m3 ||
            old_result.lyman_alpha_radiance_W_m2_sr != new_result.lyman_alpha_radiance_W_m2_sr)
            throw std::runtime_error("Quark and standalone CR APIs disagree");

        const quark::physics::SpectrometerCalibration calibration;
        if (calibration.radiance_to_counts(1, 121.57, 1e-8) !=
            raikou::SpectrometerCalibration{}.radiance_to_counts(1, 121.57, 1e-8))
            throw std::runtime_error("Quark and standalone calibration APIs disagree");

        const auto old_spark = quark::physics::SparkBreakdownSolver::step_spark_discharge(
            {}, 5e-8, {});
        const auto new_spark = raikou::SparkBreakdownSolver::step_spark_discharge({}, 5e-8, {});
        if (old_spark.deposited_energy_J != new_spark.deposited_energy_J)
            throw std::runtime_error("Quark and standalone spark APIs disagree");

        quark::physics::ZapdosPlasmaInverter::GridConfig config;
        config.nx = 4;
        config.ny = 3;
        const quark::physics::ZapdosPlasmaInverter old_inverter(config);
        const raikou::ZapdosPlasmaInverter new_inverter(config);
        if (old_inverter.compute_dynamic_gap_resistance() !=
            new_inverter.compute_dynamic_gap_resistance())
            throw std::runtime_error("Quark and standalone inverter APIs disagree");
        std::cout << "Quark/Raikou compatibility tests passed\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << error.what() << '\n';
        return 1;
    }
}
