#include "raikou/h2o_two_body_attachment.h"
#include <functional>
#include <iostream>
int main(int argc,char** argv) {try {
    using namespace raikou::kinetics;
#ifndef RAIKOU_TEST_H2O_ATTACHMENT
#define RAIKOU_TEST_H2O_ATTACHMENT "data/collisions/h2o-gas-20261029-attachment.json"
#endif
    const auto data=StrictCollisionDataset::read(argc==2?argv[1]:RAIKOU_TEST_H2O_ATTACHMENT);
    int checks=0;const auto check=[&](bool okay,const char* why) {++checks;if (!okay)throw std::runtime_error(why);};
    const auto rejects=[&](const std::function<void()>& f) {bool bad=false;try {f();}catch(const std::exception&) {bad=true;}check(bad,"Unadmitted attachment accepted");};
    constexpr double e=1.602176634e-19,me=9.1093837139e-31,c=299792458.,u=1.66053906660e-27;
    const double M=18.01056468403*u,H=1.00782503223*u;
    const auto kinetic=[&](const CollisionMomentum& p,double m) {double p2=0;for (auto x:p)p2+=x*x;return p2/(m*(std::sqrt(1+p2/(m*m*c*c))+1));};
    const CollisionMomentum beam{.6,0,.8};
    const std::array<CollisionMomentum,3> axes{{{1,0,0},{0,-1,0},{-.6,0,-.8}}};
    for (const double E:{4.5,6.4,8.4,11.2,12.5}) for (const double w:{.125,1.,32.}) for (const auto& axis:axes) {
        const auto p=conditional_ohminus_ground_products(data,"OHminus_ground_isotropic_CM_v1",E,w,M,H,beam,axis);
        const double K=E*e,p0=std::sqrt(K*(K+2*me*c*c))/c;
        for (int d=0;d<3;++d)check(std::abs(p.anion_momentum_kg_m_s[d]+p.neutral_momentum_kg_m_s[d]-p0*beam[d])<3e-12*p0,"Momentum closure");
        check(std::abs(kinetic(p.anion_momentum_kg_m_s,p.anion_state_mass_kg)-p.anion_kinetic_J)<2e-12*K,"OHminus on shell");
        check(std::abs(kinetic(p.neutral_momentum_kg_m_s,H)-p.neutral_kinetic_J)<2e-12*K,"H on shell");
        check(std::abs(p.anion_kinetic_J+p.neutral_kinetic_J+p.chemical_reference_gain_J-K)<2e-12*K,"Reference/kinetic closure");
        check(p.physical_weight_each==w&&p.internal_gain_J==0,"Matched weights and explicit ground-state endpoint");
        check(p.cross_section_m2==data.observable_value_SI("H2O:attachment_yield:OHminus",E),"Frozen rate preserved");
        check(p.neutral_state_mass_kg==H,"Host state mass basis retained");
    }
    const auto event=[&](std::string model,double E,double w,CollisionMomentum b) {(void)conditional_ohminus_ground_products(data,model,E,w,M,H,b,axes[0]);};
    rejects([&]{event("",6.4,1,beam);});rejects([&]{event("OHminus_ground_isotropic_CM_v1",4.4,1,beam);});
    rejects([&]{event("OHminus_ground_isotropic_CM_v1",12.6,1,beam);});rejects([&]{event("OHminus_ground_isotropic_CM_v1",8084.47,1,beam);});
    rejects([&]{event("OHminus_ground_isotropic_CM_v1",6.4,-1,beam);});rejects([&]{event("OHminus_ground_isotropic_CM_v1",6.4,1,{1,1,0});});
    std::cout<<"{\"passed\":true,\"checks\":"<<checks<<",\"physical_time_advanced\":0,\"GPU_used\":false}\n";return 0;
}catch(const std::exception& e) {std::cerr<<e.what()<<'\n';return 1;}}
