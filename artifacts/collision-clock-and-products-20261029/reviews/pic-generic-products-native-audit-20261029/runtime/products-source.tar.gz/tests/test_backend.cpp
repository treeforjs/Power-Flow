#include "raikou/backend.h"
#include "raikou/runtime.h"
#include <array>
#include <cmath>
#include <iostream>
#include <limits>
#include <stdexcept>
namespace {
template<class Function> void rejects(Function action,const std::string& message) {
    bool rejected=false;
    try{action();}catch(const std::exception&){rejected=true;}
    if(!rejected)throw std::runtime_error(message);
}
}
int main(int argc,char** argv) {
    try {
        bool mpi=false,cuda=false;
        for(int i=1;i<argc;++i) { const std::string arg=argv[i];mpi|=arg=="--mpi";cuda|=arg=="--cuda"; }
        raikou::backend::Runtime runtime(mpi);
        const auto shared=raikou::backend::broadcast_json(raikou::backend::mpi_rank()==0?
            raikou::Json{{"request",{1,2,3}}}:raikou::Json::object(),0,
            raikou::backend::ExecutionOptions{.mpi=mpi});
        if(shared.at("request").size()!=3)throw std::runtime_error("MPI JSON input distribution failed");
        if(cuda && !raikou::backend::cuda_available())return 77;
        constexpr std::size_t n=128;
        raikou::backend::CsrMatrix a;a.rows=n;a.offsets.push_back(0);
        for(std::size_t i=0;i<n;++i) {
            if(i){a.columns.push_back(static_cast<int>(i-1));a.values.push_back(-1);}
            a.columns.push_back(static_cast<int>(i));a.values.push_back(3);
            if(i+1<n){a.columns.push_back(static_cast<int>(i+1));a.values.push_back(-1);}
            a.offsets.push_back(a.values.size());
        }
        std::vector<double> exact(n);for(std::size_t i=0;i<n;++i)exact[i]=std::sin(static_cast<double>(i+1)*0.03);
        raikou::backend::ExecutionOptions o;o.mpi=mpi;o.device=cuda?"cuda":"cpu";o.threads=4;
        const auto b=raikou::backend::csr_multiply(a,exact,o);
        const auto solved=raikou::backend::solve_csr(a,b,o);
        if(!solved.converged)throw std::runtime_error("FGMRES did not converge");
        for(std::size_t i=0;i<n;++i)if(std::abs(exact[i]-solved.solution[i])>1e-8)throw std::runtime_error("linear solution mismatch");
        // Retained operators own their matrix and can safely serve concurrent
        // independent CPU/CUDA requests (MPI callbacks remain collective).
        auto local_options=o;local_options.mpi=false;
        auto retained_matrix=a;
        auto retained=raikou::backend::make_csr_operator(retained_matrix,local_options);
        retained_matrix.values.assign(retained_matrix.values.size(),0.0);
        raikou::backend::parallel_for(64,4,[&](std::size_t item){
            auto x=exact;const double factor=static_cast<double>(item+1);
            for(auto& value:x)value*=factor;
            const auto y=retained(x);
            for(std::size_t row=0;row<n;++row)
                if(std::abs(y[row]-factor*b[row])>1e-8)throw std::runtime_error("concurrent retained operator mismatch");
        });
        auto invalid=a;invalid.offsets[1]=invalid.values.size()+1;
        rejects([&]{invalid.validate();},"out-of-buffer intermediate CSR offset admitted");
        const raikou::backend::CsrMatrix identity{2,{0,1,2},{0,1},{1.0,1.0}};
        for(const double scale:{1e200,1e-200}) {
            const std::vector<double> rhs{scale,-2.0*scale};
            const auto result=raikou::backend::solve_csr(identity,rhs,o);
            if(!result.converged || std::abs(result.solution[0]/scale-1.0)>1e-8 ||
               std::abs(result.solution[1]/scale+2.0)>1e-8)throw std::runtime_error("scaled norm produced false convergence");
        }
        auto serial_options=o;serial_options.mpi=false;serial_options.device="cpu";
        for(const auto& sample:{std::array<double,3>{1.,1e-315,1e-315},{1e-301,1e-200,1e101},{1e-309,1e-200,1e109}}){
            const raikou::backend::CsrMatrix scalar{1,{0,1},{0},{sample[0]}};
            const auto result=raikou::backend::solve_csr(scalar,std::array<double,1>{sample[1]},serial_options);
            if(!result.converged||!std::isfinite(result.solution[0])||std::abs(result.solution[0]/sample[2]-1)>1e-8||
                result.residual/std::abs(sample[1])>serial_options.tolerance)
                throw std::runtime_error("CPU relative convergence or tiny projected pivot lost a finite solution");
        }
        const raikou::backend::CsrMatrix small_rotation{2,{0,1,2},{1,0},{-1e-40,1e-40}};
        const auto rotated=raikou::backend::solve_csr(small_rotation,std::array<double,2>{1e-40,2e-40},serial_options);
        if(!rotated.converged||std::abs(rotated.solution[0]-2)>1e-8||std::abs(rotated.solution[1]+1)>1e-8)
            throw std::runtime_error("absolute Arnoldi breakdown discarded a small nonsingular operator");
        const auto zero=raikou::backend::solve_csr(identity,std::array<double,2>{0,0},serial_options);
        if(!zero.converged||zero.residual!=0||zero.solution!=std::vector<double>({0,0}))throw std::runtime_error("zero RHS changed behavior");
        auto bad_rhs=exact;bad_rhs[0]=std::numeric_limits<double>::quiet_NaN();
        rejects([&]{static_cast<void>(raikou::backend::csr_multiply(a,bad_rhs,local_options));},"non-finite CSR vector admitted");
        if(mpi && raikou::backend::mpi_size()>1) {
            const int rank=raikou::backend::mpi_rank();
            auto rank_matrix=a;
            if(rank==0)rank_matrix.offsets[1]=rank_matrix.values.size()+1;
            rejects([&]{static_cast<void>(raikou::backend::solve_csr(rank_matrix,b,o));},"one-rank bad CSR failed to propagate");
            rank_matrix=a;if(rank==0)rank_matrix.values[0]+=1.0;
            rejects([&]{static_cast<void>(raikou::backend::solve_csr(rank_matrix,b,o));},"differing replicated matrices admitted");
            auto rank_rhs=b;if(rank==0)rank_rhs[0]=std::numeric_limits<double>::quiet_NaN();
            rejects([&]{static_cast<void>(raikou::backend::solve_csr(a,rank_rhs,o));},"one-rank bad RHS failed to propagate");
            auto rank_options=o;if(rank==0)rank_options.restart+=1;
            rejects([&]{static_cast<void>(raikou::backend::solve_csr(a,b,rank_options));},"different Krylov control flow admitted");
            auto collective_operator=raikou::backend::make_csr_operator(a,o);
            auto rank_vector=exact;if(rank==0)rank_vector.pop_back();
            rejects([&]{static_cast<void>(collective_operator(rank_vector));},"operator vector failure failed to propagate");
            rank_options=o;if(rank==0)rank_options.device="invalid";
            rejects([&]{static_cast<void>(raikou::backend::solve_csr(a,b,rank_options));},"one-rank device failure failed to propagate");
        }
        bool propagated=false;
        try{raikou::backend::parallel_for(100,4,[](std::size_t i){if(i==7)throw std::runtime_error("worker failure");});}
        catch(const std::runtime_error&){propagated=true;}
        if(!propagated)throw std::runtime_error("worker exception was lost");
        const auto tasks=raikou::backend::map_jobs(raikou::Json::array({1,2,3,4,5}),[](const raikou::Json& value){
            const auto nvalue=value.get<int>();return raikou::Json(nvalue*nvalue);
        },raikou::backend::ExecutionOptions{.device="cpu",.threads=4,.mpi=mpi});
        for(std::size_t i=0;i<5;++i)
            if(tasks.at("results").at(i).at("result").get<std::size_t>()!=(i+1)*(i+1))
                throw std::runtime_error("MPI/thread task order or result mismatch");
        const auto failed_jobs=raikou::backend::map_jobs(raikou::Json::array({0,1,2}),[](const raikou::Json& value){
            if(value.get<int>()==1)throw std::runtime_error("manufactured job failure");
            return value;
        },raikou::backend::ExecutionOptions{.device="cpu",.threads=4,.mpi=mpi});
        if(failed_jobs.at("success").get<bool>() || failed_jobs.at("results").at(1).at("ok").get<bool>() ||
           failed_jobs.at("results").at(2).at("result")!=2)throw std::runtime_error("batch failure hid independent results");
        const auto forbidden_mpi=raikou::backend::map_jobs(raikou::Json::array({0}),[&](const raikou::Json&){
            auto collective=o;collective.mpi=true;
            return raikou::Json(raikou::backend::solve_csr(identity,std::vector<double>{1.0,2.0},collective).converged);
        },raikou::backend::ExecutionOptions{.device="cpu",.threads=4,.mpi=mpi});
        if(forbidden_mpi.at("success").get<bool>())throw std::runtime_error("batch callback reached MPI backend");
        const auto reported_failure=raikou::backend::map_jobs(raikou::Json::array({0}),[](const raikou::Json&){
            return raikou::Json{{"success",false},{"message","manufactured failed solve"}};
        });
        if(reported_failure.at("success").get<bool>())throw std::runtime_error("unsuccessful solver was reported as a successful batch");
        const auto nested_mpi=raikou::execute("batch.execute",{{"jobs",raikou::Json::array({
            {{"operation","chemistry.advance"},{"request",{{"options",{{"execution",{{"mpi",true}}}}}}}},
            {{"operation","spatial.solve"},{"request",{{"solver",{{"mpi",true}}}}}}
        })}});
        for(const auto& item:nested_mpi.at("results")) {
            if(item.at("ok").get<bool>() || item.at("error").get<std::string>().find("MPI collectives")==std::string::npos)
                throw std::runtime_error("nested batch MPI configuration bypassed validation");
        }
        const auto capability_jobs=raikou::backend::map_jobs(raikou::Json(std::vector<int>(64,0)),[](const raikou::Json&){
            return raikou::backend::capabilities_json();
        },raikou::backend::ExecutionOptions{.device="cpu",.threads=4,.mpi=mpi});
        if(!capability_jobs.at("success").get<bool>())throw std::runtime_error("threaded capability reports failed");
        for(const auto& item:capability_jobs.at("results"))
            if(item.at("result").at("mpi_initialized").get<bool>()!=mpi)
                throw std::runtime_error("threaded capability MPI snapshot is stale");
        raikou::backend::parallel_for(64,4,[](std::size_t){
            raikou::backend::parallel_for(32,4,[](std::size_t){});
        });
        if(raikou::backend::mpi_rank()==0)std::cout<<raikou::backend::capabilities_json().dump()<<'\n';
        return 0;
    } catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
}
