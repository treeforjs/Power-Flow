#include "raikou/spatial_kinetics.h"
#include <algorithm>
#include <cmath>
#include <iostream>
#include <numbers>
#include <stdexcept>
namespace {
using namespace raikou;
using namespace raikou::kinetics;
void check(bool value,const std::string& message){if(!value)throw std::runtime_error(message);}
constexpr double gamma_v=593096.9584768013;
struct Radial {
    EedfGrid grid;std::vector<double> edge,centre,mass,dual;
    explicit Radial(EedfGrid value):grid(value),edge(static_cast<std::size_t>(grid.cells+1)),centre(static_cast<std::size_t>(grid.cells)),mass(centre.size()),dual(centre.size(),0){
        for(std::size_t i=0;i<edge.size();++i)edge[i]=grid.max_energy_ev*std::pow(static_cast<double>(i)/grid.cells,grid.power);
        for(std::size_t i=0;i<centre.size();++i){centre[i]=.5*(edge[i]+edge[i+1]);mass[i]=2.0/3*(std::pow(edge[i+1],1.5)-std::pow(edge[i],1.5));}
        for(std::size_t i=0;i+1<centre.size();++i)dual[i]=2.0/3*(std::pow(centre[i+1],1.5)-std::pow(centre[i],1.5));
    }
};
double temporal_error(int steps,bool second){
    const EedfGrid grid{.cells=16,.max_energy_ev=5,.power=2,.legendre_terms=3};const Radial radial(grid);
    chemistry::Mechanism mechanism;mechanism.id="manufactured angular decay";mechanism.species={{"X","gas",{{"N",1}},0,28*1.66053906660e-27,true},{"e","gas",{},-1,9.1093837015e-31,true}};
    ElectronCoupling coupling;coupling.grid=grid;coupling.strict_event_mapping=true;
    CollisionProcess process;process.kind=CollisionKind::Elastic;process.target="X";process.label="isotropic elastic";process.mass_ratio=0;process.energy_ev={0,1000};process.cross_section_m2={1e-19,1e-19};coupling.processes={process};
    auto initial=spherical_from_legendre(maxwellian_eedf(1e8,1,grid));
    for(std::size_t i=0;i<16;++i)for(int m=-2;m<=2;++m)initial.density_modes[i*9+spherical_index(2,m)]=.01*(m+3)*initial.density_modes[i*9];
    SpatialKineticCell cell;cell.mechanism=&mechanism;cell.coupling=&coupling;cell.candidate_state.densities_m3={1e20,1e8};
    auto state=initial,older=initial;const double end=1e-7,dt=end/steps;
    for(int step=0;step<steps;++step){SpatialKineticOptions options;options.grid=grid;options.dt_s=dt;options.relative_tolerance=1e-11;if(second&&step>0){options.a0=1.5;options.a1=2;options.a2=.5;}
        const auto next=advance_spatial_kinetics({{1},{}},std::vector{cell},std::vector{state},options,second&&step>0?std::vector{older}:std::vector<SphericalEedfState>{});older=state;state=next.states[0];}
    double error=0,normalization=0;
    for(std::size_t i=0;i<16;++i){
        // Cell-averaged isotropic scattering frequency: N*sigma*<v> under
        // the native sqrt(E)dE number measure. This is independent of the solver.
        const double frequency=1e20*1e-19*gamma_v*(radial.edge[i+1]*radial.edge[i+1]-radial.edge[i]*radial.edge[i])/(2*radial.mass[i]);
        for(int m=-2;m<=2;++m){const auto q=i*9+spherical_index(2,m);const double exact=initial.density_modes[q]*std::exp(-frequency*end);error+=radial.mass[i]*std::pow(state.density_modes[q]-exact,2);normalization+=radial.mass[i]*std::pow(initial.density_modes[q],2);}
    }
    return std::sqrt(error/normalization);
}
double spatial_error(std::size_t cells){
    const EedfGrid grid{.cells=16,.max_energy_ev=5,.power=2,.legendre_terms=3};const Radial radial(grid);
    const auto shape=spherical_from_legendre(maxwellian_eedf(1e8,1,grid));const double dx=1.0/cells,k=2*std::numbers::pi,amplitude=.1;
    KineticMesh mesh;mesh.cell_volumes_m3.assign(cells,dx);std::vector<SphericalEedfState> states(cells,shape);
    for(std::size_t c=0;c<cells;++c){mesh.faces.push_back({c,(c+1)%cells,{1,0,0},1});const double factor=1+amplitude*std::sin(k*(c+.5)*dx);for(double& value:states[c].density_modes)value*=factor;}
    const auto rhs=kinetic_streaming_rhs(mesh,states,2);double error=0,normalization=0;
    for(std::size_t c=0;c<cells;++c)for(std::size_t i=0;i<16;++i)for(int l=0;l<3;++l)for(int m=-l;m<=l;++m){
        double exact=0;
        if(l==1&&m==1&&i+1<16){const double energy=radial.edge[i+1];const double radial_moment=energy*((radial.centre[i+1]-energy)*shape.density_modes[i*9]+(energy-radial.centre[i])*shape.density_modes[(i+1)*9])/radial.dual[i];
            exact=-gamma_v/std::sqrt(3.0)*amplitude*k*std::cos(k*(c+.5)*dx)*radial_moment;}
        const double measure=dx*(l%2==0?radial.mass[i]:radial.dual[i]);const auto q=i*9+spherical_index(l,m);
        error+=measure*std::pow(rhs.density_mode_rates[c][q]-exact,2);normalization+=measure*exact*exact;
    }
    return std::sqrt(error/normalization);
}
}
int main(){try{
    const double be8=temporal_error(8,false),be16=temporal_error(16,false),be32=temporal_error(32,false);
    const double bdf8=temporal_error(8,true),bdf16=temporal_error(16,true),bdf32=temporal_error(32,true);
    const double h16=spatial_error(16),h32=spatial_error(32),h64=spatial_error(64);
    std::cout<<"BE "<<be8<<' '<<be16<<' '<<be32<<"; BDF2 "<<bdf8<<' '<<bdf16<<' '<<bdf32<<"; spatial "<<h16<<' '<<h32<<' '<<h64<<'\n';
    check(be8>be16&&be16>be32&&be16/be32>1.8&&be16/be32<2.2,"full real-mode backward Euler converges at first order against exact angular relaxation");
    check(bdf8>bdf16&&bdf16>bdf32&&bdf16/bdf32>3.4&&bdf16/bdf32<4.6,"full real-mode BDF2 converges at second order against exact angular relaxation");
    check(h16>h32&&h32>h64&&h32/h64>1.8&&h32/h64<2.2,"conservative upwind spherical-harmonic streaming converges in space against an analytic periodic gradient");
    return 0;
}catch(const std::exception& error){std::cerr<<error.what()<<'\n';return 1;}}
