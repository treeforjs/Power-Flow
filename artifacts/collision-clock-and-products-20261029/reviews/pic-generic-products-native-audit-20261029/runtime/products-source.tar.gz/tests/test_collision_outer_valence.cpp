#include "raikou/h2o_outer_valence.h"
#include <functional>
#include <iostream>
#include <iomanip>
int main(int argc,char** argv) {try {
    using namespace raikou::kinetics;
#ifndef RAIKOU_TEST_H2O_OUTER3
#define RAIKOU_TEST_H2O_OUTER3 "data/collisions/h2o-gas-20261029-outer3.json"
#endif
    const auto data=StrictCollisionDataset::read(argc==2?argv[1]:RAIKOU_TEST_H2O_OUTER3);
    int checks=0;const auto check=[&](bool okay,const char* why) {++checks;if (!okay)throw std::runtime_error(why);};
    const auto rejects=[&](const std::function<void()>& f) {bool bad=false;try {f();}catch(const std::exception&) {bad=true;}check(bad,"Unadmitted outer3 event accepted");};
    constexpr double e=1.602176634e-19,me=9.1093837139e-31,c=299792458.,u=1.66053906660e-27;
    const double M=18.01056468403*u,H=1.00782503223*u;const CollisionMomentum beam{.6,0,.8};
    const std::array<CollisionMomentum,3> axes{{{1,0,0},{0,-1,0},{-.6,0,-.8}}};
    const auto kinetic=[&](const CollisionMomentum& p,double m) {double p2=0;for (auto x:p)p2+=x*x;return p2/(m*(std::sqrt(1+p2/(m*m*c*c))+1));};
    for (const double E:{1000.,2000.,8084.470604111418,10000.}) {
        const auto rates=conditional_outer3_ionization_rates(data,E);
        check(rates.unmapped_2a1_m2>0,"Missing deep valence rate is positive and explicit");
        check(std::abs(rates.mapped_subset_m2()+rates.unmapped_2a1_m2-rates.four_valence_total_m2)<2e-14*rates.four_valence_total_m2,"Mapped subset plus unmapped2a1 equals original four-orbitalBEB, without renormalization");
        check(std::abs(rates.OHplus_H_m2/rates.Hplus_OH_m2-.70/.22)<2e-14,"Source1b2 branching ratio");
        check(rates.parent_m2<rates.mapped_subset_m2(),"Full ionization was not all assigned stable parent");
        for (const double w:{.125,1.,32.}) for (const auto& axis:axes) for (const auto& branch:std::array<std::string,3>{"parent","OHp_H","Hp_OH"}) {
            const auto p=conditional_outer3_ionization_products(data,"outer3_BEB_Tan_"+branch+"_v1",E,w,M,H,beam,axis,{0,-1,0});
            check(p.product_count==(branch=="parent"?3:4),"Exclusive product multiplicity");
            double totalK=0,totalq=0;CollisionMomentum totalp{};int hydrogen=0,oxygen=0;
            for (int i=0;i<p.product_count;++i) {
                check(p.kinetic_J[i]>=0&&std::abs(kinetic(p.momentum_kg_m_s[i],p.mass_kg[i])-p.kinetic_J[i])<5e-12*E*e,"Every electron/heavy product is on shell");
                totalK+=p.kinetic_J[i];totalq+=p.charge_C[i];for (int d=0;d<3;++d)totalp[d]+=p.momentum_kg_m_s[i][d];
                if (p.state_id[i]=="H2Op_ground") {hydrogen+=2;++oxygen;}
                else if (p.state_id[i]=="OHp_X_ground"||p.state_id[i]=="OH_X_v0") {++hydrogen;++oxygen;}
                else if (p.state_id[i]=="Hp"||p.state_id[i]=="H_1s")++hydrogen;
            }
            const double p0=std::sqrt(E*e*(E*e+2*me*c*c))/c;
            for (int d=0;d<3;++d)check(std::abs(totalp[d]-p0*beam[d])<5e-12*p0,"All-product momentum closure");
            check(std::abs(totalK+p.chemical_reference_gain_J-E*e)<5e-12*E*e,"Kinetic plus chemical reference closure");
            check(totalq==-e&&hydrogen==2&&oxygen==1,"Charge and H/O nucleus closure");
            check(p.physical_weight_each==w&&!p.complete_water_mechanism,"Matched weights; no false complete mechanism");
        }
    }
    const auto weights=data.channel_metadata("H2O:conditional_outer3:parent").at("orbital_weights").get<std::vector<double>>();
    check(weights==std::vector<double>({0,.08,1,1}),"Tan/Murakami parent coefficients");
    for (const auto& bad:std::vector<std::vector<double>>{{-.1,0,0,0},{0,0,0},{0,1.1,0,0}}) {
        auto broken=data.metadata();for (auto& channel:broken["channels"])if (channel["id"]=="H2O:conditional_outer3:parent")channel["orbital_weights"]=bad;
        rejects([&]{StrictCollisionDataset invalid(broken);});
    }
    rejects([&]{(void)conditional_outer3_ionization_rates(data,999);});rejects([&]{(void)conditional_outer3_ionization_rates(data,10001);});
    rejects([&]{data.require_MCC_event_kernel("H2O:conditional_outer3:unmapped_2a1","outer3_BEB_Tan_Hp_OH_v1",8084);});
    rejects([&]{data.require_MCC_event_kernel("H2O:nist_BEB_valence","outer3_BEB_Tan_parent_v1",8084);});
    rejects([&]{data.require_MCC_event_kernel("H2O:ion_yield:H2O+","parent_ground_equal_pair_CM_v1",8084);});
    const auto rates=conditional_outer3_ionization_rates(data,8084.470604111418);
    std::cout<<std::setprecision(17)<<"{\"passed\":true,\"checks\":"<<checks<<",\"at8084eV\":{\"parent_m2\":"<<rates.parent_m2<<",\"OHp_H_m2\":"<<rates.OHplus_H_m2<<",\"Hp_OH_m2\":"<<rates.Hplus_OH_m2<<",\"unmapped_2a1_m2\":"<<rates.unmapped_2a1_m2<<",\"mapped_valence_fraction\":"<<rates.mapped_subset_m2()/rates.four_valence_total_m2<<"},\"physical_time_advanced\":0,\"GPU_used\":false,\"full_mechanism\":false}\n";return 0;
}catch(const std::exception& e) {std::cerr<<e.what()<<'\n';return 1;}}
