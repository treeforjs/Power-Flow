#include "raikou/chemistry.h"
#include "chemistry_audit_cases.h"

#include <cmath>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>

namespace {
using raikou::Json;
using namespace raikou::chemistry;

void check(bool condition, const std::string& message) {
    if (!condition) throw std::runtime_error(message);
}

void near(double actual, double expected, double tolerance, const std::string& message) {
    check(std::abs(actual - expected) <= tolerance, message + ": actual=" + std::to_string(actual));
}

Json manufactured() {
    return {{"schema_version", 1}, {"id", "manufactured_isomer"}, {"status", "manufactured"},
        {"species", Json::array({
            {{"id", "A"}, {"elements", {{"N", 1}}}},
            {{"id", "B"}, {"elements", {{"N", 1}}}}})},
        {"reactions", Json::array({
            {{"id", "forward"}, {"reactants", {{"A", 1}}}, {"products", {{"B", 1}}},
             {"rate", {{"type", "constant"}, {"A", 2.0}}},
             {"energy_eV_per_event", {{"gas/electron", -3.0}, {"gas/heavy", 3.0}}},
             {"external_energy_eV_per_event", 0.0}, {"source", "manufactured numerical test"}}
        })}};
}

template<class Function> void rejects(Function function, const std::string& message) {
    bool rejected = false;
    try { function(); } catch (const std::exception&) { rejected = true; }
    check(rejected, message);
}

void validation() {
    auto input = manufactured();
    check(validate_mechanism(input).at("valid").get<bool>(), "valid mechanism rejected");
    input["species"][1]["elements"]["N"] = 2;
    check(!validate_mechanism(input).at("valid").get<bool>(), "element imbalance admitted");
    input = manufactured();
    input["species"][1]["charge"] = 1;
    check(!validate_mechanism(input).at("valid").get<bool>(), "charge imbalance admitted");
    input = manufactured();
    input["reactions"][0]["rate"].erase("A");
    check(!validate_mechanism(input).at("valid").get<bool>(), "missing coefficient became zero");
    input = manufactured();
    input["reactions"][0]["external_energy_eV_per_event"] = 1.0;
    check(!validate_mechanism(input).at("valid").get<bool>(), "energy imbalance admitted");
    input = manufactured();
    input["reactions"][0]["orders"] = {{"A", 0.5}};
    check(!validate_mechanism(input).at("valid").get<bool>(), "singular fractional zero-density order admitted");
    input = manufactured();
    input["reactions"][0]["rate"] = {{"type", "expression"}, {"expression", "system(1)"}};
    check(!validate_mechanism(input).at("valid").get<bool>(), "unknown native function admitted");
}

void sources_and_jacobian() {
    const auto mechanism = Mechanism::from_json(manufactured());
    const auto result = evaluate(mechanism, State{{5.0, 0.0}});
    near(result.production_rates_m3_s[0], -10.0, 1e-12, "A source");
    near(result.production_rates_m3_s[1], 10.0, 1e-12, "B source");
    near(result.jacobian_row_major[0], -2.0, 1e-12, "A derivative");
    near(result.jacobian_row_major[2], 2.0, 1e-12, "B derivative");
    near(result.energy_sources_W_m3.at("gas/electron"), -30.0 * 1.602176634e-19, 1e-30, "electron energy loss");
    const auto zero = evaluate(mechanism, State{{0.0, 0.0}});
    near(zero.jacobian_row_major[0], -2.0, 1e-12, "zero-density first order derivative");
    check(Mechanism::from_json(mechanism.to_json()).validate().empty(), "typed round trip");

    auto aliases = manufactured();
    aliases["reactions"][0]["energy_eV_per_event"] = {{"electron", -3.0}, {"heavy", 1.0}, {"gas/heavy", 2.0}};
    const auto aliased = Mechanism::from_json(aliases);
    const auto aliased_result = evaluate(aliased, State{{5.0, 0.0}});
    check(aliased_result.energy_sources_W_m3.size() == result.energy_sources_W_m3.size(), "aliases share physical reservoir keys");
    for (const auto& [name, value] : result.energy_sources_W_m3)
        near(aliased_result.energy_sources_W_m3.at(name), value, 1e-30,
             "qualified and unqualified energy reservoirs add to the same physical source");
    check(aliased.to_json().at("reactions")[0].at("energy_eV_per_event") == aliases.at("reactions")[0].at("energy_eV_per_event"),
          "reservoir interpretation preserves authored serialization");
}

void rate_types() {
    auto input = manufactured();
    input["reactions"][0]["rate"] = {{"type", "arrhenius"}, {"A", 2.0}, {"exponent", 1.0},
        {"reference_temperature_K", 300.0}, {"activation_temperature_K", 300.0}};
    Environment environment;
    auto mechanism = Mechanism::from_json(input);
    near(evaluate(mechanism, State{{1.0, 0.0}}, environment).rate_coefficients[0], 2.0 / std::exp(1.0), 1e-12, "Arrhenius rate");
    input["reactions"][0]["rate"] = {{"type", "electron_temperature_table"}, {"temperatures_eV", {1.0, 3.0}}, {"coefficients", {2.0, 6.0}}};
    environment.electron_temperature_eV = 2.0;
    mechanism = Mechanism::from_json(input);
    near(evaluate(mechanism, State{{1.0, 0.0}}, environment).rate_coefficients[0], 4.0, 1e-12, "table interpolation");
    environment.electron_temperature_eV = 0.5;
    rejects([&] { static_cast<void>(evaluate(mechanism, State{{1.0, 0.0}}, environment)); }, "table extrapolation");
    input["reactions"][0]["rate"] = {{"type", "expression"}, {"expression", "scale * exp(-300 / Tgas_K) + pow(Te_eV, 2)"}, {"constants", {{"scale", 2.0}}}};
    environment.electron_temperature_eV = 2.0;
    mechanism = Mechanism::from_json(input);
    near(evaluate(mechanism, State{{1.0, 0.0}}, environment).rate_coefficients[0], 2.0 / std::exp(1.0) + 4.0, 1e-12, "native expression");
    input["reactions"][0]["rate"] = {{"type", "electron_eedf"}};
    input["reactions"][0]["collision_label"] = "manufactured_collision";
    mechanism = Mechanism::from_json(input);
    check(!coverage_report(mechanism, environment).at("rates_ready").get<bool>(), "missing EEDF coverage");
    rejects([&] { static_cast<void>(evaluate(mechanism, State{{0.0, 0.0}}, environment)); }, "missing rate must fail even at zero population");
    environment.electron_rates["manufactured_collision"] = 7.0;
    near(evaluate(mechanism, State{{1.0, 0.0}}, environment).rate_coefficients[0], 7.0, 1e-12, "EEDF handoff");
}

void integration() {
    auto mechanism = Mechanism::from_json(manufactured());
    AdvanceOptions options;
    options.relative_tolerance = 1e-6;
    options.absolute_tolerance_m3 = 1e-10;
    const auto result = advance(mechanism, State{{1.0, 0.0}}, Environment{}, 1.0, options);
    check(result.success, "implicit decay failed: " + result.message);
    near(result.state.densities_m3[0], std::exp(-2.0), 5e-4, "implicit decay accuracy");
    near(result.state.densities_m3[0] + result.state.densities_m3[1], 1.0, 1e-12, "conserved isomer inventory");
    check(result.state.densities_m3[0] >= 0.0 && result.state.densities_m3[1] >= 0.0, "implicit positivity");
    near(result.integrated_energy_J_m3.at("gas/electron") + result.integrated_energy_J_m3.at("gas/heavy"), 0.0, 1e-30, "integrated energy conservation");

    auto input = manufactured();
    input["reactions"][0]["rate"]["A"] = 1e6;
    input["reactions"].push_back({{"id", "reverse"}, {"reactants", {{"B", 1}}}, {"products", {{"A", 1}}}, {"rate", {{"type", "constant"}, {"A", 1.0}}}});
    mechanism = Mechanism::from_json(input);
    const auto stiff = advance(mechanism, State{{1.0, 0.0}}, Environment{}, 1e-3, options);
    check(stiff.success, "stiff reversible solve failed: " + stiff.message);
    near(stiff.state.densities_m3[0], 1.0 / 1000001.0, 1e-7, "stiff equilibrium");
    near(stiff.state.densities_m3[0] + stiff.state.densities_m3[1], 1.0, 1e-10, "stiff conserved inventory");

    input = manufactured();
    input["reactions"][0]["orders"] = Json::object();
    mechanism = Mechanism::from_json(input);
    options.maximum_steps = 100;
    const State original{{1.0, 0.0}};
    const auto failed = advance(mechanism, original, Environment{}, 2.0, options);
    check(!failed.success && failed.advanced_time_s == 0.0 && failed.state.densities_m3 == original.densities_m3,
          "failed positivity step did not roll back");
    check(failed.integrated_energy_J_m3.empty(), "failed energy accumulation did not roll back");
    mechanism = Mechanism::from_json(manufactured());
    options.maximum_steps = 1;
    const auto budget = advance(mechanism, original, Environment{}, 2.0, options);
    check(!budget.success && budget.state.densities_m3 == original.densities_m3, "step budget rollback");

    mechanism.reactions.clear();
    options.maximum_steps = 10;
    options.nonnegative = {false, true};
    const auto signed_scalar = advance(mechanism, State{{-1.0, 0.0}}, Environment{}, 1.0, options);
    check(signed_scalar.success && signed_scalar.state.densities_m3[0] == -1.0, "per-species nonnegative override was ignored");
}

void energy_integral_guard() {
    auto input = manufactured();
    input["reactions"][0]["products"] = {{"A", 1}};
    input["reactions"][0]["rate"]["A"] = 1.0;
    input["reactions"][0]["energy_eV_per_event"] = {{"gas/heavy", 1e300}};
    input["reactions"][0].erase("external_energy_eV_per_event");
    const auto mechanism = Mechanism::from_json(input);
    const State initial{{1.0, 0.0}};
    const double power = evaluate(mechanism, initial).energy_sources_W_m3.at("gas/heavy");
    check(std::isfinite(power), "overflow fixture has finite instantaneous power");
    AdvanceOptions options;
    const auto immediate = advance(mechanism, initial, {}, 1e30, options);
    check(!immediate.success && immediate.advanced_time_s == 0 && immediate.state.densities_m3 == initial.densities_m3 &&
          immediate.integrated_energy_J_m3.empty(), "overflowing first energy integral must roll back");
    options.maximum_step_s = 1e26;
    const auto accumulated = advance(mechanism, initial, {}, 1e28, options);
    check(!accumulated.success && accumulated.accepted_steps > 0 && accumulated.advanced_time_s == 0 &&
          accumulated.state.densities_m3 == initial.densities_m3 && accumulated.integrated_energy_J_m3.empty(),
          "overflow after finite accepted integrals must roll back the whole interval");
    const auto finite = advance(mechanism, initial, {}, 1e25, options);
    check(finite.success && std::isfinite(finite.integrated_energy_J_m3.at("gas/heavy")), "large finite energy remains supported");
    near(finite.integrated_energy_J_m3.at("gas/heavy") / (power * 1e25), 1.0, 1e-14, "finite energy integral");
    const auto json = advance_json({{"mechanism", input}, {"state", {{"densities_m3", {1.0, 0.0}}}}, {"dt_s", 1e30}});
    check(!json.at("success").get<bool>() && json.at("integrated_energy_J_m3").empty(), "JSON reports energy overflow as failure, not a null integral");
}

void backend_advance(bool mpi, bool cuda) {
    Mechanism mechanism;
    mechanism.id = "manufactured_backend_isomers";
    mechanism.status = "manufactured";
    State state;
    constexpr std::size_t pairs = 32;
    for (std::size_t i = 0; i < pairs; ++i) {
        for (std::size_t member = 0; member < 2; ++member) {
            Species item;
            item.id = "X" + std::to_string(2 * i + member);
            item.elements = {{"N", 1}};
            item.mass_kg = 14.007 * 1.66053906892e-27;
            mechanism.species.push_back(std::move(item));
            state.densities_m3.push_back(member == 0 ? 1.0 : 0.0);
        }
        Reaction reaction;
        reaction.id = "pair" + std::to_string(i);
        reaction.reactants = {{2 * i, 1.0}};
        reaction.products = {{2 * i + 1, 1.0}};
        reaction.rate.A = 100.0 + static_cast<double>(i);
        mechanism.reactions.push_back(std::move(reaction));
    }
    AdvanceOptions options;
    options.relative_tolerance = 1e-4;
    options.absolute_tolerance_m3 = 1e-9;
    options.execution.device = cuda ? "cuda" : "cpu";
    options.execution.mpi = mpi;
    options.execution.threads = 2;
    options.execution.tolerance = 1e-11;
    constexpr double interval = 1e-4;
    const auto result = advance(mechanism, state, Environment{}, interval, options);
    check(result.success, "chemistry backend advance failed: " + result.message);
    for (std::size_t i = 0; i < pairs; ++i) {
        near(result.state.densities_m3[2 * i] + result.state.densities_m3[2 * i + 1], 1.0, 1e-10, "backend pair conservation");
        near(result.state.densities_m3[2 * i], std::exp(-(100.0 + static_cast<double>(i)) * interval), 2e-5, "backend analytical decay");
    }
}

void interfaces() {
    const Json input{{"id", "manufactured_phase_transfer"}, {"species", Json::array({
        {{"id", "H2_g"}, {"phase", "gas"}, {"elements", {{"H", 2}}}},
        {{"id", "H2_aq"}, {"phase", "aqueous"}, {"elements", {{"H", 2}}}}})},
        {"reactions", Json::array({{{"id", "transfer"}, {"reactants", {{"H2_g", 1}}}, {"products", {{"H2_aq", 1}}},
            {"basis_interface", "water_surface"}, {"rate", {{"type", "parameter"}, {"key", "velocity_m_s"}}}}})}};
    const auto mechanism = Mechanism::from_json(input);
    Environment environment;
    environment.parameters["velocity_m_s"] = 0.1;
    rejects([&] { static_cast<void>(evaluate(mechanism, State{{10.0, 0.0}}, environment)); }, "missing geometry admitted");
    environment.phase_volumes_m3 = {{"gas", 1.0}, {"aqueous", 2.0}};
    environment.interface_areas_m2["water_surface"] = 0.2;
    const auto result = evaluate(mechanism, State{{10.0, 0.0}}, environment);
    near(result.production_rates_m3_s[0], -0.2, 1e-12, "gas transfer source");
    near(result.production_rates_m3_s[1], 0.1, 1e-12, "liquid transfer source");
    near(result.production_rates_m3_s[0] + 2.0 * result.production_rates_m3_s[1], 0.0, 1e-12, "unequal volume conservation");
}

void json_api() {
    const Json request{{"mechanism", manufactured()}, {"state", {{"densities_m3", {{"A", 5.0}, {"B", 0.0}}}}}};
    near(evaluate_json(request).at("production_rates_m3_s").at("B").get<double>(), 10.0, 1e-12, "JSON evaluation");
    auto advance_request = request;
    advance_request["dt_s"] = 0.01;
    check(advance_json(advance_request).at("success").get<bool>(), "JSON advance");
}
} // namespace

int main(int argc, char** argv) {
    try {
        bool mpi = false;
        bool cuda = false;
        for (int i = 1; i < argc; ++i) {
            mpi = mpi || std::string(argv[i]) == "--mpi";
            cuda = cuda || std::string(argv[i]) == "--cuda";
        }
        raikou::backend::Runtime runtime(mpi);
        if (cuda && !raikou::backend::cuda_available()) return 77;
        if (mpi || cuda) {
            backend_advance(mpi, cuda);
            if (raikou::backend::mpi_rank() == 0) std::cout << "chemistry backend implicit integration passed\n";
            return 0;
        }
        validation();
        sources_and_jacobian();
        chemistry_audit::minimum_steps([](const Mechanism& mechanism, const State& state, double interval, const AdvanceOptions& options) {
            return advance(mechanism, state, {}, interval, options);
        });
        chemistry_audit::geometry([](const Mechanism& mechanism, const State& state, const Environment& environment) {
            return evaluate(mechanism, state, environment);
        });
        rate_types();
        integration();
        energy_integral_guard();
        interfaces();
        json_api();
        backend_advance(false, false);
        for (int i = 1; i < argc; ++i) {
            std::ifstream stream(argv[i]);
            if (!stream) throw std::runtime_error("cannot open mechanism pack");
            const Json value = Json::parse(stream);
            const Json& mechanism_value = value.contains("mechanism") ? value.at("mechanism") : value;
            check(validate_mechanism(mechanism_value).at("valid").get<bool>(), "invalid shipped mechanism: " + std::string(argv[i]));
            if (value.value("operation", "") == "chemistry.advance") {
                const auto advanced = advance_json(value);
                check(advanced.at("success").get<bool>(), "shipped example failed: " + advanced.at("message").get<std::string>());
            }
        }
        std::cout << "chemistry validation, sources, implicit integration, rollback and interfaces passed\n";
        return 0;
    } catch (const std::exception& exception) {
        std::cerr << exception.what() << '\n';
        return 1;
    }
}
