#include "raikou/spatial_distributed.h"
#include <algorithm>
#include <cmath>
#include <iostream>
#include <numeric>
#include <sstream>
#include <stdexcept>

namespace {
using namespace raikou;
using namespace spatial;
constexpr double eps = 8.8541878128e-12;
void check(bool value, const std::string& message) { if (!value) throw std::runtime_error(message); }
void near(double a, double b, double tol, const std::string& message) { std::ostringstream details; details.precision(17); details<<message<<": "<<a<<" vs "<<b<<", tolerance "<<tol; check(std::isfinite(a) && std::abs(a-b) <= tol, details.str()); }
template<class F> void rejects(F run, const std::string& message) { bool rejected=false; try { run(); } catch (const std::exception&) { rejected=true; } check(rejected,message); }
Problem base(std::size_t n=4) {
    Problem p; p.mesh.shape={n,1,1}; p.mesh.extent_m={1,1,1};
    p.mechanism.id="neutral conducting rock"; p.mechanism.species={{"rock","rock",{{"Si",1}},0,4.66e-26,true}};
    p.transport={{0,0}}; p.initial_densities_m3.assign(n,1e15);
    p.boundaries[0].kind=BoundaryKind::Electrode; p.boundaries[1].kind=BoundaryKind::Electrode;
    p.boundaries[1].potential_V=10;
    p.electrical=Electrical{"rock",{eps},{}};
    p.options.adaptive_time=false; p.options.time_step_s=.1; p.options.end_time_s=.3;
    p.options.relative_tolerance=1e-11; p.options.potential_tolerance_V=1e-10;
    p.options.surface_charge_tolerance_C_m2=1e-23; p.options.circuit_charge_tolerance_C=1e-23;
    return p;
}
void homogeneous() {
    auto p=base(); p.circuit.enabled=true; p.circuit.initial_voltage_V=10; p.circuit.source_voltage_V=10;
    const auto r=solve(p); check(r.success,r.message); check(r.accepted_steps==3,"three BDF steps");
    for (std::size_t c=0;c<4;++c) {
        near(r.state.potential_V[c],10*(c+.5)/4,2e-9,"uniform conductor potential");
        near(r.state.ohmic_charge_C_m3[c],0,1e-22,"no artificial uniform-conductor charge");
        near(r.ohmic_heating_J[c],eps*100*.3/4,1e-19,"cell heat partition");
    }
    near(r.samples.back().source_current_A,10*eps,1e-20,"one circuit sees Ohmic current");
    near(r.samples.back().ohmic_terminal_current_A,10*eps,1e-20,"explicit terminal current");
    near(r.chemical_energy_integrals_J.at("Electrical/source_power"),eps*100*.3,1e-19,"source work");
    near(r.chemical_energy_integrals_J.at("Electrical/ohmic_work"),eps*100*.3,1e-19,"Ohmic work");
    check(r.state.temperature_K.empty(),"Ohmic work is exported, not silently injected into gas thermal");
    p.circuit.initial_voltage_V=0; p.circuit.external_capacitance_F=eps; p.circuit.series_resistance_ohm=1/eps; p.options.end_time_s=.1;
    const auto rc=solve(p);check(rc.success,rc.message);
    near(rc.state.driven_voltage_V,1/2.2,2e-10,"shared conductor and gap/external capacitance satisfy analytic backward-Euler RC equation");
}
void skew_triangles() {
    auto p=base(); p.mesh.cells={{{"tri3"},{0,1,4}},{{"tri3"},{1,2,4}},{{"tri3"},{2,3,4}},{{"tri3"},{3,0,4}}};
    p.mesh.nodes_m={{0,0,0},{1,0,0},{1,1,0},{0,1,0},{.43,.59,0}};
    p.mesh.boundary_faces={{{3,0},0},{{1,2},1},{{0,1},2},{{2,3},3}};
    p.electrical->ohmic_conductivity_S_m={eps,3*eps,3*eps,eps};
    p.circuit.enabled=true; p.circuit.initial_voltage_V=10; p.circuit.source_voltage_V=10; p.circuit.series_resistance_ohm=1e9;
    const auto r=solve(p);check(r.success,r.message);
    for(double heat:r.ohmic_heating_J)check(heat>=0,"skew TRI3 material-cell dissipation positive");
    near(std::accumulate(r.ohmic_heating_J.begin(),r.ohmic_heating_J.end(),0.),r.chemical_energy_integrals_J.at("Electrical/ohmic_work"),1e-19,"skew TRI3 conservative heat partition");
    const auto volumes=cell_volumes(p.mesh);double charge=0;for(std::size_t c=0;c<4;++c)charge+=volumes[c]*r.state.ohmic_charge_C_m3[c];
    near(charge+r.ohmic_charge_collected_at_boundaries_C,0,1e-21,"skew TRI3 global charge ledger");
    check(r.chemical_energy_integrals_J.contains("Electrical/ohmic_field_reconstruction_work"),"skew work discrepancy is exposed for outer acceptance");
}
void layered_and_restart() {
    auto p=base(2); p.electrical->ohmic_conductivity_S_m={eps,3*eps}; p.electrical->initial_ohmic_charge_C_m3={eps,-.5*eps};
    auto initial=p; initial.options.end_time_s=0; auto first=solve(initial); check(first.success,first.message);
    auto previous=first.state; auto older=previous;
    double previous_boundary=0, older_boundary=0;
    for (int step=1;step<=4;++step) {
        p.initial_checkpoint=first.checkpoint; p.options.end_time_s=.1*step;
        const auto r=solve(p); check(r.success,r.message);
        const auto& phi=r.state.potential_V;
        const double face=-(1.5*eps)*(phi[1]-phi[0])/.5;
        const double left=eps*phi[0]/.25, right=3*eps*(phi[1]-10)/.25;
        const double a0=step==1?1:1.5,a1=step==1?1:2,a2=step==1?0:.5;
        for (std::size_t c=0;c<2;++c) {
            const double divergence=c==0?left+face:right-face;
            near((a0*r.state.ohmic_charge_C_m3[c]-a1*previous.ohmic_charge_C_m3[c]+a2*older.ohmic_charge_C_m3[c])*.5+.1*divergence,0,2e-22,"local BDF charge continuity");
            const double gauss=c==0?eps*phi[0]/.25-eps*(phi[1]-phi[0])/.5:eps*(phi[1]-10)/.25+eps*(phi[1]-phi[0])/.5;
            near(gauss,r.state.ohmic_charge_C_m3[c]*.5,2e-20,"accepted local Gauss law");
        }
        near(a0*r.ohmic_charge_collected_at_boundaries_C-a1*previous_boundary+a2*older_boundary,.1*(left+right),2e-22,"boundary BDF current integral");
        near(.5*(r.state.ohmic_charge_C_m3[0]+r.state.ohmic_charge_C_m3[1])+r.ohmic_charge_collected_at_boundaries_C,.25*eps,2e-22,"global charge inventory");
        near(std::accumulate(r.ohmic_heating_J.begin(),r.ohmic_heating_J.end(),0.),r.chemical_energy_integrals_J.at("Electrical/ohmic_work"),1e-20,"per-cell work equals integrated face ledger");
        older=previous; previous=r.state; older_boundary=previous_boundary; previous_boundary=r.ohmic_charge_collected_at_boundaries_C; first=r;
    }
    p.initial_checkpoint.reset(); const auto uninterrupted=solve(p); check(uninterrupted.success,uninterrupted.message);
    for (std::size_t c=0;c<2;++c) { near(first.state.ohmic_charge_C_m3[c],uninterrupted.state.ohmic_charge_C_m3[c],1e-22,"restart charge"); near(first.ohmic_heating_J[c],uninterrupted.ohmic_heating_J[c],1e-22,"restart heat history"); }
}
void dielectric_charge() {
    auto p=base(2); p.boundaries[1].kind=BoundaryKind::Dielectric; p.boundaries[1].capacitance_F_m2=eps;
    const auto r=solve(p); check(r.success,r.message);
    near(r.samples.back().ohmic_charge_C+r.samples.back().surface_charge_C+r.ohmic_charge_collected_at_boundaries_C,0,1e-20,"Ohmic current charges dielectric surface rather than disappearing");
    check(std::abs(r.samples.back().surface_charge_C)>1e-14,"dielectric receives current");
}
void shared_dd_circuit() {
    auto p=base(1); p.mechanism.species.push_back({"e","gas",{},-1,9.109e-31,true});
    p.mechanism.species.push_back({"ion","gas",{{"H",1}},1,1.67e-27,true});
    p.transport={{0,0},{.1,0},{0,0}}; p.initial_densities_m3={1e15,1e7,1e7};
    p.phase_fractions={{"gas",{.5}},{"rock",{.5}}}; p.boundaries[1].absorbing=true;
    p.circuit.enabled=true; p.circuit.initial_voltage_V=10; p.circuit.source_voltage_V=10; p.circuit.external_capacitance_F=eps;
    auto init=p; init.options.end_time_s=0; const auto r0=solve(init);
    const auto r=solve(p); check(r.success,r.message);
    const auto& s=r.samples.back();
    const double a0=1.5,a1=2,a2=.5,dt=.1;
    const auto electrode=[&](const State& state) { return eps*(10-state.potential_V[0])/.5; };
    const double qnew=electrode(r.state),qold=electrode(r.checkpoint.previous_state);
    auto two=p;two.options.end_time_s=.1;const auto r1=solve(two);
    const double displacement=(a0*qnew-a1*qold+a2*electrode(r1.state))/dt;
    const double carrier_into_domain=1.602176634e-19*.5*r.state.densities_m3[1]*.1*(10-r.state.potential_V[0])/.5;
    near(s.source_current_A,displacement+carrier_into_domain+s.ohmic_terminal_current_A,2e-20,"DD and Ohmic current share one terminal with displacement exactly once");
    check(std::abs(carrier_into_domain)>1e-14 && std::abs(s.ohmic_terminal_current_A)>1e-14,"both current owners active");
    (void)r0;
}
Json request() {
    return {{"mechanism",{{"schema_version",1},{"id","electrical fixture"},{"species",Json::array({{{"id","R"},{"phase","rock"},{"elements",{{"Si",1}}},{"charge",0},{"mass_kg",4.66e-26}}})},{"reactions",Json::array()}}},
        {"mesh",{{"type","structured"},{"dimension",2},{"shape",{2,1,1}},{"extent_m",{1,1,1}}}},
        {"transport",{{"R",{{"mobility_m2_V_s",0},{"diffusion_m2_s",0}}}}},{"initial_densities_m3",{{"R",1e15}}},
        {"boundaries",{{"xmin",{{"kind","electrode"},{"potential_V",0}}},{"xmax",{{"kind","electrode"},{"potential_V",10}}}}},
        {"electrical",{{"phase","rock"},{"ohmic_conductivity_S_m",eps},{"initial_ohmic_charge_C_m3",0}}},
        {"time",{{"time_step_s",.1},{"end_time_s",.2},{"adaptive",false}}},
        {"solver",{{"potential_tolerance_V",1e-10},{"relative_tolerance",1e-11}}}};
}
void reconfigure() {
    auto old=request(); old["circuit"]={{"source_voltage_V",10},{"initial_voltage_V",10},{"series_resistance_ohm",1e10},{"external_capacitance_F",eps}};
    old["time"]["end_time_s"]=0.; const auto original=solve_json(old);
    auto next=old;next["permittivity_F_m"]=3*eps;next["circuit"]["source_voltage_V"]=20;next["time"]["end_time_s"]=.1;
    auto update=reconfigure_json({{"previous_problem",old},{"checkpoint",original.at("checkpoint")},{"problem",next}});
    near(update.at("driven_voltage_V").get<double>(),5,2e-9,"finite-R terminal+external capacitor charge retained through permittivity change");
    const auto& audit=update.at("audit"); near(audit.at("source_charge_impulse_C").get<double>(),0,1e-20,"finite-R cannot deliver impulse charge");
    near(audit.at("source_work_impulse_J").get<double>(),0,1e-20,"finite-R source EMF change cannot do zero-time work");
    near(audit.at("material_polarization_work_J").get<double>(),-50*eps,2e-19,"finite-R material work uses total field and external capacitor energy");
    check(update.at("checkpoint").at("state").at("time_s")==0 && update.at("checkpoint").at("accepted_steps")==0,"local time and BDF history reset explicitly");
    next["checkpoint"]=update.at("checkpoint");const auto advanced=solve_json(next);check(advanced.at("success"),"reconfigured checkpoint restarts against exact new problem");
    near(std::accumulate(advanced.at("ohmic_heating_J").begin(),advanced.at("ohmic_heating_J").end(),0.,[](double a,const Json& b){return a+b.get<double>();}),advanced.at("chemical_energy_integrals_J").at("Electrical/ohmic_work").get<double>(),1e-20,"JSON heat vector and integrated ledger agree");
    old["circuit"]["series_resistance_ohm"]=0;const auto ideal=solve_json(old);next=old;next["permittivity_F_m"]=3*eps;
    update=reconfigure_json({{"previous_problem",old},{"checkpoint",ideal.at("checkpoint")},{"problem",next}});
    near(update.at("driven_voltage_V").get<double>(),10,1e-10,"ideal voltage retained");
    near(update.at("audit").at("source_charge_impulse_C").get<double>(),20*eps,1e-20,"ideal-source displacement impulse");
    near(update.at("audit").at("source_work_impulse_J").get<double>(),200*eps,1e-19,"ideal-source fixed-voltage work");
    near(update.at("audit").at("material_work_J").get<double>(),-100*eps,1e-19,"polarization work is not Joule heating");
    next=old; next["circuit"]["source_voltage_V"]=20;
    update=reconfigure_json({{"previous_problem",old},{"checkpoint",ideal.at("checkpoint")},{"problem",next}});
    near(update.at("audit").at("material_work_J").get<double>(),0,1e-19,"pure voltage change has no material work");
    near(update.at("audit").at("energy_balance_residual_J").get<double>(),0,1e-19,"affine ideal-voltage ramp has closed energy audit");
    old=request(); old["time"]["end_time_s"]=0.; old["electrical"]["initial_ohmic_charge_C_m3"]={eps,-eps};
    const auto charged=solve_json(old); next=old; next["electrical"]["initial_ohmic_charge_C_m3"]={-eps,eps};
    update=reconfigure_json({{"previous_problem",old},{"checkpoint",charged.at("checkpoint")},{"problem",next}});
    check(std::abs(update.at("audit").at("charge_advection_work_J").get<double>())>1e-14,"advected signed solid charge has separately audited work");
    next["electrical"]["initial_ohmic_charge_C_m3"]={0,0.5*eps}; rejects([&]{(void)reconfigure_json({{"previous_problem",old},{"checkpoint",charged.at("checkpoint")},{"problem",next}});},"charge loss in host remap rejected");
    auto corrupt=charged.at("checkpoint");corrupt["state"].erase("ohmic_charge_C_m3");old["checkpoint"]=corrupt;rejects([&]{(void)solve_json(old);},"missing conserved checkpoint state cannot silently reset");
    old=request();old["boundaries"]["xmax"]["kind"]="dielectric";old["boundaries"]["xmax"]["capacitance_F_m2"]=eps;
    old["circuit"]={{"source_voltage_V",10},{"initial_voltage_V",10},{"series_resistance_ohm",1e10},{"external_capacitance_F",eps}};
    const auto dielectric=solve_json(old);check(dielectric.at("success"),"charged dielectric setup");next=old;next["permittivity_F_m"]=2*eps;
    next["electrical"]["initial_ohmic_charge_C_m3"]=dielectric.at("checkpoint").at("state").at("ohmic_charge_C_m3");
    update=reconfigure_json({{"previous_problem",old},{"checkpoint",dielectric.at("checkpoint")},{"problem",next}});
    check(update.at("checkpoint").at("state").at("surface_charge_C_m2")==dielectric.at("checkpoint").at("state").at("surface_charge_C_m2"),"material update retains dielectric free surface charge exactly");
    near(update.at("audit").at("source_charge_impulse_C").get<double>(),0,1e-20,"finite-R dielectric backing plus external charge retained");
}
void rejection_and_validation() {
    auto p=base(2); p.electrical->ohmic_conductivity_S_m={eps,100*eps};
    p.options.adaptive_time=true; p.options.time_step_s=1; p.options.minimum_time_step_s=1; p.options.end_time_s=1;
    p.options.temporal_relative_tolerance=1e-9; p.options.temporal_potential_tolerance_V=1e30;
    const auto r=solve(p); check(!r.success && r.accepted_steps==0 && r.rejected_steps==1,"Ohmic charge participates in temporal rejection independently of voltage");
    check(r.state.time_s==0 && r.state.ohmic_charge_C_m3==std::vector<double>(2,0) && r.ohmic_heating_J==std::vector<double>(2,0),"rejected trial leaves conserved state and work untouched");
    p=base(); p.mechanism.species[0].charge=1; p.transport[0].mobility_m2_V_s=1;
    rejects([&]{(void)solve(p);},"charged DD carriers cannot own background conductivity");
    p=base(); p.electrical->ohmic_conductivity_S_m={-1}; rejects([&]{(void)solve(p);},"negative conductivity rejected");
    p=base(); p.phase_fractions["rock"]={0}; rejects([&]{(void)solve(p);},"absent material cannot conduct");
    p=base(); auto model=std::make_shared<Problem>(p); model->initial_densities_m3={1e15}; rejects([&]{(void)solve_distributed(DistributedProblem{.model=model});},"owned distributed cannot silently omit background conduction");
    p=base(2);p.options.end_time_s=0.;p.mechanism.species.push_back({"G","gas",{{"H",1}},0,1.67e-27,true});p.transport.push_back({0,0});
    p.initial_densities_m3={1e15,0,0,1e15};p.phase_fractions={{"rock",{1,0}},{"gas",{0,1}}};p.electrical->ohmic_conductivity_S_m={eps,0};
    auto checkpoint=solve(p).checkpoint;checkpoint.state.ohmic_charge_C_m3={0,eps};checkpoint.state.potential_V=solve_poisson(p,{0,eps});checkpoint.previous_state=checkpoint.state;p.initial_checkpoint=checkpoint;
    bool absent_rejected=false;try{(void)solve(p);}catch(const std::exception& error){absent_rejected=std::string(error.what()).find("absent electrical phase")!=std::string::npos;}
    check(absent_rejected,"even a Gauss-consistent checkpoint cannot place Ohmic charge in an absent owner");
}
}
int main() { try { homogeneous(); layered_and_restart(); dielectric_charge(); shared_dd_circuit(); rejection_and_validation(); reconfigure(); skew_triangles(); std::cout<<"shared electrical field, local/global charge, work, restart, rejection, reconfigure and skew TRI3 passed\n"; return 0; } catch(const std::exception& error) { std::cerr<<error.what()<<'\n'; return 1; } }
