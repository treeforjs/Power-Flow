#include "raikou/distributed.h"
#include "raikou/runtime.h"
#include <iostream>
#include <stdexcept>
#include <string>
#ifdef RAIKOU_TEST_MPI
#include <mpi.h>
#endif

namespace {
using namespace raikou;
template<class Action>void rejects(const backend::DistributedHalo& control,Action action){
    bool refused=false;try{action();}catch(const std::exception&){refused=true;}
    control.collective_require(refused?"":"asymmetric malformed JSON was accepted");
}
void legacy_entrypoints(bool mpi,int communicator_f=-1){
    backend::ExecutionOptions options;options.mpi=mpi;options.communicator_f=communicator_f;
    backend::DistributedHalo control(backend::distributed_partition(1,options),{},options);
    const bool damaged_rank=control.rank()+1==control.ranks();
    Json execution{{"mpi",mpi},{"communicator_f",communicator_f},{"threads",4}};
    Json linear{{"matrix",{{"rows",2},{"offsets",{0,1,2}},{"columns",{0,1}},{"values",{1,1}}}},
        {"rhs",{1,2}},{"execution",execution}};
    const auto linear_recovery=[&]{const auto result=execute("linear.solve",linear);
        control.collective_require(result.at("converged").get<bool>()&&std::abs(result.at("solution")[0].get<double>()-1)<1e-12&&
            std::abs(result.at("solution")[1].get<double>()-2)<1e-12?"":"linear JSON recovery failed");};
    for(int damage=0;damage<5;++damage){auto bad=linear;if(damaged_rank){
        if(damage==0)bad["matrix"]["rows"]="bad";
        if(damage==1)bad.erase("rhs");
        if(damage==2)bad["execution"]["threads"]="bad";
        if(damage==3)bad["execution"]["device"]=99;
        if(damage==4)bad["matrix"]["offsets"]="bad";
    }rejects(control,[&]{(void)execute("linear.solve",bad);});linear_recovery();}
    Json local=linear;local["execution"]={{"mpi",false}};
    Json batch{{"execution",execution},{"jobs",Json::array()}};
    for(int i=0;i<256;++i)batch["jobs"].push_back({{"operation","linear.solve"},{"request",local}});
    const auto batch_recovery=[&]{const auto result=execute("batch.execute",batch);
        control.collective_require(result.at("success").get<bool>()&&result.at("results").size()==256?"":"threaded batch JSON recovery failed");};
    for(int damage=0;damage<5;++damage){auto bad=batch;if(damaged_rank){
        if(damage==0)bad.erase("jobs");
        if(damage==1)bad["jobs"]=Json::object();
        if(damage==2)bad["execution"]["threads"]="bad";
        if(damage==3)bad["execution"]["device"]=99;
        if(damage==4)bad["execution"]["device"]="cuda";
    }rejects(control,[&]{(void)execute("batch.execute",bad);});batch_recovery();}
    auto nested=batch;nested["jobs"][0]["request"]["execution"]["mpi"]=true;
    const auto independent=execute("batch.execute",nested);
    control.collective_require(!independent.at("success").get<bool>()&&!independent.at("results")[0].at("ok").get<bool>()&&
        independent.at("results")[1].at("ok").get<bool>()?"":"threaded batch MPI rejection hid independent jobs");
    Json chemistry{{"mechanism",{{"id","legacy-preflight"},{"species",Json::array({
        {{"id","A"},{"elements",{{"N",1}}}},{{"id","B"},{"elements",{{"N",1}}}}})},
        {"reactions",Json::array({{{"id","transfer"},{"reactants",{{"A",1}}},{"products",{{"B",1}}},{"rate",{{"type","constant"},{"A",1}}}}})}}},
        {"state",{{"densities_m3",{1,0}}}},{"dt_s",.001},{"execution",execution}};
    for(int damage=0;damage<5;++damage){auto bad=chemistry;if(damaged_rank){
        if(damage==0)bad["execution"]["device"]=99;
        if(damage==1)bad["mechanism"]["species"][0].erase("id");
        if(damage==2)bad["state"]["densities_m3"]="bad";
        if(damage==3)bad["options"]="bad";
        if(damage==4)bad["dt_s"]="bad";
    }rejects(control,[&]{(void)execute("chemistry.advance",bad);});
        control.collective_require(execute("chemistry.advance",chemistry).at("success").get<bool>()?"":"legacy chemistry recovery failed");}
    Json electrons=Json::parse(R"({"processes":[{"kind":"elastic","target":"X","mass_ratio":0.00002,
        "energy_ev":[0,1000],"cross_section_m2":[1e-19,1e-19]}],
        "conditions":{"fractions":{"X":1},"reduced_field_td":10,"gas_density_m3":1e20,"ion_fraction":0},
        "grid":{"cells":16,"max_energy_ev":10,"legendre_terms":2},
        "initial":{"electron_density_m3":1e8,"mean_energy_ev":1},"dt_s":1e-12})");
    electrons["execution"]=execution;
    for(int damage=0;damage<5;++damage){auto bad=electrons;if(damaged_rank){
        if(damage==0)bad["execution"]["device"]=99;
        if(damage==1)bad.erase("processes");
        if(damage==2)bad["initial"]["mean_energy_ev"]="bad";
        if(damage==3)bad["conditions"]="bad";
        if(damage==4)bad["dt_s"]="bad";
    }rejects(control,[&]{(void)execute("eedf.advance",bad);});
        const auto result=execute("eedf.advance",electrons);control.collective_require(result.contains("state")?"":"legacy EEDF recovery failed");}
    Json spatial=Json::parse(R"({"mechanism":{"id":"shadowed-spatial-controls","species":[
        {"id":"A","elements":{"H":1}},{"id":"B","elements":{"H":1}}],
        "reactions":[{"id":"decay","reactants":{"A":1},"products":{"B":1},
            "rate":{"type":"constant","A":2}}]},
        "mesh":{"dimension":2,"shape":[2,1,1],"extent_m":[1,1,1]},
        "initial_densities_m3":{"A":1,"B":0},"transport":{},
        "boundaries":{"xmin":{"kind":"electrode","potential_V":0},
            "xmax":{"kind":"electrode","potential_V":1}},
        "time":{"time_step_s":0.001,"end_time_s":0.001,"adaptive":false}})");
    spatial["execution"]=execution;
    spatial["solver"]={{"mpi",mpi},{"communicator_f",communicator_f}};
    for(int damage=0;damage<3;++damage){auto shadowed=spatial;if(damaged_rank){
        if(damage!=1)shadowed["solver"]["mpi"]="unused malformed fallback";
        if(damage!=0)shadowed["solver"]["communicator_f"]="unused malformed fallback";
    }
        control.collective_require(execute("spatial.solve",shadowed).at("success").get<bool>()?
            "":"effective execution controls did not override shadowed solver controls");
        control.collective_require(execute("spatial.solve",spatial).at("success").get<bool>()?
            "":"spatial JSON recovery failed after shadowed solver controls");
    }
}
}

int main(int argc, char** argv) {
    try {
        const bool mpi = argc > 1 && std::string(argv[1]) == "--mpi";
        raikou::backend::Runtime runtime(mpi);
        raikou::backend::ExecutionOptions execution; execution.mpi = mpi;
        const auto partition = raikou::backend::distributed_partition(2, execution);
        const raikou::backend::DistributedHalo control(partition, {}, execution);
        legacy_entrypoints(mpi);
#ifdef RAIKOU_TEST_MPI
        if(mpi){
            MPI_Comm split=MPI_COMM_NULL;
            if(MPI_Comm_split(MPI_COMM_WORLD,control.rank()%2,control.rank(),&split)!=MPI_SUCCESS)throw std::runtime_error("cannot split test communicator");
            const int handle=static_cast<int>(MPI_Comm_c2f(split));legacy_entrypoints(true,handle);
            if(MPI_Comm_free(&split)!=MPI_SUCCESS)throw std::runtime_error("cannot free test communicator");
        }
#endif
        const auto model = raikou::Json::parse(R"({"id":"api-collective","species":[
            {"id":"A","elements":{"N":1}},{"id":"B","elements":{"N":1}}],
            "reactions":[{"id":"transfer","reactants":{"A":1},"products":{"B":1},
                "rate":{"type":"constant","A":1}}]})");
        raikou::Json request{{"mechanism", model}, {"execution", {{"mpi", mpi}}},
            {"state", {{"row_begin", partition.row_begin}, {"global_rows", 2},
                {"densities_m3", std::vector<double>(partition.local_rows, 1.0)}}}, {"dt_s", 0.01}};
        for (const auto operation : {"chemistry.evaluate_distributed", "chemistry.advance_distributed"}) {
            for (int damage = 0; damage < 6; ++damage) {
                auto bad = request;
                if (control.rank() == control.ranks() - 1) {
                    if (damage == 0) bad.erase("state");
                    if (damage == 1) bad["mechanism"]["species"][0].erase("id");
                    if (damage == 2) bad["state"]["densities_m3"] = "not an array";
                    if (damage == 3) bad["execution"]["threads"] = "not an integer";
                    if (damage == 4) bad["execution"]["device"] = 99;
                    if (damage == 5) bad["options"] = "not an object";
                }
                bool refused = false;
                try { (void)raikou::execute(operation, bad); }
                catch (const std::exception&) { refused = true; }
                if (!refused) throw std::runtime_error("asymmetric malformed JSON did not fail collectively");
                const auto result = raikou::execute(operation, request);
                if (result.contains("success") && !result.at("success").get<bool>())
                    throw std::runtime_error("collective did not recover: " + result.dump());
            }
        }
        raikou::Json electrons = raikou::Json::parse(R"({
            "processes":[{"kind":"elastic","target":"X","mass_ratio":0.00002,
                "energy_ev":[0,1000],"cross_section_m2":[1e-19,1e-19]}],
            "conditions":{"fractions":{"X":1},"reduced_field_td":10,"gas_density_m3":1e20,"ion_fraction":0},
            "grid":{"cells":32,"max_energy_ev":60,"legendre_terms":2},
            "initial":{"electron_density_m3":1e8,"mean_energy_ev":1},"dt_s":1e-12})");
        electrons["execution"] = {{"mpi", mpi}};
        const auto initial = raikou::execute("eedf.advance_distributed", electrons);
        for (int damage = 0; damage < 4; ++damage) {
            auto bad = electrons;
            if (control.rank() == control.ranks() - 1) {
                if (damage == 0) bad.erase("processes");
                if (damage == 1) bad["grid"]["cells"] = "not an integer";
                if (damage == 2) bad["execution"]["device"] = 99;
                if (damage == 3) {
                    bad.erase("initial");
                    bad["state"] = initial.at("state");
                    bad["state"]["representation"] = "invalid";
                }
            }
            bool refused = false;
            try { (void)raikou::execute("eedf.advance_distributed", bad); }
            catch (const std::exception&) { refused = true; }
            if (!refused) throw std::runtime_error("asymmetric EEDF JSON did not fail collectively");
            (void)raikou::execute("eedf.advance_distributed", electrons);
        }
        if (control.ranks() > 1) {
            auto mixed = electrons;
            if (control.rank() == 0) { mixed.erase("initial"); mixed["state"] = initial.at("state"); }
            bool refused = false;
            try { (void)raikou::execute("eedf.advance_distributed", mixed); }
            catch (const std::exception&) { refused = true; }
            if (!refused) throw std::runtime_error("mixed initial/restart modes did not fail collectively");
            (void)raikou::execute("eedf.advance_distributed", electrons);
        }
        std::cout << "Collective JSON validation and recovery passed\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << error.what() << '\n';
        return 1;
    }
}
