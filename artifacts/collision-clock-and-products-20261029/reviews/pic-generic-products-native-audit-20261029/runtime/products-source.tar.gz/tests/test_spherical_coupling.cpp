#include "raikou/spatial.h"
#include <algorithm>
#include <cmath>
#include <iostream>
#include <stdexcept>
namespace {
using raikou::Json;
void check(bool value,const std::string& message){if(!value)throw std::runtime_error(message);}
bool near(double a,double b,double tolerance){return std::abs(a-b)<=tolerance*std::max({std::abs(a),std::abs(b),1e-100});}
Json request(){
    return {{"mechanism",{{"id","manufactured full angular coupling"},{"species",Json::array({
            {{"id","X"},{"elements",{{"N",1}}}},{{"id","X+"},{"elements",{{"N",1}}},{"charge",1}},{{"id","e"},{"elements",Json::object()},{"charge",-1}}})},{"reactions",Json::array()}}},
        {"mesh",{{"shape",{1,1,1}},{"extent_m",{.001,.002,.001}}}},
        {"initial_densities_m3",{{"X",1e20},{"X+",1e8},{"e",1e8}}},{"transport",Json::object()},
        {"boundaries",{{"xmin",{{"kind","electrode"},{"potential_V",0}}},{"xmax",{{"kind","electrode"},{"potential_V",1}}}}},
        {"time",{{"time_step_s",1e-12},{"end_time_s",2e-12},{"bdf2",true},{"adaptive",false}}},
        {"execution",{{"device","cpu"},{"threads",1}}},
        {"electron_closure",{{"mode","transient_spherical"},{"electron_species","e"},{"strict_event_mapping",true},{"initial_mean_energy_eV",1},
            {"grid",{{"cells",16},{"max_energy_ev",5},{"power",2},{"legendre_terms",3}}},
            {"processes",Json::array({{{"kind","elastic"},{"target","X"},{"label","elastic"},{"mass_ratio",1e-5},{"energy_ev",{0,1000}},{"cross_section_m2",{1e-19,1e-19}}}})}}}};
}
void restart_and_field(){
    auto input=request();const auto full=raikou::spatial::solve_json(input);check(full.at("success").get<bool>(),"full spherical Poisson/kinetic solve succeeds");
    const auto& item=full.at("spherical_electron_states")[0];
    raikou::kinetics::SphericalEedfState distribution;distribution.grid=raikou::kinetics::eedf_grid_from_json(item.at("grid"));distribution.time_s=item.at("time_s").get<double>();distribution.density_modes=item.at("density_modes").get<std::vector<double>>();
    check(distribution.particle_flux_m2_s()[0]>0,"negative physical Ex accelerates electrons in positive x in the fully coupled solver");
    check(near(full.at("particle_counts").at("e").get<double>(),.2,1e-8),"closed spherical solver does not integrate electron transport or collision count twice");
    input["time"]["end_time_s"]=1e-12;const auto prefix=raikou::spatial::solve_json(input);
    input["time"]["end_time_s"]=2e-12;input["checkpoint"]=prefix.at("checkpoint");const auto resumed=raikou::spatial::solve_json(input);
    const auto modes=resumed.at("spherical_electron_states")[0].at("density_modes").get<std::vector<double>>();
    for(std::size_t q=0;q<modes.size();++q)check(std::abs(modes[q]-distribution.density_modes[q])<1e-7*std::max(1.0,std::abs(distribution.density_modes[q])),"BDF restart retains each azimuthal mode and its time history");
    input["checkpoint"]=full.at("checkpoint");
    auto damaged=distribution.density_modes;
    const auto edge=[&](std::size_t i){return distribution.grid.max_energy_ev*std::pow(static_cast<double>(i)/distribution.grid.cells,distribution.grid.power);};
    const auto weight=[&](std::size_t i){return 2.0/3*(std::pow(edge(i+1),1.5)-std::pow(edge(i),1.5));};
    const auto stride=static_cast<std::size_t>(distribution.grid.legendre_terms*distribution.grid.legendre_terms);
    const double change=-2*damaged[0];damaged[0]+=change;damaged[stride]-=change*weight(0)/weight(1);
    input["checkpoint"]["state"]["spherical_electrons"][0]["density_modes"]=damaged;
    bool rejected=false;try{(void)raikou::spatial::solve_json(input);}catch(const std::invalid_argument&){rejected=true;}
    check(rejected,"negative F00 checkpoint rejects even when no new time step is requested and total number remains valid");
}
void sharp_phase_contact(){
    auto input=request();input["mechanism"]["species"].push_back({{"id","e_aq"},{"phase","aqueous"},{"elements",Json::object()},{"charge",-1}});
    input["mesh"]["shape"]={2,1,1};input["phase_fractions"]={{"gas",{1,0}},{"aqueous",{0,1}}};
    input["initial_densities_m3"]={{"X",{1e20,0}},{"X+",{1e8,0}},{"e",{1e8,0}},{"e_aq",{0,0}}};
    input["electron_closure"]["processes"][0]["cross_section_m2"]={0,0};input["boundaries"]["xmax"]["potential_V"]=0;
    input["time"]["time_step_s"]=1e-11;input["time"]["end_time_s"]=2e-11;
    input["electron_phase_contacts"]=Json::array({{{"face_index",0},{"kind","absorbing"},{"absorbed_species","e_aq"},{"energy_to_phase","aqueous"}}});
    input["thermal"]={{"phases",{{"aqueous",{{"heat_capacity_J_m3_K",1e-12},{"initial_temperature_K",300}}}}}};
    const auto result=raikou::spatial::solve_json(input);check(result.at("success").get<bool>(),"sharp kinetic gas/liquid contact converges");
    const double gas=result.at("particle_counts").at("e").get<double>(),aqueous=result.at("particle_counts").at("e_aq").get<double>();
    check(aqueous>0&&near(gas+aqueous,.1,1e-8),"kinetic gas loss is deposited once into the authored aqueous electron owner");
    const double transferred=result.at("chemical_energy_integrals_J").at("EEDF/phase_contact_energy").get<double>();
    const double liquid_change=1e-12*1e-9*(result.at("phase_temperatures_K").at("aqueous")[1].get<double>()-300);
    check(transferred>0&&near(transferred,liquid_change,1e-8),"kinetic contact energy heats the receiving own-phase volume exactly once");
    const auto& history=result.at("history");
    check(std::abs(history.back().at("gas_charge_C").get<double>())<1e-28,"gas/liquid charge is conserved across kinetic absorption");
    const double electron_change=history.back().at("electron_energy_J").get<double>()-history.front().at("electron_energy_J").get<double>();
    const double field_work=result.at("chemical_energy_integrals_J").at("EEDF/operator/electrons/field").get<double>();
    check(std::abs(electron_change+transferred-field_work)<1e-6*transferred,"electron energy, contact heat and vector-field work close through the coupled BDF step");
}
}
int main(){try{restart_and_field();sharp_phase_contact();std::cout<<"full spherical coupled ownership qualification passed\n";return 0;}catch(const std::exception& error){std::cerr<<error.what()<<'\n';return 1;}}
