#include "raikou/adaptive_time.h"
#include <algorithm>
#include <cmath>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>

namespace {
using namespace raikou::time;
void check(bool value, const std::string& message) { if (!value) throw std::runtime_error(message); }
void close(double value, double expected, double relative, const std::string& message) {
    check(std::isfinite(value) && std::abs(value - expected) <= relative * std::max({std::abs(value), std::abs(expected), 1e-100}), message);
}
template<class Function> void rejects(Function&& function, const std::string& message) {
    bool rejected = false; try { function(); } catch (const std::invalid_argument&) { rejected = true; } check(rejected, message);
}
double forced_step(double previous, double older, double derivative_at_end, double dt, double previous_dt, int order) {
    const auto a = coefficients(dt, previous_dt, order);
    return (dt * derivative_at_end - a.previous * previous - a.older * older) / a.current;
}
void test_weights() {
    const auto be = coefficients(.3, 0, 1);
    check(be.order == 1 && be.current == 1 && be.previous == -1 && be.older == 0, "BE startup coefficients");
    const auto bdf2 = coefficients(.3, .3, 2);
    check(bdf2.order == 2 && bdf2.current == 1.5 && bdf2.previous == -2 && bdf2.older == .5, "constant-step BDF2 coefficients");
    for (double ratio : {.05, .125, .5, 1., 2., 2.4, 8.}) {
        const double t = .7, k = .2, h = ratio * k;
        for (int degree : {0, 1, 2}) {
            const auto value = [&](double x) { return std::pow(x, degree); };
            const double derivative = degree == 0 ? 0 : degree * std::pow(t + h, degree - 1);
            close(forced_step(value(t), value(t - k), derivative, h, k, 2), value(t + h), 2e-14, "variable-step BDF2 is exact on degree<=2 forcing");
        }
    }
    const auto large = coefficients(1e300, 1, 2);
    check(std::isfinite(large.current) && std::isfinite(large.previous) && std::isfinite(large.older), "large representable ratios avoid squared-ratio overflow");
}
void test_polynomial_error_multiplier() {
    for (double ratio : {.05, .125, .5, 1., 2., 2.4, 8.}) {
        const double t = .3, k = .2, h = ratio * k;
        const auto value = [](double x) { return x * x * x / 6; };
        const auto derivative = [](double x) { return x * x / 2; };
        const double old = value(t), older = value(t - k);
        const double full = forced_step(old, older, derivative(t + h), h, k, 2);
        const double first_half = forced_step(old, older, derivative(t + h / 2), h / 2, k, 2);
        const double refined = forced_step(first_half, old, derivative(t + h), h / 2, h / 2, 2);
        const double full_error = h*h*h * (1+ratio)*(1+ratio) / (6*ratio*(1+2*ratio));
        const double refined_error = h*h*h * (3*ratio*ratio+6*ratio+4) / (72*ratio*(1+ratio));
        close(full - value(t+h), full_error, 1e-11, "independent cubic full-step endpoint error");
        close(refined - value(t+h), refined_error, 1e-11, "first-half history error propagates into second half");
        const auto estimate = estimate_error(std::vector<double>{full}, std::vector<double>{refined}, std::vector<double>{1}, 0, 2, ratio);
        close(estimate.component_errors[0], full_error, 1e-11, "variable-ratio step-doubling recovers full cubic LTE");
        close(estimate.normalized_error, full_error, 1e-11, "maximum norm uses full-step LTE");
        if (ratio == 1) {
            close(full_error, 2*h*h*h/9, 1e-15, "constant-step cubic full LTE is 2h^3/9");
            close(refined_error, 13*h*h*h/144, 1e-15, "two half endpoint error is 13h^3/144");
            close(estimate.full_error_multiplier, 32./19, 1e-15, "correct BDF2 full-step multiplier is 32/19");
            check((4./3)*(full-refined) < full_error, "standard Richardson 4/3 would underestimate this history protocol");
        }
    }
    const double t = .4, h = .3, old = t*t/2;
    const double full = forced_step(old, 0, t+h, h, 0, 1);
    const double half = forced_step(old, 0, t+h/2, h/2, 0, 1);
    const double refined = forced_step(half, old, t+h, h/2, h/2, 1);
    const auto estimate = estimate_error(std::vector<double>{full}, std::vector<double>{refined}, std::vector<double>{1}, 0, 1);
    check(estimate.full_error_multiplier == 2, "BE uses BE for both half steps and multiplier 2");
    close(estimate.component_errors[0], h*h/2, 2e-14, "BE quadratic full endpoint LTE");
    for (double ratio : {1e-300, 1e300}) {
        const auto stable = estimate_error(std::vector<double>{1}, std::vector<double>{.9}, std::vector<double>{1}, 0, 2, ratio);
        check(stable.full_error_multiplier >= 1.5 && stable.full_error_multiplier <= 2, "extreme finite ratio multiplier remains bounded");
    }
}
struct DecayResult { double error; std::size_t accepted, rejected; };
DecayResult adaptive_decay(double tolerance) {
    const std::vector<double> lambda{2,20,100}, initial{1,2,.5};
    auto old = initial, older = initial;
    double time = 0, previous_dt = 0, dt = .1;
    std::size_t accepted = 0, rejected = 0;
    const auto step = [&](const std::vector<double>& a, const std::vector<double>& b, double h, double k, int order) {
        const auto weights = coefficients(h,k,order); std::vector<double> result(a.size());
        for (std::size_t i=0;i<a.size();++i) result[i]=(-weights.previous*a[i]-weights.older*b[i])/(weights.current+h*lambda[i]);
        return result;
    };
    while (time < .1*(1-1e-14)) {
        check(accepted + rejected < 100000, "adaptive decay step budget");
        dt = std::min(dt, .1-time);
        const int order = accepted ? 2 : 1;
        const auto saved_old = old, saved_older = older;
        const double saved_time = time, saved_previous_dt = previous_dt;
        const auto full = step(old,older,dt,previous_dt,order);
        const auto half = step(old,older,dt/2,previous_dt,order);
        const auto refined = step(half,old,dt/2,dt/2,order);
        const auto estimate = estimate_error(full,refined,std::vector<double>{tolerance*1e-4,tolerance*1e-4,tolerance*1e-4},tolerance,order,order==1?1:dt/previous_dt);
        if (estimate.normalized_error > 1) {
            ++rejected; dt *= recommended_factor(estimate.normalized_error,order,false);
            check(old==saved_old && older==saved_older && time==saved_time && previous_dt==saved_previous_dt, "rejected full/half trials leave accepted state/history/time unchanged");
            continue;
        }
        older=old;old=full;time+=dt;previous_dt=dt;++accepted;
        dt *= recommended_factor(estimate.normalized_error,order,true);
    }
    double error=0;
    for(std::size_t i=0;i<old.size();++i) error=std::max(error,std::abs(old[i]-initial[i]*std::exp(-lambda[i]*time)));
    return {error,accepted,rejected};
}
void test_stiff_decay_and_rollback() {
    double previous = 0; std::size_t steps = 0;
    for(double tolerance:{1e-3,1e-4,1e-5}) {
        const auto result=adaptive_decay(tolerance);
        check(result.rejected>0,"oversized stiff startup is rejected before commit");
        if(previous>0) check(result.error<.45*previous && result.accepted>steps,"tighter tolerances refine stiff scalar decay");
        previous=result.error;steps=result.accepted;
    }
    check(previous<1e-4,"adaptive stiff decay reaches useful absolute accuracy");
}
void test_controller_and_validation() {
    check(recommended_factor(0,2,true)==2,"zero accepted error grows to configured maximum");
    check(recommended_factor(0,2,false)==.5,"even a zero-error rejected trial shrinks");
    check(recommended_factor(std::numeric_limits<double>::infinity(),2,false)==.1,"failed nonlinear trial uses minimum shrink");
    close(recommended_factor(.125,2,true),1.8,1e-15,"BDF2 controller uses local cubic exponent");
    close(recommended_factor(.25,1,true),1.8,1e-15,"BE controller uses quadratic exponent");
    const std::vector<double> full{2,4}, refined{1,2}, atol{1,4};
    const auto scaled=estimate_error(full,refined,atol,.5,1);
    check(scaled.component_errors==std::vector<double>({2,4}),"componentwise signed error estimates");
    close(scaled.normalized_error,1,1e-15,"component-specific absolute and relative scales use maximum norm");
    rejects([&]{(void)coefficients(0,1,2);},"zero timestep rejected");
    rejects([&]{(void)coefficients(1,0,2);},"BDF2 missing history rejected");
    rejects([&]{(void)coefficients(1,1,3);},"unsupported order rejected");
    rejects([&]{(void)coefficients(std::numeric_limits<double>::infinity(),1,1);},"nonfinite timestep rejected");
    check(estimate_error({}, {}, {}, .1, 1, 0).normalized_error == 0,"empty owned partition has zero local error and BE ignores missing history ratio");
    rejects([&]{(void)estimate_error({}, {}, atol, .1, 1);},"nonempty per-component tolerances do not match an empty state");
    rejects([&]{(void)estimate_error(full,std::vector<double>{1},atol,.1,1);},"mismatched state sizes rejected");
    rejects([&]{(void)estimate_error(full,refined,std::vector<double>{1,2,3},.1,1);},"mismatched tolerance count rejected");
    rejects([&]{(void)estimate_error(full,refined,std::vector<double>{0},.1,1);},"zero absolute tolerance rejected");
    rejects([&]{(void)estimate_error(full,refined,atol,-.1,1);},"negative relative tolerance rejected");
    rejects([&]{(void)estimate_error(std::vector<double>{std::numeric_limits<double>::quiet_NaN()},std::vector<double>{1},std::vector<double>{1},.1,1);},"nonfinite candidate rejected");
    rejects([&]{(void)estimate_error(full,refined,atol,.1,2,0);},"invalid BDF2 ratio rejected");
    rejects([&]{(void)recommended_factor(std::numeric_limits<double>::quiet_NaN(),2,false);},"NaN controller error rejected");
    rejects([&]{(void)recommended_factor(std::numeric_limits<double>::infinity(),2,true);},"accepted infinite error rejected");
    rejects([&]{(void)recommended_factor(1,2,true,1,2,.9);},"nonshrinking lower bound rejected");
}
} // namespace
int main() {
    try { test_weights();test_polynomial_error_multiplier();test_stiff_decay_and_rollback();test_controller_and_validation();std::cout<<"variable-step BDF truncation control and rollback protocol passed\n";return 0; }
    catch(const std::exception& error){std::cerr<<"adaptive time: "<<error.what()<<'\n';return 1;}
}
