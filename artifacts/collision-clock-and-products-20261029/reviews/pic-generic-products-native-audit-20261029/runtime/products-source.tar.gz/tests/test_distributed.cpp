#include "raikou/distributed.h"
#include <algorithm>
#include <cmath>
#include <iostream>
#include <limits>
#include <stdexcept>
#ifdef RAIKOU_TEST_MPI
#include <mpi.h>
#endif

namespace {
using namespace raikou::backend;
void require(bool ok, const char* message) { if (!ok) throw std::runtime_error(message); }
template<class Action> void rejects(Action action) {
    bool rejected = false;
    try { action(); } catch (const std::exception&) { rejected = true; }
    require(rejected, "distributed asymmetric failure was not rejected");
}
double exact(GlobalIndex id) { return 1.0 + std::sin(0.017 * static_cast<double>(id)); }
DistributedCsrMatrix matrix(RowPartition p) {
    DistributedCsrMatrix a{p.global_rows, p.row_begin, {0}, {}, {}};
    for (std::size_t local = 0; local < p.local_rows; ++local) {
        const auto row = p.row_begin + local;
        if (row) { a.columns.push_back(row - 1); a.values.push_back(-0.7); }
        a.columns.push_back(row); a.values.push_back(4.0);
        if (row + 1 < p.global_rows) { a.columns.push_back(row + 1); a.values.push_back(-0.3); }
        a.columns.push_back((row + 17) % p.global_rows); a.values.push_back(0.05);
        a.offsets.push_back(a.values.size());
    }
    return a;
}
void solve_case(GlobalIndex n, const ExecutionOptions& options) {
    const auto p = distributed_partition(n, options);
    auto a = matrix(p);
    std::vector<double> rhs(p.local_rows), values(p.local_rows);
    for (std::size_t row = 0; row < p.local_rows; ++row) {
        values[row] = exact(p.row_begin + row);
        for (auto entry = a.offsets[row]; entry < a.offsets[row + 1]; ++entry)
            rhs[row] += a.values[entry] * exact(a.columns[entry]);
    }
    DistributedLinearOperator op(std::move(a), options);
    const auto& halo = op.halo();
    require(halo.exclusive_sum(static_cast<double>(p.local_rows)) == static_cast<double>(p.row_begin), "prefix sum mismatch");
    require(halo.global_sum(static_cast<double>(p.local_rows)) == static_cast<double>(n), "partition coverage mismatch");
    const auto ghosts = halo.exchange(values);
    for (std::size_t i = 0; i < ghosts.size(); ++i) {
        require(ghosts[i] == exact(halo.layout().ghost_global_ids[i]), "halo value mismatch");
        require(halo.compact_index(halo.layout().ghost_global_ids[i]) == p.local_rows + i, "compact ghost index mismatch");
    }
    const auto product = op.apply(values);
    for (std::size_t i = 0; i < product.size(); ++i) require(std::abs(product[i] - rhs[i]) < 1e-12, "local matvec mismatch");
    const auto result = op.solve(rhs);
    require(result.converged, "partitioned FGMRES did not converge");
    require(result.local_solution.size() == p.local_rows && op.matrix().local_rows() == p.local_rows, "global vector retained by local API");
    require(op.matrix().values.size() <= 4 * p.local_rows, "matrix storage is not partitioned");
    require(op.compact_matrix().input_columns == p.local_rows + ghosts.size(), "compact matrix has global columns");
    const auto restart = static_cast<std::size_t>(std::min<GlobalIndex>(static_cast<GlobalIndex>(options.restart), n));
    require(result.local_working_vector_entries <= (2 * restart + 8) * p.local_rows + 3 * ghosts.size() + halo.layout().send_local_indices.size(), "Krylov storage exceeds local bound");
    double error = 0;
    for (std::size_t i = 0; i < p.local_rows; ++i) error = std::max(error, std::abs(result.local_solution[i] - values[i]));
    require(halo.global_max(error) < 1e-8, "rank-count dependent solution");
    const auto full = gather_distributed(halo, result.local_solution);
    for (GlobalIndex i = 0; i < n; ++i) require(std::abs(full[static_cast<std::size_t>(i)] - exact(i)) < 1e-8, "final compatibility gather mismatch");
    auto bad = rhs;
    if (halo.rank() == 0 && !bad.empty()) bad[0] = std::numeric_limits<double>::quiet_NaN();
    // The N=2/four-rank case may give rank zero no rows.
    if (n > static_cast<GlobalIndex>(halo.ranks())) rejects([&] { static_cast<void>(op.solve(bad)); });
    auto controls = options;
    if (halo.rank() == 0) controls.restart += 1;
    if (halo.ranks() > 1) rejects([&] { DistributedLinearOperator invalid(matrix(p), controls); });
    controls = options;
    if (halo.rank() == 0) controls.device = "invalid";
    rejects([&] { DistributedLinearOperator invalid(matrix(p), controls); });
    auto malformed = matrix(p);
    if (halo.rank() == 0) malformed.offsets[0] = 1;
    rejects([&] { DistributedLinearOperator invalid(std::move(malformed), options); });
    if (options.device == "cpu" && n > static_cast<GlobalIndex>(halo.ranks())) {
        auto singular = matrix(p);
        if (halo.rank() == 0) {
            for (std::size_t row = 0; row < p.local_rows; ++row)
                for (auto entry = singular.offsets[row]; entry < singular.offsets[row + 1]; ++entry)
                    if (singular.columns[entry] == p.row_begin + row) singular.values[entry] = 0;
        }
        auto ilu = options; ilu.preconditioner = "block_ilu0";
        DistributedLinearOperator singular_operator(std::move(singular), ilu);
        rejects([&] { static_cast<void>(singular_operator.solve(rhs)); });
    }
    require(op.solve(rhs).converged, "operator failed after rejected collective request");
}
}
int main(int argc, char** argv) {
    try {
        bool mpi = false, cuda = false;
        for (int i = 1; i < argc; ++i) { const std::string arg(argv[i]); mpi |= arg == "--mpi"; cuda |= arg == "--cuda"; }
        Runtime runtime(mpi);
        if (cuda && !cuda_available()) return 77;
        ExecutionOptions options; options.mpi = mpi; options.device = cuda ? "cuda" : "cpu";
        options.tolerance = 1e-11; options.threads = 2;
        solve_case(257, options);
        solve_case(2, options);
        options.preconditioner = "block_ilu0";
        solve_case(257, options);
        solve_case(1, options); // empty ranks retain a valid resident preconditioner
        options.preconditioner = "jacobi";
        const auto p = distributed_partition(2, options);
        DistributedCsrMatrix identity{p.global_rows, p.row_begin, {0}, {}, {}};
        for (std::size_t i = 0; i < p.local_rows; ++i) { identity.columns.push_back(p.row_begin + i); identity.values.push_back(1); identity.offsets.push_back(i + 1); }
        DistributedLinearOperator op(identity, options);
        for (double scale : {1e200, 1e-200}) {
            std::vector<double> rhs(p.local_rows);
            for (std::size_t i = 0; i < rhs.size(); ++i) rhs[i] = scale * static_cast<double>(p.row_begin + i + 1);
            const auto result = op.solve(rhs);
            require(result.converged, "scaled distributed solve failed");
            for (std::size_t i = 0; i < rhs.size(); ++i) require(std::abs(result.local_solution[i] / scale - rhs[i] / scale) < 1e-8, "scaled distributed solution mismatch");
        }
        auto tiny = identity;
        for (auto& value : tiny.values) value = 1e-309;
        DistributedLinearOperator tiny_operator(std::move(tiny), options);
        const auto tiny_result = tiny_operator.solve(std::vector<double>(p.local_rows, 1e-200));
        require(tiny_result.converged, "subnormal matrix solve failed");
        for (double value : tiny_result.local_solution) require(std::abs(value / 1e109 - 1) < 1e-8, "RHS normalization overflowed a finite quotient");
        auto overflow = identity;
        for (auto& value : overflow.values) value = std::numeric_limits<double>::max();
        DistributedLinearOperator explosive(std::move(overflow), options);
        rejects([&] { static_cast<void>(explosive.apply(std::vector<double>(p.local_rows, 2))); });
#ifdef RAIKOU_TEST_MPI
        if (mpi) {
            MPI_Comm supplied = MPI_COMM_NULL;
            require(MPI_Comm_dup(MPI_COMM_WORLD, &supplied) == MPI_SUCCESS, "test communicator duplication failed");
            auto host = options; host.communicator_f = static_cast<int>(MPI_Comm_c2f(supplied));
            DistributedLinearOperator retained(identity, host);
            require(MPI_Comm_free(&supplied) == MPI_SUCCESS, "host communicator release failed");
            require(retained.solve(std::vector<double>(p.local_rows, 1)).converged, "operator borrowed expired host communicator");
        }
#endif
        if (mpi_rank() == 0) std::cout << "partitioned storage, halo, FGMRES, failures and communicator ownership passed\n";
        return 0;
    } catch (const std::exception& error) { std::cerr << error.what() << '\n'; return 1; }
}
