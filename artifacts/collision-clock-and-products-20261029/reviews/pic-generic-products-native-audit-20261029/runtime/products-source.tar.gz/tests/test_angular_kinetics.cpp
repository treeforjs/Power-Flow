#include "raikou/spherical_harmonics.h"
#include "raikou/kinetic_transport.h"
#include <algorithm>
#include <cmath>
#include <iostream>
#include <numbers>
#include <stdexcept>

namespace {
using namespace raikou::kinetics;
void check(bool value, const std::string& message) { if (!value) throw std::runtime_error(message); }
bool near(double a, double b, double tolerance) { return std::abs(a - b) <= tolerance * std::max({std::abs(a), std::abs(b), 1e-100}); }
double difference(const std::vector<double>& a, const std::vector<double>& b) {
    check(a.size() == b.size(), "mode vector dimensions");
    double error = 0, scale = 0;
    for (std::size_t i = 0; i < a.size(); ++i) { error = std::max(error, std::abs(a[i] - b[i])); scale = std::max(scale, std::abs(a[i])); }
    return error / std::max(scale, 1e-300);
}
CollisionProcess elastic() {
    CollisionProcess process;
    process.kind = CollisionKind::Elastic; process.target = "X"; process.label = "synthetic elastic";
    process.mass_ratio = 9.1093837015e-31 / (28 * 1.66053906660e-27);
    process.energy_ev = {0, 1000}; process.cross_section_m2 = {1e-19, 1e-19};
    return process;
}
void angular_basis_and_rotations() {
    const auto x = real_spherical_harmonics(6, {1, 0, 0});
    check(x[0] == 1 && near(x[spherical_index(1, 1)], std::sqrt(3.0), 1e-14), "Cartesian x harmonic convention");
    const auto y = real_spherical_harmonics(6, {0, 1, 0});
    check(near(y[spherical_index(1, -1)], std::sqrt(3.0), 1e-14), "Cartesian y harmonic convention");
    const auto nodes = spherical_quadrature(6);
    for (std::size_t i = 0; i < 36; ++i) for (std::size_t j = 0; j < 36; ++j) {
        double value = 0;
        for (const auto& node : nodes) value += node.weight * node.basis[i] * node.basis[j];
        check(std::abs(value - (i == j ? 1 : 0)) < 2e-13, "all real spherical harmonics are independently orthonormal");
    }
    const auto positive = real_spherical_harmonics(6, {1, 2, 3}), negative = real_spherical_harmonics(6, {-1, -2, -3});
    for (int l = 0; l < 6; ++l) for (int m = -l; m <= l; ++m)
        check(std::abs(negative[spherical_index(l, m)] - (l % 2 ? -1 : 1) * positive[spherical_index(l, m)]) < 1e-13, "full angular parity is (-1)^l for every m");
    const EedfGrid grid{.cells = 64, .max_energy_ev = 20, .power = 2, .legendre_terms = 6};
    auto state = spherical_from_legendre(maxwellian_eedf(1e8, 1, grid));
    const std::size_t stride = 36;
    for (std::size_t i = 0; i < 64; ++i) for (int l = 1; l < 6; ++l) for (int m = -l; m <= l; ++m)
        if (l % 2 == 0 || i != 63) state.density_modes[i*stride + spherical_index(l, m)] =
            state.density_modes[i*stride] * 0.002 * std::sin(static_cast<double>((l + m + 1) * (i + 1)));
    const auto rotation = axis_angle_rotation({1, 2, 3}, 0.71);
    const auto rotated = rotate_spherical_eedf(state, rotation);
    const auto restored = rotate_spherical_eedf(rotated, inverse_rotation(rotation));
    check(difference(state.density_modes, restored.density_modes) < 2e-13, "rotation inverse preserves the complete angular state");
    check(state.electron_density_m3() == rotated.electron_density_m3() && state.electron_energy_ev_m3() == rotated.electron_energy_ev_m3(), "rotations preserve exact number and energy moments");
    for (std::size_t i = 0; i < 64; ++i) for (int l = 0; l < 6; ++l) {
        double before = 0, after = 0;
        for (int m = -l; m <= l; ++m) { before += std::pow(state.density_modes[i*stride + spherical_index(l,m)],2); after += std::pow(rotated.density_modes[i*stride + spherical_index(l,m)],2); }
        check(std::abs(before - after) <= 1e-11 * std::max(before, 1e-200), "rotation preserves every degree's angular norm");
    }
    const auto expected_flux = rotate_vector(rotation, state.particle_flux_m2_s()), actual_flux = rotated.particle_flux_m2_s();
    for (std::size_t d = 0; d < 3; ++d) check(near(expected_flux[d], actual_flux[d], 1e-11), "electron particle-flux vector rotates covariantly");
    const auto other = axis_angle_rotation({-1, 1, 2}, -0.31);
    check(difference(rotate_spherical_eedf(rotated, other).density_modes,
                     rotate_spherical_eedf(state, compose_rotations(other, rotation)).density_modes) < 2e-13, "harmonic rotations represent Cartesian rotation composition");
    bool refused = false;
    try { (void)legendre_from_spherical(state); } catch (const std::invalid_argument&) { refused = true; }
    check(refused, "legacy conversion cannot silently discard non-axisymmetric modes");
}
void field_rotation_and_legacy_parity() {
    const EedfGrid grid{.cells = 64, .max_energy_ev = 20, .power = 2, .legendre_terms = 4};
    const auto initial = maxwellian_eedf(1e8, 1, grid);
    EedfConditions conditions; conditions.fractions["X"] = 1; conditions.gas_density_m3 = 1e20;
    conditions.ion_fraction = 0; conditions.reduced_field_td = 100;
    const auto legacy = advance_eedf({elastic()}, conditions, initial, 1e-10);
    const auto full = advance_spherical_eedf({elastic()}, conditions, spherical_from_legendre(initial), {0, 0, -10}, 1e-10);
    check(difference(legacy.state.density_modes, legendre_from_spherical(full.state).density_modes) < 1e-12, "full spherical m=0 path preserves legacy Legendre physics");
    const auto turning = advance_spherical_eedf({elastic()}, conditions, full.state, {-10, 0, 0}, 1e-10);
    check(turning.flux_velocity_m_s[0] > 0 && turning.flux_velocity_m_s[2] > 0, "turning the field retains old angular memory while generating new transverse drift");
    const auto rotation = axis_angle_rotation({1, 3, -2}, 0.61);
    const auto rotated_initial = rotate_spherical_eedf(turning.state, rotation);
    const Vector3 field{-4, 3, -8};
    const auto reference = advance_spherical_eedf({elastic()}, conditions, turning.state, field, 1e-10);
    const auto transformed = advance_spherical_eedf({elastic()}, conditions, rotated_initial, rotate_vector(rotation, field), 1e-10);
    check(difference(transformed.state.density_modes, rotate_spherical_eedf(reference.state, rotation).density_modes) < 2e-8,
          "arbitrary 3D field acceleration is rotationally covariant across all azimuthal modes");
    check(near(reference.state.electron_density_m3(), initial.electron_density_m3(), 1e-11), "full angular elastic kinetics conserves electron number");
    check(std::abs(reference.energy_balance_relative) < 1e-6, "full angular electron energy closes through field work and collisions");
    const auto rhs = evaluate_spherical_eedf({elastic()}, conditions, reference.state, field);
    double residual = 0, scale = 0;
    for (std::size_t i = 0; i < rhs.density_mode_rates.size(); ++i) {
        const double change = reference.state.density_modes[i] - turning.state.density_modes[i];
        residual = std::max(residual, std::abs(change - 1e-10 * rhs.density_mode_rates[i]));
        scale = std::max(scale, std::abs(change));
    }
    check(residual < 2e-7 * scale, "continuous full angular RHS reproduces the coupled backward-Euler equation");
    check(std::abs(rhs.electron_production_m3_s) < 1e-9 * initial.electron_density_m3() / 1e-10,
          "continuous collision-field RHS conserves number for elastic gas");
}
void conservative_spatial_streaming() {
    const EedfGrid grid{.cells=64,.max_energy_ev=20,.power=2,.legendre_terms=4};
    auto isotropic=spherical_from_legendre(maxwellian_eedf(1e8,1,grid));
    auto directed=isotropic;
    const std::size_t stride=16;
    for(std::size_t i=0;i<63;++i)directed.density_modes[i*stride+spherical_index(1,1)]=0.05*directed.density_modes[i*stride];
    KineticMesh periodic{{0.4,0.7},{{0,1,{1,0,0},0.5},{1,0,{1,0,0},0.5}}};
    const auto uniform=kinetic_streaming_rhs(periodic,{directed,directed});
    for(const auto& rates:uniform.density_mode_rates)for(double value:rates)check(std::abs(value)<1e-6,"uniform free-streaming distribution has zero periodic residual");
    check(near(uniform.face_particle_flux_m2_s[0],directed.particle_flux_m2_s()[0],1e-12),"staggered distribution face flux agrees with the owned number-current moment");
    check(near(uniform.face_energy_flux_ev_m2_s[0],directed.energy_flux_ev_m2_s()[0],1e-12),"staggered distribution face flux agrees with the owned energy-current moment");
    auto other=spherical_from_legendre(maxwellian_eedf(2e8,2,grid));
    const std::vector<SphericalEedfState> states{directed,other};
    const auto rates=kinetic_streaming_rhs(periodic,states,2);
    const auto certify_matrix=[&](const KineticMesh& mesh,const std::vector<SphericalEedfState>& trial){
        const auto rhs=kinetic_streaming_rhs(mesh,trial);
        const auto assembled=assemble_kinetic_streaming(mesh,grid,{static_cast<raikou::backend::GlobalIndex>(trial.size()*1024),0,trial.size()*1024});
        raikou::backend::DistributedLinearOperator op(assembled.matrix);
        std::vector<double> values,expected;
        for(std::size_t c=0;c<trial.size();++c){values.insert(values.end(),trial[c].density_modes.begin(),trial[c].density_modes.end());expected.insert(expected.end(),rhs.density_mode_rates[c].begin(),rhs.density_mode_rates[c].end());}
        auto actual=op.apply(values);for(std::size_t q=0;q<actual.size();++q)actual[q]+=assembled.affine_rates[q];
        check(difference(expected,actual)<2e-13,"row-owned streaming CSR exactly matches the all-mode conservative flux operator");
    };
    certify_matrix(periodic,states);
    const double dt=0.5*rates.maximum_explicit_step_s;
    const auto next=advance_kinetic_streaming(periodic,states,dt,2);
    double particles0=0,particles1=0,energy0=0,energy1=0;
    for(std::size_t c=0;c<2;++c) {
        particles0+=periodic.cell_volumes_m3[c]*states[c].electron_density_m3();
        particles1+=periodic.cell_volumes_m3[c]*next.states[c].electron_density_m3();
        energy0+=periodic.cell_volumes_m3[c]*states[c].electron_energy_ev_m3();
        energy1+=periodic.cell_volumes_m3[c]*next.states[c].electron_energy_ev_m3();
    }
    check(near(particles0,particles1,1e-13)&&near(energy0,energy1,1e-13),"closed free streaming conserves total electron number and energy with unequal cell volumes");
    KineticFace reflecting;reflecting.left=0;reflecting.normal={0,1,0};reflecting.wall=KineticWall::Specular;
    KineticMesh wall{{1},{reflecting}};
    certify_matrix(wall,{directed});
    const auto reflected=kinetic_streaming_rhs(wall,{directed});
    check(std::abs(reflected.outward_particle_rate_s)<1e-6&&std::abs(reflected.outward_energy_rate_ev_s)<1e-6,"specular wall conserves number and energy exactly");
    wall.faces.front().wall=KineticWall::Absorbing;
    certify_matrix(wall,{directed});
    const auto loss=kinetic_streaming_rhs(wall,{directed});
    const auto escaped=advance_kinetic_streaming(wall,{directed},0.5*loss.maximum_explicit_step_s);
    check(near(directed.electron_density_m3()-escaped.states[0].electron_density_m3(),escaped.outward_particles,1e-10),"absorbing-wall particle loss equals its integrated kinetic flux");
    check(near(directed.electron_energy_ev_m3()-escaped.states[0].electron_energy_ev_m3(),escaped.outward_energy_ev,1e-10),"absorbing-wall energy loss equals its integrated kinetic flux");
    wall.faces.front().wall=KineticWall::PrescribedIncoming;wall.faces.front().incoming=other;
    certify_matrix(wall,{directed});
    bool refused=false;
    try{(void)advance_kinetic_streaming(periodic,states,2*rates.maximum_explicit_step_s);}catch(const std::invalid_argument&){refused=true;}
    check(refused&&states[0].density_modes==directed.density_modes,"CFL rejection is transactional");
    // Linear manufactured spatial profile: the l=1 streaming equation is the mass
    // adjoint of the l=0 current operator, independent of a second implementation.
    KineticMesh line{{1,1,1},{{0,1,{1,0,0},1},{1,2,{1,0,0},1}}};
    auto low=isotropic,high=isotropic;
    for(double& value:low.density_modes)value*=0.8;
    for(double& value:high.density_modes)value*=1.2;
    const auto manufactured=kinetic_streaming_rhs(line,{low,isotropic,high});
    const double gamma=std::sqrt(2*1.602176634e-19/9.1093837015e-31);
    const std::size_t i=20;
    const auto edge=[&](std::size_t k){return grid.max_energy_ev*std::pow(static_cast<double>(k)/grid.cells,grid.power);};
    const double c0=0.5*(edge(i)+edge(i+1)),c1=0.5*(edge(i+1)+edge(i+2)),e=edge(i+1);
    const double dual=2.0/3*(std::pow(c1,1.5)-std::pow(c0,1.5));
    const double expected=-gamma/std::sqrt(3.0)*0.2*e*((c1-e)*isotropic.density_modes[i*stride]+(e-c0)*isotropic.density_modes[(i+1)*stride])/dual;
    check(near(manufactured.density_mode_rates[1][i*stride+spherical_index(1,1)],expected,1e-12),"manufactured free-streaming gradient produces the exact discrete all-mode transport operator");
}
} // namespace
int main() {
    try { angular_basis_and_rotations(); field_rotation_and_legacy_parity(); conservative_spatial_streaming(); std::cout << "full spherical angular kinetics qualification passed\n"; return 0; }
    catch (const std::exception& error) { std::cerr << "angular kinetics: " << error.what() << '\n'; return 1; }
}
