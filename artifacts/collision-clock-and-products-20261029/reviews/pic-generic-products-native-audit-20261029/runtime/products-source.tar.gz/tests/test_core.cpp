#include "raikou/raikou.h"

#include <algorithm>
#include <array>
#include <cmath>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>
#include <vector>

namespace {

using CR = raikou::CollisionalRadiativeModel;
using Spark = raikou::SparkBreakdownSolver;
using Calibration = raikou::SpectrometerCalibration;
using Inverter = raikou::ZapdosPlasmaInverter;

void check(bool condition, const std::string& message) {
    if (!condition) throw std::runtime_error(message);
}

void close(double actual, double expected, const std::string& message,
           double relative_tolerance = 2e-11, double absolute_tolerance = 0.0) {
    check(std::isfinite(actual) &&
              std::abs(actual - expected) <=
                  std::max(absolute_tolerance, relative_tolerance * std::abs(expected)),
          message + ": got " + std::to_string(actual) + ", expected " + std::to_string(expected));
}

template <typename Callable>
void rejects(Callable callable, const std::string& message) {
    try {
        callable();
    } catch (const std::invalid_argument&) {
        return;
    }
    throw std::runtime_error(message);
}

void test_rates_and_balance() {
    for (double temperature : {0.5, 2.5, 20.0}) {
        for (int lower = 1; lower < CR::NUM_LEVELS; ++lower) {
            for (int upper = lower + 1; upper <= CR::NUM_LEVELS; ++upper) {
                const double excitation = CR::excitation_rate(lower, upper, temperature);
                const double deexcitation = CR::deexcitation_rate(upper, lower, temperature);
                const double energy = CR::IH_EV *
                    (1.0 / (lower * lower) - 1.0 / (upper * upper));
                check(excitation > 0.0 && std::isfinite(excitation), "finite excitation rate");
                close(deexcitation / excitation,
                      static_cast<double>(lower * lower) / (upper * upper) *
                          std::exp(energy / temperature),
                      "excitation detailed balance");
            }
        }
        for (int level = 1; level <= CR::NUM_LEVELS; ++level) {
            const double thermal_volume = std::pow(
                CR::H_PLANCK * CR::H_PLANCK /
                    (2.0 * CR::PI * CR::ME * CR::QE * temperature), 1.5);
            close(CR::three_body_recombination(level, temperature),
                  CR::ionization_rate(level, temperature) * (level * level) *
                      thermal_volume * std::exp(CR::IH_EV / (level * level * temperature)),
                  "ionization/recombination detailed balance");
            check(CR::radiative_recombination(level, temperature) > 0.0,
                  "positive radiative recombination");
        }
    }
    close(CR::excitation_rate(2, 1, 2.5), 0.0, "forbidden excitation direction");
    close(CR::deexcitation_rate(1, 2, 2.5), 0.0, "forbidden deexcitation direction");
    close(CR::ionization_rate(0, 2.5), 0.0, "invalid level");
    close(CR::compute_lyman_alpha_cross_section(20000.0),
          CR::compute_lyman_alpha_cross_section(5000.0) / 2.0,
          "Doppler temperature scaling");
    close(CR::compute_holstein_escape_factor(0.0), 1.0, "transparent escape factor");
    double previous = 1.0;
    for (double depth : {1e-3, 0.1, 1.0, 10.0, 1000.0}) {
        const double factor = CR::compute_holstein_escape_factor(depth);
        check(factor > 0.0 && factor <= previous, "monotone positive escape factor");
        previous = factor;
    }
}

void test_forward_regression() {
    const auto result = CR{}.evaluate({});
    // Captured from the original Quark C++ implementation before extraction.
    // These are compatibility baselines, not independent experimental validation.
    constexpr std::array<double, 5> populations{
        1e20, 3362231588288517.0, 232118975019203.5,
        175615877134617.56, 226504523460498.16};
    for (std::size_t i = 0; i < populations.size(); ++i)
        close(result.populations_m3[i], populations[i], "population regression");
    close(result.lyman_alpha_radiance_W_m2_sr, 146.95338928646947, "Ly-alpha regression");
    close(result.lyman_beta_radiance_W_m2_sr, 6.287899943324609, "Ly-beta regression");
    close(result.balmer_alpha_radiance_W_m2_sr, 1.2328122378576263, "H-alpha regression");
    close(result.balmer_beta_radiance_W_m2_sr, 0.24038575946317348, "H-beta regression");
    close(result.molecular_lyman_proxy_W_m2_sr, 1.9763151635230176, "molecular regression");
    close(result.tau_0_lyman_alpha, 4.170555585531825, "Ly-alpha opacity regression");
    close(result.escape_factor_lyman_alpha, 0.14306235328169281, "Ly-alpha escape regression");
    close(result.tau_0_lyman_beta, 0.66877718012248366, "Ly-beta opacity regression");
    close(result.escape_factor_lyman_beta, 0.63058270834624863, "Ly-beta escape regression");

    CR::PlasmaState zero_path;
    zero_path.path_length_m = 0.0;
    const auto transparent = CR{}.evaluate(zero_path);
    close(transparent.lyman_alpha_radiance_W_m2_sr, 0.0, "zero path radiance");
    close(transparent.tau_0_lyman_alpha, 0.0, "zero path opacity");
    close(transparent.escape_factor_lyman_alpha, 1.0, "zero path escape");
}

CR::PlasmaState fitted_state(const CR::FitResult& fit) {
    CR::PlasmaState state;
    state.Te_eV = fit.Te_eV;
    state.ne_m3 = fit.ne_m3;
    state.nH_ground_m3 = fit.nH_m3;
    state.nH2_m3 = fit.nH2_m3;
    return state;
}

void test_fit() {
    const CR model;
    const auto target = model.evaluate({});
    const auto fit = model.fit_vuv_shot(
        target.lyman_alpha_radiance_W_m2_sr, target.lyman_alpha_radiance_W_m2_sr * 0.1,
        target.molecular_lyman_proxy_W_m2_sr, target.molecular_lyman_proxy_W_m2_sr * 0.1,
        0.005);
    check(fit.converged && fit.iterations > 0, "synthetic fit converges");
    check(std::isfinite(fit.chi2_reduced) && fit.chi2_reduced < 1e-3,
          "synthetic fit residual");
    const auto recovered = model.evaluate(fitted_state(fit));
    // Two lines cannot uniquely recover four unknowns; check the observable fit.
    close(recovered.lyman_alpha_radiance_W_m2_sr, target.lyman_alpha_radiance_W_m2_sr,
          "fitted Ly-alpha reprojection", 0.002);
    close(recovered.molecular_lyman_proxy_W_m2_sr, target.molecular_lyman_proxy_W_m2_sr,
          "fitted molecular reprojection", 0.002);
    close(fit.tau_0_lyman_alpha, recovered.tau_0_lyman_alpha, "fitted opacity consistency");

    CR::FitPriors bounds;
    bounds.min_Te_eV = 0.8; bounds.max_Te_eV = 1.0;
    bounds.min_ne_m3 = 1e17; bounds.max_ne_m3 = 2e17;
    bounds.min_nH_m3 = 1e17; bounds.max_nH_m3 = 2e17;
    bounds.min_nH2_m3 = 1e17; bounds.max_nH2_m3 = 2e17;
    const auto bounded = model.fit_vuv_shot(1e6, 1e5, 1e6, 1e5, 0.005, 5000, bounds);
    check(bounded.Te_eV >= bounds.min_Te_eV && bounded.Te_eV <= bounds.max_Te_eV &&
          bounded.ne_m3 >= bounds.min_ne_m3 && bounded.ne_m3 <= bounds.max_ne_m3 &&
          bounded.nH_m3 >= bounds.min_nH_m3 && bounded.nH_m3 <= bounds.max_nH_m3 &&
          bounded.nH2_m3 >= bounds.min_nH2_m3 && bounded.nH2_m3 <= bounds.max_nH2_m3,
          "fit result obeys all prior bounds");
    check(!bounded.converged, "poor fit is not marked converged");

    bounds.min_Te_eV = bounds.max_Te_eV = 2.5;
    bounds.min_ne_m3 = bounds.max_ne_m3 = 1e19;
    bounds.min_nH_m3 = bounds.max_nH_m3 = 1e20;
    bounds.min_nH2_m3 = bounds.max_nH2_m3 = 5e19;
    const auto fixed = model.fit_vuv_shot(
        target.lyman_alpha_radiance_W_m2_sr, target.lyman_alpha_radiance_W_m2_sr * 0.1,
        target.molecular_lyman_proxy_W_m2_sr, target.molecular_lyman_proxy_W_m2_sr * 0.1,
        0.005, 5000, bounds);
    close(fixed.Te_eV, 2.5, "fixed temperature prior");
    close(fixed.ne_m3, 1e19, "fixed electron prior");
    close(fixed.nH_m3, 1e20, "fixed hydrogen prior");
    close(fixed.nH2_m3, 5e19, "fixed molecular prior");
    // With exact radiances, only 0.01 * log10(ne/nH)^2 remains in the objective.
    close(fixed.chi2_reduced, 0.005, "reported objective matches fixed returned state", 1e-8);
}

void test_validation() {
    CR model;
    for (double invalid : {-1.0, std::numeric_limits<double>::infinity(),
                           std::numeric_limits<double>::quiet_NaN()}) {
        CR::PlasmaState state;
        state.Te_eV = invalid;
        rejects([&] { model.evaluate(state); }, "invalid electron temperature accepted");
        state = {};
        state.nH2_m3 = invalid;
        rejects([&] { model.evaluate(state); }, "invalid density accepted");
        state = {};
        state.path_length_m = invalid;
        rejects([&] { model.evaluate(state); }, "invalid path accepted");
    }
    rejects([&] { model.fit_vuv_shot(1, 0, 1, 0.1, 0.005); }, "zero sigma accepted");
    rejects([&] { model.fit_vuv_shot(1, 0.1, 1, 0.1, 0); }, "zero fit path accepted");
    CR::FitPriors reversed;
    reversed.min_ne_m3 = 1e23;
    rejects([&] { model.fit_vuv_shot(1, 0.1, 1, 0.1, 0.005, 5000, reversed); },
            "reversed priors accepted");
}

void test_spark() {
    Spark::SparkState state;
    const Spark::SparkConfig config;
    for (int step = 0; step < 100; ++step) {
        const auto next = Spark::step_spark_discharge(state, 5e-8, config);
        check(next.deposited_energy_J >= state.deposited_energy_J &&
              next.accumulated_action >= state.accumulated_action,
              "spark energy and action are monotone");
        state = next;
    }
    close(state.channel_radius_m, 0.0012016698598663193, "spark radius regression");
    close(state.pressure_Pa, 335414552.80936271, "spark pressure regression");
    close(state.temperature_K, 50000.0, "spark temperature limit");
    close(state.deposited_energy_J, 60.864225846538297, "spark energy regression");
    close(state.accumulated_action, 174.64153360756987, "spark action regression");
    const auto after = Spark::step_spark_discharge(state, 1e-6, config);
    close(after.current_A, 0.0, "current after pulse");
    close(after.deposited_energy_J, state.deposited_energy_J, "energy after pulse");
    close(Spark::compute_channel_radius(0.0), 1e-4, "minimum spark radius");
}

void test_calibration() {
    const Calibration calibration;
    const Calibration::CollectionGeometry geometry;
    close(geometry.etendue_m2_sr(), geometry.solid_angle_sr() * geometry.slit_area_m2(),
          "collection etendue");
    close(calibration.master_efficiency(121.57), 83.236637901681107,
          "spectrometer efficiency regression");
    close(calibration.radiance_to_counts(250, 121.57, 1e-8), 153094.39384647924,
          "spectrometer count regression");
    for (double wavelength : {121.57, 145.0, 160.8, 180.0}) {
        const double counts = calibration.radiance_to_counts(250, wavelength, 1e-8);
        close(calibration.counts_to_radiance(counts, wavelength, 1e-8), 250,
              "spectrometer radiance round trip");
    }
    close(calibration.radiance_to_counts(250, 110.0, 1e-8), 0.0, "window cutoff");
    bool cutoff_rejected = false;
    try { (void)calibration.counts_to_radiance(10, 110.0, 1e-8); }
    catch (const std::runtime_error&) { cutoff_rejected = true; }
    check(cutoff_rejected, "cannot invert a zero-throughput wavelength");
    rejects([&] { (void)calibration.theoretical_branching_ratio(99, 0, 1); },
            "unknown branching transition accepted");

    std::vector<Calibration::MeasuredBand> bands;
    for (const auto& transition : calibration.get_n2_lbh_database()) {
        if (transition.v_upper != 0) continue;
        const double counts = transition.einstein_A_s *
                              calibration.master_efficiency(transition.wavelength_nm);
        bands.push_back({0, transition.v_lower, transition.wavelength_nm, counts, 0.05 * counts});
    }
    const auto points = calibration.evaluate_branching_calibration(bands);
    check(points.size() == bands.size() * (bands.size() - 1) / 2, "branching pair count");
    std::size_t index = 0;
    for (std::size_t i = 0; i < bands.size(); ++i) {
        for (std::size_t j = i + 1; j < bands.size(); ++j) {
            const double ratio = calibration.master_efficiency(bands[i].wavelength_nm) /
                                 calibration.master_efficiency(bands[j].wavelength_nm);
            close(points[index].relative_efficiency, ratio, "branching efficiency recovery");
            close(points[index].uncertainty, ratio * std::sqrt(2.0) * 0.05,
                  "branching uncertainty propagation");
            ++index;
        }
    }
}

void test_inverter() {
    Inverter::GridConfig config;
    config.nx = 8;
    config.ny = 6;
    Inverter inverter(config);
    inverter.solve_space_charge_poisson(20000, 1000, 1e-9);
    inverter.step_breakdown_kinetics(1e-12);
    close(inverter.at(0, 0).phi, 2222.2222222174696, "Poisson cathode regression");
    close(inverter.at(3, 2).phi, 8888.8888888779329, "Poisson interior regression");
    close(inverter.at(3, 2).n_e, 127659514086.23828, "kinetics density regression");
    close(inverter.compute_dynamic_gap_resistance(), 83037.079471284786,
          "gap resistance regression");
    const auto lineout = inverter.synthesize_vuv_lyman_lineout();
    check(lineout.size() == 8, "lineout follows gap grid size");
    close(lineout[0], 6.1418831282047724e-9, "cathode lineout regression");
    close(lineout[3], 9.4189194818009692e-10, "interior lineout regression");
    for (int j = 0; j < config.ny; ++j) {
        for (int i = 0; i < config.nx; ++i) {
            close(inverter.at(i, j).n_e, inverter.at(i, j).n_i, "charge symmetry");
            inverter.at(i, j).sigma = 2.0;
        }
    }
    close(inverter.compute_dynamic_gap_resistance(),
          config.d_gap_m / (2.0 * config.width_m * config.height_m),
          "uniform slab resistance");

    // Exercise aggregation with an exactly reproducible one-step observation.
    Inverter reference(config);
    reference.solve_space_charge_poisson(1000.0);
    reference.step_breakdown_kinetics(1e-9);
    Inverter::InversionTargets targets;
    targets.measured_vuv_lyman_lineout_W_m2_sr = reference.synthesize_vuv_lyman_lineout();
    targets.measured_gap_resistance_ohm = reference.compute_dynamic_gap_resistance();
    const auto inferred = Inverter(config).invert_spectral_and_circuit_data(targets);
    close(inferred.chi2_reduced, 0.0, "matching observation objective", 0.0, 1e-20);
    close(inferred.calculated_resistance_ohm, targets.measured_gap_resistance_ohm,
          "inversion resistance aggregation");
    check(inferred.mean_ne_m3 > 0.0 && inferred.peak_ne_m3 >= inferred.mean_ne_m3,
          "inversion density aggregation");
}

} // namespace

int main() {
    try {
        test_rates_and_balance();
        test_forward_regression();
        test_fit();
        test_validation();
        test_spark();
        test_calibration();
        test_inverter();
        std::cout << "Raikou core tests passed\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "Raikou core test failed: " << error.what() << '\n';
        return 1;
    }
}
