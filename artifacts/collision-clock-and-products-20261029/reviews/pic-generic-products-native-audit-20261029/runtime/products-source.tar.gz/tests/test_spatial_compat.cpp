#include "raikou/spatial_distributed.h"
#include <algorithm>
#include <cmath>
#include <iostream>
#include <stdexcept>
namespace {
using namespace raikou;
void check(bool value,const std::string& message){if(!value)throw std::runtime_error(message);}
void close(double a,double b,double tolerance,const std::string& message){check(std::abs(a-b)<=tolerance*std::max({std::abs(a),std::abs(b),1.0}),message+": "+std::to_string(a)+" / "+std::to_string(b));}
void compare(const std::vector<double>& a,const std::vector<double>& b,const std::string& label,double tolerance=2e-7){check(a.size()==b.size(),label+" dimensions");for(std::size_t i=0;i<a.size();++i)close(a[i],b[i],tolerance,label+" row "+std::to_string(i));}
void compare_state(const spatial::State& a,const spatial::State& b,const std::string& label){
    close(a.time_s,b.time_s,1e-15,label+" clock");compare(a.densities_m3,b.densities_m3,label+" density");compare(a.potential_V,b.potential_V,label+" potential");
    compare(a.surface_charge_C_m2,b.surface_charge_C_m2,label+" surface charge",1e-12);compare(a.dielectric_potential_V,b.dielectric_potential_V,label+" dielectric voltage");
    compare(a.temperature_K,b.temperature_K,label+" temperature");compare(a.photon_densities_m3,b.photon_densities_m3,label+" photons");close(a.driven_voltage_V,b.driven_voltage_V,2e-7,label+" circuit");
    check(a.phase_temperatures_K.size()==b.phase_temperatures_K.size(),label+" phase temperature count");for(const auto& [phase,values]:a.phase_temperatures_K)compare(values,b.phase_temperatures_K.at(phase),label+" phase "+phase);
    check(a.spherical_electrons.size()==b.spherical_electrons.size()&&a.electrons.size()==b.electrons.size(),label+" angular cell count");
    for(std::size_t c=0;c<a.spherical_electrons.size();++c){compare(a.spherical_electrons[c].density_modes,b.spherical_electrons[c].density_modes,label+" all real modes");close(a.spherical_electrons[c].time_s,b.spherical_electrons[c].time_s,1e-15,label+" spherical clock");}
    for(std::size_t c=0;c<a.electrons.size();++c){compare(a.electrons[c].density_modes,b.electrons[c].density_modes,label+" all Legendre modes");close(a.electrons[c].time_s,b.electrons[c].time_s,1e-15,label+" Legendre clock");}
}
spatial::Problem fluid(){
    spatial::Problem p;p.mesh.shape={3,1,1};p.mesh.extent_m={.001,.002,.001};
    p.mechanism.id="manufactured compatibility";p.mechanism.species={{"H","gas",{{"H",1}},0,1.6735575e-27,true}};
    p.initial_densities_m3={1e10,2e10,3e10};p.transport={{0,1e-6}};
    p.boundaries[0].kind=spatial::BoundaryKind::Electrode;p.boundaries[1].kind=spatial::BoundaryKind::Dielectric;p.boundaries[1].potential_V=2;p.boundaries[1].capacitance_F_m2=1e-6;p.boundaries[1].initial_surface_charge_C_m2=1e-9;
    p.thermal.enabled=true;p.thermal.heat_capacity_J_m3_K={1};p.thermal.initial_temperature_K={300,310,320};p.thermal.heating_W_m3={1,2,3};p.thermal.conductivity_W_m_K={.01};
    spatial::RadiationGroup photon;photon.id="manufactured";photon.photon_energy_eV=2;photon.initial_density_m3={1e6,2e6,3e6};photon.diffusion_m2_s=1e-7;p.radiation={photon};
    p.circuit.enabled=true;p.circuit.initial_voltage_V=2;p.circuit.source_voltage_V=2;p.circuit.series_resistance_ohm=1e9;p.circuit.external_capacitance_F=1e-12;
    p.options.time_step_s=1e-7;p.options.end_time_s=2e-7;p.options.adaptive_time=false;p.options.relative_tolerance=1e-9;p.options.threads=2;return p;
}
void run_fluid(){
    auto p=fluid();const auto serial=spatial::solve(p);check(serial.success,"serial compatibility reference succeeds: "+serial.message);
    p.options.mpi=true;const auto distributed=spatial::solve_mpi_compat(p);check(distributed.success,"owned compatibility solve succeeds: "+distributed.message);
    check(!distributed.checkpoint.thermal_energy_ledger_available&&distributed.thermal_energy_integrals_J.empty(),"distributed thermal advance reports unavailable source history");
    check(!distributed.chemical_energy_integrals_J.contains("Thermal/net_energy"),"distributed output does not claim a partial thermal integral");
    compare_state(distributed.state,serial.state,"completed");compare_state(distributed.checkpoint.previous_state,serial.checkpoint.previous_state,"previous");
    compare(distributed.particle_counts,serial.particle_counts,"global inventory");
    auto back_problem=fluid();back_problem.options.end_time_s=3*back_problem.options.time_step_s;
    const auto complete_serial=spatial::solve(back_problem);check(complete_serial.success,"serial extended reference succeeds");
    back_problem.initial_checkpoint=distributed.checkpoint;const auto back=spatial::solve(back_problem);
    check(back.success,"advanced MPI checkpoint continues physical state on serial: "+back.message);compare_state(back.state,complete_serial.state,"advanced reverse backend switch");
    check(!back.checkpoint.thermal_energy_ledger_available&&back.thermal_energy_integrals_J.empty()&&back.thermal_energy_residual_bound_J.empty(),"serial continuation never invents unavailable MPI thermal history");
    check(!back.chemical_energy_integrals_J.contains("Thermal/net_energy"),"serial continuation omits incomplete cumulative thermal integral");
    p.options.mpi=false;p.options.end_time_s=p.options.time_step_s;const auto prefix=spatial::solve(p);check(prefix.success,"serial checkpoint prefix succeeds");
    p.options.end_time_s=2*p.options.time_step_s;p.initial_checkpoint=prefix.checkpoint;const auto resumed_serial=spatial::solve(p);
    p.options.mpi=true;const auto resumed=spatial::solve_mpi_compat(p);check(resumed.success,"owned compatibility restart succeeds: "+resumed.message);compare_state(resumed.state,resumed_serial.state,"resumed");compare_state(resumed.checkpoint.previous_state,resumed_serial.checkpoint.previous_state,"resumed previous");
    check(resumed.accepted_steps==resumed_serial.accepted_steps&&resumed.checkpoint.accepted_steps==resumed_serial.checkpoint.accepted_steps,"legacy accepted-step total survives owned restart");
    p.options.time_step_s*=.5;p.options.mpi=false;p.initial_checkpoint=prefix.checkpoint;
    const auto smaller_serial=spatial::solve(p);p.options.mpi=true;const auto smaller_owned=spatial::solve_mpi_compat(p);
    check(smaller_serial.success&&smaller_owned.success,"changed timestep limit restart succeeds");compare_state(smaller_owned.state,smaller_serial.state,"bounded restart");
    p.initial_checkpoint=prefix.checkpoint;p.options.end_time_s=prefix.state.time_s;
    p.initial_checkpoint->boundary_counts={7.25};p.initial_checkpoint->previous_boundary_counts={3.5};p.initial_checkpoint->energy_integrals_J={{"historical/marker",2.5}};p.initial_checkpoint->previous_energy_integrals_J={{"historical/marker",-1.25}};
    const auto unchanged=spatial::solve_mpi_compat(p);check(unchanged.success,"no-step compatibility restart succeeds");compare_state(unchanged.state,p.initial_checkpoint->state,"no-step current");compare_state(unchanged.checkpoint.previous_state,p.initial_checkpoint->previous_state,"no-step previous");
    check(unchanged.checkpoint.boundary_counts==std::vector<double>{7.25}&&unchanged.checkpoint.previous_boundary_counts==std::vector<double>{3.5},"historical global boundary ledgers are assigned once, not multiplied or divided by ranks");
    check(unchanged.checkpoint.energy_integrals_J.at("historical/marker")==2.5&&unchanged.checkpoint.previous_energy_integrals_J.at("historical/marker")==-1.25,"both historical energy ledgers survive exactly");
    check(unchanged.checkpoint.thermal_energy_ledger_available&&unchanged.thermal_energy_integrals_J==prefix.thermal_energy_integrals_J,"no-step MPI restart preserves available thermal sources");
    check(unchanged.checkpoint.previous_thermal_energy_integrals_J==prefix.checkpoint.previous_thermal_energy_integrals_J
        &&unchanged.checkpoint.thermal_energy_residual_bound_J==prefix.checkpoint.thermal_energy_residual_bound_J
        &&unchanged.checkpoint.previous_thermal_energy_residual_bound_J==prefix.checkpoint.previous_thermal_energy_residual_bound_J,"no-step MPI restart preserves both thermal BDF histories and bounds");
}
void run_phase_defaults(){
    spatial::Problem p;p.mesh.shape={2,1,1};p.mesh.extent_m={1,1,1};
    p.mechanism.id="thermal default compatibility";p.mechanism.species={{"H","gas",{{"H",1}},0,1.67e-27,true},{"H_aq","aqueous",{{"H",1}},0,1.67e-27,true}};
    p.initial_densities_m3.assign(4,0);p.transport.resize(2);p.boundaries[0].kind=spatial::BoundaryKind::Electrode;p.boundaries[1].kind=spatial::BoundaryKind::Electrode;
    p.phase_fractions={{"gas",{.5}},{"aqueous",{.5}}};p.environment.gas_temperature_K=1000;p.environment.liquid_temperature_K=300;
    p.thermal.enabled=true;for(const auto* phase:{"gas","aqueous"})p.thermal.phases[phase].heat_capacity_J_m3_K={1};p.options.end_time_s=0;
    const auto serial=spatial::solve(p);p.options.mpi=true;const auto owned=spatial::solve_mpi_compat(p);check(serial.success&&owned.success,"thermal default compatibility initialization succeeds");compare_state(owned.state,serial.state,"phase defaults");
    close(owned.state.phase_temperatures_K.at("aqueous")[0],300,1e-12,"MPI compatibility retains liquid default");
}
void run_zero_step_history(){
    for(bool failed_prefix:{false,true}){
        auto p=fluid();p.options.end_time_s=failed_prefix?p.options.time_step_s:0;
        if(failed_prefix){p.options.maximum_newton_iterations=1;p.options.minimum_time_step_s=p.options.time_step_s;p.thermal.heating_W_m3={1e9};}
        const auto prefix=spatial::solve(p);
        check(prefix.success!=failed_prefix&&prefix.accepted_steps==0,"serial initialization/failed prefix has zero accepted steps");
        check(prefix.checkpoint.previous_step_s==0,"serial zero-step prefix records no previous accepted timestep");
        p.options.maximum_newton_iterations=30;p.options.end_time_s=p.options.time_step_s;
        spatial::Result serial;
        for(bool legacy:{false,true}){
            p.options.mpi=false;p.initial_checkpoint=prefix.checkpoint;
            if(legacy)p.initial_checkpoint->previous_step_s=p.options.time_step_s; // historical serial encoding
            serial=spatial::solve(p);check(serial.success,"serial zero-step checkpoint resumes: "+serial.message);
            p.options.mpi=true;const auto owned=spatial::solve_mpi_compat(p);check(owned.success,"serial zero-step checkpoint resumes on MPI: "+owned.message);
            compare_state(owned.state,serial.state,"zero-step backend switch current");compare_state(owned.checkpoint.previous_state,serial.checkpoint.previous_state,"zero-step backend switch previous");
            check(owned.checkpoint.accepted_steps==1&&serial.checkpoint.accepted_steps==1,"zero-step backend switch starts with backward Euler");
        }
        p.initial_checkpoint.reset();p.options.end_time_s=0;const auto initialized=spatial::solve_mpi_compat(p);
        check(initialized.success&&initialized.checkpoint.previous_step_s==0,"MPI initialization records no accepted history");
        check(initialized.checkpoint.thermal_energy_ledger_available&&initialized.thermal_energy_integrals_J.at("")==std::vector<double>(3,0)
            &&initialized.checkpoint.previous_thermal_energy_integrals_J.at("")==std::vector<double>(3,0),"zero-step MPI initialization has known zero thermal history");
        p.initial_checkpoint=initialized.checkpoint;p.options.mpi=false;p.options.end_time_s=p.options.time_step_s;
        const auto back=spatial::solve(p);check(back.success,"MPI zero-step checkpoint resumes on serial backend: "+back.message);compare_state(back.state,serial.state,"reverse zero-step backend switch");
    }
}

void run_kinetic(bool spherical,bool cuda=false){
    auto p=fluid();p.mesh.shape={2,1,1};p.mechanism.species.push_back({"H+","gas",{{"H",1}},1,1.6735575e-27,true});p.mechanism.species.push_back({"e","gas",{},-1,9.1093837015e-31,true});
    p.initial_densities_m3={1e20,1e8,1e8,2e20,1e8,1e8};p.transport.assign(3,{});p.thermal={};p.radiation.clear();p.circuit={};p.boundaries[1].kind=spatial::BoundaryKind::Electrode;p.boundaries[1].potential_V=1;
    p.electron_closure.emplace();auto& closure=*p.electron_closure;closure.strict_event_mapping=true;closure.grid={.cells=16,.max_energy_ev=5,.power=2,.legendre_terms=3};
    kinetics::CollisionProcess elastic;elastic.kind=kinetics::CollisionKind::Elastic;elastic.target="H";elastic.label="elastic";elastic.mass_ratio=1e-5;elastic.energy_ev={0,1000};elastic.cross_section_m2={1e-19,1e-19};closure.processes={elastic};
    p.electron_mode=spherical?"transient_spherical":"transient_boltzmann";p.electron_field_axis={-1,0,0};p.initial_electron_mean_energy_eV=1;p.options.bdf2=spherical;p.options.time_step_s=1e-12;p.options.end_time_s=2e-12;
    const auto serial=spatial::solve(p);check(serial.success,"serial kinetic compatibility reference succeeds");p.options.mpi=true;p.options.device=cuda?"cuda":"cpu";const auto owned=spatial::solve_mpi_compat(p);check(owned.success,"owned kinetic compatibility solve succeeds: "+owned.message);compare_state(owned.state,serial.state,"kinetic current");compare_state(owned.checkpoint.previous_state,serial.checkpoint.previous_state,"kinetic previous");
    p.options.end_time_s=owned.state.time_s;p.initial_checkpoint=owned.checkpoint;const auto unchanged=spatial::solve_mpi_compat(p);check(unchanged.success,"kinetic no-step restart succeeds");compare_state(unchanged.state,owned.state,"kinetic no-step current");compare_state(unchanged.checkpoint.previous_state,owned.checkpoint.previous_state,"kinetic no-step previous");
}
}
int main(int argc,char** argv){try{backend::Runtime runtime(true);const std::string mode=argc>1?argv[1]:"";const bool cuda=argc>2&&std::string(argv[2])=="--cuda";if(cuda&&!backend::cuda_available())return 77;if(mode=="--spherical")run_kinetic(true,cuda);else if(mode=="--axial")run_kinetic(false,cuda);else {run_fluid();run_phase_defaults();run_zero_step_history();}std::cout<<"owned spatial compatibility qualification passed\n";return 0;}catch(const std::exception& error){std::cerr<<error.what()<<'\n';return 1;}}
