#pragma once

#include "raikou/chemistry.h"
#include <cmath>
#include <stdexcept>
#include <string>

namespace chemistry_audit {
using namespace raikou::chemistry;
constexpr double charge = 1.602176634e-19;
inline void require(bool condition, const std::string& message) {
    if (!condition) throw std::runtime_error(message);
}
inline void near(double actual, double expected, double tolerance, const std::string& message) {
    require(std::isfinite(actual) && std::abs(actual - expected) <= tolerance, message);
}
inline Mechanism isomer() {
    Mechanism mechanism;
    mechanism.id = "audit-chemistry-controls";
    mechanism.species = {{"A", "gas", {{"H", 1}}, 0, 1e-26, true},
                         {"B", "gas", {{"H", 1}}, 0, 1e-26, true}};
    Reaction reaction;
    reaction.id = "convert"; reaction.reactants = {{0, 1}}; reaction.products = {{1, 1}};
    reaction.rate.A = 1; reaction.energy_eV_per_event = {{"heat", 1}};
    reaction.check_energy_balance = true; reaction.external_energy_eV_per_event = 1;
    mechanism.reactions.push_back(reaction);
    return mechanism;
}

// The callback exercises the same independently specified BE step-doubling
// fixture through serial, resident CUDA and owned MPI entry points.
template<class Advance> void minimum_steps(Advance advance) {
    const auto mechanism = isomer();
    const State initial{{1, 0}};
    AdvanceOptions options;
    options.relative_tolerance = 1e-8; options.absolute_tolerance_m3 = .06;
    options.minimum_step_s = 1; options.maximum_step_s = 1.6;
    const auto result = advance(mechanism, initial, 1.6, options);
    require(result.success && result.accepted_steps == 2 && result.rejected_steps == 1,
            "chemistry must retry the legal minimum before the endpoint remainder");
    // Full h=1.6 has error .07597 > .06, but h=1 has error 1/18 < .06.
    // The accepted h=1 and h=.6 each commit two backward-Euler half steps.
    const double expected = 1 / (1.5 * 1.5 * 1.3 * 1.3);
    near(result.state.densities_m3[0], expected, 1e-13, "minimum/remainder analytic density");
    near(result.state.densities_m3[1], 1 - expected, 1e-13, "minimum/remainder atom inventory");
    near(result.integrated_energy_J_m3.at("gas/heat") / charge, 1 - expected, 1e-13,
         "minimum/remainder independently counted event energy");
    const auto continued = advance(mechanism, initial, 3.6, options);
    require(continued.success && continued.accepted_steps >= 3 && continued.rejected_steps == 1,
            "an accepted minimum must not propose a subsequent subminimum timestep");
    near(continued.state.densities_m3[0] + continued.state.densities_m3[1], 1, 1e-13,
         "continued minimum-step inventory");
    const auto endpoint = advance(mechanism, initial, .6, options);
    require(endpoint.success && endpoint.accepted_steps == 1 && endpoint.rejected_steps == 0,
            "a shorter endpoint remainder remains admissible");
    near(endpoint.state.densities_m3[0], 1 / (1.3 * 1.3), 1e-13, "short endpoint analytic density");
    options.absolute_tolerance_m3 = .01;
    const auto exhausted = advance(mechanism, initial, 1.6, options);
    require(!exhausted.success && exhausted.accepted_steps == 0 && exhausted.rejected_steps == 2 &&
            exhausted.advanced_time_s == 0 && exhausted.state.densities_m3 == initial.densities_m3 &&
            exhausted.integrated_energy_J_m3.empty(), "rejected actual minimum rolls back after exactly one retry");
    options.absolute_tolerance_m3 = .001;
    const auto rejected_endpoint = advance(mechanism, initial, .6, options);
    require(!rejected_endpoint.success && rejected_endpoint.accepted_steps == 0 && rejected_endpoint.rejected_steps == 1 &&
            rejected_endpoint.advanced_time_s == 0 && rejected_endpoint.state.densities_m3 == initial.densities_m3 &&
            rejected_endpoint.integrated_energy_J_m3.empty(), "rejected endpoint below minimum must roll back");
}

template<class Evaluate> void geometry(Evaluate evaluate) {
    auto mechanism = isomer();
    mechanism.species.push_back({"W", "aqueous", {{"O", 1}}, 0, 2e-26, true});
    const State initial{{1, 0, 1}};
    const auto missing = [&](const Environment& environment, const std::string& message) {
        bool rejected = false;
        try { (void)evaluate(mechanism, initial, environment); }
        catch (const std::exception&) { rejected = true; }
        require(rejected, message);
    };
    // An unrelated aqueous spectator does not make a homogeneous gas-volume
    // rate require absolute geometry: the gas volume cancels exactly.
    const auto homogeneous = evaluate(mechanism, initial, {});
    near(homogeneous.production_rates_m3_s[0], -1, 1e-14, "homogeneous volumetric default is preserved");
    near(homogeneous.energy_sources_W_m3.at("gas/heat") / charge, 1, 1e-14,
         "homogeneous energy volume cancels");
    auto& reaction = mechanism.reactions.front();
    reaction.basis_interface = "wall";
    Environment environment; environment.interface_areas_m2 = {{"wall", 2}};
    missing(environment, "same-phase area reaction must require its receiving volume");
    environment.phase_volumes_m3 = {{"gas", 4}};
    const auto surface = evaluate(mechanism, initial, environment);
    near(surface.production_rates_m3_s[0], -.5, 1e-14, "surface source uses physical area/volume");
    near(surface.production_rates_m3_s[1], .5, 1e-14, "surface product uses physical area/volume");
    near(surface.jacobian_row_major[0], -.5, 1e-14, "surface Jacobian uses physical area/volume");
    near(surface.jacobian_row_major[3], .5, 1e-14, "surface product Jacobian uses physical area/volume");
    near(surface.energy_sources_W_m3.at("gas/heat") / charge, .5, 1e-14, "surface energy uses physical area/volume");
    environment.interface_areas_m2.clear();
    missing(environment, "area reaction must require its authored interface area");
    reaction.basis_interface.clear();
    reaction.energy_eV_per_event = {{"gas/chemical", -1}, {"aqueous/heat", 1}};
    reaction.external_energy_eV_per_event = 0;
    environment.phase_volumes_m3 = {{"gas", 2}};
    missing(environment, "energy-only phase transfer must require the destination volume");
    environment.phase_volumes_m3 = {{"aqueous", 4}};
    missing(environment, "energy-only phase transfer must require the source volume");
    environment.phase_volumes_m3 = {{"gas", 2}, {"aqueous", 4}};
    const auto transfer = evaluate(mechanism, initial, environment);
    near(transfer.production_rates_m3_s[0], -1, 1e-14, "energy transfer preserves homogeneous mass rate");
    near(transfer.energy_sources_W_m3.at("gas/chemical") / charge, -1, 1e-14, "source phase energy density");
    near(transfer.energy_sources_W_m3.at("aqueous/heat") / charge, .5, 1e-14, "destination phase energy density");
    near((2 * transfer.energy_sources_W_m3.at("gas/chemical") +
          4 * transfer.energy_sources_W_m3.at("aqueous/heat")) / charge, 0, 1e-14,
         "energy-only transfer conserves volume-weighted energy");
    reaction.energy_eV_per_event = {{"gas/heat", 1}};
    reaction.external_energy_eV_per_event = 1; reaction.basis_phase = "aqueous";
    environment.phase_volumes_m3 = {{"gas", 4}};
    missing(environment, "a distinct volume basis must require its own phase measure");
    environment.phase_volumes_m3["aqueous"] = 2;
    const auto distinct_basis = evaluate(mechanism, initial, environment);
    near(distinct_basis.production_rates_m3_s[0], -.5, 1e-14, "distinct volume basis scales by source/receiving volume");
}
} // namespace chemistry_audit
