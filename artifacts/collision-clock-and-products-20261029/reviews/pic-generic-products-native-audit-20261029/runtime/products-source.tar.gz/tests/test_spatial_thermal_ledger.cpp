#include "raikou/spatial.h"
#include "raikou/sparse_direct.h"
#include <cmath>
#include <iostream>
#include <limits>
#include <numeric>
#include <sstream>
#include <stdexcept>

namespace {
using namespace raikou;
using namespace spatial;
constexpr double qe = 1.602176634e-19;
void check(bool value, const std::string& message) { if (!value) throw std::runtime_error(message); }
void near(double a, double b, double tol, const std::string& message) {
    std::ostringstream detail; detail.precision(17); detail << message << ": " << a << " vs " << b << ", tolerance " << tol;
    check(std::isfinite(a) && std::abs(a-b) <= tol, detail.str());
}
template<class F> void rejects(F f, const std::string& message) {
    bool rejected = false; try { f(); } catch (const std::exception&) { rejected = true; } check(rejected, message);
}
Problem base(std::size_t n = 2) {
    Problem p; p.mesh.shape = {n,1,1}; p.mesh.extent_m = {1,1,.3};
    p.mechanism.id = "thermal ledger fixture";
    p.mechanism.species = {{"N","gas",{{"N",1}},0,2.325e-26,true}};
    p.transport = {{0,0}}; p.initial_densities_m3.assign(n,1e15);
    p.boundaries[0].kind = BoundaryKind::Electrode; p.boundaries[1].kind = BoundaryKind::Electrode;
    p.thermal.enabled = true; p.thermal.heat_capacity_J_m3_K = {2}; p.thermal.initial_temperature_K = {300};
    p.options.adaptive_time = false; p.options.time_step_s = .1; p.options.end_time_s = .3;
    return p;
}
void total_check(const Result& r) {
    double total = 0; for (const auto& [phase, values] : r.thermal_energy_integrals_J) {
        (void)phase; total += std::accumulate(values.begin(), values.end(), 0.);
    }
    near(total,r.chemical_energy_integrals_J.at("Thermal/net_energy"),std::abs(total)*1e-13+1e-30,"independent global BDF source sum");
}
void tiny_source_and_restart() {
    auto p = base(); p.thermal.heating_W_m3 = {1e-18};
    const auto full = solve(p); check(full.success,full.message); check(full.accepted_steps==3,"three BDF steps");
    const auto volume = cell_volumes(p.mesh);
    for (std::size_t c=0;c<2;++c) {
        near(full.thermal_energy_integrals_J.at("")[c],1e-18*volume[c]*.3,1e-34,"sub-ULP heat stays nonzero");
        near(full.state.temperature_K[c],300,0,"tiny heat is unresolved in absolute temperature");
        check(full.thermal_energy_residual_bound_J.at("")[c] >= full.thermal_energy_integrals_J.at("")[c],"temperature-source defect has an explicit bound");
    }
    total_check(full);
    p.options.end_time_s=.1; const auto first=solve(p); check(first.success,first.message);
    p.options.end_time_s=.3; p.initial_checkpoint=first.checkpoint; const auto resumed=solve(p); check(resumed.success,resumed.message);
    check(resumed.thermal_energy_integrals_J==full.thermal_energy_integrals_J,"restart bit-identical energy history");
    check(resumed.thermal_energy_residual_bound_J==full.thermal_energy_residual_bound_J,"restart bit-identical residual history");
    check(resumed.checkpoint.previous_thermal_energy_integrals_J==full.checkpoint.previous_thermal_energy_integrals_J,"previous BDF energy retained");
    p.initial_checkpoint.reset(); p.options.maximum_steps=1; const auto partial=solve(p);
    check(!partial.success && partial.accepted_steps==1,"bounded partial result retains only accepted step");
    check(partial.thermal_energy_integrals_J==first.thermal_energy_integrals_J,"unaccepted time contributes no heat");
    p.options.maximum_steps=100; p.initial_checkpoint=first.checkpoint;
    p.initial_checkpoint->thermal_energy_integrals_J[""][0]=std::numeric_limits<double>::quiet_NaN();
    rejects([&]{(void)solve(p);},"nonfinite checkpoint energy rejected");
    p.initial_checkpoint=first.checkpoint; p.initial_checkpoint->previous_thermal_energy_residual_bound_J[""][0]=-1;
    rejects([&]{(void)solve(p);},"negative checkpoint bound rejected");
    p.initial_checkpoint=first.checkpoint; p.initial_checkpoint->thermal_energy_integrals_J.clear();
    rejects([&]{(void)solve(p);},"missing checkpoint source history rejected");
    p.initial_checkpoint=first.checkpoint; p.initial_checkpoint->previous_thermal_energy_residual_bound_J[""][0]=1;
    rejects([&]{(void)solve(p);},"nonmonotone residual-bound history rejected");
    p=base(1); p.thermal.heating_W_m3={1e-18}; p.options.end_time_s=200;
    const auto long_run=solve(p); check(long_run.success,long_run.message);
    check(long_run.accepted_steps>=1999 && long_run.thermal_energy_residual_bound_J.at("")[0]<1e-7,"BDF residual bound remains zero-stable over 2000 steps");
}
void conduction_and_phase_exchange() {
    auto p=base(); p.thermal.initial_temperature_K={400,300}; p.thermal.conductivity_W_m_K={.2};
    const auto r=solve(p); check(r.success,r.message); const auto v=cell_volumes(p.mesh);
    check(r.thermal_energy_integrals_J.at("")[0]<0 && r.thermal_energy_integrals_J.at("")[1]>0,"signed per-cell Fourier transfer");
    for(std::size_t c=0;c<2;++c) near(r.thermal_energy_integrals_J.at("")[c],2*v[c]*(r.state.temperature_K[c]-p.thermal.initial_temperature_K[c]),r.thermal_energy_residual_bound_J.at("")[c],"conduction temperature audit");
    near(std::accumulate(r.thermal_energy_integrals_J.at("").begin(),r.thermal_energy_integrals_J.at("").end(),0.),0,1e-14,"internal conduction conserves heat"); total_check(r);
    p=base(); auto liquid=p.mechanism.species[0]; liquid.id="L"; liquid.phase="liquid"; p.mechanism.species.push_back(liquid);
    p.transport.resize(2); p.initial_densities_m3={1e15,0,0,1e15}; p.phase_fractions={{"gas",{1,0}},{"liquid",{0,1}}};
    p.thermal.heat_capacity_J_m3_K.clear(); p.thermal.initial_temperature_K.clear();
    p.thermal.phases["gas"]={{2},{},{400},{},{}}; p.thermal.phases["liquid"]={{3},{},{300},{},{}};
    p.interface_heat_transfer={{"gas","liquid",.1}};
    const auto exchanged=solve(p); check(exchanged.success,exchanged.message);
    const auto& gas=exchanged.thermal_energy_integrals_J.at("gas"); const auto& liquid_heat=exchanged.thermal_energy_integrals_J.at("liquid");
    check(gas[0]<0 && liquid_heat[1]>0 && gas[1]==0 && liquid_heat[0]==0,"interface heat has exact phase/cell owners");
    near(gas[0]+liquid_heat[1],0,1e-14,"contact exchange is conservative"); total_check(exchanged);
    p.initial_checkpoint=exchanged.checkpoint; p.initial_checkpoint->thermal_energy_integrals_J["gas"][1]=1;
    rejects([&]{(void)solve(p);},"absent phase cannot own historical heat");
    p.initial_checkpoint.reset(); p.interface_heat_transfer.clear();
    chemistry::Reaction contact; contact.id="surface heat"; contact.reactants={{0,1}}; contact.products={{1,1}};
    contact.basis_phase="gas"; contact.basis_interface="surface"; contact.rate.kind=chemistry::RateKind::Parameter; contact.rate.key="speed";
    contact.energy_eV_per_event={{"gas/internal",-2},{"liquid/thermal",2}}; contact.check_energy_balance=true;
    p.mechanism.reactions={contact}; p.environment.parameters["speed"]=.1; p.face_reactions={{contact.id,"gas","liquid",""}};
    p.thermal.phases["liquid"].heat_reservoirs={"liquid/thermal"}; p.initial_densities_m3={1e15,0,0,0};
    const auto reacted=solve(p); check(reacted.success,reacted.message);
    near(reacted.thermal_energy_integrals_J.at("liquid")[1],reacted.particle_counts[1]*2*qe,1e-17,"face chemical energy uses receiving phase and cell volume");
    check(reacted.thermal_energy_integrals_J.at("liquid")[0]==0 && reacted.thermal_energy_integrals_J.at("gas")[0]==0,"face chemistry does not heat wrong phase"); total_check(reacted);
    p.mechanism.reactions.clear(); p.face_reactions.clear(); p.thermal.phases["liquid"].heat_reservoirs.clear();
    p.phase_fractions={{"gas",{.25,.75}},{"liquid",{.75,.25}}};
    p.initial_densities_m3={1e15,1e15,1e15,1e15}; p.thermal.phases["gas"].heating_W_m3={1e-18};
    const auto mixed=solve(p); check(mixed.success,mixed.message);
    for(std::size_t c=0;c<2;++c) near(mixed.thermal_energy_integrals_J.at("gas")[c],1e-18*v[c]*.3*p.phase_fractions.at("gas")[c],1e-34,"phase-volume and depth counted exactly once"); total_check(mixed);
}
void radiation_and_chemical_rejections() {
    auto p=base(1); p.options.time_step_s=1e-10; p.options.end_time_s=1e-10; p.thermal.heat_capacity_J_m3_K={1e-6};
    RadiationGroup g; g.id="absorbed"; g.photon_energy_eV=2; g.absorption_m1=10; g.initial_density_m3={1e15}; p.radiation={g};
    const auto r=solve(p); check(r.success,r.message);
    near(r.thermal_energy_integrals_J.at("")[0],p.options.time_step_s*g.speed_m_s*g.absorption_m1*r.state.photon_densities_m3[0]*2*qe*.3,1e-20,"radiation absorption feeds direct thermal ledger");
    near(r.thermal_energy_integrals_J.at("")[0],(1e15-r.state.photon_densities_m3[0])*2*qe*.3,1e-12,"photon storage agrees within its nonlinear residual tolerance"); total_check(r);
    p=base(1); auto product=p.mechanism.species[0]; product.id="product"; p.mechanism.species.push_back(product); p.transport.resize(2); p.initial_densities_m3={1e15,0};
    chemistry::Reaction reaction; reaction.id="decay heat"; reaction.reactants={{0,1}}; reaction.products={{1,1}};
    reaction.rate.kind=chemistry::RateKind::Constant; reaction.rate.A=10;
    reaction.energy_eV_per_event={{"gas/thermal",2},{"gas/internal",-2}}; reaction.check_energy_balance=true;
    p.mechanism.reactions={reaction}; p.thermal.heat_reservoirs={"gas/thermal"};
    p.options.adaptive_time=true; p.options.temporal_relative_tolerance=1e-5; p.options.minimum_time_step_s=1e-8;
    const auto reacted=solve(p); check(reacted.success,reacted.message); check(reacted.rejected_steps>0,"fixture exercises rejected trials");
    near(reacted.thermal_energy_integrals_J.at("")[0],reacted.state.densities_m3[1]*.3*2*qe,1e-13,"only accepted chemical events enter integrated heat");
    near(reacted.thermal_energy_integrals_J.at("")[0],reacted.chemical_energy_integrals_J.at("gas/thermal"),1e-17,"thermal source equals authored chemical reservoir"); total_check(reacted);
}
void selected_ion_joule() {
    auto p=base(4); p.mechanism.species={{"e","gas",{},-1,9.109e-31,true},{"ion","gas",{{"N",1}},1,2.325e-26,true}};
    p.transport={{0,0},{1e-4,1e-5}}; p.initial_densities_m3.assign(8,1e7);
    p.boundaries[1].potential_V=10; p.boundaries[0].absorbing=true; p.boundaries[1].absorbing=true;
    p.options.time_step_s=1e-4; p.options.end_time_s=3e-4; p.thermal.joule_species={"ion"};
    const auto r=solve(p); check(r.success,r.message); double heat=0; for(double q:r.thermal_energy_integrals_J.at(""))heat+=q;
    check(heat>0,"selected ion interior and electrode work produces heat");
    near(heat,r.chemical_energy_integrals_J.at("Electrical/particle_work"),heat*1e-12,"selected mobile ion work enters thermal ledger once"); total_check(r);
}
Json request() {
    return {{"mechanism",{{"schema_version",1},{"id","thermal JSON fixture"},{"species",Json::array({{{"id","N"},{"phase","gas"},{"elements",{{"N",1}}},{"charge",0},{"mass_kg",2.325e-26}}})},{"reactions",Json::array()}}},
        {"mesh",{{"type","structured"},{"dimension",2},{"shape",{1,1,1}},{"extent_m",{1,1,.3}}}},
        {"transport",{{"N",{{"mobility_m2_V_s",0},{"diffusion_m2_s",0}}}}},{"initial_densities_m3",{{"N",1e15}}},
        {"boundaries",{{"xmin",{{"kind","electrode"},{"potential_V",0}}},{"xmax",{{"kind","electrode"},{"potential_V",0}}}}},
        {"thermal",{{"heat_capacity_J_m3_K",2},{"initial_temperature_K",300},{"heating_W_m3",1e-18}}},
        {"time",{{"time_step_s",.1},{"end_time_s",.2},{"adaptive",false}}}};
}
void json_restart_and_reconfigure() {
    auto old=request(); const auto first=solve_json(old); check(first.at("success"),"JSON thermal solve");
    check(first.at("thermal_energy_ledger").at("available"),"explicit ledger availability");
    check(first.at("checkpoint").at("schema_version")==3,"checkpoint schema version");
    check(first.at("thermal_energy_integrals_J").at("").at(0)>0,"tiny JSON source survives serialization");
    auto resumed=old; resumed["checkpoint"]=first.at("checkpoint"); resumed["time"]["end_time_s"]=.3;
    const auto continued=solve_json(resumed); check(continued.at("success"),"JSON source-history restart");
    auto legacy=resumed; legacy["checkpoint"].erase("thermal_energy_integrals_J");
    rejects([&]{(void)solve_json(legacy);},"schema 3 missing history cannot silently fabricate source energy");
    auto unavailable=resumed;
    for(const auto& key:{"thermal_energy_integrals_J","previous_thermal_energy_integrals_J","thermal_energy_residual_bound_J","previous_thermal_energy_residual_bound_J"})
        unavailable["checkpoint"][key]=Json::object();
    unavailable["checkpoint"]["thermal_energy_ledger_available"]=false;
    const auto physical=solve_json(unavailable);check(physical.at("success"),"unavailable history still permits physical restart");
    check(physical.at("temperature_K")==continued.at("temperature_K"),"thermal history availability does not change state evolution");
    check(!physical.at("thermal_energy_ledger").at("available")&&!physical.at("checkpoint").at("thermal_energy_ledger_available"),"unavailable status survives serial continuation and JSON");
    check(physical.at("thermal_energy_integrals_J").empty()&&physical.at("thermal_energy_residual_bound_J").empty()
        &&!physical.at("chemical_energy_integrals_J").contains("Thermal/net_energy"),"no fabricated or partial cumulative heat is exported");
    for(int version:{1,2}){
        auto old_schema=unavailable;old_schema["checkpoint"]["schema_version"]=version;old_schema["checkpoint"].erase("thermal_energy_ledger_available");
        for(const auto& key:{"thermal_energy_integrals_J","previous_thermal_energy_integrals_J","thermal_energy_residual_bound_J","previous_thermal_energy_residual_bound_J"})old_schema["checkpoint"].erase(key);
        const auto old_result=solve_json(old_schema);check(old_result.at("success")&&!old_result.at("thermal_energy_ledger").at("available"),"legacy thermal checkpoint continues with explicit unavailable history");
        check(old_result.at("temperature_K")==continued.at("temperature_K"),"legacy backend switch preserves physical temperature");
    }
    unavailable["checkpoint"]["thermal_energy_integrals_J"][""]={1.};
    rejects([&]{(void)solve_json(unavailable);},"unavailable history cannot carry misleading partial thermal maps");
    auto next=old; next["thermal"]["initial_temperature_K"]=first.at("temperature_K");
    const auto fresh=reconfigure_json({{"previous_problem",old},{"checkpoint",first.at("checkpoint")},{"problem",next}});
    for(const auto& key:{"thermal_energy_integrals_J","previous_thermal_energy_integrals_J","thermal_energy_residual_bound_J","previous_thermal_energy_residual_bound_J"})
        near(fresh.at("checkpoint").at(key).at("").at(0),0,0,"reconfigure resets source and bound histories");
    next["checkpoint"]=fresh.at("checkpoint"); const auto repeat=solve_json(next);
    check(repeat.at("thermal_energy_integrals_J")==first.at("thermal_energy_integrals_J"),"reconfigured slice does not replay old heat");
}
void declared_direct_poisson() {
    auto p=base(9); p.options.linear_solver="direct"; p.options.linear_max_iterations=1;
    p.boundaries[1].potential_V=12; p.permittivity_F_m={1e-11,2e-11,5e-11,3e-11,8e-11,2e-11,4e-11,7e-11,3e-11};
    if (!backend::sparse_direct_available()) {
        rejects([&]{(void)solve_poisson(p,std::vector<double>(9,0));},"direct Poisson requires available direct backend"); return;
    }
    const auto potential=solve_poisson(p,std::vector<double>(9,0)); check(potential.size()==9,"direct Poisson bypasses one-iteration Krylov cap");
    auto j=request(); j["mesh"]["shape"]={9,1,1}; j["permittivity_F_m"]=p.permittivity_F_m;
    j["boundaries"]["xmax"]["potential_V"]=12; j["solver"]={{"linear_solver","direct"},{"linear_max_iterations",1}};
    const auto r=solve_json(j); check(r.at("success"),"declared direct solver is honored during initialization and Newton");
    auto next=j; next["thermal"]["initial_temperature_K"]=r.at("temperature_K");
    const auto update=reconfigure_json({{"previous_problem",j},{"checkpoint",r.at("checkpoint")},{"problem",next}});
    near(update.at("audit").at("material_work_J"),0,1e-23,"identical direct field reconfiguration has no material work");
    for(std::size_t c=0;c<9;++c) near(update.at("potential_V").at(c),r.at("potential_V").at(c),4e-14,"identical direct reconfigure preserves field to arithmetic precision");
}
} // namespace
int main() {
    try { tiny_source_and_restart(); conduction_and_phase_exchange(); radiation_and_chemical_rejections(); selected_ion_joule(); json_restart_and_reconfigure(); declared_direct_poisson();
        std::cout << "thermal ledger: sub-ULP sources, BDF/restart, accepted-only reactions, phase volumes, conduction/contact/radiation, JSON and reconfigure passed\n"; return 0;
    } catch(const std::exception& error) { std::cerr << error.what() << '\n'; return 1; }
}
