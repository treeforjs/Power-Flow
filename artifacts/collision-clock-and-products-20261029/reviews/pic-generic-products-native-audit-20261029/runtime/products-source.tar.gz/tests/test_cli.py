"""Black-box native CLI checks; run with the Raikou executable as argument."""

import json
import math
from pathlib import Path
import subprocess
import sys
import unittest


EXECUTABLE = str(Path(sys.argv.pop(1)).resolve())


class NativeCliTests(unittest.TestCase):
    def run_cli(self, *arguments, success=True):
        result = subprocess.run([EXECUTABLE, *map(str, arguments)], capture_output=True, text=True, timeout=30)
        if success:
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(result.stderr, "")
        else:
            self.assertNotEqual(result.returncode, 0)
            self.assertEqual(result.stdout, "")
            self.assertTrue(result.stderr.strip())
        return result

    def result(self, *arguments):
        def reject_constant(value):
            self.fail(f"Non-finite JSON constant: {value}")
        return json.loads(self.run_cli(*arguments).stdout, parse_constant=reject_constant)

    def test_help_and_version(self):
        self.assertIn("1.0.0", self.run_cli("--version").stdout)
        self.assertIn("Usage:", self.run_cli("--help").stdout)
        self.assertIn("--dt", self.run_cli("spark", "--help").stdout)

    def test_evaluate_molecular_formula_and_zero_path(self):
        result = self.result("evaluate")
        self.assertEqual(result["populations_m3"][0], 1e20)
        self.assertEqual(len(result["populations_m3"]), 5)
        expected = (6.62607015e-34 * 299792458.0 / 160.8e-9 / (4 * math.pi)
                    * 1e19 * 5e19 * 8e-16 * math.exp(-11.5 / 2.5) * .005)
        self.assertAlmostEqual(result["molecular_lyman_proxy_W_m2_sr"] / expected, 1.0, places=12)
        self.assertGreater(result["lyman_alpha_radiance_W_m2_sr"], 0)
        zero = self.result("evaluate", "--path-length-m", "0")
        self.assertEqual(zero["lyman_alpha_radiance_W_m2_sr"], 0)
        self.assertEqual(zero["tau_0_lyman_alpha"], 0)

    def test_rates_detailed_balance(self):
        result = self.result("rates", "--te-ev=3.5")
        for lower in range(5):
            self.assertEqual(len(result["excitation_m3_s"][lower]), 5)
            for upper in range(5):
                excitation = result["excitation_m3_s"][lower][upper]
                if lower >= upper:
                    self.assertEqual(excitation, 0)
                else:
                    gap = 13.605693122994 * (1 / (lower + 1)**2 - 1 / (upper + 1)**2)
                    expected = excitation * (lower + 1)**2 / (upper + 1)**2 * math.exp(gap / 3.5)
                    self.assertAlmostEqual(result["deexcitation_m3_s"][upper][lower] / expected, 1.0, places=12)

    def test_fit_synthetic_observation(self):
        source = self.result("evaluate")
        lyman, molecular = source["lyman_alpha_radiance_W_m2_sr"], source["molecular_lyman_proxy_W_m2_sr"]
        fitted = self.result("fit", "--ly-alpha", lyman, "--ly-alpha-sigma", .1 * lyman,
                             "--molecular", molecular, "--molecular-sigma", .1 * molecular)
        self.assertTrue(math.isfinite(fitted["chi2_reduced"]))
        self.assertTrue(.5 <= fitted["Te_eV"] <= 20)
        self.assertTrue(1e17 <= fitted["ne_m3"] <= 1e22)
        self.assertGreater(fitted["iterations"], 0)

    def test_spark_steps_and_continuation(self):
        result = self.result("spark", "--dt", "1e-8", "--steps", "10")
        self.assertAlmostEqual(result["time_s"], 1e-7)
        self.assertGreater(result["deposited_energy_J"], 0)
        self.assertGreaterEqual(result["channel_radius_m"], 1e-4)
        one = self.result("step", "--dt", "1e-8")
        expected_current = 20000 * math.sin(math.pi * 1e-8 / 5e-6) * math.exp(-2e-8 / 5e-6)
        self.assertAlmostEqual(one["current_A"] / expected_current, 1.0, places=12)

    def test_invalid_arguments(self):
        cases = [
            ["unknown"], ["evaluate", "--wat", "1"], ["evaluate", "--te-ev"],
            ["evaluate", "--te-ev", "abc"], ["evaluate", "--te-ev", "2.5junk"],
            ["evaluate", "--te-ev", "NaN"], ["evaluate", "--te-ev", "inf"],
            ["evaluate", "--te-ev", "1e9999"], ["evaluate", "--te-ev", "-1"],
            ["evaluate", "--ne-m3", "-1"], ["evaluate", "--te-ev=2", "--te-ev=3"],
            ["evaluate", "--te-ev="], ["rates"], ["rates", "--te-ev", "0"],
            ["spark", "--dt", "0"], ["spark", "--dt", "1e-8", "--steps", "1.5"],
            ["spark", "--dt", "1e-8", "--steps", "0"],
            ["spark", "--dt", "1e-8", "--plasma-conductivity", "0"],
            ["fit", "--ly-alpha", "1", "--ly-alpha-sigma", "0", "--molecular", "1", "--molecular-sigma", ".1"],
            ["--version", "trailing"],
        ]
        for arguments in cases:
            with self.subTest(arguments=arguments):
                self.run_cli(*arguments, success=False)


if __name__ == "__main__":
    unittest.main()
