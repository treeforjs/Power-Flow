#include "raikou/distributed.h"
#include "raikou/runtime.h"
#include <algorithm>
#include <cmath>
#include <iostream>
#include <stdexcept>
#include <string>

namespace {
void require(bool value,const char* message){if(!value)throw std::runtime_error(message);}
void close(double a,double b,double relative,const char* message){
    require(std::abs(a-b)<=relative*std::max({1.0,std::abs(a),std::abs(b)}),message);
}
}

int main(int argc,char** argv){
    try{
        bool mpi=false;for(int i=1;i<argc;++i)mpi=mpi||std::string(argv[i])=="--mpi";
        raikou::backend::Runtime runtime(mpi);
        raikou::backend::ExecutionOptions execution;execution.mpi=mpi;
        const auto rows=raikou::backend::distributed_partition(2,execution);
        const raikou::backend::DistributedHalo control(rows,{},execution);
        auto request=raikou::Json::parse(R"({
            "mechanism":{"id":"owned-json-decay","species":[
                {"id":"A","elements":{"H":1}},{"id":"B","elements":{"H":1}}],
                "reactions":[{"id":"decay","reactants":{"A":1},"products":{"B":1},
                    "rate":{"type":"constant","A":2}}]},
            "mesh":{"dimension":2,"shape":[2,1,1],"extent_m":[1,1,1]},
            "initial_densities_m3":{"A":0,"B":0},"transport":{},
            "boundaries":{"xmin":{"kind":"electrode","potential_V":0},
                "xmax":{"kind":"electrode","potential_V":1}},
            "time":{"time_step_s":0.005,"end_time_s":0.02,"adaptive":false,"bdf2":true}
        })");
        std::vector<double> initial;
        for(std::size_t i=0;i<rows.local_rows;++i)
            initial.push_back(1e6*(1.0+0.2*static_cast<double>(rows.row_begin+i)));
        request["execution"]={{"mpi",mpi},{"threads",2}};
        request["local_initial"]={{"cell_begin",rows.row_begin},{"cell_count",rows.local_rows},
            {"densities_m3",{{"A",initial}}}};
        const auto first=raikou::execute("spatial.solve_distributed",request);
        require(first.at("success").get<bool>(),"owned JSON initial solve failed");
        require(first.at("cell_count")==rows.local_rows,"returned nonowned cells");
        require(first.at("state").at("representation")=="owned_cell_dof_v1","missing ownership schema");
        require(first.at("state").at("owned_values").size()==first.at("storage").at("local_unknowns").get<std::size_t>(),"storage contract differs from local state");
        require(first.at("densities_m3").at("A").size()==rows.local_rows,"named density is not owned");
        close(first.at("particle_counts").at("A").get<double>()+first.at("particle_counts").at("B").get<double>(),1.1e6,1e-10,"global inventory was overcounted");
        for(std::size_t i=0;i<rows.local_rows;++i)
            close(first.at("potential_V").at(i).get<double>(),0.25+0.5*static_cast<double>(rows.row_begin+i),1e-8,"owned Poisson potential differs");

        auto restart=request;restart.erase("local_initial");restart["checkpoint"]=first.at("checkpoint");
        restart["time"]["end_time_s"]=0.04;
        const auto resumed=raikou::execute("spatial.solve_distributed",restart);
        auto full=request;full["time"]["end_time_s"]=0.04;
        const auto reference=raikou::execute("spatial.solve_distributed",full);
        require(resumed.at("success").get<bool>()&&reference.at("success").get<bool>(),"owned JSON restart failed");
        const auto actual=resumed.at("state").at("owned_values").get<std::vector<double>>();
        const auto expected=reference.at("state").at("owned_values").get<std::vector<double>>();
        require(actual.size()==expected.size(),"restart changed ownership");
        for(std::size_t i=0;i<actual.size();++i)close(actual[i],expected[i],2e-10,"owned JSON BDF restart differs");

        for(int damage=0;damage<6;++damage){
            auto bad=request;
            if(control.rank()==control.ranks()-1){
                if(damage==0)bad["mechanism"]["species"][0].erase("id");
                if(damage==1)bad["local_initial"]["densities_m3"]["A"]="invalid";
                if(damage==2)bad["initial_densities_m3"]["A"]=raikou::Json::array({1,2});
                if(damage==3)bad["execution"]["device"]=42;
                if(damage==4)bad["local_initial"]["densities_m3"]["unknown"]=raikou::Json::array();
                if(damage==5){bad.erase("local_initial");bad["checkpoint"]=first.at("checkpoint");bad["checkpoint"]["state"]["representation"]="global";}
            }
            bool refused=false;try{(void)raikou::execute("spatial.solve_distributed",bad);}catch(const std::exception&){refused=true;}
            require(refused,"asymmetric spatial JSON input did not fail collectively");
            require(raikou::execute("spatial.solve_distributed",request).at("success").get<bool>(),"owned JSON did not recover after input failure");
        }
        auto inherited=request;inherited["solver"]={{"mpi",mpi}};inherited["execution"].erase("mpi");
        require(raikou::execute("spatial.solve_distributed",inherited).at("success").get<bool>(),"partial execution block lost solver MPI settings");
        auto malformed=inherited;
        if(control.rank()==control.ranks()-1)malformed["local_initial"]["densities_m3"]["A"]="invalid";
        bool refused=false;try{(void)raikou::execute("spatial.solve_distributed",malformed);}catch(const std::exception&){refused=true;}
        require(refused,"inherited MPI settings did not propagate asymmetric parse failure");
        for(int damage=0;damage<2;++damage){
            auto invalid_history=request;invalid_history.erase("local_initial");invalid_history["checkpoint"]=first.at("checkpoint");
            if(rows.local_rows>0){
                auto& previous=invalid_history["checkpoint"]["previous_state"]["owned_values"];
                if(damage==0)previous.at(0)=-1;
                else previous.at(2)=previous.at(2).get<double>()+100;
            }
            bool rejected=false;try{(void)raikou::execute("spatial.solve_distributed",invalid_history);}catch(const std::exception&){rejected=true;}
            require(rejected,"invalid previous physical state was accepted on a no-step restart");
        }
        auto kinetic=raikou::Json::parse(R"({
            "mechanism":{"id":"owned-json-Legendre","species":[
                {"id":"H","elements":{"H":1}},
                {"id":"H+","elements":{"H":1},"charge":1},
                {"id":"e","charge":-1,"mass_kg":9.1093837015e-31}],"reactions":[]},
            "mesh":{"dimension":2,"shape":[2,1,1],"extent_m":[0.001,0.001,0.001]},
            "initial_densities_m3":{"H":1e20,"H+":1e8,"e":1e8},"transport":{},
            "boundaries":{"xmin":{"kind":"electrode"},"xmax":{"kind":"electrode"}},
            "time":{"time_step_s":1e-12,"end_time_s":0,"adaptive":false,"bdf2":false},
            "electron_closure":{"mode":"transient_boltzmann","electron_species":"e",
                "strict_event_mapping":true,"initial_mean_energy_eV":1,"fixed_field_axis":[1,0,0],
                "grid":{"cells":16,"max_energy_ev":8,"power":2,"legendre_terms":3},
                "processes":[{"kind":"elastic","label":"elastic","target":"H","mass_ratio":1e-5,
                    "energy_ev":[0,1000],"cross_section_m2":[1e-19,1e-19]}]}
        })");
        kinetic["execution"]={{"mpi",mpi}};
        const auto kinetic_prefix=raikou::execute("spatial.solve_distributed",kinetic);
        require(kinetic_prefix.at("success").get<bool>(),"owned Legendre initialization failed");
        kinetic["checkpoint"]=kinetic_prefix.at("checkpoint");
        const auto modify_isotropic=[&](raikou::Json& electrons,bool numerical_tail){
            const auto& grid=electrons.at("grid");const auto cells=grid.at("cells").get<std::size_t>(),stride=grid.at("legendre_terms").get<std::size_t>();
            auto modes=electrons.at("density_modes").get<std::vector<double>>();
            const auto edge=[&](std::size_t i){return grid.at("max_energy_ev").get<double>()*std::pow(static_cast<double>(i)/static_cast<double>(cells),grid.at("power").get<double>());};
            const auto weight=[&](std::size_t i){return (2./3)*(std::pow(edge(i+1),1.5)-std::pow(edge(i),1.5));};
            double before=0,peak=0;for(std::size_t i=0;i<cells;++i){before+=modes[i*stride]*weight(i);peak=std::max(peak,std::abs(modes[i*stride]));}
            const auto cell=numerical_tail?cells-1:cells/2;const double next=numerical_tail?-1e-12*peak:-modes[cell*stride];
            modes[0]+=(modes[cell*stride]-next)*weight(cell)/weight(0);modes[cell*stride]=next;
            double after=0;for(std::size_t i=0;i<cells;++i)after+=modes[i*stride]*weight(i);
            close(after,before,1e-12,"corrupt Legendre state must preserve the independent density moment");
            electrons["density_modes"]=modes;
        };
        auto noisy=kinetic;
        for(const auto* history:{"state","previous_state"})for(auto& electrons:noisy["checkpoint"][history]["electrons"])modify_isotropic(electrons,true);
        const auto retained=raikou::execute("spatial.solve_distributed",noisy);
        require(retained.at("success").get<bool>(),"owned JSON no-step restart rejected a numerical Legendre tail");
        noisy["time"]["end_time_s"]=1e-12;
        require(raikou::execute("spatial.solve_distributed",noisy).at("success").get<bool>(),"owned JSON numerical tail cannot advance");
        for(const auto* history:{"state","previous_state"})for(bool padding:{false,true}){
            auto invalid=kinetic;
            if(control.rank()==control.ranks()-1){auto& electrons=invalid["checkpoint"][history]["electrons"].at(0);
                if(padding){const auto cells=electrons["grid"]["cells"].get<std::size_t>(),stride=electrons["grid"]["legendre_terms"].get<std::size_t>();electrons["density_modes"][(cells-1)*stride+stride-1]=1e6;}
                else modify_isotropic(electrons,false);
            }
            bool rejected=false;try{(void)raikou::execute("spatial.solve_distributed",invalid);}catch(const std::exception&){rejected=true;}
            require(rejected,padding?"owned JSON no-step restart accepted odd padding":"owned JSON no-step restart accepted material negative F0");
            require(raikou::execute("spatial.solve_distributed",kinetic).at("success").get<bool>(),"owned Legendre checkpoint did not recover after invalid modes");
        }
        std::cout<<"Owned spatial JSON state, restart, validation and recovery passed\n";
        return 0;
    }catch(const std::exception& error){std::cerr<<error.what()<<'\n';return 1;}
}
