#include "raikou/spatial_distributed.h"
#include <algorithm>
#include <cmath>
#include <iostream>
#include <stdexcept>
#include <string>

namespace {
using namespace raikou;
using namespace spatial;
constexpr double qe=1.602176634e-19,epsilon=8.8541878128e-12;
void check(bool value,const std::string& message){if(!value)throw std::runtime_error(message);}
void near(double actual,double expected,double relative,double absolute,const std::string& message){
    check(std::isfinite(actual)&&std::abs(actual-expected)<=absolute+relative*std::max(std::abs(actual),std::abs(expected)),message);
}
template<class Action>void collectively(const backend::DistributedHalo& control,Action action){
    std::string error;try{action();}catch(const std::exception& exception){error=exception.what();}control.collective_require(error);
}
void charged_circuit(bool mpi,bool dielectric){
    Problem p;p.mesh.shape={3,4,1};p.mesh.extent_m={.001,.002,.001};
    p.mechanism.id="manufactured charged circuit";
    p.mechanism.species={{"H+","gas",{{"H",1}},1,1.67e-27,true},{"e","gas",{},-1,9.109e-31,true}};
    p.transport={{0,0},{.001,.01}};p.initial_densities_m3.assign(24,1e12);
    p.boundaries[0].kind=BoundaryKind::Electrode;
    p.boundaries[1].kind=dielectric?BoundaryKind::Dielectric:BoundaryKind::Electrode;
    p.boundaries[1].potential_V=10;p.boundaries[1].absorbing=true;p.boundaries[1].capacitance_F_m2=1e-6;
    p.circuit.enabled=true;p.circuit.initial_voltage_V=10;p.circuit.source_voltage_V=10;
    p.circuit.series_resistance_ohm=1e6;p.circuit.external_capacitance_F=1e-12;
    // Small authored capacity makes the independent J.E heat ledger observable.
    p.thermal.enabled=true;p.thermal.heat_capacity_J_m3_K={1e-10};p.thermal.initial_temperature_K={300};p.thermal.joule_species={"e"};
    p.options.time_step_s=1e-8;p.options.end_time_s=3e-8;p.options.adaptive_time=false;p.options.bdf2=false;
    p.options.relative_tolerance=1e-10;p.options.potential_tolerance_V=1e-12;
    p.options.surface_charge_tolerance_C_m2=1e-23;p.options.circuit_charge_tolerance_C=1e-25;p.options.absolute_density_tolerance_m3=1e-3;
    const auto serial=solve(p);check(serial.success,"serial charged-circuit reference: "+serial.message);
    p.options.mpi=mpi;auto model=std::make_shared<Problem>(p);model->initial_densities_m3={1e12,1e12};
    const auto numerical=solve_distributed(DistributedProblem{.model=model});
    backend::ExecutionOptions execution;execution.mpi=mpi;
    const auto geometry=mesh::geometry(p.mesh);std::vector<unsigned char> wall_mask(geometry.walls.size());
    for(std::size_t w=0;w<wall_mask.size();++w)wall_mask[w]=static_cast<unsigned char>(p.boundaries[static_cast<std::size_t>(geometry.walls[w].side)].kind==BoundaryKind::Dielectric);
    partition::DofLayout layout(geometry,2,0,1,wall_mask,true,execution);const auto& control=layout.control_halo();
    const auto value=[&](backend::GlobalIndex id){return numerical.state.owned_values.at(static_cast<std::size_t>(id-numerical.state.rows.row_begin));};
    double local_electrode_charge=0;
    collectively(control,[&]{
        check(numerical.success,"owned charged circuit: "+numerical.message);
        check(numerical.accepted_steps==3,"three backward-Euler circuit steps complete");
        for(std::size_t c=numerical.state.cells.begin;c<numerical.state.cells.begin+numerical.state.cells.count;++c){
            for(std::size_t species=0;species<2;++species)near(value(layout.cell_dof(c,species)),serial.state.densities_m3[2*c+species],2e-9,1e-3,"charged circuit species parity");
            near(value(layout.cell_dof(c,2)),serial.state.potential_V[c],2e-9,1e-10,"charged circuit potential parity");
            near(value(layout.cell_dof(c,3)),serial.state.temperature_K[c],2e-9,1e-7,"charged circuit thermal parity");
        }
        std::size_t surface=0;
        for(std::size_t w=0;w<geometry.walls.size();++w){const auto& wall=geometry.walls[w];
            if(wall.side!=1)continue;
            if(layout.owns_cell(wall.cell)){
                if(dielectric){
                    near(value(layout.sigma_dof(w)),serial.state.surface_charge_C_m2[surface],2e-8,1e-22,"charged circuit surface-charge parity");
                    local_electrode_charge+=p.boundaries[1].capacitance_F_m2*wall.area*(numerical.samples.back().driven_voltage_V-value(layout.dielectric_dof(w)));
                }else local_electrode_charge+=epsilon*wall.area*(numerical.samples.back().driven_voltage_V-value(layout.cell_dof(wall.cell,2)))/wall.normal_distance;
            }
            if(dielectric)++surface;
        }
    });
    const double final_electrode_charge=control.global_sum(local_electrode_charge);
    collectively(control,[&]{
        const double volume=p.mesh.extent_m[0]*p.mesh.extent_m[1]*p.mesh.extent_m[2],initial_particles=1e12*volume;
        for(std::size_t species=0;species<2;++species)
            near(numerical.particle_counts[species]+numerical.particles_collected_at_boundaries[species],initial_particles,2e-10,1e-8,"charged circuit particle inventory plus boundary ledger");
        const double gas_charge=qe*(numerical.particle_counts[0]-numerical.particle_counts[1]);
        const double collected_charge=qe*(numerical.particles_collected_at_boundaries[0]-numerical.particles_collected_at_boundaries[1]);
        near(gas_charge+collected_charge,0,0,2e-24,"gas plus collected electrode charge conserves the initially neutral inventory");
        if(dielectric)near(gas_charge+numerical.samples.back().surface_charge_C,0,0,2e-24,"gas plus dielectric free surface charge is conserved");
        const double initial_thermal=volume*p.thermal.heat_capacity_J_m3_K[0]*300;
        const double electric_work=numerical.chemical_energy_integrals_J.at("Electrical/particle_work");
        check(std::abs(electric_work)>1e-21,"Joule work is large enough to resolve independently of initial heat");
        near(numerical.samples.back().thermal_energy_J-initial_thermal,electric_work,2e-6,2e-26,"thermal change equals the independent integrated face J.E ledger");
        const double area=p.mesh.extent_m[1]*p.mesh.extent_m[2];
        const double gap_capacitance=epsilon*area/p.mesh.extent_m[0];
        const double initial_electrode_charge=p.circuit.initial_voltage_V*(dielectric?area/(p.mesh.extent_m[0]/epsilon+1/p.boundaries[1].capacitance_F_m2):gap_capacitance);
        double source_charge=0;for(const auto& sample:numerical.samples)source_charge+=p.options.time_step_s*sample.source_current_A;
        const double voltage_change=numerical.samples.back().driven_voltage_V-p.circuit.initial_voltage_V;
        // Absorption charges the dielectric free surface; it does not conduct
        // that current directly through the backing electrode circuit.
        near(final_electrode_charge-initial_electrode_charge+p.circuit.external_capacitance_F*voltage_change-(dielectric?0:collected_charge),source_charge,2e-5,3e-24,
            "gap/backing charge plus external capacitance equals source and absorbed plasma charge exactly once");
    });
}
void ideal_source(bool mpi,bool dielectric,bool bdf2){
    Problem p;p.mesh.shape={1,1,1};p.mesh.extent_m={1,1,1};
    p.mechanism.id="ideal terminal balance";p.mechanism.species={{"ion","gas",{{"H",1}},1,1.67e-27,true},{"e","gas",{},-1,9.109e-31,true}};
    p.initial_densities_m3={1e8,1e8};p.transport={{0,0},{0,1}};
    p.boundaries[0].kind=BoundaryKind::Electrode;p.boundaries[1].kind=dielectric?BoundaryKind::Dielectric:BoundaryKind::Electrode;
    p.boundaries[1].absorbing=true;p.boundaries[1].potential_V=10;p.boundaries[1].capacitance_F_m2=1e-9;
    p.circuit.enabled=true;p.circuit.driven_side=1;p.circuit.source_voltage_V=10;p.circuit.initial_voltage_V=10;p.circuit.series_resistance_ohm=0;p.circuit.external_capacitance_F=2e-9;
    p.options.time_step_s=.1;p.options.end_time_s=0;p.options.bdf2=bdf2;p.options.adaptive_time=false;p.options.relative_tolerance=1e-11;p.options.absolute_density_tolerance_m3=1e-5;p.options.potential_tolerance_V=1e-11;
    auto model=std::make_shared<Problem>(p);model->options.mpi=mpi;
    const auto g=mesh::geometry(p.mesh);std::vector<unsigned char> mask(g.walls.size());for(std::size_t w=0;w<g.walls.size();++w)mask[w]=static_cast<unsigned char>(dielectric&&g.walls[w].side==1);
    backend::ExecutionOptions execution;execution.mpi=mpi;partition::DofLayout layout(g,2,0,0,mask,false,execution);const auto& control=layout.control_halo();
    const auto charge=[&](const DistributedResult& result){double local=0;for(std::size_t w=0;w<g.walls.size();++w)if(g.walls[w].side==1&&layout.owns_cell(g.walls[w].cell)){const auto id=dielectric?layout.dielectric_dof(w):layout.cell_dof(g.walls[w].cell,2);const double phi=result.state.owned_values.at(static_cast<std::size_t>(id-result.state.rows.row_begin));local+=(dielectric?p.boundaries[1].capacitance_F_m2:epsilon/g.walls[w].normal_distance)*g.walls[w].area*(10-phi);}return control.global_sum(local);};
    auto owned=solve_distributed(DistributedProblem{.model=model});check(owned.success,owned.message);const double initial_charge=charge(owned);double previous_charge=initial_charge,older_charge=initial_charge;DistributedCheckpoint saved_owned;Checkpoint saved_serial;
    for(int step=1;step<=3;++step){
        p.options.end_time_s=.1*step;model->options.end_time_s=p.options.end_time_s;
        const auto serial=solve(p);owned=solve_distributed(DistributedProblem{.model=model});const double current_charge=charge(owned);
        const double a0=bdf2&&step>1?1.5:1,a1=bdf2&&step>1?2:1,a2=bdf2&&step>1?.5:0;
        const double particle_current=dielectric?0:-2*qe*owned.particle_counts[1];
        const double expected_current=(a0*current_charge-a1*previous_charge+a2*older_charge)/.1-particle_current;
        const double expected_energy=10*(current_charge-initial_charge+(dielectric?0:qe*owned.particles_collected_at_boundaries[1]));
        collectively(control,[&]{check(serial.success&&owned.success,"ideal source solve succeeds");near(owned.samples.back().source_current_A,expected_current,2e-8,1e-22,"ideal source uses terminal BDF charge and signed collection");near(serial.samples.back().source_current_A,expected_current,2e-8,1e-22,"serial ideal terminal current matches owned");near(owned.chemical_energy_integrals_J.at("Electrical/source_power"),expected_energy,2e-8,1e-22,"ideal source energy is counted on exactly one rank");near(serial.chemical_energy_integrals_J.at("Electrical/source_power"),expected_energy,2e-8,1e-22,"serial source energy follows the same BDF ledger");near(owned.chemical_energy_integrals_J.at("Electrical/resistor_loss"),0,0,1e-30,"ideal source has no resistor loss");});
        if(step==2){saved_owned=owned.checkpoint;saved_serial=serial.checkpoint;}
        if(step==3){
            DistributedProblem resumed_input{.model=model};resumed_input.checkpoint=saved_owned;const auto resumed=solve_distributed(resumed_input);
            p.initial_checkpoint=saved_serial;const auto resumed_serial=solve(p);p.initial_checkpoint.reset();
            collectively(control,[&]{check(resumed.success&&resumed_serial.success,"ideal-source restart succeeds");near(resumed.samples.back().source_current_A,owned.samples.back().source_current_A,2e-8,1e-22,"owned restart preserves ideal BDF current");near(resumed_serial.chemical_energy_integrals_J.at("Electrical/source_power"),serial.chemical_energy_integrals_J.at("Electrical/source_power"),2e-8,1e-22,"serial restart preserves source energy history");});
        }
        older_charge=previous_charge;previous_charge=current_charge;
    }
}

void voltage_jump_prediction(){
    // Manufactured closed plasma: the initial coupled direction at zero field
    // overshoots the electron inventory after this voltage jump. The field
    // prediction must converge at the requested dt, not hide behind cutbacks.
    Problem p;p.mesh.dimension=2;p.mesh.shape={10,1,1};p.mesh.extent_m={1e-4,1e-4,1};
    p.mechanism.id="manufactured voltage-jump prediction";
    p.mechanism.species={{"e","gas",{},-1,9.109e-31,true},{"H+","gas",{{"H",1}},1,1.67e-27,true}};
    p.transport={{1,.01},{0,0}};p.initial_densities_m3.assign(20,1e16);
    p.boundaries[0].kind=BoundaryKind::Electrode;p.boundaries[1].kind=BoundaryKind::Electrode;
    p.boundaries[1].potential_V=1000;
    p.circuit.enabled=true;p.circuit.source_voltage_V=1000;p.circuit.initial_voltage_V=0;p.circuit.series_resistance_ohm=20;
    p.options.time_step_s=1e-7;p.options.end_time_s=1e-7;p.options.minimum_time_step_s=1e-20;
    p.options.adaptive_time=false;p.options.maximum_steps=1;
    const auto initial=p.initial_densities_m3;
    const auto jump=solve(p);
    check(jump.success&&jump.accepted_steps==1&&jump.rejected_steps==0,"voltage jump converges without a timestep cutback: "+jump.message);
    check(jump.samples.back().nonlinear_residual<=1,"predicted voltage still satisfies the full coupled residual");
    check(jump.state.driven_voltage_V>990&&jump.state.driven_voltage_V<1000,"finite resistor charges the circuit after the voltage jump");
    for(std::size_t c=0;c<10;++c){
        check(jump.state.densities_m3[2*c]>=0,"voltage prediction retains nonnegative electrons");
        near(jump.state.densities_m3[2*c+1],1e16,1e-12,0,"immobile ions remain unchanged");
    }
    near(jump.particle_counts[0],1e8,1e-10,0,"reflecting electron inventory is conserved");
    check(p.initial_densities_m3==initial&&p.circuit.initial_voltage_V==0,"prediction does not mutate the problem's initial state");

    // The same stiff step is not temporally accurate. Prediction must not bypass
    // its rejection or commit any part of that rejected field/particle state.
    p.options.adaptive_time=true;
    const auto rejected=solve(p);
    check(!rejected.success&&rejected.accepted_steps==0&&rejected.rejected_steps==1,"temporal error rejects the converged stiff step");
    check(rejected.state.time_s==0&&rejected.state.driven_voltage_V==0&&rejected.state.densities_m3==initial,
          "temporal rejection restores all conserved and field state");

    // At a resolved step, preserve the previously converged discrete solution
    // (pre-prediction solver, commit dbacfe0e), within the unchanged 1e-8 Newton
    // relative tolerance. These are solution values, not iteration counts.
    p.options.adaptive_time=false;p.options.time_step_s=1e-12;p.options.end_time_s=1e-12;
    const auto small=solve(p);check(small.success,"resolved voltage step converges");
    near(small.state.driven_voltage_V,5.614426657961934,2e-8,0,"resolved circuit voltage is unchanged");
    const std::vector<double> reference={.994417014557148,.9999688358809016,.9999998260426534,.9999999990289742,
        .9999999999945798,.9999999999999698,.9999999999999998,1,1,1.0056143244957732};
    for(std::size_t c=0;c<10;++c)
        near(small.state.densities_m3[2*c]/1e16,reference[c],2e-8,0,"resolved electron state is unchanged");
}

}
int main(int argc,char** argv){try{
    bool mpi=false;for(int i=1;i<argc;++i)mpi|=std::string(argv[i])=="--mpi";
    backend::Runtime runtime(mpi);voltage_jump_prediction();charged_circuit(mpi,false);charged_circuit(mpi,true);for(bool dielectric:{false,true})for(bool bdf2:{false,true})ideal_source(mpi,dielectric,bdf2);
    if(backend::mpi_rank()==0)std::cout<<"charged driven circuit, cross-rank wall dependencies, charge and Joule ledgers passed\n";
    return 0;
}catch(const std::exception& exception){std::cerr<<exception.what()<<'\n';return 1;}}
