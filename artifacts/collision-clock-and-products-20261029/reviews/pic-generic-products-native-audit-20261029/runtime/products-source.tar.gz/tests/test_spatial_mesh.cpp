#include "raikou/spatial_mesh.h"
#include <algorithm>
#include <cmath>
#include <iostream>
#include <map>
#include <numbers>
#include <stdexcept>
#include <string>
#include <vector>

namespace {
using namespace raikou::spatial;
using namespace raikou::spatial::mesh;
void check(bool value, const std::string& message) { if (!value) throw std::runtime_error(message); }
void close(double value, double expected, double tolerance, const std::string& message) {
    check(std::isfinite(value) && std::abs(value - expected) <= tolerance,
        message + ": " + std::to_string(value) + " versus " + std::to_string(expected));
}
double dot(const Point& a, const Point& b) { return a[0] * b[0] + a[1] * b[1] + a[2] * b[2]; }
Point mapped(double x, double y, double z = 0) { return {x + .6 * y + .3 * z, y + .2 * z, z}; }
std::vector<std::vector<std::size_t>> faces(const Mesh::Cell& c) {
    const auto& v = c.nodes;
    if (c.type == "tri3" || c.type == "quad4") {
        std::vector<std::vector<std::size_t>> result;
        for (std::size_t k = 0; k < v.size(); ++k) result.push_back({v[k], v[(k + 1) % v.size()]});
        return result;
    }
    if (c.type == "tet4") return {{v[0], v[1], v[2]}, {v[0], v[1], v[3]}, {v[0], v[2], v[3]}, {v[1], v[2], v[3]}};
    return {{v[0], v[1], v[2], v[3]}, {v[4], v[5], v[6], v[7]},
        {v[0], v[1], v[5], v[4]}, {v[1], v[2], v[6], v[5]},
        {v[2], v[3], v[7], v[6]}, {v[3], v[0], v[4], v[7]}};
}
void label_boundaries(Mesh& m) {
    std::map<std::vector<std::size_t>, unsigned> count;
    for (const auto& cell : m.cells) for (auto f : faces(cell)) {
        std::sort(f.begin(), f.end()); ++count[f];
    }
    m.boundary_faces.clear();
    for (const auto& [f, n] : count) if (n == 1) m.boundary_faces.push_back({f, 0});
}
Mesh planar(std::size_t n, bool triangles) {
    Mesh m; m.extent_m[2] = .7;
    for (std::size_t j = 0; j <= n; ++j) for (std::size_t i = 0; i <= n; ++i)
        m.nodes_m.push_back(mapped(static_cast<double>(i) / static_cast<double>(n), static_cast<double>(j) / static_cast<double>(n)));
    for (std::size_t j = 0; j < n; ++j) for (std::size_t i = 0; i < n; ++i) {
        const auto a = i + (n + 1) * j, b = a + 1, d = a + n + 1, c = d + 1;
        if (triangles) { m.cells.push_back({"tri3", {a, b, c}}); m.cells.push_back({"tri3", {a, c, d}}); }
        else m.cells.push_back({"quad4", {a, b, c, d}});
    }
    label_boundaries(m); return m;
}
Mesh warped_planar(std::size_t n, bool triangles) {
    auto m = planar(n, triangles);
    for (auto& p : m.nodes_m) {
        const double x = p[0] - .6 * p[1], y = p[1];
        const double warp = std::sin(std::numbers::pi * x) * std::sin(std::numbers::pi * y);
        p[0] += .08 * warp; p[1] += .05 * warp;
    }
    return m;
}
Mesh solid(std::size_t n, bool tetrahedra) {
    Mesh m; m.dimension = 3;
    const auto stride = n + 1;
    for (std::size_t k = 0; k <= n; ++k) for (std::size_t j = 0; j <= n; ++j) for (std::size_t i = 0; i <= n; ++i)
        m.nodes_m.push_back(mapped(static_cast<double>(i) / static_cast<double>(n), static_cast<double>(j) / static_cast<double>(n), static_cast<double>(k) / static_cast<double>(n)));
    for (std::size_t k = 0; k < n; ++k) for (std::size_t j = 0; j < n; ++j) for (std::size_t i = 0; i < n; ++i) {
        const auto a = i + stride * (j + stride * k), b = a + 1, d = a + stride, c = d + 1;
        const auto e = a + stride * stride, f = e + 1, h = e + stride, g = h + 1;
        if (tetrahedra) {
            m.cells.push_back({"tet4", {a, b, c, g}}); m.cells.push_back({"tet4", {a, c, d, g}});
            m.cells.push_back({"tet4", {a, d, h, g}}); m.cells.push_back({"tet4", {a, h, e, g}});
            m.cells.push_back({"tet4", {a, e, f, g}}); m.cells.push_back({"tet4", {a, f, b, g}});
        } else m.cells.push_back({"hex8", {a, b, c, d, e, f, g, h}});
    }
    label_boundaries(m); return m;
}
double affine(const Point& p, const Point& gradient) { return 2.7 + dot(p, gradient); }
void affine_patch(const Geometry& g, const std::string& name, bool mixed = false) {
    // A smooth axisymmetric scalar has zero radial derivative at the axis.
    // Use axial affine data there; phi proportional to r is singular in 3D.
    const Point gradient = g.dimension == 3 ? Point{.8, -1.3, .7} : g.axisymmetric ? Point{0, .8, 0} : Point{.8, 0, 0};
    std::vector<BoundaryCondition> bc(g.walls.size(), BoundaryCondition::Dirichlet);
    for (std::size_t w = 0; w < g.walls.size(); ++w) if (g.walls[w].area == 0) bc[w] = BoundaryCondition::Neumann;
    std::size_t neumann = 0;
    if (mixed) for (std::size_t w = 0; w < g.walls.size(); ++w) if (std::abs(dot(gradient, g.walls[w].normal)) < 1e-13) { bc[w] = BoundaryCondition::Neumann; ++neumann; }
    if (mixed) check(neumann > 0, name + " has a homogeneous Neumann patch");
    const auto stencils = normal_derivatives(g, bc);
    std::vector<double> u, wall;
    for (const auto& center : g.centers) u.push_back(affine(center, gradient));
    for (const auto& w : g.walls) wall.push_back(affine(w.center, gradient));
    for (std::size_t c = 0; c < g.centers.size(); ++c) {
        for (int d = 0; d < g.dimension; ++d) close(stencils.cell_gradients[c][static_cast<std::size_t>(d)].evaluate(u, wall), gradient[static_cast<std::size_t>(d)], 2e-12, name + " affine gradient");
        check(stencils.gradient_condition_numbers[c] >= 1 && std::isfinite(stencils.gradient_condition_numbers[c]), name + " reconstruction condition number");
    }
    for (std::size_t f = 0; f < g.faces.size(); ++f) close(stencils.interior[f].evaluate(u, wall), dot(gradient, g.faces[f].normal), 3e-12, name + " interior affine normal derivative");
    for (std::size_t w = 0; w < g.walls.size(); ++w) {
        close(stencils.boundary[w].evaluate(u, wall), dot(gradient, g.walls[w].normal), 3e-12, name + " boundary affine normal derivative");
        if (bc[w] == BoundaryCondition::Neumann) check(stencils.boundary[w].cells.empty() && stencils.boundary[w].boundaries.empty(), "homogeneous Neumann stencil is exactly zero");
    }
    auto reversed = g;
    for (auto& f : reversed.faces) {
        std::swap(f.a, f.b);
        for (std::size_t d = 0; d < 3; ++d) { f.normal[d] = -f.normal[d]; f.delta[d] = -f.delta[d]; }
    }
    const auto reverse_stencils = normal_derivatives(reversed, bc);
    // Use non-affine data so antisymmetry also checks the correction stencil.
    for (std::size_t c = 0; c < u.size(); ++c) u[c] = std::sin(static_cast<double>(c) + .1);
    for (std::size_t w = 0; w < wall.size(); ++w) wall[w] = std::cos(static_cast<double>(w) + .2);
    for (std::size_t f = 0; f < g.faces.size(); ++f) close(stencils.interior[f].evaluate(u, wall) + reverse_stencils.interior[f].evaluate(u, wall), 0, 1e-12, name + " shared face orientation antisymmetry");
}
void test_affine() {
    for (bool triangles : {false, true}) {
        const auto g = geometry(planar(3, triangles));
        affine_patch(g, triangles ? "obtuse triangles" : "skew quads");
        affine_patch(g, triangles ? "mixed triangles" : "mixed quads", true);
        check(g.minimum_normal_cosine < .99, "skew geometry is accepted without orthogonality");
        check(normal_derivatives(g).has_nonorthogonal_corrections, "skew mesh reports multipoint correction");
    }
    for (bool tetrahedra : {false, true}) affine_patch(geometry(solid(2, tetrahedra)), tetrahedra ? "skew tetrahedra" : "skew hexahedra");
    for (bool triangles : {false, true}) affine_patch(geometry(warped_planar(4, triangles)), triangles ? "warped triangle grid" : "warped quad grid");
    Mesh trapezoid; trapezoid.nodes_m = {{{0, 0, 0}}, {{2, 0, 0}}, {{1.5, 1, 0}}, {{0, 1, 0}}};
    trapezoid.cells = {{"quad4", {0, 1, 2, 3}}}; label_boundaries(trapezoid);
    const auto g = geometry(trapezoid);
    close(g.volume[0], 1.75, 1e-14, "trapezoid volume");
    close(g.centers[0][0], 37. / 42, 1e-14, "true polygon centroid x");
    close(g.centers[0][1], 10. / 21, 1e-14, "true polygon centroid y");
    affine_patch(g, "single non-parallelogram quad");
    Mesh frustum; frustum.dimension = 3;
    frustum.nodes_m = {{{0, 0, 0}}, {{2, 0, 0}}, {{2, 1, 0}}, {{0, 1, 0}},
        {{.2, .1, 1}}, {{1.4, .1, 1}}, {{1.4, .7, 1}}, {{.2, .7, 1}}};
    frustum.cells = {{"hex8", {0, 1, 2, 3, 4, 5, 6, 7}}}; label_boundaries(frustum);
    const auto h = geometry(frustum);
    close(h.volume[0], 98. / 75, 1e-14, "convex frustum hexahedron volume");
    close(h.centers[0][2], 41. / 98, 1e-14, "convex frustum volume centroid");
    close(h.centers[0][0], 1 - .2 * 41. / 98, 1e-14, "convex frustum shifted centroid");
    affine_patch(h, "non-parallelepiped convex hexahedron");
}
std::vector<double> dense_solve(std::vector<std::vector<double>> a, std::vector<double> rhs) {
    const auto n = rhs.size();
    for (std::size_t k = 0; k < n; ++k) {
        std::size_t pivot = k;
        for (std::size_t i = k + 1; i < n; ++i) if (std::abs(a[i][k]) > std::abs(a[pivot][k])) pivot = i;
        check(std::abs(a[pivot][k]) > 1e-14, "manufactured diffusion system is nonsingular");
        std::swap(a[pivot], a[k]); std::swap(rhs[pivot], rhs[k]);
        for (std::size_t i = k + 1; i < n; ++i) {
            const double factor = a[i][k] / a[k][k];
            for (std::size_t j = k + 1; j < n; ++j) a[i][j] -= factor * a[k][j];
            rhs[i] -= factor * rhs[k];
        }
    }
    for (std::size_t reverse = n; reverse > 0; --reverse) {
        const auto i = reverse - 1;
        for (std::size_t j = i + 1; j < n; ++j) rhs[i] -= a[i][j] * rhs[j];
        rhs[i] /= a[i][i];
    }
    return rhs;
}
std::vector<double> elliptic_solve(const EllipticAssembly& system) {
    const auto& csr = system.matrix;
    std::vector<std::vector<double>> a(csr.rows, std::vector<double>(csr.rows));
    for (std::size_t row = 0; row < csr.rows; ++row)
        for (std::size_t j = csr.offsets[row]; j < csr.offsets[row + 1]; ++j)
            a[row][static_cast<std::size_t>(csr.columns[j])] += csr.values[j];
    return dense_solve(std::move(a), system.rhs);
}
void test_elliptic_affine() {
    for (const auto& m : {warped_planar(3, false), warped_planar(3, true), solid(2, false), solid(1, true)}) {
        const auto g = geometry(m);
        const Point gradient{.8, 0, 0};
        const double k = 2.3;
        std::vector<EllipticBoundary> boundaries(g.walls.size());
        std::size_t robin = 0, neumann = 0, dirichlet = 0;
        for (std::size_t w = 0; w < g.walls.size(); ++w) {
            const double dudn = dot(gradient, g.walls[w].normal);
            auto& b = boundaries[w];
            if (std::abs(dudn) < 1e-13) { b.kind = EllipticBoundaryKind::Neumann; ++neumann; }
            else if (w % 3 == 0) { b.kind = EllipticBoundaryKind::Dirichlet; b.value = affine(g.walls[w].center, gradient); ++dirichlet; }
            else {
                b.kind = EllipticBoundaryKind::Robin; b.value = 1.5 + .13 * static_cast<double>(w);
                // Include C=0, sigma!=0 to test a prescribed nonzero flux.
                b.capacitance = w % 4 == 0 ? 0 : 1.7;
                b.source = k * dudn + b.capacitance * (affine(g.walls[w].center, gradient) - b.value);
                ++robin;
            }
        }
        check(robin > 0 && neumann > 0 && dirichlet > 0, "elliptic affine patch has all three boundary kinds");
        const std::vector<double> conductivity{k};
        const auto system = assemble_elliptic(g, conductivity, {}, boundaries);
        check(system.matrix.rows == g.centers.size() + robin, "Robin walls own explicit coupled unknowns");
        std::vector<double> expected(system.matrix.rows), wall_values;
        for (std::size_t c = 0; c < g.centers.size(); ++c) expected[c] = affine(g.centers[c], gradient);
        for (std::size_t w = 0; w < g.walls.size(); ++w) {
            wall_values.push_back(affine(g.walls[w].center, gradient));
            if (system.robin_wall_dofs[w] >= 0) expected[static_cast<std::size_t>(system.robin_wall_dofs[w])] = wall_values[w];
            else check(system.robin_wall_dofs[w] == -1, "non-Robin boundary mapping sentinel");
        }
        for (std::size_t row = 0; row < system.matrix.rows; ++row) {
            double residual = -system.rhs[row];
            for (std::size_t j = system.matrix.offsets[row]; j < system.matrix.offsets[row + 1]; ++j)
                residual += system.matrix.values[j] * expected[static_cast<std::size_t>(system.matrix.columns[j])];
            close(residual, 0, 4e-12, "skew Robin affine patch satisfies assembled equations");
        }
        const auto solution = elliptic_solve(system);
        for (std::size_t i = 0; i < solution.size(); ++i) close(solution[i], expected[i], 3e-11, "coupled skew Robin elliptic solution is affine exact");
        double boundary_flux = 0;
        for (std::size_t w = 0; w < g.walls.size(); ++w)
            boundary_flux += k * g.walls[w].area * system.stencils.boundary[w].evaluate(std::span<const double>(solution).first(g.centers.size()), wall_values);
        close(boundary_flux, 0, 2e-11, "elliptic affine boundary flux conservation");
    }
}
void test_elliptic_backing() {
    Mesh m; m.shape = {4, 3, 1}; m.extent_m = {1, 1, .3};
    const auto g = geometry(m);
    const std::vector<double> conductivity{2};
    for (double backing : {4., 7.}) {
        std::vector<EllipticBoundary> boundaries(g.walls.size());
        for (std::size_t w = 0; w < g.walls.size(); ++w) {
            if (g.walls[w].side == 0) boundaries[w].kind = EllipticBoundaryKind::Dirichlet;
            if (g.walls[w].side == 1) boundaries[w] = {EllipticBoundaryKind::Robin, backing, 5, 0};
        }
        const auto system = assemble_elliptic(g, conductivity, {}, boundaries);
        const auto solution = elliptic_solve(system);
        const double slope = 5 * backing / 7;
        for (std::size_t c = 0; c < g.centers.size(); ++c) close(solution[c], slope * g.centers[c][0], 2e-13, "Robin backing voltage drives analytic field");
        for (std::size_t w = 0; w < g.walls.size(); ++w) if (system.robin_wall_dofs[w] >= 0)
            close(solution[static_cast<std::size_t>(system.robin_wall_dofs[w])], slope, 2e-13, "Robin wall potential includes dielectric voltage division");
    }
}
void test_layered_material() {
    Mesh m; m.extent_m[2] = .3;
    m.nodes_m = {{{0, 0, 0}}, {{.2, 0, 0}}, {{1, 0, 0}}, {{0, 1, 0}}, {{.2, 1, 0}}, {{1, 1, 0}}};
    m.cells = {{"quad4", {0, 1, 4, 3}}, {"quad4", {1, 2, 5, 4}}}; label_boundaries(m);
    const auto g = geometry(m);
    std::vector<EllipticBoundary> boundaries(g.walls.size());
    for (std::size_t w = 0; w < g.walls.size(); ++w) {
        if (std::abs(g.walls[w].center[0]) < 1e-14) boundaries[w] = {EllipticBoundaryKind::Dirichlet, 0, 0, 0};
        if (std::abs(g.walls[w].center[0] - 1) < 1e-14) boundaries[w] = {EllipticBoundaryKind::Dirichlet, 3, 0, 0};
    }
    const std::vector<double> conductivity{2, 7};
    const auto system = assemble_elliptic(g, conductivity, {}, boundaries);
    const auto solution = elliptic_solve(system);
    close(system.interior_conductivity[0], 14. / 3, 1e-14, "normal-distance-weighted layered harmonic coefficient");
    close(solution[0], .7, 1e-14, "unequal-width low-conductivity layer");
    close(solution[1], 2.2, 1e-14, "unequal-width high-conductivity layer");
    std::vector<double> wall_values(g.walls.size());
    for (std::size_t w = 0; w < g.walls.size(); ++w) wall_values[w] = boundaries[w].value;
    close(system.interior_conductivity[0] * system.stencils.interior[0].evaluate(solution, wall_values), 14, 2e-13, "layered material preserves exact series flux");
}
void test_active_phase_reconstruction() {
    for (const auto& m : {planar(4, false), planar(4, true), solid(2, false), solid(2, true)}) {
        const auto g = geometry(m);
        // xi=x-.6*y-.18*z; gradient (.6,1,0) is tangent to xi=.5.
        const Point gradient{.6, 1, 0};
        std::vector<double> fractions, u, walls;
        for (const auto& center : g.centers) {
            const bool active = center[0] - .6 * center[1] - .18 * center[2] < .5;
            fractions.push_back(active ? .25 : 0);
            u.push_back(active ? affine(center, gradient) : 1e100);
        }
        for (const auto& wall : g.walls) walls.push_back(fractions[wall.cell] > 0 ? affine(wall.center, gradient) : 1e100);
        const auto stencils = normal_derivatives_active(g, {}, fractions);
        check(stencils.cell_gradients.size() == g.centers.size() && stencils.interior.size() == g.faces.size() && stencils.boundary.size() == g.walls.size(), "phase-local reconstruction retains global arrays");
        for (std::size_t c = 0; c < g.centers.size(); ++c) {
            for (int d = 0; d < g.dimension; ++d) close(stencils.cell_gradients[c][static_cast<std::size_t>(d)].evaluate(u, walls), fractions[c] > 0 ? gradient[static_cast<std::size_t>(d)] : 0, 5e-12, "active-domain affine gradient with no absent-state coupling");
            check((stencils.gradient_condition_numbers[c] > 0) == (fractions[c] > 0), "absent-phase reconstruction has zero condition diagnostic");
        }
        std::size_t barriers = 0;
        for (std::size_t f = 0; f < g.faces.size(); ++f) {
            const auto& face = g.faces[f];
            const bool active = fractions[face.a] > 0 && fractions[face.b] > 0;
            close(stencils.interior[f].evaluate(u, walls), active ? dot(gradient, face.normal) : 0, 5e-12, "phase-local normal derivative");
            if ((fractions[face.a] > 0) != (fractions[face.b] > 0)) {
                ++barriers;
                check(stencils.interior[f].cells.empty() && stencils.interior[f].boundaries.empty(), "phase barrier has exactly zero flux stencil");
            }
            for (const auto& [cell, coefficient] : stencils.interior[f].cells) { (void)coefficient; check(fractions[cell] > 0, "no phase flux stencil references an absent cell"); }
        }
        check(barriers > 0, "active-domain patch contains an internal barrier");
        for (std::size_t w = 0; w < g.walls.size(); ++w) close(stencils.boundary[w].evaluate(u, walls), fractions[g.walls[w].cell] > 0 ? dot(gradient, g.walls[w].normal) : 0, 5e-12, "active-domain exterior derivative");
        // A constant phase must not acquire gradients from huge absent values.
        for (std::size_t c = 0; c < u.size(); ++c) if (fractions[c] > 0) u[c] = 7;
        for (std::size_t w = 0; w < walls.size(); ++w) if (fractions[g.walls[w].cell] > 0) walls[w] = 7;
        for (const auto& stencil : stencils.interior) close(stencil.evaluate(u, walls), 0, 3e-12, "absent-phase values cannot leak into constant-phase flux");
        const std::vector<double> absent{0};
        const auto empty = normal_derivatives_active(g, {}, absent);
        for (const auto& stencil : empty.interior) check(stencil.cells.empty() && stencil.boundaries.empty(), "fully absent phase has zero flux");
        const std::vector<double> present{1};
        const auto full = normal_derivatives_active(g, {}, present), ordinary = normal_derivatives(g);
        for (std::size_t f = 0; f < g.faces.size(); ++f) close(full.interior[f].evaluate(u, walls), ordinary.interior[f].evaluate(u, walls), 0, "fully present phase uses ordinary reconstruction");
    }
}
double quadratic(const Point& p) { return p[0] * p[0] + .7 * p[0] * p[1] + 1.3 * p[1] * p[1]; }
double quadratic_error(const Mesh& m) {
    const auto g = geometry(m);
    const auto s = normal_derivatives(g);
    const auto nc = g.centers.size();
    std::vector<std::vector<double>> a(nc, std::vector<double>(nc));
    std::vector<double> rhs(nc), boundary;
    for (std::size_t c = 0; c < nc; ++c) rhs[c] = -4.6 * g.volume[c];
    for (const auto& w : g.walls) boundary.push_back(quadratic(w.center));
    const auto assemble = [&](std::size_t cell, double factor, const ScalarStencil& stencil) {
        for (const auto& [j, coefficient] : stencil.cells) a[cell][j] += factor * coefficient;
        for (const auto& [j, coefficient] : stencil.boundaries) rhs[cell] -= factor * coefficient * boundary[j];
    };
    for (std::size_t f = 0; f < g.faces.size(); ++f) {
        assemble(g.faces[f].a, -g.faces[f].area, s.interior[f]);
        assemble(g.faces[f].b, g.faces[f].area, s.interior[f]);
    }
    for (std::size_t w = 0; w < g.walls.size(); ++w) assemble(g.walls[w].cell, -g.walls[w].area, s.boundary[w]);
    const auto u = dense_solve(std::move(a), std::move(rhs));
    double error = 0, volume = 0;
    for (std::size_t c = 0; c < nc; ++c) { error += g.volume[c] * std::pow(u[c] - quadratic(g.centers[c]), 2); volume += g.volume[c]; }
    return std::sqrt(error / volume);
}
void test_diffusion_refinement() {
    for (bool triangles : {false, true}) {
        for (bool warped : {false, true}) {
            double previous = 0;
            for (std::size_t n : {3u, 6u, 12u}) {
                const double error = quadratic_error(warped ? warped_planar(n, triangles) : planar(n, triangles));
                if (previous > 0) check(previous / error > (n == 6 ? 2.8 : 3.1), "quadratic manufactured skew diffusion approaches second order (tri=" + std::to_string(triangles) + ", warped=" + std::to_string(warped) + ", n=" + std::to_string(n) + ", ratio=" + std::to_string(previous / error) + ")");
                previous = error;
            }
        }
    }
}
void test_structured_and_rz() {
    Mesh m; m.shape = {3, 4, 1}; m.extent_m = {2, 3, .4};
    auto g = geometry(m); affine_patch(g, "structured planar", true);
    check(!normal_derivatives(g).has_nonorthogonal_corrections, "Cartesian structured flux is two point");
    double volume = 0; for (double v : g.volume) volume += v;
    close(volume, 2.4, 1e-14, "structured planar physical depth");
    m.dimension = 3; m.shape[2] = 2;
    affine_patch(geometry(m), "structured solid");
    m.dimension = 2; m.shape[2] = 1; m.axisymmetric = true;
    g = geometry(m); volume = 0; for (double v : g.volume) volume += v;
    close(volume, 12 * std::numbers::pi, 1e-13, "structured RZ physical volume");
    close(g.centers[0][0], 4. / 9, 1e-14, "RZ volume centroid at axis");
    affine_patch(g, "structured RZ");
    auto supplied_rz = planar(2, false); supplied_rz.axisymmetric = true;
    const auto supplied_g = geometry(supplied_rz);
    affine_patch(supplied_g, "supplied RZ");
    volume = 0; for (double v : supplied_g.volume) volume += v;
    close(volume, 1.6 * std::numbers::pi, 2e-14, "supplied RZ exact radial volume");
    const std::vector<BoundaryCondition> neumann(g.walls.size(), BoundaryCondition::Neumann);
    const auto stencils = normal_derivatives(g, neumann);
    const std::vector<double> constants(g.centers.size(), 3);
    for (const auto& stencil : stencils.interior) close(stencil.evaluate(constants, {}), 0, 1e-14, "all-Neumann constant kernel");
    for (const auto& stencil : stencils.boundary) check(stencil.cells.empty() && stencil.boundaries.empty(), "all-Neumann walls exactly zero");
}
template<class Function> void rejects(Function&& function, const std::string& message) {
    bool rejected = false;
    try { function(); } catch (const std::invalid_argument&) { rejected = true; }
    check(rejected, message);
}
void test_rejections() {
    auto m = planar(1, false); m.nodes_m[2] = {.8, .1, 0};
    rejects([&] { (void)geometry(m); }, "concave quad rejected");
    m = solid(1, false); m.nodes_m[7][2] += .1;
    rejects([&] { (void)geometry(m); }, "nonplanar hex rejected");
    m = planar(2, true); m.boundary_faces.pop_back();
    rejects([&] { (void)geometry(m); }, "missing exterior label rejected");
    m = planar(1, true); m.cells.push_back(m.cells[0]);
    rejects([&] { (void)geometry(m); }, "overlapping/nonmanifold cells rejected");
    Geometry degenerate; degenerate.centers = {{{0, 0, 0}}}; degenerate.volume = {1};
    rejects([&] { (void)normal_derivatives(degenerate); }, "rank-deficient gradient reconstruction rejected");
}
} // namespace

int main() {
    try {
        test_affine(); test_diffusion_refinement(); test_elliptic_affine(); test_elliptic_backing(); test_layered_material(); test_active_phase_reconstruction(); test_structured_and_rz(); test_rejections();
        std::cout << "spatial mesh geometry and multipoint flux tests passed\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "spatial mesh test failed: " << error.what() << '\n'; return 1;
    }
}
