#include "raikou/device.h"
#include <cmath>
#include <iostream>
#include <limits>
#include <stdexcept>

namespace {
void check(bool condition,const char* message){if(!condition)throw std::runtime_error(message);}
void close(double actual,double expected,double relative,const char* message){
    check(std::isfinite(actual)&&std::abs(actual-expected)<=relative*std::max(1e-300,std::abs(expected)),message);
}
}
int main(){
    using namespace raikou::backend;
    if(!cuda_available())return 77;
    try{
        constexpr std::size_t n=4096;
        CsrMatrix matrix;matrix.rows=n;matrix.offsets.push_back(0);
        for(std::size_t i=0;i<n;++i){
            if(i){matrix.columns.push_back(static_cast<int>(i-1));matrix.values.push_back(-0.7);}
            matrix.columns.push_back(static_cast<int>(i));matrix.values.push_back(2.1);
            if(i+1<n){matrix.columns.push_back(static_cast<int>(i+1));matrix.values.push_back(-0.3);}
            matrix.offsets.push_back(matrix.values.size());
        }
        std::vector<double> exact(n);for(std::size_t i=0;i<n;++i)exact[i]=1+std::sin(static_cast<double>(i)*0.1);
        const auto rhs=csr_multiply(matrix,exact);
        ExecutionOptions options;options.tolerance=1e-11;options.restart=40;
        const auto result=solve_cuda_resident(matrix,rhs,options);
        check(result.linear.converged,"resident nonsymmetric FGMRES did not converge");
        for(std::size_t i=0;i<n;++i)check(std::abs(result.linear.solution[i]-exact[i])<1e-9,"resident FGMRES solution differs");
        const auto expected_upload=matrix.offsets.size()*sizeof(std::size_t)+matrix.columns.size()*sizeof(int)+matrix.values.size()*sizeof(double)+rhs.size()*sizeof(double);
        check(result.transfers.host_to_device_bytes==expected_upload,"Krylov solve uploaded field vectors after initial setup");
        check(result.transfers.device_to_host_bytes<(2*n+4096)*sizeof(double),"Krylov solve downloaded bulk vectors during iteration");
        options.preconditioner="block_ilu0";
        const auto ilu_solved=solve_cuda_resident(matrix,rhs,options);
        check(ilu_solved.linear.converged&&ilu_solved.linear.iterations<=2,"resident ILU0 did not invert tridiagonal block");
        for(std::size_t i=0;i<n;++i)check(std::abs(ilu_solved.linear.solution[i]-exact[i])<1e-10,"resident ILU0 solution differs");
        auto ilu_device=make_cuda_executor({n,n,matrix.offsets,matrix.columns,matrix.values},-1,"block_ilu0");
        auto ilu_rhs=ilu_device->allocate(n),ilu_out=ilu_device->allocate(n);
        ilu_device->upload(rhs,*ilu_rhs);const auto before_ilu=ilu_device->metrics();
        ilu_device->precondition(*ilu_rhs,*ilu_out);const auto after_ilu=ilu_device->metrics();
        check(before_ilu.host_to_device_bytes==after_ilu.host_to_device_bytes&&before_ilu.device_to_host_bytes==after_ilu.device_to_host_bytes,
            "ILU0 preconditioner transferred iterative field vectors");
        const auto ilu_values=ilu_device->download(*ilu_out);
        for(std::size_t i=0;i<n;++i)check(std::abs(ilu_values[i]-exact[i])<1e-10,"resident triangular levels differ");
        bool singular_ilu=false;
        try{(void)make_cuda_executor({1,1,std::vector<std::size_t>{0,1},std::vector<int>{0},std::vector<double>{0}},-1,"block_ilu0");}
        catch(const std::runtime_error&){singular_ilu=true;}
        check(singular_ilu,"singular ILU0 silently substituted another preconditioner");
        // Many disconnected short chains have dependency levels wider than a
        // CUDA block. Unsorted duplicate entries must aggregate before ILU;
        // rectangular halo columns must not enter the owned diagonal block.
        CsrMatrix disconnected; disconnected.rows=n; disconnected.offsets.push_back(0);
        std::vector<double> block_rhs(n,0);
        for(std::size_t row=0;row<n;++row){
            const auto append=[&](int column,double value){
                disconnected.columns.push_back(column);disconnected.values.push_back(value);
                if(column>=0&&static_cast<std::size_t>(column)<n)block_rhs[row]+=value*exact[static_cast<std::size_t>(column)];
            };
            if(row%4<3){append(static_cast<int>(row+1),-0.1);append(static_cast<int>(row+1),-0.2);}
            append(static_cast<int>(n+row%2),0.25); // halo entries excluded by ILU
            append(static_cast<int>(row),0.6);
            if(row%4){append(static_cast<int>(row-1),-0.3);append(static_cast<int>(row-1),-0.4);}
            append(static_cast<int>(row),2.4);
            disconnected.offsets.push_back(disconnected.values.size());
        }
        auto wide=make_cuda_executor({n,n+2,disconnected.offsets,disconnected.columns,disconnected.values},-1,"block_ilu0");
        auto wide_rhs=wide->allocate(n),wide_out=wide->allocate(n);wide->upload(block_rhs,*wide_rhs);
        const auto wide_before=wide->metrics();
        for(int application=0;application<20;++application)wide->precondition(*wide_rhs,*wide_out);
        const auto wide_after=wide->metrics();
        check(wide_before.host_to_device_bytes==wide_after.host_to_device_bytes&&wide_before.device_to_host_bytes==wide_after.device_to_host_bytes,
            "wide ILU0 levels transferred iterative vectors");
        const auto wide_values=wide->download(*wide_out);
        for(std::size_t row=0;row<n;++row)check(std::abs(wide_values[row]-exact[row])<1e-11,"unsorted/duplicate or wide disconnected ILU0 solve differs");
        auto empty=make_cuda_executor({0,0,std::vector<std::size_t>{0},std::vector<int>{},std::vector<double>{}},-1,"block_ilu0");
        auto empty_rhs=empty->allocate(0),empty_out=empty->allocate(0);const auto empty_before=empty->metrics();
        empty->precondition(*empty_rhs,*empty_out);const auto empty_after=empty->metrics();
        check(empty->download(*empty_out).empty()&&empty_before.host_to_device_bytes==empty_after.host_to_device_bytes&&empty_before.device_to_host_bytes==empty_after.device_to_host_bytes,
            "empty rank ILU0 performs invalid work/transfers");
        const auto rejects_ilu=[&](const CsrMatrix& a){
            bool rejected=false;try{(void)make_cuda_executor({a.rows,a.rows,a.offsets,a.columns,a.values},-1,"block_ilu0");}
            catch(const std::runtime_error&){rejected=true;}check(rejected,"invalid owned ILU0 pivot admitted");
        };
        rejects_ilu(CsrMatrix{2,{0,2,4},{0,1,0,1},{1,1,1,1}}); // zero Schur pivot
        rejects_ilu(CsrMatrix{2,{0,1,2},{1,1},{1,1}}); // missing diagonal
        rejects_ilu(CsrMatrix{1,{0,2},{0,0},{1,-1}}); // duplicate cancellation
        rejects_ilu(CsrMatrix{1,{0,2},{0,0},{std::numeric_limits<double>::max(),std::numeric_limits<double>::max()}});
        wide->precondition(*wide_rhs,*wide_out);const auto recovered=wide->download(*wide_out);
        for(std::size_t row=0;row<n;++row)check(std::abs(recovered[row]-exact[row])<1e-11,"failed ILU0 setup poisoned retained executor");
        bool invalid_device=false;try{static_cast<void>(make_cuda_executor({matrix.rows,matrix.rows,matrix.offsets,matrix.columns,matrix.values},100000));}
        catch(const std::invalid_argument&){invalid_device=true;}check(invalid_device,"unavailable device ordinal silently selected another device");
        const std::vector<std::size_t> offsets{0,2,4};const std::vector<int> columns{0,2,1,2};const std::vector<double> coefficients{2,1,3,-1};
        auto device=make_cuda_executor({2,3,offsets,columns,coefficients});
        auto input=device->allocate(3),output=device->allocate(2);
        device->upload(std::vector<double>{1,2,4},*input);device->apply(*input,*output);
        auto values=device->download(*output);close(values[0],6,1e-14,"compact local/halo row0");close(values[1],2,1e-14,"compact local/halo row1");
        auto selection=device->index_plan(std::vector<std::size_t>{2,0});values=device->gather(*input,*selection);
        close(values[0],4,1e-14,"halo gather order");close(values[1],1,1e-14,"halo gather index");
        auto repeated=device->index_plan(std::vector<std::size_t>{1,1});
        values=device->gather(*input,*repeated);check(values[0]==2&&values[1]==2,"repeated peer send index must be supported");
        bool rejected=false;try{device->scatter(std::vector<double>{1,2},*repeated,*input);}catch(const std::invalid_argument&){rejected=true;}
        check(rejected,"ambiguous repeated scatter index was accepted");
        device->scatter(std::vector<double>{5,8},*selection,*input);device->apply(*input,*output);values=device->download(*output);
        close(values[0],21,1e-14,"halo scatter row0");close(values[1],1,1e-14,"halo scatter row1");
        auto norm_vector=device->allocate(2);device->upload(std::vector<double>{1e200,-1e200},*norm_vector);
        close(device->norm(*norm_vector),std::sqrt(2.0)*1e200,1e-14,"scaled large norm");
        device->upload(std::vector<double>{1e-200,-1e-200},*norm_vector);
        close(device->norm(*norm_vector),std::sqrt(2.0)*1e-200,1e-14,"scaled tiny norm");
        CsrMatrix scalar{1,{0,1},{0},{2}};
        for(double scale:{1e-200,1e200}){
            const auto solved=solve_cuda_resident(scalar,std::vector<double>{scale});check(solved.linear.converged,"scaled scalar solve failed");
            close(solved.linear.solution[0],scale/2,1e-13,"scaled scalar solution");
        }
        const auto small_coefficient=solve_cuda_resident(CsrMatrix{1,{0,1},{0},{1e-309}},std::vector<double>{1e-200});
        check(small_coefficient.linear.converged,"finite solution with subnormal matrix coefficient failed");
        close(small_coefficient.linear.solution[0],1e-200/1e-309,1e-12,"subnormal coefficient solution");
        const auto singular=solve_cuda_resident(CsrMatrix{1,{0,1},{0},{0}},std::vector<double>{1});
        check(!singular.linear.converged,"singular resident solve falsely converged");
        std::cout<<"Resident CUDA algebra, halo indices, scale robustness and transfer bounds passed\n";
    }catch(const std::exception& error){std::cerr<<error.what()<<'\n';return 1;}
}
