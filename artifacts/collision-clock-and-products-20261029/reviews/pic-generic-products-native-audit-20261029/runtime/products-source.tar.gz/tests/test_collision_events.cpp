#include "raikou/h2o_dea_kernel.h"
#include <iostream>
#include <functional>

namespace {
int n=0;
void check(bool okay,const char* text) {++n;if (!okay)throw std::runtime_error(text);}
void rejects(const std::function<void()>& f) {bool bad=false;try {f();}catch (const std::exception&) {bad=true;}check(bad,"Unadmitted event was accepted");}
}
int main(int argc,char** argv) {try {
    using namespace raikou::kinetics;
#ifndef RAIKOU_TEST_H2O_EVENTS
#define RAIKOU_TEST_H2O_EVENTS "data/collisions/h2o-gas-20261029-events.json"
#endif
    const auto data=StrictCollisionDataset::read(argc==2?argv[1]:RAIKOU_TEST_H2O_EVENTS);
    const auto& model=h2o_dea_detail::model(data);
    const auto weights=model.at("OH_vibrational_relative_intensities").get<std::vector<double>>();
    check(weights==std::vector<double>({1,.82,.57,.32,.25}),"RamTableIII source intensities");
    check(model.at("angular").at("b")==.31&&model.at("angular").at("phase_rad")==3.139,"Ram angular-fit source values");
    check(std::abs(hminus_Ram65_vibrational_eV(data,1)/1.2398419843320026e-4-3569.640)<.01,"NIST OH fundamental band check");
    const CollisionMomentum beam{0,1,0};constexpr double e=1.602176634e-19,me=9.1093837139e-31,c=299792458.;
    const double M=18.01056468403*1.66053906660e-27,Hm=1.00837*1.66053906660e-27;
    const auto kinetic=[&](const CollisionMomentum& p,double m) {double p2=0;for (auto v:p)p2+=v*v;return p2/(m*(std::sqrt(1+p2/(m*m*c*c))+1));};
    for (double energy:{6.25,6.5,6.75}) for (double w:{.125,1.,32.}) for (double u:{.01,.4,.75,.95}) {
        const auto event=conditional_hminus_Ram65_products(data,"Hminus_Ram65_factorized_window_v1",energy,w,M,Hm,beam,u,.37,.61);
        const double K=energy*e,p0=std::sqrt(K*(K+2*me*c*c))/c;
        for (int d=0;d<3;++d)check(std::abs(event.Hminus_momentum_kg_m_s[d]+event.OH_momentum_kg_m_s[d]-p0*beam[d])<3e-12*p0,"DEA momentum closure");
        check(std::abs(kinetic(event.Hminus_momentum_kg_m_s,Hm)-event.Hminus_kinetic_J)<2e-12*K,"Hminus on mass shell");
        check(std::abs(kinetic(event.OH_momentum_kg_m_s,event.OH_state_mass_kg)-event.OH_kinetic_J)<2e-12*K,"OH on mass shell");
        check(std::abs(event.Hminus_kinetic_J+event.OH_kinetic_J+event.OH_internal_gain_J+event.chemical_reference_gain_J-K)<2e-12*K,"DEA kinetic/internal/reference closure");
        check(event.physical_weight_each==w,"DEA matched weights");
        check(event.OH_vibrational_level>=0&&event.OH_vibrational_level<=4,"OH state identity");
        check(event.cross_section_m2>0,"Measured DEA rate bound");
        double parallel=0,pnorm=0;for (int d=0;d<3;++d) {parallel+=event.Hminus_momentum_kg_m_s[d]*beam[d];pnorm+=event.Hminus_momentum_kg_m_s[d]*event.Hminus_momentum_kg_m_s[d];}
        check(std::abs(parallel/std::sqrt(pnorm)-event.fragment_cosine)<2e-13,"Measured laboratory angular distribution retained by CM inversion");
    }
    double integral=0,first=0,best=-1,best_mu=0;
    for (int i=0;i<4000;++i) {
        const double mu=-1+(i+.5)/2000.;const double value=hminus_Ram65_cosine_density(data,mu);
        check(value>=0,"Source angular density positive");integral+=value/2000.;first+=mu*value/2000.;
        if (value>best) {best=value;best_mu=mu;}
    }
    check(std::abs(integral-1)<2e-7,"Full solid-angle normalization in cosine measure");
    const double peak=std::acos(best_mu)*180/std::numbers::pi;
    check(peak>100&&peak<110,"Source backward angular asymmetry near100degrees");
    check(std::abs(hminus_Ram65_cosine_cdf(data,-1))<1e-14&&std::abs(hminus_Ram65_cosine_cdf(data,1)-1)<1e-14,"Angular CDF endpoints");
    std::array<int,5> counts{};double sample_mean=0;constexpr int samples=5000;
    for (int i=0;i<samples;++i) {
        const double u=(i+.5)/samples;
        const auto event=conditional_hminus_Ram65_products(data,"Hminus_Ram65_factorized_window_v1",6.5,1,M,Hm,beam,u,u,.25);
        ++counts[event.OH_vibrational_level];sample_mean+=event.fragment_cosine/samples;
        check(std::abs(hminus_Ram65_cosine_cdf(data,event.fragment_cosine)-u)<2e-14,"Inverse CDF retains source measure");
    }
    const double total=std::accumulate(weights.begin(),weights.end(),0.);
    for (int i=0;i<5;++i)check(std::abs(double(counts[i])/samples-weights[i]/total)<=1./samples,"Reported vibrational populations reproduced");
    check(std::abs(sample_mean-first)<3e-5,"Source angular first moment reproduced");
    rejects([&]{(void)conditional_hminus_Ram65_products(data,"",6.5,1,M,Hm,beam,.5,.5,.5);});
    rejects([&]{(void)conditional_hminus_Ram65_products(data,"Hminus_Ram65_factorized_window_v1",8.5,1,M,Hm,beam,.5,.5,.5);});
    rejects([&]{(void)conditional_hminus_Ram65_products(data,"Hminus_Ram65_factorized_window_v1",8084.47,1,M,Hm,beam,.5,.5,.5);});
    rejects([&]{(void)conditional_hminus_Ram65_products(data,"Hminus_Ram65_factorized_window_v1",6.5,1,M,Hm,beam,1,.5,.5);});
    rejects([&]{(void)data.require_MCC_event_kernel("H2O:ion_yield:total","Hminus_Ram65_factorized_window_v1",6.5);});
    std::cout<<"{\"passed\":true,\"checks\":"<<n<<",\"angular_peak_deg\":"<<peak<<",\"physical_time_advanced\":0,\"GPU_used\":false}\n";return 0;
} catch(const std::exception& e) {std::cerr<<e.what()<<'\n';return 1;}}
