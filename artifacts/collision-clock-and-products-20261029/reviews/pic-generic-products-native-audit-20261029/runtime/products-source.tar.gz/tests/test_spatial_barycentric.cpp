#include "raikou/spatial_distributed.h"
#include <algorithm>
#include <cmath>
#include <iostream>
#include <sstream>
#include <stdexcept>

namespace {
using namespace raikou;
using namespace spatial;
constexpr double qe=1.602176634e-19, eps=8.8541878128e-12, mass=4.651734510436784e-26;
void check(bool ok,const std::string& message){if(!ok)throw std::runtime_error(message);}
void near(double actual,double expected,double tolerance,const std::string& message){std::ostringstream detail;detail.precision(17);detail<<message<<": "<<actual<<" vs "<<expected;check(std::isfinite(actual)&&std::abs(actual-expected)<=tolerance,detail.str());}
template<class F>void rejects(F run,const std::string& fragment){bool rejected=false;try{run();}catch(const std::exception& error){rejected=std::string(error.what()).find(fragment)!=std::string::npos;}check(rejected,"expected rejection: "+fragment);}
Problem base(){
    Problem p;p.mesh.shape={2,1,1};p.mesh.extent_m={1,1,1};p.mechanism.id="binary neutral-frame ion transport";
    p.mechanism.species={{"N2","gas",{{"N",2}},0,mass,true},{"N2+","gas",{{"N",2}},1,mass,true},{"e","gas",{},-1,9.1093837139e-31,true}};
    p.initial_densities_m3={8e7,2e7,2e7,2e7,8e7,8e7};p.transport={{0,0},{.2,.05},{0,0}};
    p.heavy_barycentric_pair=HeavyBarycentricPair{"N2","N2+"};
    p.boundaries[0].kind=BoundaryKind::Electrode;p.boundaries[1].kind=BoundaryKind::Electrode;p.boundaries[1].potential_V=10;
    p.circuit.enabled=true;p.circuit.source_voltage_V=10;p.circuit.initial_voltage_V=10;
    p.options.time_step_s=.1;p.options.end_time_s=.1;p.options.adaptive_time=false;p.options.bdf2=false;
    p.options.relative_tolerance=1e-11;p.options.absolute_density_tolerance_m3=1e-5;p.options.potential_tolerance_V=1e-11;
    p.thermal.enabled=true;p.thermal.heat_capacity_J_m3_K={1e-11};p.thermal.initial_temperature_K={300};p.thermal.joule_species={"N2+","e"};
    return p;
}
void independent_face_equations(){
    auto p=base();const auto r=solve(p);check(r.success,"independent equations: "+r.message);check(r.accepted_steps==1,"one full backward-Euler step");
    const auto& n=r.state.densities_m3;const auto& phi=r.state.potential_V;
    const double raw=scharfetter_gummel_flux(n[1],n[4],phi[0],phi[1],.5,1,p.transport[1]);
    const std::size_t donor=raw>0?3:0;
    const double neutral_fraction=n[donor]/(n[donor]+n[donor+1]);const double corrected=neutral_fraction*raw;
    const double electron_corrected=-n[donor+2]/(n[donor]+n[donor+1])*raw;
    check(std::abs(corrected)>1e6 && std::abs(raw-corrected)>1e6,"nontrivial drift and frame correction");
    near(n[0]+n[1],1e8,2e-5,"cell0 heavy inventory remains fixed without resetting neutral density");
    near(n[3]+n[4],1e8,2e-5,"cell1 heavy inventory remains fixed without resetting neutral density");
    near((n[1]-2e7)*.5/.1,-corrected,3e-5,"independent corrected ion finite-volume balance cell0");
    near((n[4]-8e7)*.5/.1,corrected,3e-5,"independent corrected ion finite-volume balance cell1");
    near((n[0]-8e7)*.5/.1,corrected,3e-5,"neutral counterflux uses the same face flux");
    near((n[2]-2e7)*.5/.1,-electron_corrected,3e-5,"electron number flux transforms from the same neutral reference frame");
    near(r.samples.back().gas_charge_C,0,3e-24,"global charge conserved in closed pore");
    near(r.samples.back().electric_work_W,qe*(corrected-electron_corrected)*(phi[0]-phi[1]),2e-23,"Joule ledger uses both corrected charge currents");
    near(r.chemical_energy_integrals_J.at("Electrical/particle_work"),.1*qe*(corrected-electron_corrected)*(phi[0]-phi[1]),2e-24,"integrated work uses corrected current once");
    near(r.samples.back().barycentric_frame_work_W,-qe*(n[donor+1]-n[donor+2])/(n[donor]+n[donor+1])*raw*(phi[0]-phi[1]),2e-23,"frame work uses the same donor for every charge carrier");
    near(r.samples.back().thermal_energy_J-3e-9,r.chemical_energy_integrals_J.at("Electrical/particle_work"),2e-22,"thermal source and independent electric work agree");
    const double initial_charge=10*eps,final_charge=eps*(10-phi[1])/.25;
    near(r.samples.back().source_current_A,(final_charge-initial_charge)/.1,2e-22,"closed pore circuit sees displacement, not a phantom heavy wall current");
    p.initial_checkpoint=r.checkpoint;p.options.end_time_s=.3;p.options.bdf2=true;const auto continued=solve(p);check(continued.success,"BDF restart: "+continued.message+", time "+std::to_string(continued.state.time_s));
    for(std::size_t c=0;c<2;++c)near(continued.state.densities_m3[3*c]+continued.state.densities_m3[3*c+1],1e8,3e-5,"BDF2/restart preserves cell-local heavy inventory");
}
void chemistry_and_fraction_limits(){
    auto p=base();chemistry::Reaction ionize;ionize.id="ionize";ionize.reactants={{0,1},{2,1}};ionize.products={{1,1},{2,2}};ionize.rate.A=1e-9;
    chemistry::Reaction recombine;recombine.id="recombine";recombine.reactants={{1,1},{2,1}};recombine.products={{0,1}};recombine.rate.A=2e-9;recombine.energy_eV_per_event={{"gas/recombination_heating",1}};p.mechanism.reactions={ionize,recombine};
    p.thermal.joule_species.clear();p.thermal.heat_reservoirs={"gas/recombination_heating"};
    p.options.bdf2=true;p.options.end_time_s=.3;const auto r=solve(p);check(r.success,"chemistry: "+r.message);
    for(std::size_t c=0;c<2;++c)near(r.state.densities_m3[3*c]+r.state.densities_m3[3*c+1],1e8,5e-5,"balanced ionization/recombination and transport preserve local heavy count");
    near(r.samples.back().gas_charge_C,0,2e-23,"chemistry plus barycentric transport preserves charge");
    near(r.chemical_energy_integrals_J.at("Thermal/collisional_heavy_heating"),r.chemical_energy_integrals_J.at("gas/recombination_heating"),2e-24,"selected collisional thermal diagnostic counts its reservoir once");
    near(r.samples.back().thermal_energy_J-3e-9,r.chemical_energy_integrals_J.at("Thermal/collisional_heavy_heating"),2e-22,"frame work is diagnostic and is not silently deposited as heat");
    for(double ion_fraction:{0.,1.,.9999}){
        p=base();for(std::size_t c=0;c<2;++c){p.initial_densities_m3[3*c]=(1-ion_fraction)*1e8;p.initial_densities_m3[3*c+1]=ion_fraction*1e8;p.initial_densities_m3[3*c+2]=ion_fraction*1e8;}
        const auto limit=solve(p);check(limit.success,"fraction "+std::to_string(ion_fraction)+": "+limit.message);
        for(std::size_t c=0;c<2;++c)near(limit.state.densities_m3[3*c]+limit.state.densities_m3[3*c+1],1e8,2e-5,"near-pure mixture conserves heavy count");
        if(ion_fraction==0)near(limit.chemical_energy_integrals_J.at("Electrical/particle_work"),0,1e-25,"pure neutral has no electrical work");
        if(ion_fraction==1)for(std::size_t c=0;c<2;++c)near(limit.state.densities_m3[3*c+1],1e8,2e-5,"pure ion limit has no heavy diffusion relative to its own barycentre");
    }
}
void nonneutral_frame_current(){
    auto p=base();p.initial_densities_m3={8e7,2e7,1e7,8e7,2e7,1e7};p.transport[2]={.3,.1};
    const auto r=solve(p);check(r.success,"nonneutral: "+r.message);const auto& n=r.state.densities_m3;const auto& phi=r.state.potential_V;
    const double ji=scharfetter_gummel_flux(n[1],n[4],phi[0],phi[1],.5,1,p.transport[1]);
    const double je=scharfetter_gummel_flux(n[2],n[5],phi[0],phi[1],.5,-1,p.transport[2]);
    const std::size_t donor=ji>0?3:0;const double nh=n[donor]+n[donor+1],rho=qe*(n[donor+1]-n[donor+2]);
    const double frame_velocity=ji/nh,drop=phi[0]-phi[1];
    near(r.samples.back().neutral_frame_particle_work_W,qe*(ji-je)*drop,2e-23,"raw neutral-frame current independently reconstructed");
    near(r.samples.back().barycentric_frame_work_W,-rho*frame_velocity*drop,2e-23,"nonneutral current changes by minus charge density times frame velocity");
    near(r.samples.back().electric_work_W,qe*(ji-je)*drop-rho*frame_velocity*drop,2e-23,"total electrical work carries the common frame correction");
    near(r.samples.back().gas_charge_C,qe*1e7,3e-24,"nonneutral closed-pore charge retained");
    p=base();p.transport[1]={0,.1};p.transport[2]={0,.1};const auto quasi=solve(p);check(quasi.success,quasi.message);
    for(std::size_t c=0;c<2;++c)near(quasi.state.densities_m3[3*c+1],quasi.state.densities_m3[3*c+2],2e-5,"equal raw diffusive charged fluxes preserve quasineutrality");
    near(quasi.samples.back().barycentric_frame_work_W,0,1e-24,"quasineutral charge current is invariant under the common upwind frame shift");
    check(std::abs(quasi.state.densities_m3[1]-p.initial_densities_m3[1])>1e4,"quasineutral test has nonzero transported charged particles");
}
void selection_and_json(){
    auto p=base();p.boundaries[1].absorbing=true;rejects([&]{(void)solve(p);},"wall mass-recycling");
    p=base();p.mesh.shape={3,1,1};p.mechanism.species.push_back({"rock","rock",{{"Si",1}},0,4.66e-26,true});p.transport.push_back({0,0});
    p.initial_densities_m3={0,0,0,1,8e7,2e7,2e7,0,0,0,0,1};p.phase_fractions={{"gas",{0,1,0}},{"rock",{1,0,1}}};
    p.boundaries[0].absorbing=true;p.boundaries[1].absorbing=true;check(solve(p).success,"absorbing outer electrodes are allowed while pair phase has no contact");
    p=base();p.transport[0].diffusion_m2_s=.1;rejects([&]{(void)solve(p);},"counterflux");
    p=base();p.mechanism.species[1].mass_kg*=2;rejects([&]{(void)solve(p);},"equal heavy molecular masses");
    p=base();p.mechanism.species.push_back({"N2_excited","gas",{{"N",2}},0,mass,true});p.transport.push_back({0,0});p.initial_densities_m3={8e7,2e7,2e7,0,2e7,8e7,8e7,0};rejects([&]{(void)solve(p);},"only the two heavy species");
    p=base();auto model=std::make_shared<Problem>(p);model->initial_densities_m3={8e7,2e7,2e7};rejects([&]{(void)solve_distributed(DistributedProblem{.model=model});},"heavy_barycentric_pair");
    p=base();Json request={{"mechanism",p.mechanism.to_json()},{"mesh",{{"type","structured"},{"shape",{2,1,1}},{"extent_m",{1,1,1}}}},
        {"transport",{{"N2+",{{"mobility_m2_V_s",.2},{"diffusion_m2_s",.05}}}}},{"initial_densities_m3",{{"N2",{8e7,2e7}},{"N2+",{2e7,8e7}},{"e",{2e7,8e7}}}},
        {"boundaries",{{"xmin",{{"kind","electrode"}}},{"xmax",{{"kind","electrode"},{"potential_V",10}}}}},
        {"heavy_barycentric_pair",{{"neutral","N2"},{"ion","N2+"}}},{"time",{{"time_step_s",.1},{"end_time_s",.1},{"adaptive",false}}}};
    const auto result=solve_json(request);check(result.at("success"),"JSON barycentric option works");
    for(std::size_t c=0;c<2;++c)near(result.at("densities_m3").at("N2")[c].get<double>()+result.at("densities_m3").at("N2+")[c].get<double>(),1e8,1e-3,"JSON carries native neutral and ion states");
    auto derived=request;derived["mechanism"]["species"][0].erase("mass_kg");derived["mechanism"]["species"][1].erase("mass_kg");
    check(solve_json(derived).at("success"),"physically derived ion electron-mass deficit is accepted by the heavy-mass approximation");
    request["heavy_barycentric_pair"]["unrecognized"]=true;rejects([&]{(void)problem_from_json(request);},"unknown heavy_barycentric_pair key");
}
}
int main(){try{independent_face_equations();chemistry_and_fraction_limits();nonneutral_frame_current();selection_and_json();std::cout<<"barycentric heavy/electron transport, local mass, frame-current/work and selection tests passed\n";return 0;}catch(const std::exception& error){std::cerr<<error.what()<<'\n';return 1;}}
