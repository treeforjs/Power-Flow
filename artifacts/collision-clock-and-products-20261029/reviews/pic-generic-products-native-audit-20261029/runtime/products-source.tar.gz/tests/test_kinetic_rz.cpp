#include "raikou/kinetic_rz.h"
#include "raikou/kinetic_transport.h"
#include "raikou/spatial_mesh.h"
#include <algorithm>
#include <cmath>
#include <iostream>
#include <numbers>
#include <stdexcept>
#include <string>

namespace {
using namespace raikou::kinetics;
void check(bool value, const std::string& message) { if (!value) throw std::runtime_error(message); }
void close(double value, double expected, double relative, const std::string& message) {
    check(std::isfinite(value) && std::abs(value - expected) <= relative * std::max({std::abs(value), std::abs(expected), 1e-200}), message);
}
double edge(const EedfGrid& g, std::size_t i) { return g.max_energy_ev * std::pow(static_cast<double>(i) / g.cells, g.power); }
double center(const EedfGrid& g, std::size_t i) { return .5 * (edge(g, i) + edge(g, i + 1)); }
double energy_mass(const EedfGrid& g, std::size_t i, bool even) {
    if (even) return 2. / 3 * (std::pow(edge(g, i + 1), 1.5) - std::pow(edge(g, i), 1.5));
    return i + 1 == static_cast<std::size_t>(g.cells) ? 0 : 2. / 3 * (std::pow(center(g, i + 1), 1.5) - std::pow(center(g, i), 1.5));
}
SphericalEedfState state(const EedfGrid& grid, bool axial, double phase = 0) {
    SphericalEedfState result; result.grid = grid;
    const auto stride = static_cast<std::size_t>(grid.legendre_terms * grid.legendre_terms);
    result.density_modes.resize(static_cast<std::size_t>(grid.cells) * stride);
    for (std::size_t i = 0; i < static_cast<std::size_t>(grid.cells); ++i) {
        const double base = std::exp(-center(grid, i) / 1.5);
        result.density_modes[i * stride] = base;
        for (int l = 1; l < grid.legendre_terms; ++l) for (int m = -l; m <= l; ++m) {
            if ((axial && m != 0) || (l % 2 != 0 && i + 1 == static_cast<std::size_t>(grid.cells))) continue;
            result.density_modes[i * stride + spherical_index(l, m)] = .02 * base * std::sin(phase + static_cast<double>((i + 1) * static_cast<std::size_t>(l + m + 1)));
        }
    }
    result.validate(); return result;
}
std::vector<double> multiply(const raikou::backend::CsrMatrix& a, const std::vector<double>& x) {
    std::vector<double> result(a.rows);
    for (std::size_t row = 0; row < a.rows; ++row)
        for (std::size_t k = a.offsets[row]; k < a.offsets[row + 1]; ++k) result[row] += a.values[k] * x[static_cast<std::size_t>(a.columns[k])];
    return result;
}
void test_geometry_measures() {
    raikou::spatial::Mesh m; m.axisymmetric = true; m.shape = {3, 2, 1}; m.extent_m = {.03, .04, 1};
    const auto g = rz_geometry(m);
    check(g.inverse_radius_m1.size() == 6, "one inverse radius per cell");
    for (std::size_t c = 0; c < 6; ++c) close(g.inverse_radius_m1[c], 2 / ((2 * static_cast<double>(c % 3) + 1) * .01), 2e-15, "exact finite-axis cylindrical inverse-radius measure");
    close(g.inverse_radius_m1[0], 200, 1e-15, "axis cell has finite 2/dr geometry");
    m.nodes_m = {{{0, 0, 0}}, {{1, 0, 0}}, {{.3, .7, 0}}}; m.cells = {{"tri3", {0, 1, 2}}};
    m.boundary_faces = {{{0, 1}, 0}, {{1, 2}, 1}, {{2, 0}, 2}};
    const auto triangle = rz_geometry(m);
    close(triangle.inverse_radius_m1[0], 30. / 13, 2e-15, "supplied RZ triangle exact radial moment");
    const auto physical = raikou::spatial::mesh::geometry(m);
    check(std::abs(triangle.inverse_radius_m1[0] - 1 / physical.centers[0][0]) > .1, "inverse-radius cell measure is distinct from reciprocal volume centroid");
}
void test_matrix_moments_and_all_modes() {
    for (double power : {1., 2.3, 4.}) {
        const EedfGrid grid{.cells = 24, .max_energy_ev = 12, .power = power, .legendre_terms = 6};
        const auto input = state(grid, false);
        const auto rhs = rz_geometry_rhs(RzGeometry{{7}}, {input}, 2).front();
        const auto matrix = rz_geometry_matrix(grid, 7);
        const auto applied = multiply(matrix, input.density_modes);
        double max_error = 0, scale = 0;
        for (std::size_t i = 0; i < rhs.size(); ++i) { max_error = std::max(max_error, std::abs(rhs[i] - applied[i])); scale = std::max(scale, std::abs(rhs[i])); }
        check(max_error < 2e-13 * scale, "geometry CSR equals direct all-mode RHS");
        auto rate_state = input; rate_state.density_modes = rhs;
        check(rate_state.electron_density_m3() == 0 && rate_state.electron_energy_ev_m3() == 0, "geometry RHS has exactly zero number and energy moments");
        const std::size_t stride = 36;
        for (std::size_t i = 0; i < 24; ++i) for (int l = 0; l < 6; ++l) {
            const auto row = i * stride + spherical_index(l, 0);
            check(rhs[row] == 0 && matrix.offsets[row] == matrix.offsets[row + 1], "every m=0 test row is exactly zero");
        }
        for (int l = 1; l < 6; l += 2) for (int m = -l; m <= l; ++m)
            check(rhs[23 * stride + spherical_index(l, m)] == 0, "odd-mode energy padding remains zero");
        check(std::abs(rhs[10 * stride + spherical_index(3, -2)]) > 1e-6 && std::abs(rhs[10 * stride + spherical_index(4, 3)]) > 1e-6,
            "geometry operator retains higher sine and cosine azimuthal modes");
    }
}
void test_sign_and_overlap() {
    const EedfGrid grid{.cells = 32, .max_energy_ev = 12, .power = 2.7, .legendre_terms = 6};
    auto isotropic = state(grid, true);
    const std::size_t stride = 36;
    for (std::size_t i = 0; i < 32; ++i) for (std::size_t mode = 1; mode < stride; ++mode) isotropic.density_modes[i * stride + mode] = 0;
    const auto rhs = rz_geometry_rhs(RzGeometry{{3}}, {isotropic}).front();
    const std::size_t i = 10;
    const double e = edge(grid, i + 1), c0 = center(grid, i), c1 = center(grid, i + 1);
    const double overlap = e * ((c1 - e) * isotropic.density_modes[i * stride] + (e - c0) * isotropic.density_modes[(i + 1) * stride]) / energy_mass(grid, i, false);
    const double expected = 3 * std::sqrt(2 * 1.602176634e-19 / 9.1093837015e-31) * overlap / std::sqrt(3.);
    close(rhs[i * stride + spherical_index(1, 1)], expected, 2e-14, "isotropic curvature RHS has positive radial sign and exact staggered velocity overlap");
    check(rhs[i * stride + spherical_index(1, -1)] == 0, "isotropic curvature has no azimuthal drift");
    const auto u = state(grid, false, .3), v = state(grid, false, 1.2);
    const auto gu = rz_geometry_rhs(RzGeometry{{1}}, {u}).front(), gv = rz_geometry_rhs(RzGeometry{{1}}, {v}).front();
    KineticFace face; face.left = 0; face.normal = {1, 0, 0}; face.area_m2 = 1;
    face.wall = KineticWall::PrescribedIncoming; face.incoming = v;
    const auto minus_ar_v = kinetic_streaming_rhs(KineticMesh{{1}, {face}}, {v}).density_mode_rates.front();
    double left = 0, right = 0, absolute = 0;
    for (std::size_t energy = 0; energy < 32; ++energy) for (int l = 0; l < 6; ++l) for (int m = -l; m <= l; ++m) {
        const auto slot = energy * stride + spherical_index(l, m);
        const double weight = energy_mass(grid, energy, l % 2 == 0);
        left += weight * (u.density_modes[slot] * gv[slot] + gu[slot] * v.density_modes[slot]);
        right -= weight * u.density_modes[slot] * minus_ar_v[slot];
        absolute += weight * (std::abs(u.density_modes[slot] * gv[slot]) + std::abs(gu[slot] * v.density_modes[slot]));
    }
    check(std::abs(left - right) < 3e-13 * absolute, "geometry satisfies G+G_mass_adjoint=A_radial with staggered energy measures");
}
void test_uniform_equilibrium_cancellation() {
    for (double r0 : {0., .015}) for (int terms : {2, 4, 6}) {
        const double r1 = r0 + .01, dz = .02;
        const double volume = std::numbers::pi * (r1 * r1 - r0 * r0) * dz;
        const EedfGrid grid{.cells = 24, .max_energy_ev = 12, .power = 2.3, .legendre_terms = terms};
        for (bool isotropic : {false, true}) {
            auto input = state(grid, true);
            const auto stride = static_cast<std::size_t>(terms * terms);
            if (isotropic) for (std::size_t i = 0; i < 24; ++i) for (std::size_t mode = 1; mode < stride; ++mode) input.density_modes[i * stride + mode] = 0;
            KineticMesh spatial; spatial.cell_volumes_m3 = {volume};
            const auto wall = [&](const Vector3& normal, double area) {
                if (area == 0) return;
                KineticFace face; face.left = 0; face.normal = normal; face.area_m2 = area;
                face.wall = KineticWall::PrescribedIncoming; face.incoming = input; spatial.faces.push_back(face);
            };
            wall({1, 0, 0}, 2 * std::numbers::pi * r1 * dz); wall({-1, 0, 0}, 2 * std::numbers::pi * r0 * dz);
            wall({0, 0, 1}, std::numbers::pi * (r1 * r1 - r0 * r0)); wall({0, 0, -1}, std::numbers::pi * (r1 * r1 - r0 * r0));
            const auto streaming = kinetic_streaming_rhs(spatial, {input}).density_mode_rates.front();
            const auto geometry = make_rz_geometry(std::vector<double>{(r1 - r0) * dz}, spatial.cell_volumes_m3);
            const auto correction = rz_geometry_rhs(geometry, {input}).front();
            double error = 0, scale = 0;
            for (std::size_t i = 0; i < streaming.size(); ++i) { error = std::max(error, std::abs(streaming[i] + correction[i])); scale = std::max(scale, std::abs(correction[i])); }
            check(error < 2e-12 * scale, "uniform isotropic/axial equilibrium cancels physical radial FV flux including the axis cell");
        }
    }
}
void test_validation() {
    bool rejected = false;
    try { (void)make_rz_geometry(std::vector<double>{1}, std::vector<double>{0}); } catch (const std::invalid_argument&) { rejected = true; }
    check(rejected, "zero physical volume rejected");
    const EedfGrid grid{.cells = 24, .max_energy_ev = 12, .power = 2, .legendre_terms = 4};
    rejected = false;
    try { (void)rz_geometry_rhs(RzGeometry{{-1}}, {state(grid, false)}); } catch (const std::invalid_argument&) { rejected = true; }
    check(rejected, "negative inverse radius rejected");
    const auto zero = rz_geometry_rhs(RzGeometry{{0}}, {state(grid, false)}).front();
    for (double value : zero) check(value == 0, "zero inverse radius disables geometry exactly");
}
} // namespace

int main() {
    try {
        test_geometry_measures(); test_matrix_moments_and_all_modes(); test_sign_and_overlap(); test_uniform_equilibrium_cancellation(); test_validation();
        std::cout << "cylindrical kinetic geometry, all-m moments and FV cancellation passed\n"; return 0;
    } catch (const std::exception& error) { std::cerr << "kinetic RZ: " << error.what() << '\n'; return 1; }
}
