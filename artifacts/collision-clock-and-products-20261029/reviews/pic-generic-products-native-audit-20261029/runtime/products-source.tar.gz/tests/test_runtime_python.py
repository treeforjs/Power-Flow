"""Numerical runtime/API checks and an opt-in clean wheel-install smoke test.

    python tests/test_runtime_python.py
    python tests/test_runtime_python.py --wheel path/to/raikou.whl

Set RAIKOU_LIBRARY for a source build. The wheel mode creates an isolated venv,
installs only the supplied wheel and repeats these tests against that package.
"""

from __future__ import annotations

import copy
from importlib.resources import files
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
import venv

ROOT = Path(__file__).resolve().parents[1]
INSTALLED = os.environ.get("RAIKOU_TEST_INSTALLED") == "1"
if not INSTALLED:
    sys.path.insert(0, str(ROOT / "python"))

import raikou


def mechanism():
    return {
        "id": "manufactured-isomer", "status": "manufactured", "schema_version": 1,
        "species": [{"id": "A", "elements": {"N": 1}}, {"id": "B", "elements": {"N": 1}}],
        "reactions": [{"id": "decay", "reactants": {"A": 1}, "products": {"B": 1},
                       "rate": {"type": "constant", "A": 2.0},
                       "source": "manufactured numerical control"}],
    }


def electron_request():
    return {
        "processes": [{"kind": "elastic", "target": "X", "mass_ratio": 9.1093837015e-31 / (28 * 1.66053906660e-27),
                       "energy_ev": [0, 1000], "cross_section_m2": [1e-19, 1e-19]}],
        "conditions": {"fractions": {"X": 1.0}, "reduced_field_td": 10, "gas_density_m3": 1e20, "ion_fraction": 0},
        "grid": {"cells": 64, "max_energy_ev": 60, "legendre_terms": 4},
    }


def coupled_request():
    """Manufactured gas/liquid control; capacities are numerical test inputs."""
    model = {
        "id": "manufactured-coupled-cell",
        "species": [
            {"id": "N", "elements": {"N": 1}}, {"id": "N+", "elements": {"N": 1}, "charge": 1},
            {"id": "e", "charge": -1, "mass_kg": 9.1093837015e-31},
            {"id": "L0", "phase": "liquid", "elements": {"N": 1}},
            {"id": "L1", "phase": "liquid", "elements": {"N": 1}},
        ],
        "reactions": [
            {"id": "ionize", "reactants": {"e": 1, "N": 1}, "products": {"e": 2, "N+": 1},
             "rate": {"type": "electron_eedf"}, "collision_label": "ionize"},
            {"id": "recombine", "reactants": {"e": 1, "N+": 1}, "products": {"N": 1},
             "rate": {"type": "electron_eedf"}, "collision_label": "recombine"},
            {"id": "liquid-heat", "basis_phase": "liquid", "reactants": {"L0": 1}, "products": {"L1": 1},
             "rate": {"type": "constant", "A": 1e6},
             "energy_eV_per_event": {"liquid/heavy": 1, "liquid/internal": -1}, "external_energy_eV_per_event": 0},
        ],
    }
    closure = {
        "gas_density_m3": 1e20, "strict_event_mapping": True,
        "grid": {"cells": 80, "max_energy_ev": 40, "power": 2, "legendre_terms": 4},
        "processes": [
            {"kind": "elastic", "target": "N", "label": "elastic", "mass_ratio": 9.1093837015e-31 / (14 * 1.66053906660e-27),
             "energy_ev": [0, 1000], "cross_section_m2": [1e-19, 1e-19]},
            {"kind": "ionization", "target": "N", "label": "ionize", "threshold_ev": 2,
             "energy_ev": [2, 5, 100], "cross_section_m2": [0, 1e-21, 1e-21]},
            {"kind": "recombination", "target": "N+", "label": "recombine",
             "energy_ev": [0, 100], "cross_section_m2": [1e-21, 1e-21]},
        ],
    }
    return {"mechanism": model, "state": {"densities_m3": {"N": 1e20, "N+": 0, "e": 1e12, "L0": 1e18, "L1": 0}},
            "electron_closure": closure, "initial_mean_energy_ev": 1, "field_magnitude_V_m": 10, "dt_s": 1e-9,
            "options": {"relative_tolerance": 1e-8, "temperature_tolerance_K": 1e-10,
                        "heat_capacity_J_m3_K": {"gas": 1e-10, "liquid": 1e-3},
                        "thermal_reservoirs": {"liquid": ["liquid/heavy"]}}}


def local_field_request(mode, linear_solver="krylov", potential_V=200.0):
    """Manufactured drift-diffusion gap: elastic, excitation and ionization on one target, electrons from a closure."""
    me = 9.1093837015e-31
    processes = [
        {"kind": "elastic", "target": "N", "label": "elastic", "mass_ratio": me / (14 * 1.66053906660e-27),
         "energy_ev": [0, 1000], "cross_section_m2": [1e-19, 1e-19]},
        {"kind": "excitation", "target": "N", "label": "excite", "threshold_ev": 5,
         "energy_ev": [5, 8, 100], "cross_section_m2": [0, 1e-20, 1e-20]},
        {"kind": "ionization", "target": "N", "label": "ionize", "threshold_ev": 12,
         "energy_ev": [12, 20, 100], "cross_section_m2": [0, 1e-20, 1e-20]},
    ]
    model = {
        "id": "manufactured-local-field", "status": "manufactured", "schema_version": 1,
        "species": [{"id": "e", "charge": -1, "mass_kg": me}, {"id": "N", "elements": {"N": 1}},
                    {"id": "N+", "elements": {"N": 1}, "charge": 1}],
        "reactions": [
            {"id": "ionize", "reactants": {"e": 1, "N": 1}, "products": {"e": 2, "N+": 1},
             "rate": {"type": "electron_eedf"}, "collision_label": "ionize"},
            {"id": "excite", "reactants": {"e": 1, "N": 1}, "products": {"e": 1, "N": 1},
             "rate": {"type": "electron_eedf"}, "collision_label": "excite"},
        ],
    }
    closure = {"mode": mode, "electron_species": "e", "processes": processes,
               "grid": {"cells": 64, "max_energy_ev": 100, "power": 2, "legendre_terms": 2}}
    if mode == "local_field_table":
        closure["reduced_fields_td"] = [10 ** (k / 10) for k in range(-10, 41)]
        closure["table_conditions"] = {"gas_temperature_K": 300, "gas_density_m3": 2.5e25, "fractions": {"N": 1.0}}
    return {"mechanism": model, "mesh": {"dimension": 2, "shape": [8, 1, 1], "extent_m": [1e-4, 1e-4, 1e-4]},
            "transport": {"N+": {"mobility_m2_V_s": 2e-4, "diffusion_m2_s": 5e-6}},
            "initial_densities_m3": {"e": 1e14, "N": 2.5e25, "N+": 1e14},
            "boundaries": {"xmin": {"kind": "electrode", "potential_V": 0},
                           "xmax": {"kind": "electrode", "potential_V": potential_V}},
            "environment": {"gas_temperature_K": 300}, "electron_closure": closure,
            "time": {"time_step_s": 1e-11, "end_time_s": 2e-10}, "solver": {"linear_solver": linear_solver}}


class RuntimePythonTests(unittest.TestCase):
    def test_spherical_field_rotation_and_restart(self):
        request = electron_request()
        request["conditions"].pop("reduced_field_td")
        request.update(initial={"electron_density_m3": 1e12, "mean_energy_ev": 2.0},
                       electric_field_V_m=[0.0, 0.0, 10.0], dt_s=1e-10)
        first = raikou.advance_spherical_eedf(request)
        state = first["state"]
        self.assertEqual(state["representation"], "real_spherical_harmonics")
        self.assertEqual(len(state["density_modes"]), 64 * 4 * 4)
        request.pop("initial")
        request["state"] = state
        request["electric_field_V_m"] = [10.0, 0.0, 0.0]
        before = copy.deepcopy(request)
        second = raikou.advance_spherical_eedf(request)
        self.assertAlmostEqual(second["state"]["electron_density_m3"] / 1e12, 1.0, places=8)
        self.assertAlmostEqual(second["state"]["time_s"], 2e-10)
        self.assertEqual(request, before)
        evaluated = raikou.evaluate_spherical_eedf(request)
        self.assertEqual(len(evaluated["density_mode_rates"]), len(state["density_modes"]))
        broken = copy.deepcopy(request)
        broken["state"]["representation"] = "axisymmetric_legendre_fixed_direction"
        with self.assertRaises(raikou.RaikouError):
            raikou.advance_spherical_eedf(broken)

    def test_owned_chemistry_api(self):
        request = {"mechanism": mechanism(), "state": {"row_begin": 0, "densities_m3": [1.0, 0.0]},
                   "dt_s": 0.01}
        before = copy.deepcopy(request)
        evaluated = raikou.evaluate_chemistry_distributed(request)
        self.assertEqual(evaluated["global_rows"], 2)
        self.assertEqual(evaluated["production_rates_m3_s"], [-2.0, 2.0])
        advanced = raikou.advance_chemistry_distributed(request)
        self.assertTrue(advanced["success"], advanced["message"])
        self.assertEqual(advanced["state"]["row_begin"], 0)
        self.assertAlmostEqual(sum(advanced["state"]["densities_m3"]), 1.0)
        serial = raikou.advance_chemistry(mechanism=mechanism(), state={"densities_m3": {"A": 1.0, "B": 0.0}}, dt_s=0.01)
        self.assertAlmostEqual(advanced["state"]["densities_m3"][0], serial["state"]["densities_m3"]["A"], places=10)
        self.assertEqual(request, before)

    def test_shared_mechanism_batches(self):
        request = {"mechanism": mechanism(), "cells": [
            {"state": {"densities_m3": {"A": 1.0, "B": 0.0}}},
            {"state": {"densities_m3": {"A": 2.0, "B": 0.0}}},
        ], "dt_s": 0.01, "execution": {"device": "cpu", "threads": 2}}
        before = copy.deepcopy(request)
        evaluated = raikou.evaluate_chemistry_batch(request)
        self.assertEqual(evaluated["species_order"], ["A", "B"])
        self.assertEqual(evaluated["cells"][1]["production_rates_m3_s"], [-4.0, 4.0])
        advanced = raikou.advance_chemistry_batch(request)
        self.assertTrue(advanced["success"])
        self.assertEqual(advanced["completed_cells"], 2)
        for i, result in enumerate(advanced["cells"]):
            self.assertAlmostEqual(sum(result["state"]["densities_m3"].values()), i + 1)
        self.assertEqual(request, before)
        if raikou.capabilities()["cuda"]:
            request["execution"] = {"device": "cuda"}
            gpu = raikou.advance_chemistry_batch(request)
            self.assertTrue(gpu["success"])
            self.assertGreater(gpu["transfers"]["host_to_device_bytes"], 0)
            for expected, actual in zip(advanced["cells"], gpu["cells"]):
                self.assertAlmostEqual(expected["state"]["densities_m3"]["A"], actual["state"]["densities_m3"]["A"], places=8)

    def cli(self, command, payload=None, *options, env=None):
        environment = os.environ.copy()
        if not INSTALLED:
            environment["PYTHONPATH"] = str(ROOT / "python")
        if env:
            environment.update(env)
        arguments = [sys.executable, "-m", "raikou", command, *options]
        if payload is not None:
            arguments.extend(["--input", "-"])
        return subprocess.run(arguments, input=payload, capture_output=True, text=True,
                              env=environment, timeout=60, check=False)

    def test_capabilities_and_backend_truth(self):
        if INSTALLED:
            self.assertNotEqual(Path(raikou.__file__).resolve().parent, ROOT / "python" / "raikou",
                                "Installed-wheel tests must not import the source Python package")
            from raikou import _core
            self.assertTrue(callable(_core.execute))
        result = raikou.capabilities()
        self.assertEqual(result["version"], raikou.__version__)
        self.assertTrue(result["cpu"])
        self.assertIn("eedf.advance", result["operations"])
        self.assertIsInstance(result["cuda"], bool)
        self.assertFalse(result["mpi_initialized"], "The binding must not initialize MPI")

    def test_linear_analytic_solution(self):
        result = raikou.linear_solve(
            matrix={"rows": 2, "offsets": [0, 2, 4], "columns": [0, 1, 0, 1], "values": [4, 1, 1, 3]},
            rhs=[1, 2], execution={"device": "cpu", "threads": 1, "tolerance": 1e-12},
        )
        self.assertTrue(result["converged"])
        self.assertAlmostEqual(result["solution"][0], 1 / 11, places=12)
        self.assertAlmostEqual(result["solution"][1], 7 / 11, places=12)
        self.assertLess(result["residual"], 1e-11)

    def test_batch_order_and_independent_failure(self):
        result = raikou.execute_batch([
            {"operation": "water.levels", "request": {"j_max": 1}},
            {"operation": "unknown.operation"},
            {"operation": "water.levels", "request": {"j_max": 2}},
        ], execution={"threads": 2})
        self.assertEqual([item["index"] for item in result["results"]], [0, 1, 2])
        self.assertTrue(result["results"][0]["ok"])
        self.assertFalse(result["results"][1]["ok"])
        self.assertTrue(result["results"][1]["error"])
        self.assertTrue(result["results"][2]["ok"])
        self.assertEqual(result["results"][2]["result"], raikou.water_levels(j_max=2))

    def test_explicit_mpi_without_host_initialization_fails(self):
        with self.assertRaises(raikou.RaikouError):
            raikou.linear_solve(matrix={"rows": 1, "offsets": [0, 1], "columns": [0], "values": [1]},
                                rhs=[1], execution={"mpi": True})
        self.assertFalse(raikou.capabilities()["mpi_initialized"])

    def test_missing_cuda_does_not_fallback(self):
        if raikou.capabilities()["cuda"]:
            return
        with self.assertRaises(raikou.RaikouError):
            raikou.linear_solve(matrix={"rows": 1, "offsets": [0, 1], "columns": [0], "values": [1]},
                                rhs=[1], execution={"device": "cuda"})

    def test_mechanism_conservation_validation(self):
        model = mechanism()
        self.assertTrue(raikou.validate_mechanism(model)["valid"])
        model["species"][1]["elements"]["N"] = 2
        invalid = raikou.validate_mechanism(model)
        self.assertFalse(invalid["valid"])
        self.assertTrue(invalid["errors"])

    def test_chemistry_source_and_analytic_jacobian(self):
        request = {"mechanism": mechanism(), "state": {"A": 5.0, "B": 0.0}}
        saved = copy.deepcopy(request)
        result = raikou.evaluate_chemistry(request)
        self.assertEqual(request, saved)
        self.assertEqual(result["production_rates_m3_s"], {"A": -10.0, "B": 10.0})
        self.assertEqual(result["jacobian_row_major"], [-2.0, 0.0, 2.0, 0.0])

    def test_chemistry_advance_decay_and_inventory(self):
        result = raikou.advance_chemistry(mechanism=mechanism(), state={"A": 1, "B": 0}, dt_s=1.0,
                                          options={"relative_tolerance": 1e-6, "absolute_tolerance_m3": 1e-10})
        self.assertTrue(result["success"], result["message"])
        state = result["state"]["densities_m3"]
        self.assertAlmostEqual(state["A"], math.exp(-2), delta=5e-4)
        self.assertAlmostEqual(state["A"] + state["B"], 1.0, places=12)

    def test_solver_failure_status_is_preserved(self):
        result = raikou.advance_chemistry(mechanism=mechanism(), state={"A": 1, "B": 0}, dt_s=1.0,
                                          options={"maximum_steps": 1, "relative_tolerance": 1e-9,
                                                   "absolute_tolerance_m3": 1e-12})
        self.assertFalse(result["success"])
        self.assertEqual(result["advanced_time_s"], 0)
        self.assertEqual(result["state"]["densities_m3"], {"A": 1.0, "B": 0.0})
        self.assertTrue(result["message"])

    def test_eedf_solve_and_full_state_restart(self):
        request = electron_request()
        steady = raikou.solve_eedf(request)
        self.assertTrue(steady["converged"])
        self.assertEqual(steady["mode"], "steady")
        self.assertGreater(steady["mean_energy_ev"], 0)
        first = raikou.advance_eedf(request, initial={"electron_density_m3": 1e8, "mean_energy_ev": 1}, dt_s=1e-10)
        self.assertEqual(len(first["state"]["density_modes"]), 64 * 4)
        resumed = raikou.advance_eedf(request, state=first["state"], dt_s=1e-10)
        self.assertAlmostEqual(resumed["state"]["time_s"], 2e-10, delta=1e-23)
        self.assertGreater(resumed["state"]["electron_density_m3"], 0)

    def test_water_level_population_normalization(self):
        result = raikou.water_levels(j_max=2)
        self.assertGreater(len(result["levels"]), 1)
        self.assertAlmostEqual(sum(level["fraction"] for level in result["levels"]), 1.0, places=12)

    def test_coupled_cell_inventory_heat_and_checkpoint(self):
        request = coupled_request()
        original = copy.deepcopy(request)
        result = raikou.advance_coupled_cell(request)
        self.assertEqual(request, original)
        self.assertLessEqual(result["nonlinear_residual"], 1)
        state = result["state"]["densities_m3"]
        self.assertGreater(state["N+"], 0)
        self.assertGreater(state["e"], 1e12)
        self.assertTrue(math.isclose(state["N"] + state["N+"], 1e20, rel_tol=1e-12))
        self.assertTrue(math.isclose(state["L0"] + state["L1"], 1e18, rel_tol=1e-12))
        self.assertAlmostEqual(state["N+"] - state["e"], -1e12, delta=100)
        self.assertGreater(result["environment"]["gas_temperature_K"], 300)
        self.assertGreater(result["environment"]["liquid_temperature_K"], 300)
        self.assertEqual(len(result["electrons"]["density_modes"]), 80 * 4)
        request.update(state=result["state"], environment=result["environment"], electrons=result["electrons"])
        request.pop("initial_mean_energy_ev")
        resumed = raikou.advance_coupled_cell(request)
        self.assertAlmostEqual(resumed["electrons"]["time_s"], 2e-9, delta=1e-22)
        self.assertGreater(resumed["state"]["densities_m3"]["N+"], state["N+"])

    def test_coupled_cell_failed_trial_is_transactional(self):
        request = coupled_request()
        request["options"].update(maximum_newton_iterations=1, relative_tolerance=1e-13,
                                   absolute_density_tolerance_m3=1e-5, temperature_tolerance_K=1e-13)
        original = copy.deepcopy(request)
        with self.assertRaises(raikou.RaikouError):
            raikou.advance_coupled_cell(request)
        self.assertEqual(request, original)

    def test_packaged_mechanism_loading(self):
        self.assertIn("aqueous_reference_subset", raikou.available_mechanisms())
        model = raikou.load_mechanism("aqueous_reference_subset")
        self.assertTrue(raikou.validate_mechanism(model)["valid"])
        self.assertEqual(model, raikou.load_mechanism("aqueous_reference_subset.json"))
        with self.assertRaises(ValueError):
            raikou.load_mechanism("../outside")
        if INSTALLED:
            self.assertTrue(files("raikou").joinpath("licenses", "NOTICE").is_file())
            self.assertTrue(files("raikou").joinpath("licenses", "nlohmann-json-LICENSE.MIT").is_file())
            self.assertTrue(files("raikou").joinpath("mechanisms", "GEANT4-LICENSE.txt").is_file())
            if raikou.capabilities().get("cuda_built"):
                license_text = files("raikou").joinpath("licenses", "NVIDIA-CUDA-runtime-LICENSE.txt").read_text(encoding="utf-8")
                self.assertGreater(len(license_text), 10000)

    def test_threaded_dll_process_shutdown(self):
        # A DLL must drain submitted work before returning, not join persistent
        # native threads later under the Windows process-detach loader lock.
        code = "import raikou; r=raikou.execute_batch([{'operation':'capabilities'}]*64,execution={'threads':4}); assert len(r['results'])==64"
        environment = os.environ.copy()
        if not INSTALLED:
            environment["PYTHONPATH"] = str(ROOT / "python")
        subprocess.run([sys.executable, "-c", code], env=environment, check=True, timeout=15,
                       stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

    def test_breakdown_short_interval(self):
        result = raikou.solve_breakdown(electron_request(),
            setup={"end_time_s": 1e-12, "outputs": 2, "seed_density_m3": 1e8, "voltage_v": 1})
        self.assertGreaterEqual(len(result["samples"]), 2)
        self.assertAlmostEqual(result["samples"][-1]["time_s"], 1e-12, delta=1e-23)
        self.assertIn("energy_J", result)

    def test_owned_eedf_restart_matches_serial(self):
        request = electron_request()
        request["initial"] = {"electron_density_m3": 1e8, "mean_energy_ev": 1}
        request["dt_s"] = 1e-12
        reference = raikou.advance_eedf(request)
        result = raikou.advance_eedf_distributed(request)
        self.assertEqual(result["state"]["global_rows"], 64 * 4)
        self.assertEqual(result["state"]["row_begin"], 0)
        self.assertEqual(result["state"]["representation"], "axisymmetric_legendre_owned_energy_cells")
        expected = reference["state"]["density_modes"]
        actual = result["state"]["density_modes"]
        scale = max(abs(value) for value in expected)
        self.assertLess(max(abs(a - b) for a, b in zip(actual, expected)), 1e-6 * scale)
        resumed = dict(request)
        resumed.pop("initial")
        resumed["state"] = result["state"]
        next_result = raikou.advance_eedf_distributed(resumed)
        self.assertAlmostEqual(next_result["state"]["time_s"], 2e-12, delta=1e-24)
        resumed["state"] = copy.deepcopy(result["state"])
        resumed["state"]["representation"] = "real_spherical_harmonics"
        with self.assertRaises(raikou.RaikouError):
            raikou.advance_eedf_distributed(resumed)

    def test_local_field_table_follows_the_steady_closure(self):
        steady = raikou.solve_spatial(**local_field_request("steady_boltzmann"))
        table = raikou.solve_spatial(**local_field_request("local_field_table"))
        self.assertTrue(steady["success"], steady["message"])
        self.assertTrue(table["success"], table["message"])
        self.assertGreater(max(table["densities_m3"]["e"]), 2e14)          # the gap ionizes
        for a, b in zip(steady["densities_m3"]["e"], table["densities_m3"]["e"]):
            self.assertAlmostEqual(b / a, 1.0, delta=2e-3)
        zero = raikou.solve_spatial(**local_field_request("local_field_table", potential_V=0.0))
        self.assertTrue(zero["success"], zero["message"])                     # tail rates below roundoff are floored
        broken = local_field_request("local_field_table")
        broken["electron_closure"]["reduced_fields_td"] = [10.0]
        with self.assertRaises(raikou.RaikouError):
            raikou.solve_spatial(**broken)

    def test_direct_linear_solver_matches_krylov(self):
        krylov = raikou.solve_spatial(**local_field_request("local_field_table"))
        try:
            direct = raikou.solve_spatial(**local_field_request("local_field_table", linear_solver="direct"))
        except raikou.RaikouError as error:
            if "Eigen" in str(error):
                self.skipTest("this build has no sparse direct solver")
            raise
        self.assertTrue(direct["success"], direct["message"])
        self.assertEqual(direct["accepted_steps"], krylov["accepted_steps"])
        for a, b in zip(krylov["densities_m3"]["e"], direct["densities_m3"]["e"]):
            self.assertAlmostEqual(b / a, 1.0, delta=1e-8)
        with self.assertRaises(raikou.RaikouError):
            raikou.solve_spatial(**local_field_request("local_field_table", linear_solver="cholesky"))

    def test_spatial_constant_neutral_potential(self):
        model = {"id": "neutral-control", "species": [{"id": "H", "elements": {"H": 1}}], "reactions": []}
        result = raikou.solve_spatial(
            mechanism=model, mesh={"dimension": 2, "shape": [3, 1, 1], "extent_m": [1e-3, 2e-3, 1e-3]},
            transport={"H": {"diffusion_m2_s": 0}}, initial_densities_m3={"H": 1e10},
            boundaries={"xmin": {"kind": "electrode", "potential_V": 0},
                        "xmax": {"kind": "electrode", "potential_V": 6}},
            time={"time_step_s": 1e-9, "end_time_s": 0},
        )
        self.assertTrue(result["success"], result["message"])
        for actual, expected in zip(result["potential_V"], [1, 3, 5]):
            self.assertAlmostEqual(actual, expected, places=8)
        self.assertEqual(result["densities_m3"]["H"], [1e10] * 3)

    def test_owned_spatial_arrays_and_checkpoint(self):
        request = {
            "mechanism": mechanism(),
            "mesh": {"dimension": 2, "shape": [2, 1, 1], "extent_m": [1, 1, 1]},
            "initial_densities_m3": {"A": 0, "B": 0}, "transport": {},
            "local_initial": {"cell_begin": 0, "cell_count": 2,
                              "densities_m3": {"A": [1e6, 1.2e6]}},
            "boundaries": {"xmin": {"kind": "electrode", "potential_V": 0},
                           "xmax": {"kind": "electrode", "potential_V": 1}},
            "time": {"time_step_s": 0.005, "end_time_s": 0.02, "bdf2": True, "adaptive": False},
        }
        original = copy.deepcopy(request)
        first = raikou.solve_spatial_distributed(request)
        self.assertTrue(first["success"], first["message"])
        self.assertEqual(request, original)
        self.assertEqual(first["state"]["representation"], "owned_cell_dof_v1")
        self.assertEqual(first["cell_count"], 2)
        self.assertEqual(len(first["state"]["owned_values"]), first["storage"]["local_unknowns"])
        self.assertAlmostEqual(sum(first["particle_counts"].values()), 1.1e6, delta=1e-5)
        resumed_request = copy.deepcopy(request)
        resumed_request.pop("local_initial")
        resumed_request["checkpoint"] = first["checkpoint"]
        resumed_request["time"]["end_time_s"] = 0.04
        resumed = raikou.solve_spatial_distributed(resumed_request)
        request["time"]["end_time_s"] = 0.04
        full = raikou.solve_spatial_distributed(request)
        self.assertTrue(resumed["success"], resumed["message"])
        self.assertTrue(full["success"], full["message"])
        for actual, expected in zip(resumed["state"]["owned_values"], full["state"]["owned_values"]):
            self.assertAlmostEqual(actual, expected, delta=2e-10 * max(1, abs(expected)))
        request["initial_densities_m3"]["A"] = [1e6, 1.2e6]
        with self.assertRaises(raikou.RaikouError):
            raikou.solve_spatial_distributed(request)

    def test_request_validation_and_native_errors(self):
        for operation in ("", "bad\0operation", None):
            with self.subTest(operation=operation), self.assertRaises(ValueError):
                raikou.execute(operation)
        with self.assertRaises(TypeError):
            raikou.execute("capabilities", [])
        with self.assertRaises(TypeError):
            raikou.execute("capabilities", {1: "key"})
        with self.assertRaises(TypeError):
            raikou.execute("capabilities", {"x": 1}, x=2)
        with self.assertRaises(ValueError):
            raikou.execute("capabilities", {"x": float("nan")})
        with self.assertRaises(raikou.RaikouError):
            raikou.execute("unknown.operation")
        with self.assertRaises(raikou.RaikouError):
            raikou.linear_solve({})

    def test_cli_runtime_json_and_legacy(self):
        result = self.cli("water.levels", '{"j_max":2}')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout), raikou.water_levels(j_max=2))
        old = self.cli("evaluate", '{"Te_eV":4}')
        self.assertEqual(old.returncode, 0, old.stderr)
        self.assertEqual(json.loads(old.stdout), raikou.evaluate(Te_eV=4))

    def test_cli_solver_failure_keeps_diagnostics_and_fails(self):
        payload = {"mechanism": mechanism(), "state": {"A": 1, "B": 0}, "dt_s": 1,
                   "options": {"maximum_steps": 1, "relative_tolerance": 1e-9, "absolute_tolerance_m3": 1e-12}}
        result = self.cli("chemistry.advance", json.dumps(payload))
        self.assertEqual(result.returncode, 1)
        self.assertFalse(json.loads(result.stdout)["success"])
        batch = self.cli("batch.execute", '{"jobs":[{"operation":"unknown.operation"}]}')
        self.assertEqual(batch.returncode, 1)
        self.assertFalse(json.loads(batch.stdout)["results"][0]["ok"])

    def test_cli_errors_are_json_clean(self):
        for payload in ("[]", "{", '{"j_max":NaN}', '{"j_max":1,"j_max":2}', '{"j_max":1e999}'):
            with self.subTest(payload=payload):
                result = self.cli("water.levels", payload)
                self.assertEqual(result.returncode, 2)
                self.assertEqual(result.stdout, "")
                self.assertNotIn("Traceback", result.stderr)
        malformed = self.cli("linear.solve", "{}")
        self.assertEqual(malformed.returncode, 2)
        self.assertNotIn("Traceback", malformed.stderr)
        missing = self.cli("capabilities", env={"RAIKOU_LIBRARY": str(ROOT / "missing-runtime-library")})
        self.assertEqual(missing.returncode, 2)
        self.assertIn("RAIKOU_LIBRARY", missing.stderr)


def wheel_smoke(wheel):
    wheel = Path(wheel).resolve(strict=True)
    with tempfile.TemporaryDirectory(prefix="raikou-wheel-") as folder:
        root = Path(folder)
        environment = os.environ.copy()
        for key in ("PYTHONPATH", "RAIKOU_LIBRARY", "RAIKOU_DLL_DIRECTORIES", "RAIKOU_TEST_INSTALLED"):
            environment.pop(key, None)
        venv.EnvBuilder(with_pip=True).create(root / "venv")
        bindir = root / "venv" / ("Scripts" if os.name == "nt" else "bin")
        python = bindir / ("python.exe" if os.name == "nt" else "python")
        subprocess.run([str(python), "-m", "pip", "install", "--no-index", "--no-deps", str(wheel)],
                       cwd=root, env=environment, check=True)
        subprocess.run([str(python), "-I", "-c", "import raikou; import raikou._core; "
                        "assert raikou.capabilities()['cpu']; assert raikou.evaluate()['populations_m3'][0] > 0"],
                       cwd=root, env=environment, check=True)
        console = bindir / ("raikou.exe" if os.name == "nt" else "raikou")
        subprocess.run([str(console), "capabilities"], cwd=root, env=environment, check=True)
        environment["RAIKOU_TEST_INSTALLED"] = "1"
        subprocess.run([str(python), str(Path(__file__).resolve())], cwd=root, env=environment, check=True)
    print("Clean wheel installation and native extension smoke test passed.")


if __name__ == "__main__":
    if len(sys.argv) == 3 and sys.argv[1] == "--wheel":
        wheel_smoke(sys.argv[2])
    else:
        unittest.main()
