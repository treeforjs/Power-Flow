# Installed SDK smoke tests

After installing a CPU build of Raikou, run:

```sh
python tests/sdk/smoke.py --prefix install --build-dir build-sdk-smoke --config Release
```

The runner builds two separate external CMake projects using only
`find_package(Raikou 1.0 CONFIG REQUIRED)`. The C project requests only
`COMPONENTS c`, and disables discovery of MPI, CUDA and Threads development
packages to verify the shared ABI has no native compiler dependency. The C++ project checks analytic
chemistry sources, Jacobian, decay and inventory conservation, then advances an
elastic EEDF through the public C++ API and checks electron number, energy and
checkpoint ownership. The second project enables only the C language and
checks successful/failed C ABI calls, unchanged outputs, JSON error envelopes
and repeated allocation/release of native strings.

Both consumers and the installed `raikou-native` executable run from a scratch
directory without compiler directories or library-search overrides in their
runtime environment. The test requires Python, CMake and the compiler used to
build the SDK; it installs no additional Python dependencies.

An installed shared library built with MPI and CUDA can be checked without
their development toolchains using `--c-only --expect-mpi --expect-cuda`.
On Windows, add `--runtime-directory C:/path/to/MPI/bin` when the MPI runtime
DLL is outside the system loader directories. The reduced runtime PATH then
contains that explicit runtime directory, the SDK bin directory and system
directories; no CUDA toolkit or compiler directory is added.
