#include <raikou/chemistry.h>
#include <raikou/chemistry_distributed.h>
#include <raikou/electron_boltzmann.h>
#include <raikou/eedf_distributed.h>
#include <raikou/spatial_distributed.h>

#include <algorithm>
#include <cmath>
#include <iostream>
#include <stdexcept>
#include <string>

namespace {
void require(bool condition, const std::string& message) {
    if (!condition) throw std::runtime_error(message);
}
bool near(double actual, double expected, double relative = 1e-10) {
    return std::isfinite(actual) && std::abs(actual - expected) <=
        relative * std::max({std::abs(actual), std::abs(expected), 1e-300});
}

void chemistry_control() {
    const auto mechanism = raikou::chemistry::Mechanism::from_json(raikou::Json::parse(R"({
        "id":"installed-sdk-isomer-control",
        "species":[{"id":"A","elements":{"N":1}},{"id":"B","elements":{"N":1}}],
        "reactions":[{"id":"decay","reactants":{"A":1},"products":{"B":1},
                      "rate":{"type":"constant","A":2},"source":"manufactured numerical control"}]
    })"));
    require(mechanism.validate().empty(), "Installed chemistry mechanism validation failed");
    const raikou::chemistry::State seed{{1.0, 0.0}};
    const auto rate = raikou::chemistry::evaluate(mechanism, seed);
    require(near(rate.production_rates_m3_s[0], -2.0) && near(rate.production_rates_m3_s[1], 2.0),
        "Installed chemistry source disagrees with analytic decay");
    require(near(rate.jacobian_row_major[0], -2.0) && near(rate.jacobian_row_major[2], 2.0),
        "Installed chemistry Jacobian disagrees with analytic derivative");
    raikou::chemistry::AdvanceOptions options;
    options.relative_tolerance = 1e-6;
    options.absolute_tolerance_m3 = 1e-10;
    const auto result = raikou::chemistry::advance(mechanism, seed, {}, 0.25, options);
    require(result.success, "Installed chemistry advance failed: " + result.message);
    require(std::abs(result.state.densities_m3[0] - std::exp(-0.5)) < 5e-4,
        "Installed chemistry trajectory disagrees with exp(-2t)");
    require(near(result.state.densities_m3[0] + result.state.densities_m3[1], 1.0),
        "Installed chemistry lost the conserved isomer inventory");
    require(seed.densities_m3 == std::vector<double>({1.0, 0.0}), "Chemistry mutated its input state");
    const raikou::chemistry::DistributedState local{{2, 0, 2}, {1.0, 0.0}};
    const auto owned = raikou::chemistry::evaluate_distributed(mechanism, local);
    require(owned.jacobian.local_rows() == 2 && near(owned.production_rates_m3_s[0], -2),
        "Installed owned chemistry API failed");
}

void electron_control() {
    namespace kinetic = raikou::kinetics;
    kinetic::CollisionProcess elastic;
    elastic.kind = kinetic::CollisionKind::Elastic;
    elastic.target = "X";
    elastic.label = "manufactured infinite-mass elastic control";
    elastic.mass_ratio = 0.0;
    elastic.energy_ev = {0.0, 1000.0};
    elastic.cross_section_m2 = {1e-19, 1e-19};
    kinetic::EedfGrid grid;
    grid.cells = 64;
    grid.max_energy_ev = 60;
    grid.legendre_terms = 4;
    kinetic::EedfConditions conditions;
    conditions.reduced_field_td = 0;
    conditions.gas_density_m3 = 1e20;
    conditions.fractions = {{"X", 1.0}};
    conditions.ion_fraction = 0;
    const auto seed = kinetic::maxwellian_eedf(1e8, 1.0, grid);
    const auto original = seed.density_modes;
    const auto result = kinetic::advance_eedf({elastic}, conditions, seed, 1e-10);
    require(result.state.density_modes.size() == 64 * 4, "Installed EEDF omitted retained angular modes");
    require(near(result.state.electron_density_m3(), seed.electron_density_m3()),
        "Installed elastic EEDF advance lost electron number");
    require(near(result.state.electron_energy_ev_m3(), seed.electron_energy_ev_m3()),
        "Installed infinite-mass zero-field EEDF advance lost electron energy");
    require(near(result.state.time_s, 1e-10), "Installed EEDF did not advance time");
    require(seed.density_modes == original, "EEDF mutated its input checkpoint");
    const auto local = kinetic::maxwellian_eedf_distributed(1e8, 1, grid);
    const auto owned = kinetic::advance_eedf_distributed({elastic}, conditions, local, 1e-10);
    require(owned.state.density_modes.size() == original.size() && owned.state.time_s == 1e-10,
        "Installed owned EEDF API failed");
}

void spatial_control() {
    auto model = std::make_shared<raikou::spatial::Problem>(raikou::spatial::problem_from_json(raikou::Json::parse(R"({
        "mechanism":{"id":"installed-spatial","species":[{"id":"H","elements":{"H":1}}],"reactions":[]},
        "mesh":{"dimension":2,"shape":[2,1,1],"extent_m":[1,1,1]},
        "initial_densities_m3":{"H":1e10},"transport":{},
        "boundaries":{"xmin":{"kind":"electrode","potential_V":0},"xmax":{"kind":"electrode","potential_V":2}},
        "time":{"time_step_s":1e-9,"end_time_s":0}
    })"), false));
    raikou::spatial::DistributedProblem problem; problem.model = model;
    const auto result = raikou::spatial::solve_distributed(problem);
    require(result.success && result.state.owned_values.size() == 4 && result.particle_counts.size() == 1,
        "Installed owned spatial API failed");
    require(near(result.particle_counts[0], 1e10), "Installed spatial inventory is incorrect");
}
}

int main() {
    try {
        chemistry_control();
        electron_control();
        spatial_control();
        std::cout << "Installed C++ chemistry, EEDF and owned spatial controls passed\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << error.what() << '\n';
        return 1;
    }
}
