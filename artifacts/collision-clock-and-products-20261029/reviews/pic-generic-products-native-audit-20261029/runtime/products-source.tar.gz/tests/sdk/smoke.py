"""Build external C++ and C-only consumers of an installed Raikou CPU SDK.

No source-tree libraries, headers or runtime search paths are supplied to the
consumers. Compiler tools are available during compilation only. Executables
run from a scratch directory with a reduced runtime environment.
"""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess


def executable(directory: Path, name: str, config: str) -> Path:
    suffix = ".exe" if os.name == "nt" else ""
    for path in (directory / config / (name + suffix), directory / (name + suffix)):
        if path.is_file():
            return path
    raise FileNotFoundError(f"Cannot find built {name} below {directory}")


def runtime_environment(prefix: Path, runtime_directories=()) -> dict[str, str]:
    environment = os.environ.copy()
    for key in ("LD_LIBRARY_PATH", "DYLD_LIBRARY_PATH", "DYLD_FALLBACK_LIBRARY_PATH",
                "RAIKOU_LIBRARY", "RAIKOU_DLL_DIRECTORIES", "PYTHONPATH"):
        environment.pop(key, None)
    if os.name == "nt":
        windows = Path(environment.get("SystemRoot", "C:/Windows"))
        paths = [prefix / "bin", *runtime_directories, windows / "System32", windows]
    else:
        paths = [prefix / "bin", *runtime_directories, Path("/usr/bin"), Path("/bin")]
    environment["PATH"] = os.pathsep.join(map(str, paths))
    return environment


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--prefix", type=Path, required=True, help="Installed Raikou SDK prefix")
    parser.add_argument("--build-dir", type=Path, default=Path("build-sdk-smoke"))
    parser.add_argument("--config", default="Release")
    parser.add_argument("--generator", help="Optional CMake generator for consumer builds")
    parser.add_argument("--c-only", action="store_true", help="Test only the shared C component and installed CLI")
    parser.add_argument("--runtime-directory", type=Path, action="append", default=[],
                        help="Explicit external runtime directory, such as the MPI DLL directory")
    parser.add_argument("--expect-mpi", action="store_true", help="Require MPI support in the installed library")
    parser.add_argument("--expect-cuda", action="store_true", help="Require CUDA support in the installed library")
    args = parser.parse_args(argv)
    prefix = args.prefix.resolve(strict=True)
    licenses = prefix / "share" / "raikou" / "licenses"
    if not (licenses / "NOTICE").is_file() or "Permission is hereby granted" not in (
            licenses / "nlohmann-json-LICENSE.MIT").read_text(encoding="utf-8"):
        raise AssertionError("Installed SDK is missing third-party notices or the full JSON MIT license")
    scratch = args.build_dir.resolve()
    cmake = shutil.which("cmake")
    if not cmake:
        raise FileNotFoundError("CMake is required for SDK consumer checks")
    sources = Path(__file__).resolve().parent
    working = scratch / "runtime"
    working.mkdir(parents=True, exist_ok=True)
    environment = runtime_environment(prefix, [path.resolve(strict=True) for path in args.runtime_directory])
    consumers = (("c", "raikou_sdk_c"),) if args.c_only else (("cpp", "raikou_sdk_cpp"), ("c", "raikou_sdk_c"))
    for language, target in consumers:
        build = scratch / language
        configure = [cmake, "-S", str(sources / language), "-B", str(build),
                     f"-DCMAKE_PREFIX_PATH={prefix}", f"-DCMAKE_BUILD_TYPE={args.config}"]
        if args.generator:
            configure.extend(["-G", args.generator])
        if language == "c":
            configure.extend(["--no-warn-unused-cli", "-DCMAKE_DISABLE_FIND_PACKAGE_MPI=ON", "-DCMAKE_DISABLE_FIND_PACKAGE_CUDAToolkit=ON",
                              "-DCMAKE_DISABLE_FIND_PACKAGE_Threads=ON"])
        subprocess.run(configure, check=True)
        subprocess.run([cmake, "--build", str(build), "--config", args.config, "--parallel", "2"], check=True)
        subprocess.run([str(executable(build, target, args.config))], cwd=working, env=environment, check=True)
    native = prefix / "bin" / ("raikou-native.exe" if os.name == "nt" else "raikou-native")
    legacy = prefix / "bin" / ("raikou.exe" if os.name == "nt" else "raikou")
    legacy_version = subprocess.run([str(legacy), "--version"], cwd=working, env=environment,
                                    capture_output=True, text=True, check=True)
    if "1.0.0" not in legacy_version.stdout:
        raise AssertionError("Installed compatibility CLI cannot load its shared C library")
    completed = subprocess.run([str(native), "capabilities"], cwd=working, env=environment,
                               capture_output=True, text=True, check=True)
    capabilities = json.loads(completed.stdout)
    if not capabilities.get("cpu") or "chemistry.advance" not in capabilities.get("operations", []):
        raise AssertionError(f"Installed runtime lacks required CPU operations: {capabilities}")
    if args.expect_mpi and not capabilities.get("mpi_built"):
        raise AssertionError("Installed shared runtime was not built with MPI")
    if args.expect_cuda and not capabilities.get("cuda_built"):
        raise AssertionError("Installed shared runtime was not built with CUDA")
    if capabilities.get("cuda_built"):
        cuda_license = licenses / "NVIDIA-CUDA-runtime-LICENSE.txt"
        if not cuda_license.is_file() or cuda_license.stat().st_size < 10000:
            raise AssertionError("CUDA SDK is missing the full matching NVIDIA runtime license")
    failed = subprocess.run([str(native), "unknown.operation"], cwd=working, env=environment,
                            capture_output=True, text=True, check=False)
    if failed.returncode == 0 or failed.stdout or not failed.stderr.strip():
        raise AssertionError("Installed CLI did not report an operation error cleanly")
    checked = "pure C" if args.c_only else "C++ and pure C"
    print(f"Installed SDK {checked} and clean-environment CLI smoke checks passed.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
