#include <raikou/c_api.h>

#include <math.h>
#include <stdio.h>
#include <string.h>

#define REQUIRE(condition, message) do { if (!(condition)) { fprintf(stderr, "%s\n", message); return 1; } } while (0)

int main(void) {
    int repeat;
    raikou_plasma_state state;
    raikou_radiance_result radiance;
    REQUIRE(raikou_version() && strlen(raikou_version()) > 0, "Installed C ABI has no version");
    REQUIRE(raikou_default_plasma_state(&state) == RAIKOU_OK, "Default state failed");
    REQUIRE(raikou_evaluate(&state, &radiance) == RAIKOU_OK, "Installed C ABI evaluate failed");
    REQUIRE(isfinite(radiance.lyman_alpha_radiance_W_m2_sr) && radiance.lyman_alpha_radiance_W_m2_sr > 0,
        "Installed C ABI returned invalid radiance");
    radiance.lyman_alpha_radiance_W_m2_sr = 42;
    state.ne_m3 = -1;
    REQUIRE(raikou_evaluate(&state, &radiance) == RAIKOU_INVALID_ARGUMENT, "Invalid state was accepted");
    REQUIRE(radiance.lyman_alpha_radiance_W_m2_sr == 42, "Failed C ABI call modified its output");
    REQUIRE(strlen(raikou_last_error()) > 0, "Failed C ABI call has no diagnostic");
    REQUIRE(raikou_default_plasma_state(&state) == RAIKOU_OK && strlen(raikou_last_error()) == 0,
        "Successful C ABI call did not clear its error");
    REQUIRE(raikou_execute_json("capabilities", "{}", NULL) != 0, "Null JSON output pointer was accepted");
    for (repeat = 0; repeat < 32; ++repeat) {
        char* output = NULL;
        int status = raikou_execute_json("capabilities", "{}", &output);
        REQUIRE(status == 0 && output, "Installed JSON C ABI success returned no allocated response");
        REQUIRE(strstr(output, "\"ok\":true") && strstr(output, "\"cpu\":true"), "Invalid JSON success envelope");
        raikou_free_string(output);
        output = NULL;
        status = raikou_execute_json("unknown.operation", "{}", &output);
        REQUIRE(status != 0 && output && strstr(output, "\"ok\":false") && strstr(output, "\"error\""),
            "Native failure did not return an allocated JSON error envelope");
        raikou_free_string(output);
        output = NULL;
        status = raikou_execute_json("capabilities", "{", &output);
        REQUIRE(status != 0 && output && strstr(output, "\"ok\":false"), "Malformed JSON was accepted");
        raikou_free_string(output);
    }
    raikou_free_string(NULL);
    puts("Installed pure C ABI status and string ownership controls passed");
    return 0;
}
