#include "raikou/spatial_kinetic_adapter.h"
#include "raikou/spatial.h"
#include <algorithm>
#include <cmath>
#include <iostream>
#include <stdexcept>
namespace {
using namespace raikou;
using namespace raikou::kinetics;
void check(bool value,const std::string& message){if(!value)throw std::runtime_error(message);}
bool near(double a,double b,double tolerance){return std::abs(a-b)<=tolerance*std::max({std::abs(a),std::abs(b),1e-100});}
spatial::Problem model(){
    spatial::Problem p;p.mesh.shape={2,1,1};p.mesh.extent_m={.001,.002,.001};
    p.mechanism.id="manufactured owned contact";
    p.mechanism.species={{"X","gas",{{"N",1}},0,28*1.66053906660e-27,true},{"X+","gas",{{"N",1}},1,28*1.66053906660e-27,true},{"e","gas",{},-1,9.1093837015e-31,true},{"e_aq","aqueous",{},-1,9.1093837015e-31,true}};
    p.boundaries[0].kind=spatial::BoundaryKind::Electrode;p.boundaries[1].kind=spatial::BoundaryKind::Electrode;
    p.electron_mode="transient_spherical";p.electron_closure.emplace();auto& kinetic=*p.electron_closure;kinetic.strict_event_mapping=true;kinetic.grid={.cells=16,.max_energy_ev=5,.power=2,.legendre_terms=3};
    CollisionProcess process;process.kind=CollisionKind::Elastic;process.target="X";process.label="elastic";process.mass_ratio=1e-5;process.energy_ev={0,1000};process.cross_section_m2={0,0};kinetic.processes={process};
    p.electron_phase_contacts[0]={{KineticWall::Absorbing,{}} ,"e_aq","aqueous"};return p;
}
void phase_contact(const backend::ExecutionOptions& execution,bool gas_heat=false){
    auto p=model();const auto geometry=spatial::mesh::geometry(p.mesh);
    if(gas_heat)p.electron_phase_contacts[0].energy_to_phase="gas";
    const auto partition=backend::distributed_partition(2,execution);const spatial::partition::CellInterval owned{static_cast<std::size_t>(partition.row_begin),partition.local_rows};
    const std::map<std::string,std::vector<double>> fractions{{"gas",{1,0}},{"aqueous",{0,1}}};
    OwnedKineticAdapter adapter(p,geometry,fractions,owned,execution);
    std::vector<chemistry::Mechanism> mechanisms(owned.count,p.mechanism);std::vector<chemistry::State> states(owned.count);
    std::vector<chemistry::Environment> environments(owned.count);std::vector<Vector3> fields(owned.count);
    std::vector<SphericalEedfState> old(owned.count);
    for(std::size_t i=0;i<owned.count;++i){const auto c=owned.begin+i;states[i].densities_m3=c==0?std::vector<double>{1e20,1e8,1e8,0}:std::vector<double>{0,0,0,0};environments[i].phase_volumes_m3={{c==0?"gas":"aqueous",geometry.volume[c]}};
        if(c==0)old[i]=spherical_from_legendre(maxwellian_eedf(1e8,1,p.electron_closure->grid));else{old[i].grid=p.electron_closure->grid;old[i].density_modes.assign(144,0);}}
    SpatialKineticOptions time;time.grid=p.electron_closure->grid;time.dt_s=1e-11;time.execution=execution;
    const auto result=adapter.evaluate(mechanisms,states,environments,fields,old,time);
    backend::DistributedHalo control(partition,{},execution);
    double source_particles=0,sink_particles=0,source_energy=0,sink_energy=0,thermal_energy=0,before=0,after=0;
    for(const auto& moment:result.boundary_moments)if(moment.boundary.owner==KineticBoundaryOwner::PhaseContact){
        check(moment.boundary.absorbed_species==3&&moment.boundary.energy_to_phase==(gas_heat?"gas":"aqueous"),"adapter retains actual receiving charge/energy owners");
        check(moment.boundary.energy_cell==(gas_heat?0u:1u),"contact heat selects the actual cell containing the authored phase");
        if(moment.owns_gas_cell){source_particles+=moment.particle_rate_s;source_energy+=moment.energy_rate_W;}
        if(moment.owns_receiving_cell){sink_particles+=moment.particle_rate_s;sink_energy+=moment.energy_rate_W;}
        if(moment.owns_energy_cell)thermal_energy+=moment.energy_rate_W;}
    for(std::size_t i=0;i<owned.count;++i){before+=geometry.volume[owned.begin+i]*old[i].electron_density_m3();after+=geometry.volume[owned.begin+i]*result.kinetic.states[i].electron_density_m3();}
    source_particles=control.global_sum(source_particles);sink_particles=control.global_sum(sink_particles);source_energy=control.global_sum(source_energy);sink_energy=control.global_sum(sink_energy);thermal_energy=control.global_sum(thermal_energy);
    check(source_particles>0&&source_energy>0&&near(source_particles,sink_particles,1e-14)&&near(source_energy,sink_energy,1e-14),"cross-rank gas/aqueous contact receives exactly the gas owner's particle and energy fluxes");
    check(near(source_energy,thermal_energy,1e-14),"cross-rank charge and thermal owners each receive the same physical transfer once");
    check(near(control.global_sum(before-after),time.dt_s*source_particles,1e-7),"contact number flux equals the single implicit kinetic moment loss");
    check(result.kinetic.local_unknowns==owned.count*144,"adapter retains only owned kinetic unknowns");
}
void secondary_template(){
    auto p=model();p.mesh.shape={1,1,1};p.electron_phase_contacts.clear();p.mechanism.species.pop_back();
    auto& wall=p.boundaries[1];wall.absorbing=true;wall.kinetic_electrons="secondary_emission";wall.secondary_emission={{"X+","e",.1}};
    wall.incoming_electrons=spherical_from_legendre(maxwellian_eedf(1,1,p.electron_closure->grid));
    const auto geometry=spatial::mesh::geometry(p.mesh);OwnedKineticAdapter adapter(p,geometry,{{"gas",{1}}},{0,1},{});
    std::vector<chemistry::Mechanism> mechanisms{p.mechanism};std::vector<chemistry::State> states{{{1e20,1e8,1e8}}};
    std::vector<chemistry::Environment> environments(1);std::vector<Vector3> fields(1);std::vector<SphericalEedfState> old{spherical_from_legendre(maxwellian_eedf(1e8,1,p.electron_closure->grid))};
    SpatialKineticOptions time;time.dt_s=1e-11;time.grid=p.electron_closure->grid;
    bool rejected=false;try{(void)adapter.evaluate(mechanisms,states,environments,fields,old,time);}catch(const std::invalid_argument&){rejected=true;}
    check(rejected,"candidate ion flux cannot be silently omitted from a secondary wall");
    check(adapter.emission_templates().size()==1,"authored secondary distribution is normalized once on static kinetic face");
    const auto& source=adapter.emission_templates()[0];KineticIncomingOverride override{source.kinetic_face,source.per_unit_number_flux};
    for(double& mode:override.incoming.density_modes)mode*=1e13;
    const auto first=adapter.evaluate(mechanisms,states,environments,fields,old,time,{},std::vector{override});
    for(double& mode:override.incoming.density_modes)mode*=2;
    const auto second=adapter.evaluate(mechanisms,states,environments,fields,old,time,{},std::vector{override});
    check(second.kinetic.states[0].electron_density_m3()>first.kinetic.states[0].electron_density_m3(),"candidate secondary incoming flux changes the same implicit distribution block");
}
void inactive_gas(const backend::ExecutionOptions& execution){
    auto p=model();p.electron_phase_contacts.clear();const auto geometry=spatial::mesh::geometry(p.mesh);
    const auto partition=backend::distributed_partition(2,execution);const spatial::partition::CellInterval owned{static_cast<std::size_t>(partition.row_begin),partition.local_rows};
    OwnedKineticAdapter adapter(p,geometry,{{"gas",{0}},{"aqueous",{1}}},owned,execution);
    std::vector<chemistry::Mechanism> mechanisms(owned.count,p.mechanism);std::vector<chemistry::State> states(owned.count,chemistry::State{{0,0,0,1e8}});
    std::vector<chemistry::Environment> environments(owned.count);std::vector<Vector3> fields(owned.count);std::vector<SphericalEedfState> old(owned.count);
    for(auto& state:old){state.grid=p.electron_closure->grid;state.density_modes.assign(144,0);}
    SpatialKineticOptions time;time.grid=p.electron_closure->grid;time.dt_s=1e-11;time.execution=execution;
    const auto result=adapter.evaluate(mechanisms,states,environments,fields,old,time);
    check(result.boundary_moments.empty()&&adapter.mesh().faces.empty(),"all-inactive gas has no physical moment or streaming faces");
    for(const auto& state:result.kinetic.states){check(state.time_s==time.dt_s,"inactive kinetic clock advances consistently");for(double value:state.density_modes)check(value==0,"all-inactive gas remains exactly zero");}
}
}
int main(int argc,char** argv){try{
    const std::string mode=argc>1?argv[1]:"";const bool mpi=mode=="--mpi"||mode=="--mpi-cuda",cuda=mode=="--cuda"||mode=="--mpi-cuda";
    backend::Runtime runtime(mpi);if(cuda&&!backend::cuda_available())return 77;backend::ExecutionOptions execution;execution.mpi=mpi;execution.device=cuda?"cuda":"cpu";execution.threads=2;
    phase_contact(execution);phase_contact(execution,true);inactive_gas(execution);secondary_template();std::cout<<"owned kinetic adapter qualification passed\n";return 0;
}catch(const std::exception& error){std::cerr<<error.what()<<'\n';return 1;}}
