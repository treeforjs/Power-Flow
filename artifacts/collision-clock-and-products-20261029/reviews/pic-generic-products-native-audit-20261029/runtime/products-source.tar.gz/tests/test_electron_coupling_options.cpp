#include "raikou/electron_coupling.h"
#include <algorithm>
#include <cmath>
#include <iostream>
#include <limits>
#include <stdexcept>
namespace {
using namespace raikou;
void check(bool value,const char* message){if(!value)throw std::runtime_error(message);}
Json closure(){return {{"processes",Json::array({{{"kind","elastic"},{"target","X"},{"mass_ratio",1e-5},
    {"energy_ev",{0,1000}},{"cross_section_m2",{1e-19,1e-19}}}})}};}
template<class Action>void rejects(Action action,const char* message="invalid coupled execution parameter was ignored"){bool failed=false;try{action();}catch(const std::invalid_argument&){failed=true;}check(failed,message);}
Json cell_closure(){return {{"grid",{{"cells",16},{"max_energy_ev",15.},{"power",2.},{"legendre_terms",2}}},
    {"processes",Json::array({{{"kind","elastic"},{"target","A"},{"label","elastic"},{"mass_ratio",0.},
        {"energy_ev",{0.,1000.}},{"cross_section_m2",{0.,0.}}}})}};}
chemistry::Mechanism cell_mechanism(const Json& rate,const Json& energy=Json::object()){
    return chemistry::Mechanism::from_json({{"species",Json::array({{{"id","A"},{"elements",{{"N",1}}}},
        {{"id","B"},{"elements",{{"N",1}}}},{{"id","e"},{"elements",Json::object()},{"charge",-1}}})},
        {"reactions",Json::array({{{"id","convert"},{"reactants",{{"A",1}}},{"products",{{"B",1}}},
            {"rate",rate},{"energy_eV_per_event",energy}}})}});
}
void reservoir_interpretation(){
    const auto coupling=kinetics::ElectronCoupling::from_json(cell_closure());
    const chemistry::State state{{1e8,0,1e8}};const chemistry::Environment environment;
    const auto electrons=kinetics::maxwellian_eedf(1e8,1,coupling.grid);
    const Json rate{{"type","constant"},{"A",1e8}};
    for(const auto* name:{"electron","electrons","gas/electron","gas/electrons"}){
        for(double energy:{-1.,1.}){
            const auto mechanism=cell_mechanism(rate,Json{{name,energy}});
            rejects([&]{(void)kinetics::advance_coupled_cell(mechanism,state,environment,coupling,electrons,0,1e-8);},
                "every spelling of noncollision electron energy must reject");
        }
    }
    const auto zero=cell_mechanism(rate,Json{{"electrons",0.}});
    (void)kinetics::advance_coupled_cell(zero,state,environment,coupling,electrons,0,1e-8);
    kinetics::CoupledCellOptions options;options.heat_capacity_J_m3_K={{"gas",1e-12}};
    options.thermal_reservoirs={{"gas",{"gas/translation"}}};
    double reference_temperature=0;
    for(const auto& energy:{Json{{"gas/translation",3.}},Json{{"translation",3.}},Json{{"translation",1.},{"gas/translation",2.}}}){
        const auto mechanism=cell_mechanism(rate,energy);
        const auto result=kinetics::advance_coupled_cell(mechanism,state,environment,coupling,electrons,0,1e-8,options);
        const double expected=1e-8*1e8*result.state.densities_m3[0]*3*1.602176634e-19;
        check(std::abs(result.thermal_energy_change_J_m3.at("gas")-expected)<1e-5*expected,
            "selected thermal energy equals independently counted reaction events");
        if(reference_temperature==0)reference_temperature=result.environment.gas_temperature_K;
        check(std::abs(result.environment.gas_temperature_K-reference_temperature)<1e-8,
            "qualified, unqualified and additive reservoir aliases heat identically");
        check(mechanism.to_json().at("reactions")[0].at("energy_eV_per_event")==energy,
            "coupled interpretation preserves raw reservoir representation");
    }
}
void conserved_temperature_validation(){
    const auto coupling=kinetics::ElectronCoupling::from_json(cell_closure());
    const chemistry::State state{{1e8,0,1e8}};const chemistry::Environment environment;
    const auto electrons=kinetics::maxwellian_eedf(1e8,1,coupling.grid);
    double number=0,energy=0;
    for(int i=0;i<16;++i){
        const double lo=15*std::pow(i/16.,2),hi=15*std::pow((i+1)/16.,2),centre=(lo+hi)/2;
        const double weight=2./3*(std::pow(hi,1.5)-std::pow(lo,1.5));
        const double shape=std::exp(-centre/(2./3));number+=weight*shape;energy+=centre*weight*shape;
    }
    const double temperature=2./3*energy/number;
    check(temperature>.669&&temperature<.671,"independent discrete temperature lies inside narrow valid table");
    const Json rate{{"type","electron_temperature_table"},{"temperatures_eV",{.669,.671}},{"coefficients",{1e6,1e6}}};
    const auto mechanism=cell_mechanism(rate);
    const auto transient=kinetics::advance_electron_feedback(mechanism,state,environment,0,coupling,electrons,1e-8);
    check(std::abs(transient.feedback.environment.electron_temperature_eV-temperature)<1e-13,
        "transient feedback validates and returns the conserved-moment temperature");
    const auto spherical=kinetics::spherical_from_legendre(electrons);
    const auto conditions=kinetics::coupled_eedf_conditions(mechanism,state,environment,0,coupling);
    const auto evaluation=kinetics::evaluate_spherical_eedf(coupling.processes,conditions,spherical,{});
    const auto feedback=kinetics::spherical_electron_feedback(mechanism,state,environment,{},coupling,spherical,evaluation);
    check(std::abs(feedback.environment.electron_temperature_eV-temperature)<1e-13,
        "spherical feedback validates at the conserved-moment temperature");
    const auto local=kinetics::advance_coupled_cell(mechanism,state,environment,coupling,electrons,0,1e-8);
    check(std::abs(local.environment.electron_temperature_eV-temperature)<1e-13,"coupled cell retains narrow-table temperature");
    const auto json=kinetics::advance_coupled_cell_json({{"mechanism",mechanism.to_json()},
        {"state",{{"densities_m3",state.densities_m3}}},{"electron_closure",cell_closure()},
        {"initial_mean_energy_ev",1.},{"field_magnitude_V_m",0.},{"dt_s",1e-8}});
    check(std::abs(json.at("environment").at("electron_temperature_eV").get<double>()-temperature)<1e-13,
        "JSON coupled cell uses the same conserved temperature");
    auto invalid=mechanism;invalid.reactions[0].rate.temperatures_eV={.677,.679};
    rejects([&]{(void)kinetics::advance_electron_feedback(invalid,state,environment,0,coupling,electrons,1e-8);},
        "genuinely out-of-range electron temperature still rejects");
    rejects([&]{(void)kinetics::spherical_electron_feedback(invalid,state,environment,{},coupling,spherical,evaluation);},
        "spherical feedback retains temperature validity checks");
}
void balanced_electron_sources(){
    const auto base=chemistry::Mechanism::from_json({{"species",Json::array({
        {{"id","X"},{"elements",{{"N",1}}}},{{"id","Xp"},{"elements",{{"N",1}}},{"charge",1}},
        {{"id","Xm"},{"elements",{{"N",1}}},{"charge",-1}},{{"id","e"},{"elements",Json::object()},{"charge",-1}}})},
        {"reactions",Json::array()}});
    for(double imbalance:{0.,1e-6}){
        auto coupling=kinetics::ElectronCoupling::from_json(cell_closure());coupling.processes[0].target="X";
        auto mechanism=base;
        for(int channel=0;channel<3;++channel){
            kinetics::CollisionProcess p;p.target="X";p.label=channel==0?"i1":channel==1?"i2":"a";
            p.kind=channel<2?kinetics::CollisionKind::Ionization:kinetics::CollisionKind::Attachment;
            p.threshold_ev=2;p.energy_ev={2,1000};const double sigma=(channel+1)*1e-20*(channel==2?1+imbalance:1);
            p.cross_section_m2={sigma,sigma};coupling.processes.push_back(p);
            chemistry::Reaction reaction;reaction.id=p.label;reaction.reactants={{0,1},{3,1}};
            reaction.products=channel<2?std::vector<chemistry::Term>{{1,1},{3,2}}:std::vector<chemistry::Term>{{2,1}};
            reaction.rate.kind=chemistry::RateKind::ElectronEedf;reaction.rate.key=p.label;mechanism.reactions.push_back(reaction);
        }
        const auto reactions=mechanism.reactions;
        const chemistry::State state{{1e20,0,0,1e8}};const chemistry::Environment environment;
        const auto electrons=kinetics::maxwellian_eedf(1e8,1,coupling.grid);
        std::vector<int> order{0,1,2};
        do{
            for(std::size_t r=0;r<order.size();++r)mechanism.reactions[r]=reactions[static_cast<std::size_t>(order[r])];
            const auto result=kinetics::advance_electron_feedback(mechanism,state,environment,0,coupling,electrons,1e-15);
            double integral=0;
            for(int i=0;i<16;++i){const double lo=std::max(2.,15*std::pow(i/16.,2)),hi=15*std::pow((i+1)/16.,2);
                if(hi>lo)integral+=result.kinetic_step.state.density_modes[static_cast<std::size_t>(2*i)]*(hi*hi-lo*lo)/2;}
            integral*=std::sqrt(2*1.602176634e-19/9.1093837015e-31)*1e20;
            const double expected=-integral*3e-20*imbalance,activity=integral*(6+3*imbalance)*1e-20;
            check(std::abs(result.feedback.mapped_electron_source_m3_s-expected)<1e-12*activity,
                "balanced sources agree with independent channel quadrature for every reaction order");
            const auto spherical=kinetics::spherical_from_legendre(electrons);
            const auto conditions=kinetics::coupled_eedf_conditions(mechanism,state,environment,0,coupling);
            const auto evaluation=kinetics::evaluate_spherical_eedf(coupling.processes,conditions,spherical,{});
            (void)kinetics::spherical_electron_feedback(mechanism,state,environment,{},coupling,spherical,evaluation);
        }while(std::next_permutation(order.begin(),order.end()));
        (void)kinetics::advance_coupled_cell(mechanism,state,environment,coupling,electrons,0,1e-15);
        auto invalid=mechanism;invalid.reactions[0].explicit_orders=true;invalid.reactions[0].orders={{0,2},{3,1}};
        rejects([&]{(void)kinetics::advance_electron_feedback(invalid,state,environment,0,coupling,electrons,1e-15);},
            "gross-source tolerance does not excuse an incorrect collision mapping");
    }
}
}
int main(){try{
    auto input=closure();input["execution"]={{"device","cuda"},{"cuda_device",2},{"mpi",true},{"communicator_f",77},{"threads",3},
        {"tolerance",1e-13},{"max_iterations",321},{"restart",72},{"preconditioner","block_ilu0"}};
    const auto parsed=kinetics::ElectronCoupling::from_json(input).conditions.execution;
    check(parsed.device=="cuda"&&parsed.cuda_device==2&&parsed.mpi&&parsed.communicator_f==77&&parsed.threads==3,"coupled backend selectors survive parsing");
    check(parsed.tolerance==1e-13&&parsed.max_iterations==321&&parsed.restart==72&&parsed.preconditioner=="block_ilu0","coupled linear solver controls survive parsing");
    for(const auto& invalid:{Json{{"preconditioner","not-a-preconditioner"}},Json{{"tolerance",0}},Json{{"tolerance",std::numeric_limits<double>::infinity()}},Json{{"restart",0}},Json{{"max_iterations",-1}}}){
        auto changed=closure();changed["execution"]=invalid;rejects([&]{(void)kinetics::ElectronCoupling::from_json(changed);});
    }
    auto nested=closure();nested["conditions"]["execution"]={{"tolerance",2e-13},{"restart",51},{"max_iterations",333},{"preconditioner","block_ilu0"}};
    const auto retained=kinetics::ElectronCoupling::from_json(nested).conditions.execution;
    check(retained.tolerance==2e-13&&retained.restart==51&&retained.max_iterations==333&&retained.preconditioner=="block_ilu0","nested coupled execution settings survive parsing");
    nested["conditions"]["execution"]["preconditioner"]="unknown";rejects([&]{(void)kinetics::ElectronCoupling::from_json(nested);});
    reservoir_interpretation();conserved_temperature_validation();balanced_electron_sources();
    std::cout<<"coupled selectors, reservoir interpretation, temperature and event-source validation passed\n";return 0;
}catch(const std::exception& exception){std::cerr<<exception.what()<<'\n';return 1;}}
