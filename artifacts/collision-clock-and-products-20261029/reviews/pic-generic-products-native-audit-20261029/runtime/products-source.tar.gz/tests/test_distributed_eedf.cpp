#include "raikou/eedf_distributed.h"
#include "../src/eedf_operators.h"
#include <algorithm>
#include <cmath>
#include <iostream>
#include <limits>
#include <stdexcept>
namespace {
using namespace raikou;
using namespace raikou::kinetics;
void require(bool ok, const std::string& message) { if (!ok) throw std::runtime_error(message); }
CollisionProcess elastic() {
    CollisionProcess p; p.target = "X"; p.label = "elastic"; p.mass_ratio = 9.1093837015e-31 / (28 * 1.66053906660e-27);
    p.energy_ev = {0, 1000}; p.cross_section_m2 = {1e-19, 1e-19}; return p;
}
template<class Function> void rejects(Function action) {
    bool failed = false; try { action(); } catch (const std::exception&) { failed = true; }
    require(failed, "asymmetric owned EEDF error was admitted");
}
void run(const backend::ExecutionOptions& execution) {
    EedfGrid grid{64, 40, 2, 4};
    EedfConditions c; c.fractions["X"] = 1; c.reduced_field_td = 10; c.execution = execution;
    const auto initial = maxwellian_eedf_distributed(1e8, 1, grid, execution);
    backend::DistributedHalo control(initial.partition, {}, execution);
    const auto full = maxwellian_eedf(1e8, 1, grid);
    const auto frozen = freeze_eedf_operator({elastic()}, c, initial);
    require(frozen.matrix.local_rows() == initial.partition.local_rows, "owned EEDF matrix retains global rows");
    require(frozen.matrix.values.size() < 16 * initial.partition.local_rows, "owned elastic EEDF matrix is not sparse");
    require(frozen.ghost_modes <= 8, "nearest-neighbour energy stencil has global ghosts");
    backend::DistributedLinearOperator op(frozen.matrix, execution);
    const auto rates = op.apply(initial.density_modes);
    auto serial = c; serial.execution = {};
    const auto reference_rates = detail::evaluate_azimuthal_rhs({elastic()}, serial, grid, 0, full.density_modes, full.density_modes).rates;
    for (std::size_t i = 0; i < rates.size(); ++i) {
        const auto global = static_cast<std::size_t>(initial.partition.row_begin) + i;
        require(std::abs(rates[i] - reference_rates[global]) <= 1e-11 * std::max(std::abs(reference_rates[global]), 1e-10), "frozen physical EEDF RHS differs from legacy operator");
    }
    const auto advanced = advance_eedf_distributed({elastic()}, c, initial, 1e-11);
    const auto expected = advance_eedf({elastic()}, serial, full, 1e-11);
    const auto gathered = backend::gather_distributed(control, advanced.state.density_modes);
    double error = 0, magnitude = 0;
    for (std::size_t i = 0; i < gathered.size(); ++i) { error = std::max(error, std::abs(gathered[i] - expected.state.density_modes[i])); magnitude = std::max(magnitude, std::abs(expected.state.density_modes[i])); }
    require(error <= 1e-9 * magnitude, "owned EEDF step differs from serial");
    require(std::abs(advanced.energy_balance_relative) < 1e-6, "owned EEDF step energy does not close");
    if (execution.mpi) {
        const auto legacy = advance_eedf({elastic()}, c, full, 1e-11);
        require(legacy.state.density_modes.size() == full.density_modes.size() && legacy.swarm.eepf.size() == static_cast<std::size_t>(grid.cells), "legacy owned boundary failed final gather");
        for (std::size_t i = 0; i < gathered.size(); ++i) require(std::abs(legacy.state.density_modes[i] - gathered[i]) < 1e-10 * magnitude, "legacy advance bypassed owned state path");
        auto malformed = full; if (control.rank() == 0) malformed.density_modes.pop_back();
        rejects([&] { static_cast<void>(advance_eedf({elastic()}, c, malformed, 1e-11)); });
        if (control.ranks() > 1) {
            auto inconsistent = full; if (control.rank() == 0) inconsistent.density_modes[0] *= 1.01;
            rejects([&] { static_cast<void>(advance_eedf({elastic()}, c, inconsistent, 1e-11)); });
        }
    }
    auto invalid = initial; if (control.rank() == 0) invalid.density_modes[0] = std::numeric_limits<double>::quiet_NaN();
    rejects([&] { static_cast<void>(advance_eedf_distributed({elastic()}, c, invalid, 1e-11)); });
    auto bad_conditions = c; if (control.rank() == 0) bad_conditions.gas_density_m3 = -1;
    rejects([&] { static_cast<void>(freeze_eedf_operator({elastic()}, bad_conditions, initial)); });
    if (control.ranks() > 1) { auto differing = c; if (control.rank() == 0) differing.reduced_field_td += 1; rejects([&] { static_cast<void>(freeze_eedf_operator({elastic()}, differing, initial)); }); }
    const auto solved = solve_eedf_distributed({elastic()}, c, grid);
    const auto expected_swarm = solve_eedf({elastic()}, serial, grid);
    const auto near = [](double a, double b) { return std::abs(a - b) < 2e-7 * std::abs(b); };
    require(near(solved.swarm.mean_energy_ev, expected_swarm.mean_energy_ev), "owned steady mean differs");
    require(near(solved.swarm.drift_velocity_m_s, expected_swarm.drift_velocity_m_s), "owned steady drift differs");
    require(near(solved.swarm.longitudinal_diffusion_n, expected_swarm.longitudinal_diffusion_n), "owned longitudinal diffusion differs");
    require(near(solved.swarm.transverse_diffusion_n, expected_swarm.transverse_diffusion_n), "owned transverse diffusion differs");
    require(near(solved.swarm.bulk_drift_velocity_m_s, expected_swarm.bulk_drift_velocity_m_s), "owned bulk drift differs");
    require(std::abs(solved.swarm.budget.residual) < 1e-8, "owned steady energy budget does not close");
    if (execution.mpi) {
        const auto sweep = solve_eedf_sweep({elastic()}, c, {5, 10}, grid);
        require(sweep.size() == 2 && sweep[0].eepf.size() == static_cast<std::size_t>(grid.cells), "legacy sweep boundary has incomplete result");
        require(near(sweep[1].mean_energy_ev, expected_swarm.mean_energy_ev) && near(sweep[1].longitudinal_diffusion_n, expected_swarm.longitudinal_diffusion_n), "legacy sweep lost owned scalar/transport results");
        if (control.ranks() > 1) {
            const std::vector<double> differing = control.rank() == 0 ? std::vector<double>{5} : std::vector<double>{5, 10};
            rejects([&] { static_cast<void>(solve_eedf_sweep({elastic()}, c, differing, grid)); });
        }
    }
    // Nonlinear Landau relaxation retains particle/energy moments without a
    // global F0 vector: every face moment uses scalar prefix/suffix reductions.
    auto landau = c; landau.reduced_field_td = 0; landau.gas_density_m3 = 1e20; landau.electron_fraction = 1e-3;
    auto plasma = maxwellian_eedf_distributed(1e17, 2, grid, execution);
    const auto ee = advance_eedf_distributed({elastic()}, landau, plasma, 1e-13);
    require(ee.linear_residual < 1e-9 && std::isfinite(ee.energy_balance_relative), "owned nonlinear Landau solve failed");
    auto no_recoil = elastic(); no_recoil.mass_ratio = 0;
    for (std::size_t row = 0; row < plasma.density_modes.size(); row += static_cast<std::size_t>(grid.legendre_terms))
        plasma.density_modes[row] *= 1 + 0.1 * std::sin(static_cast<double>(plasma.partition.row_begin + row));
    const auto isolated = advance_eedf_distributed({no_recoil}, landau, plasma, 1e-13);
    const auto global_before = backend::gather_distributed(control, plasma.density_modes), global_after = backend::gather_distributed(control, isolated.state.density_modes);
    const EedfState before{grid, 0, global_before}, after{grid, 1e-13, global_after};
    require(std::abs(after.electron_density_m3() / before.electron_density_m3() - 1) < 1e-10, "distributed Landau collisions create particles");
    require(std::abs(after.electron_energy_ev_m3() / before.electron_energy_ev_m3() - 1) < 1e-10, "distributed Landau collisions change electron energy");
    auto nonlinear = c; nonlinear.gas_density_m3 = 1e20; nonlinear.electron_fraction = 1e-4;
    const auto interacting = solve_eedf_distributed({elastic()}, nonlinear, grid);
    nonlinear.execution = {};
    const auto interacting_reference = solve_eedf({elastic()}, nonlinear, grid);
    require(std::abs(interacting.swarm.mean_energy_ev / interacting_reference.mean_energy_ev - 1) < 2e-6, "owned nonlinear steady mean differs");
    require(std::abs(interacting.swarm.longitudinal_diffusion_n / interacting_reference.longitudinal_diffusion_n - 1) < 2e-5, "owned nonlinear longitudinal response differs");
    if (control.rank() == 0) std::cout << "owned EEDF transient/steady/transport, energy, Landau and failures passed\n";
}
}
int main(int argc, char** argv) {
    try {
        bool mpi = false, cuda = false;
        for (int i = 1; i < argc; ++i) { const std::string arg(argv[i]); mpi |= arg == "--mpi"; cuda |= arg == "--cuda"; }
        backend::Runtime runtime(mpi); if (cuda && !backend::cuda_available()) return 77;
        backend::ExecutionOptions execution; execution.mpi = mpi; execution.device = cuda ? "cuda" : "cpu"; execution.tolerance = 1e-11;
        run(execution); return 0;
    } catch (const std::exception& error) { std::cerr << error.what() << '\n'; return 1; }
}
