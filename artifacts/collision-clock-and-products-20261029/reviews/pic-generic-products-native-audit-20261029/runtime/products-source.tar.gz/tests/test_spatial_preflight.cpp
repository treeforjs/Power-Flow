#include "../src/spatial_collective_preflight.h"
#include <iostream>
#include <limits>
#include <stdexcept>

namespace {
using namespace raikou;
using namespace raikou::spatial;
void check(bool ok,const char* message){if(!ok)throw std::runtime_error(message);}
template<class Action>void rejects(Action action){bool failed=false;try{action();}catch(const std::invalid_argument&){failed=true;}check(failed,"asymmetric spatial metadata/checkpoint accepted");}
}
int main(int argc,char** argv){
    try{
        bool mpi=false;for(int i=1;i<argc;++i)mpi|=std::string(argv[i])=="--mpi";
        backend::Runtime runtime(mpi);backend::ExecutionOptions execution;execution.mpi=mpi;
        auto model=std::make_shared<Problem>();model->options.mpi=mpi;model->options.end_time_s=1;
        model->mesh.shape={8,2,1};model->boundaries[0].kind=BoundaryKind::Electrode;model->boundaries[1].kind=BoundaryKind::Electrode;
        chemistry::Species species;species.id="H";species.elements={{"H",1}};species.mass_kg=1.673e-27;model->mechanism.species={species};model->transport.resize(1);model->initial_densities_m3={1};
        const auto geometry=mesh::geometry(model->mesh);
        partition::DofLayout layout(geometry,1,0,0,{},false,execution);
        const auto& control=layout.control_halo();const int rank=control.rank();
        DistributedProblem valid;valid.model=model;valid.initial.density=[rank](std::size_t,std::size_t){return 1.+rank;};
        detail::preflight_spatial_distributed(valid,layout);
        const auto altered=[&](auto mutate){auto changed=std::make_shared<Problem>(*model);if(rank==0)mutate(*changed);auto input=valid;input.model=changed;rejects([&]{detail::preflight_spatial_distributed(input,layout);});};
        altered([](Problem& p){p.options.relative_tolerance=std::numeric_limits<double>::quiet_NaN();});
        altered([](Problem& p){p.options.maximum_newton_iterations=0;});
        altered([](Problem& p){p.circuit.series_resistance_ohm=std::numeric_limits<double>::infinity();});
        if(control.ranks()>1){
            altered([](Problem& p){p.options.end_time_s=.5;});
            altered([](Problem& p){p.options.maximum_newton_iterations+=1;});
            altered([](Problem& p){p.options.bdf2=!p.options.bdf2;});
            altered([](Problem& p){p.permittivity_F_m={1e-10};});
            altered([](Problem& p){p.boundaries[0].potential_V=1;});
            altered([](Problem& p){p.mechanism.id="different static mechanism";});
            auto adaptive=valid;if(rank==0)adaptive.adaptive_time=false;rejects([&]{detail::preflight_spatial_distributed(adaptive,layout);});
        }
        DistributedCheckpoint cp;cp.state.rows=layout.row_partition();cp.state.cells=layout.owned_cells();
        cp.state.owned_values.assign(cp.state.rows.local_rows,1.+rank);cp.previous_state=cp.state;cp.next_step_s=model->options.time_step_s;
        cp.local_boundary_counts={static_cast<double>(rank)};cp.previous_local_boundary_counts=cp.local_boundary_counts;
        cp.local_energy_integrals_J["gas/local"]=rank;cp.previous_local_energy_integrals_J=cp.local_energy_integrals_J;
        auto restart=valid;restart.checkpoint=cp;detail::preflight_spatial_distributed(restart,layout); // distinct local arrays/ledgers are valid
        const auto bad_checkpoint=[&](auto mutate){auto input=restart;if(rank==0)mutate(*input.checkpoint);rejects([&]{detail::preflight_spatial_distributed(input,layout);});};
        bad_checkpoint([](DistributedCheckpoint& c){c.state.cells.count=0;});
        bad_checkpoint([](DistributedCheckpoint& c){c.previous_state.rows.local_rows+=1;});
        bad_checkpoint([](DistributedCheckpoint& c){c.previous_state.time_s=std::numeric_limits<double>::quiet_NaN();});
        bad_checkpoint([](DistributedCheckpoint& c){c.local_boundary_counts[0]=std::numeric_limits<double>::quiet_NaN();});
        bad_checkpoint([](DistributedCheckpoint& c){c.previous_local_energy_integrals_J["gas/local"]=std::numeric_limits<double>::infinity();});
        bad_checkpoint([](DistributedCheckpoint& c){c.accepted_steps=1;});
        bad_checkpoint([](DistributedCheckpoint& c){c.state.owned_values[0]=-1;});
        bad_checkpoint([](DistributedCheckpoint& c){c.previous_state.owned_values[0]=-1;});
        if(control.ranks()>1){
            auto presence=valid;if(rank==0)presence.checkpoint=cp;rejects([&]{detail::preflight_spatial_distributed(presence,layout);});
            auto clocks=restart;if(rank==0){clocks.checkpoint->state.time_s=.1;clocks.checkpoint->previous_step_s=.1;clocks.checkpoint->accepted_steps=1;}
            rejects([&]{detail::preflight_spatial_distributed(clocks,layout);});
            auto selectors=std::make_shared<Problem>(*model);selectors->options.cuda_device=rank;auto allowed=valid;allowed.model=selectors;
            selectors->options.threads=static_cast<std::size_t>(rank+1);
            detail::preflight_spatial_distributed(allowed,layout); // per-rank CUDA mapping is deliberately excluded
        }
        detail::preflight_spatial_distributed(valid,layout);detail::preflight_spatial_distributed(restart,layout);
        {
            auto physical_model=std::make_shared<Problem>(*model);
            auto aqueous=physical_model->mechanism.species[0];aqueous.id="H_aq";aqueous.phase="aqueous";physical_model->mechanism.species.push_back(aqueous);
            physical_model->transport.resize(2);physical_model->initial_densities_m3={1,0};physical_model->phase_fractions={{"gas",{1}},{"aqueous",{0}}};
            physical_model->thermal.enabled=true;physical_model->thermal.phases["gas"].heat_capacity_J_m3_K={1};physical_model->thermal.phases["aqueous"].heat_capacity_J_m3_K={1};
            RadiationGroup photons;photons.id="test";photons.photon_energy_eV=1;physical_model->radiation={photons};
            partition::DofLayout fields(geometry,2,1,2,{},false,execution);
            DistributedProblem physical;physical.model=physical_model;physical.checkpoint.emplace();auto& history=*physical.checkpoint;
            history.state.rows=fields.row_partition();history.state.cells=fields.owned_cells();history.state.owned_values.assign(history.state.rows.local_rows,1);
            for(std::size_t c=history.state.cells.begin;c<history.state.cells.begin+history.state.cells.count;++c)
                history.state.owned_values[static_cast<std::size_t>(fields.cell_dof(c,1)-history.state.rows.row_begin)]=0;
            history.previous_state=history.state;history.next_step_s=physical_model->options.time_step_s;
            history.local_boundary_counts.assign(2,0);history.previous_local_boundary_counts.assign(2,0);
            detail::preflight_spatial_distributed(physical,fields);
            for(bool previous:{false,true})for(const auto [component,value]:{std::pair<std::size_t,double>{0,-1},{1,1},{3,-1},{4,0},{5,-1}}){
                auto changed=physical;if(rank==0){auto& state=previous?changed.checkpoint->previous_state:changed.checkpoint->state;
                    state.owned_values[static_cast<std::size_t>(fields.cell_dof(state.cells.begin,component)-state.rows.row_begin)]=value;}
                rejects([&]{detail::preflight_spatial_distributed(changed,fields);});
            }
            detail::preflight_spatial_distributed(physical,fields);
        }
        for(bool spherical:{false,true}){
            auto kinetic_model=std::make_shared<Problem>(*model);auto& electron=kinetic_model->mechanism.species[0];
            electron.id="e";electron.elements.clear();electron.charge=-1;electron.mass_kg=9.1093837015e-31;
            kinetic_model->options.absolute_density_tolerance_m3=1e-8;kinetic_model->options.relative_tolerance=1e-8;
            kinetic_model->electron_mode=spherical?"transient_spherical":"transient_boltzmann";
            kinetic_model->electron_closure.emplace();auto& closure=*kinetic_model->electron_closure;closure.grid={16,10,2,2};
            closure.conditions.execution.threads=static_cast<std::size_t>(rank+1); // rank-local even inside closure
            auto kinetic=restart;kinetic.model=kinetic_model;
            for(auto* state:{&kinetic.checkpoint->state,&kinetic.checkpoint->previous_state})
                for(std::size_t local=0;local<state->cells.count;++local){auto electrons=kinetics::maxwellian_eedf(1.+rank,1,closure.grid);
                    if(spherical)state->spherical_electrons.push_back(kinetics::spherical_from_legendre(electrons));else state->electrons.push_back(std::move(electrons));}
            detail::preflight_spatial_distributed(kinetic,layout);
            const auto corrupt=[&](auto mutate){auto input=kinetic;if(rank==0)mutate(input.checkpoint->state);rejects([&]{detail::preflight_spatial_distributed(input,layout);});};
            corrupt([&](DistributedState& state){if(spherical)state.spherical_electrons[0].density_modes[0]=-1;else state.electrons[0].density_modes[0]=-1;});
            corrupt([&](DistributedState& state){state.owned_values[0]*=2;});
            corrupt([&](DistributedState& state){if(spherical)state.spherical_electrons[0].time_s=1e-3;else state.electrons[0].time_s=1e-3;});
            corrupt([&](DistributedState& state){if(spherical)state.spherical_electrons[0].grid.power+=.1;else state.electrons[0].grid.power+=.1;});
            auto inactive=kinetic;
            for(auto* state:{&inactive.checkpoint->state,&inactive.checkpoint->previous_state}){
                for(std::size_t local=0;local<state->cells.count;++local)state->owned_values[static_cast<std::size_t>(layout.cell_dof(state->cells.begin+local,0)-state->rows.row_begin)]=0;
                for(auto& electrons:state->spherical_electrons)std::fill(electrons.density_modes.begin(),electrons.density_modes.end(),0);
                for(auto& electrons:state->electrons)std::fill(electrons.density_modes.begin(),electrons.density_modes.end(),0);
            }
            detail::preflight_spatial_distributed(inactive,layout); // zero gas/electron state remains admissible
        }
        if(rank==0)std::cout<<"owned spatial shared controls, physical metadata and local checkpoint preflight passed\n";
        return 0;
    }catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 1;}
}
