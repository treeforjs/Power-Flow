// The multi-term electron Boltzmann solver against exact limits and the Reid ramp benchmark:
// relaxation to the gas Maxwellian with no field, the Druyvesteyn distribution, detailed balance
// with superelastic collisions, electron-electron collisions driving a Maxwellian that keeps the
// energy balance, a recombination sink, ionization growth (bulk against flux drift), the energy
// budget closing to rounding in every case, the Reid ramp drift and diffusion against Monte Carlo,
// convergence in the number of Legendre terms, time-dependent breakdown (growth at the steady
// rate, voltage collapse, closed energy books, step convergence), the LXCat reader and refusals.
#include "raikou/electron_boltzmann.h"
#include "raikou/hydrogen_molecule.h"
#include "raikou/electron_coupling.h"
#include <cmath>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <numbers>
#include <stdexcept>
#include <string>

namespace {
namespace sim = raikou::kinetics;
int failures = 0;
void check(bool ok, const std::string& what) {
    if (!ok) { std::cerr << "FAIL: " << what << "\n"; ++failures; }
}
bool near(double a, double b, double rel) { return std::abs(a - b) <= rel * std::abs(b); }
template <class F> bool refuses(F f) {
    try { f(); } catch (const std::invalid_argument&) { return true; }
    return false;
}
constexpr double kMe = 9.1093837015e-31, kAmu = 1.66053906660e-27, kKelvinEv = 1.380649e-23 / 1.602176634e-19;

sim::CollisionProcess elastic(double sigma, double mass_amu) {
    sim::CollisionProcess p;
    p.kind = sim::CollisionKind::Elastic;
    p.target = "X";
    p.label = "elastic";
    p.mass_ratio = kMe / (mass_amu * kAmu);
    p.energy_ev = {0, 1000};
    p.cross_section_m2 = {sigma, sigma};
    return p;
}
// Largest relative deviation from the Maxwellian at temperature te (eV) below 8 te.
double maxwellian_deviation(const sim::SwarmResult& r, double te) {
    double dev = 0;
    for (std::size_t i = 0; i < r.eepf.size(); ++i) {
        if (r.energy_ev[i] > 8 * te) break;
        const double m = 2 / std::sqrt(std::numbers::pi) * std::pow(te, -1.5) * std::exp(-r.energy_ev[i] / te);
        dev = std::max(dev, std::abs(r.eepf[i] / m - 1));
    }
    return dev;
}
void check_budget(const sim::SwarmResult& r, const std::string& what) {
    check(r.converged, what + " converged");
    check(std::abs(r.budget.residual) < 1e-9, what + " energy budget closes (" + std::to_string(r.budget.residual) + ")");
}
} // namespace

int run_tests(int argc, char** argv) {
    // A single local EEDF is partitioned across ranks; this is not a parameter sweep.
    if (argc > 1 && (std::string(argv[1]) == "--mpi" || std::string(argv[1]) == "--cuda" || std::string(argv[1]) == "--mpi-cuda")) {
        const bool mpi = std::string(argv[1]) != "--cuda", cuda = std::string(argv[1]) != "--mpi";
        raikou::backend::Runtime runtime(mpi);
        if (cuda && !raikou::backend::cuda_available()) return 77;
        sim::EedfConditions serial; serial.fractions["X"] = 1; serial.reduced_field_td = 10;
        const sim::EedfGrid grid{.cells = 64, .max_energy_ev = 40, .power = 2, .legendre_terms = 4};
        const auto reference = sim::solve_eedf({elastic(1e-19, 28)}, serial, grid);
        auto distributed = serial; distributed.execution.mpi = mpi; distributed.execution.threads = 2;
        distributed.execution.device = cuda ? "cuda" : "cpu";
        const auto result = sim::solve_eedf({elastic(1e-19, 28)}, distributed, grid);
        check(!mpi || raikou::backend::mpi_size() >= 2, "MPI EEDF test requires at least two ranks");
        check(near(result.mean_energy_ev, reference.mean_energy_ev, 1e-9) &&
              near(result.drift_velocity_m_s, reference.drift_velocity_m_s, 1e-9), "single local EEDF agrees across execution backends");
        const auto state = sim::maxwellian_eedf(1e8, 1, grid);
        const auto step = sim::advance_eedf({elastic(1e-19, 28)}, distributed, state, 1e-13);
        const auto local = sim::advance_eedf({elastic(1e-19, 28)}, serial, state, 1e-13);
        double difference = 0, scale = 0;
        for (std::size_t i = 0; i < step.state.density_modes.size(); ++i) {
            difference = std::max(difference, std::abs(step.state.density_modes[i] - local.state.density_modes[i]));
            scale = std::max(scale, std::abs(local.state.density_modes[i]));
        }
        check(difference <= 1e-9 * scale, "parallel local transient retains the complete kinetic state");
        const auto mechanism = raikou::chemistry::Mechanism::from_json({{"id", "parallel_coupled_manufactured"},
            {"species", raikou::Json::array({{{"id", "N"}, {"elements", {{"N", 1}}}},
                {{"id", "N+"}, {"elements", {{"N", 1}}}, {"charge", 1}}, {{"id", "e"}, {"elements", raikou::Json::object()}, {"charge", -1}}})},
            {"reactions", raikou::Json::array({{{"id", "ionize"}, {"reactants", {{"e", 1}, {"N", 1}}},
                {"products", {{"e", 2}, {"N+", 1}}}, {"rate", {{"type", "electron_eedf"}}}, {"collision_label", "ionize"}}})}});
        auto momentum = elastic(1e-19, 14); momentum.target = "N";
        sim::CollisionProcess ion; ion.kind = sim::CollisionKind::Ionization; ion.target = "N"; ion.label = "ionize";
        ion.threshold_ev = 2; ion.energy_ev = {2, 5, 100}; ion.cross_section_m2 = {0, 1e-21, 1e-21};
        sim::ElectronCoupling coupling; coupling.processes = {momentum, ion}; coupling.grid = grid; coupling.gas_density_m3 = 1e20;
        coupling.conditions.execution = distributed.execution;
        const raikou::chemistry::State inventory{{1e20, 0, 1e8}};
        const auto coupled = sim::advance_coupled_cell(mechanism, inventory, {}, coupling, state, 10, 1e-10);
        coupling.conditions.execution = serial.execution;
        const auto reference_coupled = sim::advance_coupled_cell(mechanism, inventory, {}, coupling, state, 10, 1e-10);
        check(coupled.nonlinear_residual <= 1 && near(coupled.state.densities_m3[1], reference_coupled.state.densities_m3[1], 1e-7),
              "parallel monolithic kinetic/chemistry Newton block agrees with serial");
        if (raikou::backend::mpi_rank() == 0 && failures == 0) std::cout << "single-cell parallel EEDF qualification passed\n";
        return failures == 0 ? 0 : 1;
    }
    // No field: elastic collisions relax the electrons to the gas Maxwellian.
    {
        sim::EedfConditions c;
        c.reduced_field_td = 0;
        c.gas_temperature_k = 300;
        c.fractions["X"] = 1;
        const auto r = sim::solve_eedf({elastic(1e-19, 28)}, c, {.cells = 400, .max_energy_ev = 1, .power = 2, .legendre_terms = 2});
        const double kt = kKelvinEv * 300;
        check(r.converged && near(r.mean_energy_ev, 1.5 * kt, 1e-4) && maxwellian_deviation(r, kt) < 1e-4, "no field: the gas Maxwellian");
    }
    // Constant cross section, cold gas: the Druyvesteyn distribution exp(-(e/e0)^2) with
    // e0 = (E/N) / (sigma sqrt(3 m/M)) and mean energy e0 Gamma(5/4) / Gamma(3/4).
    {
        sim::EedfConditions c;
        c.reduced_field_td = 10;
        c.gas_temperature_k = 0;
        c.fractions["X"] = 1;
        for (int terms : {2, 4}) {
            const auto r = sim::solve_eedf({elastic(1e-19, 28)}, c, {.cells = 400, .max_energy_ev = 60, .power = 2, .legendre_terms = terms});
            const double e0 = 1e-20 / (1e-19 * std::sqrt(3 * kMe / (28 * kAmu)));
            check(near(r.mean_energy_ev, e0 * std::tgamma(1.25) / std::tgamma(0.75), 2e-4), "Druyvesteyn mean energy, " + std::to_string(terms) + " terms");
            check(near(r.drift_velocity_m_s, r.bulk_drift_velocity_m_s, 1e-9), "Druyvesteyn: bulk drift is the flux drift");
            check_budget(r, "Druyvesteyn");
        }
    }
    // Detailed balance: an excited state populated at the gas temperature makes superelastic
    // collisions cancel excitation exactly, and with no field the distribution stays Maxwellian.
    {
        sim::CollisionProcess ex;
        ex.kind = sim::CollisionKind::Excitation;
        ex.target = "X";
        ex.product = "X*";
        ex.label = "X <-> X*";
        ex.threshold_ev = 0.05;
        ex.weight_ratio = 1.0 / 3;
        ex.energy_ev = {0.05, 0.2, 2};
        ex.cross_section_m2 = {0, 5e-20, 1e-20};
        const double tg = 600, kt = kKelvinEv * tg;
        sim::EedfConditions c;
        c.reduced_field_td = 0;
        c.gas_temperature_k = tg;
        c.fractions["X"] = 0.9;
        c.fractions["X*"] = 0.9 / ex.weight_ratio * std::exp(-0.05 / kt);
        // A jump and its reverse join the same two cells, so the balance holds to the cells'
        // resolution of the Maxwellian: second order in the cell width.
        const auto coarse = sim::solve_eedf({elastic(1e-19, 18), ex}, c, {.cells = 600, .max_energy_ev = 2, .power = 2, .legendre_terms = 2});
        const auto r = sim::solve_eedf({elastic(1e-19, 18), ex}, c, {.cells = 1200, .max_energy_ev = 2, .power = 2, .legendre_terms = 2});
        check(maxwellian_deviation(r, kt) < 2.5e-3 && maxwellian_deviation(r, kt) < 0.3 * maxwellian_deviation(coarse, kt),
              "detailed balance keeps the gas Maxwellian, to second order");
        check(r.rates.size() == 1 && std::abs(r.rates[0].power_ev_m3_s) < 1e-3 * 0.05 * 0.9 * r.rates[0].rate_m3_s, "detailed balance: no net power");
        check_budget(r, "detailed balance");
        // A cold excited population (no superelastic partner) cools the electrons below the gas.
        c.fractions.erase("X*");
        const auto cold = sim::solve_eedf({elastic(1e-19, 18), ex}, c, {.cells = 600, .max_energy_ev = 2, .power = 2, .legendre_terms = 2});
        check(cold.mean_energy_ev < 1.5 * kt && cold.budget.vibrational > 0, "excitation without superelastic cools the electrons");
    }
    // Electron-electron collisions: in the strong-coupling limit the distribution is the
    // Maxwellian whose field heating equals the elastic loss, Te = (E/N) / (sigma sqrt(12 m/M)),
    // and they exchange energy without creating any.
    {
        sim::EedfConditions c;
        c.reduced_field_td = 10;
        c.gas_temperature_k = 0;
        c.fractions["X"] = 1;
        c.gas_density_m3 = 1e22;
        c.electron_fraction = 1e-2;
        c.ion_fraction = 0;
        const auto r = sim::solve_eedf({elastic(1e-19, 28)}, c, {.cells = 400, .max_energy_ev = 60, .power = 2, .legendre_terms = 2});
        const double te = 1e-20 / (1e-19 * std::sqrt(12 * kMe / (28 * kAmu)));
        check(near(r.mean_energy_ev, 1.5 * te, 1e-3) && maxwellian_deviation(r, 2.0 / 3 * r.mean_energy_ev) < 2e-2, "electron-electron: the balancing Maxwellian");
        check(std::abs(r.budget.electron_electron) < 1e-10 * r.budget.field, "electron-electron collisions conserve energy");
        check_budget(r, "electron-electron");
        // Coulomb momentum transfer to the ions lowers the field heating and the temperature.
        c.ion_fraction = -1;
        const auto ions = sim::solve_eedf({elastic(1e-19, 28)}, c, {.cells = 400, .max_energy_ev = 60, .power = 2, .legendre_terms = 2});
        check(ions.mean_energy_ev < 0.99 * r.mean_energy_ev, "electron-ion collisions reduce the heating");
    }
    // Recombination removes slow electrons: the surviving population decays at the recombination
    // rate and is hotter than the gas; the energy the recombined electrons carry is accounted.
    {
        sim::CollisionProcess rec;
        rec.kind = sim::CollisionKind::Recombination;
        rec.target = "X+";
        rec.label = "e + X+ -> X";
        for (double e = 1e-3; e < 3; e *= 1.2) {
            rec.energy_ev.push_back(e);
            rec.cross_section_m2.push_back(1e-20 / e);
        }
        sim::EedfConditions c;
        c.reduced_field_td = 0;
        c.gas_temperature_k = 300;
        c.fractions["X"] = 1;
        c.fractions["X+"] = 1e-4;
        const auto r = sim::solve_eedf({elastic(1e-19, 18), rec}, c, {.cells = 400, .max_energy_ev = 1, .power = 2, .legendre_terms = 2});
        check(r.recombination_rate_m3_s > 0 && near(r.net_rate_m3_s, -r.recombination_rate_m3_s, 1e-12), "recombination: the decay rate");
        check(r.mean_energy_ev > 1.5 * kKelvinEv * 300 && r.budget.recombination > 0 && r.budget.growth < 0, "recombination heats the survivors");
        check_budget(r, "recombination");
    }
    // Ionization (the Lucas-Saelee model gas): the population grows, the bulk drift exceeds the
    // flux drift, and the budget includes the energy given to the new electrons.
    {
        std::vector<sim::CollisionProcess> gas(3);
        gas[0].kind = sim::CollisionKind::Elastic;
        gas[0].target = "X";
        gas[0].mass_ratio = kMe / (4 * kAmu);
        for (double e = 1e-4; e < 300; e *= 1.05) {
            gas[0].energy_ev.push_back(e);
            gas[0].cross_section_m2.push_back(4e-20 / std::sqrt(e));
        }
        gas[1].kind = sim::CollisionKind::Excitation;
        gas[2].kind = sim::CollisionKind::Ionization;
        for (int k : {1, 2}) {
            gas[static_cast<std::size_t>(k)].target = "X";
            gas[static_cast<std::size_t>(k)].threshold_ev = 15.6;
            gas[static_cast<std::size_t>(k)].energy_ev = {15.6, 215.6};
            gas[static_cast<std::size_t>(k)].cross_section_m2 = {0, 0.5 * 0.1e-20 * 200};
        }
        sim::EedfConditions c;
        c.reduced_field_td = 20;
        c.gas_temperature_k = 0;
        c.fractions["X"] = 1;
        for (auto sharing : {sim::IonizationSharing::Equal, sim::IonizationSharing::OneTakesAll}) {
            c.sharing = sharing;
            const auto r = sim::solve_eedf(gas, c, {.cells = 800, .max_energy_ev = 60, .power = 2, .legendre_terms = 6});
            check(r.net_rate_m3_s > 0 && r.bulk_drift_velocity_m_s > 1.05 * r.drift_velocity_m_s, "ionization: growth and bulk drift above flux drift");
            check(r.budget.ionization > 0 && r.budget.growth > 0, "ionization: energy to ionization and to the new electrons");
            check(r.gradient_residual < 1e-9, "ionization: the gradient solves converge");
            check_budget(r, "ionization");
        }
    }
    // A solve continued from a nearby converged distribution (SteadyEedfReuse, as the spatial
    // closure uses for every cell) reaches the cold solve's result in fewer iterations, with and
    // without electron-electron collisions, and one started far away still reaches it. Without
    // the gradient terms those stay 0 and nothing else changes.
    {
        std::vector<sim::CollisionProcess> gas(3);
        gas[0].kind = sim::CollisionKind::Elastic; gas[0].target = "X"; gas[0].mass_ratio = kMe / (4 * kAmu);
        for (double e = 1e-4; e < 300; e *= 1.05) { gas[0].energy_ev.push_back(e); gas[0].cross_section_m2.push_back(4e-20 / std::sqrt(e)); }
        gas[1].kind = sim::CollisionKind::Excitation; gas[1].label = "excitation";
        gas[2].kind = sim::CollisionKind::Ionization; gas[2].label = "ionization";
        for (auto* q : {&gas[1], &gas[2]}) { q->target = "X"; q->threshold_ev = 15.6; q->energy_ev = {15.6, 215.6}; q->cross_section_m2 = {0, 0.5 * 0.1e-20 * 200}; }
        const sim::EedfGrid grid{.cells = 400, .max_energy_ev = 60, .power = 2, .legendre_terms = 2};
        const auto same = [](const sim::SwarmResult& a, const sim::SwarmResult& b, double rel) {
            return a.converged && b.converged && near(a.mean_energy_ev, b.mean_energy_ev, rel) && near(a.mobility_n, b.mobility_n, rel) &&
                   near(a.diffusion_n, b.diffusion_n, rel) && near(a.ionization_rate_m3_s, b.ionization_rate_m3_s, rel) &&
                   near(a.net_rate_m3_s, b.net_rate_m3_s, rel) && near(a.budget.field, b.budget.field, rel);
        };
        for (double electrons : {0.0, 1e-9, 1e-4}) {
            const std::string name = (electrons > 0 ? "with electron-electron collisions" : "without electron-electron collisions") +
                                     (electrons > 0 ? " at " + std::to_string(electrons) : std::string());
            sim::EedfConditions c; c.gas_temperature_k = 0; c.fractions["X"] = 1; c.gas_density_m3 = 1e22; c.electron_fraction = electrons; c.ion_fraction = 0;
            c.reduced_field_td = 20;
            sim::SteadyEedfReuse reuse;
            const auto first = sim::solve_eedf(gas, c, grid, reuse);
            check(same(first, sim::solve_eedf(gas, c, grid), 1e-15) && !reuse.modes.empty(), "a cold start through the reuse solve is the plain solve, " + name);
            c.reduced_field_td = 21;
            const auto cold = sim::solve_eedf(gas, c, grid);
            const auto continued = sim::solve_eedf(gas, c, grid, reuse);
            check(same(continued, cold, 1e-10) && continued.iterations < cold.iterations && near(continued.longitudinal_diffusion_n, cold.longitudinal_diffusion_n, 1e-9),
                  "a nearby state continues to the cold result in fewer iterations, " + name);
            check_budget(continued, "continued solve, " + name);
            c.reduced_field_td = 100;
            check(same(sim::solve_eedf(gas, c, grid, reuse), sim::solve_eedf(gas, c, grid), 1e-10), "a start far from the state still reaches the cold result, " + name);
            sim::SteadyEedfReuse bare; bare.gradient_terms = false;
            const auto without = sim::solve_eedf(gas, c, grid, bare), with = sim::solve_eedf(gas, c, grid);
            check(same(without, with, 1e-15) && with.longitudinal_diffusion_n > 0 && without.longitudinal_diffusion_n == 0 && without.bulk_drift_velocity_m_s == 0,
                  "without the gradient terms only they are left out, " + name);
        }
    }
    // Electron-electron collisions make the steady equation quadratic in F, so its solution depends on
    // the electron density as well as the shape. The reference is the transient solver, an independent
    // path that carries the density in its unknowns: backward-Euler steps, each started at n0 / s so it
    // ends at n0 (s being the last step's growth), have as fixed point the growth eigenfunction at n0
    // whatever the step. From weak to strong coupling the steady solve is that distribution, and it does
    // not depend on where the solve starts (a sweep reaches it from twice the field).
    {
        std::vector<sim::CollisionProcess> gas(3);
        gas[0].kind = sim::CollisionKind::Elastic; gas[0].target = "X"; gas[0].mass_ratio = kMe / (4 * kAmu);
        for (double e = 1e-4; e < 300; e *= 1.05) { gas[0].energy_ev.push_back(e); gas[0].cross_section_m2.push_back(4e-20 / std::sqrt(e)); }
        gas[1].kind = sim::CollisionKind::Excitation; gas[1].label = "excitation";
        gas[2].kind = sim::CollisionKind::Ionization; gas[2].label = "ionization";
        for (auto* q : {&gas[1], &gas[2]}) { q->target = "X"; q->threshold_ev = 15.6; q->energy_ev = {15.6, 215.6}; q->cross_section_m2 = {0, 0.5 * 0.1e-20 * 200}; }
        const sim::EedfGrid grid{.cells = 400, .max_energy_ev = 60, .power = 2, .legendre_terms = 2};
        for (double electrons : {1e-6, 1e-4, 1e-3}) {
            const std::string at = " at electron fraction " + std::to_string(electrons);
            sim::EedfConditions c; c.gas_temperature_k = 300; c.fractions["X"] = 1; c.gas_density_m3 = 1e22; c.electron_fraction = electrons; c.ion_fraction = 0;
            c.reduced_field_td = 21;
            const auto steady = sim::solve_eedf(gas, c, grid);
            check_budget(steady, "electron-electron steady solve" + at);
            const double n0 = electrons * c.gas_density_m3, dt_max = 0.3 / (steady.net_rate_m3_s * c.gas_density_m3);
            auto state = sim::maxwellian_eedf(n0, 3, grid);
            double dt = 1e-12, growth = 1, last = 0;
            bool settled = false;
            sim::EedfStepResult step;
            for (int k = 0; k < 400 && !settled; ++k) {
                auto start = state;
                const double scale = n0 / (growth * start.electron_density_m3());
                for (auto& q : start.density_modes) q *= scale;
                step = sim::advance_eedf(gas, c, start, dt);
                growth = step.state.electron_density_m3() / start.electron_density_m3();
                state = step.state;
                // The transient's own nonlinear tolerance leaves about 1e-13 of noise in the mean energy
                // and 2e-12 in the density from step to step.
                settled = dt >= dt_max && std::abs(step.swarm.mean_energy_ev - last) < 1e-12 * last;
                last = step.swarm.mean_energy_ev;
                dt = std::min(1.3 * dt, dt_max);
            }
            check(settled && near(state.electron_density_m3(), n0, 1e-10), "the transient reference settles at its electron density" + at);
            check(near(steady.mean_energy_ev, step.swarm.mean_energy_ev, 1e-11) && near(steady.mobility_n, step.swarm.mobility_n, 1e-11) &&
                  near(steady.ionization_rate_m3_s, step.swarm.ionization_rate_m3_s, 1e-10),
                  "electron-electron: the steady solve is the transient fixed point" + at);
            const auto swept = sim::solve_eedf_sweep(gas, c, {42, 21}, grid)[1];
            check(swept.converged && near(swept.mean_energy_ev, steady.mean_energy_ev, 1e-11) && near(swept.mobility_n, steady.mobility_n, 1e-11),
                  "electron-electron: the steady solution does not depend on the start" + at);
        }
    }
    // The Reid ramp: sigma_m = 6e-20 m^2, an inelastic ramp 1e-19 (e - 0.2) m^2 from 0.2 eV,
    // M = 4 amu, cold gas. Monte Carlo (Raspopovic et al. 1999; White et al. 1997): mean energy,
    // flux drift, and flux transverse and longitudinal diffusion; the two-term approximation is
    // several per cent off at 24 Td, while the multi-term values match.
    {
        std::vector<sim::CollisionProcess> gas{elastic(6e-20, 4), {}};
        gas[1].kind = sim::CollisionKind::Excitation;
        gas[1].target = "X";
        gas[1].threshold_ev = 0.2;
        gas[1].energy_ev = {0.2, 100.2};
        gas[1].cross_section_m2 = {0, 1e-17};
        struct Reference { double td, mean, w, dtn, dln; };
        for (const auto& ref : {Reference{1, 0.1017, 12730, 9.66e23, 7.575e23}, Reference{12, 0.2703, 68340, 1.14e24, 5.69e23},
                                Reference{24, 0.4113, 88040, 1.131e24, 4.546e23}}) {
            sim::EedfConditions c;
            c.reduced_field_td = ref.td;
            c.gas_temperature_k = 0;
            c.fractions["X"] = 1;
            const sim::EedfGrid grid{.cells = 600, .max_energy_ev = ref.td < 5 ? 2.0 : 4.0, .power = 1.5, .legendre_terms = 10};
            const auto r = sim::solve_eedf(gas, c, grid);
            const std::string at = " at " + std::to_string(static_cast<int>(ref.td)) + " Td";
            check(near(r.mean_energy_ev, ref.mean, 0.01) && near(r.drift_velocity_m_s, ref.w, 0.01), "Reid ramp mean energy and drift" + at);
            check(near(r.transverse_diffusion_n, ref.dtn, 0.015) && near(r.longitudinal_diffusion_n, ref.dln, 0.02), "Reid ramp diffusion" + at);
            check_budget(r, "Reid ramp" + at);
            auto fewer = grid;
            fewer.legendre_terms = 8;
            const auto r8 = sim::solve_eedf(gas, c, fewer);
            check(near(r8.drift_velocity_m_s, r.drift_velocity_m_s, 2e-4) && near(r8.longitudinal_diffusion_n, r.longitudinal_diffusion_n, 2e-4),
                  "Reid ramp converged in the Legendre terms" + at);
            if (ref.td == 24) {
                fewer.legendre_terms = 2;
                const auto r2 = sim::solve_eedf(gas, c, fewer);
                check(r2.drift_velocity_m_s > 1.025 * r.drift_velocity_m_s, "two-term drift is several per cent high at 24 Td");
            }
        }
    }
    // Born-dipole rotational excitation, forward peaked, and a screened elastic angular form.
    {
        sim::CollisionProcess rot;
        rot.kind = sim::CollisionKind::Excitation;
        rot.target = "X";
        rot.product = "X(J1)";
        rot.threshold_ev = 0.004;
        rot.weight_ratio = 1.0 / 3;
        rot.angular = sim::CollisionProcess::Angular::BornDipole;
        for (double e = 0.004; e < 20; e *= 1.1) {
            rot.energy_ev.push_back(e);
            rot.cross_section_m2.push_back(e > 0.004 ? 1e-18 / e * std::log((std::sqrt(e) + std::sqrt(e - 0.004)) / (std::sqrt(e) - std::sqrt(e - 0.004))) : 0.0);
        }
        auto el = elastic(1e-19, 18);
        el.angular = sim::CollisionProcess::Angular::Screened;
        el.integral_cross_section_m2 = {3e-19, 3e-19};
        sim::EedfConditions c;
        c.reduced_field_td = 30;
        c.gas_temperature_k = 300;
        c.fractions["X"] = 0.7;
        c.fractions["X(J1)"] = 0.3;
        double previous = 0;
        for (int terms : {2, 4, 6, 8}) {
            const auto r = sim::solve_eedf({el, rot}, c, {.cells = 500, .max_energy_ev = 10, .power = 2, .legendre_terms = terms});
            check_budget(r, "anisotropic rotational, " + std::to_string(terms) + " terms");
            if (terms == 8) check(near(r.drift_velocity_m_s, previous, 1e-3), "anisotropic scattering converges in the Legendre terms");
            previous = r.drift_velocity_m_s;
            check(r.budget.rotational > 0 && r.budget.superelastic_gain > 0, "rotational loss and superelastic gain are both accounted");
        }
    }
    // Time-dependent breakdown in a model gas at 1 Torr across 1 cm.
    {
        auto el = elastic(6e-20, 18);
        sim::CollisionProcess ex, io, at, rc;
        ex.kind = sim::CollisionKind::Excitation; ex.target = "X"; ex.label = "excitation"; ex.threshold_ev = 8;
        ex.energy_ev = {8, 30, 1000}; ex.cross_section_m2 = {0, 1e-20, 1e-20};
        io.kind = sim::CollisionKind::Ionization; io.target = "X"; io.label = "ionization"; io.threshold_ev = 15;
        io.energy_ev = {15, 100, 1000}; io.cross_section_m2 = {0, 2e-20, 2e-20};
        at.kind = sim::CollisionKind::Attachment; at.target = "X"; at.label = "attachment";
        at.energy_ev = {0, 2, 5, 1000}; at.cross_section_m2 = {0, 1e-22, 0, 0};
        rc.kind = sim::CollisionKind::Recombination; rc.target = "X+"; rc.label = "recombination";
        rc.energy_ev = {0.001, 1, 100}; rc.cross_section_m2 = {1e-16, 1e-19, 1e-23};
        const std::vector<sim::CollisionProcess> gas{el, ex, io, at, rc};
        sim::EedfConditions c;
        c.fractions["X"] = 1;
        c.gas_temperature_k = 300;
        c.gas_density_m3 = 133.322 / (1.380649e-23 * 300);
        const sim::EedfGrid g{.cells = 120, .max_energy_ev = 150, .power = 2, .legendre_terms = 2};
        // An ideal source with no losses but attachment: after the seed relaxes the population
        // grows at the steady swarm's net rate with the steady mean energy, and the books close.
        sim::BreakdownSetup s;
        s.gap_m = 0.01;
        s.voltage_v = 500e-21 * c.gas_density_m3 * s.gap_m;  // 500 Td
        s.series_resistance_ohm = 0;
        s.drift_loss = false;
        s.seed_density_m3 = 1e6;
        s.end_time_s = 60e-9;
        const auto grow = sim::solve_breakdown(gas, c, s, g);
        const auto steady = sim::solve_eedf(gas, [&] { auto q = c; q.reduced_field_td = 500; return q; }(), g);
        const auto& p1 = grow.samples[grow.samples.size() - 2];
        const auto& p2 = grow.samples.back();
        const double rate = std::log(p2.electron_density_m3 / p1.electron_density_m3) / (p2.time_s - p1.time_s) / c.gas_density_m3;
        check(grow.stop == "end time" && near(rate, steady.net_rate_m3_s, 2e-3), "breakdown grows at the steady net rate (" + std::to_string(rate / steady.net_rate_m3_s) + ")");
        check(near(p2.mean_energy_ev, steady.mean_energy_ev, 2e-3), "breakdown relaxes to the steady mean energy");
        const auto& e = grow.energy;
        check(std::abs(e.electron_residual) < 1e-10 && std::abs(e.gap_residual) < 1e-9 && std::abs(e.circuit_residual) < 1e-9 && e.ionization > 0 && e.electronic > 0,
              "growth: electron, gap and circuit books close");
        // Through a resistance, with ion drift and cathode feedback: the gap voltage collapses,
        // the books close, and the breakdown time converges in the step size.
        s.series_resistance_ohm = 1000;
        s.drift_loss = true;
        s.ion_mobility_n = 6e21;
        s.secondary_yield = 0.05;
        s.seed_density_m3 = 1e9;
        s.voltage_v = 1000;
        s.end_time_s = 1e-6;
        const auto fall = sim::solve_breakdown(gas, c, s, g);
        bool falling = true;
        for (std::size_t i = 1; i < fall.samples.size(); ++i) falling = falling && fall.samples[i].gap_voltage_v <= fall.samples[i - 1].gap_voltage_v + 1e-9;
        check(fall.stop == "collapse" && fall.breakdown_time_s > 0 && falling && fall.samples.back().gap_voltage_v < 0.5 * s.voltage_v, "the gap voltage collapses");
        const auto& f = fall.energy;
        check(std::abs(f.electron_residual) < 1e-10 && std::abs(f.gap_residual) < 1e-9 && std::abs(f.circuit_residual) < 1e-4 && f.anode_loss > 0 && f.ion_joule > 0 &&
                  f.secondary_input > 0 && f.resistor > 0 && f.capacitor_change < 0,
              "collapse: electron, gap and circuit books close (" + std::to_string(f.electron_residual) + ", " + std::to_string(f.circuit_residual) + ")");
        s.step_tolerance = 0.25;
        const auto fine = sim::solve_breakdown(gas, c, s, g);
        check(near(fall.breakdown_time_s, fine.breakdown_time_s, 2e-3), "the breakdown time converges in the step size");
        s.step_tolerance = 1;
        check(refuses([&] { auto q = s; q.voltage_v = 0; (void)sim::solve_breakdown(gas, c, q, g); }), "refuses no voltage");
        check(refuses([&] { auto q = s; q.secondary_yield = 1; (void)sim::solve_breakdown(gas, c, q, g); }), "refuses a secondary yield of 1");
    }
    // The LXCat reader.
    {
        const std::string text = "ELASTIC\nAr\n 1.36e-5\nPROCESS: E + Ar -> E + Ar, Elastic\n-----\n 0 7.5e-20\n 1 1.0e-20\n-----\n"
                                 "EXCITATION\nN2 <-> N2(v1)\n 0.29 1.0\n-----\n 0.29 0\n 1 1e-21\n-----\n"
                                 "RECOMBINATION\nO2+\n-----\n 0.01 1e-18\n 1 1e-20\n-----\n";
        const auto ps = sim::read_lxcat(text);
        check(ps.size() == 3 && ps[0].kind == sim::CollisionKind::Elastic && near(ps[0].mass_ratio, 1.36e-5, 1e-12), "LXCat elastic");
        check(ps[1].product == "N2(v1)" && near(ps[1].threshold_ev, 0.29, 1e-12) && near(ps[1].weight_ratio, 1.0, 1e-12), "LXCat superelastic pair");
        check(ps[2].kind == sim::CollisionKind::Recombination && ps[2].target == "O2+" && ps[2].energy_ev.size() == 2, "LXCat recombination");
    }
    // Refusals.
    {
        sim::EedfConditions c;
        c.fractions["X"] = 1;
        check(refuses([&] { (void)sim::solve_eedf({elastic(1e-19, 28)}, c, {.cells = 4}); }), "refuses too few cells");
        check(refuses([&] { (void)sim::solve_eedf({elastic(1e-19, 28)}, c, {.legendre_terms = 1}); }), "refuses one Legendre term");
        c.fractions.clear();
        check(refuses([&] { (void)sim::solve_eedf({elastic(1e-19, 28)}, c); }), "refuses a gas with nothing in it");
        check(refuses([&] { (void)sim::read_lxcat("ELASTIC\nAr\n"); }), "refuses a truncated LXCat block");
    }
    // Persistent transient state owns density and energy, including nonzero angular modes.
    {
        const sim::EedfGrid grid{.cells = 120, .max_energy_ev = 8, .power = 2, .legendre_terms = 6};
        sim::EedfConditions c;
        c.fractions["X"] = 1;
        c.gas_density_m3 = 1e20;
        c.ion_fraction = 0;
        c.reduced_field_td = 300;
        auto state = sim::maxwellian_eedf(1e8, 1, grid);
        const auto original = state.density_modes;
        const auto first = sim::advance_eedf({elastic(1e-19, 28)}, c, state, 1e-10);
        check(near(first.state.electron_density_m3(), 1e8, 1e-12), "transient: elastic collisions and field conserve particle number");
        check(first.state.electron_energy_ev_m3() > state.electron_energy_ev_m3(), "transient: field heats electrons");
        check(first.linear_residual < 1e-9 && std::abs(first.energy_balance_relative) < 1e-6, "transient: true linear residual and discrete energy balance");
        check(state.density_modes == original && first.state.density_modes.size() == 720, "transient: immutable caller and all six angular modes persist");
        check(first.state.density_modes[3] != 0, "transient: first anisotropic mode evolves");
        auto altered = first.state;
        // The l=4 mode occupies slot 2 of each cell. A persisted higher mode cannot be
        // reconstructed from only F0 or the electron density.
        altered.density_modes[2] += 1e-4 * altered.density_modes[0];
        const auto second = sim::advance_eedf({elastic(1e-19, 28)}, c, altered, 1e-12);
        const auto without = sim::advance_eedf({elastic(1e-19, 28)}, c, first.state, 1e-12);
        check(second.state.density_modes[2] != without.state.density_modes[2], "transient: higher Legendre modes survive restart");
        check(refuses([&] { (void)sim::advance_eedf({elastic(1e-19, 28)}, c, state, 0); }), "transient refuses zero timestep");
        altered.density_modes.pop_back();
        check(refuses([&] { (void)sim::advance_eedf({elastic(1e-19, 28)}, c, altered, 1e-12); }), "transient refuses truncated angular state");
    }
    // Empty initial products retain rate channels and become targets on the next coupled call.
    {
        sim::CollisionProcess ex;
        ex.kind = sim::CollisionKind::Excitation; ex.target = "X"; ex.product = "X*"; ex.label = "X <-> X*";
        ex.threshold_ev = 0.05; ex.weight_ratio = 1.0 / 3;
        ex.energy_ev = {0.05, 0.2, 10}; ex.cross_section_m2 = {0, 5e-20, 1e-20};
        sim::CollisionProcess rec;
        rec.kind = sim::CollisionKind::Recombination; rec.target = "X+"; rec.label = "recombination";
        rec.energy_ev = {0, 10}; rec.cross_section_m2 = {1e-19, 1e-19};
        sim::EedfConditions c;
        c.fractions["X"] = 1; c.reduced_field_td = 0; c.ion_fraction = 0; c.gas_density_m3 = 1e20;
        const sim::EedfGrid grid{.cells = 120, .max_energy_ev = 8, .power = 2, .legendre_terms = 4};
        const auto state = sim::maxwellian_eedf(1e8, 1, grid);
        const std::vector<sim::CollisionProcess> gas{elastic(1e-19, 28), ex, rec};
        const auto empty = sim::advance_eedf(gas, c, state, 1e-10);
        check(empty.swarm.rates.size() == 2 && empty.swarm.rates[1].rate_m3_s > 0 && empty.swarm.rates[1].fraction == 0,
              "zero initial target keeps its coefficient and zero source");
        c.fractions["X+"] = 1e-3;
        const auto ions = sim::advance_eedf(gas, c, state, 1e-10);
        check(ions.state.electron_density_m3() < empty.state.electron_density_m3() && ions.swarm.recombination_rate_m3_s > 0,
              "transient: recombination uses actual named ion population");
        c.fractions["X*"] = 0.1;
        const auto excited = sim::advance_eedf(gas, c, state, 1e-10);
        check(excited.swarm.budget.superelastic_gain > 0 && excited.swarm.rates[0].superelastic_rate_m3_s > 0,
              "initially absent excited target activates superelastic collisions");
        c.fractions["X"] = -1;
        check(refuses([&] { (void)sim::advance_eedf(gas, c, state, 1e-10); }), "transient refuses negative target populations");
    }
    {
        auto el = elastic(1e-19, 18); el.target = "H2O";
        sim::WaterVapourOptions options; options.j_max = 2;
        const auto water = sim::water_vapour_set({el}, options);
        double sum = 0; for (const auto& level : water.levels) sum += water.fractions.at(level.name);
        check(!water.processes.empty() && !water.levels.empty() && near(sum, 1, 1e-12), "water rotational state set is normalized");
        check(sim::hydrogen_levels(1, 3).size() == 8 && sim::hydrogen_vibrational_state(0.516) == 1, "hydrogen rovibrational state helpers");
    }
    // Analytic backward-Euler angular relaxation: every retained mode has its own time
    // derivative. This checks the method independently of a second solver invocation.
    {
        const sim::EedfGrid grid{.cells = 64, .max_energy_ev = 5, .power = 2, .legendre_terms = 6};
        auto el = elastic(1e-19, 28); el.mass_ratio = 0;
        sim::EedfConditions c; c.fractions["X"] = 1; c.reduced_field_td = 0; c.ion_fraction = 0; c.gas_density_m3 = 1e20;
        auto state = sim::maxwellian_eedf(1, 0.5, grid);
        const std::size_t cell = 20, index = cell * 6 + 2; // l=4
        state.density_modes[index] = 0.01 * state.density_modes[cell * 6];
        const double lo = grid.max_energy_ev * std::pow(static_cast<double>(cell) / grid.cells, grid.power);
        const double hi = grid.max_energy_ev * std::pow(static_cast<double>(cell + 1) / grid.cells, grid.power);
        const double weight = 2.0 / 3 * (std::pow(hi, 1.5) - std::pow(lo, 1.5));
        const double gamma = std::sqrt(2 * 1.602176634e-19 / 9.1093837015e-31);
        const double rate = c.gas_density_m3 * gamma * 1e-19 * (hi * hi - lo * lo) / (2 * weight), dt = 2e-8;
        const auto result = sim::advance_eedf({el}, c, state, dt);
        check(near(result.state.density_modes[index], state.density_modes[index] / (1 + dt * rate), 1e-10),
              "all-mode transient: l=4 obeys exact discrete implicit relaxation");
        check(near(result.state.electron_energy_ev_m3(), state.electron_energy_ev_m3(), 1e-12), "zero-field infinite-mass collisions preserve electron energy");
    }
    // JSON and typed calls share the same runtime, including full-state checkpoint exchange.
    {
        const raikou::Json request = {
            {"processes", {{{"kind", "elastic"}, {"target", "X"}, {"mass_ratio", kMe / (28 * kAmu)},
                             {"energy_ev", {0, 1000}}, {"cross_section_m2", {1e-19, 1e-19}}}}},
            {"conditions", {{"fractions", {{"X", 1}}}, {"reduced_field_td", 10}, {"gas_density_m3", 1e20}, {"ion_fraction", 0}}},
            {"grid", {{"cells", 64}, {"max_energy_ev", 60}, {"legendre_terms", 4}}}};
        const auto result = sim::solve_eedf_json(request);
        check(result.at("converged").get<bool>() && result.at("mode") == "steady", "JSON steady solve");
        auto threaded = request; threaded["execution"] = {{"threads", 2}};
        const auto parallel = sim::solve_eedf_json(threaded);
        check(near(parallel.at("mean_energy_ev").get<double>(), result.at("mean_energy_ev").get<double>(), 1e-12),
              "threaded local EEDF agrees with serial");
        auto step_request = request;
        step_request["initial"] = {{"electron_density_m3", 1e8}, {"mean_energy_ev", 1}};
        step_request["dt_s"] = 1e-10;
        const auto first = sim::advance_eedf_json(step_request);
        step_request.erase("initial"); step_request["state"] = first.at("state");
        const auto resumed = sim::advance_eedf_json(step_request);
        check(resumed.at("state").at("density_modes").size() == 256 &&
              near(resumed.at("state").at("time_s").get<double>(), 2e-10, 1e-12), "JSON transient round-trip retains every angular mode");
        check(sim::water_levels_json({{"j_max", 2}}).at("levels").size() > 1, "JSON water levels");
        auto invalid_request = request;
        invalid_request["processes"][0]["kind"] = "mystery";
        check(refuses([&] { (void)sim::solve_eedf_json(invalid_request); }), "JSON rejects unknown collision kind");
    }
    // A coupled closure reads the evolving inventory instead of freezing initial fractions.
    // This small synthetic N/N+ mechanism verifies event counts, not physical nitrogen data.
    {
        using raikou::Json;
        const auto mechanism = raikou::chemistry::Mechanism::from_json({{"id", "synthetic_eedf_coupling"},
            {"species", Json::array({{{"id", "N"}, {"elements", {{"N", 1}}}},
                                     {{"id", "N+"}, {"elements", {{"N", 1}}}, {"charge", 1}},
                                     {{"id", "e"}, {"elements", Json::object()}, {"charge", -1}}})},
            {"reactions", Json::array({
                {{"id", "ionize"}, {"reactants", {{"e", 1}, {"N", 1}}}, {"products", {{"e", 2}, {"N+", 1}}},
                 {"rate", {{"type", "electron_eedf"}}}, {"collision_label", "ionize"}},
                {{"id", "recombine"}, {"reactants", {{"e", 1}, {"N+", 1}}}, {"products", {{"N", 1}}},
                 {"rate", {{"type", "electron_eedf"}}}, {"collision_label", "recombine"}}})}});
        auto el = elastic(1e-19, 14); el.target = "N";
        sim::CollisionProcess ion; ion.kind = sim::CollisionKind::Ionization; ion.target = "N"; ion.label = "ionize";
        ion.threshold_ev = 2; ion.energy_ev = {2, 5, 100}; ion.cross_section_m2 = {0, 1e-21, 1e-21};
        sim::CollisionProcess rec; rec.kind = sim::CollisionKind::Recombination; rec.target = "N+"; rec.label = "recombine";
        rec.energy_ev = {0, 100}; rec.cross_section_m2 = {1e-21, 1e-21};
        sim::ElectronCoupling coupling; coupling.processes = {el, ion, rec}; coupling.gas_density_m3 = 1e20;
        coupling.grid = {.cells = 80, .max_energy_ev = 40, .power = 2, .legendre_terms = 4}; coupling.strict_event_mapping = true;
        const raikou::chemistry::Environment environment;
        const raikou::chemistry::State neutral{{1e20, 0, 1e8}}, ionized{{9e19, 1e19, 1e8}};
        const auto first = sim::evaluate_electron_feedback(mechanism, neutral, environment, 10, coupling);
        const auto second = sim::evaluate_electron_feedback(mechanism, ionized, environment, 10, coupling);
        check(first.conditions.fractions.at("N+") == 0 && near(second.conditions.fractions.at("N+"), 0.1, 1e-12) &&
              second.swarm.recombination_rate_m3_s > 0, "coupled EEDF reads newly produced actual ions");
        check(second.collision_event_mapping_complete && near(second.kinetic_electron_source_m3_s, second.mapped_electron_source_m3_s, 1e-10),
              "coupled chemistry and EEDF electron event sources agree");
        check(second.environment.electron_rates.at("ionize") > 0 && second.mobility_m2_V_s > 0 &&
              first.swarm.mean_energy_ev != second.swarm.mean_energy_ev, "evolving composition changes EEDF rates and transport");
        const auto electrons = sim::maxwellian_eedf(1e8, 1, coupling.grid);
        const auto trial = sim::advance_electron_feedback(mechanism, ionized, environment, 10, coupling, electrons, 1e-10);
        check(trial.feedback.collision_event_mapping_complete && std::abs(trial.kinetic_step.energy_balance_relative) < 1e-6,
              "coupled transient trial preserves the kinetic energy moment");
        auto invalid_coupling = coupling; invalid_coupling.targets["N+"] = {"e"};
        check(refuses([&] { (void)sim::evaluate_electron_feedback(mechanism, neutral, environment, 10, invalid_coupling); }),
              "coupled EEDF refuses a gas electron as a heavy target");
        auto massive_electron = mechanism;
        massive_electron.species[2].elements = {{"H", 1}}; massive_electron.species[2].mass_kg = 1.67e-27;
        check(refuses([&] { (void)sim::coupled_eedf_conditions(massive_electron, neutral, environment, 10, coupling); }),
              "a negative hydrogen ion cannot be selected as kinetic electrons");
        massive_electron = mechanism; massive_electron.species[2].mass_kg = 1.67e-27;
        check(refuses([&] { (void)sim::coupled_eedf_conditions(massive_electron, neutral, environment, 10, coupling); }),
              "element-free selected electrons must carry the physical electron mass");
        auto duplicate_electrons = mechanism;
        duplicate_electrons.species.push_back(duplicate_electrons.species[2]); duplicate_electrons.species.back().id = "e_second";
        auto duplicate_inventory = neutral; duplicate_inventory.densities_m3.push_back(1e8);
        auto duplicate_targets = coupling; duplicate_targets.targets["N"] = {"e_second"};
        check(refuses([&] { (void)sim::coupled_eedf_conditions(duplicate_electrons, duplicate_inventory, environment, 10, duplicate_targets); }),
              "a second element-free electron population cannot be counted as heavy gas or used as a collision target");
        auto multiphase_json = mechanism.to_json();
        multiphase_json["species"].push_back({{"id", "L0"}, {"phase", "liquid"}, {"elements", {{"N", 1}}}});
        multiphase_json["species"].push_back({{"id", "L1"}, {"phase", "liquid"}, {"elements", {{"N", 1}}}});
        multiphase_json["reactions"].push_back({{"id", "manufactured_liquid_heat"}, {"basis_phase", "liquid"},
            {"reactants", {{"L0", 1}}}, {"products", {{"L1", 1}}}, {"rate", {{"type", "constant"}, {"A", 1e6}}},
            {"energy_eV_per_event", {{"liquid/heavy", 1}, {"liquid/internal", -1}}}, {"external_energy_eV_per_event", 0}});
        const auto multiphase = raikou::chemistry::Mechanism::from_json(multiphase_json);
        const raikou::chemistry::State inventory{{1e20, 0, 1e12, 1e18, 0}};
        const auto seed = sim::maxwellian_eedf(1e12, 1, coupling.grid);
        sim::CoupledCellOptions options;
        options.relative_tolerance = 1e-8; options.temperature_tolerance_K = 1e-10;
        // Manufactured capacities exercise the equations; no liquid/gas property calibration.
        options.heat_capacity_J_m3_K = {{"gas", 1e-10}, {"liquid", 1e-3}};
        options.thermal_reservoirs = {{"liquid", {"liquid/heavy"}}};
        const double dt = 1e-9;
        const auto complete = sim::advance_coupled_cell(multiphase, inventory, environment, coupling, seed, 10, dt, options);
        check(complete.nonlinear_residual <= 1 && complete.state.densities_m3[1] > 0 && complete.state.densities_m3[2] > inventory.densities_m3[2],
              "monolithic cell evolves breakdown ions and kinetic electron count together");
        check(complete.state.densities_m3[2] == complete.electrons.electron_density_m3(), "accepted electron count has exactly one kinetic-moment owner");
        check(std::abs((complete.state.densities_m3[1] - complete.state.densities_m3[2]) + inventory.densities_m3[2]) < 100,
              "monolithic cell conserves initial net charge");
        check(near(complete.state.densities_m3[0] + complete.state.densities_m3[1], inventory.densities_m3[0], 1e-12) &&
              near(complete.state.densities_m3[3] + complete.state.densities_m3[4], inventory.densities_m3[3], 1e-12),
              "monolithic gas/liquid elemental inventories are conserved");
        check(near(complete.thermal_energy_change_J_m3.at("liquid"), dt * complete.chemistry.energy_sources_W_m3.at("liquid/heavy"), 1e-5),
              "liquid thermal balance uses its own phase energy source");
        check(complete.environment.gas_temperature_K > environment.gas_temperature_K &&
              complete.environment.liquid_temperature_K > environment.liquid_temperature_K,
              "gas elastic transfer and liquid reaction heating couple to phase temperatures");
        // The supplied water packs use phase "aqueous" and aqueous/... reservoirs.
        // Preserve that phase's own volume when interface transfer deposits heat.
        auto aqueous_json = multiphase_json;
        for (auto& species : aqueous_json["species"]) if (species.value("phase", std::string("gas")) == "liquid") species["phase"] = "aqueous";
        aqueous_json["reactions"].back()["basis_phase"] = "aqueous";
        aqueous_json["reactions"].back()["energy_eV_per_event"] = {{"aqueous/heavy", 1}, {"aqueous/internal", -1}};
        aqueous_json["reactions"].push_back({{"id", "manufactured_aqueous_interface_heat"}, {"basis_phase", "gas"}, {"basis_interface", "wet"},
            {"reactants", {{"N", 1}}}, {"products", {{"L0", 1}}}, {"rate", {{"type", "constant"}, {"A", 1e3}}},
            {"energy_eV_per_event", {{"aqueous/heavy", 1}, {"aqueous/internal", -1}}}, {"external_energy_eV_per_event", 0}});
        const auto aqueous_mechanism = raikou::chemistry::Mechanism::from_json(aqueous_json);
        auto aqueous_environment = environment;
        aqueous_environment.phase_volumes_m3 = {{"gas", 2}, {"aqueous", 0.5}};
        aqueous_environment.interface_areas_m2 = {{"wet", 1}};
        auto aqueous_options = options;
        aqueous_options.heat_capacity_J_m3_K = {{"aqueous", 1e-3}};
        aqueous_options.thermal_reservoirs = {{"aqueous", {"aqueous/heavy"}}};
        const auto aqueous = sim::advance_coupled_cell(aqueous_mechanism, inventory, aqueous_environment, coupling, seed, 10, dt, aqueous_options);
        check(aqueous.environment.liquid_temperature_K > environment.liquid_temperature_K &&
              near(aqueous.thermal_energy_change_J_m3.at("aqueous"), dt * aqueous.chemistry.energy_sources_W_m3.at("aqueous/heavy"), 1e-5),
              "aqueous pack phase and reservoir names drive the shared liquid temperature with their own volume");
        const double total_atoms0 = 2 * (inventory.densities_m3[0] + inventory.densities_m3[1]) + 0.5 * (inventory.densities_m3[3] + inventory.densities_m3[4]);
        const double total_atoms1 = 2 * (aqueous.state.densities_m3[0] + aqueous.state.densities_m3[1]) + 0.5 * (aqueous.state.densities_m3[3] + aqueous.state.densities_m3[4]);
        check(near(total_atoms1, total_atoms0, 1e-9), "coupled aqueous interface conserves volume-weighted elemental inventory");
        aqueous_options.heat_capacity_J_m3_K["liquid"] = 1e-3;
        check(refuses([&] { (void)sim::advance_coupled_cell(aqueous_mechanism, inventory, aqueous_environment, coupling, seed, 10, dt, aqueous_options); }),
              "liquid and aqueous cannot duplicate one liquid-temperature unknown");
        auto selector_options = options;
        selector_options.heat_capacity_J_m3_K = {{"aqueous", 1}};
        selector_options.thermal_reservoirs = {{"aqueous", {"aqueous/heavy_typo"}}};
        check(refuses([&] { (void)sim::advance_coupled_cell(aqueous_mechanism, inventory, aqueous_environment, coupling, seed, 10, dt, selector_options); }),
              "unknown thermal reservoir cannot silently discard aqueous heating");
        selector_options.thermal_reservoirs = {{"aqueous", {"aqueous/heavy", "aqueous/heavy"}}};
        check(refuses([&] { (void)sim::advance_coupled_cell(aqueous_mechanism, inventory, aqueous_environment, coupling, seed, 10, dt, selector_options); }),
              "duplicate thermal reservoir cannot double aqueous heating");
        auto reserved_json = aqueous_json;
        reserved_json["reactions"].back()["energy_eV_per_event"] = {{"gas/translation", 1}, {"gas/internal", -1}};
        const auto reserved_mechanism = raikou::chemistry::Mechanism::from_json(reserved_json);
        selector_options.heat_capacity_J_m3_K = {{"gas", 1}};
        selector_options.thermal_reservoirs = {{"gas", {"gas/translation"}}};
        const auto distinct_heat = sim::advance_coupled_cell(reserved_mechanism, inventory, aqueous_environment, coupling, seed, 10, dt, selector_options);
        check(near(distinct_heat.thermal_energy_change_J_m3.at("gas"), dt *
              (distinct_heat.chemistry.energy_sources_W_m3.at("gas/translation") + distinct_heat.feedback.collision_energy_sources_W_m3.at("gas/translation")), 1e-5),
              "authored heavy chemistry gas/translation heat adds once alongside the distinct EEDF elastic transfer");
        auto bounded_json = aqueous_json;
        bounded_json["reactions"].erase(bounded_json["reactions"].end() - 1);
        bounded_json["reactions"].back()["rate"]["temperature"] = "liquid";
        bounded_json["reactions"].back()["rate"]["maximum_temperature_K"] = 300;
        bounded_json["reactions"].back()["energy_eV_per_event"] = raikou::Json::object();
        const auto bounded_mechanism = raikou::chemistry::Mechanism::from_json(bounded_json);
        selector_options.heat_capacity_J_m3_K = {{"aqueous", 1}}; selector_options.thermal_reservoirs.clear();
        const auto bounded = sim::advance_coupled_cell(bounded_mechanism, inventory, aqueous_environment, coupling, seed, 10, dt, selector_options);
        check(bounded.environment.liquid_temperature_K == 300 &&
              near(bounded.state.densities_m3[3], inventory.densities_m3[3] / (1 + 1e6 * dt), 1e-8),
              "admissible backward temperature difference advances a valid solve exactly at its upper applicability bound");
        for (const std::string reservoir : {"gas/electron", "gas/electrons"}) {
            auto unsupported_json = bounded_json;
            unsupported_json["reactions"].back()["energy_eV_per_event"] = {{reservoir, 1}, {"aqueous/internal", -1}};
            const auto unsupported = raikou::chemistry::Mechanism::from_json(unsupported_json);
            check(refuses([&] { (void)sim::advance_coupled_cell(unsupported, inventory, aqueous_environment, coupling, seed, 10, dt, selector_options); }),
                  "unmapped non-collision electron energy transfer requires a kinetic distribution source: " + reservoir);
        }
        Json closure = {{"processes", Json::array()}, {"gas_density_m3", 1e20},
                        {"grid", {{"cells", 80}, {"max_energy_ev", 40}, {"power", 2}, {"legendre_terms", 4}}}};
        for (const auto& process : coupling.processes) closure["processes"].push_back({
            {"kind", process.kind == sim::CollisionKind::Elastic ? "elastic" : (process.kind == sim::CollisionKind::Ionization ? "ionization" : "recombination")},
            {"target", process.target}, {"label", process.label}, {"mass_ratio", process.mass_ratio}, {"threshold_ev", process.threshold_ev},
            {"energy_ev", process.energy_ev}, {"cross_section_m2", process.cross_section_m2}});
        Json cell_request = {{"mechanism", multiphase_json}, {"state", {{"densities_m3", inventory.densities_m3}}},
            {"electron_closure", closure}, {"initial_mean_energy_ev", 1}, {"field_magnitude_V_m", 10}, {"dt_s", dt}};
        const auto json_first = sim::advance_coupled_cell_json(cell_request);
        cell_request["state"] = json_first.at("state"); cell_request["environment"] = json_first.at("environment");
        cell_request["electrons"] = json_first.at("electrons"); cell_request.erase("initial_mean_energy_ev");
        const auto json_second = sim::advance_coupled_cell_json(cell_request);
        check(json_second.at("nonlinear_residual").get<double>() <= 1 &&
              near(json_second.at("electrons").at("time_s").get<double>(), 2 * dt, 1e-12) &&
              json_second.at("state").at("densities_m3").at("N+").get<double>() > json_first.at("state").at("densities_m3").at("N+").get<double>(),
              "monolithic JSON state resumes with evolving heavy populations and every electron mode");
        const auto untouched = seed.density_modes;
        options.maximum_newton_iterations = 1;
        options.relative_tolerance = 1e-13; options.absolute_density_tolerance_m3 = 1e-5; options.temperature_tolerance_K = 1e-13;
        check(refuses([&] { (void)sim::advance_coupled_cell(multiphase, inventory, environment, coupling, seed, 10, dt, options); }) &&
              seed.density_modes == untouched && inventory.densities_m3[1] == 0, "failed monolithic step leaves every initial state unchanged");
        auto incorrect = mechanism.to_json();
        incorrect["reactions"][0]["orders"] = {{"e", 1}, {"N+", 1}};
        const auto wrong_order = raikou::chemistry::Mechanism::from_json(incorrect);
        check(refuses([&] { (void)sim::evaluate_electron_feedback(wrong_order, neutral, environment, 10, coupling); }),
              "EEDF bridge rejects a reaction with wrong heavy-target kinetic order");
        auto mismatch = mechanism.to_json();
        for (const auto& name : {"NX", "B", "BX"}) mismatch["species"].push_back({{"id", name}, {"elements", {{"N", 1}}}});
        mismatch["reactions"].push_back({{"id", "wrong_excitation_target"}, {"reactants", {{"e", 1}, {"B", 1}}},
            {"products", {{"e", 1}, {"BX", 1}}}, {"rate", {{"type", "electron_eedf"}}}, {"collision_label", "excite"}});
        const auto wrong_target = raikou::chemistry::Mechanism::from_json(mismatch);
        sim::CollisionProcess ex; ex.kind = sim::CollisionKind::Excitation; ex.target = "N"; ex.product = "NX"; ex.label = "excite";
        ex.threshold_ev = 0.05; ex.energy_ev = {0.05, 1, 100}; ex.cross_section_m2 = {0, 1e-22, 1e-22};
        auto wrong_coupling = coupling; wrong_coupling.processes.push_back(ex);
        check(refuses([&] { (void)sim::evaluate_electron_feedback(wrong_target, {{1e20, 0, 1e8, 0, 1e17, 0}}, environment, 10, wrong_coupling); }),
              "EEDF bridge rejects zero-electron-change excitation bound to a different species");
    }
    // Exercise the actual reference subset's aqueous phase, while retaining its strict
    // 298.15 K applicability. No thermal extrapolation or missing heats are invented.
    {
        const auto path = std::filesystem::path(__FILE__).parent_path().parent_path() / "mechanisms" / "aqueous_reference_subset.json";
        std::ifstream input(path);
        check(static_cast<bool>(input), "aqueous reference pack is available for coupled integration regression");
        if (input) {
            raikou::Json reference; input >> reference;
            reference["species"].push_back({{"id", "Xg"}, {"elements", {{"N", 1}}}});
            reference["species"].push_back({{"id", "e"}, {"elements", raikou::Json::object()}, {"charge", -1}});
            const auto mechanism = raikou::chemistry::Mechanism::from_json(reference);
            raikou::chemistry::State state; state.densities_m3.assign(mechanism.species.size(), 0);
            state.densities_m3[mechanism.species_index("Xg")] = 1e20;
            state.densities_m3[mechanism.species_index("e")] = 1e8;
            auto momentum = elastic(1e-19, 28); momentum.target = "Xg";
            sim::ElectronCoupling coupling; coupling.processes = {momentum}; coupling.gas_density_m3 = 1e20;
            coupling.grid = {.cells = 32, .max_energy_ev = 8, .power = 2, .legendre_terms = 2};
            const auto electrons = sim::maxwellian_eedf(1e8, 1, coupling.grid);
            raikou::chemistry::Environment environment; environment.liquid_temperature_K = 298.15;
            environment.phase_volumes_m3 = {{"gas", 2}, {"aqueous", 0.5}};
            sim::CoupledCellOptions options; options.heat_capacity_J_m3_K = {{"aqueous", 1e6}};
            const auto result = sim::advance_coupled_cell(mechanism, state, environment, coupling, electrons, 0, 1e-10, options);
            check(result.environment.liquid_temperature_K == 298.15 && result.thermal_energy_change_J_m3.at("aqueous") == 0,
                  "actual aqueous reference pack integrates with its named phase and declared reference temperature");
        }
    }
    if (failures == 0) std::cout << "electron Boltzmann qualification passed\n";
    return failures == 0 ? 0 : 1;
}

int main(int argc, char** argv) {
    try { return run_tests(argc, argv); }
    catch (const std::exception& error) { std::cerr << "EEDF qualification exception: " << error.what() << '\n'; return 1; }
}
