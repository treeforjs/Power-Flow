#include "raikou/c_api.h"
#include "raikou/collisional_radiative_model.h"
#include "raikou/spark_breakdown_solver.h"

#include <cmath>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <limits>
#include <string>

namespace {
void require(bool condition, const char* message) {
    if (!condition) {
        std::cerr << message << ": " << raikou_last_error() << '\n';
        std::exit(1);
    }
}
bool near(double a, double b, double relative = 1e-12) {
    return std::abs(a - b) <= relative * std::max(std::abs(a), std::abs(b));
}
}

int main() {
    using CR = raikou::CollisionalRadiativeModel;
    require(std::strcmp(raikou_version(), RAIKOU_VERSION) == 0, "Version must match the documented ABI");
    const auto numeric_version = std::to_string(RAIKOU_VERSION_MAJOR) + "." +
        std::to_string(RAIKOU_VERSION_MINOR) + "." + std::to_string(RAIKOU_VERSION_PATCH);
    require(numeric_version == RAIKOU_VERSION, "Numeric version macros must match the version string");
    raikou_plasma_state state{};
    require(raikou_default_plasma_state(&state) == RAIKOU_OK, "Default plasma state");
    const auto expected = CR{}.evaluate(CR::PlasmaState{});
    raikou_radiance_result radiance{};
    require(raikou_evaluate(&state, &radiance) == RAIKOU_OK, "Evaluate default state");
    for (int level = 0; level < RAIKOU_NUM_LEVELS; ++level)
        require(near(radiance.populations_m3[level], expected.populations_m3[level]), "C and C++ populations agree");
    require(near(radiance.lyman_alpha_radiance_W_m2_sr, expected.lyman_alpha_radiance_W_m2_sr), "C and C++ Ly-alpha agree");
    require(near(radiance.lyman_beta_radiance_W_m2_sr, expected.lyman_beta_radiance_W_m2_sr), "C and C++ Ly-beta agree");
    require(near(radiance.balmer_alpha_radiance_W_m2_sr, expected.balmer_alpha_radiance_W_m2_sr), "C and C++ H-alpha agree");
    require(near(radiance.balmer_beta_radiance_W_m2_sr, expected.balmer_beta_radiance_W_m2_sr), "C and C++ H-beta agree");
    require(near(radiance.molecular_lyman_proxy_W_m2_sr, expected.molecular_lyman_proxy_W_m2_sr), "C and C++ molecular radiance agree");
    require(near(radiance.tau_0_lyman_alpha, expected.tau_0_lyman_alpha), "C and C++ optical depth agree");
    require(near(radiance.tau_0_lyman_beta, expected.tau_0_lyman_beta), "C and C++ Ly-beta optical depth agree");
    require(near(radiance.escape_factor_lyman_alpha, expected.escape_factor_lyman_alpha), "C and C++ Ly-alpha escape agree");
    require(near(radiance.escape_factor_lyman_beta, expected.escape_factor_lyman_beta), "C and C++ Ly-beta escape agree");

    raikou_rate_result rates{};
    constexpr double temperature = 3.5;
    require(raikou_rate_coefficients(temperature, &rates) == RAIKOU_OK, "Evaluate rate coefficients");
    for (int i = 0; i < RAIKOU_NUM_LEVELS; ++i) {
        require(near(rates.ionization_m3_s[i], CR::ionization_rate(i + 1, temperature)), "C and C++ ionization rates agree");
        require(near(rates.radiative_recombination_m3_s[i], CR::radiative_recombination(i + 1, temperature)), "C and C++ radiative recombination agree");
        require(near(rates.three_body_recombination_m6_s[i], CR::three_body_recombination(i + 1, temperature)), "C and C++ three-body recombination agree");
        require(near(rates.h2_dissociation_m3_s[i], CR::h2_dissociation_to_level(i + 1, temperature)), "C and C++ dissociation agree");
        for (int j = 0; j < RAIKOU_NUM_LEVELS; ++j) {
            if (i < j) {
                require(rates.excitation_m3_s[i][j] > 0.0, "Excitation is positive");
                require(near(rates.excitation_m3_s[i][j], CR::excitation_rate(i + 1, j + 1, temperature)), "C and C++ excitation agree");
                const double lower = i + 1, upper = j + 1;
                const double gap = CR::IH_EV * (1.0 / (lower * lower) - 1.0 / (upper * upper));
                const double balanced = rates.excitation_m3_s[i][j] * lower * lower / (upper * upper) * std::exp(gap / temperature);
                require(near(rates.deexcitation_m3_s[j][i], balanced), "Rates satisfy detailed balance");
            } else require(rates.excitation_m3_s[i][j] == 0.0, "Inapplicable excitation entries are zero");
        }
    }

    raikou_fit_result fit{};
    require(raikou_fit_vuv_shot(radiance.lyman_alpha_radiance_W_m2_sr,
        radiance.lyman_alpha_radiance_W_m2_sr * 0.1, radiance.molecular_lyman_proxy_W_m2_sr,
        radiance.molecular_lyman_proxy_W_m2_sr * 0.1, state.path_length_m, state.Tgas_K, nullptr, &fit)
        == RAIKOU_OK, "Fit a synthetic VUV observation");
    require(fit.iterations > 0 && std::isfinite(fit.chi2_reduced), "Fit returns finite diagnostics");
    require(fit.Te_eV >= 0.5 && fit.Te_eV <= 20.0 && fit.ne_m3 >= 1e17 && fit.ne_m3 <= 1e22,
        "Fit respects supplied bounds");
    const auto expected_fit = CR{}.fit_vuv_shot(radiance.lyman_alpha_radiance_W_m2_sr,
        radiance.lyman_alpha_radiance_W_m2_sr * 0.1, radiance.molecular_lyman_proxy_W_m2_sr,
        radiance.molecular_lyman_proxy_W_m2_sr * 0.1, state.path_length_m, state.Tgas_K);
    require(near(fit.Te_eV, expected_fit.Te_eV) && near(fit.ne_m3, expected_fit.ne_m3)
        && near(fit.nH_m3, expected_fit.nH_m3) && near(fit.nH2_m3, expected_fit.nH2_m3), "C and C++ fitted parameters agree");
    require(fit.converged == static_cast<int>(expected_fit.converged) && fit.iterations == expected_fit.iterations,
        "C and C++ fit diagnostics agree");

    raikou_spark_config config{};
    raikou_spark_state spark{};
    require(raikou_default_spark_config(&config) == RAIKOU_OK, "Default spark config");
    require(raikou_default_spark_state(&spark) == RAIKOU_OK, "Default spark state");
    constexpr double dt = 1e-8;
    const auto expected_spark = raikou::SparkBreakdownSolver::step_spark_discharge({}, dt, {});
    require(raikou_step_spark(&spark, dt, &config, &spark) == RAIKOU_OK, "In-place spark step");
    require(near(spark.time_s, dt) && near(spark.current_A, expected_spark.current_A), "C and C++ spark state agree");
    require(near(spark.deposited_energy_J, expected_spark.deposited_energy_J), "C and C++ spark energy agree");
    require(near(spark.channel_radius_m, expected_spark.channel_radius_m)
        && near(spark.pressure_Pa, expected_spark.pressure_Pa)
        && near(spark.temperature_K, expected_spark.temperature_K)
        && near(spark.accumulated_action, expected_spark.accumulated_action), "C and C++ full spark state agree");

    require(raikou_evaluate(nullptr, &radiance) == RAIKOU_INVALID_ARGUMENT, "Null input rejected");
    require(raikou_evaluate(&state, nullptr) == RAIKOU_INVALID_ARGUMENT, "Null output rejected");
    require(raikou_default_plasma_state(nullptr) == RAIKOU_INVALID_ARGUMENT, "Null default output rejected");
    require(raikou_rate_coefficients(-1.0, &rates) == RAIKOU_INVALID_ARGUMENT, "Negative temperature rejected");
    require(raikou_rate_coefficients(std::numeric_limits<double>::quiet_NaN(), &rates) == RAIKOU_INVALID_ARGUMENT, "NaN rejected");
    require(std::strlen(raikou_last_error()) > 0, "Failure has error text");
    require(raikou_rate_coefficients(temperature, &rates) == RAIKOU_OK && std::strlen(raikou_last_error()) == 0,
        "Success clears the previous error");
    radiance.lyman_alpha_radiance_W_m2_sr = 42.0;
    state.ne_m3 = -1.0;
    require(raikou_evaluate(&state, &radiance) == RAIKOU_INVALID_ARGUMENT && radiance.lyman_alpha_radiance_W_m2_sr == 42.0,
        "Invalid input leaves the output untouched");
    require(raikou_default_plasma_state(&state) == RAIKOU_OK, "Reset state");
    state.ne_m3 = std::numeric_limits<double>::max();
    require(raikou_evaluate(&state, &radiance) == RAIKOU_NUMERICAL_ERROR, "Overflow becomes a numerical status");
    raikou_fit_priors priors{};
    require(raikou_default_fit_priors(&priors) == RAIKOU_OK, "Default fit priors");
    priors.min_Te_eV = priors.max_Te_eV + 1.0;
    require(raikou_fit_vuv_shot(1, 0.1, 1, 0.1, .005, 5000, &priors, &fit) == RAIKOU_INVALID_ARGUMENT,
        "Reversed prior bounds rejected");
    require(raikou_fit_vuv_shot(1, 0, 1, 0.1, .005, 5000, nullptr, &fit) == RAIKOU_INVALID_ARGUMENT,
        "Zero measurement uncertainty rejected");
    const double saved_time = spark.time_s;
    require(raikou_step_spark(&spark, -dt, &config, &spark) == RAIKOU_INVALID_ARGUMENT && spark.time_s == saved_time,
        "Invalid in-place spark step is atomic");
    config.plasma_conductivity = 0.0;
    require(raikou_step_spark(&spark, dt, &config, &spark) == RAIKOU_INVALID_ARGUMENT,
        "Zero conductivity rejected");
    return 0;
}
