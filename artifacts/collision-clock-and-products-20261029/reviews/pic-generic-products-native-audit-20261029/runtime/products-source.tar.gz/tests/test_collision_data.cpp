#include "raikou/collision_data.h"
#include "raikou/h2o_conditional_parent.h"
#include <iostream>
#include <functional>

namespace {
int checks=0;
void check(bool value,const std::string& text) {
    ++checks;if (!value) throw std::runtime_error(text);
}
void close(double actual,double expected,double relative,const std::string& label) {
    check(std::abs(actual-expected)<=relative*std::max(std::abs(expected),1e-300),label);
}
void rejects(const std::function<void()>& fn,const std::string& label) {
    bool threw=false;try {fn();} catch (const std::exception&) {threw=true;}check(threw,label);
}
}
int main(int argc,char** argv) {try {
#ifndef RAIKOU_TEST_H2O_DATASET
#define RAIKOU_TEST_H2O_DATASET "data/collisions/h2o-gas-20261029.json"
#endif
    if (argc>2) throw std::invalid_argument("Need at most one dataset path");
    using namespace raikou::kinetics;
    const auto data=StrictCollisionDataset::read(argc==2?argv[1]:RAIKOU_TEST_H2O_DATASET);
    // Independent source anchors: different units and sensitive small exponents.
    struct Anchor {const char* id;double energy,value;};
    const Anchor anchors[]={
        {"H2O:elastic_integral_song2021",.1,987.8e-20},
        {"H2O:elastic_momentum",.001,490e-20},
        {"H2O:elastic_momentum",1000,.0515e-20},
        {"H2O:effective_momentum",.001,39000e-20},
        {"H2O:effective_momentum",700,.093e-20},
        {"H2O:excite_v010",.26,2.15e-20},
        {"H2O:stretch_v100_plus_v001",.53,4.44e-20},
        {"H2O:excite_v100",.53,2.4864e-20},
        {"H2O:excite_v001",.53,1.9536e-20},
        {"H2O:electronic_A1B1",9,18.02e-22},
        {"H2O:electronic_A1B1",977.7,2.12e-22},
        {"H2O:neutral_OH_yield",75,1.44e-20},
        {"H2O:ion_yield:H2O+",100,1.31e-20},
        {"H2O:ion_yield:total",100,2.16e-20},
        {"H2O:ion_yield:O_atomic_2plus",90,8e-25},
        {"H2O:ion_yield:H2+",30,1.8e-24},
        {"H2O:attachment_yield:Hminus",6.5,4.61e-22},
        {"H2O:attachment_yield:Ominus",12,2.74e-23},
        {"H2O:attachment_yield:OHminus",6.5,5.50e-24}};
    for (const auto& a:anchors) close(data.observable_value_SI(a.id,a.energy),a.value,2e-14,a.id);
    constexpr double a0=5.29177210903e-11;
    close(data.observable_value_SI("H2O:munoz2007:elastic_integral",10000),.284*a0*a0,2e-14,"high-energy gas elastic anchor");
    close(data.observable_value_SI("H2O:munoz2007:inelastic_integral",10000),.436*a0*a0,2e-14,"high-energy gas inelastic anchor");
    close(data.observable_value_SI("H2O:munoz2007:measured_ionization",5000),.702*a0*a0,2e-14,"measured high-energy ion-current anchor");
    close(data.observable_value_SI("H2O:munoz2007:recommended_total",10000),.92*a0*a0,2e-14,"recommended total differs from optical total");
    close(data.observable_value_SI("H2O:elastic_momentum",.0015),455e-20,2e-14,"declared linear interpolation");
    check(data.observable_value_SI("H2O:excite_v010",.197)==0,"physical subthreshold zero");
    check(data.observable_value_SI("H2O:excite_v010",.198)==0,"threshold anchor");
    check(data.observable_value_SI("H2O:ion_yield:H2O+",12)==0,"below parent ionization threshold");
    rejects([&]{(void)data.observable_value_SI("H2O:ion_yield:H2O+",13);},"threshold-to-first table point cannot zero-fill");
    rejects([&]{(void)data.observable_value_SI("H2O:ion_yield:H+",17.5);},"blank ion cell is missing, not zero");
    rejects([&]{(void)data.observable_value_SI("H2O:elastic_momentum",8084.47);},"no high-energy momentum extrapolation");
    rejects([&]{(void)data.observable_value_SI("H2O:neutral_OH_yield",8084.47);},"no neutral dissociation endpoint hold");
    rejects([&]{(void)data.observable_value_SI("H2O:attachment_yield:Hminus",8084.47);},"no automatic high-energy attachment zero");
    rejects([&]{(void)data.observable_value_SI("H2O:nist_BEB_valence",10000.1);},"BEB nonrelativistic ceiling");
    rejects([&]{(void)data.observable_value_SI("H2O:elastic_momentum",-1);},"negative incident energy");
    rejects([&]{(void)data.observable_value_SI("H2O:elastic_momentum",std::numeric_limits<double>::quiet_NaN());},"NaN incident energy");
    check(data.observable_value_SI("H2O:nist_BEB_valence",12.61)==0,"BEB orbital threshold is12.61, not parent12.621");
    check(data.observable_value_SI("H2O:nist_BEB_valence",8084.47)>0,"analytic high-energy valence coverage");
    const std::vector<CollisionEnergyWeight> mixed{{30,1},{8084.47,9}};
    const auto evidence=data.coverage("H2O:neutral_OH_yield",mixed);
    check(!evidence.complete&&evidence.total_weight==10&&evidence.uncovered_weight==9,"physical-weight coverage");
    const auto single=data.strict_observable_rate_m3_s("H2O:neutral_OH_yield",{{30,1}});
    close(evidence.known_support_coefficient_m3_s,single/10,2e-14,"covered subset never renormalized");
    rejects([&]{(void)data.strict_observable_rate_m3_s("H2O:neutral_OH_yield",mixed);},"incomplete rate fails");
    check(data.coverage("H2O:nist_BEB_valence",mixed).complete,"BEB model covers full retained tail");
    rejects([&]{(void)data.coverage("H2O:munoz2007:stopping_energy_area",mixed);},"energy-area cannot be a cross-section rate");
    rejects([&]{(void)data.coverage("H2O:elastic_momentum",{{30,-1}});},"negative physical weight");
    rejects([&]{(void)data.coverage("H2O:elastic_momentum",{});},"empty population");
    data.require_exclusive_products("H2O:ion_yield:H2O+");++checks;
    for (const auto id:{"H2O:ion_yield:total","H2O:ion_yield:H+","H2O:ion_yield:O_atomic_2plus","H2O:nist_BEB_valence","H2O:neutral_OH_yield"})
        rejects([&]{(void)data.require_exclusive_products(id);},"yield/total cannot become exclusive event");
    rejects([&]{(void)data.require_MCC_event_kernel("H2O:ion_yield:H2O+");},"parent-ion table lacks secondary/internal/recoil kernel");
    check(data.kernel_status("H2O:ion_yield:H2O+","parent_ground_equal_pair_CM_v1").at("status")=="conditional_available","explicit conditional kernel status");
    data.require_MCC_event_kernel("H2O:ion_yield:H2O+","parent_ground_equal_pair_CM_v1",100);++checks;
    const auto processes=data.reduced_transport_processes(.001,100);
    check(processes.size()==2,"reduced model is only EMT plus bend");
    check(processes[0].kind==CollisionKind::Elastic&&processes[1].kind==CollisionKind::Excitation,"actual native process kinds");
    check(processes[1].threshold_ev==.198&&processes[1].product=="H2O_v010"&&processes[1].weight_ratio==0,"one-way state/energy convention");
    close(processes[0].mass_ratio,9.1093837139e-31/(18.0106*1.66053906660e-27),1e-14,"physical recoil mass ratio");
    rejects([&]{(void)data.reduced_transport_processes(.001,8084.47);},"limited reduced model not admitted for8keV population");
    for (int kind=0;kind<5;++kind) {
        auto broken=data.metadata();
        if (kind==0) broken["phase"]="liquid";
        if (kind==1) broken["channels"][0]["energy_eV"][1]=.1;
        if (kind==2) broken["channels"][0]["ordinate_scale_to_SI"]=-1;
        if (kind==3) broken["channels"].push_back(broken["channels"][0]);
        if (kind==4) broken["channels"][0]["outside_support"]="hold";
        rejects([&]{StrictCollisionDataset bad(broken);},"invalid/phase-confused data rejected");
    }
    // Check the authors' stated within10percent high-energy constancy. The
    // printed750eV row implies36.46eV, outside the separately quoted40+/-2eV
    // interval; preserve that source inconsistency, do not repair its numbers.
    for (double energy:{750.,1000.,1500.,2000.,3000.,4000.,5000.}) {
        const double mean=data.observable_value_SI("H2O:munoz2007:stopping_energy_area",energy)/
            data.observable_value_SI("H2O:munoz2007:recommended_inelastic",energy);
        check(mean>36&&mean<44,"mass-stopping units and stated10percent constancy");
    }
    const auto atom=data.observable_value_SI("H2O:munoz2007:rotational_integral_300K",200)/(a0*a0);
    check(std::abs(atom-2.39)<1e-12,"printed anomalous200eV value retained without repair");
    const CollisionMomentum beam{0,1,0};
    const double M=18.01528*1.66053906660e-27,me=9.1093837139e-31,c=299792458.,e=1.602176634e-19;
    const auto kinetic=[&](const CollisionMomentum& p,double mass) {double p2=0;for (double v:p)p2+=v*v;return p2/(mass*(std::sqrt(1+p2/(mass*mass*c*c))+1));};
    for (double energy:{13.5,20.,100.,1000.}) for (double weight:{.125,1.,32.}) {
        const CollisionMomentum axis{1/std::sqrt(3.),1/std::sqrt(3.),1/std::sqrt(3.)};
        const auto event=conditional_h2o_parent_products(data,"parent_ground_equal_pair_CM_v1",energy,weight,M,beam,axis);
        const double initial=energy*e,p0=std::sqrt(initial*(initial+2*me*c*c))/c;
        for (int d=0;d<3;++d) check(std::abs(event.primary_momentum_kg_m_s[d]+event.secondary_momentum_kg_m_s[d]+event.ion_momentum_kg_m_s[d]-p0*beam[d])<1e-13*p0,"conditional exact momentum closure");
        close(event.primary_kinetic_J,kinetic(event.primary_momentum_kg_m_s,me),2e-13,"primary on mass shell");
        close(event.secondary_kinetic_J,kinetic(event.secondary_momentum_kg_m_s,me),2e-13,"secondary on mass shell");
        close(event.ion_kinetic_J,kinetic(event.ion_momentum_kg_m_s,event.ion_mass_kg),2e-13,"ion on mass shell");
        close(event.primary_kinetic_J+event.secondary_kinetic_J+event.ion_kinetic_J+event.chemical_reference_gain_J,initial,2e-13,"conditional event energy closure");
        check(event.physical_weight_each==weight,"one parent/primary cohort weight retained for every product");
    }
    rejects([&]{(void)conditional_h2o_parent_products(data,"",100,1,M,beam,beam);},"no implicit conditional model activation");
    rejects([&]{(void)conditional_h2o_parent_products(data,"parent_ground_equal_pair_CM_v1",8084.47,1,M,beam,beam);},"conditional model does not bridge unsupported8keV parent data");
    std::cout<<"{\"passed\":true,\"checks\":"<<checks<<",\"physical_time_advanced\":0,\"GPU_used\":false}\n";return 0;
} catch(const std::exception& e) {std::cerr<<e.what()<<'\n';return 1;}}
