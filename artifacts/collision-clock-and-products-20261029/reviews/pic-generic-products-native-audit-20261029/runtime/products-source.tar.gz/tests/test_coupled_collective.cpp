#include "raikou/distributed.h"
#include "raikou/electron_coupling.h"
#include "raikou/runtime.h"
#include <cmath>
#include <iostream>
#include <stdexcept>
#include <string>

namespace {
using namespace raikou;
Json request(bool mpi){return {
    {"mechanism",{{"id","manufactured coupled preflight"},{"species",Json::array({
        {{"id","X"},{"elements",{{"N",1}}}},{{"id","e"},{"charge",-1}}})},{"reactions",Json::array()}}},
    {"state",{{"densities_m3",{{"X",1e20},{"e",1e8}}}}},{"initial_mean_energy_ev",1},
    {"field_magnitude_V_m",10},{"dt_s",1e-12},{"execution",{{"mpi",mpi}}},
    {"electron_closure",{{"grid",{{"cells",16},{"max_energy_ev",10},{"power",2},{"legendre_terms",2}}},
        {"processes",Json::array({{{"kind","elastic"},{"target","X"},{"label","elastic"},{"mass_ratio",1e-5},
            {"energy_ev",{0,1000}},{"cross_section_m2",{1e-19,1e-19}}}})}}}};}
template<class Action>void rejects(const backend::DistributedHalo& control,Action action){
    bool refused=false;try{action();}catch(const std::exception&){refused=true;}
    control.collective_require(refused?"":"asymmetric coupled input was accepted");
}
}
int main(int argc,char** argv){try{
    bool mpi=false;for(int i=1;i<argc;++i)mpi|=std::string(argv[i])=="--mpi";
    backend::Runtime runtime(mpi);backend::ExecutionOptions execution;execution.mpi=mpi;
    backend::DistributedHalo control(backend::distributed_partition(1,execution),{},execution);
    const auto input=request(mpi);const bool damaged_rank=control.rank()+1==control.ranks();
    const auto recover=[&]{const auto result=execute("coupled.advance",input);
        control.collective_require(result.at("nonlinear_residual").get<double>()<=1?"":"valid coupled JSON failed after rejection");};
    recover();
    for(int damage=0;damage<8;++damage){auto malformed=input;if(damaged_rank){
        if(damage==0)malformed["mechanism"]["species"][0].erase("id");
        if(damage==1)malformed["state"]["densities_m3"]="invalid state";
        if(damage==2)malformed["options"]["relative_tolerance"]=-1;
        if(damage==3)malformed["options"]["maximum_newton_iterations"]=0;
        if(damage==4)malformed["execution"]["device"]=99;
        if(damage==5)malformed["execution"]["preconditioner"]="unknown";
        if(damage==6)malformed["dt_s"]=-1;
        if(damage==7)malformed["electron_closure"]["targets"]["X"]="missing";
    }rejects(control,[&]{(void)execute("coupled.advance",malformed);});recover();}
    const auto mechanism=chemistry::Mechanism::from_json(input.at("mechanism"));
    chemistry::State state{{1e20,1e8}};chemistry::Environment environment;
    auto settings=input.at("electron_closure");settings["execution"]=input.at("execution");
    const auto coupling=kinetics::ElectronCoupling::from_json(settings);
    const auto electrons=kinetics::maxwellian_eedf(1e8,1,coupling.grid);
    const auto typed=[&](const chemistry::State& current,const kinetics::ElectronCoupling& closure,double dt,const kinetics::CoupledCellOptions& options){
        return kinetics::advance_coupled_cell(mechanism,current,environment,closure,electrons,10,dt,options);};
    for(int damage=0;damage<4;++damage){auto current=state;auto closure=coupling;kinetics::CoupledCellOptions options;double dt=1e-12;
        if(damaged_rank){if(damage==0)dt=-1;if(damage==1)current.densities_m3.pop_back();if(damage==2)options.maximum_newton_iterations=0;if(damage==3)closure.targets["X"]={"missing"};}
        rejects(control,[&]{(void)typed(current,closure,dt,options);});
        const auto result=typed(state,coupling,1e-12,{});control.collective_require(result.nonlinear_residual<=1?"":"typed coupled recovery failed");
    }
    if(control.ranks()>1){
        auto current=state;if(damaged_rank)current.densities_m3[0]*=2;
        rejects(control,[&]{(void)typed(current,coupling,1e-12,{});});
        kinetics::CoupledCellOptions options;if(damaged_rank)++options.maximum_newton_iterations;
        rejects(control,[&]{(void)typed(state,coupling,1e-12,options);});
        recover();
    }
    if(control.rank()==0)std::cout<<"coupled runtime/typed asymmetric preflight, shared-control agreement and recovery passed\n";
    return 0;
}catch(const std::exception& exception){std::cerr<<exception.what()<<'\n';return 1;}}
