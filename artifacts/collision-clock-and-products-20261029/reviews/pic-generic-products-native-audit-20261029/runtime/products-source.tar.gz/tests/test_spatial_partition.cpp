#include "raikou/spatial_partition.h"
#include <algorithm>
#include <cmath>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>

namespace {
using namespace raikou;
using namespace spatial::partition;
void check(bool value, const std::string& message) { if (!value) throw std::runtime_error(message); }
template<class Action> void collective(const backend::DistributedHalo& halo, Action&& action) {
    std::string error;
    try { action(); } catch (const std::exception& exception) { error = exception.what(); }
    halo.collective_require(error);
}
double exact(GlobalIndex id) { return 1 + .01 * static_cast<double>(id) + std::sin(.1 * static_cast<double>(id)); }
spatial::mesh::Geometry geometry(std::size_t cells) {
    spatial::Mesh mesh; mesh.shape = {cells, 1, 1}; mesh.extent_m = {1, .2, .1}; return spatial::mesh::geometry(mesh);
}
std::vector<unsigned char> dielectric_mask(const spatial::mesh::Geometry& g) {
    std::vector<unsigned char> mask(g.walls.size());
    for (std::size_t w = 0; w < g.walls.size(); ++w) mask[w] = static_cast<unsigned char>((g.walls[w].side == 2 && g.walls[w].cell % 3 == 0) || g.walls[w].side == 1);
    return mask;
}
void test_layout(const backend::ExecutionOptions& options) {
    const auto g = geometry(37); const auto mask = dielectric_mask(g);
    const DofLayout layout(g, 3, 2, 2, mask, true, options);
    const auto& control = layout.control_halo();
    collective(control, [&] {
        check(layout.components() == 8 && layout.phi_component() == 3 && layout.photon_component(1) == 5 && layout.thermal_component(1) == 7, "base component ordering");
        GlobalIndex next = 0;
        for (std::size_t c = 0; c < layout.cells(); ++c) {
            check(layout.cell_begin(c) == next, "cell blocks are consecutive");
            for (std::size_t component = 0; component < 8; ++component) check(layout.cell_dof(c, component) == next++, "cell base component ordering");
            for (std::size_t w = 0; w < g.walls.size(); ++w) if (mask[w] && g.walls[w].cell == c) {
                check(layout.sigma_dof(w) == next++ && layout.dielectric_dof(w) == next++, "wall pair follows its owning cell base block");
            }
            if (c + 1 == layout.cells()) check(layout.circuit_dof() == next++, "global circuit DOF belongs to final cell");
            check(layout.cell_end(c) == next, "variable block end includes walls/circuit");
        }
        check(next == layout.row_partition().global_rows, "global DOF count includes all variable blocks");
        const auto cells = layout.owned_cells(); const auto rows = layout.row_partition();
        if (cells.count > 0) check(rows.row_begin == layout.cell_begin(cells.begin) && rows.local_rows == layout.cell_end(cells.begin + cells.count - 1) - rows.row_begin, "row ownership follows complete cell blocks");
    });
    check(control.global_sum(static_cast<double>(layout.row_partition().local_rows)) == static_cast<double>(layout.row_partition().global_rows), "owned rows cover global layout once");
    const auto rank = static_cast<std::size_t>(control.rank()), ranks = static_cast<std::size_t>(control.ranks());
    const auto begin = 37 * rank * rank / (ranks * ranks), end = 37 * (rank + 1) * (rank + 1) / (ranks * ranks);
    const DofLayout custom(g, 3, 2, 2, mask, true, options, CellInterval{begin, end - begin});
    collective(control, [&] { check(custom.owned_cells().begin == begin && custom.owned_cells().count == end - begin, "custom rank-ordered cell intervals supported"); });
    bool rejected = false;
    try { (void)DofLayout(g, 3, 2, 2, mask, true, options, CellInterval{control.rank() == 0 ? 1u : layout.owned_cells().begin, layout.owned_cells().count}); }
    catch (const std::exception&) { rejected = true; }
    control.collective_require(rejected ? "" : "invalid custom intervals were not rejected collectively");
    if (control.ranks() > 1) {
        auto inconsistent = mask;
        if (control.rank() == 0) {
            const auto marked = std::find(inconsistent.begin(), inconsistent.end(), static_cast<unsigned char>(1));
            const auto unmarked = std::find(inconsistent.begin(), inconsistent.end(), static_cast<unsigned char>(0));
            *marked = 0; *unmarked = 1;
        }
        rejected = false;
        try { (void)DofLayout(g, 3, 2, 2, inconsistent, true, options); } catch (const std::exception&) { rejected = true; }
        control.collective_require(rejected ? "" : "equal-count but inconsistent wall mapping was not rejected collectively");
    }
}
void test_halo(const backend::ExecutionOptions& options) {
    const auto g = geometry(37); const auto mask = dielectric_mask(g);
    const DofLayout layout(g, 3, 2, 2, mask, true, options);
    std::vector<spatial::mesh::ScalarStencil> cell_stencils(37), face_stencils(g.faces.size()), wall_stencils(g.walls.size());
    std::vector<std::array<spatial::mesh::ScalarStencil, 3>> gradients(37);
    for (std::size_t c = 0; c < 37; ++c) {
        cell_stencils[c].cells = {{{(c + 4) % 37, 1}}};
        if (c + 2 < 37) gradients[c][0].cells = {{{c + 2, .5}}};
    }
    for (std::size_t f = 0; f < g.faces.size(); ++f) {
        const auto& face = g.faces[f];
        face_stencils[f].cells = {{face.a, -1}, {face.b, 1}};
        if (face.a > 0) face_stencils[f].cells.emplace_back(face.a - 1, .2);
        if (face.b + 1 < 37) face_stencils[f].cells.emplace_back(face.b + 1, -.2);
        // A symbolic wall in another reconstruction patch exercises remote
        // dielectric pair dependencies independently of direct face neighbors.
        for (std::size_t w = 0; w < g.walls.size(); ++w) if (mask[w] && g.walls[w].cell == (face.a + 3) % 37) { face_stencils[f].boundaries.emplace_back(w, 1); break; }
    }
    for (std::size_t w = 0; w < g.walls.size(); ++w) wall_stencils[w].cells = {{{(g.walls[w].cell + 5) % 37, 1}}};
    const std::vector<std::size_t> components{layout.phi_component()};
    const std::vector<GlobalIndex> extras{layout.circuit_dof(), layout.cell_dof(0, 0)};
    const StencilDependencies dependencies{cell_stencils, face_stencils, wall_stencils, gradients, components};
    const auto ids = requested_ghost_ids(layout, g, dependencies, extras);
    auto halo = layout.make_halo(ids);
    std::vector<double> local(layout.row_partition().local_rows);
    for (std::size_t i = 0; i < local.size(); ++i) local[i] = exact(layout.row_partition().row_begin + i);
    OwnedValues values(halo, std::move(local));
    collective(halo, [&] {
        check(std::is_sorted(ids.begin(), ids.end()) && std::adjacent_find(ids.begin(), ids.end()) == ids.end(), "ghost IDs are unique/sorted");
        if (!ids.empty()) {
            bool stale = false; try { (void)values.value(ids.front()); } catch (const std::logic_error&) { stale = true; }
            check(stale, "unexchanged ghost values cannot be read");
        }
    });
    values.exchange();
    collective(halo, [&] {
        for (auto id : ids) check(values.value(id) == exact(id), "halo value matches analytic global ID");
        const auto owned = layout.owned_cells();
        for (std::size_t c = owned.begin; c < owned.begin + owned.count; ++c) {
            check(values.value(layout.cell_dof((c + 4) % 37, layout.phi_component())) == exact(layout.cell_dof((c + 4) % 37, layout.phi_component())), "cell stencil ghosts include a non-face neighbor");
            if (c + 2 < 37) check(values.value(layout.cell_dof(c + 2, layout.phi_component())) == exact(layout.cell_dof(c + 2, layout.phi_component())), "gradient ghosts include the second ring");
        }
        for (std::size_t f = 0; f < g.faces.size(); ++f) if (layout.owns_cell(g.faces[f].a) || layout.owns_cell(g.faces[f].b)) {
            for (const auto& [cell, coefficient] : face_stencils[f].cells) {
                (void)coefficient;
                const auto id = layout.cell_dof(cell, layout.phi_component());
                check(values.value(id) == exact(id), "face patch includes every second-ring dependency");
            }
            for (const auto& [wall, coefficient] : face_stencils[f].boundaries) {
                (void)coefficient;
                check(values.value(layout.sigma_dof(wall)) == exact(layout.sigma_dof(wall)) && values.value(layout.dielectric_dof(wall)) == exact(layout.dielectric_dof(wall)), "symbolic wall dependency includes both dielectric unknowns");
            }
        }
        check(values.storage_entries() == layout.row_partition().local_rows + ids.size(), "persistent state stores only owned and requested ghost entries");
        check(values.exchange_working_entries_bound() == layout.row_partition().local_rows + 2 * ids.size() + halo.layout().send_local_indices.size(), "exchange peak storage bound includes only local/halo/send arrays");
        if (halo.ranks() > 1) check(values.storage_entries() < layout.row_partition().global_rows, "distributed state does not allocate a global vector");
    });
    auto mutable_values = values.local_values();
    for (double& value : mutable_values) value += 2;
    values.exchange();
    collective(halo, [&] { for (auto id : ids) check(values.value(id) == exact(id) + 2, "owned mutation is visible after halo refresh"); });
    bool rejected = false;
    std::vector<double> malformed(layout.row_partition().local_rows + (halo.rank() == 0 ? 1u : 0u));
    try { (void)OwnedValues(halo, std::move(malformed)); } catch (const std::exception&) { rejected = true; }
    halo.collective_require(rejected ? "" : "one-rank bad local value count did not fail collectively");
}
void test_local_assembly(const backend::ExecutionOptions& options) {
    const auto g = geometry(37); const DofLayout layout(g, 3, 2, 2, dielectric_mask(g), true, options);
    auto halo = layout.make_halo({}); LocalAssembly assembly(halo);
    const auto global = layout.row_partition().global_rows;
    // All ranks visit metadata-only contributions. Only their local rows are
    // retained; no global state, residual or CSR row array is constructed.
    for (GlobalIndex row = 0; row < global; ++row) {
        const auto previous = row == 0 ? global - 1 : row - 1, next = row + 1 == global ? 0 : row + 1;
        const double rhs = 4 * exact(row) - exact(previous) - exact(next);
        assembly.add_residual(row, .25 * rhs); assembly.add_residual(row, .75 * rhs);
        assembly.add_matrix(row, row, 2); assembly.add_matrix(row, row, 2);
        assembly.add_matrix(row, previous, -1); assembly.add_matrix(row, next, -1);
    }
    collective(halo, [&] {
        check(assembly.residual_storage_entries() == layout.row_partition().local_rows, "assembly residual is local only");
        check(assembly.matrix_storage_entries() == 3 * layout.row_partition().local_rows, "assembly stores only local CSR rows");
    });
    auto system = assembly.finish();
    backend::DistributedLinearOperator op(std::move(system.matrix), options);
    std::vector<double> local(layout.row_partition().local_rows);
    for (std::size_t i = 0; i < local.size(); ++i) local[i] = exact(layout.row_partition().row_begin + i);
    const auto applied = op.apply(local);
    collective(halo, [&] { for (std::size_t i = 0; i < local.size(); ++i) check(std::abs(applied[i] - system.residual[i]) < 2e-13, "local assembled operator matches manufactured residual"); });
    const auto solved = op.solve(system.residual);
    collective(halo, [&] {
        check(solved.converged, "distributed manufactured local assembly solve converged");
        for (std::size_t i = 0; i < local.size(); ++i) check(std::abs(solved.local_solution[i] - local[i]) < 2e-9, "rank-independent local block solution");
    });
    LocalAssembly invalid(halo);
    if (halo.rank() == 0) invalid.add_matrix(layout.row_partition().row_begin, 0, std::numeric_limits<double>::quiet_NaN());
    bool rejected = false; try { (void)invalid.finish(); } catch (const std::exception&) { rejected = true; }
    halo.collective_require(rejected ? "" : "one-rank assembly error was not propagated collectively");
}
void test_empty_ranks(const backend::ExecutionOptions& options) {
    const auto g = geometry(1); const DofLayout layout(g, 1, 0, 0, dielectric_mask(g), true, options);
    const std::vector<GlobalIndex> extras{layout.circuit_dof()};
    const auto ids = requested_ghost_ids(layout, g, {}, extras); auto halo = layout.make_halo(ids);
    OwnedValues values(halo); auto local = values.local_values();
    for (std::size_t i = 0; i < local.size(); ++i) local[i] = exact(layout.row_partition().row_begin + i);
    values.exchange();
    collective(halo, [&] {
        check(values.value(layout.circuit_dof()) == exact(layout.circuit_dof()), "empty ranks can request the circuit value");
        if (!layout.owned_cells().count) check(local.empty() && layout.row_partition().local_rows == 0, "empty cell ownership implies no owned variable blocks");
    });
    LocalAssembly assembly(halo); auto system = assembly.finish();
    collective(halo, [&] { check(system.residual.size() == layout.row_partition().local_rows && system.matrix.offsets.size() == system.residual.size() + 1, "empty local matrix retains valid CSR offsets"); });
}
} // namespace
int main(int argc, char** argv) {
    const bool mpi = argc > 1 && std::string(argv[1]) == "--mpi";
    try {
        backend::Runtime runtime(mpi); backend::ExecutionOptions options; options.mpi = mpi; options.tolerance = 1e-12;
        test_layout(options); test_halo(options); test_local_assembly(options); test_empty_ranks(options);
        if (backend::mpi_rank() == 0) std::cout << "spatial owned DOF layout, multipoint halos and local assembly passed\n";
        return 0;
    } catch (const std::exception& error) { std::cerr << "spatial partition: " << error.what() << '\n'; return 1; }
}
