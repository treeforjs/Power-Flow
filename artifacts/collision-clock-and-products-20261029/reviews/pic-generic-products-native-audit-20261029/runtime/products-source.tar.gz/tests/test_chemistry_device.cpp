#include "raikou/chemistry_device.h"
#include "raikou/runtime.h"
#include "chemistry_audit_cases.h"
#include <algorithm>
#include <cmath>
#include <iostream>
#include <limits>
#include <stdexcept>

namespace {
using namespace raikou::chemistry;
void check(bool ok,const std::string& message){if(!ok)throw std::runtime_error(message);}
void near(double actual,double expected,double relative,const std::string& message){
    check(std::isfinite(actual)&&std::abs(actual-expected)<=relative*std::max({1e-30,std::abs(actual),std::abs(expected)}),message);
}
Mechanism isomer(){
    Mechanism m;m.id="manufactured_cuda_isomer";m.status="manufactured";
    Species a;a.id="A";a.elements={{"N",1}};a.mass_kg=14.007*1.66053906892e-27;Species b=a;b.id="B";m.species={a,b};
    Reaction r;r.id="forward";r.reactants={{0,1}};r.products={{1,1}};r.rate.A=2;
    r.energy_eV_per_event={{"electron",-3},{"heavy",1},{"gas/heavy",2}};r.check_energy_balance=true;m.reactions={r};return m;
}
void compare(const Evaluation& gpu,const Evaluation& cpu){
    for(std::size_t i=0;i<cpu.production_rates_m3_s.size();++i)near(gpu.production_rates_m3_s[i],cpu.production_rates_m3_s[i],2e-13,"source parity");
    for(std::size_t i=0;i<cpu.jacobian_row_major.size();++i)near(gpu.jacobian_row_major[i],cpu.jacobian_row_major[i],2e-13,"Jacobian parity");
    for(std::size_t i=0;i<cpu.reaction_rates_m3_s.size();++i)near(gpu.reaction_rates_m3_s[i],cpu.reaction_rates_m3_s[i],2e-13,"rate parity");
    for(const auto& [key,value]:cpu.energy_sources_W_m3)near(gpu.energy_sources_W_m3.at(key),value,2e-13,"energy source parity");
}
void evaluation(){
    auto m=isomer();Environment e;e.gas_temperature_K=500;e.electron_temperature_eV=2;e.parameters["rate"]=7;e.electron_rates["impact"]=9;
    std::vector<State> states{{{0,0}},{{2,0}},{{1e8,2e8}}};
    const std::vector<Environment> environments{e};
    for(const auto kind:{RateKind::Constant,RateKind::Arrhenius,RateKind::ElectronTemperatureTable,RateKind::ElectronEedf,RateKind::Expression,RateKind::Parameter}){
        auto& law=m.reactions[0].rate;law.kind=kind;law.A=2;law.exponent=0.5;law.activation_temperature_K=120;
        law.reference_temperature_K=300;law.temperatures_eV={1,3};law.coefficients={2,6};law.key=kind==RateKind::ElectronEedf?"impact":"rate";
        law.expression="scale * exp(-120 / Tgas_K) + Te_eV";law.constants={{"scale",2}};
        const auto batch=evaluate_cuda_batch(m,states,environments);
        for(std::size_t c=0;c<states.size();++c)compare(batch.cells[c],evaluate(m,states[c],e));
    }
    m=isomer();m.reactions[0].explicit_orders=true;
    for(double power:{0.,1.,1.5,2.}){
        m.reactions[0].orders={{0,power},{1,0}};
        const auto batch=evaluate_cuda_batch(m,states,environments);
        for(std::size_t c=0;c<states.size();++c)compare(batch.cells[c],evaluate(m,states[c],e));
    }
    m=isomer();m.species[1].phase="aqueous";m.reactions[0].basis_interface="surface";
    m.reactions[0].energy_eV_per_event={{"gas/electron",-3},{"aqueous/heavy",3}};
    e.phase_volumes_m3={{"gas",2},{"aqueous",5}};e.interface_areas_m2={{"surface",0.25}};
    const auto result=evaluate_cuda_batch(m,states,std::vector<Environment>{e});
    for(std::size_t c=0;c<states.size();++c)compare(result.cells[c],evaluate(m,states[c],e));
    auto missing=e;missing.phase_volumes_m3.erase("aqueous");bool rejected=false;
    try{static_cast<void>(evaluate_cuda_batch(m,states,std::vector<Environment>{missing}));}
    catch(const std::invalid_argument&){rejected=true;}
    check(rejected,"missing cross-phase volume was silently defaulted");
    auto request=raikou::Json{{"mechanism",m.to_json()},{"state",{{"densities_m3",{{"A",2.},{"B",0.}}}}},
        {"environment",{{"phase_volumes_m3",e.phase_volumes_m3},{"interface_areas_m2",e.interface_areas_m2}}},{"execution",{{"device","cuda"}}}};
    check(raikou::execute("chemistry.evaluate",request).at("production_rates_m3_s").at("B").get<double>()>0,"runtime CUDA evaluate");
    // Geometry conversion must precede reaction progress multiplication, as in
    // the CPU kernel: a large equal volume ratio cannot overflow a finite source.
    m=isomer();m.reactions[0].rate.A=1e200;m.reactions[0].energy_eV_per_event.clear();m.reactions[0].check_energy_balance=false;
    e=Environment{};e.phase_volumes_m3["gas"]=1e200;
    const State finite{{1,0}};
    compare(evaluate_cuda_batch(m,std::vector<State>{finite},std::vector<Environment>{e}).cells[0],evaluate(m,finite,e));
}
void integration(){
    auto m=isomer();m.reactions[0].rate.kind=RateKind::Parameter;m.reactions[0].rate.key="rate";
    std::vector<State> states;std::vector<Environment> environments;
    for(int i=0;i<16;++i){states.push_back({{1.+i,0.}});Environment e;e.parameters["rate"]=1.+i;environments.push_back(e);}
    AdvanceOptions options;options.relative_tolerance=2e-4;options.absolute_tolerance_m3=1e-9;
    const auto batch=advance_cuda_batch(m,states,environments,0.05,options);
    std::size_t attempts=0;
    for(std::size_t c=0;c<states.size();++c){const auto& gpu=batch.cells[c];check(gpu.success,gpu.message);
        const auto cpu=advance(m,states[c],environments[c],0.05,options);check(cpu.success,cpu.message);
        for(std::size_t i=0;i<2;++i)near(gpu.state.densities_m3[i],cpu.state.densities_m3[i],2e-8,"integrated CPU/GPU parity");
        near(gpu.state.densities_m3[0]+gpu.state.densities_m3[1],states[c].densities_m3[0],1e-13,"inventory conservation");
        near(gpu.integrated_energy_J_m3.at("gas/heavy"),(states[c].densities_m3[0]-gpu.state.densities_m3[0])*3*1.602176634e-19,1e-12,"event energy ledger");
        attempts=std::max(attempts,gpu.accepted_steps+gpu.rejected_steps);
    }
    // One final state/status read, one initial validation read, and one scalar per adaptive launch.
    const auto limit=states.size()*(4*sizeof(double)+2*sizeof(std::size_t)+3*sizeof(double)+2*sizeof(int))+4*(attempts+2);
    check(batch.transfers.device_to_host_bytes<=limit,"adaptive chemistry copied bulk state during integration");
    options.execution.device="cuda";const auto single=advance(m,states[0],environments[0],0.05,options);
    check(single.success&&single.message=="completed on CUDA","standard advance did not dispatch to resident chemistry");
    // Failed cells must roll back independently of successful neighbors.
    m=isomer();m.reactions[0].rate.A=1e200;m.reactions[0].explicit_orders=true;m.reactions[0].orders={{0,2}};
    states={{{1e200,0}},{{0,0}}};environments={Environment{}};options.maximum_steps=10;
    const auto mixed=advance_cuda_batch(m,states,environments,1e-4,options);
    check(!mixed.cells[0].success&&mixed.cells[0].state.densities_m3==states[0].densities_m3&&mixed.cells[0].integrated_energy_J_m3.empty(),"overflow cell rollback");
    check(mixed.cells[1].success,"invalid cell cancelled valid neighbor");
    m=isomer();options.maximum_steps=1;const auto budget=advance_cuda_batch(m,std::vector<State>{{{1,0}}},environments,1,options);
    check(!budget.cells[0].success&&budget.cells[0].advanced_time_s==0&&budget.cells[0].state.densities_m3[0]==1,"budget rollback");
    m.reactions.clear();options.maximum_steps=10;options.nonnegative={false,true};
    const auto signed_state=advance_cuda_batch(m,std::vector<State>{{{-1,0}}},environments,1,options);
    check(signed_state.cells[0].success&&signed_state.cells[0].state.densities_m3[0]==-1,"positivity override");
    // A nonlinear reversible dimer needs off-diagonal Newton updates and
    // preserves atom count across species with different molecularity.
    m=isomer();m.species[1].elements={{"N",2}};m.species[1].mass_kg*=2;
    m.reactions[0].reactants={{0,2}};m.reactions[0].rate.A=5e3;
    auto reverse=m.reactions[0];reverse.id="reverse";reverse.reactants={{1,1}};reverse.products={{0,2}};reverse.rate.A=2e2;
    for(auto& [name,value]:reverse.energy_eV_per_event){(void)name;value=-value;}
    m.reactions.push_back(reverse);options.relative_tolerance=5e-5;options.maximum_steps=10000;options.nonnegative.clear();
    const State initial{{1,0}};options.execution.device="cpu";const auto cpu=advance(m,initial,Environment{},0.002,options);
    options.execution.device="cuda";const auto gpu=advance(m,initial,Environment{},0.002,options);
    check(cpu.success&&gpu.success,"nonlinear stiff dimer failed: "+gpu.message);
    near(gpu.state.densities_m3[0],cpu.state.densities_m3[0],2e-7,"nonlinear dimer CPU/GPU parity");
    near(gpu.state.densities_m3[0]+2*gpu.state.densities_m3[1],1,2e-13,"nonlinear atom conservation");
}
}
int main(){
    if(!raikou::backend::cuda_available())return 77;
    try{
        chemistry_audit::minimum_steps([](const Mechanism& mechanism,const State& state,double interval,const AdvanceOptions& options){
            return advance_cuda_batch(mechanism,std::span<const State>(&state,1),std::vector<Environment>{{}},interval,options).cells.front();
        });
        chemistry_audit::geometry([](const Mechanism& mechanism,const State& state,const Environment& environment){
            return evaluate_cuda_batch(mechanism,std::span<const State>(&state,1),std::span<const Environment>(&environment,1)).cells.front();
        });
        evaluation();integration();std::cout<<"CUDA chemistry rates, Jacobians, implicit batches, rollback and residency passed\n";
    }
    catch(const std::exception& error){std::cerr<<error.what()<<'\n';return 1;}
}
