"""Binding and CLI integration tests; run against a built native library."""

from __future__ import annotations

from dataclasses import asdict
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "python"))

import raikou


class PythonBindings(unittest.TestCase):
    def cli(self, *args, input=None, env=None):
        effective_env = os.environ.copy()
        effective_env["PYTHONPATH"] = str(Path(__file__).resolve().parents[1] / "python")
        if env:
            effective_env.update(env)
        return subprocess.run(
            [sys.executable, "-m", "raikou", *args], input=input,
            capture_output=True, text=True, env=effective_env, check=False,
        )

    def native_cli(self, *args):
        from raikou._native import _library
        library_path = Path(_library()._name)
        executable = library_path.parent / ("raikou.exe" if os.name == "nt" else "raikou")
        if not executable.is_file():
            self.skipTest("Native CLI was not built alongside the shared library")
        result = subprocess.run([str(executable), *args], capture_output=True, text=True, check=True)
        return json.loads(result.stdout)

    def assert_json_close(self, actual, expected):
        if isinstance(expected, dict):
            self.assertEqual(actual.keys(), expected.keys())
            for key in expected:
                self.assert_json_close(actual[key], expected[key])
        elif isinstance(expected, list):
            self.assertEqual(len(actual), len(expected))
            for left, right in zip(actual, expected):
                self.assert_json_close(left, right)
        elif isinstance(expected, (int, float)) and not isinstance(expected, bool):
            self.assertTrue(math.isclose(actual, expected, rel_tol=2e-14, abs_tol=1e-290), (actual, expected))
        else:
            self.assertEqual(actual, expected)

    def test_version_and_default_state_match_native(self):
        self.assertEqual(raikou.native_version(), raikou.__version__)
        self.assertEqual(raikou.evaluate(), raikou.evaluate(raikou.PlasmaState()))
        self.assert_json_close(raikou.evaluate(), self.native_cli("evaluate"))

    def test_mapping_and_keyword_overrides_are_not_mutated(self):
        state = {"Te_eV": 4.0, "nH_ground_m3": 2e20}
        original = state.copy()
        actual = raikou.evaluate(state, path_length_m=0.0)
        self.assertEqual(state, original)
        self.assertEqual(actual["populations_m3"][0], 2e20)
        self.assertEqual(actual["lyman_alpha_radiance_W_m2_sr"], 0.0)
        self.assertEqual(actual["molecular_lyman_proxy_W_m2_sr"], 0.0)
        self.assertEqual(len(actual["populations_m3"]), 5)
        json.dumps(actual, allow_nan=False)

    def test_rate_matrices_and_native_parity(self):
        result = raikou.rates(4.0)
        self.assert_json_close(result, self.native_cli("rates", "--te-ev", "4"))
        for i in range(5):
            for j in range(5):
                self.assertEqual(result["excitation_m3_s"][i][j] > 0.0, i < j)
                self.assertEqual(result["deexcitation_m3_s"][i][j] > 0.0, i > j)
        self.assertEqual(len(result["three_body_recombination_m6_s"]), 5)

    def test_fit_struct_and_native_parity(self):
        synthetic = raikou.evaluate()
        la = synthetic["lyman_alpha_radiance_W_m2_sr"]
        mol = synthetic["molecular_lyman_proxy_W_m2_sr"]
        actual = raikou.fit_vuv_shot(la, la * 0.08, mol, mol * 0.08)
        self.assertIsInstance(actual["converged"], bool)
        self.assertIsInstance(actual["iterations"], int)
        self.assertGreater(actual["iterations"], 0)
        self.assert_json_close(actual, self.native_cli(
            "fit", "--ly-alpha", repr(la), "--ly-alpha-sigma", repr(la * 0.08),
            "--molecular", repr(mol), "--molecular-sigma", repr(mol * 0.08),
        ))
        self.assertEqual(actual, raikou.fit_vuv_shot(la, la * 0.08, mol, mol * 0.08, priors=raikou.FitPriors()))

    def test_spark_round_trip_and_native_parity(self):
        state = raikou.SparkState()
        original = asdict(state)
        result = raikou.step_spark_discharge(state, 1e-8, raikou.SparkConfig())
        self.assertEqual(asdict(state), original)
        self.assert_json_close(result, self.native_cli("spark", "--dt", "1e-8"))
        next_state = raikou.step_spark_discharge(result, 1e-8)
        self.assertAlmostEqual(next_state["time_s"], 2e-8)
        self.assertGreater(next_state["deposited_energy_J"], result["deposited_energy_J"])

    def test_invalid_inputs_propagate_without_crashing(self):
        for bad in (-1.0, float("nan"), float("inf")):
            with self.subTest(bad=bad), self.assertRaises(ValueError):
                raikou.evaluate(Te_eV=bad)
        with self.assertRaises(ValueError):
            raikou.step_spark_discharge(dt_s=-1.0)
        with self.assertRaises(ValueError):
            raikou.fit_vuv_shot(1.0, 0.0, 1.0, 0.1)
        with self.assertRaises(TypeError):
            raikou.evaluate(unknown_field=1.0)
        with self.assertRaises(TypeError):
            raikou.evaluate([1.0])
        self.assertGreater(raikou.evaluate()["escape_factor_lyman_alpha"], 0.0)

    def test_python_cli_stdin_matches_api(self):
        result = self.cli("evaluate", "--input", "-", input='{"Te_eV":4.0,"nH2_m3":1e20}')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout), raikou.evaluate(Te_eV=4.0, nH2_m3=1e20))

    def test_python_cli_file_and_spark_alias(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "input.json"
            path.write_text('{"Te_eV":3.0}', encoding="utf-8")
            result = self.cli("rates", "--input", str(path), "--pretty")
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout), raikou.rates(3.0))
        result = self.cli("spark", "--input", "-", input='{"dt_s":2e-8}')
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout), raikou.step_spark_discharge(dt_s=2e-8))

    def test_python_cli_rejects_bad_input(self):
        for payload in ("[]", "{", '{"Te_eV":NaN}', '{"ne_m3":-1}', '{"unknown":1}'):
            with self.subTest(payload=payload):
                result = self.cli("evaluate", "--input", "-", input=payload)
                self.assertEqual(result.returncode, 2)
                self.assertEqual(result.stdout, "")
                self.assertIn("raikou:", result.stderr)
                self.assertNotIn("Traceback", result.stderr)
        for command, payload in (("rates", '{"Te_eV":"bad"}'), ("step", '{"dt_s":{}}')):
            with self.subTest(command=command):
                result = self.cli(command, "--input", "-", input=payload)
                self.assertEqual(result.returncode, 2)
                self.assertNotIn("Traceback", result.stderr)

    def test_missing_explicit_library_does_not_silently_fallback(self):
        bad = str(Path(tempfile.gettempdir()) / "missing-raikou-python-test" / "library")
        result = self.cli("evaluate", env={"RAIKOU_LIBRARY": bad})
        self.assertEqual(result.returncode, 2)
        self.assertIn("RAIKOU_LIBRARY", result.stderr)
        self.assertIn(bad, result.stderr)
        help_result = self.cli("--help", env={"RAIKOU_LIBRARY": bad})
        self.assertEqual(help_result.returncode, 0)


if __name__ == "__main__":
    unittest.main()
