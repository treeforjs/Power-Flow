"""Regenerate the transparent, deliberately incomplete research mechanisms.

This is a development utility, not a runtime dependency. Missing coefficients
remain explicit inputs. No LXCat tables or guessed physical coefficients are
embedded. Manufactured examples are written to a separate directory.
"""
from copy import deepcopy
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
AVOGADRO = 6.02214076e23
WATER_REVIEW = "https://doi.org/10.1063/5.0035315"
WATER_SWARM = "https://doi.org/10.1088/1361-6463/accaf4"
AIR_MODEL = "https://doi.org/10.1021/acs.jpca.4c03323"
HUMID_MODEL = "https://doi.org/10.1515/phys-2018-0051"
G4_SOURCE = "https://raw.githubusercontent.com/Geant4/geant4/v11.0.0/source/physics_lists/constructors/electromagnetic/src/G4EmDNAChemistry_option2.cc"
INTERFACE = "https://doi.org/10.1038/ncomms8248"


def species(name, elements, charge=0, phase="gas"):
    return dict(id=name, elements=elements, charge=charge, phase=phase)


def pack(name, species_list, reactions, sources, families, missing):
    return dict(schema_version=1, id=name, status="research", species=species_list,
                reactions=reactions,
                provenance=[dict(url=url, use="reaction-family reference; no cross-section tables redistributed") for url in sources],
                coverage=dict(included_families=families, missing_physics=missing,
                              validity="Research scaffold. Each supplied rate and cross-section set defines its own validity; no all-regime or experimental-validation claim.",
                              rates="Unspecified coefficients are required named inputs, never zero fallbacks.",
                              energy="Event energy partitions are incomplete; use coverage.unchecked_energy_reactions before coupling energy equations."))


def reaction(name, reactants, products, rate, source, **extra):
    return dict(id=name, reactants=reactants, products=products, rate=rate,
                source=source, status="research", **extra)


def electron(name, reactants, products, source):
    return reaction(name, reactants, products, dict(type="electron_eedf", key=name),
                    source, collision_label=name)


def parameter(name, reactants, products, source, **extra):
    return reaction(name, reactants, products, dict(type="parameter", key=name), source, **extra)


def combine(name, *packs):
    result = deepcopy(packs[0])
    result["id"] = name
    for addition in packs[1:]:
        existing = {item["id"]: item for item in result["species"]}
        for item in addition["species"]:
            if item["id"] in existing:
                if existing[item["id"]] != item:
                    raise ValueError("Conflicting species " + item["id"])
            else:
                result["species"].append(deepcopy(item))
        reaction_names = {item["id"] for item in result["reactions"]}
        result["reactions"].extend(deepcopy(item) for item in addition["reactions"] if item["id"] not in reaction_names)
        result["provenance"].extend(deepcopy(item) for item in addition["provenance"] if item not in result["provenance"])
        for key in ("included_families", "missing_physics"):
            result["coverage"][key].extend(item for item in addition["coverage"][key] if item not in result["coverage"][key])
    return result


def nitrogen():
    sp = [species("e_g", {}, -1), species("N2", {"N": 2}), species("N", {"N": 1}),
          species("N_D", {"N": 1}), species("N_P", {"N": 1}), species("N2p", {"N": 2}, 1),
          species("Np", {"N": 1}, 1), species("N4p", {"N": 4}, 1)]
    sp += [species("N2_" + state, {"N": 2}) for state in ("A", "B", "C")]
    sp += [species("N2_v" + str(v), {"N": 2}) for v in range(1, 11)]
    rx = [electron("N2:ionization", {"e_g": 1, "N2": 1}, {"e_g": 2, "N2p": 1}, AIR_MODEL),
          electron("N2:dissociation", {"e_g": 1, "N2": 1}, {"e_g": 1, "N": 2}, AIR_MODEL),
          electron("N:ionization", {"e_g": 1, "N": 1}, {"e_g": 2, "Np": 1}, AIR_MODEL),
          parameter("N2p:dissociative_recombination_unresolved_products", {"N2p": 1, "e_g": 1}, {"N": 2}, AIR_MODEL),
          parameter("N2p:cluster_N4p", {"N2p": 1, "N2": 2}, {"N4p": 1, "N2": 1}, AIR_MODEL),
          parameter("N4p:recombination", {"N4p": 1, "e_g": 1}, {"N2": 2}, AIR_MODEL)]
    for state in ("A", "B", "C"):
        excited = "N2_" + state
        rx += [electron("N2:excite_" + state, {"e_g": 1, "N2": 1}, {"e_g": 1, excited: 1}, AIR_MODEL),
               parameter("N2_" + state + ":quench_N2", {excited: 1, "N2": 1}, {"N2": 2}, AIR_MODEL)]
    for v in range(1, 11):
        excited = "N2_v" + str(v)
        rx += [electron("N2:excite_v" + str(v), {"e_g": 1, "N2": 1}, {"e_g": 1, excited: 1}, AIR_MODEL),
               parameter("N2:v" + str(v) + "_VT_N2", {excited: 1, "N2": 1}, {"N2": 2}, AIR_MODEL)]
    return pack("n2_research", sp, rx, [AIR_MODEL],
                ["N2 electron impact", "N2 v=1..10 and A/B/C populations", "provisional quenching, clustering and recombination channels"],
                ["No bundled electron cross sections or heavy-particle coefficients", "No N2 vibrational ladder above v=10", "No complete V-V/state-to-state or superelastic network", "N recombination product states unresolved", "Not thermodynamically closed"])


def oxygen():
    sp = [species("e_g", {}, -1), species("O2", {"O": 2}), species("O", {"O": 1}),
          species("O_D", {"O": 1}), species("O_S", {"O": 1}), species("O3", {"O": 3}),
          species("O2_a", {"O": 2}), species("O2_b", {"O": 2}), species("O2p", {"O": 2}, 1),
          species("Op", {"O": 1}, 1), species("Om", {"O": 1}, -1), species("O2m", {"O": 2}, -1),
          species("O4p", {"O": 4}, 1)]
    sp += [species("O2_v" + str(v), {"O": 2}) for v in range(1, 5)]
    rx = [electron("O2:ionization", {"e_g": 1, "O2": 1}, {"e_g": 2, "O2p": 1}, AIR_MODEL),
          electron("O2:dissociation", {"e_g": 1, "O2": 1}, {"e_g": 1, "O": 2}, AIR_MODEL),
          electron("O2:dissociative_attachment", {"e_g": 1, "O2": 1}, {"Om": 1, "O": 1}, AIR_MODEL),
          parameter("Om:detachment_O", {"Om": 1, "O": 1}, {"O2": 1, "e_g": 1}, AIR_MODEL),
          parameter("O2p:recombination_unresolved_products", {"O2p": 1, "e_g": 1}, {"O": 2}, AIR_MODEL),
          parameter("O:ozone_O2_third_body", {"O": 1, "O2": 2}, {"O3": 1, "O2": 1}, AIR_MODEL)]
    for state in ("a", "b"):
        name = "O2_" + state
        rx += [electron("O2:excite_" + state, {"e_g": 1, "O2": 1}, {"e_g": 1, name: 1}, AIR_MODEL),
               parameter(name + ":quench_O2", {name: 1, "O2": 1}, {"O2": 2}, AIR_MODEL)]
    for v in range(1, 5):
        name = "O2_v" + str(v)
        rx += [electron("O2:excite_v" + str(v), {"e_g": 1, "O2": 1}, {"e_g": 1, name: 1}, AIR_MODEL),
               parameter(name + ":VT_O2", {name: 1, "O2": 1}, {"O2": 2}, AIR_MODEL)]
    return pack("o2_research", sp, rx, [AIR_MODEL],
                ["oxygen excitation and evolving negative ions", "provisional oxygen radical, ozone and recombination channels"],
                ["No bundled cross sections or numerical heavy-particle coefficients", "Incomplete detachment, cluster and ion-conversion network", "Unresolved O recombination product states", "Not thermodynamically closed"])


def water():
    definitions = [("H2O", {"H": 2, "O": 1}, 0), ("H2O_v010", {"H": 2, "O": 1}, 0),
                   ("H2O_v100", {"H": 2, "O": 1}, 0), ("H", {"H": 1}, 0), ("H2", {"H": 2}, 0),
                   ("OH", {"H": 1, "O": 1}, 0), ("OH_A", {"H": 1, "O": 1}, 0),
                   ("HO2", {"H": 1, "O": 2}, 0), ("H2O2", {"H": 2, "O": 2}, 0),
                   ("H2Op", {"H": 2, "O": 1}, 1), ("H3Op", {"H": 3, "O": 1}, 1),
                   ("OHp", {"H": 1, "O": 1}, 1), ("Hp", {"H": 1}, 1), ("H2p", {"H": 2}, 1),
                   ("Hm", {"H": 1}, -1), ("OHm", {"H": 1, "O": 1}, -1)]
    sp = [species("e_g", {}, -1), species("O", {"O": 1}), species("Om", {"O": 1}, -1)] + [species(*item) for item in definitions]
    rx = [electron("H2O:ionization", {"e_g": 1, "H2O": 1}, {"e_g": 2, "H2Op": 1}, WATER_REVIEW),
          electron("H2O:dissociation_OH_H", {"e_g": 1, "H2O": 1}, {"e_g": 1, "OH": 1, "H": 1}, WATER_REVIEW),
          electron("H2O:dissociative_excitation_OHA", {"e_g": 1, "H2O": 1}, {"e_g": 1, "OH_A": 1, "H": 1}, WATER_REVIEW),
          electron("H2O:attachment_Hminus", {"e_g": 1, "H2O": 1}, {"Hm": 1, "OH": 1}, WATER_REVIEW),
          electron("H2O:attachment_Ominus", {"e_g": 1, "H2O": 1}, {"Om": 1, "H2": 1}, WATER_REVIEW),
          electron("H2O:attachment_OHminus", {"e_g": 1, "H2O": 1}, {"OHm": 1, "H": 1}, WATER_REVIEW),
          parameter("H2Op:proton_transfer_water", {"H2Op": 1, "H2O": 1}, {"H3Op": 1, "OH": 1}, "https://doi.org/10.1088/0022-3727/43/31/315201"),
          parameter("H3Op:dissociative_recombination", {"H3Op": 1, "e_g": 1}, {"OH": 1, "H": 2}, "https://doi.org/10.1088/0022-3727/43/31/315201"),
          parameter("OH:recombine_water_third_body", {"OH": 2, "H2O": 1}, {"H2O2": 1, "H2O": 1}, WATER_REVIEW),
          parameter("H_OH:recombine_water_third_body", {"H": 1, "OH": 1, "H2O": 1}, {"H2O": 2}, WATER_REVIEW),
          parameter("H2_O:exchange", {"H2": 1, "O": 1}, {"OH": 1, "H": 1}, WATER_REVIEW)]
    for state in ("v010", "v100"):
        rx.append(electron("H2O:excite_" + state, {"e_g": 1, "H2O": 1}, {"e_g": 1, "H2O_" + state: 1}, WATER_SWARM))
    return pack("h2o_research", sp, rx, [WATER_REVIEW, WATER_SWARM],
                ["evolving water dissociation and positive/negative ions", "hydronium proton transfer", "provisional radical recombination"],
                ["No bundled cross sections or numeric heavy rates", "Incomplete rotational and vibrational populations", "No hydrated gas cluster ladder", "Incomplete excited H/O states", "Not liquid breakdown physics", "Not thermodynamically closed"])


def air_bridges():
    sp = [species("N", {"N": 1}), species("N2", {"N": 2}), species("O", {"O": 1}), species("O2", {"O": 2}),
          species("NO", {"N": 1, "O": 1}), species("NO2", {"N": 1, "O": 2}),
          species("N2O", {"N": 2, "O": 1}), species("NO3", {"N": 1, "O": 3}),
          species("N2O5", {"N": 2, "O": 5}), species("NOp", {"N": 1, "O": 1}, 1)]
    rx = [parameter("N_O2:make_NO", {"N": 1, "O2": 1}, {"NO": 1, "O": 1}, AIR_MODEL),
          parameter("N_NO:destroy_NO", {"N": 1, "NO": 1}, {"N2": 1, "O": 1}, AIR_MODEL),
          parameter("O_NO:make_NO2_N2_third_body", {"O": 1, "NO": 1, "N2": 1}, {"NO2": 1, "N2": 1}, AIR_MODEL)]
    return pack("n_o_bridges", sp, rx, [AIR_MODEL], ["minimal N/O mixture exchange"],
                ["Only three bridge channels; full NOx kinetics requires additional sourced reactions"])


def humid_bridges():
    sp = [species("N", {"N": 1}), species("OH", {"H": 1, "O": 1}), species("H", {"H": 1}),
          species("NO", {"N": 1, "O": 1}), species("NO2", {"N": 1, "O": 2}),
          species("HNO2", {"H": 1, "N": 1, "O": 2}), species("HNO3", {"H": 1, "N": 1, "O": 3}),
          species("N2", {"N": 2})]
    rx = [parameter("N_OH:make_NO", {"N": 1, "OH": 1}, {"NO": 1, "H": 1}, HUMID_MODEL),
          parameter("H_NO2:exchange", {"H": 1, "NO2": 1}, {"OH": 1, "NO": 1}, HUMID_MODEL),
          parameter("OH_NO2:HNO3_N2_third_body", {"OH": 1, "NO2": 1, "N2": 1}, {"HNO3": 1, "N2": 1}, HUMID_MODEL)]
    return pack("n_o_h_bridges", sp, rx, [HUMID_MODEL], ["minimal H/O/N radical and acid formation bridges"],
                ["Only three humidity bridge channels; not a complete plasma-activated-water mechanism"])


def aqueous_reference():
    definitions = [("e_aq", {}, -1), ("H2O_aq", {"H": 2, "O": 1}, 0), ("H_aq", {"H": 1}, 0),
                   ("OH_aq", {"H": 1, "O": 1}, 0), ("OHm_aq", {"H": 1, "O": 1}, -1),
                   ("H3Op_aq", {"H": 3, "O": 1}, 1), ("H2O2_aq", {"H": 2, "O": 2}, 0)]
    sp = [species(name, elements, charge, "aqueous") for name, elements, charge in definitions]
    # Four unlike-reactant scalar coefficients; no stochastic identical-pair
    # convention is imported. Source uses L/(mol s); divide by 1000*N_A.
    entries = [
        ("aq:e_OH", {"e_aq": 1, "OH_aq": 1}, {"OHm_aq": 1}, 2.95e10),
        ("aq:e_H3O", {"e_aq": 1, "H3Op_aq": 1}, {"H_aq": 1, "H2O_aq": 1}, 2.11e10),
        ("aq:e_H2O2", {"e_aq": 1, "H2O2_aq": 1}, {"OHm_aq": 1, "OH_aq": 1}, 1.41e10),
        ("aq:acid_base_neutralization", {"H3Op_aq": 1, "OHm_aq": 1}, {"H2O_aq": 2}, 1.43e11)]
    rx = []
    for name, reactants, products, molar_rate in entries:
        law = dict(type="constant", A=molar_rate / (1000 * AVOGADRO), temperature="liquid",
                   minimum_temperature_K=298.15, maximum_temperature_K=298.15)
        rx.append(reaction(name, reactants, products, law, G4_SOURCE,
                           metadata=dict(note="Reference-temperature only; no liquid electron Boltzmann model or thermal extrapolation.")))
    result = pack("aqueous_reference_subset", sp, rx, [G4_SOURCE],
                  ["four numerical aqueous radical/electron/acid-base reactions at 298.15 K"],
                  ["No equilibrium water dissociation or full radiolysis", "No source of hydrated electrons", "No liquid fast-electron transport", "No oxygen/nitrogen network", "Energy partitions unavailable", "Reference-temperature-only coefficients"])
    result["provenance"] = [dict(url=G4_SOURCE, revision="Geant4 v11.0.0", use="Four independently encoded unlike-reactant coefficients, converted to particle SI units; solvent products restored for elemental accounting.",
                                 license="Geant4 Software License v1.0", notice_file="GEANT4-LICENSE.txt",
                                 acknowledgment="This product includes software developed by Members of the Geant4 Collaboration ( http://cern.ch/geant4 ).")]
    return result


def aqueous_extensions():
    definitions = [("e_aq", {}, -1), ("H2O_aq", {"H": 2, "O": 1}, 0), ("H_aq", {"H": 1}, 0),
                   ("OH_aq", {"H": 1, "O": 1}, 0), ("H3Op_aq", {"H": 3, "O": 1}, 1),
                   ("H2_aq", {"H": 2}, 0), ("O2_aq", {"O": 2}, 0), ("O3_aq", {"O": 3}, 0),
                   ("HO2_aq", {"H": 1, "O": 2}, 0), ("O2m_aq", {"O": 2}, -1),
                   ("N2_aq", {"N": 2}, 0), ("NO_aq", {"N": 1, "O": 1}, 0),
                   ("NO2_aq", {"N": 1, "O": 2}, 0), ("NO2m_aq", {"N": 1, "O": 2}, -1),
                   ("NO3m_aq", {"N": 1, "O": 3}, -1), ("HNO2_aq", {"H": 1, "N": 1, "O": 2}, 0),
                   ("HNO3_aq", {"H": 1, "N": 1, "O": 3}, 0)]
    sp = [species(name, elements, charge, "aqueous") for name, elements, charge in definitions]
    rx = [parameter("aq:electron_source_events_m3_s", {"H2O_aq": 2}, {"H3Op_aq": 1, "OH_aq": 1, "e_aq": 1},
                    "https://geant4.web.cern.ch/documentation/dev/prm_html/PhysicsReferenceManual/electromagnetic/geant4_dna/dna.html", orders={}),
          parameter("aq:electron_O2", {"e_aq": 1, "O2_aq": 1}, {"O2m_aq": 1}, INTERFACE),
          parameter("aq:H_O2", {"H_aq": 1, "O2_aq": 1}, {"HO2_aq": 1}, INTERFACE),
          parameter("aq:NO2_hydrolysis", {"NO2_aq": 2, "H2O_aq": 1}, {"HNO2_aq": 1, "HNO3_aq": 1}, "https://doi.org/10.1021/ja407149y")]
    for acid, anion in (("HO2_aq", "O2m_aq"), ("HNO2_aq", "NO2m_aq"), ("HNO3_aq", "NO3m_aq")):
        rx += [parameter("aq:" + acid + "_dissociation", {acid: 1, "H2O_aq": 1}, {anion: 1, "H3Op_aq": 1}, INTERFACE),
               parameter("aq:" + acid + "_association", {anion: 1, "H3Op_aq": 1}, {acid: 1, "H2O_aq": 1}, INTERFACE)]
    return pack("aqueous_extensions", sp, rx, [INTERFACE],
                ["explicit caller-driven liquid ionization source", "parameterized oxygen radical and N/O acid-base channels"],
                ["All extension coefficients require independently sourced inputs", "No pH/electroneutrality replacement for charge kinetics", "No concentrated-electrolyte activities", "No peroxynitrite network"])


def interfaces(gas, liquid):
    wanted = ("H2O", "H2", "O2", "N2", "NO", "NO2", "H2O2", "HNO2", "HNO3")
    all_species = {s["id"]: deepcopy(s) for p in (gas, liquid) for s in p["species"]}
    used = {"e_g", "e_aq"}
    rx = []
    for name in wanted:
        aq = name + "_aq"
        if name in all_species and aq in all_species:
            used.update((name, aq))
            rx += [parameter("interface:" + name + "_absorb_m_s", {name: 1}, {aq: 1},
                             "https://iupac.org/recommendation/henrys-law-constants/", basis_interface="gas_water"),
                   parameter("interface:" + name + "_desorb_m_s", {aq: 1}, {name: 1},
                             "https://iupac.org/recommendation/henrys-law-constants/", basis_interface="gas_water")]
    rx.append(parameter("interface:electron_injection_m_s", {"e_g": 1}, {"e_aq": 1}, INTERFACE, basis_interface="gas_water"))
    return pack("gas_aqueous_interfaces_research", [all_species[name] for name in sorted(used)], rx,
                [INTERFACE, "https://iupac.org/recommendation/henrys-law-constants/"],
                ["finite bidirectional gas-water transfer", "explicit hydrated-electron injection"],
                ["Caller must supply transfer coefficients, area and both phase volumes", "Henry partition constants alone do not determine transfer rates", "No sheath, current, interfacial potential or electron penetration prediction", "No latent/solvation heat data supplied"])


def write(name, value):
    (ROOT / (name + ".json")).write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def main():
    n2, o2, h2o = nitrogen(), oxygen(), water()
    dry_air = combine("n2_o2_research", n2, o2, air_bridges())
    humid_air = combine("n2_o2_h2o_research", dry_air, h2o, humid_bridges())
    aqueous = combine("aqueous_water_research", aqueous_reference(), aqueous_extensions())
    interface = interfaces(humid_air, aqueous)
    all_phases = combine("n2_o2_h2o_aqueous_interfaces_research", humid_air, aqueous, interface)
    for name, value in (("n2_research", n2), ("o2_research", o2), ("h2o_research", h2o),
                        ("n2_o2_research", dry_air), ("n2_o2_h2o_research", humid_air),
                        ("aqueous_reference_subset", aqueous_reference()), ("aqueous_water_research", aqueous),
                        ("gas_aqueous_interfaces_research", interface),
                        ("n2_o2_h2o_aqueous_interfaces_research", all_phases)):
        write(name, value)
    examples = ROOT.parent / "examples"
    examples.mkdir(exist_ok=True)
    aqueous_case = dict(operation="chemistry.advance", mechanism=aqueous_reference(),
                        state=dict(densities_m3={"e_aq": 1e20, "OH_aq": 1e21, "H2O2_aq": 1e22,
                                                "H3Op_aq": 6.02214076e19, "OHm_aq": 6.02214076e19,
                                                "H2O_aq": 3.34e28}),
                        environment=dict(liquid_temperature_K=298.15), dt_s=1e-7,
                        options=dict(relative_tolerance=1e-5, absolute_tolerance_m3=1e6))
    (examples / "aqueous_reference_advance.json").write_text(json.dumps(aqueous_case, indent=2) + "\n", encoding="utf-8")
    manufactured = examples / "manufactured"
    manufactured.mkdir(exist_ok=True)
    manufactured_mechanism = pack("manufactured_isomer_decay", [species("A", {"N": 1}), species("B", {"N": 1})],
                                 [reaction("manufactured:A_to_B", {"A": 1}, {"B": 1}, dict(type="constant", A=2.0),
                                           "Manufactured numerical coefficient, not physical nitrogen chemistry.",
                                           energy_eV_per_event={"gas/electron": -3.0, "gas/heavy": 3.0},
                                           external_energy_eV_per_event=0.0)], [],
                                 ["manufactured linear decay"], ["No physical mechanism or calibration"])
    manufactured_mechanism["status"] = "manufactured"
    manufactured_mechanism["reactions"][0]["status"] = "manufactured"
    case = dict(operation="chemistry.advance", mechanism=manufactured_mechanism,
                state=dict(densities_m3={"A": 1.0, "B": 0.0}), dt_s=1.0)
    (manufactured / "chemistry_decay.json").write_text(json.dumps(case, indent=2) + "\n", encoding="utf-8")
    print("Wrote 9 research mechanisms; absent coefficients remain explicit required inputs.")


if __name__ == "__main__":
    main()
