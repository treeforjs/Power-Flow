# Research chemistry packs

These mechanisms are starting points for research, with explicit omissions.
They are not a validated universal air/water chemistry model. Nitrogen, oxygen,
water vapor, aqueous water and interfaces have separate species and reactions;
the combined packs support arbitrary initial proportions of their constituents.
Adding a species does not imply that every relevant reaction involving it is
included.

`n2_research`, `o2_research` and `h2o_research` define gas reaction families.
`n2_o2_research` and `n2_o2_h2o_research` add mixture bridges. Their electron
coefficients must come from a compatible, independently obtained collision set
and EEDF calculation. Their heavy-particle coefficients are named inputs, with
no numerical defaults. Required rates remain required even when a reactant has
zero initial population. `coverage_report` lists missing rates and omitted
physics. Evaluation fails if a required coefficient is missing.

`aqueous_reference_subset` has four numerical, unlike-reactant aqueous reaction
coefficients from Geant4 v11.0.0, converted from L/(mol s) to m³/(particle s) by
dividing by `1000 * 6.02214076e23`. The solvent products are represented explicitly
for atom accounting. To prevent an unsupported temperature extrapolation, these
coefficients are admitted only at the chosen reference temperature of 298.15 K.
The pack is an independently encoded deterministic reaction subset, and does
not reproduce Geant4's radiation-track or spatial diffusion simulation.

This product includes software developed by Members of the Geant4 Collaboration
( http://cern.ch/geant4 ). The numerical subset has been adapted for Raikou;
the [Geant4 license](GEANT4-LICENSE.txt) applies to these adapted data. The
[versioned source](https://raw.githubusercontent.com/Geant4/geant4/v11.0.0/source/physics_lists/constructors/electromagnetic/src/G4EmDNAChemistry_option2.cc)
identifies the original values. No Geant4 simulation code is incorporated.

`aqueous_water_research` adds parameterized oxygen and nitrogen chemistry and an
explicit liquid ionization source. It does not solve liquid electron tracks,
cavitation, liquid breakdown, sheaths or concentrated-electrolyte activity
corrections. `e_g` denotes a gas electron; `e_aq` denotes a hydrated electron.
The gas Boltzmann solver is not applied to `e_aq`.

`gas_aqueous_interfaces_research` exchanges matter between gas and aqueous
compartments using caller-supplied, directional transfer velocities. Both phase
volumes and the interface area must be specified. They are needed to conserve
particle inventories when the compartments have different sizes. Henry
partition constants alone do not prescribe a transfer rate. The caller must
provide a consistent transfer model, charge-current closure and any associated
latent or solvation energy. The all-phase combined mechanism is
`n2_o2_h2o_aqueous_interfaces_research`.

No LXCat cross-section tables are bundled in these packs. LXCat's
[redistribution policy](https://nl.lxcat.net/instructions/redistribution.php)
requires obtaining data through the provider or arranging permission. The
references in each pack describe the reaction families and their scientific
context; citations alone are not redistribution licenses for their tables.

## Kernel conventions

Every species concentration is a particle number density in its own phase,
measured in m⁻³. Constant, Arrhenius, electron-temperature-table, native
expression, external EEDF and named parameter rates are supported. A reaction's
orders default to reactant stoichiometry; an explicit `orders` object can
represent catalysts, reduced solvent kinetics or an imposed source. The
mass-action progress convention is `k * product(n_i ** order_i)` without an
additional identical-reactant factorial.

An Arrhenius law is `A * (T / reference_temperature_K)^exponent *
exp(-activation_temperature_K / T)`, with `T` selected as gas, liquid or electron
temperature. Electron temperatures in the environment are in eV and are
converted to K for an electron-selected Arrhenius law. The electron-temperature
table uses linear interpolation and rejects extrapolation; it is a prescribed
electron-temperature closure rather than a Boltzmann solution.

Native scalar expressions accept arithmetic, exponentiation, `exp`, `log`,
`sqrt`, `abs`, `pow`, `min` and `max`. Their variables are `Tgas_K`, `Tliquid_K`,
`Te_eV`, `Te_K`, `pi`, named environment parameters and per-law constants. They
cannot execute code or access files. Reaction orders supply concentration
dependence so that the concentration Jacobian is analytic. Fractional orders
between zero and one are rejected because their derivative at zero is singular.

The kernel validates elemental and charge balance for every reaction. Signed
event energy changes are optional, keyed by `phase/reservoir`, in eV per event.
If `external_energy_eV_per_event` is provided, their sum is checked against it.
Omitted energy data remain visible as `unchecked_energy_reactions`; they are not
filled with guessed thresholds, heats or radiation yields. Use a mechanism with
complete energy data before claiming an energy-conserving multiphysics model.

`advance` uses adaptive backward Euler with Newton solves and step doubling.
Its per-species nonnegative constraints reject or shorten invalid steps; they
never clip concentrations. If the requested interval cannot be completed, it
returns the original state and zero advanced time. Temperatures, EEDF rates and
external parameters are frozen during one call; a host simulation must update
them and enforce its own coupled energy/field convergence.

`AdvanceOptions.execution` selects CPU threading, MPI row distribution or CUDA.
Non-MPI CUDA chemistry runs reaction progress, analytic Jacobians, implicit Newton
updates, positivity line search and adaptive integration on the device. The batch
API advances independent cells with a shared mechanism and per-cell environments.
Temperatures and external rate inputs remain prescribed during each local interval.
MPI chemistry currently distributes the Newton linear operator; its owned-state
assembly extension is in progress.
The host initializes MPI, supplies its communicator if needed, and invokes the
same local problem collectively. Per-cell solves inside host worker threads
must keep `mpi=false`; distributed spatial assembly belongs to the host solver.

All thermal heavy-particle channels remain active alongside electron channels.
There is no temperature-triggered chemistry replacement. These research packs
are not thermodynamically closed, so they do not claim an LTE limit or a
continuous validated description across phase changes. A host may supply a
one-temperature electron closure and a suitably closed mechanism explicitly.

The scalar numerical examples in `examples/manufactured` are separate from
these physical research packs. Regenerate the packs with
`python mechanisms/generate_starters.py`; this utility is not needed at runtime.
