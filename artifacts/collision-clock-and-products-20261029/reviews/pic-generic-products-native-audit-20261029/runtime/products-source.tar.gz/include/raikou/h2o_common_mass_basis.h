#pragma once
// Common REDUCED-MODEL mass basis for source-rounded chemical references.
// The implied0.75/1.83eV electron affinities are not precision mass measurements.
#include "raikou/collision_data.h"
namespace raikou::kinetics {
struct ConditionalWaterMassBasis {
    double H2O_kg{0},H_kg{0},OH_X_v0_kg{0},Hminus_kg{0},OHminus_X_v0_kg{0},H2Oplus_kg{0};
};
[[nodiscard]] inline ConditionalWaterMassBasis conditional_water_mass_basis(
    const StrictCollisionDataset& data,double neutral_water_mass_kg,double H_mass_kg) {
    constexpr double e=1.602176634e-19,me=9.1093837139e-31,c=299792458.;
    if (!std::isfinite(neutral_water_mass_kg)||!std::isfinite(H_mass_kg)||H_mass_kg<=100*me||neutral_water_mass_kg<=H_mass_kg)
        throw std::invalid_argument("Invalid base species masses");
    const auto& p=data.metadata().at("common_conditional_mass_basis");
    if (p.at("id")!="source_rounded_common_basis_v1")throw std::invalid_argument("Unadmitted chemical reference basis");
    const double D=p.at("H2O_to_H_OH_eV").get<double>(),A_H=p.at("implied_H_electron_affinity_eV").get<double>(),A_OH=p.at("implied_OH_electron_affinity_eV").get<double>();
    ConditionalWaterMassBasis out;out.H2O_kg=neutral_water_mass_kg;out.H_kg=H_mass_kg;
    out.OH_X_v0_kg=neutral_water_mass_kg+D*e/(c*c)-H_mass_kg;
    out.Hminus_kg=H_mass_kg+me-A_H*e/(c*c);
    out.OHminus_X_v0_kg=out.OH_X_v0_kg+me-A_OH*e/(c*c);
    out.H2Oplus_kg=neutral_water_mass_kg-me+p.at("H2O_ionization_eV").get<double>()*e/(c*c);
    return out;
}
} // namespace raikou::kinetics
