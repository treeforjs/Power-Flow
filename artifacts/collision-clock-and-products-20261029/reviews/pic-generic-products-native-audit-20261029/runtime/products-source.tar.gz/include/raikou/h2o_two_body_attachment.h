#pragma once
// Conditional ground-state OHminus + H attachment products. No inventory,
// random engine, rate scheduler, electron evolution or accepted-state mutation.
#include "raikou/h2o_conditional_parent.h"

namespace raikou::kinetics {
struct TwoBodyAttachmentProducts {
    CollisionMomentum anion_momentum_kg_m_s{},neutral_momentum_kg_m_s{};
    double anion_kinetic_J{0},neutral_kinetic_J{0};
    double anion_state_mass_kg{0},neutral_state_mass_kg{0};
    double chemical_reference_gain_J{0},internal_gain_J{0};
    double physical_weight_each{0},cross_section_m2{0};
};

[[nodiscard]] inline TwoBodyAttachmentProducts conditional_ohminus_ground_products(
    const StrictCollisionDataset& data,const std::string& explicitly_selected_model,
    double incident_target_rest_eV,double represented_weight,double neutral_parent_mass_kg,double H_mass_kg,
    const CollisionMomentum& incident_unit_direction,const CollisionMomentum& CM_anion_unit_direction) {
    constexpr double e=1.602176634e-19,me=9.1093837139e-31,c=299792458.;
    const auto require=[](bool value,const char* why) {if (!value)throw std::invalid_argument(why);};
    require(explicitly_selected_model=="OHminus_ground_isotropic_CM_v1","Explicit OHminus ground/isotropic conditional opt-in required");
    data.require_MCC_event_kernel("H2O:attachment_yield:OHminus",explicitly_selected_model,incident_target_rest_eV);
    require(std::isfinite(represented_weight)&&represented_weight>0,"Invalid represented weight");
    require(std::isfinite(neutral_parent_mass_kg)&&std::isfinite(H_mass_kg)&&neutral_parent_mass_kg>H_mass_kg&&H_mass_kg>100*me,"Invalid species/state mass basis");
    for (const auto& axis:{incident_unit_direction,CM_anion_unit_direction}) {
        double norm=0;for (const auto v:axis) {require(std::isfinite(v),"Nonfinite axis");norm+=v*v;}
        require(std::abs(norm-1)<1e-12,"Host axes must be unit vectors");
    }
    const auto status=data.kernel_status("H2O:attachment_yield:OHminus",explicitly_selected_model);
    const double reference=status.at("model").at("chemical_reference_gain_eV").get<double>()*e;
    const double K=incident_target_rest_eV*e,D=(neutral_parent_mass_kg+me)*c*c;
    const double W=std::sqrt(D*D+2*neutral_parent_mass_kg*c*c*K),available=2*neutral_parent_mass_kg*c*c*K/(W+D);
    const double Q=available-reference;require(Q>0,"Insufficient CM energy");
    const double mass1=neutral_parent_mass_kg+me+reference/(c*c)-H_mass_kg;
    require(mass1>H_mass_kg,"Invalid OHminus mass");
    const double k1=Q*(Q+2*H_mass_kg*c*c)/(2*W),k2=Q*(Q+2*mass1*c*c)/(2*W);
    const double mom=std::sqrt(k1*(k1+2*mass1*c*c))/c,p0=std::sqrt(K*(K+2*me*c*c))/c;
    const double beta=p0*c/(D+K),gamma=1/std::sqrt(1-beta*beta),gm1=beta*beta*gamma*gamma/(gamma+1);
    double mu=0;for (int d=0;d<3;++d)mu+=incident_unit_direction[d]*CM_anion_unit_direction[d];
    const double E1=mass1*c*c+k1,E2=H_mass_kg*c*c+k2;
    TwoBodyAttachmentProducts out;out.anion_state_mass_kg=mass1;out.neutral_state_mass_kg=H_mass_kg;
    out.anion_kinetic_J=k1+gm1*E1+gamma*beta*c*mom*mu;
    out.neutral_kinetic_J=k2+gm1*E2-gamma*beta*c*mom*mu;
    out.chemical_reference_gain_J=reference;out.physical_weight_each=represented_weight;
    out.cross_section_m2=data.observable_value_SI("H2O:attachment_yield:OHminus",incident_target_rest_eV);
    for (int d=0;d<3;++d) {
        out.anion_momentum_kg_m_s[d]=mom*CM_anion_unit_direction[d]+(gm1*mom*mu+gamma*beta*E1/c)*incident_unit_direction[d];
        out.neutral_momentum_kg_m_s[d]=-mom*CM_anion_unit_direction[d]+(-gm1*mom*mu+gamma*beta*E2/c)*incident_unit_direction[d];
    }
    return out;
}
} // namespace raikou::kinetics
