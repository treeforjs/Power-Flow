#pragma once
// Explicit conditional A1B1 excitation -> prompt H+OH(X) products. This
// consumes the excitation channel once, never the overlapping inclusive OH yield.
#include "raikou/h2o_conditional_parent.h"

namespace raikou::kinetics {
struct NeutralDissociationProducts {
    CollisionMomentum electron_momentum_kg_m_s{},H_momentum_kg_m_s{},OH_momentum_kg_m_s{};
    double electron_kinetic_J{0},H_kinetic_J{0},OH_kinetic_J{0},OH_state_mass_kg{0};
    double chemical_reference_gain_J{0},internal_gain_J{0},intermediate_excitation_J{0};
    double physical_weight_each{0},cross_section_m2{0},electron_CM_cosine{0};
};
namespace h2o_dissociation_detail {
constexpr double c=299792458.;
inline void require(bool value,const char* why) {if (!value)throw std::invalid_argument(why);}
inline void unit(const CollisionMomentum& axis) {double norm=0;for (const auto x:axis) {require(std::isfinite(x),"Nonfinite axis");norm+=x*x;}require(std::abs(norm-1)<1e-12,"Unit axis required");}
struct Product {CollisionMomentum p{};double kinetic{0};};
inline Product boost(const CollisionMomentum& p,double mass,double K,const CollisionMomentum& total_p,double total_E) {
    double norm=0;for (const auto v:total_p)norm+=v*v;
    if (norm==0)return {p,K};
    norm=std::sqrt(norm);const double beta=norm*c/total_E;
    require(beta<1&&total_E>0,"Invalid boost");
    const double gamma=1/std::sqrt(1-beta*beta),gm1=beta*beta*gamma*gamma/(gamma+1),energy=mass*c*c+K;
    CollisionMomentum axis{};double dot=0;for (int d=0;d<3;++d) {axis[d]=total_p[d]/norm;dot+=p[d]*axis[d];}
    Product out;out.kinetic=K+gm1*energy+gamma*beta*c*dot;
    for (int d=0;d<3;++d)out.p[d]=p[d]+(gm1*dot+gamma*beta*energy/c)*axis[d];
    return out;
}
inline CollisionMomentum axis(const CollisionMomentum& beam,double mu,double phi) {
    const int component=std::abs(beam[0])<.8?0:1;CollisionMomentum first{};first[component]=1;
    double norm=0;for (int d=0;d<3;++d) {first[d]-=beam[component]*beam[d];norm+=first[d]*first[d];}
    for (auto& x:first)x/=std::sqrt(norm);
    const CollisionMomentum second{beam[1]*first[2]-beam[2]*first[1],beam[2]*first[0]-beam[0]*first[2],beam[0]*first[1]-beam[1]*first[0]};
    CollisionMomentum out{};const double sine=std::sqrt(std::max(0.,1-mu*mu));
    for (int d=0;d<3;++d)out[d]=mu*beam[d]+sine*(std::cos(phi)*first[d]+std::sin(phi)*second[d]);
    return out;
}
} // namespace h2o_dissociation_detail

[[nodiscard]] inline NeutralDissociationProducts conditional_A1B1_dissociation_products(
    const StrictCollisionDataset& data,const std::string& explicitly_selected_model,
    double incident_target_rest_eV,double represented_weight,double neutral_parent_mass_kg,double H_mass_kg,
    const CollisionMomentum& incident_unit_direction,double electron_angle_uniform,double electron_azimuth_uniform,
    const CollisionMomentum& excited_rest_H_unit_direction) {
    using namespace h2o_dissociation_detail;
    constexpr double e=1.602176634e-19,me=9.1093837139e-31;
    require(explicitly_selected_model=="A1B1_fixed_loss_dipole_ground_v1","Explicit A1B1 fixed-loss/dipole/ground endpoint opt-in required");
    data.require_MCC_event_kernel("H2O:electronic_A1B1",explicitly_selected_model,incident_target_rest_eV);
    require(std::isfinite(represented_weight)&&represented_weight>0,"Invalid represented weight");
    require(std::isfinite(neutral_parent_mass_kg)&&std::isfinite(H_mass_kg)&&neutral_parent_mass_kg>H_mass_kg&&H_mass_kg>100*me,"Invalid state mass basis");
    unit(incident_unit_direction);unit(excited_rest_H_unit_direction);
    for (const double u:{electron_angle_uniform,electron_azimuth_uniform})require(std::isfinite(u)&&u>=0&&u<1,"Host variates must be in[0,1)");
    const auto metadata=data.kernel_status("H2O:electronic_A1B1",explicitly_selected_model).at("model");
    const double loss=metadata.at("fixed_excitation_eV").get<double>()*e,reference=metadata.at("chemical_reference_gain_eV").get<double>()*e;
    require(loss>reference&&reference>0,"Invalid source energy binding");
    const double K=incident_target_rest_eV*e,M=neutral_parent_mass_kg,Mstar=M+loss/(c*c),MOH=M+reference/(c*c)-H_mass_kg;
    const double D=(M+me)*c*c,W=std::sqrt(D*D+2*M*c*c*K),available=2*M*c*c*K/(W+D),Q=available-loss;
    require(Q>0&&MOH>0,"Channel not energetically available");
    const double ke=Q*(Q+2*Mstar*c*c)/(2*W),kstar=Q*(Q+2*me*c*c)/(2*W);
    const double pf=std::sqrt(ke*(ke+2*me*c*c))/c,p0=std::sqrt(K*(K+2*me*c*c))/c,pi=p0*M*c*c/W;
    // Dipole/Born-shaped CM density proportional to1/q^2. This is an explicit
    // differential approximation; measured integral cross sections stay intact.
    const double r=pf/pi,beta=2*r/(1+r*r),log_ratio=std::log1p(beta)-std::log1p(-beta);
    const double mu=std::clamp((1-std::exp(std::log1p(beta)-electron_angle_uniform*log_ratio))/beta,-1.,1.);
    const auto direction=axis(incident_unit_direction,mu,2*std::numbers::pi*electron_azimuth_uniform);
    CollisionMomentum pe{},ps{},incoming{};for (int d=0;d<3;++d) {pe[d]=pf*direction[d];ps[d]=-pe[d];incoming[d]=p0*incident_unit_direction[d];}
    const auto electron=boost(pe,me,ke,incoming,D+K),excited=boost(ps,Mstar,kstar,incoming,D+K);
    const double decay=loss-reference,kH=decay*(decay+2*MOH*c*c)/(2*Mstar*c*c),kOH=decay*(decay+2*H_mass_kg*c*c)/(2*Mstar*c*c);
    const double pH=std::sqrt(kH*(kH+2*H_mass_kg*c*c))/c;
    CollisionMomentum ph{},poh{};for (int d=0;d<3;++d) {ph[d]=pH*excited_rest_H_unit_direction[d];poh[d]=-ph[d];}
    const auto hydrogen=boost(ph,H_mass_kg,kH,excited.p,Mstar*c*c+excited.kinetic),hydroxyl=boost(poh,MOH,kOH,excited.p,Mstar*c*c+excited.kinetic);
    NeutralDissociationProducts out;out.electron_momentum_kg_m_s=electron.p;out.H_momentum_kg_m_s=hydrogen.p;out.OH_momentum_kg_m_s=hydroxyl.p;
    out.electron_kinetic_J=electron.kinetic;out.H_kinetic_J=hydrogen.kinetic;out.OH_kinetic_J=hydroxyl.kinetic;
    out.OH_state_mass_kg=MOH;out.chemical_reference_gain_J=reference;out.intermediate_excitation_J=loss;out.physical_weight_each=represented_weight;out.electron_CM_cosine=mu;
    out.cross_section_m2=data.observable_value_SI("H2O:electronic_A1B1",incident_target_rest_eV);
    return out;
}
} // namespace raikou::kinetics
