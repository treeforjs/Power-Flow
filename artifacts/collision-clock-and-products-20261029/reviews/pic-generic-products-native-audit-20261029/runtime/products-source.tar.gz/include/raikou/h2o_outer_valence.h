#pragma once
// High-energy OUTER-THREE-ORBITAL conditional subset. The positive2a1 rate
// is exposed as unmapped; no normalization to the four-orbital total occurs.
#include "raikou/h2o_neutral_dissociation.h"
#include "raikou/h2o_common_mass_basis.h"
namespace raikou::kinetics {
struct Outer3IonizationRates {
    double parent_m2{0},OHplus_H_m2{0},Hplus_OH_m2{0},unmapped_2a1_m2{0},four_valence_total_m2{0};
    [[nodiscard]] double mapped_subset_m2() const {return parent_m2+OHplus_H_m2+Hplus_OH_m2;}
};
[[nodiscard]] inline Outer3IonizationRates conditional_outer3_ionization_rates(const StrictCollisionDataset& data,double E_eV) {
    return {data.observable_value_SI("H2O:conditional_outer3:parent",E_eV),
        data.observable_value_SI("H2O:conditional_outer3:OHp_H",E_eV),
        data.observable_value_SI("H2O:conditional_outer3:Hp_OH",E_eV),
        data.observable_value_SI("H2O:conditional_outer3:unmapped_2a1",E_eV),
        data.observable_value_SI("H2O:nist_BEB_valence",E_eV)};
}
struct Outer3IonizationProducts {
    // Two electrons first; positive heavy product third; optional neutral fourth.
    std::array<CollisionMomentum,4> momentum_kg_m_s{};
    std::array<double,4> kinetic_J{},mass_kg{},charge_C{};
    std::array<std::string,4> state_id{};
    int product_count{0};double chemical_reference_gain_J{0},physical_weight_each{0},cross_section_m2{0};
    bool complete_water_mechanism{false};
};
[[nodiscard]] inline Outer3IonizationProducts conditional_outer3_ionization_products(
    const StrictCollisionDataset& data,const std::string& explicitly_selected_model,
    double incident_target_rest_eV,double represented_weight,double neutral_parent_mass_kg,double H_mass_kg,
    const CollisionMomentum& incident_unit_direction,const CollisionMomentum& CM_electron_pair_unit_axis,
    const CollisionMomentum& virtual_ion_rest_positive_fragment_unit_axis) {
    using namespace h2o_dissociation_detail;
    constexpr double e=1.602176634e-19,me=9.1093837139e-31;
    std::string branch;
    if (explicitly_selected_model=="outer3_BEB_Tan_parent_v1")branch="parent";
    else if (explicitly_selected_model=="outer3_BEB_Tan_OHp_H_v1")branch="OHp_H";
    else if (explicitly_selected_model=="outer3_BEB_Tan_Hp_OH_v1")branch="Hp_OH";
    else throw std::invalid_argument("Explicit outer3 branch model required; unmapped holes have no product kernel");
    const std::string channel="H2O:conditional_outer3:"+branch;
    data.require_MCC_event_kernel(channel,explicitly_selected_model,incident_target_rest_eV);
    require(std::isfinite(represented_weight)&&represented_weight>0,"Invalid represented weight");
    unit(incident_unit_direction);unit(CM_electron_pair_unit_axis);unit(virtual_ion_rest_positive_fragment_unit_axis);
    const auto basis=conditional_water_mass_basis(data,neutral_parent_mass_kg,H_mass_kg);
    const auto metadata=data.kernel_status(channel,explicitly_selected_model).at("model");
    const double reference=metadata.at("chemical_reference_gain_eV").get<double>()*e;
    const double hole=branch=="parent"?reference:metadata.at("fixed_fragmenting_hole_eV").get<double>()*e;
    const double M=neutral_parent_mass_kg,K=incident_target_rest_eV*e,D=(M+me)*c*c,W=std::sqrt(D*D+2*M*c*c*K);
    const double available=2*M*c*c*K/(W+D),Q=available-hole;
    require(Q>0,"Insufficient ionization energy");
    const double ion_mass=M-me+hole/(c*c),each=Q/2,pe=std::sqrt(each*(each+2*me*c*c))/c,p0=std::sqrt(K*(K+2*me*c*c))/c;
    CollisionMomentum incoming{},first{},second{};
    for (int d=0;d<3;++d) {incoming[d]=p0*incident_unit_direction[d];first[d]=pe*CM_electron_pair_unit_axis[d];second[d]=-first[d];}
    const auto primary=boost(first,me,each,incoming,D+K),secondary=boost(second,me,each,incoming,D+K);
    Outer3IonizationProducts out;out.product_count=branch=="parent"?3:4;
    out.momentum_kg_m_s[0]=primary.p;out.momentum_kg_m_s[1]=secondary.p;
    out.kinetic_J[0]=primary.kinetic;out.kinetic_J[1]=secondary.kinetic;
    out.mass_kg[0]=out.mass_kg[1]=me;out.charge_C[0]=out.charge_C[1]=-e;out.charge_C[2]=e;
    out.state_id[0]=out.state_id[1]="e_g";
    if (branch=="parent") {
        const auto ion=boost({},ion_mass,0,incoming,D+K);out.momentum_kg_m_s[2]=ion.p;out.kinetic_J[2]=ion.kinetic;out.mass_kg[2]=ion_mass;out.state_id[2]="H2Op_ground";
    } else {
        const double IH=data.metadata().at("outer3_fragment_ionization_eV").at("H").get<double>()*e;
        const double IOH=data.metadata().at("outer3_fragment_ionization_eV").at("OH").get<double>()*e;
        const double mass1=branch=="Hp_OH"?H_mass_kg-me+IH/(c*c):basis.OH_X_v0_kg-me+IOH/(c*c);
        const double mass2=branch=="Hp_OH"?basis.OH_X_v0_kg:H_mass_kg;
        const double decay=hole-reference;require(decay>0,"Unavailable ground-product branch");
        const double k1=decay*(decay+2*mass2*c*c)/(2*ion_mass*c*c),k2=decay*(decay+2*mass1*c*c)/(2*ion_mass*c*c);
        const double mom=std::sqrt(k1*(k1+2*mass1*c*c))/c;
        CollisionMomentum p1{},p2{};for (int d=0;d<3;++d) {p1[d]=mom*virtual_ion_rest_positive_fragment_unit_axis[d];p2[d]=-p1[d];}
        // The virtual ion is at rest in the total CM; boost each fragment directly.
        const auto a=boost(p1,mass1,k1,incoming,D+K),b=boost(p2,mass2,k2,incoming,D+K);
        out.momentum_kg_m_s[2]=a.p;out.momentum_kg_m_s[3]=b.p;out.kinetic_J[2]=a.kinetic;out.kinetic_J[3]=b.kinetic;
        out.mass_kg[2]=mass1;out.mass_kg[3]=mass2;out.state_id[2]=branch=="Hp_OH"?"Hp":"OHp_X_ground";out.state_id[3]=branch=="Hp_OH"?"OH_X_v0":"H_1s";
    }
    out.chemical_reference_gain_J=reference;out.physical_weight_each=represented_weight;out.cross_section_m2=data.observable_value_SI(channel,incident_target_rest_eV);
    return out;
}
} // namespace raikou::kinetics
