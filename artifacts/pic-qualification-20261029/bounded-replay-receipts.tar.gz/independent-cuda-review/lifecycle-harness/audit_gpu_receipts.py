#!/usr/bin/env python3
"""Read-only saved GPU evidence audit. No CUDA import, execution or signals."""
from pathlib import Path
import fcntl, hashlib, json, math, os, statistics, struct, time

PROFILE = Path('/home/treefor/Documents/Codex/2026-10-28/we/outputs/pic-profile')
ROOT = PROFILE/'cuda-gather-investigation/gpu-lifecycle-v2'
HERE = Path(__file__).resolve().parent
HARNESS = Path('/home/treefor/projects/runtimes/pic-cuda-gather-investigation-20261029/backend-v2/lifecycle-harness')
FIXTURE = PROFILE/'cuda-gather-investigation/actual-midpoint-fixture'

def read(p): return json.loads(Path(p).read_text())
def digest(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
checks = []
def need(condition, name):
    checks.append(name)
    if not condition: raise AssertionError(name)
def hold(h):
    need(h['production_host_pid']==278902 and h['start_ticks']=='5288339' and h['state']=='T' and h['cgroup_frozen'] is True, 'original stopped/frozen production identity')
    need(h['exe']=='/home/treefor/projects/runtimes/mfem-gpu-pic-20261029/qualified/heating-history-pic-gpu', 'original executable identity')
    need(h['cgroup']=='/powerflow-pic-gpu-reserved', 'original cgroup membership')

def audit():
    accepted=read(HERE/'disposition.json')
    need(digest(HARNESS/'artifact-sha256.json')==accepted['artifact_manifest_sha256'], 'accepted artifact manifest')
    artifacts=read(HARNESS/'artifact-sha256.json')
    need(len(artifacts)==42 and all(digest(p)==h for p,h in artifacts.items()), '42 accepted artifact hashes unchanged')
    need(digest(HARNESS/'parent-gpu-request.json')==accepted['parent_command_request_sha256'], 'accepted command request unchanged')
    request=read(HARNESS/'parent-gpu-request.json')
    parent=read(ROOT/'PARENT-DISPATCH.json');continuation=read(ROOT/'PARENT-CONTINUATION.json')
    need(parent['request_sha256']==accepted['parent_command_request_sha256'] and parent['artifact_sha256']==accepted['artifact_manifest_sha256'], 'dispatch bound to reviewed hashes')
    cases=parent['cases']+continuation['cases']
    need([c['phase'] for c in cases]==[c['phase'] for c in request['commands']], 'three serial phase receipts, no duplicate GPU run')
    for c in cases:
        need(c['returncode']==0 and math.isfinite(c['wall_s']) and 0<c['wall_s']<60, c['phase']+' clean bounded process exit')
    need(not parent['production_resume_authorized'] and not continuation['production_resume_authorized'] and not continuation['application_integration_authorized'], 'dispatch preserves production/integration hold')
    expected=(FIXTURE/'reference.bin').read_bytes()
    need(digest(FIXTURE/'reference.bin')==read(FIXTURE/'sha256.json')['reference.bin'], 'pinned original actual reference')
    need(len(expected)==46726*80 and all(row[-1]==0 and all(math.isfinite(x) for x in row[:-1]) for row in struct.iter_unpack('<9dQ',expected)), 'all original captured reference rows finite/status0')
    phase_results={}; hashes={}; exact_outputs=[]
    for c in request['commands']:
        phase=c['phase'];p=Path(c['output']);g=read(p/'host-guard.json');pre=read(p/'preflight.json')
        need(p==ROOT/phase, phase+' expected output path')
        need(g['child_returncode']==0 and g['guard_error'] is None and not g['production_signalled'] and not g['gpu_actions_in_guard'], phase+' host guard success')
        need(g['logical_cpu']==[7] and g['nice']>=15 and g['production_pidfd_retained_until_child_exit'] and g['periodic_checks']>=2, phase+' CPU priority and retained pidfd periodic checks')
        for h in [g['before'],g['after'],*[x['check'] for x in g['child_requests']]]:
            hold(h);need(h['pidfd_retained'] and h['host_guard_pid']==g['host_guard_pid'], phase+' authenticated host observation')
        need(g['before']['checked_unix_s']<=g['after']['checked_unix_s'],phase+' ordered hold observations')
        need(pre['passed'] and not pre['production_signalled'],phase+' nested preflight passed');hold(pre['hold'])
        need(pre['hold']['host_proc_readonly'] and pre['hold']['distinct_pid_views'] and pre['hold']['host_executable_checked_with_retained_pidfd'],phase+' readonly host-proc and exact host identity')
        need(g['command']==c['command_argv'][c['command_argv'].index('--')+1:],phase+' executed guarded argv matches accepted request')
        for f in p.glob('*comparison.json'):
            d=read(f);need(d['passed'] and d['failures']==0 and all(math.isfinite(d[k]) and d[k]==0 for k in ('max_E_error_V_m','max_B_error_T','max_u_error_m_s','weighted_u_error_scaled_by_sum_abs','relative_weighted_energy_error')),phase+' '+f.name+' unchanged gates, zero error')
        for f in p.glob('*device.bin'):
            need(f.read_bytes()==expected,phase+' '+f.name+' all46726 output records byte-equal to original capture');exact_outputs.append(str(f))
        for f in sorted(p.iterdir()):
            if f.is_file():hashes[str(f)]=digest(f)
        phase_results[phase]={'guard_periodic_checks':g['periodic_checks'],'child_returncode':g['child_returncode'],'guard_error':g['guard_error']}
    need(len(exact_outputs)==5,'five independently checked device outputs')
    lifecycle={}
    for phase,active in [('shared-lifecycle',{'shared','wrong','lost'}),('explicit-standalone',{'standalone'})]:
        d=read(ROOT/phase/'lifecycle.json');need(d['passed'] and not d['original_error'] and d['particles']==46726 and d['forces_completed']==2 and d['GPU_kernel_dispatched'] and not d['full_PIC_replay'] and not d['production_actions'] and not d['device_fault_injection'],phase+' bounded actual-midpoint lifecycle passed')
        need({k for k,v in d['cleanup'].items() if v['attempted']}==active,phase+' exact active cleanup sinks')
        for k,v in d['cleanup'].items():
            need(v['issue_count']==0 and v['issues']==[] and not v['resources_retained'],phase+' '+k+' no issue/retention')
            if k in active:
                need(all(v[x] for x in ('attempted','context_established','stream_drained','resources_released','caller_context_restored','primary_reference_released')),phase+' '+k+' complete clean shutdown')
            else:
                need(not any(v[x] for x in ('attempted','context_established','stream_drained','resources_released','caller_context_restored','primary_reference_released')),phase+' '+k+' correctly unused sink')
        count=3 if phase=='shared-lifecycle' else 1
        need(d['successful_own_retains']==count and d['successful_own_releases']==count and d['reset_attempts']==0 and d['borrowed_destroy_attempts']==0,phase+' own reference balance; no forbidden attempt')
        lifecycle[phase]=d
    d=lifecycle['shared-lifecycle'];events={e['stage']:e for e in d['events']};borrowed=d['borrowed_primary']
    expected_stages=['solve1_before_force','force1','solve2_between_forces','force2','shared_explicit_close','solve3_after_force_close','wrong_current_selected','wrong_close_restored_owned_context','wrong_owned_context_destroyed_only','solve4_after_wrong_context_probe','lost_current_selected','lost_close_restored_null','solve5_after_lost_context_probe']
    need(list(events)==expected_stages and d['manufactured_Poisson_rows']==130321 and len(d['solves'])==5,'shared solve/force/close/probe stage sequence and manufactured dimensions')
    normal=set(events)-{'wrong_current_selected','wrong_close_restored_owned_context','lost_current_selected','lost_close_restored_null'}
    need(borrowed!='0x0' and all(events[k]['current']==borrowed for k in normal) and all(e['primary_active']==1 for e in events.values()),'shared primary identity/activity survives every stage')
    need(d['wrong_current_rejected_before_dispatch'] and d['lost_current_rejected_before_dispatch'] and d['owned_context_destroys']==1,'wrong/lost rejection and only one owned-context destruction')
    for a,b,null in [('wrong_current_selected','wrong_close_restored_owned_context',False),('lost_current_selected','lost_close_restored_null',True)]:
        x,y=events[a],events[b]
        need(x['current']==y['current'] and ((x['current']=='0x0') if null else x['current'] not in ('0x0',borrowed)),a+' restores caller')
        need(all(x[k]==y[k]==events['force2'][k] for k in ('launches','H2D_dispatches','D2H_dispatches')),a+' rejects before async dispatch')
    need([events[k]['own_releases'] for k in ('shared_explicit_close','wrong_close_restored_owned_context','lost_close_restored_null')]==[1,2,3],'each backend releases its own primary reference')
    for s in d['solves']:
        need(all(math.isfinite(s[k]) for k in ('rhs_norm','residual_norm','guard_limit','relative_residual')) and s['rhs_norm']>0 and s['residual_norm']<=s['guard_limit']==max(1e-30,2e-13*s['rhs_norm']) and math.isclose(s['relative_residual'],s['residual_norm']/s['rhs_norm'],rel_tol=1e-14),s['stage']+' original residual threshold passed')
    stand=lifecycle['explicit-standalone'];se=stand['events']
    need(stand['manufactured_Poisson_rows']==0 and not stand['solves'] and stand['standalone_primary_active_before']==stand['standalone_primary_active_after']==0 and stand['owned_context_destroys']==0,'standalone fresh-process primary lifetime balanced')
    need([x['stage'] for x in se]==['standalone_before','standalone_force1','standalone_force2','standalone_after_close'] and se[0]['current']==se[-1]['current']=='0x0' and se[1]['current']==se[2]['current']!='0x0','standalone selection and null restoration')
    t=read(ROOT/'reference-inclusive-timing/reference-inclusive-timing.json');cl=read(ROOT/'reference-inclusive-timing/cleanup.json');samples=t['samples_ms']
    need(t['passed'] and t['particles']==46726 and len(samples)==20 and all(t[k] for k in ('fresh_independent_CPU_reference_every_batch','reference_generation_charged','reference_gates_charged','commit_charged')) and not t['application_integrated'] and not t['python_force_loop'],'timing scope,20 samples and mandatory reference/check/commit charges')
    need(cl['issue_count']==0 and cl['issues']==[] and cl['resources_released'] and not cl['resources_retained'] and cl['caller_context_restored'],'timing cleanup fields clean')
    for s in samples:
        need(all(isinstance(v,(int,float)) and math.isfinite(v) and v>=0 for v in s.values()),'timing sample finite/nonnegative')
        need(math.isclose(s['force_pipeline_total'],s['native_reference_generation']+s['GPU_API_including_pack_and_gates']+s['commit'],abs_tol=1e-9,rel_tol=1e-12),'timing total includes fresh reference,API and commit')
    summary={k:{'median_ms':statistics.median(s[k] for s in samples),'min_ms':min(s[k] for s in samples),'max_ms':max(s[k] for s in samples)} for k in samples[0]}
    stat=Path('/proc/278902/stat').read_text();tail=stat[stat.rfind(')')+2:].split();cg=Path('/sys/fs/cgroup/powerflow-pic-gpu-reserved/cgroup.events').read_text()
    need(tail[0]=='T' and tail[19]=='5288339' and 'frozen 1' in cg,'current original production hold intact')
    return {'status':'passed_for_bounded_fixed_midpoint_GPU_lifecycle_and_timing_scope','checks':len(checks),'phase_results':phase_results,'device_outputs_exact':exact_outputs,'device_output_records_each':46726,'shared_own_retains_releases':[3,3],'standalone_own_retains_releases':[1,1],'max_manufactured_relative_residual':max(s['relative_residual'] for s in d['solves']),'active_cleanup_sinks':{'shared-lifecycle':['shared','wrong','lost'],'explicit-standalone':['standalone']},'unused_sink_policy':'No issues/no retained resources; unattempted release fields remain false.','timing':{'samples':20,'setup_excluded_ms':t['setup_excluded_ms'],'summary':summary,'scope':t['scope']},'receipt_sha256':hashes,'parent_lease_evidence':str(HERE/'parent-lease-execution-evidence.json'),'dispatch_note':'Shared GPU phase passed before parent checker rejected an unused sink. No GPU repeat; remaining phases ran in a later leased continuation.','limitations':['Original cuDSS implementation uses manufactured Q1 system; no real deposited-charge or evolving PIC replay.','Fixed midpoint force pipeline includes mandatory fresh reference; no integrated application speedup demonstrated.','Driver retain/release/dispatch wrappers cover static backend calls, not dynamic cuDSS/runtime internals.','Timing cleanup JSON serializes fewer fields than lifecycle reports; accepted source and separate standalone lifecycle supply additional coverage.','Real device fault injection was not performed; exceptional failure/quarantine coverage remains CPU mock evidence.'],'gpu_executed_by_reviewer':False,'production_signals_sent':False,'guard_changes':False,'production_hold':{'pid':278902,'state':tail[0],'start_ticks':tail[19],'cgroup_events':cg},'created_unix_s':time.time()}

if __name__=='__main__':
    assert os.sched_getaffinity(0)=={6} and os.getpriority(os.PRIO_PROCESS,0)>=15
    with (PROFILE/'testing-core.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        result=audit()
        (HERE/'gpu-receipt-audit.json').write_text(json.dumps(result,indent=2)+'\n')
        print(json.dumps({'status':result['status'],'checks':result['checks'],'exact_device_outputs':len(result['device_outputs_exact']),'median_force_pipeline_ms':result['timing']['summary']['force_pipeline_total']['median_ms'],'gpu_executed_by_reviewer':False}))
