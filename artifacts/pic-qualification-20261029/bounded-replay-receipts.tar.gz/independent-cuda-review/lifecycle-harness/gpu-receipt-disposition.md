The parent backend-v2 GPU receipts pass independent audit for the bounded shared-primary lifecycle, explicit standalone lifetime, actual fixed-midpoint force correctness, and reference-inclusive force-stage timing. All168 receipt/content checks pass. This adds hardware evidence for that scope; it establishes no evolving PIC replay or end-to-end application speedup.

The accepted42-artifact bundle, command request, executable and core are unchanged. The audit checked parent dispatch/continuation records, executed guarded argv, host pidfd before/child/after observations, affinity/priority, cleanup/refcounts, stage sequence, original residual thresholds, comparison reports, actual device bytes and timing arithmetic. It ran only Python/CPU reads on CPU6/nice15 under testing-core.lock. `audit_gpu_receipts.py` and `gpu-receipt-audit.json` preserve the checks and receipt hashes.

Shared-primary GPU qualification passed:

- The five manufactured Q1 cuDSS solves remain on the original shared primary before, between and after both force calls, explicit force close, wrong-current cleanup and lost-current cleanup. All130,321-row finite solutions pass `residual <= max(1e-30,2e-13*||rhs||2)`. Maximum relative residual is `3.907744042725088e-15`, below the unchanged `2e-13` limit.
- Three backend-owned primary references are retained and released exactly once each:3 retains/3 releases. The original solver primary stays active. Wrong-current and lost-current evaluation reject before any additional asynchronous transfer or launch; cleanup restores the exact wrong/null caller state. A subsequent cuDSS solve succeeds after each probe.
- The active shared/wrong/lost sinks all report context established, stream drained, resources released, caller restored, own reference released, zero issues and no retained resources. There are zero shared-reset or borrowed-context-destroy attempts. The one deliberately owned private context is destroyed after restoring the solver primary.

The separate standalone process also passes. It selects a primary from initial null/current inactive state, completes two checked forces, releases1 own retain with1 release, restores null current context and returns primary activity from0 to0. Its standalone cleanup sink is fully clean, with no reset/destroy attempt.

Unused cleanup sinks are correctly unattempted. In the shared process the standalone sink is unused; in the standalone process shared/wrong/lost are unused. Those sinks have zero issues and no retained resources. Their `resources_released=false`, `stream_drained=false` and similar unset fields are expected because they owned no backend. Requiring those fields to be true was a parent receipt-checker error, not a failed GPU lifecycle or a reason to rerun it. Every active sink remains subject to the complete original cleanup checks.

All five saved device arrays—two shared, two standalone and the timing output—are byte-for-byte equal to the hash-pinned original actual-midpoint `reference.bin`. Each contains46,726 complete E/B/post-kick-proper-velocity records, all finite with status0. All five comparison reports independently record zero component, weighted-velocity and weighted-energy errors. The reviewed harness also checks fresh original provider/Boris references and transactional metadata preservation before declaring success. This verifies the captured midpoint, not changing particles/fields over an integrated timestep.

The timing phase has20 measured samples after3 warmups. Medians are:

| Fixed-midpoint force cost | Median |
| --- | ---: |
| Fresh independent CPU reference |20.163205 ms |
| GPU API including packing, transfers, synchronization and validation |2.564527 ms |
| Transactional velocity commit |0.154632 ms |
| Complete timed force pipeline |22.868514 ms |
| Device kernel, contained within the API time |0.307776 ms |

The actual sample totals equal reference generation + GPU API + commit. Medians of the components need not sum to the median total. Total samples range22.705551–23.453290ms. Setup/initial native loading,677.024495ms, is separately reported and excluded. Fixture reset, native refresh and extra golden instrumentation are also excluded and labeled. All current per-batch reference requirements and backend gates are included. This is not a matched evolving application benchmark; the small kernel time is not an end-to-end speedup, and a CPU6 fixed-state timing or CPU7 application phase average is not an interchangeable control.

All three guarded GPU children exited0, with no stderr or host-guard error. Production identity/start ticks/executable/cgroup matched the original stopped/frozen process in preflight and final observations; guards performed15,11 and16 periodic checks respectively. Affinity was CPU7 and nice15. Parent command evidence shows GPU-then-core7 leases for the initial shared run and the later two-phase continuation. The shared receipt was reused after the checker-only error; there was no duplicate shared GPU run. The phases are separate processes, and accepted artifact/fixture verification remained unchanged across the gap. The parent held no production-resume or application-integration authorization.

Limits remain explicit. The Poisson system is manufactured Q1 at the actual resolution, not the finite-foil deposited-charge solve. Driver audit counts cover statically linked backend calls rather than dynamic cuDSS/runtime internals. Timing cleanup JSON records fewer fields than the lifecycle report; the accepted implementation and separate standalone lifecycle supply additional coverage. Real device error injection was not performed; exception/drain-failure/quarantine coverage remains the27 CPU mock cases. No production promotion, reference-policy removal or runtime-mode change follows from this audit.

Any next step is a separately reviewed evolving full-step candidate with unchanged physics, finite/residual/continuity/resource/timestep guards and a matched saved-state comparator, followed by matched application timing. Production is still T/frozen1. No GPU execution, production signal, resume, guard change or competing-source edit was performed by this reviewer.
