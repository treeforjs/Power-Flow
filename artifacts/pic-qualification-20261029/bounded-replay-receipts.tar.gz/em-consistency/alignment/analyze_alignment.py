import csv,hashlib,json,math
from pathlib import Path

out=Path(__file__).resolve().parent
fixture=Path('/home/treefor/Documents/Codex/2026-10-28/we/outputs/pic-profile/cuda-gather-investigation/actual-midpoint-fixture')
manifest=json.loads((fixture/'manifest.json').read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
expected=json.loads((fixture/'sha256.json').read_text())
verified={n:sha(fixture/n)==h for n,h in expected.items()}
assert all(verified.values()) and manifest['real_midpoint_capture'] and not manifest['synthetic_self_fields']
rows=[]
for raw in csv.DictReader((out/'particles-with-fields.csv').open()):
 r={k:float(v) for k,v in raw.items() if k!='id'};r['id']=int(raw['id'])
 assert all(math.isfinite(v) for v in r.values()) and r['weight']>0
 E=[r[x+'_V_m'] for x in ('Ex','Ey','Ez')];B=[r[x+'_T'] for x in ('Bx','By','Bz')];u=[r[x+'_m_s'] for x in ('ux','uy','uz')]
 Em=math.hypot(*E);Bm=math.hypot(*B);um=math.hypot(*u);assert Em>0 and Bm>0 and um>0
 gamma=math.sqrt(1+(um/299792458.)**2);v=[x/gamma for x in u]
 epar=sum(e*b for e,b in zip(E,B))/Bm;upar=sum(x*b for x,b in zip(u,B))/Bm;mu=max(-1,min(1,upar/um));uperp=math.sqrt(max(0,um*um-upar*upar))
 perpE=math.sqrt(max(0,Em*Em-epar*epar));energy=r['mass_kg']*um*um/(gamma+1)/1.602176634e-19
 x=r['x_m']-.0045;y=r['y_m']-.0045;z=r['z_m']
 def dist_rect(xl,xh,yl,yh):return math.hypot(max(xl-x,0,x-xh),max(yl-y,0,y-yh))
 distance=min(dist_rect(-.0025,.0025,.0025,.0027),dist_rect(-.0025,.0025,-.0027,-.0025))
 edge=min(.0045-abs(x),.0045-abs(y));assert edge>=0
 assert not (-.0025<x<.0025 and (.0025<y<.0027 or -.0027<y<-.0025))
 if x<-.0025:region='left_of_foil_width'
 elif x>.0025:region='right_of_foil_width'
 elif -.0025<=y<=.0025:region='AK_footprint'
 elif y>=.0027:region='upper_back'
 elif y<=-.0027:region='lower_back'
 else:region='surface_or_gap_corner'
 r.update(E_magnitude_V_m=Em,B_magnitude_T=Bm,E_parallel_signed_V_m=epar,E_parallel_abs_V_m=abs(epar),E_perp_V_m=perpE,E_parallel_fraction=abs(epar)/Em,E_parallel_signed_fraction=epar/Em,pitch_angle_deg=math.degrees(math.acos(mu)),pitch_mu=mu,pitch_abs_mu=abs(mu),folded_pitch_deg=math.degrees(math.acos(abs(mu))),pitch_mu2=mu*mu,energy_eV=energy,speed_m_s=um/gamma,v_parallel_m_s=upar/gamma,v_perp_m_s=uperp/gamma,vx_m_s=v[0],vy_m_s=v[1],vz_m_s=v[2],larmor_radius_um=r['mass_kg']*uperp/(abs(r['charge_C'])*Bm)*1e6,E_perp_over_cB=perpE/(299792458.*Bm),outer_boundary_distance_mm=edge*1e3,foil_distance_um=distance*1e6,centered_x_mm=x*1e3,centered_y_mm=y*1e3,z_mm=z*1e3,region=region,instantaneous_work_per_electron_W=r['charge_C']*sum(a*b for a,b in zip(v,E)),parallel_work_per_electron_W=r['charge_C']*(upar/gamma)*epar)
 rows.append(r)
assert len(rows)==manifest['particles']
def quantile(values,weights,q):
 ordered=sorted(zip(values,weights));target=q*sum(weights);acc=0
 for value,w in ordered:
  acc+=w
  if acc>=target:return value
 return ordered[-1][0]
def statistic(group,key,energy_weight=False):
 pairs=[(r[key],r['weight']*(r['energy_eV'] if energy_weight else 1)) for r in group]
 total=sum(w for _,w in pairs)
 return dict(mean=sum(v*w for v,w in pairs)/total,rms=math.sqrt(sum(v*v*w for v,w in pairs)/total),min=min(v for v,_ in pairs),max=max(v for v,_ in pairs),**{f'p{q:02d}':quantile([v for v,_ in pairs],[w for _,w in pairs],q/100) for q in (5,50,95,99)})
metrics=['E_parallel_fraction','E_parallel_abs_V_m','E_magnitude_V_m','B_magnitude_T','pitch_angle_deg','folded_pitch_deg','pitch_abs_mu','pitch_mu2','energy_eV','speed_m_s','v_parallel_m_s','v_perp_m_s','vz_m_s','larmor_radius_um','E_perp_over_cB','outer_boundary_distance_mm','foil_distance_um','z_mm']
def summarize(group):
 if not group:return dict(macro_particles=0,physical_electrons=0)
 weight=sum(r['weight'] for r in group);weight2=sum(r['weight']**2 for r in group)
 result=dict(macro_particles=len(group),physical_electrons=weight,weight_effective_sample_size=weight*weight/weight2,kinetic_energy_J=sum(r['weight']*r['energy_eV']*1.602176634e-19 for r in group),statistics={k:statistic(group,k) for k in metrics})
 result['E_parallel_RMS_fraction']=math.sqrt(sum(r['weight']*r['E_parallel_abs_V_m']**2 for r in group)/sum(r['weight']*r['E_magnitude_V_m']**2 for r in group))
 result['fractions']={f'Eparallel_ratio_gt_{q}':sum(r['weight'] for r in group if r['E_parallel_fraction']>q)/weight for q in (.01,.1,.5,.9)}
 result['fractions'].update({f'pitch_within_{q}deg_of_perpendicular':sum(r['weight'] for r in group if abs(r['pitch_angle_deg']-90)<q)/weight for q in (5,15,30)})
 result['fractions'].update({f'within_{q}um_of_foil':sum(r['weight'] for r in group if r['foil_distance_um']<q)/weight for q in (25,100,500)})
 result['fractions'].update({f'pitch_within_{q}deg_of_either_parallel_direction':sum(r['weight'] for r in group if r['folded_pitch_deg']<q)/weight for q in (5,15,30)})
 result['energy_weighted_Eparallel_fraction']=statistic(group,'E_parallel_fraction',True)
 result['energy_weighted_pitch_mu2']=statistic(group,'pitch_mu2',True)
 result['instantaneous_electric_power_W']=sum(r['weight']*r['instantaneous_work_per_electron_W'] for r in group)
 result['instantaneous_parallel_electric_power_W']=sum(r['weight']*r['parallel_work_per_electron_W'] for r in group)
 return result
groups={'all':rows}
for name in sorted({r['region'] for r in rows}):groups['xy:'+name]=[r for r in rows if r['region']==name]
for name,lo,hi in [('0_25um',0,25),('25_100um',25,100),('100_500um',100,500),('ge500um',500,float('inf'))]:groups['foil_distance:'+name]=[r for r in rows if lo<=r['foil_distance_um']<hi]
for name,lo,hi in [('0_1eV',0,1),('1_10eV',1,10),('10_100eV',10,100),('100_1000eV',100,1000),('1_10keV',1000,10000),('ge10keV',10000,float('inf'))]:groups['energy:'+name]=[r for r in rows if lo<=r['energy_eV']<hi]
groups['z:midplane_1mm']=[r for r in rows if abs(r['z_m'])<.0005]
for name,lo,hi in [('short_half',-.0125,0),('feed_half',0,.0125)]:groups['z:'+name]=[r for r in rows if lo<=r['z_m']<=hi]
results={name:summarize(group) for name,group in groups.items()}
meta=dict(absolute_midpoint_time_ns=manifest['absolute_native_time_s']*1e9,capture_stage=manifest['capture_stage'],original_reference_fields_used=True,pre_kick_velocity_used=True,single_snapshot_not_trajectory=True,fixture_sha256_matches=verified,decoder_validation=json.loads((out/'decode-validation.json').read_text()),Bz_max_abs_T=max(abs(r['Bz_T']) for r in rows),position_extents_m={k:[min(r[k] for r in rows),max(r[k] for r in rows)] for k in ('x_m','y_m','z_m')},zero_E_or_B_or_u_records=0,definitions=dict(Eparallel_ratio='abs(E dot B)/(|E||B|)',pitch='acos(u dot B/(|u||B|)); proper u and ordinary v have the same direction',energy='m |u|^2/(sqrt(1+|u|^2/c^2)+1), divided by e to give eV',weight='represented electron count; all reported means/quantiles/fractions use weight unless energy-weighted explicitly',larmor='m |u_perp|/(|q||B|), local instantaneous scale only',physical_position='centered native coordinates X=xPIC-4.5mm,Y=yPIC-4.5mm; z unchanged'),cpu=6,nice=15,no_new_field_solve=True,no_simulation_advance=True,no_GPU=True)
(out/'alignment-results.json').write_text(json.dumps(dict(metadata=meta,groups=results),indent=2,allow_nan=False)+'\n')
with (out/'region-summary.csv').open('w') as f:
 fields=['region','macro_particles','physical_electrons','fraction_physical','mean_Eparallel_ratio','p95_Eparallel_ratio','mean_pitch_deg','mean_energy_eV','p95_energy_eV','mean_foil_distance_um','mean_outer_boundary_distance_mm'];w=csv.DictWriter(f,fieldnames=fields);w.writeheader();total=results['all']['physical_electrons']
 for name,result in results.items():
  if not result['macro_particles']:continue
  st=result['statistics'];w.writerow(dict(region=name,macro_particles=result['macro_particles'],physical_electrons=result['physical_electrons'],fraction_physical=result['physical_electrons']/total,mean_Eparallel_ratio=st['E_parallel_fraction']['mean'],p95_Eparallel_ratio=st['E_parallel_fraction']['p95'],mean_pitch_deg=st['pitch_angle_deg']['mean'],mean_energy_eV=st['energy_eV']['mean'],p95_energy_eV=st['energy_eV']['p95'],mean_foil_distance_um=st['foil_distance_um']['mean'],mean_outer_boundary_distance_mm=st['outer_boundary_distance_mm']['mean']))
print(json.dumps(dict(time_ns=meta['absolute_midpoint_time_ns'],particles=len(rows),physical_electrons=results['all']['physical_electrons'],groups=len(groups),all_fixture_hashes_match=all(verified.values()))))
