import bisect,csv,hashlib,json
from pathlib import Path

out=Path(__file__).resolve().parent
fields=Path('/home/treefor/projects/Power-Flow/runs/restore_field_mpi8_domain40mm')
outputs=Path('/home/treefor/Documents/Codex/2026-10-28/we/outputs')
rows=lambda p:list(csv.DictReader(p.open()))
snapshots=rows(fields/'em_field_snapshots.csv');times=[float(x['time_s']) for x in snapshots]
diagnostics=rows(fields/'diagnostics.csv');fine_times=[float(x['time_s']) for x in diagnostics]
pulse=rows(outputs/'gap-pulse-midplane110kV.csv');starts=[float(x['start_s']) for x in pulse]
targets=[times[0],times[10],times[21],26.317e-9,26.478e-9,30e-9,40e-9,times[54],60e-9]
def mix(t):
 k=min(max(bisect.bisect_right(fine_times,t)-1,0),len(fine_times)-2)
 a=(t-fine_times[k])/(fine_times[k+1]-fine_times[k])
 return {n:(1-a)*float(diagnostics[k][n])+a*float(diagnostics[k+1][n]) for n in ('foil_gradient_v_m','return_gradient_v_m','target_current_a')}
files={fields/'em_mesh.mesh',fields/'em_axes.csv',fields/'em_field_snapshots.csv',fields/'diagnostics.csv',fields/'source_run.json',fields/'schedule.csv',outputs/'gap-pulse-midplane110kV.csv',outputs/'gap-pulse-midplane110kV.json',outputs/'gap-pulse-220kV-anchored.json',outputs/'electron-heating-pic-25um-full60ns-gpu-midplane110kV-height25mm/frame_0.csv',Path('/home/treefor/projects/Power-Flow/native/mfem_edge_source/edge_driver.cpp'),Path('/home/treefor/projects/runtimes/mfem-gpu-pic-20261029/source/examples/native_heating_fields.hpp'),Path('/home/treefor/projects/runtimes/mfem-gpu-pic-20261029/source/examples/mfem_heating_history_pic.cpp')}
summary=[]
with (out/'queries.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['time_s','upper_gradient_coarse_V_m','lower_gradient_coarse_V_m','PIC_upper_potential_V'])
 for t in targets:
  k=min(max(bisect.bisect_right(times,t+32*2.220446049250313e-16*max(abs(t),1e-12))-1,0),len(times)-2)
  a=min(max((t-times[k])/(times[k+1]-times[k]),0),1);d0=mix(times[k]);d1=mix(times[k+1]);dm=mix(t)
  gu=(1-a)*d0['foil_gradient_v_m']+a*d1['foil_gradient_v_m'];gl=(1-a)*d0['return_gradient_v_m']+a*d1['return_gradient_v_m']
  v=float(pulse[min(max(bisect.bisect_right(starts,t)-1,0),len(pulse)-1)]['upper_potential_V'])
  w.writerow([format(t,'.17g'),format(gu,'.17g'),format(gl,'.17g'),format(v,'.17g')])
  for i in (k,k+1):files.update([fields/snapshots[i]['potential_file'],fields/snapshots[i]['rate_file']])
  summary.append(dict(time_ns=t*1e9,t0_ns=times[k]*1e9,t1_ns=times[k+1]*1e9,fraction=a,Vmid_V=v,PIC_upper_scalar_gradient_V_m=-v/.025,PIC_lower_scalar_gradient_V_m=v/.025,heating_upper_gradient_coarse_V_m=gu,heating_lower_gradient_coarse_V_m=gl,heating_common_gradient_coarse_V_m=(gu+gl)/2,heating_upper_gradient_fine_interpolated_V_m=dm['foil_gradient_v_m'],heating_lower_gradient_fine_interpolated_V_m=dm['return_gradient_v_m'],target_current_coarse_A=(1-a)*d0['target_current_a']+a*d1['target_current_a'],target_current_fine_interpolated_A=dm['target_current_a']))
(out/'drive_comparison.json').write_text(json.dumps(summary,indent=2)+'\n')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
manifest={str(p):sha(p) for p in sorted(files)}
(out/'input-hashes-before.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(dict(queries=len(summary),input_files=len(manifest))))
