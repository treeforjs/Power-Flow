#!/usr/bin/env python3
"""Small manufactured fixtures only. No solver, driver, or GPU invocation."""
import copy, hashlib, json, math, shutil, struct, time
from pathlib import Path
import numpy as np
import compare_traces as c

ROOT=c.HERE/'manufactured-tests'
def dump(path,value):path.write_text(json.dumps(value,allow_nan=False)+'\n')
def write_meta(path,step,clock):
    lines=['checkpoint_'+str(step)+'.bin '+str(step)+' 0']
    for i in range(4):lines+=['0','0 0','0 0']
    lines+=[str(clock)+' -1']
    path.write_text('\n'.join(lines)+'\n')
def header(abi,local):
    options=bytearray(168)
    values={'nx':1,'ny':1,'width_m':1.,'gap_m':1.,'depth_m':1.,'lower_potential_V':0.,'upper_potential_V':-1.,'distributed_fields':False,'finite_foils':False,'finite_axial_extent':False}
    for f in abi['options']:struct.pack_into('<'+{'f64':'d','i32':'i','bool':'B'}[f['kind']],options,f['offset'],values.get(f['name'],0))
    diag=diagnostics(local);diag['particle_kinetic_energy_J']=0
    return struct.pack('<Q',0x5241494b50494332)+options+struct.pack('<25d',*(diag[k] for k in c.DIAG))+struct.pack('<QQ',3,2)
def particles():
    p=np.zeros(2,dtype=c.PTYPE);p['id']=[1,2];p['x']=[[.25,.25,0],[.75,.75,0]];p['u']=[[1e5,0,0],[0,1e5,0]];p['q']=-c.E;p['m']=9.1093837e-31;p['w']=1
    return p
def diagnostics(local):
    d=dict.fromkeys(c.DIAG,0.);d.update(time_s=local,particle_charge_C=-2*c.E,deposited_charge_C=-2*c.E,lower_field_charge_C=c.E,upper_field_charge_C=c.E,field_energy_J=1e-12,authored_charge_C=-2*c.E,poisson_residual_C_per_m=1e-25)
    d['particle_kinetic_energy_J']=2*9.1093837e-31*1e10/(math.sqrt(1+1e10/c.C**2)+1)
    return d
def records():
    result=[]
    for i in range(2):
        local=(i+1)*1e-15
        result.append({'step':11+i,'dt':1e-15,'d':diagnostics(local),'p':particles(),'phi':np.array([0.,-.5,-.5,-1.]),'h':np.array([1e-20,0]),'v':np.array([0,1e-20]),'spans':np.full(4,local),'pools':[(np.array([1e-24,2e-24]),np.array([3e-22,6e-22])) for j in range(4)]})
    return result
def write_trace(root,rs,mode):
    data=bytearray()
    for r in rs:
        data+=struct.pack('<QQd',c.MAGIC,r['step'],r['dt'])+struct.pack('<25d',*(r['d'][k] for k in c.DIAG))
        data+=struct.pack('<4Q',len(r['p']),len(r['phi']),len(r['h']),len(r['v']))+r['p'].tobytes()+r['phi'].tobytes()+r['h'].tobytes()+r['v'].tobytes()+r['spans'].tobytes()
        for q,t in r['pools']:data+=struct.pack('<Q',len(q))+q.tobytes()+t.tobytes()
    (root/'evolving-state.bin').write_bytes(data)
    dump(root/'force-cleanup.json',{'passed':True,'mode':mode,'optimized_mode_is_unqualified_candidate':True,'deployment_authorized':False,'production_resume_authorized':False,'steps_recorded':len(rs),'trace_bytes':len(data),'static_uploads':1 if mode else 0,'attempted':bool(mode),'context_established':bool(mode),'stream_drained':bool(mode),'resources_released':bool(mode),'resources_retained':False,'caller_context_restored':bool(mode),'primary_reference_released':bool(mode),'issue_count':0,'issues':[],'original_error':''})
    stage=[','.join(c.STAGES)]
    prior=0.
    for r in rs:
        v=dict.fromkeys(c.STAGES,0.);v.update(relative_midpoint_s=prior+.5*r['dt'],dt_s=r['dt'],mode=mode,whole_force_ms=.1)
        if mode:v.update(lower_frame=1,upper_frame=2,voltage_V=-1.,fraction=.5)
        stage.append(','.join(str(v[k]) for k in c.STAGES));prior=r['d']['time_s']
    (root/'force-stages.csv').write_text('\n'.join(stage)+'\n')
def fixtures(root,policy,abi):
    root.mkdir();seed=root/'seed';seed.mkdir();(seed/'.manufactured-fixture').write_text('Manufactured comparator contract data. No simulation.\n')
    ck=seed/'checkpoint_10.bin';ck.write_bytes(header(abi,0)+particles().tobytes());write_meta(seed/'restart.meta',10,0.)
    identity={'production':'manufactured-only','start_ns':1.,'checkpoint':'checkpoint_10.bin','checkpoint_sha256':c.sha(ck)};dump(seed/'seed.json',identity)
    for mode,name in enumerate(['off','shadow','optimized']):
        p=root/name;p.mkdir();dump(p/'seed.json',identity);dump(p/'trace-schema.json',c.SCHEMA);write_trace(p,records(),mode)
        dump(p/'progress.json',{'phase':'completed','steps':12,'macro_particles':2,'mpi_ranks':1,'accepted_time_s':1e-9+2e-15,'requested_end_time_s':1e-9+2e-15,'start_time_s':1e-9,'upper_potential_V':-1.,'source_reservoir_electrons':1.})
        (p/'checkpoint_12.bin').write_bytes(header(abi,2e-15)+particles().tobytes());write_meta(p/'restart.meta',12,2e-15)
    receipts(root,policy)
def receipts(root,policy):
    for name in ['shadow','optimized']:
        a,b,seed=root/'off',root/name,root/'seed'
        paths=[seed/'checkpoint_10.bin']+[p/n for p in [a,b] for n in ['progress.json','restart.meta','checkpoint_12.bin']]
        dump(root/(name+'-comparison.json'),{'status':'passed','comparison_complete':True,'policy':policy,'failures':[],'paths':{'baseline':str(a),'candidate':str(b),'seed':str(seed)},'input_manifest':[{'path':str(p),'sha256':c.sha(p)} for p in paths],
           'runtime_residual_guards':{k:{'guard_passed':True,'rhs_norm':1e-10,'residual_norm':1e-25,'guard_limit':2e-23} for k in ['off',name,'seed']}})
def run(root,opt=True):
    with np.errstate(over='raise',invalid='raise',divide='raise'):
        return c.compare(root/'off',root/'shadow',root/'optimized',root/'seed',root/'shadow-comparison.json',root/'optimized-comparison.json',opt)
def main():
    require=lambda x,msg: (_ for _ in ()).throw(AssertionError(msg)) if not x else None
    require(not ROOT.exists(),'manufactured output already exists')
    ROOT.mkdir();policy,abi=c.reference({});base=ROOT/'base';fixtures(base,policy,abi)
    tests=[]
    def case(name,mutate=None,expect='invalid',refresh=True):
        p=ROOT/name;shutil.copytree(base,p)
        # Rebase all receipt paths; never point a negative test at another case.
        if mutate:mutate(p)
        if refresh:receipts(p,policy)
        started=time.monotonic()
        try:r=run(p);actual=r['status'];error='';complete=r['comparison_complete']
        except (c.Invalid,ValueError,OSError,KeyError,TypeError,IndexError,ZeroDivisionError,OverflowError,struct.error,FloatingPointError) as e:actual='invalid';error=str(e);complete=False
        require(actual==expect,name+': expected '+expect+', got '+actual+' '+error)
        tests.append({'name':name,'expected':expect,'status':actual,'comparison_complete':complete,'error':error,'wall_s':time.monotonic()-started})
    def change_vector(p,key,index,value):
        rs=records();rs[0][key][index]=value;write_trace(p/'optimized',rs,2)
    def change_particle(p,key,index,value):
        rs=records();rs[0]['p'][key][index]=value;write_trace(p/'optimized',rs,2)
    def mutate_json(p,name,key,value):
        f=p/name;d=json.loads(f.read_text());d[key]=value;dump(f,d)
    case('identical',expect='passed')
    case('within_position_budget',lambda p:change_particle(p,'x',(0,0),.25+5e-13),expect='passed')
    case('position_violation',lambda p:change_particle(p,'x',(0,0),.25+2e-12),expect='failed')
    case('velocity_violation',lambda p:change_particle(p,'u',(0,0),1e5+2e-5),expect='failed')
    case('phi_violation',lambda p:change_vector(p,'phi',0,3e-10),expect='failed')
    case('edge_violation',lambda p:change_vector(p,'h',0,1.01e-20),expect='failed')
    def diagnostic(p,key,value):
        rs=records();rs[0]['d'][key]=value;write_trace(p/'optimized',rs,2)
    case('ledger_violation',lambda p:diagnostic(p,'field_energy_J',1e-12+1e-22),expect='failed')
    case('nonfinite_ledger',lambda p:diagnostic(p,'field_energy_J',float('nan')))
    case('nonfinite_phi',lambda p:change_vector(p,'phi',0,float('nan')))
    case('nonfinite_velocity',lambda p:change_particle(p,'u',(0,0),float('inf')))
    case('overflow_velocity',lambda p:change_particle(p,'u',(0,0),1e200))
    case('particle_id',lambda p:change_particle(p,'id',0,5))
    case('duplicate_id',lambda p:change_particle(p,'id',0,2))
    case('charge_exact',lambda p:change_particle(p,'q',0,np.nextafter(-c.E,0)))
    case('mass_exact',lambda p:change_particle(p,'m',0,np.nextafter(9.1093837e-31,1)))
    case('weight_exact',lambda p:change_particle(p,'w',0,np.nextafter(1.,2)))
    def source(p):
        rs=records();rs[0]['pools'][0][0][0]=np.nextafter(1e-24,2e-24);write_trace(p/'optimized',rs,2)
    case('source_reservoir_exact',source)
    def timestep(p):
        rs=records();rs[0]['dt']=np.nextafter(1e-15,1.);write_trace(p/'optimized',rs,2)
    case('timestep_exact',timestep)
    def step(p):
        rs=records();rs[1]['step']+=1;write_trace(p/'optimized',rs,2)
    case('missing_step',step)
    def bytes_change(p,kind):
        f=p/'optimized/evolving-state.bin';data=f.read_bytes();data=data[:-1] if kind=='truncate' else data+b'x';f.write_bytes(data)
        mutate_json(p,'optimized/force-cleanup.json','trace_bytes',len(data))
    case('truncated_record',lambda p:bytes_change(p,'truncate'))
    case('trailing_byte',lambda p:bytes_change(p,'trailer'))
    case('missing_trace',lambda p:(p/'optimized/evolving-state.bin').unlink())
    case('missing_cleanup',lambda p:(p/'optimized/force-cleanup.json').unlink())
    case('failed_cleanup',lambda p:mutate_json(p,'optimized/force-cleanup.json','passed',False))
    case('retained_resources',lambda p:mutate_json(p,'optimized/force-cleanup.json','resources_retained',True))
    case('partial_progress',lambda p:mutate_json(p,'optimized/progress.json','phase','running'))
    def all_partial(p):
        for mode,name in enumerate(['off','shadow','optimized']):
            write_trace(p/name,records()[:1],mode);mutate_json(p,name+'/progress.json','steps',11);mutate_json(p,name+'/progress.json','accepted_time_s',1e-9+1e-15)
    case('matching_partial_traces',all_partial)
    def stage_missing(p):
        f=p/'optimized/force-stages.csv';f.write_text('\n'.join(f.read_text().splitlines()[:1])+'\n')
    case('missing_stage_rows',stage_missing)
    def duplicate_json(p):
        f=p/'optimized/trace-schema.json';f.write_text(f.read_text().rstrip()[:-1]+',"version":3}\n')
    case('duplicate_json_key',duplicate_json)
    case('schema_mismatch',lambda p:mutate_json(p,'optimized/trace-schema.json','particle_bytes',72))
    def missing_receipt(p):
        receipts(p,policy);(p/'optimized-comparison.json').unlink()
    case('missing_receipt',missing_receipt,refresh=False)
    def bad_receipt(p):
        receipts(p,policy);mutate_json(p,'optimized-comparison.json','status','failed')
    case('failed_receipt',bad_receipt,refresh=False)
    def changed_input(p):
        receipts(p,policy);(p/'optimized/checkpoint_12.bin').write_bytes(b'changed')
    case('saved_state_hash_mismatch',changed_input,refresh=False)
    # Default invocation cannot accidentally label contract data as real qualification.
    try:run(base,False);raise AssertionError('manufactured default rejection absent')
    except c.Invalid as e:tests.append({'name':'manufactured_default_rejected','status':'invalid','error':str(e)})
    report={'status':'passed','manufactured_only':True,'GPU_or_solver_execution':False,'cases':tests,'case_count':len(tests),'affinity':list(c.os.sched_getaffinity(0)),'nice':c.os.nice(0),'max_RSS_KiB':c.resource.getrusage(c.resource.RUSAGE_SELF).ru_maxrss}
    dump(c.HERE/'tests.json',report);print(json.dumps({k:report[k] for k in ['status','case_count','GPU_or_solver_execution','max_RSS_KiB']}))
if __name__=='__main__':main()
