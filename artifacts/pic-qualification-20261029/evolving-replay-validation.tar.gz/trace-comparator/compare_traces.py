#!/usr/bin/env python3
"""Streaming read-only comparison of three completed evolving-force v3 traces."""
import argparse, ast, contextlib, csv, datetime, fcntl, hashlib, json, math, os
from pathlib import Path
import resource, struct, sys, time
import numpy as np

HERE=Path(__file__).resolve().parent
REFERENCE=Path('/home/treefor/Documents/Codex/2026-10-28/we/outputs/pic-profile/cpu-independent-review/checkpoint-validation-v2')
LEASE=HERE.parent/'testing-core.lock'
MAGIC=0x5049435354455033
MAX_BYTES=2*1024**3
MAX_STEPS=256
MAX_PARTICLES=65536
EPS=sys.float_info.epsilon
E=1.602176634e-19
C=299792458.
DIAG='time_s particle_charge_C deposited_charge_C lower_field_charge_C upper_field_charge_C gauss_defect_C particle_charge_defect_C field_energy_J particle_kinetic_energy_J lower_absorbed_charge_C upper_absorbed_charge_C lower_absorbed_energy_J upper_absorbed_energy_J lower_injected_charge_C upper_injected_charge_C injected_energy_J authored_charge_C authored_kinetic_energy_J maximum_nodal_continuity_defect_C escaped_charge_C escaped_kinetic_energy_J short_absorbed_charge_C short_absorbed_energy_J axial_escaped_charge_C poisson_residual_C_per_m'.split()
STAGES='relative_midpoint_s dt_s mode reference_ms GPU_API_ms commit_ms whole_force_ms lower_frame upper_frame voltage_V fraction comparison_failures max_E_error max_B_error max_u_error weighted_u_error weighted_energy_error'.split()
ORDER='uint64 magic0x5049435354455033, uint64 step, double dt, raw GapPicDiagnostics, uint64 particle_count/phi_count/horizontal_count/vertical_count, raw GapParticle[], double phi[], horizontal[], vertical[], four double reservoir spans, four repetitions of uint64 size/double integral[]/double weighted_temperature[]'
SCHEMA={'version':3,'endian':'little','particle_bytes':80,'diagnostics_bytes':200,'record_order':ORDER}
PTYPE=np.dtype([('id','<u8'),('x','<f8',(3,)),('u','<f8',(3,)),('q','<f8'),('m','<f8'),('w','<f8')])

class Invalid(ValueError): pass
def require(ok,message):
    if not ok: raise Invalid(message)
def finite(x,label):
    require(type(x) in (int,float) and math.isfinite(x),label+': nonfinite or nonnumeric')
    return x
def signature(path):
    s=path.stat();return (s.st_dev,s.st_ino,s.st_size,s.st_mtime_ns,s.st_ctime_ns)
def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1024**2),b''):h.update(block)
    return h.hexdigest()
def strict_json(path,tracked):
    require(path.is_file(),str(path)+': missing file')
    require(path.stat().st_size<=16*1024**2,str(path)+': JSON exceeds 16 MiB metadata bound')
    before=signature(path);data=path.read_bytes()
    def pairs(items):
        d={}
        for k,v in items:require(k not in d,str(path)+': duplicate JSON key '+k);d[k]=v
        return d
    def bad(x):raise Invalid(str(path)+': nonfinite JSON '+x)
    value=json.loads(data,object_pairs_hook=pairs,parse_constant=bad)
    def check(v):
        if isinstance(v,float):finite(v,str(path))
        elif isinstance(v,dict):
            for x in v.values():check(x)
        elif isinstance(v,list):
            for x in v:check(x)
    check(value);require(signature(path)==before,str(path)+': changed during read')
    tracked[path]={'sha256':hashlib.sha256(data).hexdigest(),'signature':before}
    return value

def reference(tracked):
    provenance=strict_json(HERE/'reference-lock.json',tracked)
    for name in ['compare_saved_pic.py','abi-schema.json']:
        path=REFERENCE/name
        require(sha(path)==provenance[name],str(path)+': established policy source changed')
        tracked[path]={'sha256':provenance[name],'signature':signature(path)}
    module=ast.parse((REFERENCE/'compare_saved_pic.py').read_text())
    policy=next(ast.literal_eval(n.value) for n in module.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='POLICY' for t in n.targets))
    require(policy==provenance['policy'],'policy lock differs from established policy')
    abi=strict_json(REFERENCE/'abi-schema.json',tracked)
    require((abi['endian'],abi['options_size'],abi['particle_size'],abi['diagnostics_size'])==('little',168,80,200),'unsupported ABI')
    require([x['name'] for x in abi['diagnostics']]==DIAG,'diagnostic ABI names/order changed')
    require([x['offset'] for x in abi['diagnostics']]==list(range(0,200,8)),'diagnostic offsets changed')
    require([x['offset'] for x in abi['particle']]==list(range(0,80,8)),'particle offsets changed')
    return policy,abi

def decode_options(data,abi):
    o={}
    for f in abi['options']:
        value=struct.unpack_from('<'+{'f64':'d','i32':'i','bool':'B'}[f['kind']],data,f['offset'])[0]
        finite(value,'seed option '+f['name'])
        if f['kind']=='bool':require(value in (0,1),'invalid option bool')
        o[f['name']]=value
    require(type(o['nx']) is int and type(o['ny']) is int and 1<=o['nx']<=4096 and 1<=o['ny']<=4096,'invalid seed grid')
    require((o['nx']+1)*(o['ny']+1)<=1000000,'seed mesh exceeds bounded comparator memory')
    require(all(o[k]>0 for k in ['width_m','gap_m','depth_m']),'invalid seed dimensions')
    return o

def seed_state(root,abi,tracked,allow_manufactured=False):
    root=root.resolve();marker=root/'.manufactured-fixture'
    require(allow_manufactured or not marker.exists(),'manufactured fixture requires explicit test opt-in')
    ident=strict_json(root/'seed.json',tracked)
    require(set(ident)=={'production','start_ns','checkpoint','checkpoint_sha256'},'unexpected seed identity schema')
    finite(ident['start_ns'],'seed start_ns')
    meta=root/'restart.meta';require(meta.stat().st_size<=512*1024,'oversized seed metadata')
    before=signature(meta);text=meta.read_text().splitlines()
    require(len(text)==14,'seed metadata incomplete')
    h=text[0].split();require(len(h)==3,'invalid seed header')
    step=int(h[1]);require(step>=0 and h[0]=='checkpoint_'+str(step)+'.bin','invalid seed step')
    require(ident['checkpoint']==h[0],'seed checkpoint identity mismatch')
    pools=[]
    for i in range(4):
        span=[float(x) for x in text[1+3*i].split()]
        q=np.array([float(x) for x in text[2+3*i].split()]);t=np.array([float(x) for x in text[3+3*i].split()])
        require(len(span)==1 and math.isfinite(span[0]) and span[0]>=0,'invalid seed source span')
        reservoir(q,t);pools.append(len(q))
    tail=text[-1].split();require(len(tail)==2,'seed metadata tail missing')
    local,voltage=map(float,tail);finite(local,'seed clock');finite(voltage,'seed voltage')
    require(signature(meta)==before,'seed metadata changed')
    tracked[meta]={'sha256':sha(meta),'signature':before}
    ck=root/h[0];require(ck.is_file(),'missing seed checkpoint')
    require(392<=ck.stat().st_size<=392+MAX_PARTICLES*80,'seed checkpoint exceeds bounded trace capacity')
    before=signature(ck);digest=hashlib.sha256();qabs=0.;kinetic=0.
    with ck.open('rb') as f:
        head=f.read(392);digest.update(head)
        require(len(head)==392 and struct.unpack_from('<Q',head)[0]==0x5241494b50494332,'invalid seed checkpoint header')
        o=decode_options(head[8:176],abi);d=dict(zip(DIAG,struct.unpack_from('<25d',head,176)))
        for key,value in d.items():finite(value,'seed '+key)
        next_id,count=struct.unpack_from('<QQ',head,376)
        require(1<=next_id and count<=MAX_PARTICLES and ck.stat().st_size==392+count*80,'invalid seed count/length')
        for i in range(count):
            data=f.read(80);digest.update(data);p=struct.unpack('<Q9d',data)
            require(0<p[0]<next_id and all(math.isfinite(x) for x in p[1:]) and p[8]>0 and p[9]>0,'invalid seed particle')
            qabs+=abs(p[7]*p[9]);u2=sum(x*x for x in p[4:7])
            kinetic+=p[8]*u2/(math.sqrt(1+u2/(C*C))+1)*p[9]
        require(not f.read(1),'seed trailing bytes')
    require(signature(ck)==before and digest.hexdigest()==ident['checkpoint_sha256'],'seed checkpoint hash mismatch/changed')
    tracked[ck]={'sha256':digest.hexdigest(),'signature':before}
    d['particle_kinetic_energy_J']+=kinetic
    d['particle_charge_defect_C']=(d['particle_charge_C']+d['lower_absorbed_charge_C']+d['upper_absorbed_charge_C']+d['short_absorbed_charge_C']-d['lower_injected_charge_C']-d['upper_injected_charge_C']-d['authored_charge_C']+d['escaped_charge_C'])
    require(local==d['time_s'] and voltage==o['upper_potential_V'],'seed clocks/voltage mismatch')
    return {'root':root,'identity':ident,'step':step,'diagnostics':d,'qabs':qabs,'options':o,'pool_sizes':pools,'count':count}

def reservoir(q,t):
    require(1<=len(q)<=4096 and len(q)==len(t),'invalid reservoir shape')
    require(np.isfinite(q).all() and np.isfinite(t).all() and (q>=0).all() and (t>=0).all(),'nonfinite/negative reservoir')
    positive=q>0
    require((t[~positive]==0).all() and (t[positive]>0).all(),'invalid zero reservoir/temperature')
    require((t[positive]/q[positive]<=1e6).all(),'invalid reservoir weighted temperature')

class Trace:
    def __init__(self,root,mode,seed,tracked):
        self.root=root.resolve();self.mode=mode;self.path=self.root/'evolving-state.bin';self.seed=seed
        require(strict_json(self.root/'trace-schema.json',tracked)==SCHEMA,'unsupported/incomplete trace schema')
        self.cleanup=strict_json(self.root/'force-cleanup.json',tracked)
        c=self.cleanup
        require(c['passed'] is True and c['mode']==mode and type(c['mode']) is int,'failed cleanup/wrong mode')
        require(c['deployment_authorized'] is False and c['production_resume_authorized'] is False and c['optimized_mode_is_unqualified_candidate'] is True,'unexpected candidate authorization metadata')
        require(c['issue_count']==0 and c['issues']==[] and c['original_error']=='','cleanup issues/original failure')
        require(c['resources_retained'] is False,'retained force resources')
        if c['attempted']:
            require(all(c[k] is True for k in ['context_established','stream_drained','resources_released','caller_context_restored','primary_reference_released']),'incomplete active cleanup')
        require(type(c['steps_recorded']) is int and 1<=c['steps_recorded']<=MAX_STEPS,'invalid cleanup step bound')
        require(type(c['trace_bytes']) is int and self.path.is_file() and 0<c['trace_bytes']==self.path.stat().st_size<=MAX_BYTES,'missing/oversize/partial trace')
        self.progress=strict_json(self.root/'progress.json',tracked)
        p=self.progress
        require(p['phase']=='completed' and type(p['steps']) is int and type(p['macro_particles']) is int and p['mpi_ranks']==1,'run incomplete/invalid progress')
        for k in ['accepted_time_s','requested_end_time_s','start_time_s','upper_potential_V','source_reservoir_electrons']:finite(p[k],'progress '+k)
        require(p['steps']==seed['step']+c['steps_recorded'],'cleanup/progress step mismatch')
        identity=strict_json(self.root/'seed.json',tracked)
        require(identity==seed['identity'],'run seed identity mismatch')
        self.before=signature(self.path);self.f=self.path.open('rb');self.digest=hashlib.sha256();self.bytes=0;self.count=0
        self.last_time=seed['diagnostics']['time_s'];self.nonempty=False
        self.stagepath=self.root/'force-stages.csv';require(self.stagepath.is_file(),'missing force stage trace')
        require(self.stagepath.stat().st_size<=2*1024**2,'force-stage metadata exceeds bound')
        self.stage_before=signature(self.stagepath);data=self.stagepath.read_text()
        tracked[self.stagepath]={'sha256':sha(self.stagepath),'signature':self.stage_before}
        require(signature(self.stagepath)==self.stage_before,'force stage file changed')
        parsed=csv.reader(data.splitlines());require(next(parsed,None)==STAGES,'invalid force-stage columns')
        self.stages=[]
        for row in parsed:
            require(len(row)==len(STAGES),'truncated force-stage row')
            values=dict(zip(STAGES,map(float,row)))
            for k,x in values.items():finite(x,'force-stage '+k)
            require(values['mode']==mode and values['dt_s']>0,'stage mode/dt mismatch')
            require(all(values[k]>=0 for k in STAGES if k not in ['relative_midpoint_s','voltage_V']),'negative stage timing/error/metadata')
            require(values['comparison_failures']==0,'failed shadow reference comparison')
            require(all(values[k].is_integer() for k in ['mode','lower_frame','upper_frame','comparison_failures']),'nonintegral stage metadata')
            require(values['fraction']<=1,'invalid native fraction')
            require(not self.stages or values['relative_midpoint_s']>self.stages[-1]['relative_midpoint_s'],'duplicate/nonmonotonic stage time')
            self.stages.append(values)
        require(len(self.stages)<=c['steps_recorded'],'too many force-stage rows');self.stage_index=0
    def read(self,size):
        require(0<=size<=MAX_BYTES-self.bytes,'trace allocation/byte budget exceeded')
        data=self.f.read(size);self.digest.update(data);self.bytes+=len(data)
        require(len(data)==size,str(self.path)+': truncated record at byte '+str(self.bytes))
        return data
    def array(self,count):return np.frombuffer(self.read(8*count),dtype='<f8')
    def record(self):
        require(self.count<self.cleanup['steps_recorded'],'trace record count exceeded')
        magic,step,dt=struct.unpack('<QQd',self.read(24))
        require(magic==MAGIC and step==self.seed['step']+self.count+1,'bad magic/skipped/duplicate step')
        finite(dt,'dt');require(dt>0,'nonpositive timestep')
        d=dict(zip(DIAG,struct.unpack('<25d',self.read(200))))
        for k,x in d.items():finite(x,'diagnostics '+k)
        require(d['time_s']==self.last_time+dt,'trace local time does not advance by exact recorded dt')
        for k,x in d.items():
            if 'energy_J' in k or k in ['maximum_nodal_continuity_defect_C','poisson_residual_C_per_m']:require(x>=0,'negative diagnostic '+k)
        n,nphi,nh,nv=struct.unpack('<4Q',self.read(32));o=self.seed['options'];nx,ny=o['nx'],o['ny']
        require(n<=MAX_PARTICLES and (nphi,nh,nv)==((nx+1)*(ny+1),nx*(ny+1),(nx+1)*ny),'trace dimensions/capacity mismatch')
        p=np.frombuffer(self.read(n*80),dtype=PTYPE)
        require(np.isfinite(p.view('<f8').reshape(-1,10)[:,1:]).all(),'nonfinite particle')
        require((p['id']>0).all() and len(np.unique(p['id']))==n,'duplicate/zero particle ID')
        require((p['m']>0).all() and (p['w']>0).all(),'nonpositive mass/weight')
        require(np.isfinite(p['q']/p['m']).all() and np.isfinite(p['q']*p['w']).all(),'invalid represented charge/qm')
        u2=np.sum(p['u']*p['u'],axis=1)
        kinetic=p['m']*u2/(np.sqrt(1+u2/(C*C))+1)*p['w']
        require(np.isfinite(u2).all() and np.isfinite(kinetic).all(),'invalid proper velocity norm/weighted kinetic energy')
        x=p['x'];require(((x[:,0]>=0)&(x[:,0]<=o['width_m'])&(x[:,1]>=0)&(x[:,1]<=o['gap_m'])).all(),'particle outside transverse domain')
        if o['finite_axial_extent']:require(((x[:,2]>=o['short_z_m'])&(x[:,2]<=o['feed_z_m'])).all(),'particle outside axial domain')
        if o['finite_foils']:
            for foil in ['lower_foil','upper_foil']:
                require(not ((x[:,0]>o[foil+'.left_m'])&(x[:,0]<o[foil+'.right_m'])&(x[:,1]>o[foil+'.bottom_m'])&(x[:,1]<o[foil+'.top_m'])).any(),'particle in conductor')
        phi,h,v=self.array(nphi),self.array(nh),self.array(nv)
        require(all(np.isfinite(a).all() for a in [phi,h,v]),'nonfinite phi/edge transfers')
        spans=self.array(4);require(np.isfinite(spans).all() and (spans>=0).all(),'invalid reservoir spans')
        pools=[]
        for i in range(4):
            size=struct.unpack('<Q',self.read(8))[0];require(size==self.seed['pool_sizes'][i],'source patch size changed')
            q,t=self.array(size),self.array(size);reservoir(q,t);pools.append((q,t))
        stage=None;mid=self.last_time+.5*dt
        if self.stage_index<len(self.stages):
            next_stage=self.stages[self.stage_index]
            require(next_stage['relative_midpoint_s']>=mid,'unmatched/early force stage')
            if next_stage['relative_midpoint_s']==mid:
                stage=next_stage;self.stage_index+=1;require(stage['dt_s']==dt,'force/trace timestep mismatch')
        require(not n or stage is not None,'missing force-stage row for populated accepted state')
        if n and self.mode:
            require(stage['upper_frame']==stage['lower_frame']+1,'invalid selected frame pair')
        self.last_time=d['time_s'];self.count+=1;self.nonempty|=n>0
        return {'step':step,'dt':dt,'d':d,'p':p,'phi':phi,'h':h,'v':v,'spans':spans,'pools':pools,'stage':stage,'qabs':float(np.sum(np.abs(p['q']*p['w'])))}
    def finish(self,tracked,policy):
        require(self.count==self.cleanup['steps_recorded'] and not self.f.read(1),'trailing bytes/partial trace')
        require(self.bytes==self.cleanup['trace_bytes'] and self.stage_index==len(self.stages),'byte/stage count mismatch')
        require(signature(self.path)==self.before,'trace changed during streaming comparison')
        tracked[self.path]={'sha256':self.digest.hexdigest(),'signature':self.before}
        require(not (self.mode and self.nonempty) or self.cleanup['attempted'] is True,'populated active run has no cleanup attempt')
        p=self.progress;tol=max(1e-23,policy['time_roundoff_factor']*EPS*abs(self.last_time))
        global_end=p['start_time_s']+self.last_time
        require(abs(global_end-p['accepted_time_s'])<=tol and abs(p['accepted_time_s']-p['requested_end_time_s'])<=tol,'partial/noncompleted trace endpoint')
        elapsed=self.last_time-self.seed['diagnostics']['time_s']
        require(0<elapsed<=1.00000001e-12,'trace outside bounded one-ps scope')
        require(abs((p['start_time_s']+self.seed['diagnostics']['time_s'])-self.seed['identity']['start_ns']*1e-9)<=tol,'trace/seed global start mismatch')
        self.f.close()
    def close(self):
        if hasattr(self,'f'):self.f.close()

def receipt(path,a,b,seed,policy,tracked):
    r=strict_json(path.resolve(),tracked)
    require(r['status']=='passed' and r['comparison_complete'] is True and r['failures']==[],'saved-state comparison has not passed')
    require(r['policy']==policy,'saved-state comparison tolerance policy mismatch')
    require(Path(r['paths']['baseline']).resolve()==a.resolve() and Path(r['paths']['candidate']).resolve()==b.resolve() and Path(r['paths']['seed']).resolve()==seed['root'],'saved-state comparison paths mismatch')
    manifest=r['input_manifest'];require(isinstance(manifest,list) and len(manifest)>0,'saved-state input hashes absent')
    seen=set()
    for x in manifest:
        p=Path(x['path']).resolve();require(p not in seen,'duplicate saved-state input path');seen.add(p)
        require(p.is_file(),'missing saved-state input '+str(p));before=signature(p)
        require(sha(p)==x['sha256'] and signature(p)==before,'saved-state input changed: '+str(p))
        tracked[p]={'sha256':x['sha256'],'signature':before}
    require(seed['root']/seed['identity']['checkpoint'] in seen,'saved-state receipt lacks exact seed checkpoint')
    for root in [a.resolve(),b.resolve()]:
        require(root/'restart.meta' in seen and root/'progress.json' in seen,'saved-state receipt lacks completed run metadata')
        require((root/'restart.meta').stat().st_size<=512*1024,'oversized final checkpoint metadata')
        with (root/'restart.meta').open() as f:line=f.readline(4096).split()
        require(len(line)==3 and Path(line[0]).name==line[0] and root/line[0] in seen,'saved-state receipt lacks final checkpoint')
    guards=r['runtime_residual_guards'];require(isinstance(guards,dict) and len(guards)==3,'saved-state original guard limits missing')
    for g in guards.values():
        for k in ['rhs_norm','residual_norm','guard_limit']:finite(g[k],'recorded guard '+k)
        require(g['guard_passed'] is True and g['guard_limit']>=0 and 0<=g['residual_norm']<=g['guard_limit'],'invalid original guard receipt')
    return max(g['guard_limit'] for g in guards.values())

def scales(records,seed):
    ds=[r['d'] for r in records]+[seed['diagnostics']]
    charge=max([r['qabs'] for r in records]+[seed['qabs']])
    charge=max(charge,max(sum(abs(v) for k,v in d.items() if k.endswith('charge_C') and k not in ['lower_field_charge_C','upper_field_charge_C']) for d in ds),E)
    electrode=max(abs(d['lower_field_charge_C'])+abs(d['upper_field_charge_C']) for d in ds)
    energy=max(sum(abs(v) for k,v in d.items() if 'energy_J' in k and k!='field_energy_J') for d in ds)
    return ds,charge,electrode,energy

def ledger_limits(records,seed,policy,residual_limit):
    ds,charge,electrode,energy=scales(records,seed);limits={}
    for k in DIAG:
        if k=='time_s':limits[k]=0.;continue
        if k=='poisson_residual_C_per_m':limits[k]=residual_limit;continue
        if k=='field_energy_J':scale=max(abs(d[k]) for d in ds)
        elif 'energy_J' in k:scale=energy
        elif k in ['lower_field_charge_C','upper_field_charge_C','gauss_defect_C']:scale=electrode
        else:scale=charge
        limits[k]=policy['ledger_roundoff_factor']*EPS*scale
    return limits,policy['ledger_roundoff_factor']*EPS*charge

class Comparison:
    def __init__(self):self.metrics={};self.failures=[];self.failure_count=0;self.checked_values=0
    def check(self,name,a,b,limit,step):
        a=np.asarray(a);b=np.asarray(b);require(a.shape==b.shape,name+': shape mismatch')
        require(np.isfinite(a).all() and np.isfinite(b).all(),name+': nonfinite comparison')
        delta=np.abs(a-b);maximum=float(np.max(delta,initial=0.));scale=float(max(np.max(np.abs(a),initial=0.),np.max(np.abs(b),initial=0.)))
        finite(maximum,name+' difference');finite(scale,name+' scale');finite(limit,name+' limit')
        old=self.metrics.setdefault(name,{'values_compared':0,'max_absolute_difference':0.,'max_observed_scale':0.,'min_absolute_limit':limit,'max_absolute_limit':limit,'worst_step':None,'max_fraction_of_limit':0.})
        old['values_compared']+=a.size;self.checked_values+=a.size
        old['min_absolute_limit']=min(old['min_absolute_limit'],limit);old['max_absolute_limit']=max(old['max_absolute_limit'],limit);old['max_observed_scale']=max(old['max_observed_scale'],scale)
        if maximum>old['max_absolute_difference']:old['max_absolute_difference']=maximum;old['worst_step']=step
        if limit>0 and old['max_fraction_of_limit'] is not None:old['max_fraction_of_limit']=max(old['max_fraction_of_limit'],maximum/limit)
        elif maximum:old['max_fraction_of_limit']=None
        if maximum>limit:
            self.failure_count+=1
            if len(self.failures)<64:self.failures.append({'name':name,'step':step,'absolute_difference':maximum,'absolute_limit':limit,'index':int(np.argmax(delta)) if delta.size else None})

def compare_step(a,b,seed,policy,residual_limit,comp,label):
    step=a['step'];require((step,a['dt'],a['d']['time_s'])==(b['step'],b['dt'],b['d']['time_s']),label+': exact step/dt/clock mismatch')
    pa,pb=a['p'],b['p'];require(len(pa)==len(pb) and np.array_equal(pa['id'],pb['id']),label+': exact particle count/ordered IDs mismatch')
    for k in ['q','m','w']:require(np.array_equal(pa[k],pb[k]),label+': exact particle '+k+' mismatch')
    require(np.array_equal(a['spans'],b['spans']),label+': exact reservoir spans mismatch')
    for i,((qa,ta),(qb,tb)) in enumerate(zip(a['pools'],b['pools'])):
        require(np.array_equal(qa,qb) and np.array_equal(ta,tb),label+': exact source reservoir mismatch in pool '+str(i))
    sa,sb=a['stage'],b['stage'];require((sa is None)==(sb is None),label+': force-stage row presence mismatch')
    if sa is not None:
        for k in ['relative_midpoint_s','dt_s']:require(sa[k]==sb[k],label+': exact stage '+k+' mismatch')
        if label=='shadow_vs_optimized':
            for k in ['lower_frame','upper_frame','voltage_V','fraction']:require(sa[k]==sb[k],label+': selected native metadata mismatch '+k)
    limits,edge_limit=ledger_limits([a,b],seed,policy,residual_limit)
    comp.check(label+'.position_m',pa['x'],pb['x'],policy['position_atol_m'],step)
    uscale=max(float(np.max(np.abs(pa['u']),initial=0.)),float(np.max(np.abs(pb['u']),initial=0.)))
    comp.check(label+'.proper_velocity_m_s',pa['u'],pb['u'],policy['velocity_rtol_global']*uscale,step)
    vscale=max(float(np.max(np.abs(a['phi']),initial=0.)),float(np.max(np.abs(b['phi']),initial=0.)))
    comp.check(label+'.nodal_phi_V',a['phi'],b['phi'],policy['field_rtol_global']*vscale+256*EPS*vscale,step)
    for k in ['h','v']:comp.check(label+'.edge_transfers_'+k+'_C',a[k],b[k],edge_limit,step)
    for k in DIAG:comp.check(label+'.diagnostics.'+k,a['d'][k],b['d'][k],limits[k],step)
    for name,r in [('a',a),('b',b)]:
        d=r['d'];charge=float(np.sum(r['p']['q']*r['p']['w']))
        comp.check(label+'.'+name+'.particle_charge_reconstruction',d['particle_charge_C'],charge,limits['particle_charge_C'],step)
        comp.check(label+'.'+name+'.deposition_charge',d['deposited_charge_C'],d['particle_charge_C'],limits['particle_charge_C'],step)
        comp.check(label+'.'+name+'.gauss_identity',d['gauss_defect_C'],d['particle_charge_C']+d['lower_field_charge_C']+d['upper_field_charge_C'],limits['gauss_defect_C'],step)

def compare(off,shadow,optimized,seed_path,off_shadow_receipt,off_optimized_receipt,allow_manufactured=False):
    tracked={};readers=[];started=time.monotonic()
    try:
        policy,abi=reference(tracked);seed=seed_state(seed_path,abi,tracked,allow_manufactured)
        paths=[Path(p).resolve() for p in [off,shadow,optimized]];require(len(set(paths))==3,'three distinct run paths required')
        r1=receipt(Path(off_shadow_receipt),paths[0],paths[1],seed,policy,tracked)
        r2=receipt(Path(off_optimized_receipt),paths[0],paths[2],seed,policy,tracked)
        for mode,p in enumerate(paths):readers.append(Trace(p,mode,seed,tracked))
        require(len({r.cleanup['steps_recorded'] for r in readers})==1,'trace step counts differ')
        for key in ['start_time_s','requested_end_time_s']:require(len({r.progress[key] for r in readers})==1,'run time domains differ')
        comp=Comparison();first=None;last=None
        for i in range(readers[0].cleanup['steps_recorded']):
            records=[r.record() for r in readers]
            for a,b,label,budget in [(0,1,'off_vs_shadow',r1),(0,2,'off_vs_optimized',r2),(1,2,'shadow_vs_optimized',max(r1,r2))]:
                compare_step(records[a],records[b],seed,policy,budget,comp,label)
            if first is None:first=records[0]['step']
            last=records[0]
        for r in readers:
            require(r.progress['macro_particles']==len(last['p']),'progress/final trace particle count mismatch')
            r.finish(tracked,policy)
        for p,x in tracked.items():require(signature(p)==x['signature'],'input changed during comparison: '+str(p))
        return {'status':'passed' if not comp.failure_count else 'failed','comparison_complete':True,
          'manufactured_fixture':allow_manufactured,'steps_compared':readers[0].count,'first_step':first,'last_step':last['step'],
          'exact_checks':['every dt/local clock/step','ordered IDs and count','q/mass/weight','source spans/integrals/weighted temperatures','force clocks','shadow/optimized selected frame/voltage/fraction'],
          'policy':policy,'residual_comparison_limits':{'off_vs_shadow':r1,'off_vs_optimized':r2,'shadow_vs_optimized':max(r1,r2)},
          'edge_transfer_budget':'Same 1024*epsilon*particle/ledger charge scale as established continuity diagnostic; per pair/step with seed included.',
          'nodal_phi_budget':'Same established potential budget: 1e-10*global potential scale + 256*epsilon*potential scale.',
          'metric_summary':comp.metrics,'checked_scalar_values':int(comp.checked_values),'failure_count':comp.failure_count,'failures':comp.failures,
          'input_manifest':[{'path':str(p),'bytes':x['signature'][2],'sha256':x['sha256']} for p,x in sorted(tracked.items())],
          'limits':['Full traces contain public diagnostics(), not checkpoint raw ledgers; no kinetic energy is added twice.',
           'Per-step RHS norms/guard limits are absent. Residual differences use original guard limits recorded in the passed final saved-state comparisons, as the established comparator does. This does not independently reconstruct each step residual guard.',
           'No unrecorded midpoint E/B, source temperature samples, next_id, source work, or crossing-event log is inferred.',
           'Nodal phi is compared directly. Full final checkpoint/frame and their original guards must pass separately through the required saved-state receipts.',
           'This short-window regression result cannot qualify later native-frame refreshes, physical convergence, deployment, or production resume.'],
          'execution':{'affinity':list(os.sched_getaffinity(0)),'nice':os.nice(0),'wall_s':time.monotonic()-started,'max_RSS_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'GPU_execution':False}}
    finally:
        for r in readers:r.close()

@contextlib.contextmanager
def cpu_lease():
    require(sorted(os.sched_getaffinity(0))==[6] and os.getpriority(os.PRIO_PROCESS,0)==15,'run on CPU6 nice15')
    for key in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:require(os.getenv(key)=='1',key+' must be 1')
    with LEASE.open('a+') as f:
        try:fcntl.flock(f,fcntl.LOCK_SH|fcntl.LOCK_NB)
        except BlockingIOError:raise Invalid('testing-core.lock is busy; yield to exclusive build/test owner')
        yield

def main():
    p=argparse.ArgumentParser(description=__doc__)
    for name in ['off','shadow','optimized']:p.add_argument(name,type=Path)
    p.add_argument('--seed',type=Path,required=True);p.add_argument('--off-shadow-comparison',type=Path,required=True);p.add_argument('--off-optimized-comparison',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True);p.add_argument('--allow-manufactured-fixture',action='store_true')
    args=p.parse_args();require(args.output.resolve().is_relative_to(HERE),'write comparison receipts only inside owned comparator output prefix')
    require(not args.output.exists(),'output already exists')
    try:
        with cpu_lease(),np.errstate(over='raise',invalid='raise',divide='raise'):
            report=compare(args.off,args.shadow,args.optimized,args.seed,args.off_shadow_comparison,args.off_optimized_comparison,args.allow_manufactured_fixture)
    except (Invalid,ValueError,OSError,KeyError,TypeError,IndexError,ZeroDivisionError,OverflowError,struct.error,FloatingPointError) as e:
        report={'status':'invalid','comparison_complete':False,'error':str(e),'error_type':type(e).__name__,'GPU_execution':False}
        fingerprints=[]
        for root in [args.off,args.shadow,args.optimized]:
            for name in ['evolving-state.bin','trace-schema.json','force-cleanup.json','progress.json','force-stages.csv']:
                path=root/name
                try:
                    size=path.stat().st_size
                    with path.open('rb') as f:data=f.read(65536)
                    fingerprints.append({'path':str(path.resolve()),'bytes':size,'fingerprinted_prefix_bytes':len(data),'sha256_prefix':hashlib.sha256(data).hexdigest(),'full_file_hash':size==len(data)})
                except OSError as error:fingerprints.append({'path':str(path),'unavailable':str(error)})
        report['invalid_input_fingerprints']=fingerprints
    report['created_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    with args.output.open('x') as f:json.dump(report,f,indent=2,allow_nan=False);f.write('\n')
    print(json.dumps({k:report[k] for k in ['status','comparison_complete','steps_compared','failure_count','error'] if k in report}))
    return 0 if report['status']=='passed' else 1 if report['status']=='failed' else 2
if __name__=='__main__':raise SystemExit(main())
