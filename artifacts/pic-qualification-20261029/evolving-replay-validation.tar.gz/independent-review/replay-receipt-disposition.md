The three private v3 GPU receipts, force-stage clocks/selections, shadow comparisons, cleanup and completed final-checkpoint comparison reports pass independent audit. Full binary per-step state parity remains a separate pending qualification. No physics/deployment or speedup conclusion follows yet.

The accepted manifest/recipe and executable hashes match. Parent command-execution evidence shows verification of all88 artifacts and copied seed hashes, acquisition of GPU then core7 leases held across the serial runs, exact reviewed guarded argv, and after-run verification. All three children exited0 within60s on CPU7/nice15. Their authenticated retained-pidfd guards recorded the original production PID/start/executable/cgroup stopped and frozen before, in the child preflight, periodically and after each run. Periodic check counts were131,143 and93. Production remains T/frozen1 now. No production signal/resume or deployment authorization was used.

Each mode recorded210 accepted steps, the same exact210 midpoint/dt pairs, the same final clock and46,842 final particles. Starting from the pinned restart clock, the CSV midpoint equals original `ledger.time + .5*dt` on every row; accumulation reaches exactly the reported requested end. For every shadow/optimized row, independent reconstruction with the frozen native and pulse tables, original32-epsilon lookup, upper_bound/clamp and original absolute-time association gives the same frame IDs27/28, interpolation fraction and voltage. Each active mode has exactly one initial static upload; this window does not exercise an actual native-frame refresh. Off's provider columns are correctly unused zeros.

All210 shadow kicks report zero component E/B/u, weighted velocity and weighted energy comparison error and zero failures under the unchanged gates. Optimized's zero comparison columns mean the redundant oracle was not executed; they are not an independent equality result. Its state correctness still depends on the external comparisons.

Shadow and optimized cleanup both report attempted/context-established/stream-drained/resources-released/caller-restored/own-primary-reference-released, with zero issues and no retained resources. Off correctly has no force backend: its sink is unattempted with zero issues/no retention. The original field solver still ran in off. All process returns are consistent with the unchanged original inline physics/residual/timestep/resource guards remaining satisfied; numerical per-step fields and ledgers still need the streaming comparison.

All three trace file sizes equal the cleanup byte counters at1,457,665,600bytes each, below2GiB, with210 recorded steps below256. These checks establish byte count/bounds and emitter success, not independent binary content parity. The full trace stream was not parsed or compared by this receipt audit.

The now-complete final-checkpoint reports each pass all164 established checks with zero failures and an exactly unchanged policy dictionary. Off was compared with the frozen native control; shadow and optimized with off. The original comparator was executed by the parent; this review inspected its complete reports and policy rather than duplicating that CPU work. Passing the final saved state is not a substitute for the pending full-step comparison.

Raw single-trial instrumented timing is:

| Mode | Process wall | Sum of whole force stages | Median force stage |
| --- | ---: | ---: | ---: |
| Off/native |13.079084s |4295.380773ms |20.359857ms |
| Shadow |14.282559s |5345.730802ms |24.241867ms |
| Optimized candidate |9.225693s |605.960270ms |1.842758ms |

Whole force stages include setup/export/refresh, checks, transfers, synchronization and commit, plus fresh reference generation and comparison in shadow. First-force times include initial setup:260.260678ms shadow and218.668700ms optimized; their cost is retained in the totals. Component CSV columns do not partition whole force time. Full process wall includes approximately1.46GB observation trace/file costs per mode and is not an uninstrumented production benchmark. Different wall-triggered history sampling is also expected when one run crosses the10s progress threshold and another does not. The raw difference is provisional until full-step parity passes; this audit reports no acceleration ratio or broader application claim.

`audit_replay_receipts.py`, `replay-receipt-audit.json` and `parent-replay-execution-evidence.json` preserve the assertions, metadata hashes and parent lease/copy code evidence. The audit used CPU6/nice15 and the exclusive testing-core lease, did no GPU execution, did not alter candidate source or acceptance tolerances, and sent no production signals. The separately prepared streaming comparator and its policy/results still require review before qualification.
