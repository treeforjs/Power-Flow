#!/usr/bin/env python3
"""Audit bounded-v3 receipts and CSVs only; full binary-state parity is separate."""
from pathlib import Path
import bisect, csv, fcntl, hashlib, json, math, os, statistics, struct, sys, time

PROFILE=Path('/home/treefor/Documents/Codex/2026-10-28/we/outputs/pic-profile')
CANDIDATE=Path('/home/treefor/projects/runtimes/pic-cuda-force-evolving-v3-20261029')
ROOT=CANDIDATE/'qualification-runs'
HERE=Path(__file__).resolve().parent
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
checks=[]
def need(test,name):
    checks.append(name)
    if not test:raise AssertionError(name)
def hold(d):
    need(d['production_host_pid']==278902 and d['start_ticks']=='5288339' and d['state']=='T' and d['cgroup_frozen'] is True,'original stopped/frozen hold identity')
    need(d['exe']=='/home/treefor/projects/runtimes/mfem-gpu-pic-20261029/qualified/heating-history-pic-gpu' and d['cgroup']=='/powerflow-pic-gpu-reserved','original executable/cgroup')
def table(path):
    with Path(path).open() as f:return list(csv.reader(f))[1:]
def run():
    accepted=read(HERE/'disposition.json');dispatch=read(ROOT/'PARENT-DISPATCH.json');recipe=read(CANDIDATE/'PARENT-REPLAY-RECIPE.json')
    need(sha(CANDIDATE/'ARTIFACT-SHA256.json')==accepted['artifact_manifest_sha256']==dispatch['manifest_sha256'],'accepted manifest binding')
    need(sha(CANDIDATE/'PARENT-REPLAY-RECIPE.json')==accepted['parent_replay_recipe_sha256']==dispatch['recipe_sha256'],'accepted replay recipe binding')
    need(sha(CANDIDATE/'build/heating_history_pic_force_candidate')==accepted['executable_sha256'],'accepted executable unchanged')
    need(not dispatch['production_resume_authorized'] and not dispatch['deployment_authorized'],'production/deployment hold')
    need([x['mode'] for x in dispatch['cases']]==['off','shadow','optimized'],'three serial runs in accepted order')
    origin=struct.unpack_from('<d',Path('/home/treefor/Documents/Codex/2026-10-28/we/outputs/heating-history-full.bin').read_bytes(),48)[0]
    relative_start=float((PROFILE/'seed-late-phase/restart.meta').read_text().strip().splitlines()[-1].split()[0])
    native_times=[float(x[0]) for x in table('/home/treefor/projects/Power-Flow/runs/restore_field_mpi8_domain40mm/em_field_snapshots.csv')]
    pulses=table('/home/treefor/Documents/Codex/2026-10-28/we/outputs/gap-pulse-midplane110kV.csv');pulse_starts=[float(x[0]) for x in pulses]
    expected_clocks=None;results={};receipt_hashes={}
    for index,(case,command) in enumerate(zip(dispatch['cases'],recipe['commands'])):
        mode=case['mode'];p=Path(case['output']);need(p==Path(command['output'])==ROOT/('gpu-'+mode),'accepted output '+mode)
        need(case['returncode']==0 and math.isfinite(case['wall_s']) and 0<case['wall_s']<60,'clean bounded child '+mode)
        rr=read(p/'run-receipt.json');guard=read(p/'host-guard.json');pre=read(p/'preflight.json');clean=read(p/'force-cleanup.json');progress=read(p/'progress.json')
        need(rr['mode']==mode and rr['command']==command['command_argv'] and rr['binary']==str(CANDIDATE/'build/heating_history_pic_force_candidate'),'actual command matches recipe '+mode)
        need(rr['returncode']==0 and rr['wall_s']==case['wall_s'] and rr['profile_cpu']==7 and rr['window_ps']==1,'run receipt bounds '+mode)
        need(rr['production_left_stopped'] and rr['manual_pause_preserved'] and not rr['production_signals_sent'],'run receipt hold '+mode)
        for key in ('production_identity','production_identity_after'):
            ident=rr[key];need(ident['pid']==278902 and ident['start_ticks']=='5288339' and ident['state']=='T','original process identity '+mode)
        need(rr['seed']['checkpoint_sha256']==recipe['seed_sha256'][str(PROFILE/'seed-late-phase/checkpoint_437411.bin')],'original seed hash '+mode)
        need(sha(p/'seed.json')==recipe['seed_sha256'][str(PROFILE/'seed-late-phase/seed.json')],'copied seed metadata hash '+mode)
        need(guard['command']==command['command_argv'][command['command_argv'].index('--')+1:] and guard['logical_cpu']==[7] and guard['nice']>=15,'guarded child command/CPU/priority '+mode)
        need(guard['child_returncode']==0 and guard['guard_error'] is None and not guard['production_signalled'] and guard['production_pidfd_retained_until_child_exit'] and guard['periodic_checks']>=2,'guard success '+mode)
        for h in [guard['before'],guard['after'],*[v['check'] for v in guard['child_requests']]]:
            hold(h);need(h['pidfd_retained'] and h['host_guard_pid']==guard['host_guard_pid'],'authenticated pidfd observation '+mode)
        need(pre['passed'] and not pre['production_signalled'],'nested preflight passed '+mode);hold(pre['hold'])
        need(pre['hold']['host_proc_readonly'] and pre['hold']['distinct_pid_views'] and pre['hold']['host_executable_checked_with_retained_pidfd'],'readonly distinct host PID view '+mode)
        need(clean['passed'] and clean['mode']==index and not clean['deployment_authorized'] and not clean['production_resume_authorized'] and clean['original_error']=='' and clean['issue_count']==0 and clean['issues']==[] and not clean['resources_retained'],'clean runtime result '+mode)
        if mode=='off':
            need(not clean['attempted'] and clean['static_uploads']==0 and not clean['resources_released'],'off correctly unused backend')
        else:
            need(all(clean[k] for k in ('attempted','context_established','stream_drained','resources_released','caller_context_restored','primary_reference_released')) and clean['static_uploads']==1,'active backend clean lifecycle '+mode)
        size=(p/'evolving-state.bin').stat().st_size
        need(size==clean['trace_bytes'] and 0<size<=2*1024**3 and clean['steps_recorded']==210<=256,'trace size/step caps '+mode)
        need(progress['phase']=='completed' and not progress['full_history_run'] and progress['checkpoint_benchmark'] and progress['steps']==437621 and progress['macro_particles']==46842 and progress['mpi_ranks']==1,'completed bounded replay '+mode)
        with (p/'force-stages.csv').open() as f:rows=list(csv.DictReader(f))
        need(len(rows)==clean['steps_recorded']==210,'force-stage row count '+mode)
        clocks=[(float(x['relative_midpoint_s']),float(x['dt_s'])) for x in rows]
        if expected_clocks is None:expected_clocks=clocks
        need(clocks==expected_clocks,'exact midpoint/dt sequence across modes '+mode)
        relative=relative_start
        for row,(mid,dt) in zip(rows,clocks):
            values={k:float(v) for k,v in row.items()};need(all(math.isfinite(v) for v in values.values()),'finite stage data '+mode)
            need(values['mode']==index and dt>0 and mid==relative+.5*dt,'exact original midpoint expression '+mode);relative+=dt
            need(all(values[k]>=0 for k in ('reference_ms','GPU_API_ms','commit_ms','whole_force_ms')),'nonnegative force timings '+mode)
            need(all(values[k]==0 for k in ('comparison_failures','max_E_error','max_B_error','max_u_error','weighted_u_error','weighted_energy_error')),'recorded shadow-error columns zero '+mode)
            if mode=='off':
                need(all(values[k]==0 for k in ('reference_ms','GPU_API_ms','commit_ms','lower_frame','upper_frame','voltage_V','fraction')),'off unused provider/oracle columns')
            else:
                absolute=origin+mid;lookup=absolute+32*sys.float_info.epsilon*max(abs(absolute),1e-12)
                k=max(0,min(bisect.bisect_right(native_times,lookup)-1,len(native_times)-2));f=max(0.,min((absolute-native_times[k])/(native_times[k+1]-native_times[k]),1.))
                vk=max(0,min(bisect.bisect_right(pulse_starts,lookup)-1,len(pulses)-1))
                need(values['lower_frame']==k and values['upper_frame']==k+1 and values['fraction']==f and values['voltage_V']==float(pulses[vk][2]),'exact original native/pulse selection '+mode)
                need(values['GPU_API_ms']>0 and values['commit_ms']>0 and values['whole_force_ms']>=values['reference_ms']+values['GPU_API_ms']+values['commit_ms'],'whole-force includes component charges '+mode)
                need((values['reference_ms']>0) if mode=='shadow' else values['reference_ms']==0,'explicit shadow/optimized oracle cost '+mode)
        need(origin+relative==progress['accepted_time_s']==progress['requested_end_time_s'] and progress['start_time_s']==origin and 0<(origin+relative)-(origin+relative_start)<=1.00000001e-12,'exact final clock/one-ps bound '+mode)
        timing={k:{'sum_ms':sum(float(x[k]) for x in rows),'median_ms':statistics.median(float(x[k]) for x in rows),'first_ms':float(rows[0][k])} for k in ('whole_force_ms','reference_ms','GPU_API_ms','commit_ms')}
        results[mode]={'returncode':case['returncode'],'instrumented_wall_s':case['wall_s'],'rows':len(rows),'steps':clean['steps_recorded'],'trace_bytes':size,'host_periodic_checks':guard['periodic_checks'],'static_uploads':clean['static_uploads'],'stage_timing':timing,'final_time_s':progress['accepted_time_s'],'final_particles':progress['macro_particles']}
        for fn in ('run-receipt.json','host-guard.json','preflight.json','force-cleanup.json','progress.json','force-stages.csv','trace-schema.json','seed.json','benchmark_profile.json'):
            receipt_hashes[str(p/fn)]=sha(p/fn)
    checkpoint_reports={};policy=read(PROFILE/'cuda-gather-investigation/actual-capture-full-comparison.json')['policy']
    for mode,name in [('off','full-comparison-native-control.json'),('shadow','full-comparison.json'),('optimized','full-comparison.json')]:
        f=ROOT/('gpu-'+mode)/name;d=read(f)
        need(d['status']=='passed' and d['comparison_complete'] and len(d['checks'])==164 and not d['failures'] and d['policy']==policy,'complete164-check saved-state report and unchanged policy '+mode)
        receipt_hashes[str(f)]=sha(f);checkpoint_reports[mode]={'path':str(f),'status':d['status'],'complete':d['comparison_complete'],'checks':164,'failures':0,'policy_unchanged':True}
    st=Path('/proc/278902/stat').read_text();tail=st[st.rfind(')')+2:].split();cg=Path('/sys/fs/cgroup/powerflow-pic-gpu-reserved/cgroup.events').read_text();need(tail[0]=='T' and tail[19]=='5288339' and 'frozen 1' in cg,'current production hold intact')
    return {'status':'receipts_stages_and_final_checkpoint_reports_passed_full_step_parity_pending','checks':len(checks),'modes':results,'exact_clock_dt_rows_per_mode':210,'shadow_gates_zero_error_every_kick':True,'optimized_oracle_columns':'uncomputed, not an independent comparison pass','receipt_sha256':receipt_hashes,'full_checkpoint_comparison_reports':checkpoint_reports,'full_checkpoint_comparison_execution':'Original comparator executed by parent; reports/policy independently inspected, comparison not rerun.','full_binary_step_parity_status':'separate streaming comparison pending; not read or compared by this audit','speedup_conclusion':'withheld pending full-step parity; timings are one instrumented1ps trial including full trace I/O','parent_execution_evidence':str(HERE/'parent-replay-execution-evidence.json'),'gpu_executed_by_reviewer':False,'production_signals_sent':False,'production_hold':{'pid':278902,'state':tail[0],'start_ticks':tail[19],'cgroup_events':cg},'created_unix_s':time.time()}

if __name__=='__main__':
    assert os.sched_getaffinity(0)=={6} and os.getpriority(os.PRIO_PROCESS,0)>=15
    with (PROFILE/'testing-core.lock').open('a') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        result=run();(HERE/'replay-receipt-audit.json').write_text(json.dumps(result,indent=2)+'\n')
        print(json.dumps({'status':result['status'],'checks':result['checks'],'clock_rows_per_mode':210,'shadow_gates_zero_error':True,'state_parity':'pending','reviewer_GPU_execution':False}))
