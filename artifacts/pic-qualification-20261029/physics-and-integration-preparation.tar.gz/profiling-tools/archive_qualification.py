from pathlib import Path
import tarfile, hashlib, json, time, fcntl
W=Path('/home/treefor/Documents/Codex/2026-10-28/we')
OUT=Path('/home/treefor/projects/Power-Flow/artifacts/pic-qualification-20261029')
R=Path('/home/treefor/projects/runtimes')
assert not OUT.exists()
OUT.mkdir()
manifest={'created_unix_s':time.time(),'status':'experimental_qualification_not_deployment','production_resume_authorized':False,'archives':{},'files':{}}
source_roots={
 'cuda-gather/source':R/'pic-cuda-gather-investigation-20261029/source',
 'cuda-gather/tools':R/'pic-cuda-gather-investigation-20261029/tools',
 'cuda-gather/backend-v2':R/'pic-cuda-gather-investigation-20261029/backend-v2',
 'rhs-observer':R/'pic-rhs-observer-20261029',
 'native-events':W/'outputs/pic-profile/native-event-log-prototype',
 'event-analysis-v2':W/'outputs/pic-profile/native-event-analysis-v2',
 'particle-tracker':W/'outputs/pic-profile/particle-motion-audit/tracking-candidate/source',
}
allowed={'.cpp','.cc','.cu','.cuh','.hpp','.h','.py','.sh','.json','.txt','.md','.patch','.diff'}
skip={'build','test-build','build-on','build-off','__pycache__','.git','evidence-fixtures','real-seed-1ps','post-gpu-audit'}
def add(tf,p,arc):
 assert p.is_file() and not p.is_symlink(),str(p)
 before=hashlib.sha256(p.read_bytes()).hexdigest();tf.add(p,arcname=arc,recursive=False)
 after=hashlib.sha256(p.read_bytes()).hexdigest();assert before==after,('Changed during capture',str(p))
 manifest['files'][arc]={'source':str(p),'bytes':p.stat().st_size,'sha256':after}
def finalize(name):
 p=OUT/name;assert p.stat().st_size<96*1024*1024,('Archive too large',str(p),p.stat().st_size)
 manifest['archives'][name]={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
with open(W/'outputs/pic-profile/testing-core.lock','a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 name='first-party-sources-and-contracts.tar.gz'
 with tarfile.open(OUT/name,'w:gz',compresslevel=6) as tf:
  for prefix,root in source_roots.items():
   for p in sorted(root.rglob('*')):
    rel=p.relative_to(root)
    if p.is_file() and not p.is_symlink() and not any(v in skip or v.startswith('build-') for v in rel.parts) and (p.suffix in allowed or p.name in {'run-frozen-with-host-proc','run-observer'}) and p.stat().st_size<5*1024*1024:
     add(tf,p,prefix+'/'+str(rel))
 finalize(name)
 name='actual-midpoint-and-rhs-fixtures.tar.gz'
 with tarfile.open(OUT/name,'w:gz',compresslevel=6) as tf:
  for prefix,root in {
   'actual-midpoint-fixture':W/'outputs/pic-profile/cuda-gather-investigation/actual-midpoint-fixture',
   'actual-rhs-capture':W/'outputs/pic-profile/rhs-observer-1ps-capture',
  }.items():
   for p in sorted(root.iterdir()):
    if p.is_file() and not p.is_symlink():add(tf,p,prefix+'/'+p.name)
 finalize(name)
 name='bounded-replay-receipts.tar.gz'
 with tarfile.open(OUT/name,'w:gz',compresslevel=6) as tf:
  roots={
   'gpu-lifecycle-v2':W/'outputs/pic-profile/cuda-gather-investigation/gpu-lifecycle-v2',
   'independent-cuda-review':W/'outputs/pic-profile/cuda-gather-independent-review/backend-v2',
   'owner-cuda-audit':R/'pic-cuda-gather-investigation-20261029/backend-v2/post-gpu-audit',
   'rhs-replay':W/'outputs/pic-profile/rhs-observer-1ps-cpu7',
   'native-events-real-replay':W/'outputs/pic-profile/native-event-log-prototype/real-seed-1ps',
   'particle-motion-audit':W/'outputs/pic-profile/particle-motion-audit',
   'chicago-review':W/'outputs/chicago-pic-review',
   'em-consistency':W/'outputs/pic-profile/em-field-consistency-audit',
  }
  skip_receipt={'build','tracking-candidate','source','baseline-track-1ps','baseline-track-10ps','native-b'}
  for prefix,root in roots.items():
   for p in sorted(root.rglob('*')):
    rel=p.relative_to(root)
    if p.is_file() and not p.is_symlink() and not any(x in skip_receipt for x in rel.parts) and p.suffix in {'.json','.txt','.md','.py','.patch','.diff','.gif','.png','.csv'} and p.stat().st_size<30*1024*1024:
     add(tf,p,prefix+'/'+str(rel))
 finalize(name)
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(OUT/'README.txt').write_text('PIC qualification follow-up snapshot, 2026-10-29.\n\nThe full run remains explicitly paused at its preserved ~26.48 ns state. Nothing here is a production deployment or restart authorization.\n\nSources are first-party experimental work; frozen CUDA/cuDSS/NVRTC/MFEM toolchains and third-party binaries are not redistributed. Sources include the corrected v2 CUDA gather/Boris lifetime handling, bounded actual-RHS observer, passive native event observer and exact-native-operand analyzer, and copied-state particle tracker. Original absolute source paths and SHA256 values are recorded in manifest.json. Rebuild into a fresh prefix with pinned dependencies.\n\nFixed-midpoint GPU qualification passed for46726 captured particles, including shared cuDSS-primary context lifecycle and zero field/velocity differences. This does not establish an integrated timestep speedup. Median GPU kernel0.307776ms is contained within the reference-inclusive22.868514ms force pipeline, which includes20.1632045ms fresh independent CPU reference. Actual evolving CUDA-force integration remains separate.\n\nThe RHS observer passed full saved-state comparison over1ps and captured16 half-solves in8 populated advances with the unchanged two-refinement FP64 solver/residual contract; the matrices match the audited native CSR exactly. Raw captured vectors and fixed-stage fixture are retained so later solver investigations can be reproduced.\n\nThe event analyzer corrected native binary64 endpoint/prefix arithmetic without changing input logs, physical fluxes or tolerances. Its800 real-stream checks passed; unknown inherited source provenance and incomplete incidence-angle coverage remain unknown.\n\nThe trajectory replay is a separate short copied-state diagnostic and must not be confused with accepted progress of the paused full run. All conditional voltage, mirrored anode temperatures, coarse prescribed B, height-averaged2D space charge, absent ions/gas/collisions/phase changes and unresolved convergence limits remain. CHICAGO publications are reference studies, not validation of this model.\n')
print(json.dumps({'archives':manifest['archives'],'source_and_evidence_files':len(manifest['files'])},indent=2))
