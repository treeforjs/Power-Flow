"""Manufactured algebra checks only; no PIC solver, model or coupled-physics qualification."""
import json,math,os,pathlib,fcntl
P=pathlib.Path(__file__).parent
assert sorted(os.sched_getaffinity(0))==[6]and os.getpriority(os.PRIO_PROCESS,0)==15
EPS=2.220446049250313e-16
records=[]
def check(name,a,b,activity):
 tolerance=128*EPS*activity
 assert abs(a-b)<=tolerance,(name,a,b,tolerance)
 records.append({'name':name,'a':a,'b':b,'absolute_error':abs(a-b),'operand_activity_bound':tolerance,'passed':True})
def dot(a,b):return a[0]*b[0]+a[1]*b[1]+a[2]*b[2]
def cross(a,b):return [a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
e=1.602176634e-19;m=9.1093837139e-31;c=299792458.
def gamma(u):return math.sqrt(1+dot(u,u)/(c*c))
def kinetic(u):return m*dot(u,u)/(gamma(u)+1)
with (P.parent/'testing-core.lock').open('a+')as lease:
 fcntl.flock(lease,fcntl.LOCK_EX)
 # Electric sub-kick identity with a norm-preserving Boris rotation between them.
 u=[1e7,2e7,-3e6];q=-e;dt=1e-14;w=1.7
 channels=[[.7e7,-1.2e7,.3e7],[-.1e7,.4e7,-.8e7],[.05e7,-.08e7,.11e7]];E=[sum(x[i]for x in channels)for i in range(3)];B=[.2,-.1,1.]
 minus=[u[i]+.5*dt*q/m*E[i]for i in range(3)];t=[.5*dt*q/m*B[i]/gamma(minus)for i in range(3)];mt=cross(minus,t);prime=[minus[i]+mt[i]for i in range(3)];s=[2*x/(1+dot(t,t))for x in t];ps=cross(prime,s);plus=[minus[i]+ps[i]for i in range(3)];new=[plus[i]+.5*dt*q/m*E[i]for i in range(3)]
 D=[.5*dt*((minus[i]+u[i])/(gamma(minus)+gamma(u))+(new[i]+plus[i])/(gamma(new)+gamma(plus)))for i in range(3)]
 work=[w*q*dot(x,D)for x in channels];rotation=w*(kinetic(plus)-kinetic(minus));gain=w*(kinetic(new)-kinetic(u))
 activity=w*sum(abs(kinetic(x))for x in (u,minus,plus,new))
 check('two electric kicks plus magnetic roundoff',gain,sum(work)+rotation,activity)
 check('linear field-channel partition',sum(work),w*q*dot(E,D),sum(abs(x)for x in work))
 # Pure magnetic rotation is analytically norm preserving; its floating error is numerical.
 check('magnetic rotation energy',kinetic(plus),kinetic(minus),abs(kinetic(plus))+abs(kinetic(minus)))
 # Vacuum capacitor source work requires voltage quadrature, not final-V times charge.
 cap=1e-10;v0=10.;v1=30.;dq=cap*(v1-v0);dU=.5*cap*(v1*v1-v0*v0)
 check('vacuum capacitor signed source work',.5*(v0+v1)*dq,dU,abs(dU))
 assert v1*dq!=dU
 # Symmetric matrix identity: U=.5 H phi^T A phi, r=A phi-b.
 H=.025;coeff=1e-12;q=-1e-19
 def state(s,V):
  b=[0.,q*(1-s)/H,q*s/H,0.];phi=[0.,(2*b[1]+b[2]+coeff*V)/(3*coeff),(b[1]+2*b[2]+2*coeff*V)/(3*coeff),V]
  action=[coeff*(phi[0]-phi[1]),coeff*(-phi[0]+2*phi[1]-phi[2]),coeff*(-phi[1]+2*phi[2]-phi[3]),coeff*(-phi[2]+phi[3])]
  reaction=[H*(action[i]-b[i])for i in range(4)];energy=.5*H*sum(phi[i]*action[i]for i in range(4));return b,phi,reaction,energy
 for V0,V1 in [(0.,0.),(20.,20.),(10.,30.)]:
  b0,p0,r0,U0=state(.2,V0);b1,p1,r1,U1=state(.8,V1);mean=[.5*(p0[i]+p1[i])for i in range(4)];rho=H*sum(mean[i]*(b1[i]-b0[i])for i in range(4));boundary=sum(mean[i]*(r1[i]-r0[i])for i in(0,3));check('Poisson matrix ports '+str((V0,V1)),U1-U0,rho+boundary,abs(U0)+abs(U1)+abs(rho)+abs(boundary))
 # Authored nonrelativistic, mass-conserving three-product ionization toy.
 incoming=math.sqrt(2*30*e/m);V=incoming/12;cost=10*e;Kcm=.5*(12*m)*V*V;a=math.sqrt((30*e-Kcm-cost)/m);ve1=V+a;ve2=V-a;vi=V
 pin=m*incoming;pout=m*ve1+m*ve2+10*m*vi;Kout=.5*m*(ve1*ve1+ve2*ve2)+.5*10*m*vi*vi
 check('toy ionization momentum',pout,pin,abs(pin)+abs(pout))
 check('toy ionization kinetic plus reference energy',Kout+cost,30*e,Kout+cost+30*e)
 check('toy ionization charge',-e-e+e,-e,3*e)
 (P/'algebra-checks.json').write_text(json.dumps({'status':'passed','scope':'scalar manufactured identities only; no solver/coupled implementation was run','cpu':6,'nice':15,'lease':str(P.parent/'testing-core.lock'),'GPU_work':False,'records':records,'missing_online_work_was_not_inferred':True},indent=2)+'\n')
 print(json.dumps({'status':'passed','algebra_checks':len(records),'native_solver_run':False}))
