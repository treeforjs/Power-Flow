from pathlib import Path
import json, hashlib, datetime
P=Path(__file__).resolve().parent

def source(id,title,authors,year,doi,url,kind,ranges,summary,limits,access,priority='core'):
    return dict(id=id,title=title,authors=authors,year=year,doi=doi,primary_url=url,
                target='isolated gas-phase H2O',projectile='electron',evidence_kind=kind,
                incident_energy_support=ranges,summary=summary,limits=limits,
                inspected_evidence=access,priority=priority,numeric_dataset_promoted=False,
                physical_coupling_ready=False)
S=[]
S.append(source('schutten1966','Gross- and Partial-Ionization Cross Sections for Electrons on Water Vapor in the Energy Range 0.1–20 keV',
 ['J. Schutten','F. J. de Heer','H. R. Moustafa','A. J. H. Boerboom','J. Kistemaker'],1966,'10.1063/1.1726553','https://doi.org/10.1063/1.1726553','experiment',
 [{'observable':'gross ionization','min_eV':100,'max_eV':20000}, {'observable':'fragment-ion partial cross sections','min_eV':20,'max_eV':2000}],
 'Publisher abstract separates the two ranges. Gross measurements report 15% experimental error and Bethe–Fano–Platzman behavior above 400 eV.',
 ['Gross normalization/counting convention requires full methods before use as an event cross section.','No fragment partial measurement above 2 keV established by this paper.','No exclusive branching or secondary energy partition established.'],
 'Publisher abstract and citation inspected; publisher-deposited Crossref metadata archived; full article not retrieved.'))
S[-1]['alternate_primary_url']='https://ir.amolf.nl/pub/1922'
S[-1]['metadata_note']='AMOLF expands H. R. Moustafa as H. R. Moustafa Moussa; publisher citation uses H. R. Moustafa.'
S.append(source('vroom1977','Measurement of energy distributions of secondary electrons ejected from water vapor by fast electrons',
 ['D. A. Vroom','R. L. Palmer'],1977,'10.1063/1.434410','https://doi.org/10.1063/1.434410','experiment',
 [{'observable':'secondary electron spectra','min_eV':1000,'max_eV':10000}],
 'Publisher-deposited abstract gives ejected energies up to 300 eV, full-sphere spectra and angles 30, 60, 90, 120, 150 degrees.',
 ['Lower ejected-energy cutoff, numerical spectra, normalization and uncertainty not bound here.','Does not cover all kinematically allowed secondary energies or fragment-coincident energy sharing.'],
 'Publisher-deposited Crossref abstract and exact author/date/volume metadata archived; full article not retrieved.'))
S[-1].update(secondary_energy_support_eV={'min':None,'max':300,'lower_bound_status':'not stated in inspected abstract'},publication_date='1977-04-15',journal='Journal of Chemical Physics 66(8), 3720–3723')
S.append(source('khare1987','Cross sections for the direct and dissociative ionisation of NH3, H2O and H2S by electron impact',
 ['S. P. Khare','W. J. Meath'],1987,'10.1088/0022-3700/20/9/021','https://doi.org/10.1088/0022-3700/20/9/021','semiempirical theory',
 [{'observable':'direct/dissociative partial-ion and total cross sections','min_eV':None,'min_kind':'channel ionization threshold','max_eV':10000}],
 'Oscillator-strength Jain–Khare approach. Publisher reports satisfactory comparisons for H2O+ and OH+; O+ and H+ are underestimated.',
 ['Model calculation is not a measured 2–10 keV branch table.','Formula/parameters and current-data comparison must be audited before numeric adoption.','Partial-ion predictions do not fix exclusive neutral coproducts.'],
 'IOP publisher abstract inspected through search result; DOI metadata archived. Full article not retrieved.'))
S[-1].update(publication_date='1987-05-14',journal='Journal of Physics B 20, 2101–2116')
S.append(source('singh2013','Partial ionization cross-sections of H2O molecule by 10–25 keV electron ionization',
 ['Raj Singh','Pragya Bhatt','Namita Yadav','R. Shanker'],2013,'10.1016/j.elspec.2013.03.003','https://www.sciencedirect.com/science/article/abs/pii/S0368204813000443','multiple-ion coincidence experiment',
 [{'observable':'relative ion fractions and precursor-specific relative partial cross sections','min_eV':10000,'max_eV':25000}],
 'Six ions resolved. Dication and trication coincidences identify multiple charged fragments; relative fractions are approximately constant within the measured interval.',
 ['Relative yields require absolute normalization and efficiency/multiplicity conventions.','Measured lower bound is 10 keV; no interpolation to 1–8 keV approved.','Reported 94.4/5.3/0.3 percent contributions refer to total ion yield; no conversion to exclusive event probabilities made.'],
 'Elsevier publisher abstract, highlights and section snippets inspected; DOI author metadata archived. Full article not retrieved.'))
S[-1].update(journal='Journal of Electron Spectroscopy and Related Phenomena 186, 58–62',publication_date_metadata='2013-02 (volume date; not asserted as online release date)',detected_ions=['H2O+','OH+','H+','O+','O2+ (atomic O, charge +2)','H2+'],coincidences={'dication':['H+ + OH+','H+ + O+ + H','H+ + H+ + O'],'trication':['H+ + O2+ + H','H+ + H+ + O+']})
S.append(source('miller1987','Differential cross sections for ionization of water vapor by high-velocity bare ions and electrons',
 ['J. H. Miller','W. E. Wilson','S. T. Manson','M. E. Rudd'],1987,'10.1063/1.452774','https://digitalcommons.unl.edu/physicsrudd/22/','semiempirical SDCS theory',
 [{'observable':'electron-impact SDCS model comparison','min_eV':500,'min_kind':'approximate lower comparison scale, not strict validity boundary','max_eV':None}],
 'First-Born low-secondary-energy asymptote joins a binary-encounter high-secondary-energy limit; abstract reports generally experimental-uncertainty agreement above about 500 eV, with discrepancies.',
 ['Upper validated electron energy not established in inspected abstract.','Coefficients, shell scope and electron labeling must be read before implementation.','Proton/other projectile results are not electron validation.'],
 'Authors institutional repository abstract and publisher-deposited Crossref abstract inspected; full article not retrieved.'))
S[-1]['journal']='Journal of Chemical Physics 86, 157 (1987)'
S.append(source('vroom1969','Production of Excited Hydrogen Atoms by Impact of Fast Electrons on Water Vapor',
 ['D. A. Vroom','F. J. de Heer'],1969,'10.1063/1.1671284','https://doi.org/10.1063/1.1671284','optical emission experiment',
 [{'observable':'absolute Lyman-alpha and Balmer-alpha,beta,gamma,delta emission cross sections','min_eV':50,'max_eV':6000}],
 'State-selective dissociative-excitation evidence reaching 6 keV; analyzed with the Bethe approximation.',
 ['Photon yields are not total neutral dissociation or ground-state OH(X)+H event cross sections.','Does not reach the retained 8 keV tail; no extension performed.','Cascade, state, neutral coproduct and recoil resolution remain necessary.'],
 'Publisher-deposited Crossref abstract and primary-paper search text inspected; full article not retrieved.'))
S[-1].update(alternate_primary_url='https://ir.amolf.nl/pub/2025',journal='Journal of Chemical Physics 50, 1883–1887',publication_date='1969-02-15')
S.append(source('bolorizadeh1986','Angular and energy dependence of cross sections for ejection of electrons from water vapor. I. 50–2000-eV electron impact',
 ['M. A. Bolorizadeh','M. E. Rudd'],1986,'10.1103/PhysRevA.33.882','https://journals.aps.org/pra/abstract/10.1103/PhysRevA.33.882','absolute differential experiment',
 [{'observable':'absolute electron-ejection angular/energy distributions','min_eV':50,'max_eV':2000}],
 'Measured angles 15–150 degrees; secondary energies from 2 eV to incident energy minus first ionization potential.',
 ['Provides 1–2 keV overlap, not 8–10 keV coverage.','Parts II and III concern proton and neutral-hydrogen projectiles.','Use the later Hollman correction as an overlap check.'],
 'APS publisher abstract and author/date metadata inspected.'))
S[-1].update(journal='Physical Review A 33, 882–887',publication_date='1986-02-01',secondary_energy_support_eV={'min':2,'max_kind':'incident energy minus first ionization potential'})
S.append(source('hollman1988','Differential cross sections for secondary electron production by 1.5-keV electrons in water vapor',
 ['K. W. Hollman','G. W. Kerby III','M. E. Rudd','J. H. Miller','S. T. Manson'],1988,'10.1103/PhysRevA.38.3299','https://journals.aps.org/pra/abstract/10.1103/PhysRevA.38.3299','revised differential experiment',
 [{'observable':'differential electron production','min_eV':1500,'max_eV':1500}],
 'Improved spurious-electron suppression and forward-angle accounting resolve earlier discrepancies; oxygen K-shell edge is observed.',
 ['Single incident-energy validation point, not a 10 keV table.','Full numerical spectrum and uncertainties not extracted.'],
 'APS publisher abstract and author/date metadata inspected.'))
S[-1].update(journal='Physical Review A 38, 3299',publication_date='1988-10-01')
S.append(dict(id='nist-beb',title='Electron-Impact Cross Section Database: Introduction and Water orbital constants',authors=['NIST'],year=None,doi=None,primary_url='https://pml.nist.gov/PhysRefData/Ionization/intro.html',orbital_constants_url='https://physics.nist.gov/cgi-bin/Ionization/table.pl?ionization=H2O',target='isolated gas-phase H2O',projectile='electron',evidence_kind='nonrelativistic BEB model/database',incident_energy_support=[{'observable':'model applicability limit','min_eV':None,'max_eV':10000,'range_kind':'NIST states do not use above this energy; not validation to this accuracy'}],summary='NIST quotes typical 5–20% accuracy only through about 1 keV. Water entry has four valence orbitals, eight electrons; all Double Ion. flags No. Water-specific differential spectrum is not supplied by this page.',limits=['Total orbital ionization supplies no parent survival or fragment branch.','The listed water entry lacks the core orbital; it is not a bound complete all-shell high-energy event model.','NIST SDCS online scope is H, He and H2, not H2O.'],inspected_evidence='NIST introduction, references and H2O orbital-constant page read through web tool; local HTML requests returned HTTP 403.',numeric_dataset_promoted=False,physical_coupling_ready=False,priority='core'))

follow=[dict(id='khare1989',title='Dissociative ionization of NH3 and H2O molecules by electron impact',authors=['S. P. Khare','Satya Prakash','William J. Meath'],year=1989,doi='10.1016/0168-1176(89)85025-6',primary_url='https://doi.org/10.1016/0168-1176(89)85025-6',status='Publisher-deposited bibliography verified; primary abstract/full text not obtained. No physics/range claim promoted.',reason='Follow up the 1987 minor-ion underprediction.'),dict(id='kim2000',title='Extension of the binary-encounter-dipole model to relativistic incident electrons',authors=['Yong-Ki Kim','José Paulo Santos','Fernando Parente'],year=2000,doi='10.1103/PhysRevA.62.052710',primary_url='https://journals.aps.org/pra/abstract/10.1103/PhysRevA.62.052710',status='APS abstract inspected. General relativistic/inner-shell model, not a water branching dataset.',reason='Future energies above the NIST nonrelativistic ceiling or explicit core-shell work.'),dict(id='champion2002',title='Theoretical differential and total cross sections of water-molecule ionization by electron impact',authors=['C. Champion','J. Hanssen','P. A. Hervieux'],year=2002,doi='10.1103/PhysRevA.65.022710',primary_url='https://journals.aps.org/pra/abstract/10.1103/PhysRevA.65.022710',status='APS abstract inspected; water-vapor distorted-wave Born treatment without exchange. Exact incident range not bound from inspected text.',reason='Independent differential-model check; do not import guessed 10 keV coverage.'),dict(id='fuss2015',title='The role of pyrimidine and water as underlying molecular constituents for describing radiation damage in living tissue: A comparative study',authors=['M. C. Fuss','L. Ellis-Gibbings','D. B. Jones','M. J. Brunger','F. Blanco','A. Muñoz','P. Limão-Vieira','G. García'],year=2015,doi='10.1063/1.4921810',primary_url='https://doi.org/10.1063/1.4921810',status='Primary article search text labels neutral dissociation approximate; 10 keV transport study, not an exclusive neutral-fragment measurement.',reason='Audit any approximate total-inelastic residual before considering it as a model; do not assign that residual to OH(X)+H.')]
coverage=[
 dict(observable='Gross ionization',at_8keV='Experimental coverage identified',sources=['schutten1966'],unresolved='Numerical values and exact charge/event counting convention not bound.'),
 dict(observable='Parent H2O+ and partial-ion yields',at_8keV='Theory candidate to 10 keV; no new high-energy numerical dataset',sources=['khare1987'],unresolved='Minor O+/H+ discrepancies; no approved absolute stitch to existing 1 keV recommendations.'),
 dict(observable='Exclusive multi-ion event branching',at_8keV='Unresolved',sources=['singh2013'],unresolved='Coincidence support starts 10 keV; no data-driven bridge to 8 keV established.'),
 dict(observable='Secondary-electron energy spectrum',at_8keV='Measured incident-energy coverage, incomplete secondary-energy coverage',sources=['vroom1977','miller1987'],unresolved='Only ejected energies <=300 eV verified for the measurement; complete normalized event distribution and shell/channel coupling missing.'),
 dict(observable='Neutral OH(X)+H event cross section',at_8keV='Unresolved',sources=['vroom1969'],unresolved='Existing OH yield table stops at 300 eV; excited-H optical data stop at 6 keV and describe a different observable.'),
 dict(observable='Core-shell/Auger channel and stopping energy',at_8keV='Missing explicit event closure',sources=['hollman1988','nist-beb','kim2000'],unresolved='Core feature exists in measured spectrum; water BEB entry has valence orbitals only. No augmentation or magnitude estimate made.'),
 dict(observable='Native attachment/vibration and other loss channels',at_8keV='No high-energy closure established in this focused inventory',sources=[],unresolved='No high-energy zero or resonant-tail extension inferred; elastic/rotation/vibration and heavy reactions require separate complete transport scope.'),
 dict(observable='Neutral/ion recoil, prompt states and event energy balance',at_8keV='Unresolved',sources=['singh2013','vroom1977'],unresolved='Separate ion yields and inclusive electron spectra do not jointly determine each event.')]
R=dict(schema_version=1,status='additive_primary_source_coverage_audit_only',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),scope_eV=[1000,10000],reference_handoff='../physics-data-handoff.txt',existing_table_extraction_repeated=False,new_numeric_cross_sections_extracted=False,simulation_executed=False,chemistry_executed=False,gpu_executed=False,production_changes=False,registry_does_not_authorize_interpolation_or_extrapolation=True,sources=S,follow_up_leads=follow,coverage_at_retained_tail=coverage,normalization_contract={'event_cross_section':'sigma_event=sum_c sigma_c','ion_yield_cross_section':'Y_i=sum_c nu_i,c sigma_c','charge_yield_cross_section':'sigma_charge=sum_i z_i Y_i','definitions':'c is a mutually exclusive event, nu is product multiplicity, z is ion charge in units of e. These formulas are bookkeeping requirements, not definitions attributed to any uninspected paper.','forbidden_shortcuts':['Use gross total as parent-only H2O:ionization','Normalize overlapping partial-ion yields as exclusive probabilities','Use BEB total as branching','Infer total event weights directly from percentages reported per total ion yield','Hold last numerical table point or extrapolate as a hidden default']},next_steps=['Bind numerical gross data and counting definition from full Schutten methods.','Obtain full Khare 1987 and follow-up 1989 model equations/parameters; test against existing data and upper-end coincidence evidence with explicit model discrepancy.','Obtain Vroom 1977 spectra and full SDCS model; audit normalization, unmeasured W range, electron labeling and core/Auger scope against 1.5–2 keV overlap data.','Resolve independent neutral dissociation channels/state/cascade/recoil data; keep uncovered energies unknown.','Only after event/energy closure, compare local sum(w sigma v)/sum(w) with full physical normalization and band-resolved contributions. No rate or collision run authorized here.'])
(P/'high-energy-source-registry.json').write_text(json.dumps(R,indent=2,ensure_ascii=False)+'\n')

report='''H2O electron-impact coverage from 1 to 10 keV
Prepared 2026-10-29. Primary-source inventory; no numerical data promoted.

The high-energy problem is partly a data-access and observable-definition gap. Primary gross-ionization measurements reach 20 keV, secondary-electron measurements reach 10 keV incident energy, and an established partial-ion model reaches 10 keV. None alone closes exclusive fragmentation, neutral production and event energy sharing at the retained ~8 keV tail. All GPU/domain cases remain unexecuted.

Existing evidence retained
The original handoff and inventories were read without modification. They contain 19 species, 13 balanced reactions, eight EEDF channels, no bundled numerical rates and no completed event-energy partitions. The older copied 26.299946 ns snapshot reaches 8084.47 eV; 57.886% of physical weight exceeds the existing ionization table's 1 keV ceiling. That population fraction is not the missing reaction-rate fraction. No below-1-keV table was re-extracted. Input hashes and additive source metadata are included here.

Observable contract
For mutually exclusive channels c, sigma_event=sum_c sigma_c; an ion yield is Y_i=sum_c nu_i,c sigma_c; a charge yield is sum_i z_i Y_i. Multiplicity makes these different. A coincidence channel may generate several ions and several new electrons in one event. An inclusive partial-ion spectrum cannot be normalized as exclusive branching without that bookkeeping. Native H2O:ionization produces only H2O+ and one extra electron, so assigning any all-ion total to it would change the physical source model. Neutral coproducts, prompt electronic states, recoil, electron sharing and energy loss require separate support. These are bookkeeping deductions, not extra measurements.

Primary sources and exact range limits

1. J. Schutten, F. J. de Heer, H. R. Moustafa, A. J. H. Boerboom and J. Kistemaker (1966), “Gross- and Partial-Ionization Cross Sections for Electrons on Water Vapor in the Energy Range 0.1–20 keV,” J. Chem. Phys. 44, 3924–3928, published 15 May. https://doi.org/10.1063/1.1726553 ; institutional record https://ir.amolf.nl/pub/1922
The publisher abstract explicitly gives gross measurements at 0.1–20 keV but partial fragment measurements only at 0.02–2 keV. The title must not be used to extend partials to 20 keV. It reports 15% experimental error for the gross discussion. Full methods/numbers are still required to bind the detector's gross counting convention to an event model.

2. D. A. Vroom and R. L. Palmer (1977), “Measurement of energy distributions of secondary electrons ejected from water vapor by fast electrons,” J. Chem. Phys. 66(8), 3720–3723, published 15 April. https://doi.org/10.1063/1.434410
The publisher-deposited abstract verifies 1–10 keV primary electrons, ejected energies up to 300 eV, full-sphere spectra and five angles. This directly spans the primary tail but leaves the rest of the allowed secondary-energy domain, channel coincidence and full event normalization unbound. Full text was unavailable; no spectra were digitized.

3. S. P. Khare and W. J. Meath (1987), “Cross sections for the direct and dissociative ionisation of NH3, H2O and H2S by electron impact,” J. Phys. B 20, 2101–2116, published 14 May. https://doi.org/10.1088/0022-3700/20/9/021
The primary oscillator-strength semiempirical calculation runs from threshold to 10 keV. The publisher reports satisfactory H2O+ and OH+ comparisons but underestimates O+ and H+. This is a candidate high-energy partial-yield model, with known discrepancy, rather than experimental or exclusive-branch closure. Equations/parameters were not imported. The 1989 follow-up DOI 10.1016/0168-1176(89)85025-6 is bibliographically verified but its physics was not promoted.

4. Raj Singh, Pragya Bhatt, Namita Yadav and R. Shanker (2013), “Partial ionization cross-sections of H2O molecule by 10–25 keV electron ionization,” J. Electron Spectrosc. Relat. Phenom. 186, 58–62. https://doi.org/10.1016/j.elspec.2013.03.003 ; https://www.sciencedirect.com/science/article/abs/pii/S0368204813000443
Multiple-ion coincidence measurements give relative ions and precursor-specific relative partials, including dication/trication breakup. They begin at 10 keV. Atomic O2+ means O with charge +2. Near-invariant fractions within 10–25 keV do not establish 1–8 keV fractions. Reported 94.4/5.3/0.3% single/double/triple contributions are to total ion yield; no event-probability conversion was made.

5. J. H. Miller, W. E. Wilson, S. T. Manson and M. E. Rudd (1987), “Differential cross sections for ionization of water vapor by high-velocity bare ions and electrons,” J. Chem. Phys. 86, 157. https://doi.org/10.1063/1.452774 ; author repository https://digitalcommons.unl.edu/physicsrudd/22/
The SDCS model joins a first-Born low-secondary-energy form to a binary-encounter limit. Its abstract reports generally experimental-uncertainty agreement above about 500 eV, with discrepancies. The inspected material gives no firm upper electron-validation boundary; coefficients, shell treatment and electron labeling remain a full-text task.

6. D. A. Vroom and F. J. de Heer (1969), “Production of Excited Hydrogen Atoms by Impact of Fast Electrons on Water Vapor,” J. Chem. Phys. 50, 1883–1887, published 15 February. https://doi.org/10.1063/1.1671284 ; https://ir.amolf.nl/pub/2025
Absolute Lyman/Balmer emission yields cover 50–6000 eV. They support selected dissociative excitation, not total neutral dissociation or ground-state OH(X)+H. They also stop below the retained tail. No optical yield was reassigned to a prompt chemistry channel.

7–8. M. A. Bolorizadeh and M. E. Rudd (1986), Phys. Rev. A 33, 882–887: absolute electron-ejection spectra at 50–2000 eV, angles 15–150 degrees, secondary energies 2 eV to T minus first ionization energy. https://doi.org/10.1103/PhysRevA.33.882
K. W. Hollman, G. W. Kerby III, M. E. Rudd, J. H. Miller and S. T. Manson (1988), Phys. Rev. A 38, 3299: improved 1.5 keV spectra correct spurious-electron/forward-angle problems and resolve an oxygen K-shell edge. https://doi.org/10.1103/PhysRevA.38.3299
These are useful 1–2 keV overlap checks. The 1986 Parts II/III use protons/neutral hydrogen, so do not extend electron coverage.

9. NIST Electron-Impact Cross Section Database. https://pml.nist.gov/PhysRefData/Ionization/intro.html ; water constants https://physics.nist.gov/cgi-bin/Ionization/table.pl?ionization=H2O
NIST explicitly disallows its nonrelativistic BEB above 10 keV; that ceiling is not a water accuracy validation. Its typical 5–20% accuracy statement extends only to about 1 keV. The water entry lists four valence orbitals, eight electrons and no double-ionization flags. It supplies no water-specific secondary spectrum or fragment branching, and omits the core orbital. Do not treat this entry as complete all-shell ionization or as a parent H2O+ event cross section.

Practical next preparation
Bind full numerical Schutten data and its counting convention, then audit Khare equations/parameters and the 1989 follow-up against the already extracted overlap and 10 keV coincidence endpoint. Retrieve Vroom spectra and a complete SDCS model, checking the unmeasured secondary tail and 1.5–2 keV corrections. Treat core ionization/Auger electrons as an explicit scope question rather than silently adding them. Ground-state neutral OH and state/recoil coverage above 300 eV remain unresolved; excited-H optical data are a different observable. No endpoint hold, Bethe extrapolation, assumed constant branch or liquid-water substitution is adopted. The native attachment/vibrational channels and other electron energy-loss mechanisms have no new high-energy closure from this focused inventory; their rates are not set to zero by omission.

Before coupling, require exclusive channels to reproduce applicable ion and charge yields with efficiency/multiplicity definitions, conserve H/O/charge and total event energy, and integrate their differential spectra to the same event total. Define electron labels consistently to avoid double counting. Only then assess local weighted sigma*v contributions in 1–2, 2–6, 6–8 and 8–10 keV bands with the original physical normalization. Missing support stays explicit; a truncated EEDF is not renormalized. No rates, transport, chemistry, PIC, GPU or field solves were executed for this inventory.
'''
(P/'high-energy-coverage-review.txt').write_text(report)
for f in json.loads((P/'input-provenance.json').read_text())['files']:
    assert hashlib.sha256(Path(f['path']).read_bytes()).hexdigest()==f['sha256'], f['path']
assert all(not s['numeric_dataset_promoted'] and not s['physical_coupling_ready'] for s in S)
assert next(s for s in S if s['id']=='schutten1966')['incident_energy_support'][1]['max_eV']==2000
assert next(s for s in S if s['id']=='vroom1977')['secondary_energy_support_eV']['max']==300
assert next(s for s in S if s['id']=='singh2013')['incident_energy_support'][0]['min_eV']==10000
checks=dict(json_roundtrip=True,source_ids_unique=len({s['id'] for s in S})==len(S),input_hashes_unchanged=True,no_numeric_data_promoted=True,no_simulation=True,range_contracts_pass=True,core_source_count=len(S),follow_up_lead_count=len(follow))
(P/'validation.json').write_text(json.dumps(checks,indent=2)+'\n')
manifest=[]
for f in sorted(P.rglob('*')):
    if f.is_file() and f.name!='output-manifest.json':
        manifest.append(dict(path=str(f.relative_to(P)),bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest()))
(P/'output-manifest.json').write_text(json.dumps(dict(files=manifest),indent=2)+'\n')
print(json.dumps(checks));print('review_words',len(report.split()))
