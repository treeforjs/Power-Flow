#!/usr/bin/env python3
"""Independent Decimal audit of selected actual CSR rows; no equation solve."""
from pathlib import Path
from decimal import Decimal, localcontext
import hashlib
import json
import numpy as np

out=Path(__file__).resolve().parent
metrics=json.loads((out/'metrics.json').read_text())
cap=Path(metrics['capture'])
rows=np.fromfile(cap/'matrix.rows.i32',dtype='<i4')
cols=np.fromfile(cap/'matrix.cols.i32',dtype='<i4')
vals=np.fromfile(cap/'matrix.values.f64',dtype='<f8')
ldvals=vals.astype(np.longdouble)
b=np.fromfile(cap/'call_0016_constrained_rhs.f64',dtype='<f8')
n=len(b)
selected=set(int(i) for i in np.linspace(0,n-1,257))
checks=[]
for name in ['call_0015_accepted_solution.f64','call_0016_projected_previous_phi.f64','call_0016_incoming_zeroed_X.f64']:
 x=np.fromfile(cap/name,dtype='<f8')
 extended=np.add.reduceat(ldvals*x.astype(np.longdouble)[cols],rows[:-1])-b
 selected.update(int(i) for i in np.argpartition(np.abs(extended),-16)[-16:])
 worst=Decimal(0)
 bound_ratio=Decimal(0)
 with localcontext() as ctx:
  ctx.prec=80
  for i in sorted(selected):
   terms=[Decimal.from_float(float(vals[j]))*Decimal.from_float(float(x[cols[j]])) for j in range(int(rows[i]),int(rows[i+1]))]
   exact=sum(terms,Decimal(0))-Decimal.from_float(float(b[i]))
   # A string with enough digits preserves the extended result independently.
   got=Decimal(str(extended[i]))
   error=abs(got-exact)
   # Conservative product/sum bound for the longdouble audit, not a physical bound.
   magnitude=sum((abs(t) for t in terms),Decimal(0))+abs(Decimal.from_float(float(b[i])))
   budget=Decimal(64)*Decimal(str(np.finfo(np.longdouble).eps))*magnitude+Decimal('1e-90')
   assert error<=budget,(i,str(error),str(budget))
   worst=max(worst,error)
   bound_ratio=max(bound_ratio,error/budget)
 checks.append({'vector':name,'rows_checked':len(selected),'max_absolute_disagreement_C_per_m':str(worst),'max_fraction_of_conservative_rounding_bound':str(bound_ratio)})
receipt={'status':'passed','method':'80-digit Decimal arithmetic of original FP64 values, selected actual CSR rows; no solve',
 'checks':checks,'rows_selection':'257 evenly spaced indices plus 16 largest absolute residual entries for each tested vector',
 'extended_precision_mantissa_bits':int(np.finfo(np.longdouble).nmant),'solver_or_GPU_execution':False,
 'metrics_sha256':hashlib.sha256((out/'metrics.json').read_bytes()).hexdigest()}
(out/'arithmetic-validation.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
