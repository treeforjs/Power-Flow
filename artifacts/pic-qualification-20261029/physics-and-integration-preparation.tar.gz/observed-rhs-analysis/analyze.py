#!/usr/bin/env python3
"""Read-only norms/CSR products of observed vectors. No solver or simulation."""
from pathlib import Path
import hashlib
import json
import math
import os
import resource
import sys
import time
import numpy as np

ROOT = Path('/home/treefor/Documents/Codex/2026-10-28/we/outputs/pic-profile')
CAP = ROOT / 'rhs-observer-1ps-capture'
OUT = Path(__file__).resolve().parent
start = time.monotonic()
capture = json.loads((CAP/'capture.json').read_text())
validation = json.loads((CAP/'validation.json').read_text())
assert capture['status'] == 'complete' and not capture['synthetic_contract_fixture']
assert validation['status'] == 'validated' and validation['audit_upper_CSR_bitwise_parity']
assert capture['captured_solves'] == 16 and capture['captured_populated_steps'] == 8
hashes = {}

def checked_bytes(name):
    data = (CAP/name).read_bytes()
    h = hashlib.sha256(data).hexdigest()
    if name in validation['files']:
        assert validation['files'][name]['sha256'] == h, name
        assert validation['files'][name]['bytes'] == len(data), name
    hashes[name] = {'bytes':len(data), 'sha256':h}
    return data

def arr(name, dtype):
    return np.frombuffer(checked_bytes(name), dtype=dtype)

n = capture['matrix']['rows']
rows = arr('matrix.rows.i32','<i4')
cols = arr('matrix.cols.i32','<i4')
vals = arr('matrix.values.f64','<f8')
mask = arr('essential_mask.u8','u1').astype(bool)
essential = arr('essential.i32','<i4')
assert len(rows)==n+1 and rows[0]==0 and rows[-1]==len(vals)==len(cols)
assert np.all(rows[1:]>rows[:-1]) and len(mask)==n
assert np.array_equal(np.flatnonzero(mask),np.sort(essential))
free = ~mask
ldvals = vals.astype(np.longdouble)

def mv(x, extended=True):
    """Original stored CSR including zeros, with independently rounded summation."""
    if extended:
        return np.add.reduceat(ldvals*x.astype(np.longdouble)[cols], rows[:-1])
    return np.add.reduceat(vals*x[cols], rows[:-1])

def norms(x):
    a = np.asarray(x,dtype=np.longdouble)
    return {'l1':float(np.sum(np.abs(a),dtype=np.longdouble)),
            'l2':float(np.sqrt(np.sum(a*a,dtype=np.longdouble))),
            'linf':float(np.max(np.abs(a),initial=0)),
            'sum':float(np.sum(a,dtype=np.longdouble)),
            'nonzero_entries':int(np.count_nonzero(a))}

def split_norms(x):
    return {'all':norms(x),'free':norms(x[free]),'essential':norms(x[mask])}

def ratio(a,b):
    return a/b if b else None

def energy_error(d):
    d = d.astype(np.longdouble)
    value = float(np.sum(d*mv(d),dtype=np.longdouble))
    assert value >= -1e-25
    return {'delta_phi_A_delta_phi_V_C_per_m':value,
            'A_norm_sqrt_V_C_per_m':math.sqrt(max(0,value))}

records=[]
prev=None
first_b=None
for call in capture['calls']:
    v = {k:arr(meta['file'],'<f8') for k,meta in call['vectors'].items()}
    assert all(len(a)==n and np.isfinite(a).all() for a in v.values())
    b,q,x,p,s,g = (v[k] for k in ['constrained_rhs','full_charge_rhs',
         'incoming_zeroed_X','projected_previous_phi','accepted_solution','guard_residual'])
    assert np.count_nonzero(x[free])==0 and np.array_equal(x[mask],p[mask])
    qfree = q.copy(); qfree[mask]=0
    rzero = mv(x)-b
    rprojected = mv(p)-b
    racc = mv(s)-b
    rfp64 = mv(s,False)-b
    if first_b is None: first_b=b.copy()
    rec={k:call[k] for k in ['sequence','captured_step_ordinal','driver_step_index','half',
         'driver_start_time_s','dt_s','ledger_time_s_at_advance_entry','lower_potential_V','upper_potential_V']}
    rec['field_sampling_time_s'] = call['driver_start_time_s'] + call['dt_s']*(.5 if call['half']==1 else 1.)
    rec['actual_vectors']={k:split_norms(a) for k,a in v.items()}
    rec['derived']={
        'charge_rhs_with_essential_entries_zeroed':norms(qfree),
        'constrained_rhs_minus_free_charge_rhs':split_norms(b-qfree),
        'residual_of_actual_incoming_X_extended':split_norms(rzero),
        'residual_of_actual_projected_trial_extended':split_norms(rprojected),
        'residual_of_accepted_solution_extended':split_norms(racc),
        'residual_of_accepted_solution_FP64_reduceat':split_norms(rfp64),
        'extended_residual_minus_original_guard':split_norms(racc-g),
        'projected_trial_minus_accepted_solution_V':split_norms(p-s),
        'incoming_X_minus_accepted_solution_V':split_norms(x-s),
        'projected_trial_error_A_norm':energy_error(p-s),
        'rhs_delta_from_first':split_norms(b-first_b),
        'guard_limit_C_per_m':max(1e-30,2e-13*call['rhs_norm']),
    }
    qnorm=norms(qfree)['l2']; bnorm=norms(b)['l2']
    rec['ratios']={
        'rhs_l2_over_free_charge_l2':ratio(bnorm,qnorm),
        'guard_limit_over_free_charge_l2':ratio(rec['derived']['guard_limit_C_per_m'],qnorm),
        'captured_guard_l2_over_free_charge_l2':ratio(norms(g)['l2'],qnorm),
        'accepted_extended_residual_l2_over_free_charge_l2':ratio(norms(racc)['l2'],qnorm),
        'projected_trial_residual_l2_over_free_charge_l2':ratio(norms(rprojected)['l2'],qnorm),
        'incoming_X_residual_l2_over_free_charge_l2':ratio(norms(rzero)['l2'],qnorm),
        'projected_trial_residual_l2_over_incoming_X_residual_l2':ratio(norms(rprojected)['l2'],norms(rzero)['l2'])}
    if prev is not None:
        sp,bp,qp,gp,previous_call = prev
        # This is the captured preceding accepted solution, never reconstructed.
        rp = mv(sp)-b
        delta_s=s-sp
        delta_q=q-qp
        delta_b=b-bp
        projection=p-sp
        # Extended subtraction makes cancellation in stored FP64 b explicit.
        charge_vs_b_delta = delta_b.astype(np.longdouble)[free] - delta_q.astype(np.longdouble)[free]
        rec['previous_captured_solution']={
            'sequence':previous_call['sequence'],
            'boundary_values_metadata_identical':all(call[k]==previous_call[k] for k in ['lower_potential_V','upper_potential_V']),
            'residual_against_current_rhs_extended':split_norms(rp),
            'potential_difference_to_current_V':split_norms(delta_s),
            'actual_projected_trial_minus_preceding_accepted_V':split_norms(projection),
            'operator_action_of_projection_change':split_norms(mv(projection)),
            'charge_rhs_change':split_norms(delta_q),
            'constrained_rhs_change':split_norms(delta_b),
            'free_constrained_rhs_change_minus_free_charge_rhs_change':norms(charge_vs_b_delta),
            'solution_change_A_norm':energy_error(delta_s),
            'residual_l2_over_free_charge_l2':ratio(norms(rp)['l2'],qnorm),
            'residual_l2_over_zero_X_residual_l2':ratio(norms(rp)['l2'],norms(rzero)['l2']),
            'residual_l2_over_projected_trial_residual_l2':ratio(norms(rp)['l2'],norms(rprojected)['l2']),
            'residual_l2_over_original_guard_limit':ratio(norms(rp)['l2'],rec['derived']['guard_limit_C_per_m']),
            'free_charge_rhs_change_l2_over_current_charge_l2':ratio(norms(delta_q[free])['l2'],qnorm),
            'delta_equation_closure_extended':split_norms(mv(delta_s)-delta_b-(racc-(mv(sp)-bp))),
        }
    records.append(rec)
    prev=(s.copy(),b.copy(),q.copy(),g.copy(),call)

def ranges(values):
    a=[float(x) for x in values if x is not None]
    return {'min':min(a),'max':max(a),'median':float(np.median(a)),'count':len(a)}

summary={
 'full_charge_rhs_l2_C_per_m':ranges(r['actual_vectors']['full_charge_rhs']['all']['l2'] for r in records),
 'free_charge_rhs_l2_C_per_m':ranges(r['derived']['charge_rhs_with_essential_entries_zeroed']['l2'] for r in records),
 'charge_rhs_essential_l2_C_per_m':ranges(r['actual_vectors']['full_charge_rhs']['essential']['l2'] for r in records),
 'charge_rhs_sum_C_per_m':ranges(r['actual_vectors']['full_charge_rhs']['all']['sum'] for r in records),
 'constrained_rhs_l2_C_per_m':ranges(r['actual_vectors']['constrained_rhs']['all']['l2'] for r in records),
 'rhs_to_charge_l2_ratio':ranges(r['ratios']['rhs_l2_over_free_charge_l2'] for r in records),
 'incoming_X_residual_l2_C_per_m':ranges(r['derived']['residual_of_actual_incoming_X_extended']['all']['l2'] for r in records),
 'projected_trial_residual_l2_C_per_m':ranges(r['derived']['residual_of_actual_projected_trial_extended']['all']['l2'] for r in records),
 'projected_trial_residual_to_charge_l2':ranges(r['ratios']['projected_trial_residual_l2_over_free_charge_l2'] for r in records),
 'captured_guard_residual_l2_C_per_m':ranges(r['actual_vectors']['guard_residual']['all']['l2'] for r in records),
 'guard_limit_C_per_m':ranges(r['derived']['guard_limit_C_per_m'] for r in records),
 'guard_limit_to_charge_l2':ranges(r['ratios']['guard_limit_over_free_charge_l2'] for r in records),
 'captured_guard_residual_to_charge_l2':ranges(r['ratios']['captured_guard_l2_over_free_charge_l2'] for r in records),
 'accepted_extended_residual_to_charge_l2':ranges(r['ratios']['accepted_extended_residual_l2_over_free_charge_l2'] for r in records),
 'previous_accepted_residual_l2_C_per_m':ranges(r['previous_captured_solution']['residual_against_current_rhs_extended']['all']['l2'] for r in records[1:]),
 'previous_accepted_residual_to_charge_l2':ranges(r['previous_captured_solution']['residual_l2_over_free_charge_l2'] for r in records[1:]),
 'previous_accepted_residual_to_zero_X_residual_l2':ranges(r['previous_captured_solution']['residual_l2_over_zero_X_residual_l2'] for r in records[1:]),
 'previous_accepted_residual_to_projected_trial_residual_l2':ranges(r['previous_captured_solution']['residual_l2_over_projected_trial_residual_l2'] for r in records[1:]),
 'previous_accepted_residual_to_guard_limit':ranges(r['previous_captured_solution']['residual_l2_over_original_guard_limit'] for r in records[1:]),
 'consecutive_solution_change_linf_V':ranges(r['previous_captured_solution']['potential_difference_to_current_V']['all']['linf'] for r in records[1:]),
 'projection_overwrite_free_DOF_count':ranges(r['previous_captured_solution']['actual_projected_trial_minus_preceding_accepted_V']['free']['nonzero_entries'] for r in records[1:]),
 'projection_overwrite_free_linf_V':ranges(r['previous_captured_solution']['actual_projected_trial_minus_preceding_accepted_V']['free']['linf'] for r in records[1:]),
 'consecutive_free_charge_rhs_relative_l2_change':ranges(r['previous_captured_solution']['free_charge_rhs_change_l2_over_current_charge_l2'] for r in records[1:]),
 'free_rhs_delta_minus_charge_delta_l2_C_per_m':ranges(r['previous_captured_solution']['free_constrained_rhs_change_minus_free_charge_rhs_change']['l2'] for r in records[1:]),
 'extended_residual_minus_original_guard_l2_C_per_m':ranges(r['derived']['extended_residual_minus_original_guard']['all']['l2'] for r in records),
}
hashes['validation.json']={'bytes':(CAP/'validation.json').stat().st_size,'sha256':hashlib.sha256((CAP/'validation.json').read_bytes()).hexdigest()}
checked_bytes('capture.json')
paritypath=ROOT/'rhs-observer-1ps-cpu7/full-comparison.json'
parity=json.loads(paritypath.read_text())
assert parity['status']=='passed' and parity['comparison_complete']
output={
 'schema':'observed_rhs_opportunity_v1','status':'analyzed_without_solver_execution',
 'capture':str(CAP),'saved_state_comparison':str(paritypath),
 'saved_state_comparison_sha256':hashlib.sha256(paritypath.read_bytes()).hexdigest(),
 'saved_state_comparison_passed':True,
 'matrix':capture['matrix'],'free_DOFs':int(free.sum()),'essential_DOFs':int(mask.sum()),
 'steps':8,'solves':16,'call_window_s':float(capture['calls'][-1]['driver_start_time_s']+capture['calls'][-1]['dt_s']-capture['calls'][0]['driver_start_time_s']),
 'bias_metadata_identical_across_all_calls':all(c[k]==capture['calls'][0][k] for c in capture['calls'] for k in ['lower_potential_V','upper_potential_V']),
 'all_guesses_evaluated_not_accepted_or_used':True,'new_solves_or_GPU_or_simulation_runs':0,
 'raw_unprojected_first_prior_unavailable':True,
 'definitions':{
   'units':'Potential V; assembled epsilon0 Laplacian A has F/m units and RHS/residual C/m. Charge norm is actual assembled full_charge_rhs, not A*phi.',
   'free':'Complement of the actual essential mask. Includes natural outer-boundary DOFs overwritten by ProjectBdrCoefficient before finite-foil essential list replacement.',
   'incoming_X':'Actual captured X: final essential values retained, all free entries zeroed by default FormLinearSystem copy_interior=0.',
   'projected_trial':'Actual captured trial BEFORE FormLinearSystem; original outer-boundary projection and finite-foil assignments already occurred.',
   'previous_captured_solution':'For calls 2..16, actual accepted solution of the immediately preceding captured call. Evaluated unchanged against current A,b, without constructing/resetting a guess. No previous accepted vector captured for call1.',
   'charge_free':'Actual charge RHS restricted to free DOFs; essential entries zeroed only in this offline derived view. No charge deposition is rerun.',
   'bias_view':'b - charge_free is an algebraic difference of captured vectors, not a separately assembled bias solve or self-potential.',
   'norms':'Unweighted algebraic l1/l2/linf norms; no mesh mass weighting or continuum norm claims.',
   'extended_matvec':'Original stored FP64 CSR coefficients/vectors promoted to available NumPy longdouble before products and reduceat row sums. No inferred/symmetrized/reordered matrix; retained stored zeros. This improves arithmetic audit but is not a new solution or forward-error proof.',
   'guard_residual':'Captured original FP64 CPU residual remains authoritative for the unchanged runtime guard. Independent row-sum rounding differs; both recorded.',
   'A_norm':'sqrt(delta_phi^T A delta_phi), algebraic SPD error/energy measure relative to captured accepted solution; not independent physical accuracy.',
   'residual_ratio_limit':'Small residual relative to driven b alone cannot establish tiny charge-field accuracy. This report also divides by actual charge RHS, without asserting a condition number or field-error bound.',
   'sampling_time':'Derived bookkeeping: driver start + dt/2 or dt after corresponding half drift, not newly sampled external fields.',
 },
 'arithmetic':{'numpy_version':np.__version__,'FP64_mantissa_bits':int(np.finfo(float).nmant),'longdouble_mantissa_bits':int(np.finfo(np.longdouble).nmant)},
 'summary':summary,'calls':records,'input_files':hashes,
 'execution':{'affinity':list(os.sched_getaffinity(0)),'nice':os.nice(0),'wall_seconds':time.monotonic()-start,
              'process_CPU_seconds':resource.getrusage(resource.RUSAGE_SELF).ru_utime+resource.getrusage(resource.RUSAGE_SELF).ru_stime,
              'max_RSS_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'thread_env':{k:os.getenv(k) for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']}},
}
(OUT/'metrics.json').write_text(json.dumps(output,indent=2,allow_nan=False)+'\n')
print(json.dumps({'summary':summary,'execution':output['execution']},indent=2))
