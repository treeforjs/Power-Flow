#!/usr/bin/env bash
set -eu
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1
forecast_root=/home/treefor/Documents/Codex/2026-10-28/we/outputs/pic-profile/source-growth-forecast
exec 9>>/home/treefor/Documents/Codex/2026-10-28/we/outputs/pic-profile/testing-core.lock
if ! taskset -c 6 nice -n 15 flock -n 9; then
  printf '%s\n' 'CPU6 lease busy; no source forecast started.' >&2
  exit 75
fi
taskset -c 6 nice -n 15 timeout 90s python3 "$forecast_root/tools/run_forecast.py"
