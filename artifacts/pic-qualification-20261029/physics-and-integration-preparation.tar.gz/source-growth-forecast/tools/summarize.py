#!/usr/bin/env python3
"""Summarize bounded cache quadrature; no PIC or GPU calls."""
import csv
from decimal import Decimal as D, ROUND_CEILING, ROUND_FLOOR, getcontext
import hashlib
import json
import math
import os
from pathlib import Path
import sys
import fcntl

getcontext().prec=60
ROOT=Path(__file__).resolve().parent.parent
PROFILE=ROOT.parent
E=D('1.602176634e-19')
FACE=('back','gap','left','right')
H=D('1e-14')

def load(path):return json.loads(path.read_text(),parse_float=D)
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,value):
    path.resolve().relative_to(ROOT.resolve())
    path.write_text(json.dumps(value,indent=2,default=str,allow_nan=False)+'\n')
def ceil(x):return int(x.to_integral_value(rounding=ROUND_CEILING))
def floor(x):return int(x.to_integral_value(rounding=ROUND_FLOOR))
def csv_rows(path):
    with path.open() as f:return list(csv.DictReader(f))
def save_csv(path,rows):
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
def fmt(x):return f'{float(x):.8g}'

def main():
    assert len(sys.argv)==2
    assert os.sched_getaffinity(0)=={6} and os.getpriority(os.PRIO_PROCESS,0)==15
    actual=os.fstat(9);want=(PROFILE/'testing-core.lock').stat()
    assert (actual.st_dev,actual.st_ino)==(want.st_dev,want.st_ino)
    fcntl.flock(9,fcntl.LOCK_EX|fcntl.LOCK_NB)
    out=Path(sys.argv[1]).resolve();out.relative_to(ROOT.resolve())
    raw=load(out/'integrals.json');segments=csv_rows(out/'segments.csv');instant=csv_rows(out/'instantaneous.csv');crossings=csv_rows(out/'crossings.csv')
    assert raw['complete'] and raw['source_only'] and raw['monotone'] and raw['thermal_states']==295
    assert load(out/'constant-temperature-fixture/check.json')['passed']
    assert len(segments)==4*raw['segments'] and len(instant)==120
    for row in segments:
        lo=D(row['physical_electrons_per_electrode_lower']);hi=D(row['physical_electrons_per_electrode_upper'])
        assert 0<lo<=hi and (hi-lo)/hi<=D('1.000001e-5')
        assert int(row['panels'])>=1 and D(row['final_relative_gap'])<=D(row['coarse_relative_gap'])+D('1e-10')
    for f in range(4):
        for key,label in [('lower','physical_electrons_per_electrode_lower'),('upper','physical_electrons_per_electrode_upper')]:
            actual=sum(D(r[label]) for r in segments if int(r['face'])==f)
            assert abs(actual-raw['face_per_electrode_'+key][f])/actual<D('1e-16')
    # Numeric CSVs retain enough digits for decimal bookkeeping; these are
    # analytic convex brackets with FP cushions, not directed interval math.
    total_lo=2*sum(raw['face_per_electrode_lower']);total_hi=2*sum(raw['face_per_electrode_upper'])
    source_error=2*sum(raw['native_midpoint_error_bound_h1ps'])
    event_rows=[]
    for f,name in enumerate(FACE):
        lo=max(D(0),raw['face_per_electrode_lower'][f]-raw['native_midpoint_error_bound_h1ps'][f])
        hi=raw['face_per_electrode_upper'][f]+raw['native_midpoint_error_bound_h1ps'][f]
        emitted_lo=max(D(0),lo-1);emitted_hi=hi+1
        maximum_event=(1+raw['face_rate_max_per_electrode_s'][f]*H)*(1+D('1e-12'))
        elo_charge=ceil(emitted_lo/maximum_event)
        elo=max(elo_charge,int(raw['face_flush_count_lower_partitioned'][f]))
        ehi=floor(emitted_hi*(1+D('1e-12')))
        assert 0<=elo<=ehi
        event_rows.append(dict(face=name,formal_supply_both_electrodes_lower=2*raw['face_per_electrode_lower'][f],
            formal_supply_both_electrodes_upper=2*raw['face_per_electrode_upper'][f],
            native_window_emitted_both_lower=2*emitted_lo,native_window_emitted_both_upper=2*emitted_hi,
            face_flush_count_lower=elo,face_flush_count_upper=ehi,
            charge_only_flush_lower=elo_charge,partitioned_flush_lower=int(raw['face_flush_count_lower_partitioned'][f]),
            electrode_emission_event_count_lower=2*elo,electrode_emission_event_count_upper=2*ehi,
            maximum_physical_electrons_per_electrode_event=maximum_event))
    save_csv(out/'source-event-bounds.csv',event_rows)
    elo=sum(r['face_flush_count_lower'] for r in event_rows);ehi=sum(r['face_flush_count_upper'] for r in event_rows)
    macro_rows=[]
    for m in [32,16,8]:
        lower=2*m*elo;upper=2*m*ehi
        macro_rows.append(dict(M=m,macros_per_face_flush=2*m,max_macros_per_accepted_step=8*m,
            cumulative_created_macros_lower=lower,cumulative_created_macros_upper=upper,
            cumulative_particle_payload_bytes_lower=80*lower,
            source_sampler_work_relative_to_M32=D(m)/32,
            event_sampling_SD_relative_to_M32=math.sqrt(32/m),
            RNG_constructions_lower=2*(m+1)*elo,RNG_constructions_upper=2*(m+1)*ehi,
            expected_birth_macros_in_1mm_slab_per_electrode_event=D('.04')*m,
            probability_zero_birth_macros_in_slab_per_electrode_event=.96**m,
            slab_birth_charge_relative_SD=math.sqrt(.96/(.04*m)),
            retained_macro_count='unknown',peak_RSS='unknown',wall_time='unknown'))
    save_csv(out/'macro-cost-noise.csv',macro_rows)
    milestones=[]
    for t in sorted({D(r['time_s']) for r in instant}):
        state=[r for r in instant if D(r['time_s'])==t and int(r['M'])==32]
        included=[r for r in segments if D(r['end_s'])<=t+D('1e-22')]
        low=2*sum(D(r['physical_electrons_per_electrode_lower']) for r in included)
        high=2*sum(D(r['physical_electrons_per_electrode_upper']) for r in included)
        current=sum(D(r['source_current_both_electrodes_A']) for r in state)
        assert abs(current-2*E*sum(D(r['physical_electrons_per_electrode_s']) for r in state))/current<D('1e-15')
        milestones.append(dict(time_ns=t*D('1e9'),formal_cumulative_electrons_lower=low,
            formal_cumulative_electrons_upper=high,formal_cumulative_charge_magnitude_C_lower=E*low,
            formal_cumulative_charge_magnitude_C_upper=E*high,formal_source_current_A=current,
            max_temperature_K=max(D(r['max_temperature_K']) for r in state)))
    save_csv(out/'milestones.csv',milestones)
    assert milestones[0]['formal_cumulative_electrons_upper']==0
    eedf_path=PROFILE/'fragmentation-raikou-plan/checkpoint-electron-samples.csv'
    assessment=PROFILE/'fragmentation-raikou-plan/snapshot-assessment.json'
    eedf_before={str(p):digest(p) for p in [eedf_path,assessment]}
    totals={part:dict(weight=0.,energy=0.,above_1000=0.,above_300=0.,macros=0) for part in ['full','slab']}
    for row in csv_rows(eedf_path):
        w=float(row['weight_physical_electrons']);energy=float(row['kinetic_energy_eV'])
        for part in (['full','slab'] if row['inside_slab']=='True' else ['full']):
            v=totals[part];v['weight']+=w;v['energy']+=w*energy;v['above_1000']+=w*(energy>1000);v['above_300']+=w*(energy>300);v['macros']+=1
    eedf=dict(absolute_time_s=load(assessment)['absolute_time_s'],snapshot_not_time_history=True)
    for part,v in totals.items():
        eedf[part]=dict(mean_energy_eV=v['energy']/v['weight'],physical_electrons=v['weight'],
            macros=v['macros'],weighted_fraction_above_1000_eV=v['above_1000']/v['weight'],
            weighted_fraction_above_300_eV=v['above_300']/v['weight'])
    assert abs(eedf['full']['mean_energy_eV']-float(load(assessment)['mean_energy_eV']))<1e-8
    assert eedf_before=={str(p):digest(p) for p in [eedf_path,assessment]}
    steps=max(int(raw['any_state_step_lower_bound']),ceil((raw['end_s']-raw['start_s'])/D('1e-12')))
    field_steps=ceil(D(elo)/4)
    noise=[]
    for time in [min(D(r['time_s']) for r in instant),max(D(r['time_s']) for r in instant)]:
        for m in [32,16,8]:
            rows=[r for r in instant if D(r['time_s'])==time and int(r['M'])==m]
            rate=sum(D(r['physical_electrons_per_electrode_s']) for r in rows)
            noise.append(dict(time_ns=time*D('1e9'),M=m,
                instantaneous_current_weighted_unsampled_probability=sum(D(r['physical_electrons_per_electrode_s'])*D(r['expected_unsampled_source_probability']) for r in rows)/rate,
                event_energy_mean_relative_SD_min=min(D(r['event_mean_energy_relative_SD']) for r in rows),
                event_energy_mean_relative_SD_max=max(D(r['event_mean_energy_relative_SD']) for r in rows)))
    native_occupied_steps=ceil((D('60')-D('26.48'))*D('1e-9')/H)
    summary=dict(status='complete_bounded_source_only_forecast',decimal_values_encoded_as_strings=True,
        window_ns=[D('26.48'),D('60')],reference_depth_m=D('.025'),both_foil_source_area_m2=D('.000520'),
        formal_supply_electrons=[total_lo,total_hi],formal_supply_charge_magnitude_C=[E*total_lo,E*total_hi],
        formal_supply_relative_bracket_width=(total_hi-total_lo)/total_hi,
        native_midpoint_source_error_bound_electrons_hmax_1ps=source_error,
        arbitrary_initial_and_final_pending_electrons_each_both_foils_less_than=8,
        native_emitted_window_electrons_lower=sum(r['native_window_emitted_both_lower'] for r in event_rows),
        native_emitted_window_electrons_upper=sum(r['native_window_emitted_both_upper'] for r in event_rows),
        face_flush_count_bounds=[elo,ehi],electrode_emission_event_count_bounds=[2*elo,2*ehi],
        face_events=event_rows,macro_cost_and_noise=macro_rows,instantaneous_noise_diagnostics=noise,
        accepted_step_lower_bound_any_native_state=steps,
        accepted_step_lower_bound_if_occupied_throughout=native_occupied_steps,
        nonempty_advance_lower_bound_from_flushes=field_steps,
        field_solve_calls_lower_bound_from_flushes=2*field_steps,
        CPU_Richardson_evaluations_lower_bound=9216*steps,
        CPU_patch_CDF_entries_constructed_lower_bound=2*sum(k*r['face_flush_count_lower'] for k,r in zip([2048,2048,256,256],event_rows)),
        minimum_source_only_dt_fs=raw['minimum_source_only_dt_s']*D('1e15'),
        source_guard_below_occupied_10fs_cap=False,
        actual_late_dt_s=None,losses=None,retention=None,retained_macros=None,peak_memory=None,wall_time=None,
        max_temperature_K=raw['max_temperature_K'],milestones=milestones,EEDF_context=eedf,
        quadrature=dict(segments=raw['segments'],thermal_nodes=raw['source_evaluations'],
            Richardson_evaluations=raw['Richardson_evaluations'],wall_s=raw['wall_s'],
            max_segment_relative_bracket=max(D(r['final_relative_gap']) for r in segments),
            max_initial_coarse_relative_bracket=max(D(r['coarse_relative_gap']) for r in segments),
            max_panels=max(int(r['panels']) for r in segments),nested_refinement_checks_passed=True,
            constant_temperature_fixture_passed=True,directed_interval_arithmetic=False),
        assumptions=['Frozen native Richardson phi4.3eV and ideal A1201732.289489034',
            'Native linear interpolation of each absolute-temperature patch; no temporal extrapolation',
            'Upper back/gap/left/right cache mirrored to lower electrode;25mm extrusion',
            'Constant provisional material properties; no phase change or moving geometry',
            'Collisionless electron-only model; no gas, ion, chemistry, or material feedback',
            'Native schedule hypothetically completes the exact stated window without guard failure',
            'Unknown per-face/electrode pending source in[0,1) at both endpoints',
            'Analytic real-arithmetic bounds evaluated in floating point with explicit cushions'],
        GPU_execution=False,trajectory_steps=0,field_solves_executed=0,heating_runs=0,
        production_changed=False,source_count_change_recommended=False,
        EEDF_input_sha256=eedf_before)
    assert summary['minimum_source_only_dt_fs']>10
    write(out/'summary.json',summary)
    report=[]
    def line(s=''):report.append(s)
    line('Source-growth forecast,26.48->60ns -- source-only, no execution decision')
    line('Prepared2026-10-29. Full production run remains frozen/untouched.')
    line()
    line(f'Formal supplied electrons across BOTH foils: [{fmt(total_lo)}, {fmt(total_hi)}].')
    line(f'Charge magnitude: [{fmt(E*total_lo)}, {fmt(E*total_hi)}] C; electron charge has negative sign.')
    line(f'Convex quadrature bracket width: {fmt(100*(total_hi-total_lo)/total_hi)}%.')
    line(f'Formal current magnitude rises {fmt(milestones[0]["formal_source_current_A"])} -> {fmt(milestones[-1]["formal_source_current_A"])} A.')
    line('These are unrestricted Richardson source-law values, not transmitted/collected current or retained charge.')
    line()
    line('Formal cumulative supply and instantaneous current (both electrodes)')
    line('time_ns       cumulative_electrons_lower..upper       |Q|_C_lower..upper        I_A          Tmax_K')
    for v in milestones:
        line(f'{float(v["time_ns"]):7.2f}       {fmt(v["formal_cumulative_electrons_lower"])}..{fmt(v["formal_cumulative_electrons_upper"])}       {fmt(v["formal_cumulative_charge_magnitude_C_lower"])}..{fmt(v["formal_cumulative_charge_magnitude_C_upper"])}       {fmt(v["formal_source_current_A"])}       {fmt(v["max_temperature_K"])}')
    line()
    line('Model/input support')
    line('295 cached boundary states;2048/2048/256/256 patches; absolute kelvin already includes initial offset.')
    line('Native face mapping is top->back,bottom->gap,left/right, with mirrored lower foil and reversed side profiles.')
    line('Both foils have total emitting area5.20e-4m2 at25mm extrusion. No1mm-slab rescaling of full source.')
    line('J(T)=1201732.289489034*T^2*exp[-4.3*e/(kB*T)] A/m2; the actual foil work function/A are uncalibrated.')
    line(f'Future patch maximum reaches {fmt(raw["max_temperature_K"])}K at60ns; all patch intervals after26.48ns are nondecreasing.')
    line('The surviving thermionic-supply metadata calls the heating provisional constant-property, without melting/vaporization.')
    line('The associated restored field/heating configuration declares sigma3e6S/m, volumetric heat capacity2.8e6J/m3/K,')
    line('thermal conductivity16W/m/K and300K initial state; it explicitly disclaims a qualified SS304 material model.')
    line('The original2048-case source paths named in supply metadata no longer exist here. The binary temperature cache')
    line('is the forecast input; no material re-fit, new thermal solution, phase cutoff, or temperature clipping was invented.')
    line('Interpolation stays within the recorded0.749788..60ns support. Recorded hot temperatures still exceed material-model validity.')
    line('No phase change, material motion, Schottky/tunneling, collisions, neutral/ion chemistry, surface depletion or gas feedback is added.')
    line()
    line('Bounded quadrature and schedule uncertainty')
    line('Per-electrode face rate lambda_f=L_f*0.025/(e*K_f)*sum_i J(T_i); broad L=.005m, side L=.0002m.')
    line('For C=phi*e/kB, J_second(T)=A*exp(-C/T)*(2+2C/T+(C/T)^2)>0.')
    line('Within each native linear-temperature interval, composite midpoint sums bound below and trapezoid sums above.')
    line('Each interval is doubled until all four relative gaps<=1e-5; brackets must nest. No PIC clock is stepped.')
    line(f'{raw["segments"]} intervals; {raw["source_evaluations"]} distinct thermal nodes; maximum {summary["quadrature"]["max_panels"]} panels/interval;')
    line(f'max initial/final interval gap={fmt(summary["quadrature"]["max_initial_coarse_relative_bracket"])} / {fmt(summary["quadrature"]["max_segment_relative_bracket"])}; integration wall={fmt(raw["wall_s"])}s.')
    line('The constant2500K fixture independently checks analytic area*duration supply and the both-foil factor.')
    line('Bounds are mathematical real-arithmetic brackets evaluated with double/long-double arithmetic and1e-12 cushions;')
    line('they are not a certified directed-rounding interval proof. Input/model error dominates this integration tolerance.')
    line('Native arbitrary midpoint schedules may straddle thermal knots. TV(lambda_prime), including all slope jumps,')
    line('gives |native_midpoint_integral-exact|<=h_max^2*TV/8 for the same exact window endpoints.')
    line(f'Using universal h_max=1ps gives <= {fmt(source_error)} electrons across both foils;10fs gives1e-4 of this bound.')
    line('No actual late accepted dt is inferred. Existing gyro/plasma/displacement/input-clock guards may tighten it.')
    line(f'The source-induced guard alone bottoms at {fmt(summary["minimum_source_only_dt_fs"])}fs, above the occupied10fs cap.')
    line('A native path starting at a different frozen timestamp needs its endpoint correction;26.48ns is the declared forecast boundary.')
    line()
    line('Reservoir/event accounting -- cumulative births are not retained particles')
    line('Each face has one symmetric per-electrode reservoir. At ne>=1 it emitsM macros at EACH electrode, then resets')
    line('the entire pool to0. It does not subtract one electron, cap event charge at1, or emit one macro per electron.')
    line('A face flush therefore creates2M macros; a step can flush four faces and create8M. All counts preserve source charge.')
    line('R0,R1 are unknown in[0,1) per face/electrode. Emitted P=S_native+R0-R1; sum across both foils differs by<8e.')
    line('Every emitting step is<=10fs under native occupied/empty-to-emission guards. Hence a face/electrode event has')
    line('1<=N_event<1+lambda_face,max*10fs, while its macro weight isN_event/M. Charge alone boundsE betweenP/max_event andP.')
    line('A stronger clock-free lower bound uses midpoint bins: remove2ps edge coverage; each ofE+1 nonemitting blocks')
    line('carries<1e, andE emitting steps occupy<=E*10fs. Thus E>=ceil[(Delta-2ps-1/lambda(a))/(10fs+1/lambda(a))].')
    line('Sum these disjoint midpoint-bin bounds per face. Reservoir endpoint uncertainty and universal midpoint error are retained.')
    line('face        formal_electrons_both_lower..upper          face_flush_lower..upper')
    for v in event_rows:line(f'{v["face"]:5s}       {fmt(v["formal_supply_both_electrodes_lower"])}..{fmt(v["formal_supply_both_electrodes_upper"])}       {v["face_flush_count_lower"]}..{v["face_flush_count_upper"]}')
    line(f'Total face flushes bounded [{elo}, {ehi}]; electrode emission calls are twice these counts.')
    line('The upper bound is deliberately broad because no lower accepted dt is assumed. No exact future event trace is claimed.')
    line('Near one-electron threshold, expected flush delay is supply-limited and macros carry about1/M electron.')
    line('Once a face delivers>>1e per accepted step, it flushes each such step; rising supply mostly raises weights.')
    line('crossings.csv lists one-electron-per1ps/10fs and nominal10fs weight-one crossings; these are rate diagnostics, not actual dt.')
    line('face      first>=1e/10fs_ns       nominal60ns_electrons_per_macro_at10fs,M32')
    for f,name in enumerate(FACE):
        crossing=next(r for r in crossings if int(r['face'])==f and r['meaning']=='one_electron_per10fs')
        weight=raw['face_rate_max_per_electrode_s'][f]*H/32
        line(f'{name:5s}     {fmt(D(crossing["time_s"])*D("1e9"))}                     {fmt(weight)}')
    line('Those illustrative60ns10fs weights double atM16 and quadruple atM8; smaller actual dt changes them.')
    line()
    line('Count/cost/noise comparison for the SAME hypothetical accepted/source trace')
    line('M       macros/flush      cumulative_created_macros_lower..upper        sampler_work/32      SD/32      slab_birth_mean/P0')
    for v in macro_rows:line(f'{v["M"]:2d}      {v["macros_per_face_flush"]:3d}              {v["cumulative_created_macros_lower"]}..{v["cumulative_created_macros_upper"]}       {fmt(v["source_sampler_work_relative_to_M32"])}       {fmt(v["event_sampling_SD_relative_to_M32"])}       {fmt(v["expected_birth_macros_in_1mm_slab_per_electrode_event"])}/{fmt(v["probability_zero_birth_macros_in_slab_per_electrode_event"])}')
    line('Slab mean/P0 entries are per electrode event; a two-electrode face flush doubles the mean birth count.')
    line('The slab birth probability is1mm/25mm=.04 for native uniform axial launch; it is not a transported-density assumption.')
    line('For patch probabilityp, Var(represented patch source)=N_event^2*p*(1-p)/M; missing source probability=sum p*(1-p)^M.')
    line('M16 hassqrt2 andM8 has2 timesM32 source SD at fixed event. Larger physical macro weight does not improve this sampling.')
    line('Instantaneous current-profile diagnostics (actual events use reservoir-integrated profiles):')
    for n in noise:line(f'  {float(n["time_ns"]):.2f}ns M{n["M"]}: current-weighted unsampled mass={fmt(n["instantaneous_current_weighted_unsampled_probability"])}; event energy-mean relative SD={fmt(n["event_energy_mean_relative_SD_min"])}..{fmt(n["event_energy_mean_relative_SD_max"])}')
    line('The thermal effusive source mean is2kBT (nonrelativistic), around0.25..0.30eV initially and1.66..1.91eV at60ns,')
    line('distinct from the accelerated gap EEDF. Macros share event charge; they do not resolve all warm patches individually.')
    line()
    line('What force offload can and cannot settle')
    line(f'A native completion needs at least {steps} accepted steps even allowing empty states, from monotone supply promotion')
    line('and the original empty<=1ps/occupied<=10fs rules. This is a lower work bound, not a predicted schedule.')
    line(f'If occupied throughout, duration/10fs alone gives {native_occupied_steps} steps; this condition is not assumed.')
    line(f'At least {field_steps} source-bearing advance calls and {2*field_steps} native solve_fields calls follow from flushes/4.')
    line(f'The two mandatory4608-patch Richardson sweeps per iteration alone imply >= {9216*steps} CPU J evaluations;')
    line('an empty-state will_emit check adds a third sweep. CDF construction isO(K) per electrode event independent ofM.')
    line('Native source RNG construction costs(M+1) per electrode event; macro generation/allocation isO(M).')
    line('Cumulative80B particle payload construction is reported in macro-cost-noise.csv; it is not resident/peak memory.')
    line('Retained macros=N_initial+births-absorbed-escaped, with every term defined on actual trajectories. No future losses,')
    line('retention, residence time, two-million-particle guard time, late EEDF, phase cost or wall ETA is available from this cache.')
    line('Force offload does not remove source integration/RNG/allocation, charge deposition, Poisson work or timestep guards.')
    line('This forecast therefore cannot establish that force offload alone is sufficient; use the already-authorized bounded')
    line('phase capture/owner review for measured costs. No new capture, offload test, or run was started here.')
    line()
    line('Coupled validation and energy-data coverage')
    line('No emission count change is recommended.32/16 still need64-referenced common-trace and native-adaptive paired stages,')
    line('six seed triplets per decision stage, physical-weight/fresh/sink/field metrics and the locked confidence/resource gates.')
    line('Source-only agreement is insufficient;8 remains a noise/cost comparison outside the current64/32/16 coupled proposal.')
    line(f'The audited snapshot at {fmt(eedf["absolute_time_s"]*D("1e9"))}ns has mean {fmt(eedf["full"]["mean_energy_eV"])}eV;')
    line(f'weighted >1keV fractions are {fmt(100*eedf["full"]["weighted_fraction_above_1000_eV"])}% full and {fmt(100*eedf["slab"]["weighted_fraction_above_1000_eV"])}% in1mm slab.')
    line('This is the existing26.299946ns snapshot, consistent with the early-final~1.74keV/58%/66% context; it is not a60ns EEDF.')
    line('Neutral OH data end at300eV, ionization data at1keV, and DEA much lower. No silent high-energy extrapolation or')
    line('instant H2O-breakup closure is supplied. See the physics/data handoff for missing branching/recoil/energy/gas inputs.')
    line()
    line('Resources and reproducibility')
    line('One CPU6 job at nice15, one thread, testing-core.lock. Standard library/compiler only; no dependencies installed.')
    line('Utility caps:45CPU seconds,50wall seconds,256MiB address space,200000 thermal nodes,32768 panels/interval; wrapper90s.')
    line('Actual build/integration resource receipts, linkage, unchanged-input hashes and the2500K fixture are sealed in this attempt.')
    line('Zero MPI initialization, GPU contexts/probes, Poisson solves, trajectory steps or heating runs. Production files/signals untouched.')
    line('Reproduce: bash '+str(ROOT/'run-forecast.sh'))
    line('Core results: '+str(out/'summary.json'))
    line('Detailed bounds: '+str(out/'segments.csv')+'; source-event-bounds.csv; milestones.csv; macro-cost-noise.csv; instantaneous.csv; crossings.csv')
    line('Input context: '+str(PROFILE.parent/'heating-history-full.json'))
    line('Material/source scope: '+str(PROFILE.parent/'thermionic-supply/summary.json'))
    line('Material configuration: /home/treefor/projects/Power-Flow/runs/restore_field_mpi8_domain40mm/configuration.json')
    line('Coupled proposal: '+str(PROFILE/'source-sampling-validation/coupled-validation-proposal.txt'))
    line('Physics/EEDF: '+str(PROFILE/'fragmentation-raikou-plan/physics-data-handoff.txt'))
    line('CHICAGO comparison: '+str(PROFILE/'fragmentation-raikou-plan/chicago-comparison.txt'))
    text='\n'.join(report)+'\n';(out/'forecast-report.txt').write_text(text)
    (ROOT/'forecast-report.txt').write_text(text)
    write(ROOT/'summary.json',summary)
    write(out/'checks.json',dict(passed=True,geometry_and_both_foil_factor=True,convex_brackets=True,
        nested_refinement=True,all_final_brackets_within_1e_minus5=True,face_sum_reconciled=True,
        constant_temperature_fixture=True,source_guard_above_10fs=True,EEDF_metadata_reconciled=True,
        unknown_retention_and_timestep_preserved=True,physical_convergence_claimed=False))
    write(out/'seal.json',dict(files_sha256={str(p.relative_to(out)):digest(p) for p in sorted(out.rglob('*')) if p.is_file() and p.name!='seal.json'},
        tools_sha256={p.name:digest(p) for p in (ROOT/'tools').iterdir() if p.is_file()}))
    write(ROOT/'latest.json',dict(status=summary['status'],result_directory=str(out),report=str(ROOT/'forecast-report.txt'),summary=str(ROOT/'summary.json')))
    print(json.dumps(dict(status=summary['status'],face_flush_count_lower=elo,accepted_step_lower=steps)))

if __name__=='__main__':main()
