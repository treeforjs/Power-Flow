#include "native_source.hpp"
#include <chrono>
#include <iomanip>
#include <iostream>
#include <map>
#include <sys/resource.h>
#include <sched.h>
namespace {
constexpr double initial=26.48e-9,h_occupied=1e-14,h_empty=1e-12;
constexpr double A=1201732.289489034,phi=4.3,eps=8.8541878188e-12,H=.025;
constexpr double source_C=.01*eps*pic_me*25e-6/pic_e;
constexpr long double relative_tolerance=1e-5L,roundoff_pad=1e-12L;
constexpr std::array<double,4> lengths{.005,.005,.0002,.0002};
struct Value {std::array<long double,4> rate{};double maxJ=0,maxT=0;};
struct Segment {
    double a=0,b=0;std::array<long double,4> lower{},upper{},derivative_a{},derivative_b{};
    std::array<long double,4> coarse_gap{};
    Value left,right;std::size_t panels=0;
};
auto began=std::chrono::steady_clock::now();std::size_t evaluations=0,richardson_evaluations=0;
void require(bool v,const char* s){if(!v)throw std::runtime_error(s);}
struct Evaluate {
    const Thermal& thermal;std::map<double,Value> cache;
    Value operator()(double t){
        auto found=cache.find(t);if(found!=cache.end())return found->second;
        require(++evaluations<=200000,"source evaluation cap reached");
        require(std::chrono::duration<double>(std::chrono::steady_clock::now()-began).count()<45,"45s source utility wall cap reached");
        auto T=thermal.at(t);Value v;
        for(int f=0;f<4;++f){long double sum=0;for(double temp:T[f]){++richardson_evaluations;double J=pic_richardson_supply_A_m2(temp,phi,A);sum+=J;v.maxJ=std::max(v.maxJ,J);v.maxT=std::max(v.maxT,temp);}
            v.rate[f]=sum*lengths[f]*H/(pic_e*T[f].size());}
        cache[t]=v;return v;
    }
};
Segment integrate(Evaluate& evaluate,double a,double b){
    Segment result;result.a=a;result.b=b;result.left=evaluate(a);result.right=evaluate(b);
    std::array<long double,4> previous_lo{},previous_hi{};
    for(std::size_t n=1;n<=32768;n*=2){
        const double dt=(b-a)/n;std::array<long double,4> lo{},hi{};
        auto left=evaluate(a);
        for(std::size_t k=0;k<n;++k){
            double right_time=k+1==n?b:a+(k+1)*dt;
            auto middle=evaluate(a+(k+.5)*dt),right=evaluate(right_time);
            for(int f=0;f<4;++f){lo[f]+=middle.rate[f]*dt;hi[f]+=(left.rate[f]+right.rate[f])*(.5L*dt);}
            left=right;
        }
        bool complete=true;
        for(int f=0;f<4;++f){lo[f]*=1-roundoff_pad;hi[f]*=1+roundoff_pad;
            require(lo[f]>0&&hi[f]>=lo[f],"convex source bounds failed");
            if(n==1)result.coarse_gap[f]=(hi[f]-lo[f])/hi[f];
            else require(lo[f]>=previous_lo[f]*(1-1e-10L)&&hi[f]<=previous_hi[f]*(1+1e-10L),"refinement brackets are not nested");
            previous_lo[f]=lo[f];previous_hi[f]=hi[f];
            complete&=(hi[f]-lo[f])<=relative_tolerance*hi[f];}
        if(complete){result.lower=lo;result.upper=hi;result.panels=n;return result;}
    }
    throw std::runtime_error("quadrature refinement cap reached");
}
std::array<long double,4> derivative(const Thermal& thermal,double t,std::size_t k){
    auto T=thermal.at(t);std::array<long double,4> answer{};
    constexpr double barrier=phi*pic_e/1.380649e-23;
    for(int f=0;f<4;++f){long double sum=0;const auto K=thermal.sizes[f];
        for(std::size_t i=0;i<K;++i){const double temp=T[f][i];const double slope=(thermal.temperatures[f][(k+1)*K+i]-thermal.temperatures[f][k*K+i])/(thermal.times[k+1]-thermal.times[k]);
            ++richardson_evaluations;sum+=pic_richardson_supply_A_m2(temp,phi,A)*(2/temp+barrier/(temp*temp))*slope;}
        answer[f]=sum*lengths[f]*H/(pic_e*K);}
    return answer;
}
void array_json(std::ostream& out,const std::array<long double,4>& v){out<<'[';for(int i=0;i<4;++i){if(i)out<<',';out<<v[i];}out<<']';}
}
int main(int argc,char** argv){try{
    require(argc==3,"Usage: forecast THERMAL_BINARY OUTPUT_DIR");
    cpu_set_t mask;CPU_ZERO(&mask);sched_getaffinity(0,sizeof(mask),&mask);
    require(CPU_COUNT(&mask)==1&&CPU_ISSET(6,&mask)&&getpriority(PRIO_PROCESS,0)==15,"CPU6/nice15 required");
    Thermal thermal(argv[1]);const std::filesystem::path out=argv[2];
    require(thermal.sizes==std::array<std::uint64_t,4>{2048,2048,256,256},"thermal geometry changed");
    const double end=thermal.times.back();require(initial>=thermal.times.front()&&std::abs(end-60e-9)<1e-20,"thermal support does not cover26.48->60ns");
    bool monotone=true;std::size_t cooling=0;
    auto first=std::upper_bound(thermal.times.begin(),thermal.times.end(),initial)-thermal.times.begin()-1;
    for(int f=0;f<4;++f)for(std::size_t k=first;k+1<thermal.times.size();++k)for(std::size_t i=0;i<thermal.sizes[f];++i){
        if(thermal.temperatures[f][(k+1)*thermal.sizes[f]+i]<thermal.temperatures[f][k*thermal.sizes[f]+i]){monotone=false;++cooling;}}
    require(monotone,"monotonicity-dependent rate/step bounds require a new analysis for cooling inputs");
    Evaluate evaluate{thermal,{}};std::vector<double> knots{initial,end};
    for(double t:thermal.times)if(t>initial&&t<end)knots.push_back(t);
    const std::array<double,10> report_ns{26.48,27,28,30,35,40,45,50,55,60};
    const auto report_time=[&](double ns){return ns==report_ns.front()?initial:std::min(end,ns*1e-9);};
    for(double ns:report_ns){double t=report_time(ns);if(t>initial&&t<end)knots.push_back(t);}
    std::sort(knots.begin(),knots.end());knots.erase(std::unique(knots.begin(),knots.end()),knots.end());
    std::vector<Segment> segments;std::array<long double,4> lower{},upper{},variation{},previous_derivative{},flush_lower{};
    bool have_previous=false;long double all_state_steps_lower=0,occupied_steps_lower=0;
    std::ofstream per(out/"segments.csv");per<<std::setprecision(21)<<"start_s,end_s,face,physical_electrons_per_electrode_lower,physical_electrons_per_electrode_upper,panels,rate_start_per_s,rate_end_per_s,any_state_dt_upper_s,source_only_dt_upper_s,step_count_lower_for_midpoints,coarse_relative_gap,final_relative_gap,face_flush_count_lower_by_midpoint\n";
    for(std::size_t n=0;n+1<knots.size();++n){
        auto s=integrate(evaluate,knots[n],knots[n+1]);
        auto k=std::clamp(int(std::upper_bound(thermal.times.begin(),thermal.times.end(),.5*(s.a+s.b))-thermal.times.begin())-1,0,int(thermal.times.size())-2);
        s.derivative_a=derivative(thermal,s.a,k);s.derivative_b=derivative(thermal,s.b,k);
        for(int f=0;f<4;++f){lower[f]+=s.lower[f];upper[f]+=s.upper[f];variation[f]+=std::abs(s.derivative_b[f]-s.derivative_a[f]);if(have_previous)variation[f]+=std::abs(s.derivative_a[f]-previous_derivative[f]);previous_derivative[f]=s.derivative_b[f];}
        have_previous=true;
        const long double maximum_face_lower=*std::max_element(s.left.rate.begin(),s.left.rate.end());
        const double source_upper=std::cbrt(source_C/std::max(s.left.maxJ,1e-100));
        const double any_upper=std::min({h_empty,source_upper,std::max(h_occupied,double(1/maximum_face_lower))});
        // Count by accepted-step midpoint. At most two1ps boundary panels can
        // contribute from outside an interval; every remaining panel is<=upper.
        const long double count=std::max(0.L,std::ceil(((s.b-s.a)-2*h_empty)/any_upper-1e-10L));
        const long double occupied=std::max(0.L,std::ceil(((s.b-s.a)-2*h_occupied)/h_occupied-1e-10L));
        all_state_steps_lower+=count;occupied_steps_lower+=occupied;
        for(int f=0;f<4;++f){
            // Between E emitting steps, E+1 nonemitting blocks each carry<1e.
            // Emitting steps are<=10fs. Count by midpoint with2ps edge padding.
            const long double rate=s.left.rate[f]*(1-1e-12L);
            const long double flush=std::max(0.L,std::ceil(((s.b-s.a)-2*h_empty-1/rate)/(h_occupied+1/rate)-1e-10L));
            flush_lower[f]+=flush;
            per<<s.a<<','<<s.b<<','<<f<<','<<s.lower[f]<<','<<s.upper[f]<<','<<s.panels<<','<<s.left.rate[f]<<','<<s.right.rate[f]<<','<<any_upper<<','<<source_upper<<','<<count<<','<<s.coarse_gap[f]<<','<<(s.upper[f]-s.lower[f])/s.upper[f]<<','<<flush<<'\n';}
        segments.push_back(s);
    }
    // Conservative variation-of-derivative midpoint error: h_max^2 TV(g')/8,
    // including slope jumps at thermal knots. This does not assume late dt.
    std::array<long double,4> midpoint_error_1ps{},midpoint_error_10fs{};
    for(int f=0;f<4;++f){midpoint_error_1ps[f]=h_empty*h_empty/8*variation[f]*(1+1e-10L);midpoint_error_10fs[f]=h_occupied*h_occupied/8*variation[f]*(1+1e-10L);}
    auto final=evaluate(end);
    std::ofstream instant(out/"instantaneous.csv");instant<<std::setprecision(21)<<"time_s,face,max_temperature_K,mean_source_temperature_K,physical_electrons_per_electrode_s,source_current_both_electrodes_A,effective_patches,nominal10fs_electrons_per_electrode,source_only_dt_cap_s,M,expected_unsampled_source_probability,nonrel_mean_energy_eV,event_mean_energy_relative_SD,slab_expected_macros,slab_no_macro_probability,slab_charge_relative_SD\n";
    for(double ns:report_ns){double t=report_time(ns);auto T=thermal.at(t);auto v=evaluate(t);
        for(int f=0;f<4;++f){std::vector<double> currents;long double sum=0,sum2=0,kt=0,kt2=0;double tmax=0;
            for(double temp:T[f]){++richardson_evaluations;double J=pic_richardson_supply_A_m2(temp,phi,A);currents.push_back(J);sum+=J;sum2+=J*J;tmax=std::max(tmax,temp);kt+=J*(1.380649e-23*temp/pic_e);kt2+=J*std::pow(1.380649e-23*temp/pic_e,2);}
            kt/=sum;kt2/=sum;
            for(int M:{32,16,8}){long double missing=0;for(double J:currents){long double p=J/sum;missing+=p*std::pow(1-p,M);}
                instant<<t<<','<<f<<','<<tmax<<','<<kt*pic_e/1.380649e-23<<','<<v.rate[f]<<','<<2*pic_e*v.rate[f]<<','<<sum*sum/sum2<<','<<v.rate[f]*h_occupied<<','<<std::cbrt(source_C/v.maxJ)<<','<<M<<','<<missing<<','<<2*kt<<','<<std::sqrt((6*kt2-4*kt*kt)/M)/(2*kt)<<','<<.04*M<<','<<std::pow(.96,M)<<','<<std::sqrt(.96/(.04*M))<<'\n';}
        }
    }
    std::ofstream cross(out/"crossings.csv");cross<<std::setprecision(21)<<"face,rate_target_per_electrode_s,meaning,time_s,bracket_width_s\n";
    for(int f=0;f<4;++f)for(double target:{1e12,1e14,8e14,16e14,32e14}){
        if(evaluate(end).rate[f]<target)continue;
        double a=initial,b=end;
        if(evaluate(a).rate[f]<target)for(int n=0;n<60;++n){double m=.5*(a+b);if(evaluate(m).rate[f]<target)a=m;else b=m;}
        else b=a;
        const char* meaning=target==1e12?"one_electron_per1ps":target==1e14?"one_electron_per10fs":target==8e14?"nominal_M8_weight_one":target==16e14?"nominal_M16_weight_one":"nominal_M32_weight_one";
        cross<<f<<','<<target<<','<<meaning<<','<<b<<','<<b-a<<'\n';
    }
    std::ofstream result(out/"integrals.json");result<<std::setprecision(21)<<"{\n\"complete\":true,\n\"source_only\":true,\n\"start_s\":"<<initial<<",\n\"end_s\":"<<end<<",\n\"thermal_states\":"<<thermal.times.size()<<",\n\"cooling_patch_intervals\":"<<cooling<<",\n\"monotone\":true,\n\"face_per_electrode_lower\":";array_json(result,lower);
    result<<",\n\"face_per_electrode_upper\":";array_json(result,upper);
    result<<",\n\"derivative_total_variation\":";array_json(result,variation);
    result<<",\n\"native_midpoint_error_bound_h1ps\":";array_json(result,midpoint_error_1ps);
    result<<",\n\"native_midpoint_error_bound_h10fs\":";array_json(result,midpoint_error_10fs);
    result<<",\n\"face_rate_max_per_electrode_s\":";array_json(result,final.rate);
    result<<",\n\"face_flush_count_lower_partitioned\":";array_json(result,flush_lower);
    result<<",\n\"global_max_J_A_m2\":"<<final.maxJ<<",\n\"max_temperature_K\":"<<final.maxT<<",\n\"minimum_source_only_dt_s\":"<<std::cbrt(source_C/final.maxJ)
          <<",\n\"any_state_step_lower_bound\":"<<all_state_steps_lower<<",\n\"occupied_step_lower_bound_partitioned\":"<<occupied_steps_lower
          <<",\n\"quadrature_relative_bracket_target\":"<<relative_tolerance<<",\n\"roundoff_cushion\":"<<roundoff_pad<<",\n\"source_evaluations\":"<<evaluations<<",\n\"segments\":"<<segments.size()<<",\n\"Richardson_evaluations\":"<<richardson_evaluations
          <<",\n\"cpu\":6,\n\"nice\":15,\n\"threads\":1,\n\"wall_s\":"<<std::chrono::duration<double>(std::chrono::steady_clock::now()-began).count()<<"\n}\n";
    require(bool(result)&&bool(per)&&bool(instant)&&bool(cross),"forecast write failed");
    std::cout<<"Bounded source forecast completed with "<<evaluations<<" thermal-node evaluations\n";return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 2;}}
