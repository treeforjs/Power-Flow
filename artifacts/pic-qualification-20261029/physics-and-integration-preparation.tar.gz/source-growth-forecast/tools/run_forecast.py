#!/usr/bin/env python3
"""Bounded, standard-library-only source-cache analysis. Never launches PIC."""
import fcntl
import hashlib
import json
import os
from pathlib import Path
import resource
import math
import struct
import subprocess
import time

ROOT=Path(__file__).resolve().parent.parent
TOOLS=ROOT/'tools'
PROFILE=ROOT.parent
THERMAL=PROFILE.parent/'heating-history-full.bin'
SAMPLER=Path('/home/treefor/projects/runtimes/pic-source-sampling-validation-20261029/native_slice.hpp')
EQUIVALENCE=PROFILE/'source-sampling-validation/native-equivalence.json'
FROZEN=Path('/home/treefor/projects/runtimes/mfem-gpu-pic-20261029')

def digest(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
    return h.hexdigest()

def write(path,value):
    path.resolve().relative_to(ROOT.resolve())
    path.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')

def lease():
    assert os.sched_getaffinity(0)=={6} and os.getpriority(os.PRIO_PROCESS,0)==15
    actual=os.fstat(9);expected=(PROFILE/'testing-core.lock').stat()
    assert (actual.st_dev,actual.st_ino)==(expected.st_dev,expected.st_ino)
    fcntl.flock(9,fcntl.LOCK_EX|fcntl.LOCK_NB)
    assert all(os.environ.get(k)=='1' for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'])

def source_limits():
    resource.setrlimit(resource.RLIMIT_AS,(256*1024**2,256*1024**2))
    resource.setrlimit(resource.RLIMIT_CPU,(45,46))

def command(args,log,timeout=50,limited=False):
    result=subprocess.run([str(x) for x in args],capture_output=True,text=True,timeout=timeout,
                          preexec_fn=source_limits if limited else None,pass_fds=(9,))
    log.write_text(result.stdout+result.stderr)
    if result.returncode:raise RuntimeError(f'Owned utility returned {result.returncode}; see {log}')
    return result.stdout

def main():
    lease();began=time.monotonic()
    i=1
    while (ROOT/f'attempt-{i:03d}').exists():i+=1
    out=ROOT/f'attempt-{i:03d}';out.mkdir()
    write(out/'progress.json',dict(status='preparing_source_only',GPU_execution=False,trajectory_steps=0,field_solves=0))
    equivalence=json.loads(EQUIVALENCE.read_text())
    metadata=THERMAL.with_suffix('.json')
    inputs=[THERMAL,metadata,SAMPLER,EQUIVALENCE,FROZEN/'sealed-files.json',
            PROFILE.parent/'thermionic-supply/summary.json',
            PROFILE.parent/'thermionic-supply/surface_supply_arrays.npz',
            Path('/home/treefor/projects/Power-Flow/runs/restore_field_mpi8_domain40mm/configuration.json'),
            *map(Path,equivalence['frozen_sha256'])]
    before={str(p):digest(p) for p in inputs}
    assert before[str(THERMAL)]==json.loads(metadata.read_text())['binary_sha256']
    assert before[str(PROFILE.parent/'thermionic-supply/surface_supply_arrays.npz')]==json.loads(metadata.read_text())['source_npz_sha256']
    assert before[str(SAMPLER)]==equivalence['generated_sha256']
    for path,want in equivalence['frozen_sha256'].items():assert before[path]==want
    (TOOLS/'native_source.hpp').write_bytes(SAMPLER.read_bytes())
    compiler=['/usr/sbin/c++','-std=c++20','-O3','-DNDEBUG','-Wall','-Wextra','-Werror=return-type']
    command(compiler+[TOOLS/'forecast.cpp','-o',TOOLS/'forecast'],out/'build.log',timeout=30)
    linkage=command(['ldd',TOOLS/'forecast'],out/'linkage.txt',timeout=5)
    assert not any(x in linkage.lower() for x in ['cuda','cudss','nvidia','nvml','libmpi','mfem'])
    command([TOOLS/'forecast',THERMAL,out],out/'integration.log',limited=True)
    fixture=out/'constant-temperature-fixture';fixture.mkdir()
    fixture_input=fixture/'thermal.bin'
    fixture_input.write_bytes(struct.pack('<6Q',0x544845524d303031,2,2048,2048,256,256)+
        struct.pack('<2d',26e-9,60e-9)+struct.pack('<d',2500.)*(2*4608))
    command([TOOLS/'forecast',fixture_input,fixture],fixture/'run.log',limited=True)
    measured=json.loads((fixture/'integrals.json').read_text())
    current=1201732.289489034*2500**2*math.exp(-4.3*1.602176634e-19/(1.380649e-23*2500))
    for f,length in enumerate([.005,.005,.0002,.0002]):
        exact=current*length*.025/1.602176634e-19*(measured['end_s']-measured['start_s'])
        assert measured['face_per_electrode_lower'][f]<=exact<=measured['face_per_electrode_upper'][f]
        assert (measured['face_per_electrode_upper'][f]-measured['face_per_electrode_lower'][f])/exact<3e-12
    write(fixture/'check.json',dict(passed=True,constant_temperature_K=2500.,analytic_geometry_and_duration_verified=True))
    after={str(p):digest(p) for p in inputs};assert before==after
    integrals=json.loads((out/'integrals.json').read_text());assert integrals['complete'] and integrals['thermal_states']==295
    write(out/'provenance.json',dict(status='bounded_source_integration_complete',
        inputs_before_after_sha256=before,compiler=compiler,
        owned_code_sha256={p.name:digest(p) for p in TOOLS.iterdir() if p.is_file()},
        CPU=6,nice=15,threads=1,local_jobs=1,testing_lease_held=True,
        utility_memory_cap_MiB=256,utility_cpu_cap_s=45,utility_wall_cap_s=50,
        wrapper_wall_cap_s=90,thermal_node_cap=200000,per_segment_panel_cap=32768,
        elapsed_wall_s=time.monotonic()-began,
        GPU_execution=False,MPI_initialized=False,trajectory_steps=0,field_solves=0,
        production_opened=False,production_signals=False,dependencies_installed=False))
    write(out/'progress.json',dict(status='source_integration_complete',GPU_execution=False,trajectory_steps=0,field_solves=0))
    write(ROOT/'latest-integration.json',dict(result_directory=str(out)))
    summarizer=TOOLS/'summarize.py'
    if summarizer.exists():command(['python3',summarizer,out],out/'summary.log',timeout=20)
    print(json.dumps(dict(result_directory=str(out),integration_wall_s=integrals['wall_s'],
                         source_nodes=integrals['source_evaluations'],GPU_execution=False)))

if __name__=='__main__':main()
