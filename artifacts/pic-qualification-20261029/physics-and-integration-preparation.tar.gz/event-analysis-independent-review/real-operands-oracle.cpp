#include <cmath>
#include <iomanip>
#include <iostream>
__attribute__((noinline)) double length(double low,double high,double first,double last){const double span=high-low;high=low+last*span;low+=first*span;return high-low;}
__attribute__((noinline)) double weight(double J,double L,double D,double dt,int n){return J*L*D*dt/(1.602176634e-19*n);}
__attribute__((noinline)) double energy(double x,double y,double z,double m,double w){double u2=x*x+y*y+z*z;return m*u2/(std::sqrt(1+u2/(299792458.0*299792458.0))+1)*w;}
int main(){std::cout<<std::hexfloat;double ledger[]={-0x1.a7970ab83e52fp-53,-0x1.a7970ab83e498p-53,0x1.e1d4ad4efb020p-54,0x0.0p+0,0x0.0p+0,-0x1.a76a9f7c2916fp-53,-0x1.48ebb8bb3b1fcp-55,0x0.0p+0,-0x1.7ab09243c924bp-68,-0x1.7ab09243c924bp-68,0x1.e769572dad06cp-55,0x1.554d420eb2977p-48,0x0.0p+0,0x1.89f71649d7ee6p-69};
{volatile double v[]={-0x1.c9a1954871c7cp+15,0x1.e3819ebc5e5fdp+21,0x1.f769d58c3eb15p+20,0x1.279dcc922bcd9p-100,0x1.0027b6c45a9f9p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 1 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[6]+=Q;
ledger[11]+=K;
}
{volatile double v[]={0x1.1e0a3168c74bbp+22,0x1.31531cdc7dcd3p+21,0x1.a3e58ee436e4cp+16,0x1.279dcc922bcd9p-100,0x1.00c05dff952e2p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 2 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[6]+=Q;
ledger[11]+=K;
}
{volatile double v[]={0x1.086743c7dc413p+21,0x1.3496e7a736170p+21,0x1.4b84c03bbebbfp+20,0x1.279dcc922bcd9p-100,0x1.003790c0f1ff5p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 3 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[6]+=Q;
ledger[11]+=K;
}
{volatile double v[]={0x1.2daae9c568952p+22,0x1.c09ef13f27073p+21,-0x1.22bf48f16a111p+21,0x1.279dcc922bcd9p-100,0x1.00fc06fe43624p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 4 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[6]+=Q;
ledger[11]+=K;
}
{volatile double v[]={0x1.eb6a5144c6367p+15,-0x1.3707770655ff2p+17,0x1.6024fec9dbf58p+16,0x1.279dcc922bcd9p-100,0x1.0038339d903c1p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 5 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={-0x1.79f502bd9ad2ep+22,0x1.78cdbddd81b77p+22,-0x1.c3b9d8b0ef762p+19,0x1.279dcc922bcd9p-100,0x1.0037bf185bc48p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 6 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[6]+=Q;
ledger[11]+=K;
}
{volatile double v[]={0x1.59ad2d535caacp+16,0x1.05fff960d1d1dp+18,-0x1.35daf92b61b50p+16,0x1.279dcc922bcd9p-100,0x1.008d6dc29d8b4p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 7 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={-0x1.cda75f5a26070p+21,0x1.cba89c9b2618dp+20,-0x1.9839546046309p+21,0x1.279dcc922bcd9p-100,0x1.00fca5116a317p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 8 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[6]+=Q;
ledger[11]+=K;
}
{volatile double v[]={0x1.01e766dc7237ap+23,-0x1.b018ed8023d55p+17,0x1.2227258223fe5p+21,0x1.279dcc922bcd9p-100,0x1.001150752f975p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 9 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[6]+=Q;
ledger[11]+=K;
}
{volatile double v[]={-0x1.3a46d45d1347cp+21,0x1.c201434c9f59cp+21,0x1.3f09687f2ad65p+11,0x1.279dcc922bcd9p-100,0x1.0029c60d57d36p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 10 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[6]+=Q;
ledger[11]+=K;
}
{volatile double v[]={-0x1.65b4f9c946e2fp+17,0x1.64f6445a07c27p+18,-0x1.12082a8881780p+17,0x1.279dcc922bcd9p-100,0x1.00b103a179ddcp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x1.0000000000000p-8,0x1.0000000000000p-7,0x1.07ac2250ce2b0p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 11 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.a40ba625833fep+16,0x1.099dad53bc956p+16,0x1.cd1699baae8dbp+16,0x1.279dcc922bcd9p-100,0x1.00b103a179ddcp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x1.c000000000000p-6,0x1.0000000000000p-5,0x1.07ac2250ce2b0p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 12 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.a6206a224edc1p+17,-0x1.16326cae00f5ap+17,0x1.1f4ffbf2e071cp+18,0x1.279dcc922bcd9p-100,0x1.00b103a179ddcp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x1.0000000000000p-7,0x1.8000000000000p-7,0x1.07ac2250ce2b0p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 13 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.9157b81dfddf6p+16,-0x1.89b1cb43c08c1p+18,-0x1.52beee1c75994p+15,0x1.279dcc922bcd9p-100,0x1.00b103a179ddcp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x1.8000000000000p-6,0x1.c000000000000p-6,0x1.07ac2250ce2b0p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 14 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.e9e78ff96dae4p+17,-0x1.0dc87ddfc8f81p+17,-0x1.9a7d236e93be4p+16,0x1.279dcc922bcd9p-100,0x1.00b103a179ddcp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x1.c000000000000p-6,0x1.0000000000000p-5,0x1.07ac2250ce2b0p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 15 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.690da6306cf14p+16,-0x1.ebd8a644864ccp+16,-0x1.332ad6cbb99ccp+15,0x1.279dcc922bcd9p-100,0x1.00b103a179ddcp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x1.8000000000000p-6,0x1.c000000000000p-6,0x1.07ac2250ce2b0p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 16 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.83b649cddd9dep+17,-0x1.a5c4d5a05e02dp+14,-0x1.5568d279041b7p+17,0x1.279dcc922bcd9p-100,0x1.00b103a179ddcp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x1.0000000000000p-5,0x1.2000000000000p-5,0x1.07ac2250ce2b0p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 17 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.19273d309e15dp+18,0x1.371e49f6a8dc2p+14,-0x1.22a4a42079795p+17,0x1.279dcc922bcd9p-100,0x1.00b103a179ddcp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x0.0p+0,0x1.0000000000000p-8,0x1.07ac2250ce2b0p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 18 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.e6c2d94dbc12cp+16,-0x1.b2afc08f8536fp+18,-0x1.1fc42bf76c536p+17,0x1.279dcc922bcd9p-100,0x1.00b103a179ddcp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x1.0000000000000p-5,0x1.2000000000000p-5,0x1.07ac2250ce2b0p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 19 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.02044b5036eadp+17,0x1.fa00be63ae025p+13,-0x1.94b3811492c25p+15,0x1.279dcc922bcd9p-100,0x1.00b103a179ddcp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x1.0000000000000p-7,0x1.8000000000000p-7,0x1.07ac2250ce2b0p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 20 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.045d91c98a2e1p+18,0x1.bad79fc831fccp+15,-0x1.86136d7084f98p+12,0x1.279dcc922bcd9p-100,0x1.00b103a179ddcp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x0.0p+0,0x1.0000000000000p-8,0x1.07ac2250ce2b0p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 21 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.2e3d8fe8cdcf3p+18,0x1.9317f480ada99p+17,-0x1.5d84cc2741dcdp+17,0x1.279dcc922bcd9p-100,0x1.00b103a179ddcp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x1.c000000000000p-6,0x1.0000000000000p-5,0x1.07ac2250ce2b0p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 22 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.2de3f657451e8p+18,-0x1.d0de22cead33cp+14,-0x1.6e9de7b84e091p+16,0x1.279dcc922bcd9p-100,0x1.00b103a179ddcp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x1.4000000000000p-4,0x1.5000000000000p-4,0x1.07ac2250ce2b0p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 23 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.e7eb671154a83p+17,-0x1.0550b55352e3bp+14,0x1.5a1b19fd2c4cdp+14,0x1.279dcc922bcd9p-100,0x1.00b103a179ddcp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x0.0p+0,0x1.0000000000000p-8,0x1.07ac2250ce2b0p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 24 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.8e87518a74282p+17,-0x1.8d2b675b80433p+14,0x1.b900900d59722p+12,0x1.279dcc922bcd9p-100,0x1.00b103a17b173p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x1.e000000000000p-5,0x1.0000000000000p-4,0x1.07ac2250ce2b0p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 25 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.bc48d5ce5d2abp+14,-0x1.7c4b3cf074bc4p+12,-0x1.256ba33f6da6dp+17,0x1.279dcc922bcd9p-100,0x1.00b103a179ddcp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x1.0000000000000p-7,0x1.8000000000000p-7,0x1.07ac2250ce2b0p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 26 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.740b039825763p+16,0x1.e6521334a48c4p+17,-0x1.708075e200215p+17,0x1.279dcc922bcd9p-100,0x1.00b103a179ddcp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x1.0000000000000p-7,0x1.8000000000000p-7,0x1.07ac2250ce2b0p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 27 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.88f8aaf1f4361p+17,-0x1.df469a6cce317p+17,0x1.ddadfffb41c6cp+15,0x1.279dcc922bcd9p-100,0x1.00b103a179ddcp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x1.0000000000000p-8,0x1.0000000000000p-7,0x1.07ac2250ce2b0p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 28 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.1b0680b4a8bdep+18,0x1.8a75553b5fffep+17,-0x1.3518ddbb0e39bp+16,0x1.279dcc922bcd9p-100,0x1.00b103a179ddcp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x1.0000000000000p-7,0x1.8000000000000p-7,0x1.07ac2250ce2b0p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 29 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.c8284ffbaa6bcp+15,-0x1.9bd70aa225a19p+17,-0x1.c6ccd7924afebp+15,0x1.279dcc922bcd9p-100,0x1.00b103a179ddcp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x1.0000000000000p-8,0x1.0000000000000p-7,0x1.07ac2250ce2b0p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 30 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.9614110be238ep+16,0x1.86669acb503c0p+17,-0x1.1bca43fecc182p+15,0x1.279dcc922bcd9p-100,0x1.00b103a179ddcp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x1.8000000000000p-5,0x1.a000000000000p-5,0x1.07ac2250ce2b0p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 31 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.33db0e743827ap+17,0x1.2c69d2e7e0d5fp+16,0x1.383586500b894p+18,0x1.279dcc922bcd9p-100,0x1.00b103a179ddcp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x0.0p+0,0x1.0000000000000p-8,0x1.07ac2250ce2b0p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 32 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.ad423ae39ace7p+17,0x1.b40365d4a1abbp+16,-0x1.5cffdfdd5ae0fp+16,0x1.279dcc922bcd9p-100,0x1.00b103a179ddcp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x1.a000000000000p-5,0x1.c000000000000p-5,0x1.07ac2250ce2b0p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 33 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.be483686f233ep+17,-0x1.1298b2c0f4435p+16,0x1.87a361bbfc1a4p+17,0x1.279dcc922bcd9p-100,0x1.00b103a179ddcp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x1.0000000000000p-7,0x1.8000000000000p-7,0x1.07ac2250ce2b0p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 34 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.04a9c3d5f544bp+18,-0x1.61e8638460902p+16,0x1.398276a0fc3e3p+18,0x1.279dcc922bcd9p-100,0x1.00b103a179ddcp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x1.0000000000000p-8,0x1.0000000000000p-7,0x1.07ac2250ce2b0p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 35 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.49d3797194454p+18,0x1.9203cf6e71beap+17,0x1.4e373fef0b570p+18,0x1.279dcc922bcd9p-100,0x1.00b103a179ddcp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x0.0p+0,0x1.0000000000000p-8,0x1.07ac2250ce2b0p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 36 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.1afc9d71a8668p+19,0x1.a4bae7539ad8ep+17,-0x1.8c87e0229565bp+16,0x1.279dcc922bcd9p-100,0x1.00b103a179ddcp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x1.0000000000000p-8,0x1.0000000000000p-7,0x1.07ac2250ce2b0p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 37 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.5bc369b1838a0p+17,0x1.5e29511cbb4bdp+15,-0x1.3430cf20995eep+17,0x1.279dcc922bcd9p-100,0x1.00b103a179ddcp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x0.0p+0,0x1.0000000000000p-8,0x1.07ac2250ce2b0p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 38 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.0087bba07cc6cp+18,0x1.70fa8505a63adp+17,0x1.af465151c0c94p+13,0x1.279dcc922bcd9p-100,0x1.00b103a179ddcp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x1.8000000000000p-7,0x1.0000000000000p-6,0x1.07ac2250ce2b0p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 39 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.f34b32d45dc25p+16,-0x1.8511296914fecp+17,0x1.24bf136bc98e1p+16,0x1.279dcc922bcd9p-100,0x1.00b103a179ddcp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x1.c000000000000p-5,0x1.e000000000000p-5,0x1.07ac2250ce2b0p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 40 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.0c079a8a4d987p+18,0x1.10cd3409aa6b7p+14,-0x1.57ffe8ef6466dp+16,0x1.279dcc922bcd9p-100,0x1.00b103a17b173p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x1.4000000000000p-6,0x1.8000000000000p-6,0x1.07ac2250ce2b0p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 41 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.38f04e48684c0p+17,-0x1.8120d07232caap+16,-0x1.d305b7c001fa2p+17,0x1.279dcc922bcd9p-100,0x1.00b103a179ddcp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x1.1000000000000p-4,0x1.2000000000000p-4,0x1.07ac2250ce2b0p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 42 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.7cfb7911ccccfp+18,0x1.e28636d58d92ep+15,0x1.6dcec5d84dbb1p+16,0x1.279dcc922bcd9p-100,0x1.00b103a179de0p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.f200000000000p-1,0x1.f400000000000p-1,0x1.07ac2250ce2b4p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 43 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.d84f811b1700fp+17,0x1.d85808821e772p+17,0x1.86231b214d63fp+17,0x1.279dcc922bcd9p-100,0x1.00b103a179de0p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.fe00000000000p-1,0x1.0000000000000p+0,0x1.07ac2250ce2b4p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 44 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.d4da54eaad258p+17,0x1.d6954e216267dp+17,0x1.c80dc46da5859p+14,0x1.279dcc922bcd9p-100,0x1.00b103a179de0p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.fe00000000000p-1,0x1.0000000000000p+0,0x1.07ac2250ce2b4p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 45 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.608cb0a95fe9fp+16,-0x1.232c1a094022ap+16,-0x1.512e8d272b193p+18,0x1.279dcc922bcd9p-100,0x1.00b103a17a7abp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.fa00000000000p-1,0x1.fc00000000000p-1,0x1.07ac2250ce2b4p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 46 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.1204c0c849203p+17,-0x1.03519d0118d55p+18,-0x1.f34bb48a415c1p+17,0x1.279dcc922bcd9p-100,0x1.00b103a17a7abp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.fa00000000000p-1,0x1.fc00000000000p-1,0x1.07ac2250ce2b4p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 47 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.6558209b1c50bp+17,-0x1.de4c3fb17d09ep+16,-0x1.5cb95084b532cp+15,0x1.279dcc922bcd9p-100,0x1.00b103a17a7abp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.fa00000000000p-1,0x1.fc00000000000p-1,0x1.07ac2250ce2b4p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 48 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.509f5611cd788p+17,0x1.ed3539d9a03cbp+13,0x1.79b6dd7694387p+15,0x1.279dcc922bcd9p-100,0x1.00b103a179de0p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.f800000000000p-1,0x1.fa00000000000p-1,0x1.07ac2250ce2b4p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 49 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.b3eeffccac664p+17,0x1.18158cde05166p+17,-0x1.cc41d23fdf5dcp+13,0x1.279dcc922bcd9p-100,0x1.00b103a17a7abp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.fa00000000000p-1,0x1.fc00000000000p-1,0x1.07ac2250ce2b4p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 50 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.26bc33cf094dcp+18,0x1.7321319dd8ba7p+17,0x1.7c3d74274614fp+16,0x1.279dcc922bcd9p-100,0x1.00b103a179de0p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.fc00000000000p-1,0x1.fe00000000000p-1,0x1.07ac2250ce2b4p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 51 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.efa967ba88206p+16,0x1.a73d9eeddb6cep+17,-0x1.d72343b29e3ffp+16,0x1.279dcc922bcd9p-100,0x1.00b103a179de0p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.f800000000000p-1,0x1.fa00000000000p-1,0x1.07ac2250ce2b4p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 52 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.9fb3e721f3354p+15,-0x1.1935e5ddd61d5p+17,-0x1.0672ac3ff38fcp+18,0x1.279dcc922bcd9p-100,0x1.00b103a179de0p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.fc00000000000p-1,0x1.fe00000000000p-1,0x1.07ac2250ce2b4p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 53 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.53dc47650c798p+18,0x1.44019b341d585p+13,0x1.233b5a57b5396p+16,0x1.279dcc922bcd9p-100,0x1.00b103a179de0p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.fc00000000000p-1,0x1.fe00000000000p-1,0x1.07ac2250ce2b4p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 54 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.506afe8b8dddbp+16,0x1.585e05acd6f83p+17,0x1.20aa5b129a02cp+18,0x1.279dcc922bcd9p-100,0x1.00b103a179de0p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.fc00000000000p-1,0x1.fe00000000000p-1,0x1.07ac2250ce2b4p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 55 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.f984faf31d7bfp+16,-0x1.6da334e1b027bp+16,-0x1.5bd7e6940d595p+18,0x1.279dcc922bcd9p-100,0x1.00b103a179de0p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.fe00000000000p-1,0x1.0000000000000p+0,0x1.07ac2250ce2b4p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 56 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.da6ae82cb2a6dp+17,0x1.a234c17a48237p+13,0x1.484d98a2e4d94p+15,0x1.279dcc922bcd9p-100,0x1.00b103a17a7abp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.fa00000000000p-1,0x1.fc00000000000p-1,0x1.07ac2250ce2b4p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 57 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.20a0611b52e14p+17,-0x1.e93005965e953p+17,0x1.52c1e9044f14cp+17,0x1.279dcc922bcd9p-100,0x1.00b103a179de0p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.fc00000000000p-1,0x1.fe00000000000p-1,0x1.07ac2250ce2b4p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 58 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.2060a3a5afb64p+18,0x1.54da47a89a5aep+17,-0x1.6fdfcca29e459p+10,0x1.279dcc922bcd9p-100,0x1.00b103a179de0p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.ee00000000000p-1,0x1.f000000000000p-1,0x1.07ac2250ce2b4p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 59 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.287ce17e2d729p+18,-0x1.4156ceb045d85p+16,-0x1.54dc09fb7ae80p+17,0x1.279dcc922bcd9p-100,0x1.00b103a17a7abp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.e600000000000p-1,0x1.e800000000000p-1,0x1.07ac2250ce2b4p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 60 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.d6a8a3761afe1p+17,0x1.e36a55a6b142ep+15,0x1.eee6e042ec7b2p+13,0x1.279dcc922bcd9p-100,0x1.00b103a17a7abp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.e600000000000p-1,0x1.e800000000000p-1,0x1.07ac2250ce2b4p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 61 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.039fd72b33eecp+17,-0x1.7874b9175c5bcp+14,-0x1.1899f0dad2e95p+17,0x1.279dcc922bcd9p-100,0x1.00b103a179de0p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.fe00000000000p-1,0x1.0000000000000p+0,0x1.07ac2250ce2b4p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 62 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.e3429d486f77bp+15,0x1.62583d6018681p+16,-0x1.1a21d3a263ebfp+14,0x1.279dcc922bcd9p-100,0x1.00b103a179de0p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.f600000000000p-1,0x1.f800000000000p-1,0x1.07ac2250ce2b4p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 63 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.3ed5ea245df58p+17,0x1.f4bca2bb818d2p+15,-0x1.2739c3a8660d5p+16,0x1.279dcc922bcd9p-100,0x1.00b103a179de0p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.fc00000000000p-1,0x1.fe00000000000p-1,0x1.07ac2250ce2b4p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 64 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.65fd984996000p+16,0x1.11396da14e8dap+19,0x1.072ddd5a5e8aap+18,0x1.279dcc922bcd9p-100,0x1.00b103a17a7abp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.c800000000000p-1,0x1.ca00000000000p-1,0x1.07ac2250ce2b4p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 65 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.a217acbcb251ep+17,0x1.3f099d8eb8fe9p+18,0x1.6d383c9d39869p+16,0x1.279dcc922bcd9p-100,0x1.00b103a179de0p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.f200000000000p-1,0x1.f400000000000p-1,0x1.07ac2250ce2b4p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 66 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.07e6b417a78c8p+18,0x1.aa84e15be1113p+14,0x1.30e79057de574p+17,0x1.279dcc922bcd9p-100,0x1.00b103a179de0p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.fe00000000000p-1,0x1.0000000000000p+0,0x1.07ac2250ce2b4p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 67 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.3cbf2710e6ae3p+16,-0x1.44856ca96e1d8p+15,-0x1.90e6df0a84ad2p+18,0x1.279dcc922bcd9p-100,0x1.00b103a179de0p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.f800000000000p-1,0x1.fa00000000000p-1,0x1.07ac2250ce2b4p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 68 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.e77afee27a8b2p+16,0x1.4123aae97430dp+13,0x1.84b6cfd8479d7p+15,0x1.279dcc922bcd9p-100,0x1.00b103a17a7abp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.fa00000000000p-1,0x1.fc00000000000p-1,0x1.07ac2250ce2b4p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 69 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.67ef102f30809p+16,-0x1.303084a728370p+18,0x1.85f5ca11a5bdep+16,0x1.279dcc922bcd9p-100,0x1.00b103a179de0p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.e200000000000p-1,0x1.e400000000000p-1,0x1.07ac2250ce2b4p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 70 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.cd9952aedf9e6p+17,-0x1.bd7732ad43b91p+15,0x1.0ec4bdf724e72p+15,0x1.279dcc922bcd9p-100,0x1.00b103a179de0p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.f200000000000p-1,0x1.f400000000000p-1,0x1.07ac2250ce2b4p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 71 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.3f12425eaac87p+17,0x1.197d75be5497cp+15,-0x1.a359e12ea0076p+17,0x1.279dcc922bcd9p-100,0x1.00b103a179de0p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.fe00000000000p-1,0x1.0000000000000p+0,0x1.07ac2250ce2b4p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 72 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.8daaa71062817p+18,-0x1.7da3d12a4f64bp+17,0x1.58e77d8b6247cp+16,0x1.279dcc922bcd9p-100,0x1.00b103a179de0p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.f800000000000p-1,0x1.fa00000000000p-1,0x1.07ac2250ce2b4p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 73 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.0bd5d702e29dep+19,-0x1.417b5f75d632bp+17,-0x1.07b0944fa7abep+16,0x1.279dcc922bcd9p-100,0x1.00b103a179de0p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.fe00000000000p-1,0x1.0000000000000p+0,0x1.07ac2250ce2b4p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 74 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.6e6840a85545ep+17,-0x1.931509d8d388dp+14,-0x1.dfddc4c865bd7p+15,0x1.279dcc922bcd9p-100,0x1.00b103a8fde57p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x1.8000000000000p-6,0x1.c000000000000p-6,0x1.07ac225886860p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 75 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.3411d2ae7bf3ap+17,0x1.33f16cad207c6p+16,0x1.34f46cc6b063fp+18,0x1.279dcc922bcd9p-100,0x1.00b103a8fde57p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x0.0p+0,0x1.0000000000000p-8,0x1.07ac225886860p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 76 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.40a5b68a60769p+17,0x1.00f26031c7823p+18,-0x1.b9f72a29aff83p+9,0x1.279dcc922bcd9p-100,0x1.00b103a8fde57p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x1.8000000000000p-7,0x1.0000000000000p-6,0x1.07ac225886860p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 77 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.8a29542efea9dp+17,-0x1.07b52a70f6494p+17,-0x1.0b20b6dfc674bp+17,0x1.279dcc922bcd9p-100,0x1.00b103a8fde57p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x0.0p+0,0x1.0000000000000p-8,0x1.07ac225886860p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 78 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.225c60022ab20p+18,0x1.14dd8aee2a9ddp+15,-0x1.13d969198defdp+18,0x1.279dcc922bcd9p-100,0x1.00b103a8fde57p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x1.0000000000000p-4,0x1.1000000000000p-4,0x1.07ac225886860p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 79 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.62fbb41715fa4p+17,-0x1.766c3ffce6aafp+17,-0x1.b51ef6042e4a5p+16,0x1.279dcc922bcd9p-100,0x1.00b103a8fde57p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x1.8000000000000p-7,0x1.0000000000000p-6,0x1.07ac225886860p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 80 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.1da9f85fea8bap+17,0x1.b163ead3e72a2p+16,0x1.49ec021348d67p+17,0x1.279dcc922bcd9p-100,0x1.00b103a8fde57p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x1.0000000000000p-8,0x1.0000000000000p-7,0x1.07ac225886860p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 81 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.b238df8ed87f5p+15,0x1.1e840292011eep+18,0x1.5ab56d2e862f3p+14,0x1.279dcc922bcd9p-100,0x1.00b103a8fde57p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x1.4000000000000p-5,0x1.6000000000000p-5,0x1.07ac225886860p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 82 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.95d6695ab68c0p+14,-0x1.29e9d8119be98p+16,0x1.7fa92ea1bf3f3p+17,0x1.279dcc922bcd9p-100,0x1.00b103a8fde57p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x1.0000000000000p-8,0x1.0000000000000p-7,0x1.07ac225886860p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 83 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.37a20e9b42290p+18,0x1.90b6cdaa012fcp+14,-0x1.9266013bde226p+17,0x1.279dcc922bcd9p-100,0x1.00b103a8fde57p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x1.0000000000000p-7,0x1.8000000000000p-7,0x1.07ac225886860p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 84 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.b1bb79cf94701p+17,0x1.9a7efb795db34p+17,-0x1.2b35a57c30dc6p+13,0x1.279dcc922bcd9p-100,0x1.00b103a8fde57p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x0.0p+0,0x1.0000000000000p-8,0x1.07ac225886860p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 85 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.02ff1c86a5b16p+17,0x1.51fe4eb539400p+16,-0x1.73112b00198c5p+16,0x1.279dcc922bcd9p-100,0x1.00b103a8fde57p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x0.0p+0,0x1.0000000000000p-8,0x1.07ac225886860p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 86 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.0bb76632fb013p+17,-0x1.7f543ccb38eaap+17,-0x1.ca75c9db073f3p+15,0x1.279dcc922bcd9p-100,0x1.00b103a8fde57p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x0.0p+0,0x1.0000000000000p-8,0x1.07ac225886860p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 87 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.11ee86a8ae3fdp+17,0x1.34963d5175d45p+17,0x1.acdcde39fd285p+16,0x1.279dcc922bcd9p-100,0x1.00b103a8ff1ecp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x1.4000000000000p-6,0x1.8000000000000p-6,0x1.07ac225886860p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 88 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.a74453611d201p+16,0x1.585ca21c71137p+17,0x1.672f1d27eda0ap+16,0x1.279dcc922bcd9p-100,0x1.00b103a8fde57p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x1.0000000000000p-7,0x1.8000000000000p-7,0x1.07ac225886860p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 89 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.594914614538dp+14,0x1.66785f9b562eep+17,-0x1.08d504a12c866p+16,0x1.279dcc922bcd9p-100,0x1.00b103a8fde57p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x0.0p+0,0x1.0000000000000p-8,0x1.07ac225886860p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 90 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.af5f27d62b41ap+17,0x1.8c470306a78d2p+17,0x1.fed98e0d746c9p+18,0x1.279dcc922bcd9p-100,0x1.00b103a8ff1ecp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x1.4000000000000p-6,0x1.8000000000000p-6,0x1.07ac225886860p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 91 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.a6df50bb0f9acp+17,0x1.a2363891cd767p+17,-0x1.7fccdb10c4f2dp+14,0x1.279dcc922bcd9p-100,0x1.00b103a8fde57p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x0.0p+0,0x1.0000000000000p-8,0x1.07ac225886860p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 92 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.c4e8a1c76fd6ap+17,-0x1.02f9b5f235617p+13,-0x1.55e7cd0c138b5p+15,0x1.279dcc922bcd9p-100,0x1.00b103a8fde57p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x1.0000000000000p-8,0x1.0000000000000p-7,0x1.07ac225886860p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 93 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.53aa2d5578be9p+16,-0x1.2b9d3d5fc905fp+15,-0x1.48b36303a34e0p+18,0x1.279dcc922bcd9p-100,0x1.00b103a8fde57p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x1.6000000000000p-5,0x1.8000000000000p-5,0x1.07ac225886860p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 94 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.23a01e2158555p+18,0x1.f098d75c26461p+15,-0x1.0e914ce9b0c21p+16,0x1.279dcc922bcd9p-100,0x1.00b103a8fde57p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x1.8000000000000p-6,0x1.c000000000000p-6,0x1.07ac225886860p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 95 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.327830d69dbb9p+17,-0x1.33980f7a56756p+18,0x1.e91cc12910879p+16,0x1.279dcc922bcd9p-100,0x1.00b103a8fde57p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x1.4000000000000p-5,0x1.6000000000000p-5,0x1.07ac225886860p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 96 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.07cb3469a995fp+18,0x1.ea79d5a7099bcp+18,-0x1.4671b3d15383ep+17,0x1.279dcc922bcd9p-100,0x1.00b103a8fde57p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x0.0p+0,0x1.0000000000000p-8,0x1.07ac225886860p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 97 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.1806e819daca4p+17,-0x1.3cca31a3734b8p+13,0x1.24adc815e9eb5p+18,0x1.279dcc922bcd9p-100,0x1.00b103a8fde57p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x1.0000000000000p-8,0x1.0000000000000p-7,0x1.07ac225886860p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 98 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.0cbf52a285853p+18,-0x1.1a7859a7b3bd9p+14,0x1.c0775b0868a75p+16,0x1.279dcc922bcd9p-100,0x1.00b103a8fde57p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x1.0000000000000p-8,0x1.0000000000000p-7,0x1.07ac225886860p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 99 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.a9e746152beb8p+18,-0x1.ac37d5b7da9a2p+17,-0x1.089500e24857bp+18,0x1.279dcc922bcd9p-100,0x1.00b103a8fde57p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x1.0000000000000p-6,0x1.4000000000000p-6,0x1.07ac225886860p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 100 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.8cab2437e718dp+17,0x1.6906a5e271398p+16,-0x1.34babc05decd2p+17,0x1.279dcc922bcd9p-100,0x1.00b103a8fde57p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x1.0000000000000p-6,0x1.4000000000000p-6,0x1.07ac225886860p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 101 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.2d5fad7834b0bp+17,0x1.bfd74398f0686p+16,0x1.6d129bd9823a7p+17,0x1.279dcc922bcd9p-100,0x1.00b103a8fde57p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x1.0000000000000p-5,0x1.2000000000000p-5,0x1.07ac225886860p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 102 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.736a1ba56e8e7p+17,0x1.dce745f7439c6p+16,0x1.d2ebb0c36fb07p+16,0x1.279dcc922bcd9p-100,0x1.00b103a8fde57p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x1.4000000000000p-5,0x1.6000000000000p-5,0x1.07ac225886860p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 103 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.a9e026e18dee5p+17,-0x1.254e91758830cp+17,0x1.011bfe1faadb5p+17,0x1.279dcc922bcd9p-100,0x1.00b103a8ff1ecp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x1.4000000000000p-6,0x1.8000000000000p-6,0x1.07ac225886860p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 104 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.fb0c1a123ad20p+17,0x1.31579433770c3p+16,-0x1.07db6b123088dp+14,0x1.279dcc922bcd9p-100,0x1.00b103a8fde57p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x1.c000000000000p-5,0x1.e000000000000p-5,0x1.07ac225886860p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 105 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.327ce803afc86p+17,-0x1.eb02827b9f943p+16,0x1.cad4da793f1c4p+17,0x1.279dcc922bcd9p-100,0x1.00b103a8fde57p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.cac083126e979p-8,0x1.d7dbf487fcb92p-8,0x1.2000000000000p-5,0x1.4000000000000p-5,0x1.07ac225886860p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 106 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.c3252ace476cap+17,0x1.1de04a1b03421p+17,-0x1.dd2a1c49961e8p+15,0x1.279dcc922bcd9p-100,0x1.00b103a8fe828p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.f000000000000p-1,0x1.f200000000000p-1,0x1.07ac225886866p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 107 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.855d9a17877ecp+17,-0x1.551c7b322e849p+17,-0x1.bda5cb09bcc31p+15,0x1.279dcc922bcd9p-100,0x1.00b103a8fe828p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.fa00000000000p-1,0x1.fc00000000000p-1,0x1.07ac225886866p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 108 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.502e342969002p+16,-0x1.b069ca7b82434p+15,0x1.68698035ea8d2p+16,0x1.279dcc922bcd9p-100,0x1.00b103a8fe828p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.f000000000000p-1,0x1.f200000000000p-1,0x1.07ac225886866p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 109 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.97adf9802aa8bp+16,-0x1.fc247d07f20e9p+11,0x1.87e89660f8df7p+14,0x1.279dcc922bcd9p-100,0x1.00b103a8fe828p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.fa00000000000p-1,0x1.fc00000000000p-1,0x1.07ac225886866p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 110 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.5611857aad398p+16,0x1.fe53ece1fd824p+15,-0x1.7ab14705c5d9fp+16,0x1.279dcc922bcd9p-100,0x1.00b103a8fde5dp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.fe00000000000p-1,0x1.0000000000000p+0,0x1.07ac225886866p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 111 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.05f681990e41cp+18,-0x1.2bed9214dc135p+17,0x1.a3180c6f70474p+17,0x1.279dcc922bcd9p-100,0x1.00b103a8fde5dp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.f400000000000p-1,0x1.f600000000000p-1,0x1.07ac225886866p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 112 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.5ba910e8f97a1p+18,-0x1.c318d3c699e21p+15,-0x1.58aa6c04942e3p+16,0x1.279dcc922bcd9p-100,0x1.00b103a8fe828p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.fa00000000000p-1,0x1.fc00000000000p-1,0x1.07ac225886866p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 113 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.9f6de4e997c5bp+18,-0x1.97271c13b7fbep+17,0x1.2a05102b21effp+15,0x1.279dcc922bcd9p-100,0x1.00b103a8fde5dp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.d800000000000p-1,0x1.da00000000000p-1,0x1.07ac225886866p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 114 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.5eb945d62f15fp+18,0x1.7a1c0ba705699p+16,-0x1.27c8fc51b1e14p+17,0x1.279dcc922bcd9p-100,0x1.00b103a8fde5dp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.e800000000000p-1,0x1.ea00000000000p-1,0x1.07ac225886866p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 115 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.78038fe2c66f3p+18,-0x1.29abe28f13a4ap+13,-0x1.29da81626e66cp+16,0x1.279dcc922bcd9p-100,0x1.00b103a8fde5dp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.fc00000000000p-1,0x1.fe00000000000p-1,0x1.07ac225886866p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 116 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.563234ba425eap+18,-0x1.fca055af08315p+16,-0x1.d1d88e379b6edp+17,0x1.279dcc922bcd9p-100,0x1.00b103a8fde5dp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.fe00000000000p-1,0x1.0000000000000p+0,0x1.07ac225886866p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 117 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.b9306384038bcp+17,0x1.2c358f6839845p+15,-0x1.913e5a40fb455p+14,0x1.279dcc922bcd9p-100,0x1.00b103a8fde5dp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.fe00000000000p-1,0x1.0000000000000p+0,0x1.07ac225886866p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 118 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.c30fc9d544b1cp+18,-0x1.f562e96126861p+16,-0x1.29da216c04494p+15,0x1.279dcc922bcd9p-100,0x1.00b103a8fde5dp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.f800000000000p-1,0x1.fa00000000000p-1,0x1.07ac225886866p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 119 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.d97c0e8ae86bdp+15,0x1.9e22a809f05fep+16,-0x1.508a1a163ec8cp+16,0x1.279dcc922bcd9p-100,0x1.00b103a8fde5dp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.fe00000000000p-1,0x1.0000000000000p+0,0x1.07ac225886866p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 120 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.ef99a25eaa9b6p+16,-0x1.a6c94290a346ap+15,0x1.b08b9948997a2p+16,0x1.279dcc922bcd9p-100,0x1.00b103a8fde5dp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.ec00000000000p-1,0x1.ee00000000000p-1,0x1.07ac225886866p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 121 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.555ac71702039p+18,0x1.aaa03510b651cp+16,0x1.9f36ab63607a1p+16,0x1.279dcc922bcd9p-100,0x1.00b103a8fde5dp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.f400000000000p-1,0x1.f600000000000p-1,0x1.07ac225886866p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 122 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.44106a41e0a23p+18,-0x1.3729ea96421d8p+17,0x1.04eff52e5820ap+18,0x1.279dcc922bcd9p-100,0x1.00b103a8fde5dp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.f400000000000p-1,0x1.f600000000000p-1,0x1.07ac225886866p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 123 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.6a00ec8328583p+17,0x1.78d7df668f6f5p+16,0x1.1a0c5a8c384efp+15,0x1.279dcc922bcd9p-100,0x1.00b103a8fe828p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.e600000000000p-1,0x1.e800000000000p-1,0x1.07ac225886866p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 124 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.aadb80658ce85p+18,0x1.e5d38f2cb1bf5p+15,0x1.9eb0f93446e21p+16,0x1.279dcc922bcd9p-100,0x1.00b103a8fde5dp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.fe00000000000p-1,0x1.0000000000000p+0,0x1.07ac225886866p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 125 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.811fc53bacf75p+17,-0x1.de5effc0e78fap+14,0x1.67c225293314dp+15,0x1.279dcc922bcd9p-100,0x1.00b103a8fde5dp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.f400000000000p-1,0x1.f600000000000p-1,0x1.07ac225886866p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 126 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.763fab3d9472ap+15,-0x1.450a2bda39362p+17,-0x1.bcbee9e9f5097p+18,0x1.279dcc922bcd9p-100,0x1.00b103a8fde5dp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.f200000000000p-1,0x1.f400000000000p-1,0x1.07ac225886866p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 127 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.1484a9708c900p+17,-0x1.678e5792fd847p+14,0x1.7e90db27ea521p+13,0x1.279dcc922bcd9p-100,0x1.00b103a8fde5dp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.f400000000000p-1,0x1.f600000000000p-1,0x1.07ac225886866p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 128 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.1c1422b2a1166p+16,-0x1.21bebf52f7c6fp+15,0x1.7f2c73cd5d68dp+16,0x1.279dcc922bcd9p-100,0x1.00b103a8fde5dp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.fc00000000000p-1,0x1.fe00000000000p-1,0x1.07ac225886866p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 129 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.bd0dc39fe1fddp+17,0x1.efc00975c41fbp+11,0x1.5ea033861f57ep+17,0x1.279dcc922bcd9p-100,0x1.00b103a8fde5dp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.fe00000000000p-1,0x1.0000000000000p+0,0x1.07ac225886866p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 130 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.8e63af0bea4e1p+15,0x1.8d2885d059a52p+16,0x1.307aef28ae14fp+17,0x1.279dcc922bcd9p-100,0x1.00b103a8fde5dp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.fe00000000000p-1,0x1.0000000000000p+0,0x1.07ac225886866p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 131 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.ad1a843345c15p+16,0x1.38405c4adf3b4p+17,0x1.0828f8a2831edp+14,0x1.279dcc922bcd9p-100,0x1.00b103a8fe828p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.fa00000000000p-1,0x1.fc00000000000p-1,0x1.07ac225886866p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 132 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.d5ed683629163p+16,0x1.ed1ff3b5d042ap+16,0x1.236cad87fba11p+12,0x1.279dcc922bcd9p-100,0x1.00b103a8fde5dp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.e800000000000p-1,0x1.ea00000000000p-1,0x1.07ac225886866p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 133 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.73f72c8a2d76fp+15,0x1.04a762c983649p+18,-0x1.c9b012b4e0686p+15,0x1.279dcc922bcd9p-100,0x1.00b103a8fde5dp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.f800000000000p-1,0x1.fa00000000000p-1,0x1.07ac225886866p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 134 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.cb1447c7fcedbp+16,0x1.f0b683f0c9af1p+15,0x1.7d70cd10e07f9p+16,0x1.279dcc922bcd9p-100,0x1.00b103a8fde5dp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.fe00000000000p-1,0x1.0000000000000p+0,0x1.07ac225886866p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 135 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.32e30f402317bp+17,-0x1.6c6437625bff7p+13,-0x1.16d7fff2b104ep+14,0x1.279dcc922bcd9p-100,0x1.00b103a8fde5dp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.f400000000000p-1,0x1.f600000000000p-1,0x1.07ac225886866p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 136 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.3803eed122250p+18,-0x1.893b31fba4f67p+17,-0x1.ef6d2c05167a8p+16,0x1.279dcc922bcd9p-100,0x1.00b103a8fe828p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.f000000000000p-1,0x1.f200000000000p-1,0x1.07ac225886866p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 137 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.2f5e603201cc0p+17,-0x1.670af8b6ef869p+13,0x1.38a3113898677p+18,0x1.279dcc922bcd9p-100,0x1.00b103a8fde5dp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.d7dbf487fcb92p-10,0x1.0624dd2f1a9fcp-9,0x1.ec00000000000p-1,0x1.ee00000000000p-1,0x1.07ac225886866p-2,0x1.999999999999ap-6,0x1.18fb21113bf12p-40};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 138 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.85e473e9a4c2ap+21,0x1.42b24fb45a19bp+22,-0x1.06329907979d1p+21,0x1.279dcc922bcd9p-100,0x1.00fc06fe43624p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 139 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[6]+=Q;
ledger[11]+=K;
}
{volatile double v[]={0x1.e40b560fc669cp+15,-0x1.033fc9be22737p+17,-0x1.0af4c27c4a8d8p+18,0x1.279dcc922bcd9p-100,0x1.00b103a179de0p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 140 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={0x1.9ab61f2f453d4p+16,0x1.4005bdba597f6p+17,0x1.287283c449abbp+18,0x1.279dcc922bcd9p-100,0x1.00b103a179de0p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 141 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={-0x1.5665c7ad3e4f0p+16,0x1.0e7a4e348925ep+16,-0x1.6a9a9316fdd51p+16,0x1.279dcc922bcd9p-100,0x1.00b103a8fde5dp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 142 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={-0x1.55454daeaa838p+16,0x1.b1f850779f778p+16,-0x1.31cce67ddf197p+16,0x1.279dcc922bcd9p-100,0x1.00b103a8fde5dp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 143 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={-0x1.3b063575ec1b0p+16,-0x1.51ad13b3e3cb6p+15,0x1.7c216945dc19bp+16,0x1.279dcc922bcd9p-100,0x1.00b103a8fde5dp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 144 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={0x1.ea27d82bc8170p+16,-0x1.fda868e07a7dap+17,0x1.38f44584e8597p+17,0x1.279dcc922bcd9p-100,0x1.00b103a179de0p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 145 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={0x1.db2769bd804d2p+16,0x1.b69b8f725254fp+12,0x1.993f77ebac8b5p+15,0x1.279dcc922bcd9p-100,0x1.00b103a17a7abp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 146 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={0x1.804bd5e30e6dep+16,-0x1.66278318dda6fp+15,-0x1.53d5ac974585ap+18,0x1.279dcc922bcd9p-100,0x1.00b103a17a7abp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 147 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={0x1.f6beedc5d2835p+16,0x1.b8d36af12de2ap+17,-0x1.8546dd7782efdp+16,0x1.279dcc922bcd9p-100,0x1.00b103a179de0p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 148 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={0x1.495a86159b11ap+17,0x1.10da807cdd2b7p+16,-0x1.080c5e20b29d9p+16,0x1.279dcc922bcd9p-100,0x1.00b103a179de0p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 149 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={-0x1.ee63c31d2ea9fp+16,0x1.ade1e9c99bddfp+15,0x1.9982dbb2d5280p+16,0x1.279dcc922bcd9p-100,0x1.00b103a8fde5dp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 150 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={-0x1.8bef2b97623b7p+15,-0x1.6efd8dacdd946p+18,0x1.374c0c3f326bcp+16,0x1.279dcc922bcd9p-100,0x1.00adbfb3393b3p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x0.0p+0,0x1.0000000000000p-11,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 151 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.9005af6b42ae6p+17,-0x1.78190864241f1p+17,-0x1.0655292338fc0p+16,0x1.279dcc922bcd9p-100,0x1.00adbfb3393b3p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x1.0000000000000p-11,0x1.0000000000000p-10,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 152 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.eddc0f5541abbp+13,-0x1.d26618eca7929p+17,0x1.9c6c040837222p+16,0x1.279dcc922bcd9p-100,0x1.00adbfb3393b3p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x0.0p+0,0x1.0000000000000p-11,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 153 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.eeeda7e21cfa0p+16,-0x1.5a40053dffb7dp+17,-0x1.55cc6d39de055p+16,0x1.279dcc922bcd9p-100,0x1.00adbfb3396d6p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x1.ffc0000000000p-1,0x1.0000000000000p+0,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 154 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.2b22d0db3550dp+12,-0x1.8f31840b45ac8p+14,0x1.1d3d2d5333b97p+16,0x1.279dcc922bcd9p-100,0x1.00adbfb3393b3p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x1.0000000000000p-11,0x1.0000000000000p-10,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 155 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.af75b7656f0a6p+14,-0x1.5b5c26ec031e5p+16,0x1.2cb2c314d4e5ap+18,0x1.279dcc922bcd9p-100,0x1.00adbfb3393b3p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x1.0000000000000p-11,0x1.0000000000000p-10,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 156 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.806d72aa3e5fcp+16,-0x1.55f2dd33990aap+16,-0x1.1fedb245823e9p+16,0x1.279dcc922bcd9p-100,0x1.00adbfb3396d6p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x1.ffc0000000000p-1,0x1.0000000000000p+0,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 157 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.e8e25aa6a6b6dp+16,-0x1.b5dcbf9c82f01p+17,0x1.2ae8bdd5ae02dp+18,0x1.279dcc922bcd9p-100,0x1.00adbfb3393b3p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x1.0000000000000p-11,0x1.0000000000000p-10,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 158 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.80f1dce4e08b7p+16,-0x1.55acb62c0eae0p+18,0x1.f9ab8badc3630p+17,0x1.279dcc922bcd9p-100,0x1.00adbfb3393b3p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x1.0000000000000p-10,0x1.8000000000000p-10,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 159 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.e57db7e4a8a96p+13,-0x1.bbc4f3f10f24ep+17,-0x1.8f856395e9901p+17,0x1.279dcc922bcd9p-100,0x1.00adbfb3396d6p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x1.ff40000000000p-1,0x1.ff80000000000p-1,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 160 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.8c7903859d45ep+14,-0x1.616d875bedbcfp+17,0x1.94ab663848f47p+15,0x1.279dcc922bcd9p-100,0x1.00adbfb3396d6p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x1.ffc0000000000p-1,0x1.0000000000000p+0,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 161 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.a75b604531b33p+17,-0x1.7335029e912d8p+17,-0x1.85d47b0e75ed7p+16,0x1.279dcc922bcd9p-100,0x1.00adbfb3396d6p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x1.ffc0000000000p-1,0x1.0000000000000p+0,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 162 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.5b6893d4a9ed8p+17,-0x1.1fcd2bdc8929fp+17,0x1.44266f9735fb5p+6,0x1.279dcc922bcd9p-100,0x1.00adbfb3396d6p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x1.ffc0000000000p-1,0x1.0000000000000p+0,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 163 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.651a94dbb1439p+13,-0x1.519d44708e80cp+18,-0x1.242bda4765b44p+17,0x1.279dcc922bcd9p-100,0x1.00adbfb3396d6p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x1.ffc0000000000p-1,0x1.0000000000000p+0,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 164 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.dfdeb99a8e528p+14,-0x1.f2c015a1b5524p+16,-0x1.9cd3879c40d9bp+14,0x1.279dcc922bcd9p-100,0x1.00adbfb3393b3p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x1.4000000000000p-9,0x1.8000000000000p-9,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 165 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.8658557799c7bp+14,-0x1.9436c6746c178p+17,0x1.5d7f235b5ce4ep+17,0x1.279dcc922bcd9p-100,0x1.00adbfb3393b3p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x0.0p+0,0x1.0000000000000p-11,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 166 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.9f8363fec3ec4p+17,-0x1.2fdeae07ed686p+17,0x1.5b33716ee03e8p+16,0x1.279dcc922bcd9p-100,0x1.00adbfb3396d6p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x1.ffc0000000000p-1,0x1.0000000000000p+0,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 167 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.6d3b26e7faeebp+15,-0x1.91c1d6ef6a23dp+17,0x1.5e9038e6a73dfp+16,0x1.279dcc922bcd9p-100,0x1.00adbfb3396d6p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x1.ff40000000000p-1,0x1.ff80000000000p-1,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 168 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.a8a252f1ba008p+16,-0x1.03d485698ae5ap+17,-0x1.410890d258b00p+15,0x1.279dcc922bcd9p-100,0x1.00adbfb3393b3p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x0.0p+0,0x1.0000000000000p-11,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 169 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.0924a911ffc6ep+17,-0x1.67bd5686ec496p+16,0x1.28bd22226934dp+13,0x1.279dcc922bcd9p-100,0x1.00adbfb3393b3p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x0.0p+0,0x1.0000000000000p-11,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 170 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.8cbf78c5afcddp+13,-0x1.7c5500b9c0a88p+17,-0x1.a1b5e10a89c54p+12,0x1.279dcc922bcd9p-100,0x1.00adbfb3396d6p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x1.ffc0000000000p-1,0x1.0000000000000p+0,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 171 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.57ed7d1700f19p+16,-0x1.64bcb35f09b66p+16,-0x1.ca90b111b9fadp+17,0x1.279dcc922bcd9p-100,0x1.00adbfb3396d6p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x1.ff40000000000p-1,0x1.ff80000000000p-1,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 172 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.32476e54b5370p+18,-0x1.2210d710a3911p+17,-0x1.3f7b359257971p+16,0x1.279dcc922bcd9p-100,0x1.00adbfb3393b3p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x1.4000000000000p-9,0x1.8000000000000p-9,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 173 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.92789f1a48bb3p+16,-0x1.3b61adfeda81fp+17,-0x1.3f0344baecdefp+17,0x1.279dcc922bcd9p-100,0x1.00adbfb3393b3p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x0.0p+0,0x1.0000000000000p-11,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 174 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.0474b66680bf3p+18,-0x1.71f36a3b89bfdp+18,-0x1.84fd7cbbbe284p+17,0x1.279dcc922bcd9p-100,0x1.00adbfb3393b3p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x1.0000000000000p-11,0x1.0000000000000p-10,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 175 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.429c001fba239p+18,-0x1.745d6c224eb73p+16,-0x1.632dc0695437dp+18,0x1.279dcc922bcd9p-100,0x1.00adbfb3396d6p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x1.ffc0000000000p-1,0x1.0000000000000p+0,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 176 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.ef9f5cdf4bb1ep+15,-0x1.0a02b8d842a39p+17,0x1.86fc5902f679ep+16,0x1.279dcc922bcd9p-100,0x1.00adbfb339091p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x1.ff80000000000p-1,0x1.ffc0000000000p-1,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 177 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.28fabb759418bp+14,-0x1.f490f3de2dfdfp+16,-0x1.d8b69ad10c0f0p+17,0x1.279dcc922bcd9p-100,0x1.00adbfb3396d6p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x1.ffc0000000000p-1,0x1.0000000000000p+0,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 178 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.b189780a7f0fbp+16,-0x1.7b6c5460babbfp+18,-0x1.7e17776636f3cp+16,0x1.279dcc922bcd9p-100,0x1.00adbfb3396d6p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x1.ffc0000000000p-1,0x1.0000000000000p+0,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 179 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.afe6958e470a5p+14,-0x1.8e2860cfe3304p+17,-0x1.163a3b2102800p+17,0x1.279dcc922bcd9p-100,0x1.00adbfb3396d6p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x1.ffc0000000000p-1,0x1.0000000000000p+0,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 180 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.f7fea8f136ee2p+17,-0x1.fd83bfbf88460p+17,-0x1.779243d9c6822p+17,0x1.279dcc922bcd9p-100,0x1.00adbfb3396d6p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x1.ffc0000000000p-1,0x1.0000000000000p+0,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 181 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.c322105df301cp+16,-0x1.ef3cb3ab09c80p+16,-0x1.80fd3f0d9bcdfp+7,0x1.279dcc922bcd9p-100,0x1.00adbfb339091p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x1.ff80000000000p-1,0x1.ffc0000000000p-1,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 182 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[1]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.17f3379ecd08dp+16,0x1.74a014e3d1569p+15,-0x1.baa25da06ba79p+17,0x1.279dcc922bcd9p-100,0x1.00adbfb3393b3p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x0.0p+0,0x1.0000000000000p-11,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 183 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.5ce066ac63876p+17,0x1.7923c47d79e28p+15,0x1.b6f5b6d556c56p+16,0x1.279dcc922bcd9p-100,0x1.00adbfb3393b3p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x0.0p+0,0x1.0000000000000p-11,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 184 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.e4055f491de0dp+16,0x1.c27e6f8a4017bp+17,0x1.4f0cde97387a0p+17,0x1.279dcc922bcd9p-100,0x1.00adbfb3396d6p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x1.ffc0000000000p-1,0x1.0000000000000p+0,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 185 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.2ffff09069406p+18,0x1.d48c650ebb5f9p+17,0x1.e545c485c74adp+15,0x1.279dcc922bcd9p-100,0x1.00adbfb339091p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x1.ff80000000000p-1,0x1.ffc0000000000p-1,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 186 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.987b8abadd515p+16,0x1.64b3b9d4b8c76p+18,0x1.01e2c26bdf2b0p+16,0x1.279dcc922bcd9p-100,0x1.00adbfb3393b3p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x0.0p+0,0x1.0000000000000p-11,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 187 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.7a045b38eaf57p+16,0x1.eeb11184243c7p+17,-0x1.24938310d8d2cp+11,0x1.279dcc922bcd9p-100,0x1.00adbfb3396d6p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x1.ffc0000000000p-1,0x1.0000000000000p+0,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 188 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.f60f821cf5f1fp+12,0x1.0f314dcd7083dp+18,-0x1.7682e0dfcced3p+16,0x1.279dcc922bcd9p-100,0x1.00adbfb3393b3p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x1.0000000000000p-11,0x1.0000000000000p-10,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 189 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.288e640796906p+17,0x1.e38c936ed5f7ap+16,0x1.eb51498871b9ap+17,0x1.279dcc922bcd9p-100,0x1.00adbfb3396d6p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x1.ffc0000000000p-1,0x1.0000000000000p+0,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 190 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.8a22f105b74c6p+16,0x1.dffe9287175fep+15,-0x1.867bcc632adf4p+16,0x1.279dcc922bcd9p-100,0x1.00adbfb339091p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x1.fe00000000000p-1,0x1.fe40000000000p-1,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 191 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.31af7e9fb61dbp+17,0x1.e31d221e0675fp+18,0x1.1e078d4ddfcf9p+16,0x1.279dcc922bcd9p-100,0x1.00adbfb339091p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x1.ff80000000000p-1,0x1.ffc0000000000p-1,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 192 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.9ebcabb466318p+15,0x1.5d780c3d74a86p+17,-0x1.0dbe1d333ce4ep+16,0x1.279dcc922bcd9p-100,0x1.00adbfb3393b3p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x0.0p+0,0x1.0000000000000p-11,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 193 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.11ba1a0b03ff1p+14,0x1.8df7f7b16f2ecp+16,0x1.5276d2775e1c1p+14,0x1.279dcc922bcd9p-100,0x1.00adbfb3393b3p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x0.0p+0,0x1.0000000000000p-11,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 194 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.9039952660eaep+16,0x1.2bd805e1bb595p+17,0x1.f919e9279afb6p+16,0x1.279dcc922bcd9p-100,0x1.00adbfb3393b3p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x0.0p+0,0x1.0000000000000p-11,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 195 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.1f2f395b7d928p+16,0x1.adb42fca472aep+17,-0x1.008a9e4df01e1p+18,0x1.279dcc922bcd9p-100,0x1.00adbfb3393b3p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x0.0p+0,0x1.0000000000000p-11,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 196 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.4cc5e922cd12bp+16,0x1.d3e7e23fa9ce0p+17,-0x1.524e19aaeac25p+17,0x1.279dcc922bcd9p-100,0x1.00adbfb3396d6p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x1.ff40000000000p-1,0x1.ff80000000000p-1,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 197 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.773b42501d1edp+15,0x1.f4cba977345c7p+17,0x1.2e3663736895ep+15,0x1.279dcc922bcd9p-100,0x1.00adbfb3393b3p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x0.0p+0,0x1.0000000000000p-11,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 198 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.303958e6be586p+15,0x1.1b399ac11d48ap+18,0x1.6762d1c9f6f85p+17,0x1.279dcc922bcd9p-100,0x1.00adbfb3393b3p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x0.0p+0,0x1.0000000000000p-11,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 199 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.31f1dc59b4a87p+18,0x1.edb9829182256p+17,0x1.a907694c53c86p+16,0x1.279dcc922bcd9p-100,0x1.00adbfb3396d6p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x1.ffc0000000000p-1,0x1.0000000000000p+0,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 200 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.8646f87029207p+16,0x1.a4e1019920706p+17,-0x1.ce6e4576c2352p+17,0x1.279dcc922bcd9p-100,0x1.00adbfb3393b3p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x0.0p+0,0x1.0000000000000p-11,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 201 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.887c9cd610395p+16,0x1.b75e075fcd3dep+17,0x1.5d435374fb07fp+16,0x1.279dcc922bcd9p-100,0x1.00adbfb3393b3p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x1.0000000000000p-10,0x1.8000000000000p-10,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 202 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.50bcaf291b813p+17,0x1.bac44e56dddd7p+17,-0x1.a6c6cd119d361p+12,0x1.279dcc922bcd9p-100,0x1.00adbfb3393b3p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x1.0000000000000p-11,0x1.0000000000000p-10,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 203 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.69bb4f58ab3f7p+15,0x1.7da8cc48928eep+18,0x1.143d6bcfeb816p+15,0x1.279dcc922bcd9p-100,0x1.00adbfb3396d6p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x1.ffc0000000000p-1,0x1.0000000000000p+0,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 204 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.38d4d656a7918p+16,0x1.428078970dd33p+16,-0x1.1c31df67f2264p+17,0x1.279dcc922bcd9p-100,0x1.00adbfb3396d6p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x1.0000000000000p-9,0x1.4000000000000p-9,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 205 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.1d38634695638p+17,0x1.8bb4bafb7da9bp+16,-0x1.8022a97839acep+17,0x1.279dcc922bcd9p-100,0x1.00adbfb3396d6p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x1.ffc0000000000p-1,0x1.0000000000000p+0,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 206 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.2986b91728585p+17,0x1.9b8aa5aa73a36p+18,-0x1.0fcfcfa06a646p+17,0x1.279dcc922bcd9p-100,0x1.00adbfb339091p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x1.ff00000000000p-1,0x1.ff40000000000p-1,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 207 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.26078d7d2cccbp+17,0x1.02cfdafc0dad8p+17,0x1.9059f19e566ebp+17,0x1.279dcc922bcd9p-100,0x1.00adbfb3396d6p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x1.ffc0000000000p-1,0x1.0000000000000p+0,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 208 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.36a9ac8cd0e78p+14,0x1.a8daf4e4c50dfp+17,-0x1.d74071b9923f7p+18,0x1.279dcc922bcd9p-100,0x1.00adbfb3393b3p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x1.0000000000000p-10,0x1.8000000000000p-10,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 209 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.0fef5afb3b14ap+16,0x1.9af4993c32703p+17,0x1.abfe04b0d03f4p+17,0x1.279dcc922bcd9p-100,0x1.00adbfb3393b3p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x0.0p+0,0x1.0000000000000p-11,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 210 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.34566b298a9b9p+17,0x1.0c0425ed521f7p+16,0x1.1c3b9555d4033p+16,0x1.279dcc922bcd9p-100,0x1.00adbfb3396d6p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x1.ffc0000000000p-1,0x1.0000000000000p+0,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 211 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.41f94d26d4ce7p+12,0x1.09d2b937d3670p+18,0x1.e5379a9fcbed2p+17,0x1.279dcc922bcd9p-100,0x1.00adbfb3396d6p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x1.ffc0000000000p-1,0x1.0000000000000p+0,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 212 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={0x1.805b910893fdep+17,0x1.ae82c6c59875dp+17,-0x1.3f1c571f4f441p+12,0x1.279dcc922bcd9p-100,0x1.00adbfb339091p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x1.ff80000000000p-1,0x1.ffc0000000000p-1,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 213 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.1d72cb4768f17p+16,0x1.1828891e04ac3p+18,0x1.01443b8b83c9cp+17,0x1.279dcc922bcd9p-100,0x1.00adbfb3396d6p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
volatile double p[]={0x1.0624dd2f1a9fcp-9,0x1.cac083126e979p-8,0x1.ffc0000000000p-1,0x1.0000000000000p+0,0x1.d00a552561103p-4,0x1.999999999999ap-6,0x1.98b318d33fea5p-41};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);
std::cout<<"P 214 "<<L<<" "<<W<<"\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;
ledger[0]+=Q;
ledger[2]+=batch_energy;
}
{volatile double v[]={-0x1.676a5a26d05bap+16,-0x1.8e9fe05432068p+12,0x1.b3135c328adc3p+14,0x1.279dcc922bcd9p-100,0x1.00b103a8fe828p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 215 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={-0x1.78a8231fd04fap+15,0x1.58990d7e7532bp+16,0x1.4553ed904ffa1p+17,0x1.279dcc922bcd9p-100,0x1.00b103a8fde5dp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 216 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={0x1.7dd9e1bee80e9p+17,-0x1.cb8cca2b99ac6p+16,-0x1.a9d2cd7f42cc1p+15,0x1.279dcc922bcd9p-100,0x1.00b103a17a7abp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 217 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={0x1.797f92ee70aa0p+17,0x1.3febe6a5ccbb7p+13,0x1.95145aa2dae2bp+15,0x1.279dcc922bcd9p-100,0x1.00b103a179de0p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 218 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={-0x1.83120becca6b5p+16,-0x1.fb29342d6679dp+15,0x1.59fe6ddbd512bp+16,0x1.279dcc922bcd9p-100,0x1.00b103a8fe828p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 219 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={-0x1.7d59008d619c6p+15,0x1.08ed5266bcefbp+18,-0x1.ab5b66e8a6f9fp+14,0x1.279dcc922bcd9p-100,0x1.00b103a8fde5dp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 220 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={-0x1.6a66699e80498p+17,-0x1.3d5a1e4769ab0p+13,-0x1.0daaf8d47ab84p+14,0x1.279dcc922bcd9p-100,0x1.00b103a8fde5dp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 221 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={0x1.0bc29df49a142p+18,0x1.ca4992c91cb09p+17,0x1.d9964c5de92d0p+15,0x1.279dcc922bcd9p-100,0x1.00b103a179de0p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 222 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={0x1.9dfdce0cadef1p+16,0x1.00b0927f4c5dap+19,0x1.4534eba4c6968p+18,0x1.279dcc922bcd9p-100,0x1.00b103a17a7abp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 223 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={0x1.1f55dcece21f6p+18,0x1.a7a44d043cefbp+12,0x1.39beedc6a2ed8p+17,0x1.279dcc922bcd9p-100,0x1.00b103a179de0p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 224 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={-0x1.b24b208df48bap+17,-0x1.4606efa5a9c55p+17,-0x1.2899773c9fadcp+16,0x1.279dcc922bcd9p-100,0x1.00b103a8fe828p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 225 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={-0x1.e59fc2cd20f4ep+16,0x1.30beb9d698d6dp+17,0x1.35cea686ac25ap+15,0x1.279dcc922bcd9p-100,0x1.00b103a8fe828p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 226 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={-0x1.4bdbf7df9c6e2p+16,-0x1.13cf39ae654ddp+16,-0x1.affe09c55f451p+17,0x1.279dcc922bcd9p-100,0x1.00adbfb3393b3p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 227 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={-0x1.4f208f1a8d3eap+17,-0x1.ca17734cfe393p+15,0x1.e3d894b3239c5p+16,0x1.279dcc922bcd9p-100,0x1.00adbfb3393b3p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 228 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={-0x1.5110a7cb1ee44p+17,0x1.6152269b01eebp+16,0x1.9aaa23a12fe00p+15,0x1.279dcc922bcd9p-100,0x1.00b103a8fe828p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 229 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={-0x1.c5b1a4a51cbccp+16,0x1.e4c15a39481e2p+16,0x1.7f0724456cb60p+14,0x1.279dcc922bcd9p-100,0x1.00b103a8fde5dp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 230 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={-0x1.7283a20a8d5b6p+16,-0x1.865838fe0aac5p+15,-0x1.971f10abb2471p+16,0x1.279dcc922bcd9p-100,0x1.00adbfb339091p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 231 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={0x1.3e070972dce64p+17,-0x1.21941b6e15705p+17,-0x1.648ad78a1574fp+17,0x1.279dcc922bcd9p-100,0x1.00adbfb3396d6p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 232 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={-0x1.4005bba7d96dbp+17,-0x1.502a301c4f6f5p+16,0x1.d3328f2aa1916p+15,0x1.279dcc922bcd9p-100,0x1.00adbfb3396d6p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 233 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={-0x1.fea1897a15268p+17,-0x1.681bc517f5ce8p+17,0x1.7d05e40cb6787p+17,0x1.279dcc922bcd9p-100,0x1.00b103a8fde5dp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 234 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={0x1.bca2deaaf6132p+16,-0x1.d52b77fdef5e8p+16,0x1.dfaeb0b896d03p+16,0x1.279dcc922bcd9p-100,0x1.00adbfb3393b3p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 235 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={0x1.147858e67da24p+17,-0x1.af18b9d093b61p+17,-0x1.1c32cbde821ddp+18,0x1.279dcc922bcd9p-100,0x1.00b103a17a7abp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 236 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={0x1.509cdca9b266ap+18,0x1.4b469fdab3a45p+17,0x1.f76cfca7921fcp+16,0x1.279dcc922bcd9p-100,0x1.00b103a179de0p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 237 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={0x1.0966121af998ap+18,0x1.2a94b95073195p+12,0x1.69990c5ee9d4fp+15,0x1.279dcc922bcd9p-100,0x1.00b103a17a7abp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 238 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={0x1.5d2049ed169f2p+16,0x1.98256ff38fd87p+14,-0x1.8db0fa34bb124p+18,0x1.279dcc922bcd9p-100,0x1.00b103a179de0p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 239 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={-0x1.616278531adccp+17,-0x1.0e399ab498f6ap+17,0x1.c88203fc26f0fp+17,0x1.279dcc922bcd9p-100,0x1.00adbfb3396d6p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 240 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={-0x1.78dffaa5ade0fp+16,-0x1.593a3ff026618p+16,-0x1.032d8b4b1eec9p+17,0x1.279dcc922bcd9p-100,0x1.00adbfb3396d6p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 241 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={0x1.b5d8abe565e52p+17,0x1.baff1b9a513e5p+15,0x1.fbc47dcd062a2p+14,0x1.279dcc922bcd9p-100,0x1.00b103a17a7abp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 242 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={-0x1.4929772ad7366p+18,-0x1.5c96dc2a08300p+15,-0x1.5eb16c235f95ap+16,0x1.279dcc922bcd9p-100,0x1.00b103a8fe828p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 243 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={0x1.ff17f50ea2f7bp+17,0x1.83e12b360a599p+17,0x1.dedee4af69307p+17,0x1.279dcc922bcd9p-100,0x1.00b103a179de0p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 244 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={-0x1.53b3913815cadp+18,0x1.9b81b1479fda0p+10,-0x1.06cb96cc60900p+16,0x1.279dcc922bcd9p-100,0x1.00b103a8fde5dp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 245 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={-0x1.9a91ca72cb263p+18,0x1.2916bfa3c4a52p+15,0x1.e1775a27d7917p+16,0x1.279dcc922bcd9p-100,0x1.00b103a8fde5dp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 246 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={-0x1.01142dbdcb0a9p+17,-0x1.9c0b078e394fcp+14,0x1.c72b53b8fdea4p+13,0x1.279dcc922bcd9p-100,0x1.00b103a8fde5dp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 247 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={-0x1.61e0fadc9ca6cp+18,-0x1.a1d775b5697dcp+17,0x1.c3e8a2beb6033p+17,0x1.279dcc922bcd9p-100,0x1.00b103a8fde5dp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 248 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={0x1.4b6f3672d7074p+17,-0x1.d37e1c10dadf7p+17,-0x1.0c326a48ee842p+15,0x1.279dcc922bcd9p-100,0x1.00adbfb3393b3p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 249 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={0x1.314f9f46d3e01p+17,0x1.2ee083cf929dcp+16,-0x1.7d9027e44c32ap+17,0x1.279dcc922bcd9p-100,0x1.00b103a179de0p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 250 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={-0x1.c318c52a84807p+17,0x1.2b861df9d741fp+17,-0x1.68dce248dc216p+14,0x1.279dcc922bcd9p-100,0x1.00b103a8fe828p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 251 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={-0x1.2c2a09ceea3b2p+17,-0x1.ac90f67273111p+17,0x1.27d49a181cc2cp+17,0x1.279dcc922bcd9p-100,0x1.00adbfb3396d6p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 252 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={0x1.cde933a7a374fp+17,0x1.11e8d6088511fp+17,0x1.71e70a0073a54p+14,0x1.279dcc922bcd9p-100,0x1.00b103a17a7abp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 253 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={-0x1.cf5e73c600a42p+17,-0x1.3574ed6d3f66ap+15,0x1.62ba17ccf5f3fp+17,0x1.279dcc922bcd9p-100,0x1.00b103a8fde5dp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 254 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={0x1.db14538569e7dp+10,-0x1.259fb60e52a61p+18,0x1.7660f1b62562bp+17,0x1.279dcc922bcd9p-100,0x1.00adbfb3393b3p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 255 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={-0x1.1fe7690dc36a4p+22,0x1.35180fefee2f7p+22,0x1.b6731f6a67c1dp+19,0x1.279dcc922bcd9p-100,0x1.00412f3bcd16fp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 256 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[6]+=Q;
ledger[11]+=K;
}
{volatile double v[]={0x1.dffd83f967cacp+16,0x1.b09d000604f1ep+12,-0x1.0baec2d5840ccp+17,0x1.279dcc922bcd9p-100,0x1.00b103a179de0p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 257 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={-0x1.43fbf788c71c9p+18,0x1.e4e1532a3f5bap+16,-0x1.c26f2508e496ap+16,0x1.279dcc922bcd9p-100,0x1.00b103a8fde5dp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 258 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={-0x1.77f7e437e0339p+16,-0x1.b2542a8222fa6p+17,-0x1.e00cbf0feb59dp+13,0x1.279dcc922bcd9p-100,0x1.00adbfb3396d6p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 259 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={-0x1.37eb25c2f2850p+18,-0x1.efa5085b05d9bp+17,-0x1.262bb72cb4030p+13,0x1.279dcc922bcd9p-100,0x1.00adbfb339091p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 260 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={-0x1.b08a97ecee879p+14,-0x1.0942c4f5a67e0p+18,-0x1.4ee1b65ce1dedp+16,0x1.279dcc922bcd9p-100,0x1.00adbfb3393b3p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 261 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={0x1.6fd74b81445e9p+17,-0x1.b64e20019e3cap+17,0x1.99a229c07d148p+15,0x1.279dcc922bcd9p-100,0x1.00adbfb339091p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 262 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={-0x1.da964b0452e7dp+16,-0x1.4a2b392f2e6e8p+16,0x1.8b4f657f69a54p+16,0x1.279dcc922bcd9p-100,0x1.00b103a8fde5dp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 263 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={0x1.0e27bd8120868p+12,-0x1.a314795925cabp+17,-0x1.045dddfb68bb8p+18,0x1.279dcc922bcd9p-100,0x1.00adbfb3393b3p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 264 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={-0x1.18dfeb4bfd941p+17,-0x1.9e2f7cda5cb9cp+17,-0x1.bb4940f3c7225p+18,0x1.279dcc922bcd9p-100,0x1.00adbfb3393b3p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 265 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={0x1.3e461204d840fp+16,-0x1.063dd3082bb74p+17,0x1.e12eba52e7009p+17,0x1.279dcc922bcd9p-100,0x1.00adbfb3396d6p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 266 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={0x1.50529046fd8f8p+16,-0x1.41ff5c8d26fd5p+18,0x1.e176abd5ed020p+13,0x1.279dcc922bcd9p-100,0x1.00b103a179de0p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 267 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={0x1.bb8096047fda5p+14,-0x1.722b02cc7a9f8p+18,0x1.aaec1d4faf423p+15,0x1.279dcc922bcd9p-100,0x1.00adbfb3396d6p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 268 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={-0x1.403729c0c427ap+17,-0x1.b99d4d01d995ap+16,0x1.2db06d59049cep+18,0x1.279dcc922bcd9p-100,0x1.00b103a8fde5dp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 269 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={-0x1.e7eb352a1b73fp+15,-0x1.e5dc411c6fe3dp+17,0x1.d6e446c8cab39p+16,0x1.279dcc922bcd9p-100,0x1.00adbfb3393b3p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 270 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={-0x1.372178c038059p+16,-0x1.11256062fbb6ap+18,0x1.d997645dec228p+17,0x1.279dcc922bcd9p-100,0x1.00adbfb3396d6p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 271 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={0x1.e88858ea4caadp+17,-0x1.fc1c36032a483p+17,0x1.a9d0fe2398379p+17,0x1.279dcc922bcd9p-100,0x1.00adbfb3396d6p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 272 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={-0x1.4ec5e768e31fdp+17,-0x1.adfc80ec99dfap+17,-0x1.5fdb31570a87cp+17,0x1.279dcc922bcd9p-100,0x1.00adbfb3393b3p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 273 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={0x1.b1f6600df2c5ap+16,-0x1.c7d6cd4242c1ap+18,0x1.0549cdaae2440p+17,0x1.279dcc922bcd9p-100,0x1.00adbfb339091p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 274 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={-0x1.911ba9174381fp+16,-0x1.976cabd5f13a2p+18,-0x1.597fb4e9e6f66p+17,0x1.279dcc922bcd9p-100,0x1.00adbfb339091p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 275 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={0x1.b35d6b7c01262p+14,-0x1.9fc4da971cf1ep+16,0x1.4480dbb560e5ap+14,0x1.279dcc922bcd9p-100,0x1.00adbfb3393b3p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 276 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={0x1.9acf8526d5eadp+14,-0x1.6b0f4f27ecb96p+17,-0x1.2f4cb77c8ed5ap+16,0x1.279dcc922bcd9p-100,0x1.00adbfb3393b3p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 277 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={-0x1.f642b6df75538p+16,-0x1.06e22eff011d6p+18,0x1.8b3e4f8b77db9p+16,0x1.279dcc922bcd9p-100,0x1.00adbfb3396d6p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 278 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={-0x1.63de0c33c81f0p+18,0x1.58d8a717e0496p+15,0x1.23b21eee29e67p+17,0x1.279dcc922bcd9p-100,0x1.00b103a8fde5dp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 279 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={-0x1.e98dd1a2b130ep+13,-0x1.09b1cb1c3378bp+18,0x1.e623251b37e91p+15,0x1.279dcc922bcd9p-100,0x1.00adbfb3393b3p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 280 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={-0x1.89069e2fc42b1p+17,-0x1.b99f62471eda4p+15,0x1.3647a755c0a7dp+15,0x1.279dcc922bcd9p-100,0x1.00b103a8fde5dp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 281 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={0x1.7cac061da1b37p+18,-0x1.c900e41c0c283p+17,0x1.ce734cf083563p+10,0x1.279dcc922bcd9p-100,0x1.00b103a179de0p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 282 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={0x1.08d89791c54c1p+19,-0x1.11f2a121f276dp+17,-0x1.ebc27a8883f59p+16,0x1.279dcc922bcd9p-100,0x1.00b103a179de0p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 283 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={-0x1.bcf882f2ec9b9p+18,-0x1.cdad90fef6f58p+16,-0x1.48891ad63570dp+16,0x1.279dcc922bcd9p-100,0x1.00b103a8fde5dp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 284 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={0x1.ecfb4480ea70fp+21,0x1.970ee7095c3e0p+20,0x1.0d1e728b8dda1p+22,0x1.279dcc922bcd9p-100,0x1.00929a30649f9p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 285 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[6]+=Q;
ledger[11]+=K;
}
{volatile double v[]={0x1.5f5a63b9476eap+18,-0x1.74dfcf0c6f7bep+15,0x1.320c1a230fde2p+16,0x1.279dcc922bcd9p-100,0x1.00b103a179de0p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 286 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={0x1.cc0e5e0cd3563p+17,-0x1.3f60c61786391p+16,0x1.bf06f84dac346p+13,0x1.279dcc922bcd9p-100,0x1.00b103a179de0p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 287 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={-0x1.58fe02a9a22cbp+18,-0x1.ced6615d95b0ap+13,-0x1.feaf758500359p+17,0x1.279dcc922bcd9p-100,0x1.00b103a8fde5dp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 288 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={0x1.d6c56508f8d0ap+17,0x1.8e8ed93ab9aebp+17,0x1.06376f0e8e0f4p+18,0x1.279dcc922bcd9p-100,0x1.00b103a179de0p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 289 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={0x1.a286f60497f5bp+17,-0x1.84eb60d0757a0p+17,0x1.feefb346eaeabp+16,0x1.279dcc922bcd9p-100,0x1.00adbfb3393b3p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 290 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={0x1.35aebb7c52c35p+18,0x1.d8e6960540656p+16,0x1.a07875e5c3358p+16,0x1.279dcc922bcd9p-100,0x1.00b103a179de0p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 291 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={0x1.1cb31ab28a565p+17,-0x1.3e6f2410bc506p+17,-0x1.7606590a142c6p+15,0x1.279dcc922bcd9p-100,0x1.0025580368c0dp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 292 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={-0x1.26bed42cbc4c2p+18,-0x1.bd0cd0a6bec0cp+16,-0x1.962382ef30c7bp+17,0x1.279dcc922bcd9p-100,0x1.00b103a8fe828p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 293 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={-0x1.45ab2efdab33bp+20,0x1.b1ddc3789139ap+21,-0x1.6294c0abfb51ep+20,0x1.279dcc922bcd9p-100,0x1.0012a73a74b3ap-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 294 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[6]+=Q;
ledger[11]+=K;
}
{volatile double v[]={0x1.1c9f842d5fab7p+16,0x1.e51939615ec2fp+15,0x1.11743d9650e1ep+16,0x1.279dcc922bcd9p-100,0x1.00b103a179de0p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 295 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={0x1.288877b9eef70p+16,-0x1.d76254e4c7780p+17,-0x1.23b8142082a78p+17,0x1.279dcc922bcd9p-100,0x1.00adbfb3396d6p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 296 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={0x1.47ab03f04dd92p+17,-0x1.461523274c835p+18,-0x1.49963792607d8p+16,0x1.279dcc922bcd9p-100,0x1.00adbfb3393b3p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 297 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={-0x1.8aac9d7c89e42p+20,0x1.670403674753cp+22,0x1.00dfcf7ebc4b3p+22,0x1.279dcc922bcd9p-100,0x1.0004323b58567p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 298 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[6]+=Q;
ledger[11]+=K;
}
{volatile double v[]={-0x1.7815436a64d8dp+22,0x1.79797beb02f8bp+21,0x1.9cec38a9a1350p+18,0x1.279dcc922bcd9p-100,0x1.0004572cace8dp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 299 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[6]+=Q;
ledger[11]+=K;
}
{volatile double v[]={-0x1.c92405b334025p+17,-0x1.f13493fd3f1c5p+15,0x1.5898919ea8fd5p+13,0x1.279dcc922bcd9p-100,0x1.00b103a8fde5dp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 300 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={0x1.5894ee51e1fbbp+18,-0x1.d5c9bd6e61aefp+17,-0x1.24cc5ef967fe9p+14,0x1.279dcc922bcd9p-100,0x1.00b103a179de0p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 301 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={0x1.3104ec6c16377p+18,0x1.2fd9fb03afc77p+15,-0x1.1ed7830103a7dp+17,0x1.279dcc922bcd9p-100,0x1.00b103a17a7abp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 302 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={0x1.1be866b35a175p+21,0x1.1e58ac3be6bdbp+23,-0x1.bc92d9a484e6cp+20,0x1.279dcc922bcd9p-100,0x1.00d426fd53e3cp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 303 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[6]+=Q;
ledger[11]+=K;
}
{volatile double v[]={-0x1.800ab1820e37cp+17,0x1.865fcd8c8e23dp+18,-0x1.c7ab939d48b66p+15,0x1.279dcc922bcd9p-100,0x1.00b103a8fde5dp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 304 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={-0x1.332cda0695f5ap+21,0x1.40d6124fc37cfp+22,-0x1.565912a644971p+21,0x1.279dcc922bcd9p-100,0x1.0018324cfc17fp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 305 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[6]+=Q;
ledger[11]+=K;
}
{volatile double v[]={0x1.0bc9a167930b8p+16,-0x1.6c604db86c639p+17,-0x1.62c16f42119d3p+11,0x1.279dcc922bcd9p-100,0x1.00255803688edp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 306 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[5]+=Q;
ledger[10]+=K;
}
{volatile double v[]={-0x1.4c9eb5f8358d1p+20,0x1.86c11b35d8238p+21,0x1.ee8466339b1eep+20,0x1.279dcc922bcd9p-100,0x1.0012a73a74e5bp-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 307 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[6]+=Q;
ledger[11]+=K;
}
{volatile double v[]={-0x1.a95661ff78cb6p+20,0x1.73bf58681ecc8p+22,-0x1.2f9e7433afe91p+20,0x1.279dcc922bcd9p-100,0x1.00b2151472882p-5};double K=energy(v[0],v[1],v[2],v[3],v[4]);
std::cout<<"S 308 "<<K<<"\n";double Q=-0x1.7a4da290c1653p-63*v[4];
ledger[6]+=Q;
ledger[11]+=K;
}
std::cout<<"L lower_injected_charge_C "<<ledger[0]<<"\n";
std::cout<<"L upper_injected_charge_C "<<ledger[1]<<"\n";
std::cout<<"L injected_energy_J "<<ledger[2]<<"\n";
std::cout<<"L authored_charge_C "<<ledger[3]<<"\n";
std::cout<<"L authored_kinetic_energy_J "<<ledger[4]<<"\n";
std::cout<<"L lower_absorbed_charge_C "<<ledger[5]<<"\n";
std::cout<<"L upper_absorbed_charge_C "<<ledger[6]<<"\n";
std::cout<<"L short_absorbed_charge_C "<<ledger[7]<<"\n";
std::cout<<"L escaped_charge_C "<<ledger[8]<<"\n";
std::cout<<"L axial_escaped_charge_C "<<ledger[9]<<"\n";
std::cout<<"L lower_absorbed_energy_J "<<ledger[10]<<"\n";
std::cout<<"L upper_absorbed_energy_J "<<ledger[11]<<"\n";
std::cout<<"L short_absorbed_energy_J "<<ledger[12]<<"\n";
std::cout<<"L escaped_kinetic_energy_J "<<ledger[13]<<"\n";
}
