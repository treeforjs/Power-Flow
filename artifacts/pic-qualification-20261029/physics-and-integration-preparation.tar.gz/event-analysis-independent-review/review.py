from pathlib import Path
import ast
import csv
import datetime
import fcntl
import hashlib
import importlib.util
import json
import math
import os
import struct
import subprocess
import sys

sys.dont_write_bytecode=True
ROOT=Path('/home/treefor/Documents/Codex/2026-10-28/we/outputs/pic-profile')
V2=ROOT/'native-event-analysis-v2';V1=ROOT/'native-event-log-prototype';OUT=ROOT/'event-analysis-v2-independent-review'
assert os.sched_getaffinity(0)=={6} and os.getpriority(os.PRIO_PROCESS,0)==15
with open(ROOT/'testing-core.lock','a') as handle:
    try:fcntl.flock(handle,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:pass
    else:raise RuntimeError('Testing-core lease required')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def load(name,path):
    spec=importlib.util.spec_from_file_location(name,path);module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module);return module
sys.path.insert(0,str(V2));a=load('independent_event_v2',V2/'analyze_events.py');old=load('independent_event_v1',V1/'analyze_events.py')
preserved=json.loads((V2/'preserved-inputs-before.json').read_text());after=json.loads((V2/'preserved-inputs-after.json').read_text())
assert len(preserved)==23 and after['sha256']==preserved and after['all_preserved']
assert all(sha(Path(path))==digest for path,digest in preserved.items())
artifact=json.loads((V2/'artifact-manifest.json').read_text())['sha256_files']
assert all(sha(V2/path)==digest for path,digest in artifact.items())
protected={**{str(V2/path):digest for path,digest in artifact.items()},**preserved}
def inspect(directory):
    try:return a.inspect(directory)
    except (ValueError,OSError,KeyError,TypeError,OverflowError,ZeroDivisionError,struct.error) as error:
        return {'status':'invalid','flux_eligible':False,'error':str(error)}
results={}
for label,directory in [('real',V1/'real-seed-1ps/events'),('finite',V1/'evidence/finite-on-enabled/events'),('flat',V1/'evidence/flat-on-enabled/events'),('resume',V1/'evidence/resume-on/events')]:
    current=inspect(directory);assert current['status']=='passed' and not current['failures']
    saved=json.loads((V2/({'real':'real-seed'}.get(label,label)+'-event-analysis.json')).read_text())
    assert json.loads(json.dumps(current,allow_nan=False))==saved
    results[label]={'status':current['status'],'checks':len(current['checks']),'events':current['event_count']}
real=inspect(V1/'real-seed-1ps/events');old_real=old.inspect(V1/'real-seed-1ps/events')
assert len(real['checks'])==800 and (real['event_count'],real['births'],real['sinks'])==(308,192,116)
assert (real['source_known_sink_count'],real['inherited_or_unobserved_sink_count'])==(94,22)
assert len(old_real['failures'])==25
preserved_outputs={key:real[key]==old_real[key] for key in ['flux','thermal_creation_flux_by_face','authored_birth_totals','incidence_angle_coverage_complete']}
assert all(preserved_outputs.values())
def function_tree(path,name):
    tree=ast.parse(path.read_text());return next(node for node in ast.walk(tree) if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)) and node.name==name)
helpers={name:ast.dump(function_tree(V2/'analyze_events.py',name),include_attributes=False)==ast.dump(function_tree(V1/'analyze_events.py',name),include_attributes=False) for name in ['checkpoint','geometry','spectrum','main','close']}
assert all(helpers.values())
prefixes={name:{'numeric_exact':item['replayed_final']==item['final'],'binary64_hex_exact':item['replayed_final_hex']==item['final_hex'],'additions':item['native_additions'],'bound_proved':item['sum_delta_rounding_bound_proved']} for name,item in real['native_ledger_roundoff'].items()}
assert len(prefixes)==14 and all(row['numeric_exact'] and row['binary64_hex_exact'] and row['bound_proved'] for row in prefixes.values())
patches=real['native_patch_roundoff'];assert len(patches)==192 and all(row['coordinate_rounding_bound_proved'] for row in patches)
corruptions=[]
expected=json.loads((V2/'test-results.json').read_text())['corruptions']
for entry in expected:
    family,name=entry['fixture'].split('/',1);directory=(V1/'evidence-fixtures'/name) if family=='v1' else (V2/'fixtures'/name)
    result=inspect(directory);assert result['status'] in ('invalid','failed','incomplete') and not result['flux_eligible']
    assert result['status']==entry['status']
    corruptions.append({'fixture':entry['fixture'],'status':result['status'],'failed_checks':[item['name'] for item in result.get('failures',[])],'error':result.get('error')})
assert len(corruptions)==35 and len(set(row['fixture'] for row in corruptions))==35
capped={}
for label in ['finite','flat']:
    result=inspect(V1/('evidence/'+label+'-on-capped/events'));assert result['status']=='incomplete' and not result['flux_eligible'];capped[label]=result['status']
print('Independent analysis, 35 corruption cases, preservation hashes and unchanged reductions pass',flush=True)

# Arithmetic-only C++ oracle using actual real-stream coordinates, momenta and
# prefixes. No MFEM, PIC run, field callback, GPU library or native replay.
summary=json.loads((V1/'real-seed-1ps/events/summary.json').read_text())
cursor=json.loads((V1/'real-seed-1ps/events/cursor.json').read_text());options=a.checkpoint(Path(cursor['checkpoint']))[0]
rows=[]
for raw in csv.DictReader((V1/'real-seed-1ps/events/events.csv').open()):
    rows.append({key:(value if key in a.TEXT else None if value=='' else int(value) if key in a.INTEGER else float(value)) for key,value in raw.items()})
assert {row['kernel_count'] for row in rows if row['kind']=='thermal_birth'}=={1}
keys=list(real['native_ledger_roundoff']);key_index={key:i for i,key in enumerate(keys)}
hx=lambda value:float(value).hex()
code=['#include <cmath>\n#include <iomanip>\n#include <iostream>\n'
      '__attribute__((noinline)) double length(double low,double high,double first,double last){const double span=high-low;high=low+last*span;low+=first*span;return high-low;}\n'
      '__attribute__((noinline)) double weight(double J,double L,double D,double dt,int n){return J*L*D*dt/(1.602176634e-19*n);}\n'
      '__attribute__((noinline)) double energy(double x,double y,double z,double m,double w){double u2=x*x+y*y+z*z;return m*u2/(std::sqrt(1+u2/(299792458.0*299792458.0))+1)*w;}\n'
      'int main(){std::cout<<std::hexfloat;double ledger[]={'+','.join(hx(summary['initial']['ledger'][key]) for key in keys)+'};\n']
def add(key,expression):return 'ledger['+str(key_index[key])+']+='+expression+';\n'
for row in rows:
    seq=row['event_seq'];kind=row['kind'];values=[row[k] for k in ['ux_m_s','uy_m_s','uz_m_s','mass_kg','weight']]
    code.append('{volatile double v[]={'+','.join(hx(value) for value in values)+'};double K=energy(v[0],v[1],v[2],v[3],v[4]);\n')
    if kind=='thermal_birth':
        electrode=('lower','upper')[row['source_electrode']];surface=row['source_surface'];axis=('left_m','right_m') if surface<2 else ('bottom_m','top_m')
        low,high=(options[electrode+'_foil.'+name] for name in axis)
        code.append('volatile double p[]={'+','.join(hx(value) for value in [low,high,row['start_fraction'],row['end_fraction'],row['kernel_J_A_m2'],options['depth_m'],row['kernel_dt_s']])+'};double L=length(p[0],p[1],p[2],p[3]);double W=weight(p[4],L,p[5],p[6],1);\n')
        code.append('std::cout<<"P '+str(seq)+' "<<L<<" "<<W<<"\\n";double Q=(-1.602176634e-19*v[4])*1;double batch_energy=0;batch_energy+=K;\n')
        code.append(add(electrode+'_injected_charge_C','Q')+add('injected_energy_J','batch_energy'))
    else:
        assert kind in ['lower_wall','upper_wall']
        label='lower_absorbed' if kind=='lower_wall' else 'upper_absorbed'
        code.append('std::cout<<"S '+str(seq)+' "<<K<<"\\n";double Q='+hx(row['q_C'])+'*v[4];\n')
        code.append(add(label+'_charge_C','Q')+add(label+'_energy_J','K'))
    code.append('}\n')
for i,key in enumerate(keys):code.append('std::cout<<"L '+key+' "<<ledger['+str(i)+']<<"\\n";\n')
code.append('}\n');(OUT/'real-operands-oracle.cpp').write_text(''.join(code))
launcher='/home/treefor/projects/runtimes/arch-base-20261028/run-frozen'
commands=[['/usr/sbin/c++','-O3','-DNDEBUG','-std=c++20',str(OUT/'real-operands-oracle.cpp'),'-o',str(OUT/'real-operands-oracle')],[str(OUT/'real-operands-oracle')],[str(V2/'native-arithmetic-oracle')]]
outputs=[]
for number,command in enumerate(commands):
    actual=[launcher,*command];result=subprocess.run(actual,capture_output=True,text=True);assert result.returncode==0,result.stderr
    (OUT/('oracle-'+str(number)+'.log')).write_text(result.stdout+result.stderr);outputs.append(result.stdout)
save={'commands':[[launcher,*command] for command in commands],'logical_cpu':6,'nice':15,'threads':1,'lease_held':True,'GPU_work':False,'PIC_run':False}
(OUT/'commands.json').write_text(json.dumps(save,indent=2)+'\n')
by_seq={row['event_seq']:row for row in rows};counts={'patches':0,'sink_energies':0,'prefix_ledgers':0}
for line in outputs[1].splitlines():
    parts=line.split()
    if parts[0]=='P':
        row=by_seq[int(parts[1])];assert float.fromhex(parts[2]).hex()==row['patch_length_m'].hex();assert float.fromhex(parts[3]).hex()==row['weight'].hex();counts['patches']+=1
    elif parts[0]=='S':
        row=by_seq[int(parts[1])];assert float.fromhex(parts[2]).hex()==row['native_weighted_K_J'].hex();counts['sink_energies']+=1
    else:assert float.fromhex(parts[2]).hex()==float(summary['final']['ledger'][parts[1]]).hex();counts['prefix_ledgers']+=1
assert counts=={'patches':192,'sink_energies':116,'prefix_ledgers':14}
assert outputs[2]==(V2/'oracle-1.log').read_text()
oracle_fixture=json.loads((V2/'native-arithmetic-fixtures.json').read_text())
assert len(oracle_fixture['patch_cases'])==85 and len(oracle_fixture['ledger_cases'])==8
for line in outputs[2].splitlines():
    parts=line.split();number=int(parts[1]);value=float.fromhex(parts[2])
    if parts[0]=='P':assert value.hex()==oracle_fixture['patch_cases'][number]['certificate']['native_length_m'].hex()
    else:assert value.hex()==float(oracle_fixture['ledger_cases'][number]['certificate']['final']).hex()
assert all(sha(Path(path))==digest for path,digest in protected.items())
result={'status':'passed_no_actionable_findings','completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'findings':[],'method':'Source/operator-order review, read-only analyzer reruns, independent C++ real-operand oracle, preserved-hash and AST checks.',
    'analysis_reruns':results,'real_counts':{'events':308,'births':192,'sinks':116,'known_source_sinks':94,'inherited_unknown_sinks':22},
    'v1_failures_reproduced':len(old_real['failures']),'unchanged_flux_reductions':preserved_outputs,'AST_unchanged_helpers':helpers,
    'native_real_prefixes':prefixes,'native_real_patch_certificates':len(patches),'independent_cpp_real_operand_checks':counts,
    'existing_oracle_patch_cases':85,'existing_oracle_prefix_cases':8,'corruptions_rejected':35,'corruption_results':corruptions,
    'capped_streams_ineligible':capped,'preserved_input_hashes_checked':23,'v2_artifact_hashes_checked':len(artifact),
    'all_review_inputs_unchanged':True,'new_PIC_or_GPU_run':False,'runtime_or_analysis_sources_modified':False,
    'limits':['Exact operation replay targets the pinned binary64/native order and compiler flags.','Finite-foil/transverse normals and inherited source provenance remain unknown.','Cumulative double ledgers alone cannot identify increments that round away; event identities, physical balances and the existing parent saved-state comparison are still needed.','No re-run of the native 1 ps replay or GPU comparator was performed.']}
(OUT/'review.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
(OUT/'input-manifest.json').write_text(json.dumps(protected,indent=2)+'\n')
print('Independent C++ agrees exactly for 192 real lengths/weights, 116 sink energies and 14 inherited ledgers',flush=True)
print('No actionable findings; all protected inputs remain unchanged',flush=True)
