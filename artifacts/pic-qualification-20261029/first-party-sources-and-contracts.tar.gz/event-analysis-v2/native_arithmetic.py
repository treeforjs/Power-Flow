"""Frozen binary64 operation-order checks. No tolerance is added to prefix replay."""
import math
from fractions import Fraction as F

C=299792458.0
E=1.602176634e-19

def ordered_sum(values,start=0.):
 result=start
 for value in values:result+=value
 return result

def patch_operands(options,row):
 e,f=row['source_electrode'],row['source_surface']
 if not options['finite_foils']:return 0.,options['width_m'],row['start_fraction'],row['end_fraction']
 name=('lower','upper')[e]
 axis='left_m'if f<2 else'bottom_m';end='right_m'if f<2 else'top_m'
 return options[name+'_foil.'+axis],options[name+'_foil.'+end],row['start_fraction'],row['end_fraction']

def patch_certificate(low,high,start,end):
 # The native source stores the full-face difference, scales each endpoint,
 # adds its original coordinate, then subtracts the two rounded coordinates.
 span=high-low
 upper_product=end*span;lower_product=start*span
 upper=low+upper_product;lower=low+lower_product
 length=upper-lower
 ideal=(F(high)-F(low))*(F(end)-F(start))
 half_ulp=lambda x:F(math.ulp(x))/2
 bound=abs(F(end)-F(start))*half_ulp(span)+sum((half_ulp(x)for x in (upper_product,lower_product,upper,lower,length)),F(0))
 error=abs(F(length)-ideal)
 return {'native_length_m':length,'ideal_length_m':float(ideal),'native_minus_ideal_m':float(F(length)-ideal),'coordinate_rounding_bound_m':math.nextafter(float(bound),math.inf),'coordinate_rounding_bound_proved':error<=bound,'operands_hex':{'low':low.hex(),'high':high.hex(),'start':start.hex(),'end':end.hex(),'span':span.hex(),'lower':lower.hex(),'upper':upper.hex(),'length':length.hex()}}

def patch_length(options,row):return patch_certificate(*patch_operands(options,row))['native_length_m']

def native_energy(row):
 x,y,z=(row[k]for k in ('ux_m_s','uy_m_s','uz_m_s'))
 u2=x*x+y*y+z*z
 return row['mass_kg']*u2/(math.sqrt(1+u2/(C*C))+1)*row['weight']

BATCH_FIELDS=('source_electrode','source_surface','profile_event_seq','profile_seed','patch_index','patch_count','profile_T_K','profile_J_A_m2','kernel_seed','kernel_T_K','kernel_J_A_m2','kernel_dt_s','kernel_count','start_fraction','end_fraction','patch_length_m','time_local_s','advance_step','weight','q_C','mass_kg')
def thermal_batches(rows):
 batches=[];i=0
 while i<len(rows):
  first=rows[i]
  if first['kind']!='thermal_birth':i+=1;continue
  n=first['kernel_count'];batch=rows[i:i+n]
  if len(batch)!=n or any(r['kind']!='thermal_birth'or any(r[k]!=first[k]for k in BATCH_FIELDS)or r['particle_id']!=first['particle_id']+j for j,r in enumerate(batch)):
   raise ValueError('inconsistent contiguous native thermal batch')
  if any(r['q_C']!=-E for r in batch):raise ValueError('native thermal birth must be an electron')
  batches.append({'start_index':i,'rows':batch,'electrode':first['source_electrode'],'charge_C':(-E*first['weight'])*n,'energy_J':ordered_sum(native_energy(r)for r in batch)})
  i+=n
 return batches

KEYS=('lower_injected_charge_C','upper_injected_charge_C','injected_energy_J','authored_charge_C','authored_kinetic_energy_J','lower_absorbed_charge_C','upper_absorbed_charge_C','short_absorbed_charge_C','escaped_charge_C','axial_escaped_charge_C','lower_absorbed_energy_J','upper_absorbed_energy_J','short_absorbed_energy_J','escaped_kinetic_energy_J')
def ledger_streams(rows,batches):
 streams={k:[]for k in KEYS};starts={b['start_index']:b for b in batches}
 for i,r in enumerate(rows):
  kind=r['kind'];q=r['q_C']*r['weight']
  if kind=='thermal_birth':
   if i not in starts:continue
   b=starts[i];streams[('lower'if b['electrode']==0 else'upper')+'_injected_charge_C'].append(b['charge_C']);streams['injected_energy_J'].append(b['energy_J'])
  elif kind=='authored_birth':streams['authored_charge_C'].append(q);streams['authored_kinetic_energy_J'].append(native_energy(r))
  else:
   label={'lower_wall':'lower_absorbed','upper_wall':'upper_absorbed','short_absorption':'short_absorbed'}.get(kind)
   if label:
    streams[label+'_charge_C'].append(q);streams[label+'_energy_J'].append(r['native_weighted_K_J'])
   else:
    streams['escaped_charge_C'].append(q);streams['escaped_kinetic_energy_J'].append(r['native_weighted_K_J'])
    if kind in ('feed_escape','short_plane_escape'):streams['axial_escaped_charge_C'].append(q)
 return streams

def ledger_certificate(initial,final,increments):
 initial=float(initial);final=float(final);replay=initial;bound=F(0);rounding_error=F(0)
 for value in increments:
  previous=replay;replay+=value
  rounding_error+=F(replay)-F(previous)-F(value)
  bound+=F(math.ulp(replay))/2
 increment_exact=sum((F(x)for x in increments),F(0));increment_sum=math.fsum(increments)
 delta=final-initial
 # Budget for the diagnostic difference of rounded sum versus rounded delta.
 delta_bound=bound+F(math.ulp(delta))/2+F(math.ulp(increment_sum))/2
 discrepancy=abs(F(increment_sum)-F(delta))
 return {'initial':initial,'final':final,'native_additions':len(increments),'replayed_final':replay,'prefix_replay_exact':replay==final,'initial_hex':initial.hex(),'final_hex':final.hex(),'replayed_final_hex':replay.hex(),'event_increment_sum':increment_sum,'stored_ledger_delta':delta,'increment_minus_delta':increment_sum-delta,'exact_accumulation_roundoff':float(rounding_error),'add_rounding_bound':math.nextafter(float(bound),math.inf),'sum_delta_rounding_bound':math.nextafter(float(delta_bound),math.inf),'sum_delta_rounding_bound_proved':discrepancy<=delta_bound,'increment_sum_exact_rational':str(increment_exact),'scope':'binary64 operands, native sequential update order; no prefix-replay tolerance'}
