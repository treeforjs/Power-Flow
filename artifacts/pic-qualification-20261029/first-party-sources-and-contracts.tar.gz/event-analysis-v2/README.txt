Analysis v2: exact native operands and inherited-prefix arithmetic

The parent real-seed 1 ps replay already passes complete saved-state, reservoir,
restart/history and frame parity against its baseline. This revision changes
only the offline event analyzer. No native source, observer binary, replay data,
v1 analyzer or failed receipt was changed. No GPU rerun was performed.

PREFIX
/home/treefor/Documents/Codex/2026-10-28/we/outputs/pic-profile/native-event-analysis-v2

RESULT
real-seed-event-analysis.json passes 800 checks for 308 events: 192 births and
116 sinks, including 94 sinks with a birth recorded in this segment and 22 with
inherited/unknown origin. The aggregate flux, source-face spectra, authored
birth totals and angular coverage flag are EXACTLY the same values as the v1
failed report. This revision corrects verification of the arithmetic, not the
observed data or the flux reduction. Finite-foil/transverse normals and inherited
origins remain unknown. Complete incidence-angle coverage is still false.

V1 FAILURE DIAGNOSIS
V1 failed 22 source patch-length comparisons and 3 charge-ledger comparisons.
Neither failure identifies changed native physics:

1. Actual thermal source length is a difference of rounded coordinates.
For original coordinate low/high and fractions f0/f1, native code performs:
  span = high - low
  upper = low + f1*span
  lower = low + f0*span
  length = upper - lower
Each operation uses binary64. Native weight then uses this ACTUAL length:
  J*length*depth*dt/(e*count)
V1 instead checked face_area/depth*(f1-f0), scaling its tolerance by the tiny
patch length. That formula omits rounding of the larger translated endpoints
and adds an area/depth roundtrip of its own. With 256 patches along a 0.2 mm
foil thickness, 0.78 um patches sit at roughly 1.8/7 mm offsets.

Event 25 logged length 7.812500000007813e-7 m; ideal represented-coordinate
length is 7.812499999999987e-7 m. Error is 7.826584432629735e-19 m, within a
coordinate-operand bound of 8.691616830013191e-19 m. V1's length-scaled limit
was only 1.776356839402027e-19 m. All 192 thermal lengths match the native
endpoint computation EXACTLY. V2 requires this exact identity; it does not
increase the length tolerance. The report also retains endpoint hex values,
ideal length and an independently justified forward-error certificate.

The bound for absolute native length error relative to represented-coordinate
ideal (high-low)*(f1-f0) is:
  |f1-f0| * half_ulp(span)
  + half_ulp(f1*span) + half_ulp(f0*span)
  + half_ulp(upper) + half_ulp(lower) + half_ulp(length).
Fractions of the exact binary64 values are used to prove this bound. This
accounts for coordinate cancellation, not a guessed relative patch tolerance.

2. Inherited ledger prefixes round at their full magnitude during every add.
The three relevant inherited charge ledgers are about -1.84e-16 C. This window
adds only about -4.82/-4.92e-19 C through 96/98 sequential additions. Native
ledger += increment rounds on EACH addition to the inherited prefix. Subtracting
final-initial afterward does not recover the mathematical sum of increments.

lower source: -4.6713430801112406e-31 C difference, 96 additions.
upper source: -3.796007920387242e-31 C difference, 96 additions.
lower wall:   -4.729120978442858e-31 C difference, 98 additions.
The prefix ULP is 2.465190328815662e-32 C. The old shared increment-scaled
limit was 3.515423226376129e-31 C. Native sequential replay from each recorded
inherited prefix reproduces every final ledger BIT FOR BIT, including these
three. Their addition-rounding bounds are about 1.1833e-30/1.2079e-30 C.
Actual signed accumulation roundoff and the small sum/subtraction roundoff
are recorded separately in native_ledger_roundoff; nothing is silently zeroed.

V2 VERIFICATION
All 14 cumulative source/sink charge/energy streams are replayed from their
initial prefix in event commit order. Native thermal calls are reconstructed
as contiguous kernel_count rows with identical metadata and consecutive IDs.
The native charge operand is (-e*weight)*count for each batch, not a different
per-particle summation. Batch energies use native left-associated three-term
norm2 and sequential per-batch accumulation. Python 3.12+ sum() may use improved
summation, so it must not stand in for a C++ sequential addition when checking
its exact operation order. Existing independent physical K, weight, histogram
and energy-vs-native-operand checks remain in place.

Each native ledger replay requires EXACT final equality (zero tolerance).
Thermal batch aggregate charge/energy operands also match exactly. One-ULP
prefix/final corruption is rejected, even when the corrupt final value is also
written into a copied checkpoint to pass the checkpoint-summary binding.
No universal epsilon multiplier was raised. The old 1024*epsilon helper is
unchanged for independent physical balances, event weights/energies and spectral
normalization; runtime/scientific residual guards are untouched.

For audit, the difference between a rounded accurate event sum and rounded
(final-initial) has an operand-specific bound:
  sum_over_native_adds(half_ulp(rounded_prefix_after_add))
  + half_ulp(rounded_delta) + half_ulp(rounded_event_sum).
The report uses exact rational values of binary64 operands to certify this
inequality and calculate signed cumulative roundoff. This is explanatory
metadata in addition to, never a replacement for, exact prefix replay.
A cumulative double ledger cannot resolve arbitrary sub-ULP increments by
itself; event identity/count, source metadata, physical balances and the parent's
full-state comparison remain necessary and are retained.

SCOPE OF EXACT REPLAY
The exact operation checks target this frozen x86 binary64 implementation and
its current source/operator order and build flags (-O3, no fast-math or explicit
FMA target). The independent compiled C++ oracle uses that compiler/flags.
Changing native arithmetic order, FMA contraction, ABI or floating-point mode
requires a new reviewed analysis version. V2 fails closed on an exact mismatch;
it does not silently switch to a larger epsilon budget.

CPU EVIDENCE
All checks ran CPU 6, nice 15, one job/thread under testing-core.lock, with no
visible CUDA device. test-results.json records:
- Real parent stream: 800 checks passed.
- Original finite/flat/restart CPU streams: 218/127/109 checks passed.
- Original capped streams remain incomplete/ineligible.
- 85 compiled C++ oracle patch cases: offsets 0, 1.8 mm, 7 mm, 0.125 m and
  1024 m; 2/256/4096/65536 patches with endpoints/interiors; exact native length
  and native source-weight agreement plus coordinate forward-error proof.
  These isolate native arithmetic; they are not new full PIC mesh simulations.
- 8 compiled native prefix cases include the three actual inherited ledgers,
  huge prefixes with very small increments, cancellation, tiny normal numbers
  and multi-particle source batches. Exact replay and rational bounds pass.
- All 27 v1 corrupt evidence cases remain rejected; 8 new real-stream mutations
  reject one-ULP length/prefix/final errors, inconsistent batch boundaries,
  altered weights/energy, and fabricated normals/origins (35 total).
- preserved-inputs-before/after.json prove all 23 captured parent/v1 files remain
  byte-identical, including the observer executable, failed receipt, raw events,
  summary/cursor/checkpoint, full comparison and ancillary replay data.

RUN (lease acquired internally)
  taskset -c 6 nice -n 15 env OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 CUDA_VISIBLE_DEVICES= python3 /home/treefor/Documents/Codex/2026-10-28/we/outputs/pic-profile/native-event-analysis-v2/analyze_events.py /home/treefor/Documents/Codex/2026-10-28/we/outputs/pic-profile/native-event-log-prototype/real-seed-1ps/events --output /absolute/path/to/new-report.json

Test entry point is test_analysis_v2.py with the same CPU/thread environment.
Native oracle source, executable, stdout and exact compiler commands are retained
in native-arithmetic-oracle.cpp, oracle-*.log and native-arithmetic-fixtures.json.
No production run, source integration, chemistry or extra diagnostic is included.
