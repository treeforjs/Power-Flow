"""Read-only real-evidence audit, native arithmetic oracle and corruption tests."""
import csv,hashlib,json,math,os,pathlib,shutil,struct,subprocess,sys
sys.dont_write_bytecode=True
import analyze_events as a
import native_arithmetic as fp
P=pathlib.Path(__file__).parent
V1=P.parent/'native-event-log-prototype'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

def check(ok,message):
 if not ok:raise AssertionError(message)
def read_rows(path):
 with path.open(newline='')as f:return list(csv.DictReader(f))
def json_change(d,file,fn):
 p=d/file;x=json.loads(p.read_text());fn(x);p.write_text(json.dumps(x)+'\n')
def rewrite(d,rows):
 with(d/'events.csv').open('w',newline='')as f:
  w=csv.DictWriter(f,fieldnames=a.COLUMNS);w.writeheader();w.writerows(rows)
 json_change(d,'cursor.json',lambda x:x.update(csv_prefix_bytes=(d/'events.csv').stat().st_size))
def inspect(d):
 try:return a.inspect(d)
 except (ValueError,OSError,KeyError,TypeError,OverflowError,ZeroDivisionError,struct.error)as e:return {'status':'invalid','flux_eligible':False,'error':str(e)}
def main():
 check(sorted(os.sched_getaffinity(0))==[6]and os.getpriority(os.PRIO_PROCESS,0)==15,'scheduling')
 outputs={};oracle=[];ledgercases=[];corruptions=[];fixtures=P/'fixtures';fixtures.mkdir(exist_ok=True)
 with a.native.cpu_lease():
  before=json.loads((P/'preserved-inputs-before.json').read_text());check(all(sha(pathlib.Path(k))==v for k,v in before.items()),'v1 changed before checks')
  for label,path in [('real-seed',V1/'real-seed-1ps/events'),('finite',V1/'evidence/finite-on-enabled/events'),('flat',V1/'evidence/flat-on-enabled/events'),('resume',V1/'evidence/resume-on/events')]:
   r=inspect(path);check(r['status']=='passed',label+': '+str(r.get('failures',r.get('error'))));outputs[label]=r
   (P/(label+'-event-analysis.json')).write_text(json.dumps(r,indent=2,allow_nan=False)+'\n')
  for label in ('finite','flat'):
   r=inspect(V1/('evidence/'+label+'-on-capped/events'));check(r['status']=='incomplete'and not r['flux_eligible'],'capped '+label)
  for d in sorted((V1/'evidence-fixtures').iterdir()):
   if not d.is_dir():continue
   r=inspect(d);check(r['status']in ('invalid','failed','incomplete')and not r['flux_eligible'],'accepted v1 corruption '+d.name);corruptions.append({'fixture':'v1/'+d.name,'status':r['status']})
  # High-resolution sources translated far from the origin: reproduce native
  # endpoint subtraction, not the nominal face length times fractional width.
  for low,span in [(0.,.005),(.0018,.0002),(.007,.0002),(.125,.005),(1024.,.005)]:
   high=low+span
   for n in (2,256,4096,65536):
    for i in sorted({0,1,n//2,n-2,n-1}):
     start=i/n;end=(i+1)/n;c=fp.patch_certificate(low,high,start,end);check(c['native_length_m']>0 and c['coordinate_rounding_bound_proved'],'patch forward-error proof')
     oracle.append({'low':low,'high':high,'start':start,'end':end,'J':3e-8,'depth':.025,'dt':1e-12,'count':3,'certificate':c})
  # The real 96-add prefix and deliberately poorly conditioned ledgers.
  real=outputs['real-seed']['native_ledger_roundoff']
  parsed=[]
  for raw in read_rows(V1/'real-seed-1ps/events/events.csv'):
   parsed.append({k:(raw[k]if k in a.TEXT else None if raw[k]==''else int(raw[k])if k in a.INTEGER else float(raw[k]))for k in a.COLUMNS})
  real_streams=fp.ledger_streams(parsed,fp.thermal_batches(parsed))
  for key in ('lower_injected_charge_C','upper_injected_charge_C','lower_absorbed_charge_C'):
   ledgercases.append({'name':key,'initial':real[key]['initial'],'increments':real_streams[key]})
  for name,initial,values in [('large-prefix',1.,[1e-18]*512),('prefix-small-increments',-1e-6,[-1e-12]*256),('cancelling-prefix',1.,[1e-16,-1e-16]*128),('tiny-normal',1e-300,[1e-310]*512),('multicount-source',-1e-16,[(-fp.E*2.3e-5)*3]*96)]:ledgercases.append({'name':name,'initial':initial,'increments':values})
  def hx(x):return float(x).hex()
  code=['#include <cmath>\n#include <iostream>\n#include <vector>\n__attribute__((noinline)) double length(double lo,double hi,double first,double last){double span=hi-lo;hi=lo+last*span;lo+=first*span;return hi-lo;}\n__attribute__((noinline)) double weight(double J,double L,double D,double dt,int n){return J*L*D*dt/(1.602176634e-19*n);}\nint main(){std::cout<<std::hexfloat;\n']
  for j,r in enumerate(oracle):
   code.append('{volatile double v[]={'+','.join(hx(r[k])for k in ('low','high','start','end','J','depth','dt'))+'};double L=length(v[0],v[1],v[2],v[3]);std::cout<<"P '+str(j)+' "<<L<<" "<<weight(v[4],L,v[5],v[6],3)<<"\\n";}\n')
  for j,r in enumerate(ledgercases):
   code.append('{volatile double initial='+hx(r['initial'])+';volatile double v[]={'+','.join(hx(x)for x in r['increments'])+'};double t=initial;for(double x:v)t+=x;std::cout<<"L '+str(j)+' "<<t<<"\\n";}\n')
  code.append('}\n');(P/'native-arithmetic-oracle.cpp').write_text(''.join(code))
  commands=[['/home/treefor/projects/runtimes/arch-base-20261028/run-frozen','/usr/sbin/c++','-O3','-DNDEBUG','-std=c++20',str(P/'native-arithmetic-oracle.cpp'),'-o',str(P/'native-arithmetic-oracle')],['/home/treefor/projects/runtimes/arch-base-20261028/run-frozen',str(P/'native-arithmetic-oracle')]]
  for i,command in enumerate(commands):
   r=subprocess.run(command,capture_output=True,text=True);(P/('oracle-'+str(i)+'.log')).write_text(r.stdout+r.stderr);check(r.returncode==0,'native arithmetic oracle command')
  for line in r.stdout.splitlines():
   parts=line.split();j=int(parts[1]);value=float.fromhex(parts[2])
   if parts[0]=='P':
    row=oracle[j];expected=row['certificate']['native_length_m'];check(value==expected,'native patch operation order');w=row['J']*value*row['depth']*row['dt']/(fp.E*row['count']);check(w==float.fromhex(parts[3]),'native source weight operation order')
   else:
    row=ledgercases[j];expected=fp.ordered_sum(row['increments'],row['initial']);check(value==expected,'native ledger operation order');certificate=fp.ledger_certificate(row['initial'],value,row['increments']);check(certificate['prefix_replay_exact']and certificate['sum_delta_rounding_bound_proved'],'ledger bound certificate');row['certificate']=certificate
    corrupt=fp.ledger_certificate(row['initial'],math.nextafter(value,math.inf),row['increments']);check(not corrupt['prefix_replay_exact'],'accepted one-ULP final ledger corruption')
  (P/'native-arithmetic-fixtures.json').write_text(json.dumps({'patch_cases':oracle,'ledger_cases':ledgercases,'commands':commands},indent=2,allow_nan=False)+'\n')
  # More mutations of the parent real event stream; all writes are under v2.
  def fixture(name,fn):
   d=fixtures/name
   if d.exists():shutil.rmtree(d)
   shutil.copytree(V1/'real-seed-1ps/events',d);fn(d);r=inspect(d)
   check(r['status']in ('invalid','failed','incomplete')and not r['flux_eligible'],'accepted new corruption '+name)
   corruptions.append({'fixture':'v2/'+name,'status':r['status'],'failed_checks':[x['name']for x in r.get('failures',[])],'error':r.get('error')})
  def row_change(predicate,key,fn):
   def change(d):
    rows=read_rows(d/'events.csv');row=next(x for x in rows if predicate(x));row[key]=fn(row[key]);rewrite(d,rows)
   return change
  source=lambda r:r['kind']=='thermal_birth'
  sink=lambda r:r['kind']=='lower_wall'
  fixture('patch_length_one_ulp',row_change(source,'patch_length_m',lambda x:repr(math.nextafter(float(x),math.inf))))
  fixture('kernel_count_batch_boundary',row_change(source,'kernel_count',lambda _: '2'))
  fixture('source_weight_corruption',row_change(source,'weight',lambda x:repr(float(x)*(1+1e-7))))
  fixture('sink_native_energy_corruption',row_change(sink,'native_weighted_K_J',lambda x:repr(float(x)*(1+1e-7))))
  fixture('invented_normal',row_change(sink,'normal_known',lambda _: '1'))
  fixture('inherited_origin_invented',row_change(lambda r:r['source_known']=='0','source_known',lambda _:'1'))
  fixture('inherited_prefix_one_ulp',lambda d:json_change(d,'summary.json',lambda x:x['initial']['ledger'].update(lower_injected_charge_C=math.nextafter(x['initial']['ledger']['lower_injected_charge_C'],math.inf))))
  def final_ulp(d):
   cursor=json.loads((d/'cursor.json').read_text());original=pathlib.Path(cursor['checkpoint']);dest=d/'corrupt-checkpoint.bin';data=bytearray(original.read_bytes());schema=a.native.schema()['diagnostics'];offset=176+next(field['offset']for field in schema if field['name']=='lower_injected_charge_C')
   value=math.nextafter(struct.unpack_from('<d',data,offset)[0],math.inf);struct.pack_into('<d',data,offset,value);dest.write_bytes(data)
   json_change(d,'cursor.json',lambda x:x.update(checkpoint=str(dest)));json_change(d,'summary.json',lambda x:x['final']['ledger'].update(lower_injected_charge_C=value))
  fixture('final_ledger_one_ulp_with_matching_checkpoint',final_ulp)
  check(all(sha(pathlib.Path(k))==v for k,v in before.items()),'v1/parent evidence changed')
  (P/'preserved-inputs-after.json').write_text(json.dumps({'all_preserved':True,'sha256':before},indent=2)+'\n')
  report={'status':'passed','execution':{'cpu':6,'nice':15,'threads':1,'jobs':1,'lease':str(a.native.LEASE),'GPU_work':False},'real_event_counts':{k:outputs['real-seed'][k]for k in ('event_count','births','sinks','source_known_sink_count','inherited_or_unobserved_sink_count')},'analysis_checks':{k:len(v['checks'])for k,v in outputs.items()},'native_high_resolution_offset_patch_cases':len(oracle),'native_prefix_ledger_cases':len(ledgercases),'rejected_corruptions':len(corruptions),'corruptions':corruptions,'preserved_v1_parent_files':len(before),'native_runtime_or_scientific_guard_changes':False,'GPU_rerun':False}
  (P/'test-results.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n');print(json.dumps({k:v for k,v in report.items()if k not in ('corruptions','execution')}))
if __name__=='__main__':main()
