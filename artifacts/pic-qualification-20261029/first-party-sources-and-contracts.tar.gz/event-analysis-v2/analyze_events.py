"""Independent finite/balance/normalization checks for the observational prototype."""
import argparse,bisect,csv,hashlib,json,math,pathlib,struct,sys
sys.dont_write_bytecode=True
HERE=pathlib.Path(__file__).parent
sys.path.insert(0,str(HERE.parent/'cpu-independent-review/checkpoint-validation'))
import compare_saved_pic as native
import native_arithmetic as arithmetic
KINDS=['thermal_birth','authored_birth','lower_wall','upper_wall','short_absorption','feed_escape','short_plane_escape','transverse_escape']
INTEGER={'event_seq','advance_step','half','particle_id','normal_known','source_known','birth_event_seq','source_electrode','source_surface','profile_event_seq','profile_seed','patch_index','patch_count','kernel_seed','kernel_count'}
TEXT={'kind','normal_convention'}
OPTIONAL={'native_weighted_K_J','profile_seed','patch_index','patch_count','profile_T_K','profile_J_A_m2','kernel_seed','kernel_T_K','kernel_J_A_m2','kernel_dt_s','kernel_count','start_fraction','end_fraction','patch_length_m'}
COLUMNS='event_seq kind time_global_s time_local_s advance_step half flight_s particle_id weight q_C mass_kg x_m y_m z_m ux_m_s uy_m_s uz_m_s native_weighted_K_J normal_known nx ny nz normal_convention source_known birth_event_seq source_electrode source_surface profile_event_seq profile_seed patch_index patch_count profile_T_K profile_J_A_m2 kernel_seed kernel_T_K kernel_J_A_m2 kernel_dt_s kernel_count start_fraction end_fraction patch_length_m'.split()
ENERGY=[0.,.1,.3,1.,3.,10.,30.,100.,300.,1000.,3000.,10000.,100000.,1000000.]

def checkpoint(path):
 s=native.schema();data=path.read_bytes();native.require(len(data)>=392 and struct.unpack_from('<Q',data)[0]==native.MAGIC,'bad checkpoint header')
 o=native.decode(data,8,s['options'],'options');d=native.decode(data,176,s['diagnostics'],'diagnostics');next_id,n=struct.unpack_from('<QQ',data,376)
 native.require(0<next_id and n<=native.MAX_PARTICLES and len(data)==392+80*n,'bad checkpoint count/length')
 p=[native.decode(data,392+80*i,s['particle'],'particle')for i in range(n)]
 return o,d,next_id,p

def geometry(options):
 """Independent exposed areas/normals from the checkpoint geometry, in SI."""
 width=options['width_m'];height=options['gap_m'];depth=options['depth_m']
 native.require(min(width,height,depth)>0,'invalid geometry')
 foil={}
 for electrode,label in enumerate(('lower','upper')):
  w=options[label+'_foil.right_m']-options[label+'_foil.left_m'];h=options[label+'_foil.top_m']-options[label+'_foil.bottom_m']
  foil[electrode]=(w,h)
 finite=options['finite_foils'];axial=options['finite_axial_extent']
 vacuum=width*height-(sum(w*h for w,h in foil.values())if finite else 0)
 bridge=foil[0][0]*(options['upper_foil.bottom_m']-options['lower_foil.top_m'])if axial else 0.
 areas=dict.fromkeys(KINDS,0.)
 for electrode,label in enumerate(('lower','upper')):
  w,h=foil[electrode];areas[label+'_wall']=2*(w+h)*depth if finite else width*depth
 areas.update(short_absorption=bridge,feed_escape=vacuum if axial else 0.,short_plane_escape=vacuum-bridge if axial else 0.,transverse_escape=2*(width+height)*depth if finite else 0.)
 faces={(e,f):((foil[e][0]if f<2 else foil[e][1])*depth if finite else width*depth)for e in (0,1)for f in range(4)if finite or f==0}
 return areas,faces

def spectrum(events,area_cm2,exposure):
 energy_hist={};mu_hist={};joint={};unknown=0.
 for r in events:
  eb=bisect.bisect_right(ENERGY,r['derived_K_eV'])-1
  native.require(0<=eb<len(ENERGY)-1,'prototype energy support overflow; no silent clipping')
  energy_hist[eb]=energy_hist.get(eb,0.)+r['weight']
  if r['incidence_cosine']is None:unknown+=r['weight'];continue
  mb=min(int(max(0.,r['incidence_cosine'])*8),7)
  mu_hist[mb]=mu_hist.get(mb,0.)+r['weight'];joint[eb,mb]=joint.get((eb,mb),0.)+r['weight']
 energy=[{'E_lo_eV':ENERGY[j],'E_hi_eV':ENERGY[j+1],'dGamma_dE_cm2_s_eV':w/(area_cm2*exposure*(ENERGY[j+1]-ENERGY[j]))}for j,w in sorted(energy_hist.items())]
 angular=[{'mu_lo':j/8,'mu_hi':(j+1)/8,'theta_lo_rad':math.acos((j+1)/8),'theta_hi_rad':math.acos(j/8),'weight':w,'dGamma_dmu_cm2_s':w/(area_cm2*exposure/8)}for j,w in sorted(mu_hist.items())]
 pairs=[{'E_lo_eV':ENERGY[e],'E_hi_eV':ENERGY[e+1],'mu_lo':m/8,'mu_hi':(m+1)/8,'d2Gamma_dEdmu_cm2_s_eV':w/(area_cm2*exposure*(ENERGY[e+1]-ENERGY[e])/8)}for(e,m),w in sorted(joint.items())]
 return {'energy_spectrum':energy,'known_incidence_spectrum':angular,'known_joint_energy_incidence_spectrum':pairs,'unknown_incidence_weight':unknown}

def inspect(directory):
 directory=pathlib.Path(directory);s=native.strict_json(directory/'summary.json');cursor=native.strict_json(directory/'cursor.json');data=(directory/'events.csv').read_bytes()
 native.require(cursor['csv_prefix_bytes']==len(data),'uncommitted or truncated CSV tail; no automatic trimming')
 native.require(cursor['written_rows']==s['written_rows'],'cursor/summary row mismatch')
 path=pathlib.Path(cursor['checkpoint']);native.require(path.stat().st_size==cursor['checkpoint_bytes'],'checkpoint size differs from cursor')
 options,d,next_id,particles=checkpoint(path)
 areas,face_areas=geometry(options)
 native.require(s['schema']==cursor['schema']==1,'unsupported schema')
 native.require(set(s['final']['ledger'])==set(d)and all(s['final']['ledger'][k]==v for k,v in d.items()),'checkpoint final ledger differs from summary')
 final_ids={p['id']for p in particles}
 native.require(len(final_ids)==len(particles)and all(0<i<next_id for i in final_ids),'invalid checkpoint IDs')
 native.require(d['time_s']==cursor['checkpoint_clock_s'] and next_id==cursor['checkpoint_next_id'] and len(particles)==cursor['checkpoint_macros'],'checkpoint identity differs from cursor')
 native.require(cursor['checkpoint_matches_observed_endpoint'] and d['time_s']==s['final']['ledger']['time_s'] and next_id==s['final']['next_id'] and len(particles)==s['final']['macro_particles'],'checkpoint is not the observed endpoint')
 checks=[]
 def close(name,a,b,scale):
  native.finite(a,name);native.finite(b,name);limit=1024*native.EPS*max(abs(scale),1e-300)
  checks.append({'name':name,'a':a,'b':b,'absolute_difference':abs(a-b),'absolute_limit':limit,'passed':abs(a-b)<=limit})
 def exact(name,a,b):checks.append({'name':name,'a':a,'b':b,'passed':a==b})
 close('checkpoint final weight',sum(p['weight']for p in particles),s['final']['weight'],s['final']['weight'])
 close('checkpoint final charge',sum(p['charge_C']*p['weight']for p in particles),s['final']['charge_C'],abs(s['final']['charge_C']))
 native.require(s['max_window_s']==1e-12 and s['max_steps']==4096 and 1<=s['row_cap']<=65536 and 0<=s['accepted_steps']<=4096,'invalid prototype bounds')
 native.require(0<=s['written_rows']<=s['row_cap']and s['dropped_rows']==s['attempted_events']-s['written_rows']and cursor['dropped_rows']==s['dropped_rows'],'invalid row budget counters')
 rows=[];births={};removed=set();groups={k:[]for k in KINDS};angle_unknown={k:0. for k in KINDS}
 with (directory/'events.csv').open(newline='')as f:
  reader=csv.DictReader(f);native.require(reader.fieldnames==COLUMNS,'unexpected event schema')
  for number,raw in enumerate(reader,1):
   native.require(None not in raw and all(x is not None for x in raw.values()),'malformed event row')
   row={}
   for k,text in raw.items():
    if k in TEXT:row[k]=text
    elif text=='':native.require(k in OPTIONAL,'missing required '+k);row[k]=None
    elif k in INTEGER:row[k]=int(text)
    else:row[k]=native.finite(float(text),'event '+k)
   native.require(row['event_seq']==number and row['kind']in KINDS,'event cursor/kind mismatch')
   native.require(row['particle_id']>0 and row['weight']>0 and row['mass_kg']>0 and row['normal_known']in (0,1) and row['source_known']in (0,1),'invalid event particle/flag')
   time_tol=64*native.EPS*max(abs(row['time_global_s']),1e-12)
   native.require(abs(row['time_global_s']-(s['global_origin_s']+row['time_local_s']))<=time_tol,'event clock origin mismatch')
   native.require(s['initial']['ledger']['time_s']-time_tol<=row['time_local_s']<=s['final']['ledger']['time_s']+time_tol,'event outside accepted exposure')
   u=[row[k]for k in ('ux_m_s','uy_m_s','uz_m_s')];u2=sum(x*x for x in u);native.finite(u2,'proper speed squared')
   energy=row['mass_kg']*u2/(math.sqrt(1+u2/native.C_LIGHT**2)+1);native.finite(energy,'event kinetic energy')
   row['derived_K_J']=energy;row['derived_K_eV']=energy/native.E_CHARGE;row['weighted_K_J']=energy*row['weight'];row['weighted_charge_C']=row['q_C']*row['weight']
   normal=[row[k]for k in ('nx','ny','nz')]
   if row['normal_known']:
    native.require(sum(x*x for x in normal)==1.,'invalid normal');row['incidence_cosine']=sum(x*y for x,y in zip(u,normal))/math.sqrt(u2)if u2 else None
    if row['incidence_cosine']is not None:native.require(-64*native.EPS<=row['incidence_cosine']<=1+64*native.EPS,'event momentum disagrees with known outward normal')
   else:
    native.require(normal==[0.,0.,0.]and row['normal_convention']=='unknown','unknown normal must not contain a fabricated direction');row['incidence_cosine']=None;angle_unknown[row['kind']]+=row['weight']
   if not row['source_known']or row['kind']=='authored_birth':
    native.require(row['profile_event_seq']==0 and all(row[k]is None for k in OPTIONAL-{'native_weighted_K_J'}),'unknown/authored source carries invented thermal provenance')
   if row['kind']=='thermal_birth':
    e,f=row['source_electrode'],row['source_surface'];native.require((e,f)in face_areas,'unsupported source face')
    normal_expected=([0.,1. if e==0 else -1.,0.]if f==0 else [0.,-1. if e==0 else 1.,0.]if f==1 else [-1.,0.,0.]if f==2 else [1.,0.,0.])
   elif row['kind']in ('lower_wall','upper_wall')and not options['finite_foils']:
    normal_expected=[0.,-1. if row['kind']=='lower_wall'else 1.,0.]
   elif row['kind']in ('short_absorption','short_plane_escape','feed_escape'):
    normal_expected=[0.,0.,1. if row['kind']=='feed_escape'else -1.]
   else:normal_expected=[0.,0.,0.]
   native.require(normal==normal_expected and bool(row['normal_known'])==bool(any(normal_expected)),'normal disagrees with retained native surface information')
   expected_convention='source_outward'if row['kind']=='thermal_birth'else 'vacuum_outward'if any(normal_expected)else 'unknown'
   native.require(row['normal_convention']==expected_convention,'wrong normal convention')
   if row['kind'].endswith('_birth'):
    native.require(row['particle_id']not in births and row['particle_id']not in removed and row['birth_event_seq']==row['event_seq'] and row['source_known']==1,'invalid birth identity/provenance')
    native.require(row['half']==0 and row['flight_s']==0,'birth was backdated into a drift');births[row['particle_id']]=row
    if row['kind']=='thermal_birth':
     native.require(row['source_electrode']in (0,1)and row['source_surface']in (0,1,2,3)and row['kernel_count']and row['kernel_count']>0 and row['kernel_dt_s']>0 and row['patch_length_m']>0,'missing thermal creation provenance')
     native.require(row['kernel_T_K']>0 and row['kernel_J_A_m2']>=0 and 0<=row['start_fraction']<row['end_fraction']<=1,'invalid source kernel metadata')
     exact('source patch length '+str(row['event_seq']),row['patch_length_m'],arithmetic.patch_length(options,row))
     expected=row['kernel_J_A_m2']*row['patch_length_m']*options['depth_m']*row['kernel_dt_s']/(native.E_CHARGE*row['kernel_count'])
     close('birth weight '+str(row['event_seq']),row['weight'],expected,expected)
     if row['profile_event_seq']:
      native.require(row['profile_seed']is not None and row['patch_count']and 0<=row['patch_index']<row['patch_count'] and row['profile_T_K']==row['kernel_T_K'],'missing/mismatched actual profile patch provenance')
   else:
    native.require(row['particle_id']not in removed and row['half']in (1,2)and row['flight_s']>=0,'duplicate sink or invalid drift phase');removed.add(row['particle_id'])
    native.require(row['native_weighted_K_J']is not None,'sink lacks existing native energy operand')
    close('native sink energy '+str(row['event_seq']),row['native_weighted_K_J'],row['weighted_K_J'],row['native_weighted_K_J'])
    if row['source_known']:
     native.require(row['particle_id']in births and row['birth_event_seq']==births[row['particle_id']]['event_seq'],'sink source must reference an actual logged birth')
     b=births[row['particle_id']]
     native.require(all(row[k]==b[k]for k in ('weight','q_C','mass_kg','source_electrode','source_surface','profile_event_seq','profile_seed','patch_index','patch_count','profile_T_K','profile_J_A_m2','kernel_seed','kernel_T_K','kernel_J_A_m2','kernel_dt_s','kernel_count','start_fraction','end_fraction','patch_length_m')),'sink/birth provenance changed')
    else:native.require(row['birth_event_seq']==0 and row['source_electrode']==row['source_surface']==-1,'inherited provenance must remain unknown')
   groups[row['kind']].append(row);rows.append(row)
 exact('written rows',len(rows),s['written_rows'])
 eligible=s['complete']is True and s['dropped_rows']==0 and not s['io_error']and not s['step_cap_hit']
 if not eligible:return {'status':'incomplete','flux_eligible':False,'written_rows':len(rows),'dropped_rows':s['dropped_rows'],'reason':'bounded/incomplete stream cannot supply complete energy/angle flux','checks':checks}
 native.require(all(s['initial']['next_id']<=r['particle_id']<next_id for r in births.values()),'birth ID outside segment allocation')
 native.require(all((r['source_known']or r['particle_id']<s['initial']['next_id'])and r['particle_id']not in final_ids for r in rows if not r['kind'].endswith('_birth')),'sink identity disagrees with checkpoint')
 native.require(all((pid in removed)==(pid not in final_ids)for pid in births),'birth survivor identity disagrees with checkpoint')
 exact('attempted/written events',s['attempted_events'],len(rows));exact('cursor attempted sequence',cursor['last_attempted_event_seq'],len(rows))
 exposure=s['actual_exposure_s'];native.require(exposure>0,'zero exposure cannot normalize flux')
 close('actual exposure',exposure,s['final']['ledger']['time_s']-s['initial']['ledger']['time_s'],exposure)
 def total(k,key):return sum(r[key]for r in groups[k])
 scales={key:sum(abs(r[key])for r in rows)for key in ('weight','weighted_charge_C','weighted_K_J')}
 birth=[r for r in rows if r['kind'].endswith('_birth')];sink=[r for r in rows if not r['kind'].endswith('_birth')]
 exact('macro count balance',s['initial']['macro_particles']+len(birth)-len(sink),s['final']['macro_particles'])
 exact('next ID increment',s['final']['next_id']-s['initial']['next_id'],len(birth))
 close('physical weight balance',s['initial']['weight']+sum(r['weight']for r in birth)-sum(r['weight']for r in sink),s['final']['weight'],s['initial']['weight']+scales['weight'])
 close('physical charge balance',s['initial']['charge_C']+sum(r['weighted_charge_C']for r in birth)-sum(r['weighted_charge_C']for r in sink),s['final']['charge_C'],abs(s['initial']['charge_C'])+scales['weighted_charge_C'])
 # Preserve independent physical reductions and verify native cumulative ledgers
 # by replaying their actual binary64 updates from the inherited prefix.
 batches=arithmetic.thermal_batches(rows)
 streams=arithmetic.ledger_streams(rows,batches)
 ledger_roundoff={key:arithmetic.ledger_certificate(s['initial']['ledger'][key],s['final']['ledger'][key],increments)for key,increments in streams.items()}
 for key,certificate in ledger_roundoff.items():
  exact(key+' native prefix replay',certificate['replayed_final'],certificate['final'])
  exact(key+' operand-based roundoff certificate',certificate['sum_delta_rounding_bound_proved'],True)
 for electrode,label in ((0,'lower'),(1,'upper')):
  own=[b for b in batches if b['electrode']==electrode]
  exact(label+' native batch charge',arithmetic.ordered_sum(b['charge_C']for b in own),s['thermal_native_charge_C'][electrode])
  exact(label+' native batch energy operation order',arithmetic.ordered_sum(b['energy_J']for b in own),s['thermal_native_energy_J'][electrode])
  e=sum(r['weighted_K_J']for r in groups['thermal_birth']if r['source_electrode']==electrode)
  close(label+' native batch energy',e,s['thermal_native_energy_J'][electrode],scales['weighted_K_J'])
 patch_roundoff=[{'event_seq':r['event_seq'],**arithmetic.patch_certificate(*arithmetic.patch_operands(options,r))}for r in groups['thermal_birth']]
 for certificate in patch_roundoff:exact('patch operand-based roundoff '+str(certificate['event_seq']),certificate['coordinate_rounding_bound_proved'],True)
 surfaces={x['kind']:x for x in s['surfaces']};native.require(set(surfaces)==set(KINDS)and len(s['surfaces'])==len(KINDS),'invalid surface aggregates');flux={}
 source_flux={}
 for kind,events in groups.items():
  aggregate=surfaces[kind];exact(kind+' native aggregate macros',len(events),aggregate['macros'])
  close(kind+' native aggregate weight',total(kind,'weight'),aggregate['weight'],scales['weight'])
  close(kind+' independent area',aggregate['aggregate_area_m2'],areas[kind],areas[kind])
  close(kind+' native aggregate charge',total(kind,'weighted_charge_C'),aggregate['charge_C'],scales['weighted_charge_C'])
  if not kind.endswith('_birth'):close(kind+' native aggregate energy',total(kind,'weighted_K_J'),aggregate['native_sink_energy_J'],scales['weighted_K_J'])
  area_cm2=areas[kind]*1e4
  if kind.endswith('_birth'):continue
  native.require(area_cm2>0 or not events,'event surface has no normalization area')
  hist={};mu_hist={};wave=[{'weight':0.,'charge_C':0.,'energy_J':0.}for _ in range(4)]
  for row in events:
   eb=bisect.bisect_right(ENERGY,row['derived_K_eV'])-1;native.require(0<=eb<len(ENERGY)-1,'prototype energy support overflow; no silent clipping')
   hist[eb]=hist.get(eb,0.)+row['weight']
   if row['incidence_cosine']is not None:
    mb=min(int(max(0.,row['incidence_cosine'])*8),7);mu_hist[mb]=mu_hist.get(mb,0.)+row['weight']
   wb=min(max(int((row['time_local_s']-s['initial']['ledger']['time_s'])/exposure*4),0),3);wave[wb]['weight']+=row['weight'];wave[wb]['charge_C']+=row['weighted_charge_C'];wave[wb]['energy_J']+=row['weighted_K_J']
  energy_rows=[{'E_lo_eV':ENERGY[j],'E_hi_eV':ENERGY[j+1],'dGamma_dE_cm2_s_eV':w/(area_cm2*exposure*(ENERGY[j+1]-ENERGY[j]))}for j,w in sorted(hist.items())]
  if area_cm2:
   close(kind+' energy flux normalization',sum(x['dGamma_dE_cm2_s_eV']*(x['E_hi_eV']-x['E_lo_eV'])*area_cm2*exposure for x in energy_rows),total(kind,'weight'),scales['weight'])
  close(kind+' known plus unknown angle coverage',sum(mu_hist.values())+angle_unknown[kind],total(kind,'weight'),scales['weight'])
  flux[kind]={'aggregate_area_cm2':area_cm2,'exposure_s':exposure,'particle_flux_cm2_s':total(kind,'weight')/(area_cm2*exposure)if area_cm2 else None,'signed_charge_current_A':total(kind,'weighted_charge_C')/exposure,'energy_flux_W_cm2':total(kind,'weighted_K_J')/(area_cm2*exposure)if area_cm2 else None,'unknown_incidence_weight':angle_unknown[kind],'full_incidence_spectrum_available':angle_unknown[kind]==0.,'energy_spectrum':energy_rows,'known_mu_weight_histogram':mu_hist,'time_bins':[{'t_lo_local_s':s['initial']['ledger']['time_s']+i*exposure/4,'t_hi_local_s':s['initial']['ledger']['time_s']+(i+1)*exposure/4,'current_A':w['charge_C']/(exposure/4),'power_W':w['energy_J']/(exposure/4),'particle_flux_cm2_s':w['weight']/(area_cm2*exposure/4)if area_cm2 else None}for i,w in enumerate(wave)]}
 for kind,events in groups.items():
  if not kind.endswith('_birth')and areas[kind]:
   distributions=spectrum(events,areas[kind]*1e4,exposure);flux[kind].update(distributions)
   close(kind+' joint angle normalization',sum(x['d2Gamma_dEdmu_cm2_s_eV']*(x['E_hi_eV']-x['E_lo_eV'])*(x['mu_hi']-x['mu_lo'])*areas[kind]*1e4*exposure for x in distributions['known_joint_energy_incidence_spectrum'])+distributions['unknown_incidence_weight'],total(kind,'weight'),scales['weight'])
 for(e,f),area in face_areas.items():
  events=[r for r in birth if r['kind']=='thermal_birth'and(r['source_electrode'],r['source_surface'])==(e,f)]
  distributions=spectrum(events,area*1e4,exposure)
  weight=sum(r['weight']for r in events)
  close('source face '+str((e,f))+' energy normalization',sum(x['dGamma_dE_cm2_s_eV']*(x['E_hi_eV']-x['E_lo_eV'])*area*1e4*exposure for x in distributions['energy_spectrum']),weight,scales['weight'])
  source_flux[str(e)+':'+str(f)]={'electrode':e,'surface':f,'macros':len(events),'weight':weight,'aggregate_area_cm2':area*1e4,'particle_creation_flux_cm2_s':weight/(area*1e4*exposure),'signed_charge_current_A':sum(r['weighted_charge_C']for r in events)/exposure,'energy_creation_flux_W_cm2':sum(r['weighted_K_J']for r in events)/(area*1e4*exposure),'clock_definition':'actual batch creation; accumulated reservoir supply is not backdated',**distributions}
 failures=[x for x in checks if not x['passed']]
 digest=lambda content:hashlib.sha256(content).hexdigest()
 return {'status':'passed'if not failures else'failed','flux_eligible':not failures,'incidence_angle_coverage_complete':all(x['full_incidence_spectrum_available']for x in flux.values()),'event_count':len(rows),'births':len(birth),'sinks':len(sink),'source_known_sink_count':sum(r['source_known']for r in sink),'inherited_or_unobserved_sink_count':sum(not r['source_known']for r in sink),'checks':checks,'failures':failures,'analysis_version':2,'native_ledger_roundoff':ledger_roundoff,'native_patch_roundoff':patch_roundoff,'flux':flux,'thermal_creation_flux_by_face':source_flux,'authored_birth_totals':{'macros':len(groups['authored_birth']),'weight':total('authored_birth','weight'),'signed_charge_C':total('authored_birth','weighted_charge_C'),'energy_J':total('authored_birth','weighted_K_J'),'area_and_emitter_face':'unknown; no surface density inferred'},'checkpoint_seal':{'checkpoint':str(path),'checkpoint_sha256':digest(path.read_bytes()),'csv_prefix_sha256':digest(data),'csv_prefix_bytes':len(data),'cursor_sha256':digest((directory/'cursor.json').read_bytes()),'summary_sha256':digest((directory/'summary.json').read_bytes()),'crash_durable':False},'limits':['Terminal native sinks only; no internal detector or reflection crossings are inferred.','Finite foil/transverse escape normals and faces are not retained; their incidence spectra remain unavailable.','Aggregate areas are the declared extruded surfaces, not resolved local face maps.','No chemistry, ions or experimental validation is provided.']}

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('directory',type=pathlib.Path);p.add_argument('--output',type=pathlib.Path,required=True);a=p.parse_args()
 try:
  with native.cpu_lease():r=inspect(a.directory)
 except (ValueError,OSError,KeyError,TypeError,OverflowError,ZeroDivisionError,struct.error)as e:r={'status':'invalid','flux_eligible':False,'error':str(e)}
 a.output.write_text(json.dumps(r,indent=2,allow_nan=False)+'\n');print(json.dumps({k:r[k]for k in ('status','flux_eligible','error')if k in r}))
 return 0 if r['status']=='passed'else 1 if r['status']in ('failed','incomplete')else 2
if __name__=='__main__':raise SystemExit(main())
