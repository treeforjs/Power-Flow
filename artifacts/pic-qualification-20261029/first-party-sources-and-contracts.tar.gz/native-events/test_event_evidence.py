"""CPU-only independent evidence and corruption tests. Does not run a PIC solver."""
import copy,csv,hashlib,io,json,math,os,pathlib,shutil,subprocess,sys
sys.dont_write_bytecode=True
import analyze_events as a
HERE=pathlib.Path(__file__).parent
CASES=HERE/'evidence'
FIXTURES=HERE/'evidence-fixtures'

def check(condition,message):
 if not condition:raise AssertionError(message)
def near(x,y):return math.isclose(x,y,rel_tol=1e-12,abs_tol=0.)
def parsed(path):
 with path.open(newline='')as f:return list(csv.DictReader(f))
def rewrite(directory,rows):
 with (directory/'events.csv').open('w',newline='')as f:
  w=csv.DictWriter(f,fieldnames=a.COLUMNS);w.writeheader();w.writerows(rows)
 cursor=json.loads((directory/'cursor.json').read_text());cursor['csv_prefix_bytes']=(directory/'events.csv').stat().st_size
 (directory/'cursor.json').write_text(json.dumps(cursor)+'\n')
def mutate_json(directory,name,fn):
 p=directory/name;obj=json.loads(p.read_text());fn(obj);p.write_text(json.dumps(obj)+'\n')
def main():
 check(sorted(os.sched_getaffinity(0))==[6]and os.getpriority(os.PRIO_PROCESS,0)==15,'wrong scheduling')
 check(all(os.getenv(k)=='1'for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'))and os.getenv('CUDA_VISIBLE_DEVICES')=='','wrong thread/device environment')
 FIXTURES.mkdir(exist_ok=True);reports={};corruptions=[];assertions=[]
 with a.native.cpu_lease():
  for name in ('finite-on-enabled','flat-on-enabled','resume-on','finite-on-capped','flat-on-capped'):
   r=a.inspect(CASES/name/'events');reports[name]=r
   check(r['status']==('incomplete'if name.endswith('capped')else 'passed'),name)
   (CASES/(name+'-analysis.json')).write_text(json.dumps(r,indent=2,allow_nan=False)+'\n')
  finite=reports['finite-on-enabled'];flat=reports['flat-on-enabled'];resume=reports['resume-on']
  check((finite['event_count'],finite['births'],finite['sinks'])==(44,36,8),'finite native counts')
  check((flat['event_count'],flat['births'],flat['sinks'])==(15,12,3),'flat native counts')
  expected={'lower_wall':2.6,'upper_wall':2.6,'short_absorption':.25,'feed_escape':.79,'short_plane_escape':.54,'transverse_escape':9.}
  for k,area in expected.items():check(near(finite['flux'][k]['aggregate_area_cm2'],area),'independent geometry '+k)
  check(not finite['incidence_angle_coverage_complete']and flat['incidence_angle_coverage_complete'],'normal availability')
  for k in ('lower_wall','upper_wall','transverse_escape'):
   x=finite['flux'][k];check(x['unknown_incidence_weight']>0 and not x['known_incidence_spectrum']and not x['known_joint_energy_incidence_spectrum'],'unknown normal coverage '+k)
  for k in ('short_absorption','feed_escape','short_plane_escape'):
   x=finite['flux'][k];check(x['unknown_incidence_weight']==0 and x['known_incidence_spectrum'],'native axial normal '+k)
  check(near(finite['flux']['feed_escape']['particle_flux_cm2_s'],1e-5/(.79*4e-13)),'known one-crossing flux')
  rows=parsed(CASES/'finite-on-enabled/events/events.csv')
  direct=[r for r in rows if r['kind']=='thermal_birth'and r['kernel_seed']=='998']
  check(len(direct)==2 and all(r['profile_event_seq']=='0'and r['profile_seed']==''and float(r['time_local_s'])==2e-13 for r in direct),'direct source context/time')
  delayed=[r for r in rows if r['particle_id']=='7'and r['kind']=='lower_wall']
  check(len(delayed)==1 and delayed[0]['half']=='2'and 1e-13<float(delayed[0]['time_local_s'])<2e-13,'second half flight timestamp')
  resumed=parsed(CASES/'resume-on/events/events.csv');check(len(resumed)==1 and resumed[0]['particle_id']=='10'and resumed[0]['source_known']=='0'and resumed[0]['birth_event_seq']=='0','resume inherited provenance')
  check(finite['source_known_sink_count']==1 and resume['source_known_sink_count']==0,'source lifecycle count')
  for r in reports.values():
   if r['status']=='passed':check(all(x['passed']for x in r['checks']),'independent balance failure')
   else:check(not r['flux_eligible']and 'flux'not in r,'cap supplied a partial flux')
  assertions.extend(['independent checkpoint/ledger and identity balances','actual source face length/weight and batch energy','all terminal source/sink charge and energy ledgers','independent surface areas and known one-crossing flux','joint energy/mu and source-face normalization','finite foil angles explicitly unavailable','flat/axial normals verified','profile context cleared for direct source','second-half accepted flight timestamp','fresh-process inherited provenance unknown','capped stream ineligible while native parity remains passed'])
  template=CASES/'finite-on-enabled/events'
  def fixture(name,fn):
   d=FIXTURES/name
   if d.exists():shutil.rmtree(d)
   shutil.copytree(template,d);fn(d)
   try:r=a.inspect(d)
   except (ValueError,OSError,KeyError,TypeError,OverflowError,ZeroDivisionError)as e:r={'status':'invalid','flux_eligible':False,'error':str(e)}
   check(r['status']in ('invalid','failed','incomplete')and not r['flux_eligible'],'accepted corrupt fixture '+name)
   corruptions.append({'name':name,'status':r['status'],'error':r.get('error'),'failed_checks':[x['name']for x in r.get('failures',[])]})
  def row_change(predicate,key,value):
   def change(d):
    rs=parsed(d/'events.csv');target=next(r for r in rs if predicate(r));target[key]=value;rewrite(d,rs)
   return change
  first=lambda r:r['event_seq']=='1'
  sink=lambda r:r['kind']=='upper_wall'and r['source_known']=='1'
  for name,key,value in [('nan_weight','weight','nan'),('inf_u','ux_m_s','inf'),('nan_clock','time_local_s','nan'),('negative_weight','weight','-1'),('zero_mass','mass_kg','0'),('source_weight','weight','0.01'),('source_kernel_J','kernel_J_A_m2','0.01'),('birth_backdated','time_local_s','-1e-13'),('wrong_birth_id','particle_id','9000')]:fixture(name,row_change((lambda r:r['kind']=='thermal_birth')if name=='source_kernel_J'else first,key,value))
  fixture('wrong_source_link',row_change(sink,'birth_event_seq','999'))
  fixture('changed_birth_metadata',row_change(sink,'weight','0.01'))
  fixture('invented_source',row_change(lambda r:r['kind']=='feed_escape','source_known','1'))
  fixture('wrong_axial_normal',row_change(lambda r:r['kind']=='feed_escape','nz','-1'))
  def duplicate(d):
   rs=parsed(d/'events.csv');sinks=[r for r in rs if not r['kind'].endswith('_birth')];sinks[1]['particle_id']=sinks[0]['particle_id'];rewrite(d,rs)
  fixture('duplicate_sink',duplicate)
  fixture('wrong_area',lambda d:mutate_json(d,'summary.json',lambda s:s['surfaces'][2].update(aggregate_area_m2=1.)))
  fixture('zero_exposure',lambda d:mutate_json(d,'summary.json',lambda s:s.update(actual_exposure_s=0.)))
  fixture('changed_final_ledger',lambda d:mutate_json(d,'summary.json',lambda s:s['final']['ledger'].update(escaped_charge_C=1.)))
  fixture('changed_final_weight',lambda d:mutate_json(d,'summary.json',lambda s:s['final'].update(weight=1.)))
  fixture('wrong_checkpoint_clock',lambda d:mutate_json(d,'cursor.json',lambda s:s.update(checkpoint_clock_s=1.)))
  fixture('wrong_cursor_bytes',lambda d:mutate_json(d,'cursor.json',lambda s:s.update(csv_prefix_bytes=1)))
  fixture('uncommitted_tail',lambda d:(d/'events.csv').write_bytes((d/'events.csv').read_bytes()+b'garbage\n'))
  fixture('truncated_csv',lambda d:(d/'events.csv').write_bytes((d/'events.csv').read_bytes()[:-10]))
  fixture('missing_summary',lambda d:(d/'summary.json').unlink())
  fixture('missing_cursor',lambda d:(d/'cursor.json').unlink())
  def malformed(d):
   data=(d/'events.csv').read_bytes().replace(b'event_seq,kind',b'bad,kind',1);(d/'events.csv').write_bytes(data);mutate_json(d,'cursor.json',lambda s:s.update(csv_prefix_bytes=len(data)))
  fixture('malformed_schema',malformed)
  for name,obj in [('nonfinite_summary','summary.json'),('nonfinite_cursor','cursor.json')]:
   fixture(name,lambda d,obj=obj:(d/obj).write_text('{"x":NaN}'))
 # Exercise CLI status paths with its own lease, outside the lease above.
 cli=[]
 for name,src,code in [('valid',CASES/'finite-on-enabled/events',0),('incomplete',CASES/'finite-on-capped/events',1),('invalid',FIXTURES/'nan_weight',2)]:
  output=CASES/('cli-'+name+'.json');r=subprocess.run([sys.executable,str(HERE/'analyze_events.py'),str(src),'--output',str(output)],capture_output=True,text=True)
  check(r.returncode==code,'CLI status '+name+': '+r.stdout+r.stderr);cli.append({'name':name,'returncode':r.returncode})
 result={'status':'passed','execution':{'cpu':6,'nice':15,'threads':1,'jobs':1,'lease':str(a.native.LEASE),'GPU_work':False},'native_check_counts':{k:len(v.get('checks',[]))for k,v in reports.items()},'independent_assertions':assertions,'corruption_fixtures':corruptions,'rejected_corruptions':len(corruptions),'cli_status_tests':cli}
 (CASES/'independent-event-checks.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n');print(json.dumps({'status':result['status'],'rejected_corruptions':len(corruptions),'native_checks':result['native_check_counts']}))
if __name__=='__main__':main()
