import json,pathlib,subprocess,os,sys,fcntl,struct,shutil
sys.dont_write_bytecode=True
import analyze_events as a
p=pathlib.Path(__file__).parent;e=p/'evidence';commands=json.loads((e/'commands.json').read_text());record=[]
assert sorted(os.sched_getaffinity(0))==[6]and os.getpriority(os.PRIO_PROCESS,0)==15

def run(name,args,env=None):
 with (e/(name+'.log')).open('wb')as f:r=subprocess.run(args,env=env,stdout=f,stderr=subprocess.STDOUT)
 record.append({'name':name,'argv':args,'returncode':r.returncode});assert r.returncode==0,name

def cpstate(path):
 o,d,n,parts=a.checkpoint(path);return [o,d,n,parts]
with a.native.cpu_lease():
 for label in ('on','reference'):
  cmd=next(x['argv']for x in commands if x['name']=='compile-'+label).copy()
  cmd[cmd.index(str(p/'tests/native_scenario.cpp'))]=str(p/'tests/window_bounds.cpp')
  cmd[cmd.index('-o')+1]=str(e/('bounds-'+label));run('compile-bounds-'+label,cmd)
 report=[]
 for mode in ('time','step','step-late'):
  for label in ('reference','on'):
   out=e/('bounds-'+mode+'-'+label)
   if out.exists():shutil.rmtree(out)
   env=os.environ.copy();env.pop('PIC_NATIVE_EVENT_LOG_DIR',None)
   if label=='on':env['PIC_NATIVE_EVENT_LOG_DIR']=str(out/'events')
   run('bounds-'+mode+'-'+label,[commands[0]['argv'][0],str(e/('bounds-'+label)),str(out),mode],env)
  assert(e/('bounds-'+mode+'-on.log')).read_bytes()==(e/('bounds-'+mode+'-reference.log')).read_bytes()
  assert cpstate(e/('bounds-'+mode+'-on/checkpoint_final.bin'))==cpstate(e/('bounds-'+mode+'-reference/checkpoint_final.bin'))
  eventdir=e/('bounds-'+mode+'-on/events');summary=json.loads((eventdir/'summary.json').read_text())
  if mode=='time':
   assert summary['accepted_steps']==2 and summary['written_rows']==1 and summary['actual_exposure_s']==1.2e-12
   assert len(list(__import__('csv').DictReader((eventdir/'events.csv').open())))==1
  else:assert summary['accepted_steps']==4096 and summary['step_cap_hit']and not summary['complete']and summary['written_rows']==0
  cursor=json.loads((eventdir/'cursor.json').read_text());assert cursor['checkpoint_matches_observed_endpoint']==(mode=='step')
  try:r=a.inspect(eventdir)
  except ValueError as exc:r={'status':'invalid','flux_eligible':False,'reason':str(exc)}
  assert not r['flux_eligible']
  report.append({'case':mode,'physics_checkpoint_and_trace_identical':True,'accepted_steps':summary['accepted_steps'],'logged_rows':summary['written_rows'],'actual_exposure_s':summary['actual_exposure_s'],'step_cap_hit':summary['step_cap_hit'],'later_checkpoint_rejected':mode!='step','cap_at_endpoint_rejected':mode=='step','consumer_status':r['status']})
 (e/'bounds-commands.json').write_text(json.dumps(record,indent=2)+'\n')
 (e/'bounds-checks.json').write_text(json.dumps({'status':'passed','cpu':6,'nice':15,'lease':str(a.native.LEASE),'GPU_work':False,'cases':report},indent=2)+'\n');print(json.dumps(report))
