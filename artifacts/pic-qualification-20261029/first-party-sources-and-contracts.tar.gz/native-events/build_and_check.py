import pathlib,subprocess,os,json,fcntl,hashlib,datetime,struct,re,difflib,sys
sys.dont_write_bytecode=True
OUT=pathlib.Path(__file__).parent;RT=pathlib.Path('/home/treefor/projects/runtimes');MF=RT/'mfem-4.10-pic-20261029';GPU=RT/'mfem-cuda-benchmark-20261029/cuda-libs/nvidia'
REF=RT/'mfem-gpu-pic-20261029/source';RUN=str(RT/'arch-base-20261028/run-frozen')
assert sorted(os.sched_getaffinity(0))==[6] and os.getpriority(os.PRIO_PROCESS,0)==15
assert all(os.environ.get(k)=='1'for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS'))
EVID=OUT/'evidence';commands=[];results=[]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()

def run(name,args,env=None,stdout=None):
 log=stdout or EVID/(name+'.log');cmd=[RUN]+[str(x)for x in args]
 with log.open('wb')as f:proc=subprocess.run(cmd,cwd=OUT,stdout=f,stderr=subprocess.PIPE,env=env)
 (EVID/(name+'.stderr')).write_bytes(proc.stderr);commands.append({'name':name,'argv':cmd,'returncode':proc.returncode,'stdout':str(log),'environment_override':{k:env[k]for k in ('PIC_NATIVE_EVENT_LOG_DIR','PIC_EVENT_MAX_ROWS')if env and k in env}})
 (EVID/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
 if proc.returncode:raise RuntimeError(name+' failed: '+proc.stderr.decode(errors='replace')[-1500:]+'; see '+str(log))
 print(name+': passed',flush=True);return log

def compile_driver(label,source,library,enabled):
 args=['/usr/sbin/c++','-std=c++20','-O3','-DNDEBUG','-I'+str(source/'include'),'-I'+str(source/'src'),'-isystem',str(MF/'install-mpi/include'),'-isystem',str(MF/'tpl/hypre/include'),'-isystem',str(MF/'tpl/metis/include')]
 if enabled:args+=['-DPIC_OBSERVE_EVENTS=1']
 args+=[str(OUT/'tests/native_scenario.cpp'),'-o',str(EVID/('scenario-'+label)),str(library),str(MF/'install-mpi/lib/libmfem.a'),str(MF/'tpl/hypre/lib/libHYPRE.a'),str(MF/'tpl/metis/lib/libmetis.a'),str(MF/'tpl/GKlib/lib/libGKlib.a'),'/usr/lib/libmpi.so','-Wl,-rpath,/usr/lib',str(GPU/'cu12/lib/libcudss.so.0'),str(GPU/'cuda_runtime/lib/libcudart.so.12'),'-Wl,-rpath,'+':'.join(str(GPU/p)for p in ('cu12/lib','cublas/lib','cuda_runtime/lib'))]
 run('compile-'+label,args)

# Canonical comparison ignores only undefined options-struct padding.
sys.path.insert(0,str(OUT.parent/'cpu-independent-review/checkpoint-validation'))
import compare_saved_pic as binary
S=binary.schema()
def state(path):
 data=path.read_bytes();assert struct.unpack_from('<Q',data)[0]==binary.MAGIC
 o=binary.decode(data,8,S['options'],'options');d=binary.decode(data,176,S['diagnostics'],'diagnostics');next_id,n=struct.unpack_from('<QQ',data,376)
 assert len(data)==392+n*80
 particles=[binary.decode(data,392+i*80,S['particle'],'particle')for i in range(n)]
 return {'options':o,'raw_diagnostics':d,'next_id':next_id,'particles':particles,'ABI':[168,200,80]}

with (OUT.parent/'testing-core.lock').open('a+')as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 for label,on in (('off',False),('on',True)):
  build=OUT/('build-'+label)
  args=['/usr/sbin/cmake','-S',str(OUT/'source'),'-B',str(build),'-DCMAKE_BUILD_TYPE=Release','-DMFEM_DIR='+str(MF/'install-mpi/lib/cmake/mfem'),'-DCMAKE_EXPORT_COMPILE_COMMANDS=ON']
  if on:args.append('-DPIC_OBSERVE_EVENTS=ON')
  run('configure-'+label,args)
  run('build-'+label,['/usr/sbin/cmake','--build',build,'--parallel','1','--target','pic','pic_foundation_tests','heating_history_pic_gpu'])
  run('foundation-'+label,[build/'pic_foundation_tests'])
  compile_driver(label,OUT/'source',build/'libpic.a',on)
 compile_driver('reference',REF,RT/'pic-cpu-candidate-20261029/baseline-build/libpic.a',False)
 common=os.environ.copy();common.pop('PIC_NATIVE_EVENT_LOG_DIR',None);common.pop('PIC_EVENT_MAX_ROWS',None)
 for mode in ('finite','flat'):
  refdir=EVID/(mode+'-reference');reftrace=run(mode+'-reference',[EVID/'scenario-reference',refdir,mode],common)
  for label,enable,cap in (('off',True,None),('on-disabled',False,None),('on-enabled',True,None),('on-capped',True,'3')):
   d=EVID/(mode+'-'+label);env=common.copy()
   if enable:env['PIC_NATIVE_EVENT_LOG_DIR']=str(d/'events')
   if cap:env['PIC_EVENT_MAX_ROWS']=cap
   exe=EVID/('scenario-off'if label=='off'else'scenario-on')
   actual=run(mode+'-'+label,[exe,d,mode],env)
   assert actual.read_bytes()==reftrace.read_bytes(),mode+' '+label+' physical trace changed'
   for name in ('checkpoint_mid.bin','checkpoint_final.bin'):assert state(d/name)==state(refdir/name),name+' differs'
   if label=='off':assert not(d/'events').exists()
   if label=='on-disabled':assert not(d/'events').exists()
   results.append({'mode':mode,'variant':label,'trace_bytes':actual.stat().st_size,'byte_identical_physics_trace':True,'all_checkpoint_fields_identical':True,'trace_sha256':sha(actual)})
 # Fresh-process resume deliberately carries no remembered source provenance.
 parent=EVID/'finite-reference/checkpoint_final.bin'
 reftrace=run('resume-reference',[EVID/'scenario-reference',EVID/'resume-reference','resume',parent],common)
 env=common.copy();env['PIC_NATIVE_EVENT_LOG_DIR']=str(EVID/'resume-on/events')
 trace=run('resume-on',[EVID/'scenario-on',EVID/'resume-on','resume',parent],env)
 assert trace.read_bytes()==reftrace.read_bytes();assert state(EVID/'resume-on/checkpoint_final.bin')==state(EVID/'resume-reference/checkpoint_final.bin')
 results.append({'mode':'fresh_process_resume','byte_identical_physics_trace':True,'all_checkpoint_fields_identical':True,'trace_sha256':sha(trace)})
 # I/O setup failure is diagnostic-only and must not alter physics or overwrite.
 d=EVID/'io-failure';(d/'events').mkdir(parents=True);(d/'events/keep.txt').write_text('preserve\n');env=common.copy();env['PIC_NATIVE_EVENT_LOG_DIR']=str(d/'events')
 trace=run('io-failure',[EVID/'scenario-on',d,'finite'],env)
 assert trace.read_bytes()==(EVID/'finite-reference.log').read_bytes() and (d/'events/keep.txt').read_text()=='preserve\n'
 results.append({'mode':'diagnostic_io_failure','byte_identical_physics_trace':True,'existing_directory_preserved':True})
 # Recompute a literal source-removal proof after all edits.
 base=json.loads((OUT/'base-manifest.json').read_text());proof={};patch=''
 for name,digest in base['files'].items():
  current=OUT/'source'/name
  text=current.read_text();original=(REF/name).read_text();stripped=re.sub(r'(?ms)^(?://|#) PIC_NATIVE_EVENTS_BEGIN\n.*?^(?://|#) PIC_NATIVE_EVENTS_END\n','',text)
  proof[name]=stripped==original;assert proof[name],name
  if text!=original:patch+=''.join(difflib.unified_diff(original.splitlines(True),text.splitlines(True),fromfile='a/'+name,tofile='b/'+name))
 h=OUT/'source/src/pic_native_events.hpp';patch+=''.join(difflib.unified_diff([],h.read_text().splitlines(True),fromfile='/dev/null',tofile='b/src/pic_native_events.hpp'))
 (OUT/'native-event-observer.patch').write_text(patch)
 report={'status':'passed','execution':{'cpu':6,'nice':15,'threads':1,'jobs':1,'lease':str(OUT.parent/'testing-core.lock'),'GPU_work':False},'cases':results,'source_removal_all_original_files_byte_identical':all(proof.values()),'source_removal_file_results':proof,'ABI_header_unchanged':(OUT/'source/include/raikou/mfem_gap_pic.h').read_bytes()==(REF/'include/raikou/mfem_gap_pic.h').read_bytes(),'default_build_flag_off':'PIC_OBSERVE_EVENTS:BOOL=OFF'in(OUT/'build-off/CMakeCache.txt').read_text(),'patch_sha256':sha(OUT/'native-event-observer.patch'),'reference_library_sha256':sha(RT/'pic-cpu-candidate-20261029/baseline-build/libpic.a'),'parent_full_1ps_or_10ps_GPU_parity_not_performed':True}
 (EVID/'native-parity.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({'status':'passed','parity_cases':len(results),'source_removal':all(proof.values()),'ABI_unchanged':report['ABI_header_unchanged']},indent=2),flush=True)
