#include "raikou/mfem_gap_pic.h"
#ifdef PIC_OBSERVE_EVENTS
#include "pic_native_events.hpp"
#endif
#include <filesystem>
#include <iostream>
using namespace raikou::mfem_backend;
int main(int argc,char**argv){try{
 if(argc!=3)return 2;
 std::filesystem::path out(argv[1]);std::filesystem::create_directories(out);std::string mode=argv[2];
 GapPicOptions o;o.nx=o.ny=3;GapPic p(o);p.solve_fields();
#ifdef PIC_OBSERVE_EVENTS
 pic_native_events::request(&p,2e-8,0);
#endif
 if(mode=="time"){
  p.advance_empty(.6e-12);GapParticle a;a.position_m={.5*o.width_m,.5*o.gap_m,0};a.weight=1e-8;p.add_particle(a);p.advance(.6e-12);
  p.add_particle(a);p.advance(.6e-12);
 }else{for(int i=0;i<(mode=="step"?4096:4097);++i)p.advance_empty(1e-18);}
 p.save_checkpoint((out/"checkpoint_final.bin").string());
#ifdef PIC_OBSERVE_EVENTS
 pic_native_events::finish(&p);
#endif
 std::cout<<std::hexfloat<<p.diagnostics().time_s<<' '<<p.particles().size()<<'\n';return 0;
}catch(const std::exception&e){std::cerr<<e.what()<<'\n';return 2;}}
