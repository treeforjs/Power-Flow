#include "raikou/mfem_gap_pic.h"
#ifdef PIC_OBSERVE_EVENTS
#include "pic_native_events.hpp"
#endif
#include <filesystem>
#include <fstream>
#include <iostream>
#include <cstring>
using namespace raikou::mfem_backend;
void trace(GapPic& p){
 const auto d=p.diagnostics();for(std::size_t i=0;i<sizeof(d)/sizeof(double);++i){double x;std::memcpy(&x,reinterpret_cast<const char*>(&d)+i*sizeof(double),sizeof(x));std::cout<<x<<' ';}std::cout<<'\n';
 for(const auto& x:p.particles()){std::cout<<x.id<<' '<<x.charge_C<<' '<<x.mass_kg<<' '<<x.weight<<' ';for(double v:x.position_m)std::cout<<v<<' ';for(double v:x.proper_velocity_m_s)std::cout<<v<<' ';}std::cout<<'\n';
 for(int i=0;i<p.potential().Size();++i)std::cout<<p.potential()[i]<<' ';std::cout<<'\n';
 for(double x:{.1,.5,.9})for(double y:{.1,.5,.9}){auto e=p.electric_field(x*p.options().width_m,y*p.options().gap_m);for(double v:e)std::cout<<v<<' ';}std::cout<<'\n';
 for(double x:p.horizontal_transfers_C())std::cout<<x<<' ';std::cout<<'\n';for(double x:p.vertical_transfers_C())std::cout<<x<<' ';std::cout<<'\n';
}
int main(int argc,char** argv){try{
 if(argc<3)throw std::runtime_error("Expected output directory and finite|flat|resume [checkpoint]");
 std::filesystem::path out(argv[1]);std::filesystem::create_directories(out);std::string mode(argv[2]);
 GapPicOptions o;o.nx=o.ny=45;o.width_m=o.gap_m=.009;o.depth_m=.025;
 const bool finite=mode!="flat";o.finite_foils=o.finite_axial_extent=finite;
 if(finite){o.lower_foil={.002,.007,.0018,.002};o.upper_foil={.002,.007,.007,.0072};}
 GapPic p(o);
 if(mode=="resume"){if(argc!=4)throw std::runtime_error("Missing resume checkpoint");p.load_checkpoint(argv[3]);}
 else{
  auto add=[&](PicVector x,PicVector u){GapParticle a;a.position_m=x;a.proper_velocity_m_s=u;a.weight=1e-5;p.add_particle(a);};
  if(finite){
   add({.0045,.002+1e-9,0},{0,-1e6,0});add({.0045,.007-1e-9,0},{0,1e6,0});
   add({.009-1e-9,.0045,0},{1e6,0,0});add({.0045,.0045,o.short_z_m+1e-9},{0,0,-1e6});
   add({.0045,.0045,o.feed_z_m-1e-9},{0,0,1e6});add({.001,.0045,o.short_z_m+1e-9},{0,0,-1e6});
   add({.0045,.002+1.5e-7,0},{0,-1e6,0});add({.0045,.0045,0},{1000,0,0});
  }else{add({.0045,1e-9,0},{0,-1e6,0});add({.0045,.009-1e-9,0},{0,1e6,0});}
  p.solve_fields();
 }
 unsigned long long e_calls=0,b_calls=0,e3_calls=0;
 p.set_external_fields([&](double,double,double){++e_calls;return PicVector{};},[&](double,double,double){++b_calls;return PicVector{};});
 p.set_external_electric_3d([&](double,double,double,double){++e3_calls;return PicVector{};});
#ifdef PIC_OBSERVE_EVENTS
 pic_native_events::request(&p,2e-8,0);
#endif
 if(mode!="resume"){
  GapParticle a;a.position_m={.0045,(finite?.007:.009)-1e-9,0};a.proper_velocity_m_s={0,1e6,0};a.weight=2e-6;p.add_particle(a);
  a.position_m={.0045,(finite?.002:0.)+5.5e-7,0};a.proper_velocity_m_s={0,-1e6,0};a.weight=3e-6;p.add_particle(a);
  for(auto electrode:{GapElectrode::Lower,GapElectrode::Upper}){
   if(finite){for(auto side:{GapSurface::Gap,GapSurface::Back,GapSurface::Left,GapSurface::Right})p.inject_surface_profile(electrode,side,{2000,2500},{1e-8,3e-8},1e-12,4,1234+static_cast<int>(electrode)*10+static_cast<int>(side));}
   else p.inject_surface_profile(electrode,GapSurface::Gap,{2000,2500},{1e-8,3e-8},1e-12,4,1234+static_cast<int>(electrode));
  }
 }
 std::cout<<std::hexfloat<<"ABI "<<sizeof(GapPicOptions)<<' '<<sizeof(GapPicDiagnostics)<<' '<<sizeof(GapParticle)<<' '<<sizeof(GapPic)<<'\n';
 for(int step=0;step<2;++step){p.advance(2e-13);trace(p);if(step==0){p.save_checkpoint((out/"checkpoint_mid.bin").string());if(mode!="resume")p.inject_thermal_electrons(GapElectrode::Upper,2200,2e-8,1e-12,2,998);}}
 p.save_checkpoint((out/"checkpoint_final.bin").string());std::cout<<"callbacks "<<e_calls<<' '<<b_calls<<' '<<e3_calls<<'\n';
#ifdef PIC_OBSERVE_EVENTS
 pic_native_events::finish(&p);
#endif
 return 0;
}catch(const std::exception& e){std::cerr<<e.what()<<'\n';return 2;}}
