#pragma once
// Read-only, bounded observer. No serialized/native class layouts are extended.
#include "raikou/mfem_gap_pic.h"
#include <algorithm>
#include <array>
#include <cctype>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <memory>
#include <string>
#include <unordered_map>
namespace pic_native_events {
using namespace raikou::mfem_backend;
inline constexpr std::size_t max_steps=4096;
inline constexpr double max_window_s=1e-12;
inline constexpr const char* names[]={"thermal_birth","authored_birth","lower_wall","upper_wall","short_absorption","feed_escape","short_plane_escape","transverse_escape"};
struct Profile { bool known=false;std::uint64_t event=0,seed=0;std::size_t patch=0,patches=0;double T=0,J=0; };
struct Birth { bool known=false,thermal=false;std::uint64_t seq=0,seed=0;int electrode=-1,surface=-1,count=0;double T=0,J=0,dt=0,lo=0,hi=0,length=0;Profile profile; };
struct Sum { std::uint64_t macros=0;double weight=0,charge=0,energy=0; };
struct Snapshot { GapPicDiagnostics ledger;std::uint64_t next=0,macros=0;double weight=0,charge=0; };
inline Snapshot snapshot(const GapPicDiagnostics& d,const std::vector<GapParticle>& p,std::uint64_t next){Snapshot s;s.ledger=d;s.next=next;s.macros=p.size();for(const auto& x:p){s.weight+=x.weight;s.charge+=x.charge_C*x.weight;}return s;}
inline std::string quoted(const std::string& x){std::string out="\"";for(unsigned char c:x){if(c=='"'||c=='\\'){out+='\\';out+=c;}else if(c=='\n')out+="\\n";else if(c=='\r')out+="\\r";else if(c=='\t')out+="\\t";else if(c<32)out+='?';else out+=c;}return out+'"';}
inline void ledger_json(std::ostream& f,const GapPicDiagnostics& d){f<<'{';bool first=true;
#define PIC_EVENT_LEDGER(x) if(!first)f<<',';first=false;f<<"\"" #x "\":"<<d.x;
 PIC_EVENT_LEDGER(time_s) PIC_EVENT_LEDGER(particle_charge_C) PIC_EVENT_LEDGER(deposited_charge_C)
 PIC_EVENT_LEDGER(lower_field_charge_C) PIC_EVENT_LEDGER(upper_field_charge_C) PIC_EVENT_LEDGER(gauss_defect_C)
 PIC_EVENT_LEDGER(particle_charge_defect_C) PIC_EVENT_LEDGER(field_energy_J) PIC_EVENT_LEDGER(particle_kinetic_energy_J)
 PIC_EVENT_LEDGER(lower_absorbed_charge_C) PIC_EVENT_LEDGER(upper_absorbed_charge_C)
 PIC_EVENT_LEDGER(lower_absorbed_energy_J) PIC_EVENT_LEDGER(upper_absorbed_energy_J)
 PIC_EVENT_LEDGER(lower_injected_charge_C) PIC_EVENT_LEDGER(upper_injected_charge_C) PIC_EVENT_LEDGER(injected_energy_J)
 PIC_EVENT_LEDGER(authored_charge_C) PIC_EVENT_LEDGER(authored_kinetic_energy_J) PIC_EVENT_LEDGER(maximum_nodal_continuity_defect_C)
 PIC_EVENT_LEDGER(escaped_charge_C) PIC_EVENT_LEDGER(escaped_kinetic_energy_J) PIC_EVENT_LEDGER(short_absorbed_charge_C)
 PIC_EVENT_LEDGER(short_absorbed_energy_J) PIC_EVENT_LEDGER(axial_escaped_charge_C) PIC_EVENT_LEDGER(poisson_residual_C_per_m)
#undef PIC_EVENT_LEDGER
 f<<'}';}
inline void snapshot_json(std::ostream& f,const Snapshot& s){f<<"{\"macro_particles\":"<<s.macros<<",\"next_id\":"<<s.next<<",\"weight\":"<<s.weight<<",\"charge_C\":"<<s.charge<<",\"ledger\":";ledger_json(f,s.ledger);f<<'}';}
struct State {
 const void* owner;double origin=0,start=0,deadline=0,base_clock=0,offset=0;std::uint64_t base_step=0,steps=0,seq=0,rows=0,dropped=0,profile_seq=0;
 bool initialized=false,end_valid=false,closed=false,phase_active=false,error=false,step_cap=false,finished=false;int half=0;
 std::size_t row_cap=4096;std::filesystem::path directory;std::ofstream log;GapPicOptions options;Snapshot initial,last;Profile profile;
 std::array<Sum,8> sums{};std::array<double,2> thermal_native_charge{},thermal_native_energy{};double authored_native_charge=0,authored_native_energy=0;
 std::unordered_map<std::uint64_t,Birth> births;
 State(const void* p,double t,std::uint64_t step,const char* dir):owner(p),origin(t),base_step(step),directory(dir){
  const char* cap=std::getenv("PIC_EVENT_MAX_ROWS");if(cap){std::string text(cap);if(text.empty()||text.size()>6||!std::all_of(text.begin(),text.end(),[](unsigned char c){return std::isdigit(c);}))throw std::runtime_error("invalid PIC_EVENT_MAX_ROWS");row_cap=std::stoul(text);if(row_cap<1||row_cap>65536)throw std::runtime_error("event row budget outside1..65536");}
  if(!std::filesystem::create_directory(directory))throw std::runtime_error("event directory must be new");
  log.exceptions(std::ios::failbit|std::ios::badbit);log.open(directory/"events.csv");log<<std::setprecision(17);
  log<<"event_seq,kind,time_global_s,time_local_s,advance_step,half,flight_s,particle_id,weight,q_C,mass_kg,x_m,y_m,z_m,ux_m_s,uy_m_s,uz_m_s,native_weighted_K_J,normal_known,nx,ny,nz,normal_convention,source_known,birth_event_seq,source_electrode,source_surface,profile_event_seq,profile_seed,patch_index,patch_count,profile_T_K,profile_J_A_m2,kernel_seed,kernel_T_K,kernel_J_A_m2,kernel_dt_s,kernel_count,start_fraction,end_fraction,patch_length_m\n";
 }
 bool within(double clock)const{return initialized&&!closed&&clock<deadline&&steps<max_steps;}
 void ensure(const GapPicOptions& o,const GapPicDiagnostics& d,const std::vector<GapParticle>& p,std::uint64_t next){if(initialized)return;options=o;initial=last=snapshot(d,p,next);start=d.time_s;deadline=start+max_window_s;initialized=end_valid=true;}
 std::uint64_t row(int kind,double clock,double flight,const GapParticle& p,const Birth& source,int axis,int sign,bool native_energy,double energy){
  const auto event=++seq;auto& sum=sums[kind];++sum.macros;sum.weight+=p.weight;sum.charge+=p.charge_C*p.weight;if(native_energy)sum.energy+=energy;
  if(rows>=row_cap){++dropped;return 0;}
  const bool normal=axis>=0;log<<event<<','<<names[kind]<<','<<origin+clock<<','<<clock<<','<<base_step+steps+(half>0?1:0)<<','<<half<<','<<flight<<','<<p.id<<','<<p.weight<<','<<p.charge_C<<','<<p.mass_kg;
  for(double x:p.position_m)log<<','<<x;for(double x:p.proper_velocity_m_s)log<<','<<x;
  log<<',';if(native_energy)log<<energy;log<<','<<normal;for(int i=0;i<3;++i)log<<','<<(normal&&i==axis?sign:0);
  log<<','<<(normal?(kind<2?"source_outward":"vacuum_outward"):"unknown")<<','<<source.known<<','<<(kind<2?event:source.seq)<<','<<source.electrode<<','<<source.surface<<','<<source.profile.event<<',';
  if(source.profile.known)log<<source.profile.seed;log<<',';if(source.profile.known)log<<source.profile.patch;log<<',';if(source.profile.known)log<<source.profile.patches;log<<',';if(source.profile.known)log<<source.profile.T;log<<',';if(source.profile.known)log<<source.profile.J;
  log<<',';if(source.thermal)log<<source.seed;log<<',';if(source.thermal)log<<source.T;log<<',';if(source.thermal)log<<source.J;log<<',';if(source.thermal)log<<source.dt;log<<',';if(source.thermal)log<<source.count;log<<',';if(source.thermal)log<<source.lo;log<<',';if(source.thermal)log<<source.hi;log<<',';if(source.thermal)log<<source.length;log<<'\n';++rows;return event;
 }
 void thermal(const std::vector<GapParticle>& incoming,double charge,double energy,double clock,int electrode,int surface,double T,double J,double dt,int count,std::uint64_t seed,double lo,double hi,double length,int axis,int sign){
  if(!within(clock))return;thermal_native_charge[electrode]+=charge;thermal_native_energy[electrode]+=energy;half=0;
  for(const auto& p:incoming){Birth b;b.known=b.thermal=true;b.electrode=electrode;b.surface=surface;b.T=T;b.J=J;b.dt=dt;b.count=count;b.seed=seed;b.lo=lo;b.hi=hi;b.length=length;b.profile=profile;
   // Birth energy is derived offline; retain the existing batch energy above.
   b.seq=row(0,clock,0,p,b,axis,sign,false,0);if(b.seq&&births.size()<row_cap)births.emplace(p.id,b);
  }
 }
 void authored(const GapParticle& p,double charge,double clock,const GapPicDiagnostics& d){if(!within(clock))return;authored_native_charge+=charge;authored_native_energy=d.authored_kinetic_energy_J-initial.ledger.authored_kinetic_energy_J;half=0;Birth b;b.known=true;b.seq=row(1,clock,0,p,b,-1,0,false,0);if(b.seq&&births.size()<row_cap)births.emplace(p.id,b);}
 void phase(double clock,double phase_offset,int h){base_clock=clock;offset=phase_offset;half=h;phase_active=within(clock);}
 void sink(const GapParticle& p,int hit,int axial_end,double flight,double energy){
  if(!phase_active)return;int kind=7,axis=-1,sign=0;
  if(hit==0){kind=2;if(!options.finite_foils){axis=1;sign=-1;}}
  else if(hit==1){kind=3;if(!options.finite_foils){axis=1;sign=1;}}
  else if(hit==3){kind=4;axis=2;sign=-1;}
  else if(hit==4){kind=axial_end==1?5:6;if(axial_end>=0){axis=2;sign=axial_end==1?1:-1;}}
  Birth b;auto it=births.find(p.id);if(it!=births.end())b=it->second;
  row(kind,base_clock+offset+flight,flight,p,b,axis,sign,true,energy);if(it!=births.end())births.erase(it);
 }
 void accepted(const GapPicDiagnostics& d,const std::vector<GapParticle>& p,std::uint64_t next){if(!phase_active)return;++steps;last=snapshot(d,p,next);end_valid=true;half=0;if(d.time_s>=deadline)closed=true;if(steps>=max_steps&&d.time_s<deadline){step_cap=true;closed=true;}phase_active=false;}
 void cursor(const std::string& path,const GapPicDiagnostics& d,const std::vector<GapParticle>& p,std::uint64_t next){
  log.flush();const auto bytes=static_cast<std::uint64_t>(log.tellp());std::ofstream f(directory/"cursor.json.tmp");f.exceptions(std::ios::failbit|std::ios::badbit);f<<std::setprecision(17);
  f<<"{\"schema\":1,\"checkpoint\":"<<quoted(std::filesystem::absolute(path).string())<<",\"checkpoint_bytes\":"<<std::filesystem::file_size(path)<<",\"checkpoint_clock_s\":"<<d.time_s<<",\"checkpoint_next_id\":"<<next<<",\"checkpoint_macros\":"<<p.size()<<",\"written_rows\":"<<rows<<",\"last_attempted_event_seq\":"<<seq<<",\"csv_prefix_bytes\":"<<bytes<<",\"dropped_rows\":"<<dropped<<",\"checkpoint_matches_observed_endpoint\":"<<((end_valid&&d.time_s==last.ledger.time_s&&next==last.next&&p.size()==last.macros)?"true":"false")<<",\"crash_durable\":false,\"resume_policy\":\"new segment; inherited source provenance unknown\"}\n";
  f.close();std::filesystem::rename(directory/"cursor.json.tmp",directory/"cursor.json");
 }
 void finish(){
  if(finished)return;log.flush();log.close();std::ofstream f(directory/"summary.json.tmp");f.exceptions(std::ios::failbit|std::ios::badbit);f<<std::setprecision(17);
  const bool complete=initialized&&end_valid&&steps>0&&!error&&!dropped&&!step_cap;
  f<<"{\"schema\":1,\"complete\":"<<(complete?"true":"false")<<",\"io_error\":"<<(error?"true":"false")<<",\"step_cap_hit\":"<<(step_cap?"true":"false")<<",\"row_cap\":"<<row_cap<<",\"max_steps\":"<<max_steps<<",\"max_window_s\":"<<max_window_s<<",\"global_origin_s\":"<<origin<<",\"base_step\":"<<base_step<<",\"accepted_steps\":"<<steps<<",\"actual_exposure_s\":"<<(last.ledger.time_s-start)<<",\"initial\":";snapshot_json(f,initial);f<<",\"final\":";snapshot_json(f,last);
  f<<",\"attempted_events\":"<<seq<<",\"written_rows\":"<<rows<<",\"dropped_rows\":"<<dropped<<",\"thermal_native_charge_C\":["<<thermal_native_charge[0]<<','<<thermal_native_charge[1]<<"],\"thermal_native_energy_J\":["<<thermal_native_energy[0]<<','<<thermal_native_energy[1]<<"],\"authored_native_charge_C\":"<<authored_native_charge<<",\"authored_native_energy_J\":"<<authored_native_energy<<",\"surfaces\":[";
  const double lw=options.lower_foil.right_m-options.lower_foil.left_m,lh=options.lower_foil.top_m-options.lower_foil.bottom_m;
  const double uw=options.upper_foil.right_m-options.upper_foil.left_m,uh=options.upper_foil.top_m-options.upper_foil.bottom_m;
  const double plane=options.width_m*options.gap_m-(options.finite_foils?lw*lh+uw*uh:0);
  const double bridge=options.finite_axial_extent?lw*(options.upper_foil.bottom_m-options.lower_foil.top_m):0;
  for(int kind=0;kind<8;++kind){if(kind)f<<',';double area=0;
   if(kind==2)area=options.finite_foils?2*(lw+lh)*options.depth_m:options.width_m*options.depth_m;
   if(kind==3)area=options.finite_foils?2*(uw+uh)*options.depth_m:options.width_m*options.depth_m;
   if(kind==4)area=bridge;if(kind==5)area=options.finite_axial_extent?plane:0;
   if(kind==6)area=options.finite_axial_extent?plane-bridge:0;if(kind==7)area=options.finite_foils?2*(options.width_m+options.gap_m)*options.depth_m:0;
   const auto& x=sums[kind];f<<"{\"kind\":"<<quoted(names[kind])<<",\"macros\":"<<x.macros<<",\"weight\":"<<x.weight<<",\"charge_C\":"<<x.charge<<",\"native_sink_energy_J\":"<<x.energy<<",\"aggregate_area_m2\":"<<area<<'}';
  }
  f<<"],\"inherited_source_provenance\":\"unknown; no synthetic birth records\",\"foil_and_transverse_sink_normals\":\"unknown in current native hit code\",\"window_definition\":\"all events in accepted steps beginning before the1ps cap; exposure uses actual accepted endpoints\",\"chemical_model_added\":false}\n";
  f.close();std::filesystem::rename(directory/"summary.json.tmp",directory/"summary.json");finished=true;
 }
};
inline std::unique_ptr<State> observer;
template<class F>inline void apply(const void* owner,F&& fn)noexcept{if(!observer||observer->owner!=owner||observer->finished)return;try{fn(*observer);}catch(...){observer->error=true;}}
inline void request(const void* owner,double origin,std::uint64_t step)noexcept{const char* dir=std::getenv("PIC_NATIVE_EVENT_LOG_DIR");if(!dir||!*dir)return;try{if(observer&&!observer->finished)throw std::runtime_error("one observer at a time");observer=std::make_unique<State>(owner,origin,step,dir);}catch(const std::exception& e){std::cerr<<"Event observation unavailable: "<<e.what()<<'\n';observer.reset();}}
inline void ensure(const void* owner,const GapPicOptions& o,const GapPicDiagnostics& d,const std::vector<GapParticle>& p,std::uint64_t next)noexcept{apply(owner,[&](State& s){s.ensure(o,d,p,next);});}
inline void profile_patch(const void* owner,std::uint64_t seed,std::size_t i,std::size_t n,int ordinal,double T,double J)noexcept{apply(owner,[&](State& s){if(ordinal==0)++s.profile_seq;s.profile={true,s.profile_seq,seed,i,n,T,J};});}
inline void profile_end(const void* owner)noexcept{apply(owner,[](State& s){s.profile=Profile{};});}
struct ProfileScope {const void* owner;~ProfileScope()noexcept{profile_end(owner);}};
inline void authored(const void* owner,const GapParticle& p,double q,double clock,const GapPicDiagnostics& d)noexcept{apply(owner,[&](State& s){s.authored(p,q,clock,d);});}
inline void thermal(const void* owner,const std::vector<GapParticle>& p,double q,double e,double clock,int electrode,int surface,double T,double J,double dt,int count,std::uint64_t seed,double lo,double hi,double length,int axis,int sign)noexcept{apply(owner,[&](State& s){s.thermal(p,q,e,clock,electrode,surface,T,J,dt,count,seed,lo,hi,length,axis,sign);});}
inline void phase(const void* owner,double clock,double offset,int half)noexcept{apply(owner,[&](State& s){s.phase(clock,offset,half);});}
inline void sink(const void* owner,const GapParticle& p,int hit,int axial_end,double flight,double energy)noexcept{apply(owner,[&](State& s){s.sink(p,hit,axial_end,flight,energy);});}
inline void accepted(const void* owner,const GapPicDiagnostics& d,const std::vector<GapParticle>& p,std::uint64_t next)noexcept{apply(owner,[&](State& s){s.accepted(d,p,next);});}
inline void cursor(const void* owner,const std::string& path,const GapPicOptions& o,const GapPicDiagnostics& d,const std::vector<GapParticle>& p,std::uint64_t next)noexcept{apply(owner,[&](State& s){s.ensure(o,d,p,next);s.cursor(path,d,p,next);});}
inline void finish(const void* owner)noexcept{apply(owner,[](State& s){s.finish();});}
} // namespace pic_native_events
