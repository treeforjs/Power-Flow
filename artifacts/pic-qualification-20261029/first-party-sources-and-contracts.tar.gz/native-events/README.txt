Bounded native birth and terminal-crossing observer — isolated prototype

Prepared for parent-controlled qualification. No shared source was edited and no
GPU work, process signalling, production restart, or deployment was performed.
All local builds/checks used CPU 6, nice 15, one job/thread, the testing-core.lock
lease, and no visible CUDA devices. GPU dependencies were linked; GPU code was
not executed. The heating_history_pic_gpu executable was compiled only.

PREFIX
/home/treefor/Documents/Codex/2026-10-28/we/outputs/pic-profile/native-event-log-prototype

BASE
/home/treefor/projects/runtimes/mfem-gpu-pic-20261029/source
This is the frozen GPU PIC source, not the subsequently updated main checkout.
The patch is suitable for review/porting onto the current candidate. It does not
include or replace the already integrated Q1 cache work.

PRODUCTION FOOTPRINT
native-event-observer.patch changes only CMakeLists.txt, src/mfem_gap_pic.cpp,
examples/mfem_heating_history_pic.cpp and adds src/pic_native_events.hpp. Native
GapParticle, GapPic, options/diagnostics and checkpoint layouts are unchanged.
Deleting the added header and stripping PIC_NATIVE_EVENTS_BEGIN/END blocks
recovers all ten original files byte for byte; see source-removal-proof.json.
The unmodified frozen base hashes are retained in base-manifest.json.

ENABLEMENT
Build option PIC_OBSERVE_EVENTS defaults OFF. The ON build additionally requires
PIC_NATIVE_EVENT_LOG_DIR set to a NEW directory whose parent already exists.
PIC_EVENT_MAX_ROWS is optional: default 4096, valid 1..65536. For example, the
parent may set these in its existing bounded replay launcher:
  PIC_NATIVE_EVENT_LOG_DIR=/absolute/path/to/new/replay/events
  PIC_EVENT_MAX_ROWS=65536
The isolated ON executable is:
  build-on/heating_history_pic_gpu
Do not run that executable directly against the live production directory.
Use a copied checkpoint/reservoir/input set and the existing replay launcher.
One MPI rank and one selected GapPic instance per process are the supported
prototype scope. The auxiliary unit-bias GapPic is not selected for observation.
A missing runtime opt-in causes no log. An existing directory or diagnostic I/O
failure cannot abort or change physics; existing output is preserved. Consumers
must reject missing, malformed or incomplete evidence.

EVENTS AND TIME
Committed thermal/authored births and lower/upper electrode, conducting short,
feed escape, short-plane escape outside the bridge, and transverse terminal
escape are logged. No arbitrary detector plane or reflected transit is logged.
Sink hooks use the endpoint, accepted native flight, hit decision and weighted
kinetic-energy operand already computed by drift(). No field gather/callback,
RNG draw, source seed, emission law, particle ordering, timestep, solver or ledger
operation is added or changed. Observer-only endpoint weight/charge scans occur
while armed. Runtime/CPU overhead with observation enabled is not qualified.

Raw rows retain position, proper velocity, mass, elementary charge, physical
weight, ID, local/global time, accepted step and half-drift. Terminal event time
is the old ledger clock + half-drift offset + the native accepted flight time.
Second-half arrival energy uses the post-push proper velocity already in p.
Birth time is the actual creation clock. It is never distributed backward over
a reservoir interval. CSV order is commit/particle iteration order and is not
a chronological sort. Global time = main's heating start origin + local PIC time.

Bounds are fixed at 1 ps of accepted-step starts and 4096 accepted steps; rows
have the separate runtime cap. The entire last accepted step is included, even
if its endpoint exceeds 1 ps. Exposure is the actual observed endpoint minus
start, never an assumed 1 ps. Logging stops without changing native stepping.
A row/step cap or I/O error makes the diagnostic incomplete and ineligible for
full flux. Aggregate counts continue after the row budget, but missing rows are
never reconstructed into spectra. The provenance map is bounded by the row cap.
A longer replay's final checkpoint differs from the observed endpoint and is
rejected: parent should use the intended approximately 1 ps replay segment and
its matching endpoint, not a later checkpoint.

SOURCE PROVENANCE
Thermal births retain electrode/surface, effective kernel seed, temperature,
current density, supply interval, count, fractional patch bounds and length.
Profile calls additionally record the actual existing patch draw, profile seed,
patch index/count and that patch's T/J. Effective kernel J differs from the
profile patch J under native importance sampling; both are labelled separately.
The observer does not reproduce or advance the RNG. Direct thermal calls clear
profile context. Authored birth creation is known but its emitter face is not.
Known births are linked to later sinks by ID within this segment. Initial or
resumed particles have source_known=0, birth_event_seq=0 and emitter=-1/-1;
no synthetic inherited birth is generated. Charge/mass are raw particle data,
not a chemical-species or H2O-fragment identification.

NORMALS AND AREAS
Thermal source normals come from the native creation normal (conductor toward
vacuum). Flat y wall and accepted axial sink normals point out of the vacuum.
Finite-foil hit code retains electrode identity but discards which slab face
won and its normal; transverse escape similarly lacks the selected outer face.
Those rows use normal_known=0, normal=(0,0,0), convention=unknown. Their energy
flux is available; a complete incidence spectrum is unavailable. No normal or
azimuth is guessed from coordinates. Raw momentum direction alone is not a
surface incidence angle.

Sink areas are whole declared extruded surfaces: foil perimeter times depth,
flat wall width times depth, outer perimeter times depth, axial vacuum plane,
conducting bridge, and axial vacuum plane minus bridge. These give aggregate
surface averages, not local spatial flux maps. Per-source-face creation spectra
use the full declared source face area. The analyzer independently reconstructs
all these areas from checkpoint geometry. For the finite fixture: lower/upper
2.6 cm^2 each, short .25 cm^2, feed .79 cm^2, short-plane escape .54 cm^2,
outer transverse 9 cm^2. Thermal face currents represent creation in this window;
they must not be interpreted as a backdated continuous reservoir emission rate.

INDEPENDENT REDUCTION
analyze_events.py reads the quiescent events.csv, summary.json, cursor.json and
native checkpoint with the frozen ABI decoder. It verifies all 25 final ledger
fields against the checkpoint; macro/next-ID/survivor, weight and charge balance;
source patch weights and native batch energies; every sink charge/energy ledger;
axial escape as a subset of total escape; source links; and independent areas.
Relativistic K=m*u^2/(sqrt(1+u^2/c^2)+1) and incidence mu=(u dot n)/|u| are derived
offline. No observer energy calculation perturbs a native source RNG or sum.

For complete evidence it reports signed current sum(q*w)/exposure, particle flux
sum(w)/(area_cm2*exposure), energy flux sum(K*w)/(area_cm2*exposure), weighted energy,
known-mu and joint energy/mu densities, plus four time-bin currents/powers/fluxes.
Unknown angular weight is explicit. Integrating histogram widths recovers the
corresponding weights; angles from mu bins are in radians. Angular spectra
cover only known-normal events. Fixed energy bins cover 0..1 MeV; any overflow
rejects the reduction rather than clipping a tail. This is a prototype support
limit, not a physical energy ceiling. Authored births without face area have
totals but no fabricated surface flux. No collision/rate/yield is inferred.

RESTART AND CURSOR CONTRACT
Native save_checkpoint writes its ordinary checkpoint first. Only after its
successful rename does the observer flush CSV and atomically rename cursor.json.
The cursor records checkpoint path/size/clock/next ID/count, CSV byte prefix,
last attempted sequence, written/dropped rows and endpoint match. It does not
alter any serialized particle structure. Cursor flush/rename is logical commit,
not fsync/crash durability, and the native cursor carries no cryptographic seal.
The analyzer returns SHA-256 hashes for the checkpoint, exact CSV prefix, cursor
and summary; retain that report with the immutable replay receipt and input/
executable hashes. This hashes the supplied evidence; it is not authentication
or permission to analyze concurrently changing files.

For real heating replays, also use the established full checkpoint comparator
to bind checkpoint filename/step/time to restart.meta, reservoirs, histories and
final CSVs. This event analyzer does not replace that full-state proof. A cursor
written before a crash during reservoir metadata commit is insufficient by
itself. Missing footer/cursor, CSV tail or truncation, inconsistent checkpoint,
cap or I/O failure is ineligible; nothing is silently trimmed or repaired.
Resume in a NEW log directory/segment. Inherited source provenance becomes
unknown even when the earlier segment is available. Automatic append, dedup,
provenance recovery and crash-safe coordinated log/checkpoint restart are not
implemented. Use coherent endpoint segments; do not splice unknown origins.

CPU EVIDENCE
The OFF and ON builds and both serial-CG foundation suites pass. Ten native
variants compare reference, compiled-OFF with runtime opt-in, compiled-ON without
runtime opt-in, compiled-ON enabled, row-capped, fresh-process restart and an I/O
setup failure. Every physical stdout trace is byte-identical, including all
particle records, sampled fields/potential, transfer ledgers and callback counts.
Every semantic checkpoint field is identical (undefined options padding ignored).
The finite fixture logs 44 events (36 births/8 sinks), flat logs 15 (12/3), and
resume logs 1 terminal crossing of a prior-segment birth with unknown provenance.
Independent checks: 166 finite, 99 flat, 91 resume; 27 corrupted evidence cases
are rejected, and CLI statuses 0/1/2 are tested. Row-capped evidence is ineligible.
Additional native time/step-bound scenarios compare physical state to reference,
exercise accepted-step overshoot of 1 ps, a 4096-step cap, and reject a later
checkpoint. All used CPU 6/nice 15/one thread under the shared CPU lease.
See evidence/native-parity.json, evidence/independent-event-checks.json and
evidence/bounds-checks.json; raw logs and exact commands are retained.

RUN THE INDEPENDENT EVIDENCE TESTS (takes the lease internally)
  taskset -c 6 nice -n 15 env OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 CUDA_VISIBLE_DEVICES= python3 test_event_evidence.py
  taskset -c 6 nice -n 15 env OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 CUDA_VISIBLE_DEVICES= python3 check_bounds.py
An individual reduction uses the same prefix/env and:
  python3 analyze_events.py /absolute/path/to/events --output /absolute/path/to/report.json
build_and_check.py is the recorded clean-prefix build/native parity harness;
its existing run directories must be preserved or a fresh isolated prefix used.
It intentionally refuses to overwrite an existing event directory.

PARENT QUALIFICATION STILL REQUIRED
The approximately 1 ps full production-like GPU comparison with observation on
and off belongs to the parent. No GPU observation replay was run here. Existing
parent CPU cache and actual-midpoint capture passes qualify their own candidates;
they do not qualify this new observer executable. Use the full saved-state
comparator, including reservoirs/metadata/history/fields, before accepting event
flux as observational on the real replay. No duplicate full 10 ps cache run was
performed. Main integration, enabled-overhead measurements, spatial face maps,
long observations and crash-safe continuation remain outside this prototype.

BENCHMARK OBSERVABLES AND CHEMISTRY LIMIT
The supplied CHICAGO review is the mapping source:
/home/treefor/Documents/Codex/2026-10-28/we/outputs/chicago-pic-review/review.txt
Its finite-electrode cases motivate matched collisionless orbit/E x B tests,
electrode/loss-current waveforms, arrival energy/incidence and plasma extent.
The present geometry/model still needs matched inputs and convergence checks.
ICCD light is not electron density or an EEDF. SHOP-DI cm^-2 is a line integral,
not a local cm^-3 pixel; miniXRD inversion is not a measured full EEDF. Agreement
of a prescribed-B, height-averaged Poisson model with selected observables is
not validation of all full electromagnetic CHICAGO dynamics.
No H2O instant-ionization closure, fragmentation network, collisions or reaction
cross sections were added. In particular the reviewed water -> 3e + 2H+ + O+
closure is not a validated finite-rate H2O model. This observer supplies measured
native creation/loss operands for future audits; it does not supply chemistry.
The review's updated H2O reference is Song et al. (2021), JPCRD 50, 023103,
DOI 10.1063/5.0035315; consult channel-resolved data before any future rate work.
