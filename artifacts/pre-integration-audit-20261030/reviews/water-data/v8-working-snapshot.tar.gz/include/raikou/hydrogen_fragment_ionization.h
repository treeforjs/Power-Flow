#pragma once
// Separate ground-H continuation data; cannot masquerade as an H2O target.
#include "raikou/h2o_neutral_dissociation.h"

namespace raikou::kinetics {
class HydrogenFragmentIonizationData {
    Json data_;
public:
    explicit HydrogenFragmentIonizationData(Json data):data_(std::move(data)) {
        using h2o_dissociation_detail::require;
        require(data_.at("schema")=="raikou-ground-H-fragment-ionization-v1"&&data_.at("phase")=="gas"&&data_.at("target_state")=="H_1s","Ground atomic H gas dataset required");
        require(data_.at("B_eV")==13.6057&&data_.at("U_eV")==13.6057&&data_.at("N")==1&&data_.at("Q")==.5668,"Frozen source1s constants changed");
        require(data_.at("bohr_radius_m")==5.2918e-11&&data_.at("rydberg_eV")==13.6057,"Frozen BEB constants changed");
        require(data_.at("support_eV")==Json::array({14,10000})&&data_.at("known_zero_up_to_eV")==13.59844,"Ground-H support changed");
        require(data_.at("chemical_reference_gain_eV")==13.59844&&!data_.at("full_fragment_mechanism_ready").get<bool>(),"H/Hplus catalog or completeness changed");
        require(data_.at("products")==Json({{"e_g",2},{"Hp",1}})&&data_.at("electron_net_gain")==1,"Ground-H product inventory changed");
        require(data_.at("model")=="H1s_NIST_BEB_equal_pair_CM_v1"&&data_.at("parent_debit")==Json({{"H_1s",1}})&&!data_.at("GPU_execution").get<bool>(),"Ground-H model/parent contract changed");
    }
    static HydrogenFragmentIonizationData read(const std::string& path) {
        std::ifstream input(path);h2o_dissociation_detail::require(bool(input),"Cannot read ground-H data");Json data;input>>data;input>>std::ws;
        h2o_dissociation_detail::require(input.eof(),"Trailing ground-H data");return HydrogenFragmentIonizationData(std::move(data));
    }
    [[nodiscard]] const Json& metadata() const {return data_;}
    [[nodiscard]] double ionization_cross_section_m2(double energy_eV) const {
        using h2o_dissociation_detail::require;require(std::isfinite(energy_eV)&&energy_eV>=0,"Invalid H-target incident energy");
        if (energy_eV<=13.59844)return 0;
        if (energy_eV<14||energy_eV>10000)throw CollisionCoverageError("Ground-H ionization: unsupported positive energy; no threshold-gap or tail completion");
        constexpr double B=13.6057,U=13.6057,N=1,Q=.5668,a=5.2918e-11,R=13.6057;
        const double t=energy_eV/B,u=U/B,l=std::log(t),S=4*std::numbers::pi*a*a*N*(R/B)*(R/B);
        return S/(t+u+1)*(Q*l/2*(1-1/(t*t))+(2-Q)*(1-1/t-l/(t+1)));
    }
    [[nodiscard]] CollisionCoverage coverage(const std::vector<CollisionEnergyWeight>& population) const {
        using h2o_dissociation_detail::require;CollisionCoverage out;out.observable="ground_H_ionization_model";double numerator=0;
        for (const auto& s:population) {
            require(std::isfinite(s.energy_eV)&&s.energy_eV>=0&&std::isfinite(s.physical_electrons)&&s.physical_electrons>=0,"Invalid physical electron population");
            if (s.physical_electrons==0)continue;
            out.total_weight+=s.physical_electrons;
            try {const double sigma=ionization_cross_section_m2(s.energy_eV),q=s.energy_eV/510998.95069;
                numerator+=s.physical_electrons*sigma*299792458.*std::sqrt(q*(q+2))/(q+1);out.covered_weight+=s.physical_electrons;
            } catch (const CollisionCoverageError&) {out.uncovered_weight+=s.physical_electrons;}
        }
        require(out.total_weight>0&&std::isfinite(out.total_weight)&&std::isfinite(numerator),"Empty/overflowing electron population");
        out.known_support_coefficient_m3_s=numerator/out.total_weight;out.complete=out.uncovered_weight==0;return out;
    }
    [[nodiscard]] double strict_rate_m3_s(const std::vector<CollisionEnergyWeight>& population) const {
        const auto result=coverage(population);if (!result.complete)throw CollisionCoverageError("Ground-H rate has uncovered electron weight; no renormalization");
        return result.known_support_coefficient_m3_s;
    }
};

[[nodiscard]] inline ConditionalParentProducts conditional_H1s_ionization_products(
    const HydrogenFragmentIonizationData& data,const std::string& explicitly_selected_model,
    double incident_target_rest_eV,double represented_weight,double H_mass_kg,
    const CollisionMomentum& beam_unit,const CollisionMomentum& isotropic_CM_pair_unit) {
    using namespace h2o_dissociation_detail;constexpr double e=1.602176634e-19,me=9.1093837139e-31,I=13.59844;
    require(explicitly_selected_model=="H1s_NIST_BEB_equal_pair_CM_v1","Explicit ground-H ionization kinematic model required");
    const double sigma=data.ionization_cross_section_m2(incident_target_rest_eV);require(sigma>0,"No admitted ground-H ionization event");
    require(std::isfinite(represented_weight)&&represented_weight>0&&std::isfinite(H_mass_kg)&&H_mass_kg>1800*me&&H_mass_kg<1900*me,"Invalid ground-protium cohort/mass");
    unit(beam_unit);unit(isotropic_CM_pair_unit);
    const double K=incident_target_rest_eV*e,D=(H_mass_kg+me)*c*c,W=std::sqrt(D*D+2*H_mass_kg*c*c*K);
    const double Q=2*H_mass_kg*c*c*K/(W+D)-I*e;require(Q>0,"Insufficient invariant H-ionization energy");
    const double ion_mass=H_mass_kg-me+I*e/(c*c),each=Q/2,p=std::sqrt(each*(each+2*me*c*c))/c,p0=std::sqrt(K*(K+2*me*c*c))/c;
    CollisionMomentum a{},b{},incoming{};for (int i=0;i<3;++i) {a[i]=p*isotropic_CM_pair_unit[i];b[i]=-a[i];incoming[i]=p0*beam_unit[i];}
    const auto first=boost(a,me,each,incoming,D+K),second=boost(b,me,each,incoming,D+K),ion=boost({},ion_mass,0,incoming,D+K);
    ConditionalParentProducts out;out.primary_momentum_kg_m_s=first.p;out.secondary_momentum_kg_m_s=second.p;out.ion_momentum_kg_m_s=ion.p;
    out.primary_kinetic_J=first.kinetic;out.secondary_kinetic_J=second.kinetic;out.ion_kinetic_J=ion.kinetic;
    out.ion_mass_kg=ion_mass;out.chemical_reference_gain_J=I*e;out.physical_weight_each=represented_weight;out.cross_section_m2=sigma;
    return out;
}
} // namespace raikou::kinetics
