#include "raikou/hydrogen_fragment_ionization.h"
#include "raikou/h2o_deep_valence.h"
#include <functional>
#include <iomanip>
#include <iostream>
int main(int argc,char** argv) {try {
    using namespace raikou::kinetics;
#ifndef RAIKOU_TEST_H_FRAGMENT
#define RAIKOU_TEST_H_FRAGMENT "data/collisions/H-1s-ionization-20261029.json"
#endif
    const auto data=HydrogenFragmentIonizationData::read(argc>=2?argv[1]:RAIKOU_TEST_H_FRAGMENT);
    int checks=0;const auto check=[&](bool yes,const char* why) {++checks;if (!yes)throw std::runtime_error(why);};
    const auto rejects=[&](const std::function<void()>& f) {bool bad=false;try {f();}catch(const std::exception&) {bad=true;}check(bad,"Unadmitted ground-H input accepted");};
    constexpr double e=1.602176634e-19,me=9.1093837139e-31,c=299792458.,u=1.66053906660e-27;
    const double H=1.00782503223*u;double max_energy_error=0,max_momentum_error=0;
    const auto kinetic=[&](const CollisionMomentum& p,double m) {double p2=0;for (auto x:p)p2+=x*x;return p2/(m*(std::sqrt(1+p2/(m*m*c*c))+1));};
    for (const auto& reference:data.metadata().at("formula_reference_points")) {
        const double E=reference.at("energy_eV").get<double>(),expected=std::stod(reference.at("cross_section_m2_decimal").get<std::string>());
        check(std::abs(data.ionization_cross_section_m2(E)/expected-1)<3e-14,"Independent65-digit Q-dependent BEB formula check");
    }
    for (double E:{0.,1.,13.59844})check(data.ionization_cross_section_m2(E)==0,"Physical ground-state below-reference ionization forbidden");
    for (double E:{13.6,13.6057,13.9,10001.})rejects([&]{(void)data.ionization_cross_section_m2(E);});
    for (double E:{14.,20.,100.,1000.,8084.470604111418,10000.}) for (double W:{.125,1.,32.}) for (const auto& axis:std::array<CollisionMomentum,3>{{{1,0,0},{0,-1,0},{.6,0,.8}}}) {
        const auto p=conditional_H1s_ionization_products(data,"H1s_NIST_BEB_equal_pair_CM_v1",E,W,H,{.6,0,.8},axis);
        const double p0=std::sqrt(E*e*(E*e+2*me*c*c))/c;
        for (int d=0;d<3;++d) {const double error=std::abs(p.primary_momentum_kg_m_s[d]+p.secondary_momentum_kg_m_s[d]+p.ion_momentum_kg_m_s[d]-p0*CollisionMomentum{.6,0,.8}[d])/p0;max_momentum_error=std::max(max_momentum_error,error);check(error<2e-13,"Two electron plus proton momentum conservation");}
        check(std::abs(kinetic(p.primary_momentum_kg_m_s,me)-p.primary_kinetic_J)<3e-13*E*e,"Primary electron on shell");
        check(std::abs(kinetic(p.secondary_momentum_kg_m_s,me)-p.secondary_kinetic_J)<3e-13*E*e,"Secondary electron on shell");
        check(std::abs(kinetic(p.ion_momentum_kg_m_s,p.ion_mass_kg)-p.ion_kinetic_J)<3e-13*E*e,"Proton recoil on shell");
        const double error=std::abs((p.primary_kinetic_J+p.secondary_kinetic_J+p.ion_kinetic_J+p.chemical_reference_gain_J)/(E*e)-1);max_energy_error=std::max(max_energy_error,error);check(error<2e-13,"Kinetic plus source-rounded chemical reference closes");
        check(p.physical_weight_each==W&&p.cross_section_m2==data.ionization_cross_section_m2(E),"Matched physical weight and correct H-target rate");
        check(p.ion_mass_kg==H-me+13.59844*e/(c*c)&&p.chemical_reference_gain_J==13.59844*e,"Shared H/Hplus reference basis");
    }
    const auto covered=data.coverage({{1,42.3},{8084,57.7}}),gap=data.coverage({{13.7,42.3},{8084,57.7}});
    check(covered.complete&&covered.total_weight==100&&covered.covered_weight==100,"Known below-reference zero retains all represented electrons");
    check(!gap.complete&&gap.total_weight==100&&gap.uncovered_weight==42.3&&gap.covered_weight==57.7,"Unresolved threshold population is not normalized away");
    rejects([&]{(void)data.strict_rate_m3_s({{13.7,42.3},{8084,57.7}});});
    rejects([&]{(void)data.coverage({{8084,-1}});});rejects([&]{(void)data.coverage({});});
    const auto event=[&](const std::string& model,double W,double mass,const CollisionMomentum& axis) {return conditional_H1s_ionization_products(data,model,8084,W,mass,{1,0,0},axis);};
    rejects([&]{(void)event("",1,H,{1,0,0});});rejects([&]{(void)event("H1s_NIST_BEB_equal_pair_CM_v1",0,H,{1,0,0});});
    rejects([&]{(void)event("H1s_NIST_BEB_equal_pair_CM_v1",1,18*u,{1,0,0});});rejects([&]{(void)event("H1s_NIST_BEB_equal_pair_CM_v1",1,H,{1,1,0});});
    for (int kind=0;kind<4;++kind) {
        auto broken=data.metadata();if (kind==0)broken["target_state"]="H2O_g";if (kind==1)broken["Q"]=1;if (kind==2)broken["products"]["e_g"]=3;if (kind==3)broken["chemical_reference_gain_eV"]=13.6057;
        rejects([&]{HydrogenFragmentIonizationData invalid(broken);});
    }
    if (argc==3) {
        const auto water=StrictCollisionDataset::read(argv[2]);const auto masses=conditional_2a1_state_masses(water,18.01056468403*u,H);
        check(masses.Hplus_kg==event("H1s_NIST_BEB_equal_pair_CM_v1",1,H,{1,0,0}).ion_mass_kg,"Continuation proton mass matches upstream H2O fragment catalog");
        rejects([&]{HydrogenFragmentIonizationData wrong(water.metadata());});
    }
    std::cout<<std::setprecision(17)<<"{\"passed\":true,\"checks\":"<<checks<<",\"max_relative_energy_error\":"<<max_energy_error<<",\"max_relative_momentum_error\":"<<max_momentum_error<<",\"sigma8084_m2\":"<<data.ionization_cross_section_m2(8084.470604111418)<<",\"electron_net_gain\":1,\"physical_time_advanced\":0,\"GPU_used\":false,\"full_fragment_mechanism\":false}\n";return 0;
}catch(const std::exception& e) {std::cerr<<e.what()<<'\n';return 1;}}
