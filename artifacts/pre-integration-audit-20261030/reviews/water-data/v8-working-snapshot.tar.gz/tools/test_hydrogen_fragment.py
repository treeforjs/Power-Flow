#!/usr/bin/env python3
"""Pinned, leased CPU qualification of separate ground-H continuation data."""
from pathlib import Path
import fcntl,hashlib,json,os,subprocess,time
ROOT=Path(__file__).resolve().parents[1]
OUT=Path('/home/treefor/Documents/Codex/2026-10-28/we/outputs/h2o-collision-data-20261029')
FROZEN=Path('/home/treefor/projects/runtimes/arch-base-20261028/run-frozen')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,v):p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
def main():
    assert os.sched_getaffinity(0)=={7} and os.getpriority(os.PRIO_PROCESS,0)==15
    assert all(os.environ.get(k)=='1' for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'])
    lock=(OUT.parent/'pic-profile/testing-core7.lock').open('a')
    try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:raise SystemExit(75)
    began=time.monotonic();i=1
    while (OUT/f'fragment-attempt-{i:03d}').exists():i+=1
    where=OUT/f'fragment-attempt-{i:03d}';where.mkdir()
    path=ROOT/'data/collisions/H-1s-ionization-20261029.json';water=ROOT/'data/collisions/h2o-gas-20261029-deep-valence.json'
    before=sha(path);assert before==json.loads(path.with_suffix('.lock.json').read_text())['dataset_sha256']
    assert sha(water)=='bac4e1e0876caae8eec0f11c5183458561e2c92661653cdb6803310bca2f5f77'
    facts=OUT/'source-documents/nist-H-1s-binding.json';binding=json.loads(facts.read_text());data=json.loads(path.read_text())
    for k in ['B_eV','U_eV','N','Q','bohr_radius_m','rydberg_eV']:assert data[k]==binding[k]
    def run(args,name):
        p=subprocess.run([str(FROZEN),*map(str,args)],cwd=ROOT,capture_output=True,text=True,timeout=35)
        (where/name).write_text(p.stdout+p.stderr)
        if p.returncode:raise RuntimeError(f'Failed command; see {where/name}')
        return p.stdout
    exe=where/'test-H-fragment'
    run(['/usr/bin/c++','-std=c++20','-O2','-Wall','-Wextra','-Wpedantic','-Werror','-I'+str(ROOT/'include'),ROOT/'tests/test_fragment_hydrogen.cpp','-o',exe],'build.log')
    linkage=run(['ldd',exe],'linkage.txt');assert not any(s in linkage.lower() for s in ['cuda','cudss','nvidia','nvml','libmpi'])
    result=json.loads(run([exe,path,water],'native-tests.json'));assert result['passed'] and sha(path)==before
    receipt=dict(status='conditional_ground_H_continuation_qualified_no_evolution',dataset=str(path),dataset_sha256=before,water_v7_dataset_sha256=sha(water),tests=result,
        formula_oracle_scope=data['formula_reference_scope'],native_runtime=str(FROZEN),frozen_userspace=True,CPU=7,nice=15,threads=1,lease_held=True,wall_s=time.monotonic()-began,
        source_binding_sha256={str(facts):sha(facts)},runtime_receipts_sha256={str(p):sha(p) for p in [FROZEN,FROZEN.parent/'kernel.release',FROZEN.parent/'root-files.sha256']},
        dataset_rebuilt_or_modified=False,GPU_used=False,PIC_or_chemistry_evolution=False,
        limitations=['ground-protium1s target only','14..10000eV positive rate/event support; threshold gap explicit','Q-dependent BEB total and conditional equal-pair kinematics, not detailed BED secondary data','excitation/elastic/recombination/other fragments remain missing; full water mechanism false'])
    dump(where/'validation.json',receipt)
    sources=[path,water,ROOT/'include/raikou/hydrogen_fragment_ionization.h',ROOT/'include/raikou/collision_data.h',ROOT/'include/raikou/h2o_conditional_parent.h',ROOT/'include/raikou/h2o_neutral_dissociation.h',ROOT/'include/raikou/h2o_common_mass_basis.h',ROOT/'include/raikou/h2o_outer_valence.h',ROOT/'include/raikou/h2o_deep_valence.h',ROOT/'tests/test_fragment_hydrogen.cpp',ROOT/'tools/build_hydrogen_fragment_data.py',Path(__file__)]
    dump(where/'seal.json',dict(source_sha256={str(p.relative_to(ROOT)):sha(p) for p in sources},files_sha256={p.name:sha(p) for p in where.iterdir() if p.is_file()}))
    dump(OUT/'fragment-latest.json',dict(result_directory=str(where),dataset_sha256=before))
    print(json.dumps(receipt,indent=2))
if __name__=='__main__':main()
