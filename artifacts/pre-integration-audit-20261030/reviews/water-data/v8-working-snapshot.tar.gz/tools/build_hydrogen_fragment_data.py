#!/usr/bin/env python3
"""Freeze separate ground-H ionization facts and computational formula oracles."""
from decimal import Decimal,localcontext
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[1]
def main():
    d=dict(schema='raikou-ground-H-fragment-ionization-v1',id='H-1s-ionization-20261029-v1',phase='gas',target_state='H_1s',
        source=dict(url='https://physics.nist.gov/cgi-bin/Ionization/ion_data.php?differential=Y&id=HI&initial=&ision=I',
            formula='https://physics.nist.gov/PhysRefData/Ionization/intro.html',
            role='Official ground-H orbital constants and general Q-dependent BEB Eq1; this release evaluates that total formula, not the more detailed BED secondary spectrum from the CGI',
            physical_reference='Existing shared water fragment mass catalog uses source-rounded H ionization13.59844eV; retain that same catalog here'),
        B_eV=13.6057,U_eV=13.6057,N=1.,Q=.5668,bohr_radius_m=5.2918e-11,rydberg_eV=13.6057,
        support_eV=[14,10000],known_zero_up_to_eV=13.59844,chemical_reference_gain_eV=13.59844,
        model='H1s_NIST_BEB_equal_pair_CM_v1',products={'e_g':2,'Hp':1},parent_debit={'H_1s':1},electron_net_gain=1,
        assumptions=['ground-state isolated atomic hydrogen target only','Q-dependent nonrelativistic BEB total rate from official1s parameters',
            '14eV selected onset avoids unresolved sub14eV threshold/finite-target-mass region; unsupported positive-energy interval is not set tozero',
            'equal-energy back-to-backCM electron pair and proton at rest in CM; exact boost, not measured secondary/angular sharing',
            'all species mass references bound to the same source-rounded H/Hplus catalog as water kernels'],
        exclusions=['excitedH, Hminus, H2 and ion targets','radiative/three-body recombination, elastic scattering and excitation',
            'nonrelativistic BEB above10keV','complete fragment or full water mechanism'],
        full_fragment_mechanism_ready=False,GPU_execution=False)
    with localcontext() as ctx:
        ctx.prec=65
        a=Decimal('5.2918e-11');B=U=R=Decimal('13.6057');Q=Decimal('.5668');pi=Decimal('3.1415926535897932384626433832795028841971693993751058209749445923078')
        values=[]
        for E in ['14','20','50','100','1000','8084.470604111418','10000']:
            t=Decimal(E)/B;u=U/B;l=t.ln();S=4*pi*a*a*(R/B)**2
            value=S/(t+u+1)*(Q*l/2*(1-1/t**2)+(2-Q)*(1-1/t-l/(t+1)))
            values.append(dict(energy_eV=float(E),cross_section_m2_decimal=str(value)))
        d['formula_reference_points']=values
        d['formula_reference_scope']='Independent65-digit Decimal evaluation of the published formula; computational checks, not experimental measurements or downloaded CGI cross sections'
    out=ROOT/'data/collisions/H-1s-ionization-20261029.json';raw=(json.dumps(d,indent=2,allow_nan=False)+'\n').encode();digest=hashlib.sha256(raw).hexdigest();lock=out.with_suffix('.lock.json')
    if lock.exists():assert json.loads(lock.read_text())['dataset_sha256']==digest,'Frozen H-data drift'
    out.write_bytes(raw)
    if not lock.exists():lock.write_text(json.dumps(dict(dataset_sha256=digest,dataset_id=d['id'],schema='immutable-data-sha256-v1'),indent=2)+'\n')
    print(json.dumps(dict(path=str(out),sha256=digest)))
if __name__=='__main__':main()
