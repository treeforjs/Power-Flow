from pathlib import Path
import datetime
import hashlib
import json

OUT=Path(__file__).resolve().parent
SOURCE=Path('/home/treefor/projects/runtimes/mfem-gpu-pic-20261029/source')
ARCHIVE=SOURCE.parent/'build/libpic.a'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
text=(SOURCE/'src/mfem_gap_pic.cpp').read_text()
def extract(signature):
    start=text.index(signature);opening=text.index('{',start);depth=1;end=opening+1
    while depth:
        if text[end]=='{':depth+=1
        elif text[end]=='}':depth-=1
        end+=1
    return text[start:end]
functions={name:extract(signature) for name,signature in [('pic_boris','PicVector pic_boris('),('norm2','double norm2('),('gamma','double gamma('),('finite','bool finite('),('cross','PicVector cross(')]}
(OUT/'frozen-kernel-source.txt').write_text('\n\n'.join(functions.values())+'\n')
controls={'created_before_kernel_execution_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'actual_kernel':'Frozen libpic.a pic_boris linked directly; no replacement force function.',
 'source':str(SOURCE/'src/mfem_gap_pic.cpp'),'source_sha256':sha(SOURCE/'src/mfem_gap_pic.cpp'),
 'header':str(SOURCE/'include/raikou/mfem_gap_pic.h'),'header_sha256':sha(SOURCE/'include/raikou/mfem_gap_pic.h'),
 'archive':str(ARCHIVE),'archive_sha256':sha(ARCHIVE),'function_sha256':{key:hashlib.sha256(value.encode()).hexdigest() for key,value in functions.items()},
 'existing_tests_source':str(SOURCE/'tests/test_mfem_gap_pic.cpp'),'existing_tests_sha256':sha(SOURCE/'tests/test_mfem_gap_pic.cpp'),
 'benchmark_source_sha256':sha(OUT/'boris_ideal_benchmarks.cpp'),
 'units':'SI; proper velocity u=gamma*v. Kernel q/m is -e/m_e.',
 'cases':{'voltage_V':[100000,110000],'gap_m':.005,'steps_per_analytic_period':[160,320,640,1280],'Hull_B_over_critical':[.98,1,1.02],'drift_B_over_critical_signed':[-1.5,1.5],'drift_periods':8,'cutoff_bisection_iterations':24,'gradient_curvature_steps_per_period':[160,320,640],'gradient_curvature_periods':200,'gradient_scale_and_curvature_radius_m':.1,'gradient_curvature_B_T':1.,'proper_speed_m_s':1e7},
 'acceptance_predeclared':{'existing_magnetic_norm_absolute_m_s':2e-6,'existing_gyro_phase_relative':6e-6,'existing_weak_drift_absolute_m_s':.05,
  'max_nonrelativistic_gyro_angle':.05,'Hull_below_crosses_above_turns':True,'finest_Hull_envelope_relative_error':2e-5,'finest_Hull_critical_field_relative_error':2e-5,'minimum_first_to_last_refinement_order':1.5,
  'coarse_uniform_drift_relative_error':1e-3,'finest_uniform_drift_relative_error':2e-5,'gradient_curvature_relative_error':.01,'magnetic_only_energy_relative_error':1e-11},
 'budget':{'maximum_kernel_calls':2000000,'maximum_CPU_seconds':30,'maximum_address_space_bytes':2147483648},
 'scope':'Unit-kernel calls only. No GapPic construction/advance, sources, Poisson/MPI solve, CUDA API, production/PIC replay or cutoff switch. No force-law/guard/tolerance changes.'}
(OUT/'controls.json').write_text(json.dumps(controls,indent=2)+'\n')
print('Predeclared controls and frozen source/archive hashes prepared')
