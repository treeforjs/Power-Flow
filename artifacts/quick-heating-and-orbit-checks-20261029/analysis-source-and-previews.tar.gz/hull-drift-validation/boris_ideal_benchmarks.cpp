#include "raikou/mfem_gap_pic.h"
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <fstream>
#include <functional>
#include <iomanip>
#include <iostream>
#include <limits>
#include <numbers>
#include <stdexcept>
#include <string>
#include <sys/resource.h>
#include <sched.h>

using namespace raikou::mfem_backend;
namespace {
constexpr double pi=std::numbers::pi;
constexpr double qm=-pic_e/pic_me;
std::uint64_t calls=0;
double squared(const PicVector& u) {return u[0]*u[0]+u[1]*u[1]+u[2]*u[2];}
double lorentz_gamma(const PicVector& u) {return std::sqrt(1+squared(u)/(pic_c*pic_c));}
double kinetic(const PicVector& u) {return pic_me*squared(u)/(lorentz_gamma(u)+1);}
struct State {PicVector x{},u{};};
struct Fields {PicVector E{},B{};};
struct Step {PicVector midpoint;};
Step advance(State& state,double dt,const std::function<Fields(const PicVector&)>& field) {
    // Native position splitting: a half drift, actual frozen pic_boris, half drift.
    const double half=.5*dt,g0=lorentz_gamma(state.u);
    state.x[0]+=(state.u[0]/g0)*half;state.x[1]+=(state.u[1]/g0)*half;state.x[2]+=half*state.u[2]/g0;
    const PicVector midpoint=state.x;const auto values=field(midpoint);
    state.u=pic_boris(state.u,qm,values.E,values.B,dt);++calls;
    if(calls>2000000)throw std::runtime_error("Unit-kernel call budget exceeded");
    const double g1=lorentz_gamma(state.u);
    state.x[0]+=(state.u[0]/g1)*half;state.x[1]+=(state.u[1]/g1)*half;state.x[2]+=half*state.u[2]/g1;
    return {midpoint};
}
double hull(double voltage,double gap) {
    const double a=pic_e*voltage/(pic_me*pic_c*pic_c);
    return pic_me*pic_c/(pic_e*gap)*std::sqrt(2*a+a*a);
}
struct Orbit {
    State state;double dt=0,time=0,max_x=0,period=0,analytic_max_x=0,expected_drift=0,energy_error=0;
};
Orbit crossed(double voltage,double gap,double B,int n,int cycles,bool balanced=false) {
    Orbit result;const double E=voltage/gap,beta=E/(pic_c*std::abs(B));
    if(!(beta<1))throw std::runtime_error("Crossed-field analytic orbit requires |E|<c|B|");
    const double gd=1/std::sqrt(1-beta*beta);
    result.period=2*pi*gd*gd*gd/std::abs(qm*B);result.dt=result.period/n;result.time=cycles*result.period;
    result.expected_drift=E/B;
    result.analytic_max_x=2*pic_me*E/(pic_e*(B*B-E*E/(pic_c*pic_c)));
    if(balanced)result.state.u[1]=gd*result.expected_drift;
    const auto field=[&](const PicVector&){return Fields{{-E,0,0},{0,0,B}};};
    const double initial_energy=kinetic(result.state.u);
    for(int step=0;step<n*cycles;++step) {
        const auto half=advance(result.state,result.dt,field);
        result.max_x=std::max({result.max_x,half.midpoint[0],result.state.x[0]});
        const double invariant=kinetic(result.state.u)-pic_e*E*result.state.x[0]-initial_energy;
        result.energy_error=std::max(result.energy_error,std::abs(invariant)/(pic_e*voltage+initial_energy));
    }
    return result;
}
void emit(std::ofstream& output,const std::string& family,std::initializer_list<std::pair<std::string,double>> values) {
    output<<"{\"family\":\""<<family<<'"';
    for(const auto& [key,value]:values) {
        if(!std::isfinite(value))throw std::runtime_error("Nonfinite benchmark result");
        output<<",\""<<key<<"\":"<<value;
    }
    output<<"}\n";
}
void existing_tests(std::ofstream& output) {
    const double B=.01;PicVector u{1e7,0,0};
    const double g=std::sqrt(1+1e14/(pic_c*pic_c));const double period=2*pi*g/std::abs(qm*B);
    for(int n=0;n<2000;++n){u=pic_boris(u,qm,{0,0,0},{0,0,B},period/2000);++calls;}
    const double norm_error=std::abs(std::hypot(u[0],u[1])-1e7),phase_error=std::abs(u[1])/1e7;
    const double E=100,dt=2*pi/(std::abs(qm*B)*1000);u={0,0,0};double y=0;
    for(int n=0;n<10000;++n){const auto next=pic_boris(u,qm,{E,0,0},{0,0,B},dt);++calls;y+=.5*dt*(u[1]+next[1]);u=next;}
    emit(output,"existing_tests",{{"momentum_norm_absolute_error_m_s",norm_error},{"gyro_phase_relative_error",phase_error},{"weak_ExB_measured_m_s",y/(dt*10000)},{"weak_ExB_expected_m_s",-E/B}});
    bool zero_dt=false,nonfinite=false,overflow=false;
    try {(void)pic_boris({0,0,0},qm,{0,0,0},{0,0,0},0);}catch(const std::invalid_argument&){zero_dt=true;}
    try {(void)pic_boris({0,0,0},qm,{std::numeric_limits<double>::infinity(),0,0},{0,0,0},1e-15);}catch(const std::invalid_argument&){nonfinite=true;}
    try {(void)pic_boris({1e200,0,0},qm,{0,0,0},{0,0,0},1e-15);}catch(const std::runtime_error&){overflow=true;}
    emit(output,"unchanged_guards",{{"zero_dt_rejected",zero_dt},{"nonfinite_field_rejected",nonfinite},{"overflow_rejected",overflow}});
}
void gradient(std::ofstream& output,int n) {
    constexpr double B0=1,L=.1,U=1e7;State state;state.u={U,0,0};
    const double g=lorentz_gamma(state.u),period=2*pi*g/std::abs(qm*B0),dt=period/n;
    const double expected=pic_me*U*U/(2*(-pic_e)*g*B0*L);
    const double center0=state.x[1]-pic_me*state.u[0]/(-pic_e*B0),energy0=kinetic(state.u);
    double energy_error=0;
    const auto field=[&](const PicVector& x){return Fields{{0,0,0},{0,0,B0*(1+x[0]/L)}};};
    for(int step=0;step<200*n;++step) {
        advance(state,dt,field);energy_error=std::max(energy_error,std::abs(kinetic(state.u)-energy0)/energy0);
    }
    const double Bfinal=B0*(1+state.x[0]/L),center=state.x[1]-pic_me*state.u[0]/(-pic_e*Bfinal);
    const double measured=(center-center0)/(200*period);
    emit(output,"grad_B",{{"steps_per_period",double(n)},{"cycles",200},{"dt_s",dt},{"B0_T",B0},{"gradient_scale_m",L},{"proper_perp_speed_m_s",U},{"rho_over_L",pic_me*U/(pic_e*B0*L)},{"expected_drift_y_m_s",expected},{"measured_guiding_center_drift_y_m_s",measured},{"relative_error",std::abs((measured-expected)/expected)},{"max_magnetic_energy_relative_error",energy_error}});
}
void curvature(std::ofstream& output,int n,bool exact_helix) {
    constexpr double B0=1,R=.1,U=1e7;State state;state.x={R,0,0};state.u={0,U,0};
    const double steady_uz=pic_me*U*U/(-pic_e*B0*R);if(exact_helix)state.u[2]=steady_uz;
    const double g=lorentz_gamma(state.u),period=2*pi*g/std::abs(qm*B0),dt=period/n;
    const double expected=steady_uz/g,energy0=kinetic(state.u);double energy_error=0,radius_error=0;
    const auto field=[&](const PicVector& x){const double radius=std::hypot(x[0],x[1]);return Fields{{0,0,0},{-B0*x[1]/radius,B0*x[0]/radius,0}};};
    for(int step=0;step<200*n;++step) {
        advance(state,dt,field);energy_error=std::max(energy_error,std::abs(kinetic(state.u)-energy0)/energy0);
        radius_error=std::max(radius_error,std::abs(std::hypot(state.x[0],state.x[1])-R)/R);
    }
    const double measured=state.x[2]/(200*period);
    emit(output,exact_helix?"curvature_exact_helix":"curvature_parallel_launch",{{"steps_per_period",double(n)},{"cycles",200},{"dt_s",dt},{"B0_T",B0},{"curvature_radius_m",R},{"proper_parallel_speed_m_s",U},{"parallel_adiabatic_parameter",pic_me*U/(pic_e*B0*R)},{"expected_drift_z_m_s",expected},{"measured_drift_z_m_s",measured},{"relative_error",std::abs((measured-expected)/expected)},{"max_magnetic_energy_relative_error",energy_error},{"max_relative_radius_excursion",radius_error}});
}
}
int main(int argc,char** argv) {
    try {
        if(argc!=2)throw std::invalid_argument("Usage: boris_ideal_benchmarks OUTPUT_JSONL");
        cpu_set_t cpu;CPU_ZERO(&cpu);sched_getaffinity(0,sizeof(cpu),&cpu);
        if(CPU_COUNT(&cpu)!=1 || !CPU_ISSET(6,&cpu) || getpriority(PRIO_PROCESS,0)!=15)throw std::runtime_error("CPU 6/nice 15 required");
        std::ofstream output(argv[1]);output<<std::setprecision(17);existing_tests(output);
        constexpr double gap=.005;
        for(double voltage:{100000.,110000.}) {
            const double critical=hull(voltage,gap);
            emit(output,"analytic_Hull",{{"voltage_V",voltage},{"gap_m",gap},{"critical_B_T",critical},{"nonrelativistic_B_T",std::sqrt(2*pic_me*voltage/pic_e)/gap}});
            for(int n:{160,320,640,1280}) {
                for(double ratio:{.98,1.,1.02}) {
                    const double B=ratio*critical;const auto orbit=crossed(voltage,gap,B,n,1);
                    emit(output,"Hull_orbit",{{"voltage_V",voltage},{"gap_m",gap},{"B_over_Hull",ratio},{"B_T",B},{"steps_per_period",double(n)},{"dt_s",orbit.dt},{"nonrel_gyro_angle",std::abs(qm*B)*orbit.dt},{"analytic_max_x_m",orbit.analytic_max_x},{"computed_native_max_x_m",orbit.max_x},{"relative_max_x_error",std::abs(orbit.max_x/orbit.analytic_max_x-1)},{"crossed_anode_plane",orbit.max_x>=gap},{"max_energy_potential_invariant_relative_error",orbit.energy_error}});
                }
                double low=.98*critical,high=1.02*critical;
                if(!(crossed(voltage,gap,low,n,1).max_x>=gap && crossed(voltage,gap,high,n,1).max_x<gap))throw std::runtime_error("Hull crossing bracket absent");
                for(int iteration=0;iteration<24;++iteration) {
                    const double middle=.5*(low+high);
                    if(crossed(voltage,gap,middle,n,1).max_x>=gap)low=middle;else high=middle;
                }
                emit(output,"Hull_numeric_bracket",{{"voltage_V",voltage},{"steps_per_period",double(n)},{"analytic_B_T",critical},{"crossing_low_B_T",low},{"noncrossing_high_B_T",high},{"relative_bracket_width",(high-low)/critical},{"relative_center_error",std::abs((.5*(low+high))/critical-1)}});
                for(double sign:{-1.,1.})for(bool balanced:{false,true}) {
                    const double B=sign*1.5*critical;const auto orbit=crossed(voltage,gap,B,n,8,balanced);const double measured=orbit.state.x[1]/orbit.time;
                    emit(output,balanced?"ExB_balanced_launch":"ExB_cold_launch",{{"voltage_V",voltage},{"B_T",B},{"steps_per_period",double(n)},{"cycles",8},{"dt_s",orbit.dt},{"nonrel_gyro_angle",std::abs(qm*B)*orbit.dt},{"drift_beta",std::abs(orbit.expected_drift)/pic_c},{"expected_drift_y_m_s",orbit.expected_drift},{"measured_drift_y_m_s",measured},{"relative_drift_error",std::abs(measured/orbit.expected_drift-1)},{"net_x_m",orbit.state.x[0]}});
                }
            }
        }
        for(int n:{160,320,640}){gradient(output,n);curvature(output,n,false);curvature(output,n,true);}
        emit(output,"execution",{{"valid_pic_boris_updates",double(calls)},{"guard_test_calls",3},{"logical_cpu",6},{"nice",15},{"threads",1},{"GapPic_instances_or_advances",0},{"field_solves",0},{"driver_CUDA_calls",0}});
        output.close();if(!output)throw std::runtime_error("Benchmark output failed");
        std::cout<<"Completed isolated frozen-pic_boris ideal benchmarks: "<<calls<<" kernel calls\n";
    }catch(const std::exception& error){std::cerr<<error.what()<<'\n';return 1;}
}
