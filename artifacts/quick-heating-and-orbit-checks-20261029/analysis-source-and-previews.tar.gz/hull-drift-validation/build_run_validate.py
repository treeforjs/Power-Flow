from pathlib import Path
import datetime
import fcntl
import hashlib
import json
import math
import os
import shlex
import subprocess
import time

OUT=Path(__file__).resolve().parent
NATIVE=Path('/home/treefor/projects/runtimes/mfem-gpu-pic-20261029')
LAUNCHER='/home/treefor/projects/runtimes/arch-base-20261028/run-frozen'
LOCK=Path('/home/treefor/Documents/Codex/2026-10-28/we/outputs/pic-profile/testing-core.lock')
assert os.sched_getaffinity(0)=={6} and os.getpriority(os.PRIO_PROCESS,0)==15
with LOCK.open('a') as lease:
    try:fcntl.flock(lease,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:pass
    else:raise RuntimeError('Acquire testing-core.lock before this entry point')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
control=json.loads((OUT/'controls.json').read_text());limits=control['acceptance_predeclared']
assert sha(OUT/'boris_ideal_benchmarks.cpp')==control['benchmark_source_sha256']
for name in ['source','header','archive']:assert sha(Path(control[name]))==control[name+'_sha256']
flags=(NATIVE/'build/CMakeFiles/pic.dir/flags.make').read_text()
includes=shlex.split(next(line.split('=',1)[1] for line in flags.splitlines() if line.startswith('CXX_INCLUDES =')))
parts=shlex.split((NATIVE/'build/CMakeFiles/pic_foundation_tests.dir/link.txt').read_text())
libraries=[str(NATIVE/'build/libpic.a') if value=='libpic.a' else value for value in parts[parts.index('-o')+2:]]
binary=OUT/'boris_ideal_benchmarks'
commands=[['/usr/sbin/c++','-std=c++20','-O3','-DNDEBUG',*includes,str(OUT/'boris_ideal_benchmarks.cpp'),'-o',str(binary),*libraries],
          ['prlimit','--as=2147483648','--cpu=30','--',str(binary),str(OUT/'raw-results.jsonl')]]
evidence=[]
for label,command in zip(['build','run'],commands):
    actual=[LAUNCHER,*command];start=time.monotonic();result=subprocess.run(actual,cwd=OUT,capture_output=True,text=True)
    (OUT/(label+'.log')).write_text(result.stdout+result.stderr)
    evidence.append({'label':label,'command':actual,'elapsed_s':time.monotonic()-start,'returncode':result.returncode,'cpu_affinity':sorted(os.sched_getaffinity(0)),'nice':os.getpriority(os.PRIO_PROCESS,0),'threads':1,'lease_exclusion_verified':True})
    (OUT/'commands.json').write_text(json.dumps(evidence,indent=2)+'\n')
    if result.returncode:raise RuntimeError(result.stdout+result.stderr)
    print(label+' passed',flush=True)
rows=[json.loads(line) for line in (OUT/'raw-results.jsonl').read_text().splitlines()]
checks=[]
def check(name,passed,**details):checks.append({'name':name,'passed':bool(passed),**details})
existing=next(row for row in rows if row['family']=='existing_tests')
check('existing magnetic norm',existing['momentum_norm_absolute_error_m_s']<=limits['existing_magnetic_norm_absolute_m_s'],measured=existing['momentum_norm_absolute_error_m_s'],limit=limits['existing_magnetic_norm_absolute_m_s'])
check('existing gyro phase',existing['gyro_phase_relative_error']<limits['existing_gyro_phase_relative'],measured=existing['gyro_phase_relative_error'],limit=limits['existing_gyro_phase_relative'])
check('existing weak ExB',abs(existing['weak_ExB_measured_m_s']-existing['weak_ExB_expected_m_s'])<=limits['existing_weak_drift_absolute_m_s'],measured=existing['weak_ExB_measured_m_s'],expected=existing['weak_ExB_expected_m_s'],absolute_limit=limits['existing_weak_drift_absolute_m_s'])
guards=next(row for row in rows if row['family']=='unchanged_guards');check('unchanged kernel guards',all(value==1 for key,value in guards.items() if key!='family'))
def order(first,last,error):
    coarse=first[error];fine=last[error]
    return math.log(coarse/fine)/math.log(last['steps_per_period']/first['steps_per_period']) if coarse>0 and fine>0 else None
for voltage in [100000,110000]:
    for ratio in [.98,1.,1.02]:
        own=sorted((row for row in rows if row['family']=='Hull_orbit' and row['voltage_V']==voltage and row['B_over_Hull']==ratio),key=lambda row:row['steps_per_period'])
        assert len(own)==4
        check(f'Hull envelope {voltage} {ratio}',own[-1]['relative_max_x_error']<=limits['finest_Hull_envelope_relative_error'],measured=own[-1]['relative_max_x_error'],limit=limits['finest_Hull_envelope_relative_error'])
        observed=order(own[0],own[-1],'relative_max_x_error')
        check(f'Hull envelope refinement {voltage} {ratio}',observed is not None and observed>=limits['minimum_first_to_last_refinement_order'],order=observed)
        for row in own:
            check(f'gyro angle {voltage} {ratio} N{row["steps_per_period"]}',row['nonrel_gyro_angle']<=limits['max_nonrelativistic_gyro_angle'])
            if ratio!=1:check(f'Hull below/above crossing {voltage} {ratio} N{row["steps_per_period"]}',bool(row['crossed_anode_plane'])==(ratio<1))
    own=sorted((row for row in rows if row['family']=='Hull_numeric_bracket' and row['voltage_V']==voltage),key=lambda row:row['steps_per_period'])
    check(f'Hull numeric bracket fine error {voltage}',own[-1]['relative_center_error']<=limits['finest_Hull_critical_field_relative_error'],measured=own[-1]['relative_center_error'],limit=limits['finest_Hull_critical_field_relative_error'])
    observed=order(own[0],own[-1],'relative_center_error');check(f'Hull bracket refinement {voltage}',observed is not None and observed>=limits['minimum_first_to_last_refinement_order'],order=observed)
    for sign in [-1,1]:
        for family in ['ExB_cold_launch','ExB_balanced_launch']:
            own=sorted((row for row in rows if row['family']==family and row['voltage_V']==voltage and math.copysign(1,row['B_T'])==sign),key=lambda row:row['steps_per_period'])
            assert len(own)==4
            check(f'{family} sign {voltage} {sign}',all(row['measured_drift_y_m_s']*row['expected_drift_y_m_s']>0 for row in own))
            check(f'{family} coarse error {voltage} {sign}',own[0]['relative_drift_error']<=limits['coarse_uniform_drift_relative_error'],measured=own[0]['relative_drift_error'],limit=limits['coarse_uniform_drift_relative_error'])
            check(f'{family} fine error {voltage} {sign}',own[-1]['relative_drift_error']<=limits['finest_uniform_drift_relative_error'],measured=own[-1]['relative_drift_error'],limit=limits['finest_uniform_drift_relative_error'])
            observed=order(own[0],own[-1],'relative_drift_error');check(f'{family} refinement {voltage} {sign}',observed is not None and observed>=limits['minimum_first_to_last_refinement_order'],order=observed)
for row in rows:
    if row['family'] in ['grad_B','curvature_parallel_launch','curvature_exact_helix']:
        key='measured_guiding_center_drift_y_m_s' if row['family']=='grad_B' else 'measured_drift_z_m_s'
        expected='expected_drift_y_m_s' if row['family']=='grad_B' else 'expected_drift_z_m_s'
        check(f'{row["family"]} sign N{row["steps_per_period"]}',row[key]*row[expected]>0)
        check(f'{row["family"]} approximation N{row["steps_per_period"]}',row['relative_error']<=limits['gradient_curvature_relative_error'],measured=row['relative_error'],limit=limits['gradient_curvature_relative_error'])
        check(f'{row["family"]} magnetic energy N{row["steps_per_period"]}',row['max_magnetic_energy_relative_error']<=limits['magnetic_only_energy_relative_error'],measured=row['max_magnetic_energy_relative_error'],limit=limits['magnetic_only_energy_relative_error'])
execution=next(row for row in rows if row['family']=='execution');check('bounded unit update count',execution['valid_pic_boris_updates']<=control['budget']['maximum_kernel_calls'])
for name in ['source','header','archive']:assert sha(Path(control[name]))==control[name+'_sha256']
failures=[item for item in checks if not item['passed']]
result={'status':'passed' if not failures else 'failed','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':checks,'failures':failures,'rows':rows,
 'predeclared_controls_unchanged':True,'controls_sha256':sha(OUT/'controls.json'),'benchmark_binary_sha256':sha(binary),'actual_frozen_archive_unchanged':True,
 'source_or_force_law_guard_changes':False,'GapPic_or_production_PIC_execution':False,'GPU_execution':False,'shared_testing_core_lease':True,'cpu_affinity':[6],'nice':15,'threads':1,
 'test_scope':'Actual frozen pic_boris unit calls with the native two-half-drift position split; prescribed analytic fields only. No field solve/source/boundary cutoff is applied.'}
(OUT/'validation.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print('Validation',result['status'],len(checks),'checks;',len(failures),'failures',flush=True)
for failure in failures:print(failure,flush=True)
