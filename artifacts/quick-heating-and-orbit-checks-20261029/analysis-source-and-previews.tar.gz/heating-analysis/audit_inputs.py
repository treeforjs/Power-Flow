#!/usr/bin/env python3
"""Bounded read-only metadata/temperature comparison; no field solve."""
from pathlib import Path
import csv, hashlib, json, math, os, resource
import numpy as np

BASE=Path('/home/treefor/projects/Power-Flow')
OUTPUT=Path('/home/treefor/Documents/Codex/2026-10-28/we/outputs')
HERE=Path(__file__).resolve().parent
tracked={}
def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for x in iter(lambda:f.read(1024**2),b''):h.update(x)
    return h.hexdigest()
def record(path):
    s=path.stat();tracked[str(path)]={'bytes':s.st_size,'sha256':digest(path),'mtime_ns':s.st_mtime_ns}
def load(path):record(path);return json.loads(path.read_text())

summary=load(OUTPUT/'thermionic-supply/summary.json')
history=load(OUTPUT/'heating-history-full.json')
old_spec=load(BASE/'configs/mfem_edge_current_arch_2048x256.json')
native=BASE/'runs/restore_field_mpi8_domain40mm'
current=load(native/'source_run.json')
config=load(native/'configuration.json')
assert current['configuration']==config
npzpath=OUTPUT/'thermionic-supply/surface_supply_arrays.npz';record(npzpath)
assert tracked[str(npzpath)]['sha256']==history['source_npz_sha256']
record(OUTPUT/'heating-history-full.bin')
assert tracked[str(OUTPUT/'heating-history-full.bin')]['sha256']==history['binary_sha256']
z=np.load(npzpath,allow_pickle=False)
faces={}
for face in ['top','bottom','left','right']:
    manifest=load(native/(face+'_surface.json'))
    p=native/(face+'.csv');record(p)
    assert tracked[str(p)]['sha256']==manifest['table']['sha256']
    rows={}
    with p.open() as f:
        for r in csv.DictReader(f):
            t=float(r['time_s']);i=int(r['x_index']);assert int(r['z_index'])==0
            assert i not in rows.setdefault(t,{})
            rows[t][i]=float(r['temperature_value'])+manifest['temperature']['initial_temperature_k']
    times=np.array(sorted(rows));n=len(rows[times[0]])
    assert all(set(row)==set(range(n)) for row in rows.values())
    T=np.array([[rows[t][i] for i in range(n)] for t in times])
    oldT=z[face+'_temperature_K'];oldtimes=z[face+'_time_s']
    original_old_shape=list(oldT.shape)
    assert oldT.ndim==3 and oldT.shape[1]==1
    oldT=oldT[:,0,:]  # The source explicitly has one invariant-current-direction patch.
    assert np.isfinite(T).all() and np.isfinite(oldT).all()
    common=[]
    for t in [40e-9,60e-9]:
        ci=np.flatnonzero(times==t);oi=np.flatnonzero(oldtimes==t)
        assert len(ci)==len(oi)==1
        a,b=oldT[oi[0]],T[ci[0]];assert a.shape[0]%b.shape[0]==0
        # This derived geometric averaging is for comparison only; no source input changes.
        averaged=a.reshape(len(b),-1).mean(axis=1)
        J=lambda v:summary['ideal_Richardson_A_m2_K2']*v*v*np.exp(-4.3/(8.617333262145e-5*v))
        ja,jb=J(a),J(b)
        common.append({'time_s':t,'old_absolute_K_min':float(a.min()),'old_absolute_K_max':float(a.max()),
          'current_absolute_K_min':float(b.min()),'current_absolute_K_max':float(b.max()),
          'current_minus_geometrically_averaged_old_K_linf':float(np.max(np.abs(b-averaged))),
          'formal_old_mean_Richardson_A_m2':float(ja.mean()),'formal_current_mean_Richardson_A_m2':float(jb.mean()),
          'formal_current_over_old_mean_supply':float(jb.mean()/ja.mean()),
          'formal_J_at_averaged_old_over_mean_old_J':float(J(averaged).mean()/ja.mean())})
    faces[face]={'old_stored_shape_time_z_x':original_old_shape,'old_shape':list(oldT.shape),'current_shape':list(T.shape),
      'time_arrays_exact':bool(np.array_equal(oldtimes,times)),
      'current_time_count':len(times),'old_time_count':len(oldtimes),
      'current_time_bounds_s':[float(times[0]),float(times[-1])],
      'current_surface_definition':{k:manifest[k] for k in ['temperature','face']},'comparisons':common}
cases={}
for name in ['restore_field_mpi8_v2','restore_field_mpi8_domain20mm','restore_field_mpi8_domain40mm']:
    d=load(BASE/'runs'/name/'source_run.json')
    cases[name]={'configuration':{k:v for k,v in d['configuration'].items() if k not in ['field_snapshot_times_s']},'final':d['diagnostics']['final']}
source_hashes={}
for relative,expected in current['owned_source_sha256'].items():
    path=BASE/relative;record(path)
    source_hashes[relative]={'actual':tracked[str(path)]['sha256'],'recorded':expected,'matched':tracked[str(path)]['sha256']==expected}
for path in [Path('/home/treefor/projects/runtimes/mfem-gpu-pic-20261029/source/examples/native_heating_fields.hpp'),
             Path('/home/treefor/projects/runtimes/mfem-gpu-pic-20261029/source/examples/mfem_heating_history_pic.cpp'),
             OUTPUT/'electron-mapping-paused-26p48ns/native-b/manifest.json',
             OUTPUT/'pic-profile/em-field-consistency-audit/audit-report.txt']:
    record(path)
differences={}
for k in set(old_spec)|set(config):
    if k=='field_snapshot_times_s':continue
    if old_spec.get(k)!=config.get(k):differences[k]={'surviving_highres_spec':old_spec.get(k),'executed_native40_config':config.get(k)}
for path,x in tracked.items():
    p=Path(path);assert p.stat().st_mtime_ns==x['mtime_ns'] and digest(p)==x['sha256'],path
report={'status':'read_only_audit_complete','old_run_complete_provenance_available':False,
 'surviving_highres_configuration_is_not_execution_proof':str(BASE/'configs/mfem_edge_current_arch_2048x256.json'),
 'known_thermal_cache':history,'configuration_differences':differences,'surface_comparison':faces,
 'existing_exterior_cases':cases,'native_source_provenance_match':source_hashes,
 'formal_supply_comparison_scope':'Ideal A,phi4.3eV at exported absolute patch-average temperatures. No space charge, barrier lowering, chemistry, phase change or physical emission qualification. J(mean T) differs from mean J(T). No data were rescaled.',
 'no_field_solve_or_PIC_or_GPU_or_production_action':True,
 'input_manifest':tracked,'execution':{'affinity':list(os.sched_getaffinity(0)),'nice':os.nice(0),'CPU_s':resource.getrusage(resource.RUSAGE_SELF).ru_utime+resource.getrusage(resource.RUSAGE_SELF).ru_stime,'max_RSS_KiB':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss}}
(HERE/'input-audit.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps({'faces':{f:v['comparisons'] for f,v in faces.items()},'configuration_differences':differences,'execution':report['execution']},indent=2))
