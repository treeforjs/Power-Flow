from pathlib import Path
import json,subprocess,time,fcntl,os,hashlib
W=Path('/home/treefor/Documents/Codex/2026-10-28/we');P=Path('/home/treefor/projects/Power-Flow');O=W/'outputs/heating-rerun-20261029'
record=O/'run-status.json';assert not record.exists();state={'status':'waiting_for_CPU6_CPU7_leases','production_PIC_resume_authorized':False,'MPI_ranks':2,'OS_CPUs':[6,7],'cases':[],'started_unix_s':time.time()};record.write_text(json.dumps(state,indent=2)+'\n')
def hold():
 p=Path('/proc/278902');s=(p/'stat').read_text().split();assert s[2]=='T' and s[21]=='5288339';assert 'frozen 1' in Path('/sys/fs/cgroup/powerflow-pic-gpu-reserved/cgroup.events').read_text()
try:
 with open(W/'outputs/pic-profile/testing-core.lock','a') as c6,open(W/'outputs/pic-profile/testing-core7.lock','a') as c7:
  fcntl.flock(c6,fcntl.LOCK_EX);fcntl.flock(c7,fcntl.LOCK_EX)
  for size in ['128x16','256x32']:
   hold();output=P/('runs/quick_heating_'+size+'_domain40mm_height25mm_20261029');assert not output.exists()
   config=P/('configs/mfem_edge_current_quick_'+size+'_domain40mm_height25mm.json')
   command=['timeout','--signal=TERM','--kill-after=5s','900s','taskset','-c','6,7','nice','-n','15','/home/treefor/projects/runtimes/arch-base-20261028/run-frozen','env','OMP_NUM_THREADS=1','OPENBLAS_NUM_THREADS=1','MKL_NUM_THREADS=1','CUDA_VISIBLE_DEVICES=','python3',str(P/'tools/run_mfem_edge_source.py'),'--config',str(config),'--build-dir','/home/treefor/projects/runtimes/mfem-4.10-pic-20261029/build-edge','--mfem-dir','/home/treefor/projects/runtimes/mfem-4.10-pic-20261029/install-mpi/lib/cmake/mfem','--output-dir',str(output),'--ranks','2','--cpu-list','6,7']
   case={'resolution':size,'output':str(output),'command':command,'status':'running','started_unix_s':time.time(),'config_sha256':hashlib.sha256(config.read_bytes()).hexdigest()};state['cases'].append(case);state['status']='running_'+size;record.write_text(json.dumps(state,indent=2)+'\n')
   start=time.monotonic()
   with open(O/(size+'.stdout'),'x') as so,open(O/(size+'.stderr'),'x') as se:result=subprocess.run(command,cwd=P,stdout=so,stderr=se,timeout=915)
   case['returncode']=result.returncode;case['wall_s']=time.monotonic()-start;case['status']='completed' if not result.returncode else 'failed';record.write_text(json.dumps(state,indent=2)+'\n');print(json.dumps(case),flush=True);assert result.returncode==0
   run=json.loads((output/'source_run.json').read_text());assert run['passed'] and run['source_files_unchanged_after_run'] and run['parallel_execution']['mpi_ranks']==2 and run['parallel_execution']['all_ranks_participated'];hold()
 state['status']='both_matched_heating_field_runs_completed_pending_analysis'
except BaseException as e:
 state['status']='failed_closed';state['error']=repr(e);raise
finally:
 state['finished_unix_s']=time.time();record.write_text(json.dumps(state,indent=2)+'\n')
