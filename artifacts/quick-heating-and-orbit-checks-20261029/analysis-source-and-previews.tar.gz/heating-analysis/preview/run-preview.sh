#!/bin/bash
set -euo pipefail
out=/home/treefor/Documents/Codex/2026-10-28/we/outputs/heating-rerun-20261029/preview
lease=/home/treefor/Documents/Codex/2026-10-28/we/outputs/pic-profile/testing-core7.lock
exec 9>"$lease"
flock -x 9
state=/home/treefor/Documents/Codex/2026-10-28/we/outputs/heating-rerun-20261029/run-status.json
# Parent's dispatcher releases leases immediately before its final status write.
for attempt in 1 2 3 4 5; do
  if /usr/bin/python3 -c 'import json,sys; s=json.load(open(sys.argv[1]));sys.exit(0 if s["status"]=="both_matched_heating_field_runs_completed_pending_analysis" else 1)' "$state"; then
    cd /home/treefor/projects/Power-Flow
    taskset -c 7 nice -n 15 /home/treefor/projects/runtimes/arch-base-20261028/run-frozen env OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 CUDA_VISIBLE_DEVICES= /home/treefor/projects/Power-Flow/.venv/bin/python "$out/compare_heating.py"
    exit $?
  fi
  sleep 1
done
printf '%s\n' 'Completed matched-run status missing; preview did not execute.' >&2
exit 2
