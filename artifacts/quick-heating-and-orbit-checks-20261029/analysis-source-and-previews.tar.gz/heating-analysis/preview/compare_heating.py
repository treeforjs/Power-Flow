"""Read completed native exports and compare recorded temperatures; no field solver."""
from pathlib import Path
import csv, importlib.util, json, math, os, sys, time, hashlib, resource
os.environ.setdefault('MPLCONFIGDIR',str(Path(__file__).parent/'matplotlib-cache'))
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
import PIL
from PIL import Image

ROOT=Path('/home/treefor/projects/Power-Flow')
OUT=Path(__file__).resolve().parent
VERIFIED=ROOT/'tools/render_mfem_foil_temperature.py'
spec=importlib.util.spec_from_file_location('verified_temperature_reader',VERIFIED)
v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
THRESHOLDS=(1000,2000,4000)
started=time.monotonic()
inputs={}

def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
    return h.hexdigest()

def bind(p,expected=None):
    p=Path(p).resolve();h=sha(p)
    if expected is not None and h!=expected:raise ValueError('input hash mismatch: '+str(p))
    if str(p) in inputs and h!=inputs[str(p)]['sha256']:raise ValueError('input changed while reading')
    inputs[str(p)]={'sha256':h,'bytes':p.stat().st_size}
    return h

class AnodeDirectory:
    """Only map original reader's four schema names to native anode schemas.
    CSV paths are already explicit inside their native JSON and remain unchanged.
    """
    def __init__(self,path):self.path=path
    def __truediv__(self,name):
        if name in {f+'_surface.json' for f in ('top','bottom','left','right')}:name='anode_'+name
        return self.path/name

def weighted_quantile(a,w,p):
    a=np.asarray(a).ravel();w=np.broadcast_to(w,np.shape(a)).ravel()
    order=np.argsort(a,kind='stable');total=np.cumsum(w[order]);return float(a[order[np.searchsorted(total,p*total[-1],side='left')]])

def stats(a,w):
    a=np.asarray(a).ravel();w=np.broadcast_to(w,np.shape(a)).ravel()
    return {'mean_k':float(np.sum(a*w)/np.sum(w)),'min_k':float(np.min(a)),
            'max_k':float(np.max(a)),'area_weighted_p95_k':weighted_quantile(a,w,.95),
            'area_weighted_p99_k':weighted_quantile(a,w,.99),
            'area_fraction_at_or_above':{str(t):float(np.sum(w[a>=t])/np.sum(w)) for t in THRESHOLDS}}

def load(label):
    directory=ROOT/('runs/quick_heating_'+label+'_domain40mm_height25mm_20261029')
    run_path=directory/'source_run.json';bind(run_path)
    run=json.loads(run_path.read_text());c=run['configuration']
    assert run['passed'] and run['source_files_unchanged_after_run']
    assert c['exterior_half_extent_m']==.04 and c['current_length_m']==.025 and c['stop_time_s']==60e-9
    assert [c['foil_width_m'],c['foil_thickness_m'],c['gap_m']]==[.005,.0002,.005]
    assert c['initial_temperature_k']==300
    names=['configuration.json','diagnostics.csv','foil_snapshots.json','foil_snapshots.csv','schedule.csv']
    names += [prefix+face+suffix for prefix in ('','anode_') for face in ('top','bottom','left','right') for suffix in ('_surface.json','.csv')]
    for name in names:bind(directory/name,run['outputs_sha256'][name])
    # Frozen source snapshot is the executed source evidence, read-only.
    for name in ('native/mfem_edge_source/edge_driver.cpp','tools/run_mfem_edge_source.py'):
        source=directory/'source_snapshot'/name
        if source.exists():bind(source)
    fields=v.read_fields(directory,c)
    upper=v.read_surfaces(directory);lower=v.read_surfaces(AnodeDirectory(directory))
    assert set(upper)==set(lower)=={'top','bottom','left','right'}
    for prefix,faces in (('',upper),('anode_',lower)):
        for face,data in faces.items():
            cfg=json.loads((directory/(prefix+face+'_surface.json')).read_text())
            assert cfg['temperature']['evaluation']=='one_sided_material_boundary_trace_patch_average'
            assert cfg['temperature']['material_sample_depth_m']==0
            axis='y' if face in ('left','right') else 'x'
            assert cfg['face'].get('physical_in_plane_axis','x')==axis
            assert all(b>a for a,b in zip(data['times'],data['times'][1:]))
            assert np.all(np.diff(data['edges'])>0)
            data['physical_in_plane_axis']=axis
            data['normal_position_m']=cfg['face']['normal_position_m']
    with (directory/'diagnostics.csv').open(newline='') as stream:
        diag=[{k:float(x) for k,x in row.items()} for row in csv.DictReader(stream)]
    assert all(math.isfinite(x) for row in diag for x in row.values())
    times=[r['time_s'] for r in diag]
    assert all(data['times']==times for faces in (upper,lower) for data in faces.values())
    assert list(fields)==run['field_snapshot_times_s']
    assert times[-1]==60e-9 and list(fields)[-1]==60e-9
    # Read Joule cell averages using the exact same geometry decoder/checks as T.
    # A single sequential pass verifies row indices against already verified fields.
    nx,ny=c['width_cells'],c['thickness_cells'];width=c['foil_width_m'];thickness=c['foil_thickness_m']
    q={t:np.full((ny,nx),np.nan) for t in fields}
    with (directory/'foil_snapshots.csv').open(newline='') as stream:
        for row in csv.DictReader(stream):
            t=float(row['time_s']);ix=round((float(row['x_left_m'])+width/2)*nx/width);iy=round(float(row['depth_left_m'])*ny/thickness)
            value=float(row['joule_power_w_m3'])
            assert math.isfinite(value) and value>=0 and np.isnan(q[t][iy,ix])
            assert float(row['temperature_k'])==fields[t][iy,ix]
            q[t][iy,ix]=value
    assert all(np.all(np.isfinite(a)) for a in q.values())
    return {'label':label,'directory':directory,'run':run,'configuration':c,'fields':fields,'upper':upper,'lower':lower,'diag':diag,'times':times,'q':q}

def record_metrics(case):
    c=case['configuration'];cell_area=c['foil_width_m']*c['foil_thickness_m']/(c['width_cells']*c['thickness_cells']);volume=c['foil_width_m']*c['foil_thickness_m']*c['current_length_m']
    dt=np.diff(case['times']);d=case['diag'];row=d[-1]
    energies={key:float(np.dot(dt,[r[key] for r in d[1:]])) for key in ('foil_joule_power_w','return_joule_power_w','total_joule_power_w')}
    final=case['fields'][60e-9];mean=float(np.mean(final));solid=stats(final,np.ones(final.size))
    upper_thermal=c['volumetric_heat_capacity_j_m3_k']*volume*(mean-c['initial_temperature_k'])
    total_thermal=row['thermal_energy_j']
    power=float(np.sum(case['q'][60e-9]))*cell_area*c['current_length_m']
    assert math.isclose(power,row['foil_joule_power_w'],rel_tol=2e-12,abs_tol=1e-8)
    assert math.isclose(upper_thermal,energies['foil_joule_power_w'],rel_tol=2e-10,abs_tol=1e-8)
    assert math.isclose(total_thermal,energies['total_joule_power_w'],rel_tol=2e-10,abs_tol=1e-8)
    traces={}
    for body in ('upper','lower'):
        traces[body]={}
        for face,data in case[body].items():
            a=data['temperature_k'][-1];lengths=np.diff(data['edges'])
            traces[body][face]=dict(stats(a,lengths),patch_count=len(a),patch_length_m_min=float(lengths.min()),patch_length_m_max=float(lengths.max()),physical_coordinate_edges_m=data['edges'].tolist(),physical_normal_position_m=data['normal_position_m'])
    # Finite physical edge/center regions: overlap integrals of native cell averages.
    x=np.linspace(-c['foil_width_m']/2,c['foil_width_m']/2,c['width_cells']+1)
    regions={}
    for name,intervals in {'width_edges_abs_x_ge_2mm':[(-.0025,-.002),(.002,.0025)],'width_center_abs_x_le_0p5mm':[(-.0005,.0005)]}.items():
        lengths=sum((np.maximum(0,np.minimum(x[1:],hi)-np.maximum(x[:-1],lo)) for lo,hi in intervals),start=np.zeros(c['width_cells']))
        weights=np.broadcast_to(lengths,(c['thickness_cells'],len(lengths))).ravel()
        regions[name]=stats(final,weights)
        regions[name]['mean_joule_w_m3']=float(np.sum(case['q'][60e-9]*lengths)/np.sum(np.broadcast_to(lengths,final.shape)))
    return {'cell_dx_m':c['foil_width_m']/c['width_cells'],'cell_dy_m':c['foil_thickness_m']/c['thickness_cells'],
            'upper_solid_temperature':solid,'upper_solid_area_m2':cell_area*final.size,'upper_mean_joule_w_m3':float(np.mean(case['q'][60e-9])),
            'upper_max_cell_average_joule_w_m3':float(np.max(case['q'][60e-9])),
            'native_final':row,'joule_energy_right_endpoint_native_sum_j':energies,
            'upper_thermal_energy_from_cell_mean_j':upper_thermal,'native_total_thermal_energy_j':total_thermal,
            'both_conductors_mean_temperature_from_native_thermal_energy_k':c['initial_temperature_k']+total_thermal/(2*c['volumetric_heat_capacity_j_m3_k']*volume),
            'energy_integral_start_s':case['times'][0],'energy_integral_stop_s':case['times'][-1],
            'boundary_traces':traces,'upper_physical_regions':regions,'exported_lower_bulk_temperature':False,
            'checks':{'cell_average_joule_integral_matches_native_power':True,'upper_mean_thermal_energy_matches_native_joule_integral':True,'total_thermal_energy_matches_native_joule_integral':True}}

def comparison(a,b,ma,mb):
    assert a['times']==b['times'] and list(a['fields'])==list(b['fields'])
    allowed={'width_cells','thickness_cells','outside_cells','gap_cells','purpose','resolution_reference'}
    differences={k:[a['configuration'].get(k),b['configuration'].get(k)] for k in a['configuration']|b['configuration'] if a['configuration'].get(k)!=b['configuration'].get(k)}
    assert not (set(differences)-allowed),differences
    def delta(x,y):return {'128':x,'256':y,'256_minus_128':y-x,'relative_to_128':None if x==0 else (y-x)/x}
    d={}
    for metric in ('mean_k','max_k','area_weighted_p95_k','area_weighted_p99_k'):
        d['upper_solid_'+metric]=delta(ma['upper_solid_temperature'][metric],mb['upper_solid_temperature'][metric])
    for key in ('upper_mean_joule_w_m3','upper_max_cell_average_joule_w_m3','native_total_thermal_energy_j'):
        d[key]=delta(ma[key],mb[key])
    d['native_total_final_joule_power_w']=delta(ma['native_final']['total_joule_power_w'],mb['native_final']['total_joule_power_w'])
    d['integrated_total_joule_j']=delta(ma['joule_energy_right_endpoint_native_sum_j']['total_joule_power_w'],mb['joule_energy_right_endpoint_native_sum_j']['total_joule_power_w'])
    for body in ('upper','lower'):
        for face in ('top','bottom','left','right'):
            for metric in ('mean_k','max_k'):
                d[f'{body}_{face}_{metric}']=delta(ma['boundary_traces'][body][face][metric],mb['boundary_traces'][body][face][metric])
    return {'matched_recorded_clocks':True,'configuration_differences':differences,'metrics':d,'convergence_claim':False}

cmap=LinearSegmentedColormap.from_list('light_cold_kelvin',['#f5fbff','#cce7f2','#fff2bd','#fbbf6a','#ef7655','#ad2a44'])
plt.rcParams.update({'figure.facecolor':'white','axes.facecolor':'white','savefig.facecolor':'white','font.size':9,'axes.spines.top':False,'axes.spines.right':False})

def map_panel(ax,case,stamp,vmax):
    c=case['configuration'];im=ax.imshow(case['fields'][stamp],origin='lower',extent=(-2.5,2.5,0,.2),cmap=cmap,vmin=300,vmax=vmax,interpolation='nearest',aspect='auto')
    ax.set(title=case['label']+' | upper solid cell averages',xlabel='Physical width x (mm)',ylabel='Depth from upper gap face (mm)',yticks=[0,.1,.2])
    return im

def trace_panel(ax,cases,body,side,stamp,vmax):
    pair=('left','right') if side else (('bottom','top') if body=='upper' else ('top','bottom'))
    face_names={'top':'back' if body=='upper' else 'gap','bottom':'gap' if body=='upper' else 'back','left':'left edge','right':'right edge'}
    for n,case in enumerate(cases):
        for face,col in zip(pair,('#007a9a','#b44842')):
            data=case[body][face];i=data['times'].index(stamp);edges=data['edges']*1e3
            ax.stairs(data['temperature_k'][i],edges,baseline=None,color=col,lw=1.4 if n else 1,ls='--' if n==0 else '-',label=case['label']+' '+face_names[face])
    ax.set_ylim(300,vmax);ax.set_ylabel('Boundary patch temperature (K)');ax.grid(alpha=.18)
    ax.set_xlabel('Physical y (mm)' if side else 'Physical width x (mm)')
    ax.set_title(('Upper cathode' if body=='upper' else 'Lower return')+' | '+('side faces' if side else 'gap / back faces'))
    ax.legend(fontsize=7,ncol=2,loc='upper center',frameon=False)

def final_png(cases,vmax):
    fig=plt.figure(figsize=(12,9.2),dpi=150)
    gs=fig.add_gridspec(3,2,height_ratios=(.85,1.15,1.15),left=.075,right=.90,bottom=.09,top=.88,hspace=.52,wspace=.25)
    for i,case in enumerate(cases):im=map_panel(fig.add_subplot(gs[0,i]),case,60e-9,vmax)
    for row,body in enumerate(('upper','lower'),start=1):
        for col in (0,1):trace_panel(fig.add_subplot(gs[row,col]),cases,body,bool(col),60e-9,vmax)
    cbax=fig.add_axes([.925,.67,.014,.20]);fig.colorbar(im,cax=cbax,label='Temperature (K)')
    fig.suptitle('Matched native MQS + solid heating | 60 ns',fontsize=15,y=.974)
    fig.text(.5,.934,'5 mm foil / 5 mm gap / 0.2 mm thickness | exterior ±40 mm | current length 25 mm',ha='center',fontsize=10)
    fig.text(.5,.023,'Recorded cells and one-sided boundary patches; fixed Kelvin scales; thickness expanded. Constant solid; no phase change.',ha='center',fontsize=8)
    fig.savefig(OUT/'temperature_60ns_128_vs_256.png');plt.close(fig)

def compact_gif(case,vmax):
    times=list(case['fields']);indices=v.selected_indices(times,3)
    fig=plt.figure(figsize=(9,6),dpi=100)
    gs=fig.add_gridspec(2,2,height_ratios=(.85,1.2),left=.08,right=.90,bottom=.12,top=.84,hspace=.45,wspace=.28)
    ax=fig.add_subplot(gs[0,:]);im=map_panel(ax,case,times[0],vmax)
    axes=[fig.add_subplot(gs[1,i]) for i in (0,1)]
    cb=fig.add_axes([.925,.63,.016,.20]);fig.colorbar(im,cax=cb,label='Temperature (K)')
    title=fig.suptitle('',fontsize=13,y=.97)
    fig.text(.5,.90,'256×32 | native upper solid and direct electrode gap/back boundaries',ha='center',fontsize=9)
    fig.text(.5,.025,'Selected recorded frames; no interpolation or smoothing. Fixed Kelvin scale; constant-property solid.',ha='center',fontsize=8)
    frames=[]
    for i in indices:
        stamp=times[i];im.set_data(case['fields'][stamp]);title.set_text(f'Matched native heating | t = {stamp*1e9:.3f} ns')
        for panel,body in zip(axes,('upper','lower')):
            panel.clear();trace_panel(panel,[case],body,False,stamp,vmax)
        frames.append(v.capture(fig))
    plt.close(fig);path=OUT/'temperature_256_recorded.gif';count=v.save_gif(frames,path,8)
    return {'path':str(path),'frame_count':count,'actual_native_times_s':[times[i] for i in indices],'spatial_smoothing':False,'temporal_interpolation':False,'fps':8,'playback_clock':'equal frame durations; physical recorded timestamps shown, not constant physical-time speed'}

def main():
    assert not (OUT/'temperature-comparison.json').exists(),'Use a new explicit output prefix for a new accepted render.'
    bind(VERIFIED);bind(__file__)
    cases=[load('128x16'),load('256x32')];metrics={c['label']:record_metrics(c) for c in cases}
    compare=comparison(*cases,metrics['128x16'],metrics['256x32'])
    maximum=max(max(float(np.max(a)) for a in c['fields'].values()) for c in cases)
    maximum=max(maximum,max(float(np.max(face['temperature_k'])) for c in cases for body in ('upper','lower') for face in c[body].values()))
    vmax=math.ceil(maximum/1000)*1000
    final_png(cases,vmax);gif=compact_gif(cases[1],vmax)
    # Verify decoded PNG/GIF dimensions and unchanged consumed inputs.
    with Image.open(OUT/'temperature_60ns_128_vs_256.png') as im:png_size=list(im.size);assert im.mode in ('RGB','RGBA')
    for p,r in inputs.items():assert sha(p)==r['sha256'],p
    record={'status':'read_only_resolution_sensitivity_preview','convergence_claim':False,
            'runs':{c['label']:str(c['directory']) for c in cases},'source_reader':str(VERIFIED),
            'temperature_scale':{'vmin_k':300,'vmax_k':vmax,'fixed_linear_for_all_panels_and_frames':True},
            'spatial_smoothing':False,'temporal_interpolation':False,'upper_only_solid_export':True,'lower_boundaries_directly_exported':True,
            'metrics':metrics,'comparison':compare,'png_dimensions_px':png_size,'gif':gif,
            'analysis_wall_s':time.monotonic()-started,'analysis_cpu_s':resource.getrusage(resource.RUSAGE_SELF).ru_utime+resource.getrusage(resource.RUSAGE_SELF).ru_stime,'max_rss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,
            'runtime':{'python':sys.version,'numpy':np.__version__,'matplotlib':matplotlib.__version__,'Pillow':PIL.__version__,'cpu_affinity':sorted(os.sched_getaffinity(0)),'nice':os.getpriority(os.PRIO_PROCESS,0),'thread_environment':{k:os.environ.get(k) for k in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS')}}}
    assert record['runtime']['cpu_affinity']==[7] and record['runtime']['nice']>=15
    (OUT/'input-bindings.json').write_text(json.dumps(inputs,indent=2)+'\n')
    (OUT/'temperature-comparison.json').write_text(json.dumps(record,indent=2,allow_nan=False)+'\n')
    lines=['Matched native heating: 128x16 versus 256x32, exact 60 ns exports.','Fixed scales; direct material boundaries; no interpolation/smoothing.','Upper solid bulk export only; lower return boundaries were directly computed.','Both use ±40 mm magnetic exterior and 25 mm current length.','']
    for label,m in metrics.items():
        t=m['upper_solid_temperature'];lines.append(f"{label}: upper area mean {t['mean_k']:.6f} K; max cell-average {t['max_k']:.6f} K; final total Joule {m['native_final']['total_joule_power_w']:.9g} W; integrated total Joule {m['joule_energy_right_endpoint_native_sum_j']['total_joule_power_w']:.9g} J.")
    lines += ['','256 minus 128 relative differences:']
    for name in ('upper_solid_mean_k','upper_solid_max_k','upper_mean_joule_w_m3','upper_max_cell_average_joule_w_m3','native_total_final_joule_power_w','integrated_total_joule_j'):
        m=compare['metrics'][name];lines.append(f"{name}: {m['256_minus_128']:.9g}; {100*m['relative_to_128']:.6g}%.")
    lines += ['','See JSON for all eight boundary patch statistics, fixed-temperature area fractions and physical region integrals.','Joule time integration uses the actual native right endpoints from the first supported current knot; no prehistory is reconstructed.','Cell-integrated upper Joule matches native foil power; upper/total thermal energy matches corresponding native integrated Joule within recorded checks.','Two coarse resolutions measure sensitivity and do not establish spatial/material convergence. Constant stationary solid properties omit feedback and phase change.','No B arrays reconstructed, new fields solved, heating advanced, PIC/GPU run or shared sources edited. All consumed hashes verified unchanged.']
    (OUT/'handoff.txt').write_text('\n'.join(lines)+'\n')
    manifest={str(p.relative_to(OUT)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(OUT.iterdir()) if p.is_file() and p.name!='output-manifest.json'}
    (OUT/'output-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print('\n'.join(lines),flush=True)

if __name__=='__main__':main()
