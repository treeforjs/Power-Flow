from pathlib import Path
import io,tarfile,hashlib,json,time,fcntl,shutil
W=Path('/home/treefor/Documents/Codex/2026-10-28/we');P=Path('/home/treefor/projects/Power-Flow');D=P/'artifacts/quick-heating-and-orbit-checks-20261029';assert not D.exists();D.mkdir(parents=True)
class Chunks:
 def __init__(self):self.parts=[];self.f=None;self.used=0
 def write(self,b):
  n=len(b);offset=0
  while offset<n:
   if self.f is None or self.used==48*1024**2:
    if self.f:self.f.close()
    p=D/('native-runs.tar.gz.part%03d'%len(self.parts));self.parts.append(p);self.f=p.open('xb');self.used=0
   count=min(n-offset,48*1024**2-self.used);self.f.write(b[offset:offset+count]);self.used+=count;offset+=count
  return n
 def flush(self):
  if self.f:self.f.flush()
 def close(self):
  if self.f:self.f.close();self.f=None
class Joined:
 def __init__(self,parts):self.parts=iter(parts);self.f=None
 def read(self,n=-1):
  assert n>=0;out=[];left=n
  while left:
   if self.f is None:
    try:self.f=next(self.parts).open('rb')
    except StopIteration:break
   b=self.f.read(left);out.append(b);left-=len(b)
   if not b:self.f.close();self.f=None
  return b''.join(out)
 def close(self):
  if self.f:self.f.close()
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
manifest={};chunks=Chunks()
with open(W/'outputs/pic-profile/testing-core7.lock','a') as lease:
 fcntl.flock(lease,fcntl.LOCK_EX)
 with tarfile.open(fileobj=chunks,mode='w|gz') as tf:
  for case in ['128x16','256x32']:
   root=P/('runs/quick_heating_'+case+'_domain40mm_height25mm_20261029')
   run=json.loads((root/'source_run.json').read_text());assert run['passed'] and run['source_files_unchanged_after_run']
   for p in sorted(root.rglob('*')):
    if not p.is_file():continue
    assert not p.is_symlink();before=digest(p);name=case+'/'+str(p.relative_to(root));tf.add(p,name,recursive=False);assert digest(p)==before;manifest[name]={'bytes':p.stat().st_size,'sha256':before}
 chunks.close();joined=Joined(chunks.parts);seen=set()
 with tarfile.open(fileobj=joined,mode='r|gz') as tf:
  for e in tf:
   assert e.isfile() and not e.name.startswith('/') and '..' not in Path(e.name).parts
   assert e.size==manifest[e.name]['bytes'] and hashlib.sha256(tf.extractfile(e).read()).hexdigest()==manifest[e.name]['sha256'];seen.add(e.name)
 joined.close();assert seen==set(manifest)
 small=D/'analysis-source-and-previews.tar.gz'
 with tarfile.open(small,'w:gz') as tf:
  for prefix,root in [('heating-analysis',W/'outputs/heating-rerun-20261029'),('hull-drift-validation',W/'outputs/pic-profile/hull-drift-validation')]:
   for p in sorted(root.rglob('*')):
    if p.is_file() and not p.is_symlink() and '__pycache__' not in p.parts and p.suffix in {'.py','.cpp','.txt','.json','.jsonl','.csv','.sh','.png','.gif'} and p.stat().st_size<10*1024**2:
     tf.add(p,prefix+'/'+str(p.relative_to(root)),recursive=False)
 files={p.name:{'bytes':p.stat().st_size,'sha256':digest(p)} for p in chunks.parts+[small]}
(D/'manifest.json').write_text(json.dumps({'status':'native_two_resolution_60ns_heating_and_bounded_orbit_unit_tests','archives':files,'native_files':manifest,'production_PIC_resumed':False,'restore':'Concatenate native-runs.tar.gz.part000,part001,... in ascending order, then read as a gzip tar archive. Verify every part SHA256 and member SHA256 first.'},indent=2)+'\n')
(D/'README.txt').write_text('Matched solid magnetic/heating quick runs and frozen electron-orbit checks.\n\n128x16 and256x32 cells per foil; both run continuously from0.749788055492ns through60ns with5mmwidth,0.2mmthickness,5mmgap,25mm current length and±40mm exterior. Both temperature histories and native Az/rate fields originate in each same run. Two real MPI ranks are bound to OS CPUs6/7 via translated hwloc PU indices12/14. Numerical dependencies remain frozen.\n\nBoth direct electrode surface histories are retained; the solid cell-average bulk export covers the upper foil only. Hot corner/patch values remain mesh sensitive, and material properties are constant with no phase change. These are quick conditional studies, not material/grid-converged predictions.\n\nRaw native runs are preserved across48MiB gzip-tar parts with checksums; analysis-source-and-previews.tar.gz contains replay/analysis/plotting code, hashed evidence, preview images and frozen pic_boris unit benchmarks. No third-party binary libraries are included. The orbit checks do not run PIC or model the full pulsed finite target. The primary long PIC run remains paused and its original inputs/checkpoints are preserved separately. New heating inputs require a fresh consistent PIC history if adopted.\n')
print(json.dumps({'parts':len(chunks.parts),'raw_files':len(manifest),'archive_bytes':sum(x['bytes'] for x in files.values()),'directory':str(D)},indent=2),flush=True)
