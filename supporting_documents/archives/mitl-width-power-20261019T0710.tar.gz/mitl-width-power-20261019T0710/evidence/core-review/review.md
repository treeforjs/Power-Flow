# Matched-input width assembly static review

The new assembly module and frozen design were read before its numerical tests
or positive producer batch. No substantive correctness or claims issue was
identified and no edits were requested. The module performs no scalar time
integration. It admits three supplied unit-reference-area histories, evaluates
their saved-state RHS records once per source/sample identity and reuses those
records across the two three-patch hypotheses.

Canonical exact geometry and complete common problem, state, cost, provenance
and logical-grid association are explicit. Actual patch area multiplies areal
fields once. Unprojected products form extensive totals and signed differences
before final projection. The exact prescribed power identity is independent of
rounded scalar prescribed-input channels and separately accumulated input.
Every patch retains its own temperature and full source/time/state association.

Arithmetic admission and signed projection/residual diagnostics do not certify
the nonlinear trajectories. Fresh references for the three new forcing cases
and independent geometry/aggregation/contrast checks remain required. This
review ran no scalar evolution, flux evaluation, test or numerical model.
It does not qualify lateral conduction, real foil geometry or material,
physical water coverage, monolayers, spectra, Hall, FLASH, gap or host/owner
coupling.
