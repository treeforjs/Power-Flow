"""Freeze bounded static scientific/interface review of new width assembly."""
import datetime as dt
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = Path('/workspace/Power-Flow/mhdlab/thermal_width_power_reference.py')
EXPECTED_SHA = 'ed796e54e9a46a9981459aabc5a09d4da28479f776ef4ce601f85e108cba930c'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

if (ROOT / 'completion.json').exists():
    raise RuntimeError('Refuse repeated width core-review freeze')
status = json.loads(Path('/workspace/research_work/mitl-upstream-status.json').read_text())
assert status['active_lease_owner'] == 'mitl-upstream-20261019T0710'
assert dt.datetime.fromisoformat(status['active_editing_lease_until_utc']) > dt.datetime.now(dt.timezone.utc)
assert sha(SOURCE) == EXPECTED_SHA
design_path = ROOT.parent / 'core/design.json'
design = json.loads(design_path.read_text())
assert design['source']['sha256'] == EXPECTED_SHA
checks = [
    ('exact_geometry_and_area_once', 'Canonical signed width coordinates and positive common length give exact Fraction areas and required 1/4,1/2,1/4 weights. Only areal fields receive true patch area; source extensive fields are checked but never rescaled.'),
    ('unit_reference_area_and_common_inputs', 'Typed problem/reservoir records are revalidated, unit scalar area and positive base activation energy are mandatory, and complete problem/state/cost/energy-reference/provenance data must agree.'),
    ('history_identity_and_grid', 'Canonical whole-history hashes bind supplied data before and after admission/assembly. One constant-power source segment, complete strict integer indices and exact logical time grids are checked.'),
    ('sample_admission', 'Finite canonical source floats, initial state, supported N/T, cumulative monotonicity and unit-area extensive mappings are checked. Derived channels must match exact represented-input projections.'),
    ('arithmetic_budget_qualification', 'The explicit scale/step ulp admission budget constrains arithmetic residuals without repairing them. It is stated separately from ODE truncation error or physical uncertainty.'),
    ('matched_total_power', 'Exact area times assigned source power must match across hypotheses. Exact prescribed energy is retained separately from projected scalar prescribed channels and integrated-input roundoff.'),
    ('RHS_cache', 'Each distinct admitted history/sample receives one complete RHS evaluation before patch copies. Full rate records and flux are cached under source identity/index; no time evolution occurs inside assembly.'),
    ('full_mixture', 'Each patch retains geometry, state, history hash, exact logical time, N, T, release flux and channels. No averaged temperature or single thermal velocity substitutes for the mixture.'),
    ('unprojected_totals_and_differences', 'Exact represented areal-area products are summed before total projection; signed nonuniform-minus-uniform differences subtract unprojected totals. No expected enhancement or sign is encoded.'),
    ('energy_and_inventory_signs', 'Whole-area initial inventory, supplied D/I, wall thermal change, gas channels and external input enter separately recomputed residuals with the declared signs.'),
    ('projection_diagnostics', 'Each extensive result retains exact numerator/denominator, nearest float and signed rounding error/flags. Lost nonzero underflow or overflow rejects; no clipping or renormalization appears.'),
    ('scope', 'The new module admits/assembles supplied data and computes new saved-state RHS rates only. It calls no scalar time evolution and supplies no lateral conduction, actual foil/water/monolayer, spectra, Hall, FLASH, gap or owner acceptance.')
]
notes = '''# Matched-input width assembly static review

The new assembly module and frozen design were read before its numerical tests
or positive producer batch. No substantive correctness or claims issue was
identified and no edits were requested. The module performs no scalar time
integration. It admits three supplied unit-reference-area histories, evaluates
their saved-state RHS records once per source/sample identity and reuses those
records across the two three-patch hypotheses.

Canonical exact geometry and complete common problem, state, cost, provenance
and logical-grid association are explicit. Actual patch area multiplies areal
fields once. Unprojected products form extensive totals and signed differences
before final projection. The exact prescribed power identity is independent of
rounded scalar prescribed-input channels and separately accumulated input.
Every patch retains its own temperature and full source/time/state association.

Arithmetic admission and signed projection/residual diagnostics do not certify
the nonlinear trajectories. Fresh references for the three new forcing cases
and independent geometry/aggregation/contrast checks remain required. This
review ran no scalar evolution, flux evaluation, test or numerical model.
It does not qualify lateral conduction, real foil geometry or material,
physical water coverage, monolayers, spectra, Hall, FLASH, gap or host/owner
coupling.
'''
(ROOT / 'review.md').write_text(notes)
report = {
    'schema': 'mitl-width-power-static-core-review-v1',
    'status': 'review_complete_no_substantive_issue_identified',
    'completed_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
    'reviewed_source_path': str(SOURCE), 'reviewed_source_sha256': EXPECTED_SHA,
    'reviewed_design_path': str(design_path), 'reviewed_design_sha256': sha(design_path),
    'full_new_source_and_design_read': True,
    'checks': [{'area': name, 'static_review_complete': True, 'finding': finding} for name, finding in checks],
    'findings': [], 'source_changes_requested': False,
    'scalar_evolution_or_flux_evaluation_executed': False,
    'numerical_models_or_tests_executed': False, 'scientific_module_imported': False,
    'producer_or_oracle_executed': False, 'old_models_or_audits_repeated': False,
    'public_source_edits_by_reviewer': False,
    'physical_parameters_validated': False, 'host_budget_accepted': False,
    'limits': ['Static scientific/domain/interface source inspection only.',
               'Arithmetic admission is separate from nonlinear trajectory accuracy and physical uncertainty.',
               'Actual new scalar/reference/aggregation/contrast evidence belongs to separate checks.',
               'Manufactured independent stationary patches only; no physical water/material/monolayer/spectral or host acceptance.'],
    'artifact_sha256': {p.name: sha(p) for p in sorted(ROOT.iterdir()) if p.is_file()}
}
path = ROOT / 'completion.json'
path.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'completion': str(path), 'sha256': sha(path), 'schema': report['schema'],
                  'status': report['status'], 'reviewed_source_sha256': EXPECTED_SHA}, indent=2))
