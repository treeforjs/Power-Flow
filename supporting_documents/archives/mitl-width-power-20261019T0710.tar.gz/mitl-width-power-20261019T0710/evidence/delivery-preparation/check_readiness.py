"""Read source text, AST literals and frozen pins without importing delivery helpers."""
import ast
import hashlib
import json
from pathlib import Path
import subprocess

WORK = Path(__file__).resolve().parents[1]
REPO = Path('/workspace/Power-Flow')
EXPECTED_HEAD = 'df8eb7026b3a712bf641cbb4d136c497e8af50ba'
EXPECTED_BASE = '3bd20e44ba617cca44cbac2df993e1face2ec221'
EXPECTED_RECORDS = {
    'producer_run': '21031ac2ef2f1a59bff3ed2afa3efbf7de6b984a4b09fe7d64f0ad5ba2e44cd7',
    'producer_completion': 'b0d71df7d50a1cca9d84737b276a0308b411fbab33a9e06a9b49b320fff45c66',
    'parser_guards': '432753b45f7f02e34045a1d96bb61da971d8e3689815aa68d80f4f924cf5260b',
    'export_amendment': '7a58d40f8450f9914848168fc96490d1dd263674e93435b35cef05e1afde80cb',
    'plot_correction': '58256631f84206fa5430eeca192565e5c61790ae526ac71412518d24c47f7360',
    'producer_before_run': '1ff1d7ea5bb339fa8263a7efdcd55a5b436f7e8aa44d0f78c702ca1565ad7b4e',
    'tests_completion': '32aa8affae971ceab99a6724b88d81d90d75a85fcaa02bd80eeb0246c8599273',
    'core_freeze': 'a4099a10d2bd9357c7ce9ce8639e7c58154b70040c6d7bb4f9c662a5180f0815',
    'static_core_review': '0d816422583d085fd32de088b9fde173ec07b532b350fceb6ee12885cd70bd93',
    'oracle_completion': 'b1e463a848e5fe6bf759e05d7b8016edfd3d8db12b0a0698ecfb8f8ce2245086',
    'oracle_report': '5a0b0cfce3fa594376718579645b8ee424bf80b6de0ac5ade0eeab829fc3d84c',
    'oracle_summary': 'ae7e5680e4d559943b2aaa7d0fbe5a6688edb06dcf50e5bbeaa4d50620b9e8cc',
    'oracle_review': 'd2a42ce4fb5abb29f9ac358691f7373a1f089cac4a33108a960a2931590a0b39',
    'root_result_association': 'd20546dfb2aff0015e106168e54745e8ca9b0f2484913f2f086ed114bcd737a2',
    'selection': '7c58c00492f72893a7d6d12e54821ccd5e21e004bce6ccd297607d066ee80659',
}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def literal(tree, key):
    found = [node.value for node in ast.walk(tree) if isinstance(node, ast.Assign)
             and any(isinstance(target, ast.Name) and target.id == key for target in node.targets)]
    assert len(found) == 1, key
    return ast.literal_eval(found[0])


def main():
    helper_names = ('prepare_delivery.py', 'freeze_delivery.py', 'verify_delivery.py')
    trees = {}
    for name in helper_names:
        text = (WORK/name).read_text()
        compile(text, str(WORK/name), 'exec')
        trees[name] = ast.parse(text)
        assert 'raise RuntimeError(' not in text
    prepare, freeze = trees['prepare_delivery.py'], trees['freeze_delivery.py']
    assert literal(prepare, 'HEAD') == EXPECTED_HEAD and literal(prepare, 'BASE') == EXPECTED_BASE
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == EXPECTED_HEAD
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=REPO, text=True).strip()
    public = literal(prepare, 'PUBLIC')
    assert len(public) == 5 and len(literal(prepare, 'WRAPPERS')) == 2
    assert set(subprocess.check_output(['git', 'diff', '--name-only', EXPECTED_BASE, EXPECTED_HEAD], cwd=REPO, text=True).splitlines()) == set(public)
    roles = literal(freeze, 'REPORT_PATHS')
    assert set(roles) == set(EXPECTED_RECORDS) and len(roles) == 15
    actual = {key: sha(WORK/name) for key, name in roles.items()}
    assert actual == EXPECTED_RECORDS
    results = literal(freeze, 'results')
    assert results['distinct_new_scalar_histories'] == 3 and results['unique_scalar_samples'] == 195
    assert results['expanded_patch_samples'] == 390 and results['aggregate_samples'] == 130 and results['comparison_samples'] == 65
    assert results['actual_scalar_evolutions_in_adapter_tests'] == results['actual_scalar_RHS_evaluations_in_adapter_tests'] == 0
    assert results['reference_precision_grids'] == 6 and results['saved_state_flux_evaluations_across_two_precision_grids'] == 390
    assert results['portable_executions_performed'] is False and results['old_cases_or_suites_replayed'] is False
    record = {'schema': 'mitl-width-power-delivery-helper-readiness-v1', 'status': 'ready_for_root_execution',
        'source_commit': EXPECTED_HEAD, 'base_commit': EXPECTED_BASE,
        'helper_sha256': {name: sha(WORK/name) for name in helper_names},
        'record_paths': roles, 'record_sha256': actual, 'public_source_sha256': {name: sha(REPO/name) for name in public},
        'results': results, 'selection_key': 'selected_task',
        'validation_scope': 'Source text compilation, AST literal and frozen data-pin reads only; delivery helpers not imported or executed.',
        'scientific_model_test_or_oracle_calls': 0, 'assembly_freeze_or_verification_helpers_executed': False,
        'portable_execution_claimed': False}
    (WORK/'delivery-preparation/helper-readiness.json').write_text(json.dumps(record, indent=2, allow_nan=False)+'\n')
    print(json.dumps(record, indent=2))


if __name__ == '__main__':
    main()
