"""Prepare a conditional saved-history boundary task without numerical runs."""

from hashlib import sha256
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
PASS = ROOT.parent
PUBLIC = Path("/workspace/Power-Flow")


def pin(path: Path) -> dict:
    return {"path": str(path), "sha256": sha256(path.read_bytes()).hexdigest()}


def write(name: str, document: dict) -> None:
    path = ROOT / name
    if path.exists():
        raise ValueError(f"refusing to replace existing proposal record: {name}")
    path.write_text(json.dumps(document, indent=2, allow_nan=False) + "\n")


inputs = {
    "current_width_source": pin(PUBLIC / "mhdlab/thermal_width_power_reference.py"),
    "current_width_freeze": pin(PASS / "core/source-freeze.json"),
    "current_width_design": pin(PASS / "core/design.json"),
    "current_static_review": pin(PASS / "core-review/completion.json"),
    "existing_window_source": pin(PUBLIC / "mhdlab/temkin_planar.py"),
    "existing_window_guide": pin(PUBLIC / "docs/source_window_resolution.md"),
    "cached_queue": pin(Path("/workspace/research_work/mitl-upstream-status.json")),
    "scope_inventory_log": pin(PASS / "next-window-scope-inventory.log"),
}
inventory = {
    "schema": "mhdlab-coupled-window-next-task-inventory-v1",
    "status": "declaration_inventory_only",
    "inputs": inputs,
    "existing_scope": {
        "source_quote": "Deplete independent local pools using qualified frozen-midpoint solves.",
        "source_path": str(PUBLIC / "mhdlab/temkin_planar.py"),
        "source_line": 256,
        "guide_quote": "frozen-temperature intervals. It reads coordinates, rather than evolving a new",
        "guide_line": 6,
        "distinction": "Existing interval/window controls condition a supplied frozen-temperature source. They do not admit the new coupled N/T histories as a continuously varying emission-temperature measure.",
    },
    "new_evidence_available_after_current_pass": [
        "Three distinct64-step constant-power coupled histories with65 saved nodes each and explicit source associations.",
        "Cumulative emitted parents, T, all gross energy channels, scalar residuals, exact logical times and cached endpoint Gamma/Tdot.",
        "Explicit shared scalar-history identities across six hypothesis/patch references with exact areas and common state.",
    ],
    "independent_checkpoint_availability": {
        "declared_by_current_verification_owner": True,
        "retained": "65 knot reference states/channels/Gamma per precision case, plus local transformed s/Z/b states.",
        "not_retained": "Dense Taylor coefficients or substep polynomials.",
        "consequence": "No existing off-knot reference claim. Future off-knot/window moment checks require a fresh bounded query calculation seeded from saved independent states.",
        "new_runs_requested_during_planning": False,
    },
    "old_numerical_source_test_or_oracle_replayed": False,
    "novelty_scope": "A new boundary interface for coupled constant-power emission and temperature mixtures; no global unpublished-code search is claimed.",
}
write("inventory.json", inventory)
proposal = {
    "schema": "mhdlab-coupled-emission-window-proposal-v1",
    "task_id": "constant-power-coupled-emission-window-interface",
    "status": "conditional_on_current_width_source_independent_acceptance",
    "purpose": "Advance the queued full time/state/temperature mixture handoff with bounded emission-window number, time and thermal-energy moments from saved coupled histories, without assigning velocities or invoking transport.",
    "inventory": pin(ROOT / "inventory.json"),
    "inputs": inputs,
    "proposed_public_scope": [
        "mhdlab/coupled_emission_windows.py",
        "tests/test_coupled_emission_windows.py",
        "tools/export_coupled_emission_windows.py",
        "configs/coupled_emission_windows_manufactured.json",
        "docs/coupled_emission_windows.md",
    ],
    "bounded_source": {
        "cases": ["uniform_power", "edge_power", "middle_power"],
        "power_w_m2": [60000000.0, 90000000.0, 30000000.0],
        "constant_power_only": True,
        "source_histories_evolved_again": False,
        "source_RHS_evaluated_again": False,
        "source_assembly_repeated": False,
        "support": "Only the exact finite logical support of the accepted current saved assembly; no endpoint padding, extrapolation or held tail.",
        "admission": "Bind an explicit approved source report hash, exact saved-file hashes and canonical source histories. Validate the source/cache/patch/time/state/area associations as data without calling old or new numerical producers.",
        "scheduled_power_jump_gate": "Not supported. A single shared endpoint Tdot is insufficient for scheduled power jumps; a future separate one-sided derivative and segment admission contract would be required.",
    },
    "piecewise_polynomial_contract": {
        "coordinate": "u=(t-t0)/h with exact positive h from saved logical-time Fractions; all coefficients are rational functions of represented saved endpoint data.",
        "emitted_parent_controls": ["M0", "M0+h*Gamma0/3", "M1-h*Gamma1/3", "M1"],
        "temperature_controls": ["T0", "T0+h*Tdot0/3", "T1-h*Tdot1/3", "T1"],
        "emission_measure": "dM/du is the quadratic Bernstein derivative of the cumulative cubic; Gamma_interpolant(t)=(dM/du)/h.",
        "positive_guards": [
            "Require finite initial inventory and0<=M0<=M1<=N_initial at each cell.",
            "Require all four emitted-parent Bernstein controls to be nondecreasing; this sufficient conservative guard makes dM nonnegative throughout each cell.",
            "Require all temperature Bernstein controls within the supplied positive temperature support; convex-hull bounds then contain the entire interpolant.",
            "Reject unsupported intervals, nonfinite/unrepresentable coefficients or outputs, lost positive mass, mismatched endpoints and invalid derivative/state/source associations.",
            "No slope capping, clipping, monotonicity repair, fitted normalization or fallback to constant temperature.",
        ],
        "inventory_qualification": "The measure interpolates stored cumulative M. It does not redefine stored N=N_initial-M or erase the scalar inventory residual; original endpoint N and residuals remain associated separately.",
        "kinetic_qualification": "The positive polynomial measure approximates the saved coupled trajectory. It is not a new exact solution of Gamma(N,T) between nodes.",
    },
    "window_quantities": {
        "number": "M(b)-M(a), splitting at every source cell boundary and evaluating exact polynomial differences.",
        "time_moments": "Direct exact polynomial integrals of t and t^2 against dM; retain centered moments about a declared local anchor before normalized projections.",
        "temperature_moments": "Direct exact polynomial integrals of T and T^2 against dM, preserving the time/temperature association. A statistical mean is not substituted for the temperature mixture.",
        "translation": "2*kB*integral(T dM), with exact SI kB and positive polynomial products; never inferred by a stored-energy residual or by an effective-temperature fit.",
        "internal_and_removal": "Fixed supplied I*DeltaM and D*DeltaM remain separate; kinetic Ea is not debited.",
        "gross_wall": "D*DeltaM+I*DeltaM+2*kB*integral(T dM).",
        "input": "Exact prescribed constant P*(b-a), separately from stored integrated-input rounding.",
        "thermal_change": "C_A*(T_interpolant(b)-T_interpolant(a)) retained as its own signed quantity.",
        "residuals": "Report the polynomial window energy defect and all source residual references. Do not force polynomial thermal/number/translation consistency with stored RK cumulative channels.",
        "exact_zero_mass": "Represent exact zero explicitly and mark normalized moments unavailable; nonzero projection underflow or overflow rejects instead of silently becoming zero.",
        "representation": "Exact rational coefficients, masses, products, sums and moments; explicit finite projected values and rounding diagnostics. Area is applied once to areal window quantities.",
    },
    "source_comparisons": {
        "stored_RK_translation": "At original-knot window endpoints, compare direct polynomial translation to the stored cumulative-X difference and preserve its signed interpolation discrepancy. For off-knot endpoints, mark this stored-X comparison unavailable unless an additional independently declared cumulative-X representation is introduced in a fresh scope.",
        "stored_RK_other_channels": "Likewise preserve source knot channel and residual differences; neither re-normalize the emission measure nor overwrite stored source quantities.",
        "independent_IVP": "New reference window quantities establish finite interpolation-plus-source error. Separate them from polynomial algebra checks and source RK residuals.",
        "error_claims": "Finite reference/quadrature changes estimate numerical stability only; no rigorous interpolation enclosure, physical uncertainty or spectroscopic significance is inferred.",
    },
    "bounded_queries": [
        {"window_id": "complete_source_support", "start_duration_fraction": "0/1", "stop_duration_fraction": "1/1", "knot_aligned": True},
        {"window_id": "early_interior", "start_duration_fraction": "1/16", "stop_duration_fraction": "5/16", "knot_aligned": True},
        {"window_id": "off_knot_interior", "start_duration_fraction": "23/128", "stop_duration_fraction": "71/128", "knot_aligned": False},
    ],
    "reuse_and_output": {
        "distinct_source_window_pairs": 9,
        "hypothesis_patch_window_references": 18,
        "source_reuse": "Calculate each distinct source/window measure once, then attach the accepted patch areas and identities without repeating scalar evolution, RHS calls or identical window integration.",
        "preserve": ["source hashes", "constant-power provenance", "exact support", "patch geometry/area", "state identity", "time/temperature polynomial coefficients", "number/time/temperature/energy moments", "source residuals", "interpolation discrepancy", "reference-error qualification"],
        "owner_boundary": "A reviewable source-mixture handoff only. No velocity sampler, packet launch, collection kernel, owner implementation or host-budget acceptance is supplied.",
    },
    "new_verification": [
        "Freeze the pure source-data/window implementation and all query/tolerance declarations before its sole new export batch.",
        "Use new manufactured polynomial fixtures with independent closed-form moment values, plus invalid monotonicity/domain/support/association/representation controls. Do not run old window or scalar suites.",
        "Reuse saved independent knot states/channels for knot-aligned cumulative checks where their precision supports the contrast.",
        "Because the current reference stores no dense Taylor coefficients, perform a fresh bounded independent query calculation seeded from saved independent states for new off-knot points and moment integrals. Do not repeat unchanged full-state grids for activity.",
        "Independently compare number, direct positive translation/time/T moments and per-patch/full-area mixtures; establish new window contrast budgets before the first calculation.",
        "Treat failed conservative polynomial guards or unresolved interpolation/reference discrepancies as explicit rejection; a finer new source run would require a fresh justified scope rather than an automatic retry.",
    ],
    "retained_queue_and_gates": [
        "Keep the queued owner full time/state/temperature/velocity mixture and fixed linear full-width response controls; this task supplies upstream evidence only.",
        "Actual physical water inventory, monolayer convention, initial pool allocation, material kinetics/thermodynamics and state/fragment energy pathways remain externally gated.",
        "No CR, Boltzmann, molecular-state tables, gap kinetics, Hall, FLASH, owner code or Quark runners are touched.",
        "Actual VUV reduction/response/noise/covariance and physical spectral discrimination remain separately gated.",
        "Verified Fe2O3(001) metadata does not supply unavailable full-text parameters; no adoption. Joly/Li-Dylla blocked routes are not retried.",
        "Licensed FLASH/workstation and actual field/unit/material interfaces retain their setup and benchmark gates.",
    ],
    "current_width_independent_pass_required_before_selection": True,
    "numerical_execution_during_planning": False,
    "public_implementation_started": False,
}
write("coupled_emission_window_proposal.json", proposal)
write("conditional-selection.json", {
    "schema": "mhdlab-upstream-conditional-selection-v1",
    "status": "waiting_for_actual_width_source_independent_acceptance_and_report_review",
    "task_id": proposal["task_id"],
    "proposal": pin(ROOT / "coupled_emission_window_proposal.json"),
    "required_actual_gate": "Saved current-pass independent report and completion, final report-bound method review, sole three-history producer batch and final adapter/test provenance must pass and be hash-bound.",
    "fresh_lease_required_before_public_work": True,
    "final_selection_written": False,
    "numerical_execution": False,
})
print(json.dumps({
    "proposal": pin(ROOT / "coupled_emission_window_proposal.json"),
    "inventory": pin(ROOT / "inventory.json"),
    "conditional_selection": pin(ROOT / "conditional-selection.json"),
    "numerical_execution": False,
}, indent=2))
