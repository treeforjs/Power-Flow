"""Bind the next task only after the actual width-source acceptance is final."""

import argparse
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
PASS = ROOT.parent
PUBLIC = Path("/workspace/Power-Flow")
CORE_PATH = "mhdlab/thermal_width_power_reference.py"
CORE_SHA = "ed796e54e9a46a9981459aabc5a09d4da28479f776ef4ce601f85e108cba930c"


def require(condition: bool, reason: str) -> None:
    if not condition:
        raise ValueError(reason)


def pin(path: Path) -> dict:
    return {"path": str(path), "sha256": sha256(path.read_bytes()).hexdigest()}


def read(relative: str, expected: str) -> tuple[dict, dict]:
    require(len(expected) == 64 and all(char in "0123456789abcdef" for char in expected), "an approved lower-case SHA256 is required")
    path = PASS / relative
    record = pin(path)
    require(record["sha256"] == expected, f"approved acceptance pin mismatch: {relative}")
    return json.loads(path.read_text()), record


def write(name: str, document: dict) -> None:
    path = ROOT / name
    require(not path.exists(), f"refusing to replace frozen selection artifact: {name}")
    path.write_text(json.dumps(document, indent=2, allow_nan=False) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--independent-completion-sha256", required=True)
    parser.add_argument("--independent-report-sha256", required=True)
    parser.add_argument("--oracle-review-sha256", required=True)
    parser.add_argument("--producer-completion-sha256", required=True)
    args = parser.parse_args()
    require(pin(PUBLIC / CORE_PATH)["sha256"] == CORE_SHA, "frozen adapter changed")
    proposal, proposal_pin = read(
        "next-upstream-selection/coupled_emission_window_proposal.json",
        "bc7cf2dd909b9fe4057f2a0301a14b37eee9671e383fc45d2515603608f45cd9",
    )
    independent, independent_pin = read("independent-verification/completion.json", args.independent_completion_sha256)
    report, report_pin = read("independent-verification/oracle-initial/report.json", args.independent_report_sha256)
    review, review_pin = read("oracle-review/completion.json", args.oracle_review_sha256)
    producer, producer_pin = read("producer/completion.json", args.producer_completion_sha256)
    tests, tests_pin = read("tests/completion.json", "32aa8affae971ceab99a6724b88d81d90d75a85fcaa02bd80eeb0246c8599273")
    core_review, core_review_pin = read("core-review/completion.json", "0d816422583d085fd32de088b9fde173ec07b532b350fceb6ee12885cd70bd93")

    require(producer["status"] == "passed_production_and_saved_export_checks", "producer not accepted")
    require(producer["positive_batch_count"] == 1, "producer batch count changed")
    require(tuple(producer[key] for key in ("distinct_scalar_evolution_calls", "distinct_scalar_history_count", "unique_scalar_samples", "expanded_patch_samples", "aggregate_samples", "comparison_samples")) == (3, 3, 195, 390, 130, 65), "producer scope changed")
    require(tuple(producer["cache"][key] for key in ("distinct_scalar_histories", "scalar_samples", "rhs_evaluations", "patch_history_references", "scalar_evolutions_by_assembly")) == (3, 195, 195, 6, 0), "cache/reuse scope changed")
    require(producer["numerical_run_code_sha256"][CORE_PATH] == CORE_SHA, "producer adapter association mismatch")
    require(producer["open_substantive_findings"] == [] and producer["old_suites_sources_or_numerical_cases_replayed"] is False, "producer replay or finding declared")
    producer_report_path = PASS / producer["report_path"]
    producer_report_pin = pin(producer_report_path)
    require(producer_report_pin["sha256"] == producer["report_sha256"], "producer report changed")
    producer_report = json.loads(producer_report_path.read_text())
    require(producer_report["code_sha256"][CORE_PATH] == CORE_SHA, "saved report adapter pin mismatch")
    assembly_pin = pin(PASS / producer["assembly_path"])
    require(assembly_pin["sha256"] == producer["assembly_sha256"] == producer_report["assembly_sha256"], "saved assembly association mismatch")

    require(tests["all_checks_passed"] is True and tests["new_adapter_tests_passed"] == 34, "new adapter tests not qualified")
    require(tests["test_case_executions"] == 34 and tests["targeted_test_runs"] == 1, "adapter tests replayed")
    require(tests["actual_scalar_evolutions"] == 0 and tests["actual_scalar_RHS_evaluations"] == 0, "assembly fixture tests called scalar producers")
    require(tests["public_source_sha256"][CORE_PATH] == CORE_SHA, "test adapter pin mismatch")
    require(core_review["source_changes_requested"] is False and core_review["findings"] == [], "core review has findings")
    require(independent["status"] == "passed" and independent["all_checks_passed"] is True, "independent completion not passed")
    require(report["status"] == "passed" and report["all_checks_passed"] is True, "independent report not passed")
    require(independent["report_sha256"] == report_pin["sha256"], "independent report association mismatch")
    require(independent["producer_report_sha256"] == producer_report_pin["sha256"], "independent source report association mismatch")
    require(tuple(independent[key] for key in ("new_scalar_cases", "unique_scalar_reference_samples", "unique_scalar_flux_references", "expanded_patch_samples_checked", "aggregate_samples_checked", "difference_samples_checked", "post_source_cache_records_verified", "independent_RHS_field_comparisons")) == (3, 195, 195, 390, 130, 65, 195, 1560), "independent reference/check scope changed")
    require(independent["new_independent_oracle_runs"] == 1 and independent["old_case_or_oracle_runs"] == 0 and independent["producer_imports_or_calls"] == [], "independent numerical replay or producer use declared")
    require(independent["dense_Taylor_coefficients_or_off_knot_queries_retained"] is False, "checkpoint scope changed; requalify the next proposal")
    require(review["owner_report_sha256"] == report_pin["sha256"], "final method review does not bind actual report")
    require(review["status"] == "accepted" and review["further_changes_requested"] is False, "final method review not accepted")
    require(all(finding["status"] == "repaired_before_first_reference" for finding in review["findings"]), "final method review has unresolved findings")
    require(review["completed_report_bound_without_numerical_replay"] is True, "final method review did not bind report without replay")

    status_path = Path("/workspace/research_work/mitl-upstream-status.json")
    status = json.loads(status_path.read_text())
    retained_queue = [item for item in status["next_work"] if item["priority"] in range(2, 8)]
    require([item["priority"] for item in retained_queue] == list(range(2, 8)), "saved queue2-7 is incomplete")
    math_pin = pin(ROOT / "mathematical-notes.json")
    require(math_pin["sha256"] == "58052ddb0c59101360922d55ae2e8baf5669fe5f960fc458d306df04c71b0280", "window mathematics notes changed")
    acceptance = {
        "schema": "mhdlab-emission-window-predecessor-acceptance-v1",
        "status": "actual_saved_width_source_acceptance_bound",
        "records": {"adapter_review": core_review_pin, "adapter_tests": tests_pin,
                    "producer_completion": producer_pin, "producer_report": producer_report_pin,
                    "assembly": assembly_pin, "independent_completion": independent_pin,
                    "independent_report": report_pin, "final_independent_method_review": review_pin},
        "adapter_sha256": CORE_SHA,
        "observed_source_scope": {"new_scalar_evolutions": 3, "source_samples": 195,
                                  "cached_RHS_evaluations": 195, "patch_references": 6,
                                  "expanded_patch_samples": 390, "aggregate_samples": 130,
                                  "comparison_samples": 65},
        "source_code_versions": {"numerical_run": producer["numerical_run_code_sha256"],
                                 "final_public_cli_sha256": producer["final_public_cli_sha256"],
                                 "plot_support_amendment": producer["plot_support_amendment"]},
        "independent_report_observed_scalars": {key: value for key, value in report.items() if not isinstance(value, (dict, list))},
        "resolved_pre_reference_method_findings": review["findings"],
        "planning_readback_only": True,
        "numerical_execution_by_selection": False,
        "acceptance_limits": "Manufactured scalar/width algebra and reference-error qualification only; no physical water/material/velocity/owner/transport/observation acceptance.",
    }
    write("predecessor-acceptance.json", acceptance)
    selection = {
        "schema": "mhdlab-upstream-selected-task-v1",
        "status": "selected_pending_fresh_bounded_lease",
        "selected_utc": datetime.now(timezone.utc).isoformat(),
        "task_id": proposal["task_id"],
        "selected_task": "Constant-power saved coupled-history emission-window number/time/temperature/energy mixture interface.",
        "proposal": proposal_pin,
        "mathematical_notes": math_pin,
        "inventory": pin(ROOT / "inventory.json"),
        "preserved_conditional_selection": pin(ROOT / "conditional-selection.json"),
        "predecessor_acceptance": pin(ROOT / "predecessor-acceptance.json"),
        "selected_reason": "The accepted coupled width source now supplies complete emission/temperature endpoint derivatives. A bounded pure-data window measure concretely advances the queued mixture handoff while preserving all owner and physical-inference gates.",
        "work_budget": {"distinct_saved_sources": 3, "windows": 3, "unique_source_window_pairs": 9,
                        "expanded_patch_window_references": 18, "scalar_evolutions": 0,
                        "source_RHS_reevaluations": 0, "source_assembly_replays": 0,
                        "velocity_samples": 0},
        "scope": "Constant power only. Off-knot references require new bounded queries seeded from saved independent states because dense Taylor checkpoints were not retained.",
        "error_layers": ["exact polynomial algebra/projection", "source residual/allocation versus interpolation discrepancy", "fresh independent IVP/query error"],
        "retained_queue_source": pin(status_path),
        "preserved_queue_items_2_through_7": retained_queue,
        "retained_gates": proposal["retained_queue_and_gates"],
        "public_implementation_started": False,
        "fresh_lease_required": True,
        "public_files_changed_by_selection": [],
        "numerical_execution_by_selection": False,
    }
    write("selection.json", selection)
    print(json.dumps({"selection": pin(ROOT / "selection.json"), "predecessor_acceptance": pin(ROOT / "predecessor-acceptance.json"), "numerical_execution": False}, indent=2))


if __name__ == "__main__":
    main()
