"""Fresh scalar references plus independent exact width-assembly verification."""
import argparse
import csv
import json
from decimal import Decimal as D, localcontext
from fractions import Fraction as F
from pathlib import Path

from decimal_forced_reference import QE, represented as decimal_represented
from exact_width_math import (aggregate_represented, areal_mapping, canonical_sha, check_projection,
    decimal_area, geometry, pair, recomputed_residuals, represented, same)
from scalar_checks import CHANNELS, compare_trajectory, encode, load, normalized, require, sha
from width_reference import new_reference, scalar_case
from width_science import INPUTS, QUANTITIES, case_scales, contrast_reference

HERE=Path(__file__).resolve().parent
RHS_KEYS=('release_flux_m2_s','coverage_rate_m2_s','temperature_rate_k_s','input_power_j_m2_s',
    'binding_power_j_m2_s','internal_power_j_m2_s','translational_power_j_m2_s','total_wall_power_j_m2_s')


def rational_decimal(value):
    return D(value.numerator)/D(value.denominator)


def record_set(actual,expected):
    require(set(actual)==set(expected),'quantity key set differs')
    for key,value in expected.items():
        check_projection(actual[key],value)


def csv_value(token,value):
    require(float(token).hex()==float(value).hex(),'CSV scalar projection differs')


def csv_quantities(row,prefix,records):
    for key,record in records.items():
        name=prefix+key
        csv_value(row[name],record['value'])
        same(row[name+'__exact_numerator'],record['exact']['numerator'])
        same(row[name+'__exact_denominator'],record['exact']['denominator'])
        same(json.loads(row[name+'__projection_json']),record['projection'])


def csv_readback(run,assembly,producer):
    counts={}
    with (run/'patch_samples.csv').open(newline='') as stream:
        rows=list(csv.DictReader(stream))
    require(len(rows)==390,'expanded patch CSV rows differ')
    seen=set()
    for row in rows:
        hypothesis=row['hypothesis']; patch_index=int(row['patch_index']); index=int(row['sample_index'])
        require((hypothesis,patch_index,index) not in seen,'duplicate patch CSV row');seen.add((hypothesis,patch_index,index))
        patch=assembly['hypotheses'][hypothesis]['patches'][patch_index];sample=patch['samples'][index]
        for key in ('width_left_m','width_right_m','area_m2'):
            csv_value(row[key],patch[key])
        same(json.loads(row['area_exact_json']),patch['area_exact_m2'])
        for key in ('state_id','scalar_history_id','history_sha256'):
            same(row[key],patch[key])
        for key in ('segment_index','segment_step','time_s'):
            csv_value(row[key],sample[key])
        same(json.loads(row['logical_time_json']),sample['logical_time_s'])
        for key,value in sample['areal'].items():
            csv_value(row['areal__'+key],value)
        csv_quantities(row,'extensive__',sample['extensive'])
    counts['expanded_patch_CSV_rows_checked']=len(rows)
    with (run/'aggregate_samples.csv').open(newline='') as stream:
        rows=list(csv.DictReader(stream))
    require(len(rows)==130,'aggregate CSV rows differ')
    seen=set()
    for row in rows:
        identity=(row['hypothesis'],int(row['sample_index']))
        require(identity not in seen,'duplicate aggregate CSV row');seen.add(identity)
        sample=assembly['hypotheses'][row['hypothesis']]['totals'][int(row['sample_index'])]
        for key in ('segment_index','segment_step','time_s'):
            csv_value(row[key],sample[key])
        same(row['state_id'],sample['state_id'])
        same(json.loads(row['logical_time_json']),sample['logical_time_s'])
        csv_quantities(row,'extensive__',sample['extensive'])
        csv_quantities(row,'recomputed_residuals__',sample['recomputed_residuals'])
    counts['aggregate_CSV_rows_checked']=len(rows)
    with (run/'width_comparison.csv').open(newline='') as stream:
        rows=list(csv.DictReader(stream))
    require(len(rows)==65,'comparison CSV rows differ')
    seen=set()
    for row in rows:
        require(int(row['sample_index']) not in seen,'duplicate comparison CSV row');seen.add(int(row['sample_index']))
        sample=assembly['comparison']['samples'][int(row['sample_index'])]
        csv_value(row['time_s'],sample['time_s'])
        same(json.loads(row['logical_time_json']),sample['logical_time_s'])
        csv_quantities(row,'difference__',sample['difference_nonuniform_minus_uniform'])
        csv_quantities(row,'',{key:sample[key] for key in ('exact_prescribed_input_energy_j',
            'integrated_input_difference_j','prescribed_input_difference_j')})
    counts['comparison_CSV_rows_checked']=len(rows)
    return counts


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-dir',type=Path,required=True)
    parser.add_argument('--output-dir',type=Path,required=True)
    args=parser.parse_args()
    require(not args.output_dir.exists(),'fresh independent output directory required')
    freeze=load(HERE/'before_code_freeze.json');plan=load(HERE/'oracle_plan.json');config=load(HERE/'input_config.json')
    for name,digest in freeze['code_and_input_sha256'].items():
        require(sha(HERE/name)==digest,'frozen code/input changed')
    producer=load(args.run_dir/'report.json')
    require(producer['schema']=='mhdlab-thermal-width-power-reference-run-v1','producer schema differs')
    require(sha(args.run_dir/'input_config.json')==sha(HERE/'input_config.json')==producer['config_sha256'],'config differs')
    edges,length,areas=geometry(config)
    declarations={item['case_id']:item for item in config['scalar_cases']}
    require(set(declarations)==set(plan['cases']),'case identities differ')
    cases={key:scalar_case(config,value) for key,value in declarations.items()}
    records={item['case_id']:item for item in producer['scalar_histories']}
    require(set(records)==set(cases),'saved source identities differ')
    powers={key:F.from_float(float(value['power_w_m2'])) for key,value in declarations.items()}
    hypothesis_power={key:sum((area*powers[source] for area,source in zip(areas,assignment)),F(0))
        for key,assignment in config['hypotheses'].items()}
    require(hypothesis_power['uniform']==hypothesis_power['nonuniform']==F(234375,128),'exact prescribed power differs')
    args.output_dir.mkdir(parents=True)
    references={};coarse_references={};stability={};scalar_results=[];checkpoints={}
    for key,case in cases.items():
        levels={}
        for label in ('coarse','refined'):
            samples=new_reference(case,precision=plan[label+'_precision'],order=plan[label+'_order'],
                subdivisions=plan[label+'_subdivisions'],quadrature_order=plan[label+'_quadrature_order'])
            checkpoint=args.output_dir/(key+'_'+label+'_checkpoint.json')
            checkpoint.write_text(json.dumps(encode({'case_id':key,'level':label,'config_sha256':sha(HERE/'input_config.json'),
                'samples':[{'logical_time':time,**sample} for time,sample in sorted(samples.items())]}),indent=2,allow_nan=False)+'\n')
            checkpoints[checkpoint.name]=sha(checkpoint);levels[label]=samples
        coarse_references[key],references[key]=levels['coarse'],levels['refined']
        with localcontext() as context:
            context.prec=plan['refined_precision']
            scales,_=case_scales(case,references[key]);maxima={}
            for quantity in (*CHANNELS,'release_flux_m2_s'):
                values=[normalized(levels['coarse'][time][quantity]-levels['refined'][time][quantity],scales[quantity]) for time in references[key]]
                maxima[quantity]=max(values)
                require(max(values)<=D(plan['reference_change_tolerance']),'reference stability unresolved: '+quantity)
            for name in RHS_KEYS:
                scale=max(abs(sample['rhs_reference'][name]) for sample in references[key].values())
                change=max(normalized(levels['coarse'][time]['rhs_reference'][name]-levels['refined'][time]['rhs_reference'][name],scale) for time in references[key])
                maxima['rhs__'+name]=change
                require(change<=D(plan['reference_change_tolerance']),'reference instantaneous-rate stability unresolved')
            for samples in levels.values():
                for sample in samples.values():
                    for quantity,scale in (('independent_total_energy_residual_j_m2',scales['wall_thermal_change_j_m2']),
                        ('independent_wall_energy_residual_j_m2',scales['wall_thermal_change_j_m2']),
                        ('independent_wall_channel_residual_j_m2',scales['total_wall_energy_debit_j_m2']),
                        ('independent_count_quadrature_residual_m2',scales['released_m2'])):
                        require(normalized(sample[quantity],scale)<=D(plan['reference_change_tolerance']),'reference channel consistency unresolved')
            stability[key]=maxima
        record=dict(records[key],segment_steps=[config['steps']],input_parameters=case['problem'],
            history_sha256=records[key]['history_file_sha256'])
        scalar_results.append(compare_trajectory(record,case,args.run_dir,references[key],plan))
        print('completed NEW independent forcing reference '+key,flush=True)
    assembly_path=args.run_dir/producer['assembly_file'];assembly=load(assembly_path)
    require(assembly['schema']=='mhdlab-thermal-width-power-reference-v1','assembly schema differs')
    same(assembly['host_budget_accepted'],False);same(assembly['owner_implementation_verified'],False)
    same(assembly['parameter_status'],'manufactured')
    geom=assembly['geometry']
    same(geom['width_edges_m'],[float(value) for value in edges]);same(geom['common_length_m'],float(length))
    same(geom['patch_areas_m2'],[float(value) for value in areas]);same(geom['total_area_m2'],float(sum(areas)))
    require([pair(record) for record in geom['area_weights']]==[value/sum(areas) for value in areas],'exact area weights differ')
    require([pair(value) for value in geom['width_edges_exact_m']]==edges,'exact width edges differ')
    require([pair(value) for value in geom['patch_areas_exact_m2']]==areas,'exact areas differ')
    require(pair(geom['common_length_exact_m'])==length and pair(geom['total_area_exact_m2'])==sum(areas),'exact face geometry differs')
    for name,value in {'distinct_scalar_histories':3,'scalar_samples':195,'rhs_evaluations':195,
            'patch_history_references':6,'scalar_evolutions_by_assembly':0}.items():
        same(assembly['cache'][name],value)
    times=sorted(next(iter(references.values())))
    cached={};histories={};rhs_maxima={};rhs_scales={};rhs_csv_cells=0
    with localcontext() as context:
        context.prec=plan['refined_precision']
        for key,case in cases.items():
            record=records[key];cache=assembly['scalar_histories'][key]
            history=load(args.run_dir/record['history_file']);histories[key]=history
            same(cache['history'],history)
            require(cache['history_sha256']==record['canonical_history_sha256']==canonical_sha(history),'canonical source digest differs')
            require(len(cache['release_flux_m2_s'])==len(cache['rhs'])==len(cache['logical_time_s'])==65,'cache cardinality differs')
            require([pair(time) for time in cache['logical_time_s']]==times,'cache logical times differ')
            cached[key]=cache
            scales={name:max(abs(sample['rhs_reference'][name]) for sample in references[key].values()) for name in RHS_KEYS}
            maxima={name:D(0) for name in RHS_KEYS}
            with (args.run_dir/record['csv_file']).open(newline='') as stream:
                csv_rows=list(csv.DictReader(stream))
            for index,time in enumerate(times):
                same(cache['release_flux_m2_s'][index],cache['rhs'][index]['release_flux_m2_s'])
                same(csv_rows[index]['state_id'],case['problem']['reservoir']['state_id'])
                csv_value(csv_rows[index]['release_flux_m2_s'],cache['release_flux_m2_s'][index]);rhs_csv_cells+=1
                require(set(cache['rhs'][index])==set(RHS_KEYS),'cached rate identities differ')
                for name in RHS_KEYS:
                    fraction=normalized(decimal_represented(cache['rhs'][index][name])-references[key][time]['rhs_reference'][name],scales[name])
                    maxima[name]=max(maxima[name],fraction)
                    require(fraction<=D(plan['flux_budget_tolerance']),'new instantaneous rate error unresolved: '+name)
                    csv_value(csv_rows[index]['instantaneous__'+name],cache['rhs'][index][name]);rhs_csv_cells+=1
            rhs_maxima[key]=maxima
            rhs_scales[key]=scales
        reference_totals,reference_contrasts,contrast_scales,temp_contrasts=contrast_reference(config,references,areas)
        coarse_totals,coarse_contrasts,_,_=contrast_reference(config,coarse_references,areas)
        exact_totals={};aggregate_errors={};residual_maxima={};patch_count=quantity_records=0
        for hypothesis,assignment in config['hypotheses'].items():
            data=assembly['hypotheses'][hypothesis];require(len(data['patches'])==3 and len(data['totals'])==65,'hypothesis shape differs')
            exact_totals[hypothesis]={};aggregate_errors[hypothesis]={};residual_maxima[hypothesis]={}
            for patch_index,(patch,source,area) in enumerate(zip(data['patches'],assignment,areas)):
                same(patch['patch_index'],patch_index);same(patch['width_left_m'],float(edges[patch_index]));same(patch['width_right_m'],float(edges[patch_index+1]))
                same(patch['area_m2'],float(area));require(pair(patch['area_exact_m2'])==area,'patch exact area differs')
                same(patch['scalar_history_id'],source);same(patch['history_sha256'],cached[source]['history_sha256'])
                same(patch['state_id'],config['common_scalar_problem']['reservoir']['state_id'])
                require(len(patch['samples'])==65,'patch sample count differs')
                for index,(sample,time) in enumerate(zip(patch['samples'],times)):
                    original=histories[source]['samples'][index]
                    expected_areal={name:value for name,value in original.items() if name not in ('time_s','segment_index','segment_step','extensive')}
                    expected_areal['release_flux_m2_s']=cached[source]['release_flux_m2_s'][index]
                    same(sample['areal'],expected_areal)
                    same(sample['state_id'],patch['state_id']);same(sample['scalar_history_id'],source)
                    for name in ('time_s','segment_index','segment_step'):
                        same(sample[name],original[name])
                    require(pair(sample['logical_time_s'])==time,'patch logical support differs')
                    expected=aggregate_represented([original],[cached[source]['release_flux_m2_s'][index]],[area],'release_rate_s')
                    record_set(sample['extensive'],expected);quantity_records+=len(expected);patch_count+=1
            budgets={extensive:sum((decimal_area(area)*case_scales(cases[source],references[source])[0][areal]
                for source,area in zip(assignment,areas)),D(0)) for areal,extensive in QUANTITIES.items()}
            for index,(total,time) in enumerate(zip(data['totals'],times)):
                samples=[histories[source]['samples'][index] for source in assignment]
                fluxes=[cached[source]['release_flux_m2_s'][index] for source in assignment]
                expected=aggregate_represented(samples,fluxes,areas,'release_rate_s')
                record_set(total['extensive'],expected);quantity_records+=len(expected)
                recomputed=recomputed_residuals(samples,areas,config['common_scalar_problem'])
                record_set(total['recomputed_residuals'],recomputed);quantity_records+=len(recomputed)
                for name in ('time_s','segment_index','segment_step'):
                    same(total[name],samples[0][name])
                same(total['state_id'],config['common_scalar_problem']['reservoir']['state_id'])
                require(pair(total['logical_time_s'])==time,'aggregate logical support differs')
                exact_totals[hypothesis][time]=expected
                for quantity,reference in reference_totals[hypothesis][time].items():
                    error=rational_decimal(expected[quantity])-reference
                    fraction=normalized(error,budgets[quantity])
                    aggregate_errors[hypothesis][quantity]=max(aggregate_errors[hypothesis].get(quantity,D(0)),fraction)
                    require(fraction<=D(plan['aggregate_budget_tolerance']),'aggregate independent error unresolved: '+quantity)
                for name,residual in recomputed.items():
                    scale=(budgets['released_number'] if name=='inventory_residual_number' else
                        budgets['wall_thermal_change_j'] if name=='wall_debit_residual_j' else
                        budgets['binding_energy_j'] if name in ('binding_allocation_residual_j','adsorbate_reference_residual_j') else
                        budgets['internal_energy_j'] if name=='internal_allocation_residual_j' else
                        budgets['input_energy_j'] if name=='input_energy_residual_j' else budgets['total_wall_energy_debit_j'])
                    fraction=normalized(rational_decimal(residual),scale)
                    residual_maxima[hypothesis][name]=max(residual_maxima[hypothesis].get(name,D(0)),fraction)
                    require(fraction<=D(plan['ledger_budget_tolerance']),'aggregate independent residual unresolved: '+name)
        check_projection(assembly['comparison']['exact_total_input_power_w'],hypothesis_power['uniform'])
        require(len(assembly['comparison']['samples'])==65,'comparison support differs')
        contrasts={};contrast_errors={};contrast_stability={};temperature_errors={};comparison_rows=[]
        for index,(actual,time) in enumerate(zip(assembly['comparison']['samples'],times)):
            difference={key:exact_totals['nonuniform'][time][key]-exact_totals['uniform'][time][key]
                for key in exact_totals['uniform'][time]}
            record_set(actual['difference_nonuniform_minus_uniform'],difference);quantity_records+=len(difference)
            check_projection(actual['exact_prescribed_input_energy_j'],hypothesis_power['uniform']*time)
            check_projection(actual['integrated_input_difference_j'],difference['input_energy_j'])
            check_projection(actual['prescribed_input_difference_j'],difference['prescribed_input_energy_j'])
            require(pair(actual['logical_time_s'])==time,'comparison exact logical support differs')
            same(actual['time_s'],float(time))
            if index==0:
                require(all(value==0 for value in difference.values()),'initial contrast is not structurally zero')
            rows={}
            for quantity,scale in contrast_scales.items():
                observed=rational_decimal(difference[quantity]);reference=reference_contrasts[time][quantity]
                error=observed-reference;change=coarse_contrasts[time][quantity]-reference
                fraction=normalized(error,scale);stability_fraction=normalized(change,scale)
                contrast_errors[quantity]=max(contrast_errors.get(quantity,D(0)),fraction)
                contrast_stability[quantity]=max(contrast_stability.get(quantity,D(0)),stability_fraction)
                require(fraction<=D(plan['contrast_budget_tolerance']),'own contrast prediction error unresolved: '+quantity)
                require(stability_fraction<=D(plan['reference_change_tolerance']),'own contrast reference stability unresolved: '+quantity)
                allowance=abs(error)+abs(change)
                rows[quantity]={'production_difference':observed,'reference_difference':reference,
                    'signed_error':error,'own_contrast_scale':scale,'absolute_contrast_fraction':fraction,
                    'observed_numerical_allowance':allowance,'numerically_resolved_sign':abs(reference)>allowance}
            for patch_index in range(3):
                source=config['hypotheses']['nonuniform'][patch_index];uniform=config['hypotheses']['uniform'][patch_index]
                observed=decimal_represented(histories[source]['samples'][index]['temperature_k'])-decimal_represented(histories[uniform]['samples'][index]['temperature_k'])
                error=observed-temp_contrasts[patch_index]['values'][time]
                fraction=normalized(error,temp_contrasts[patch_index]['scale'])
                temperature_errors[patch_index]=max(temperature_errors.get(patch_index,D(0)),fraction)
                require(fraction<=D(plan['contrast_budget_tolerance']),'own patch temperature contrast unresolved')
            comparison_rows.append({'logical_time':time,'quantities':rows})
    csv_counts=csv_readback(args.run_dir,assembly,producer)
    reference_path=args.output_dir/'reference_samples.json'
    reference_path.write_text(json.dumps(encode({key:[{'logical_time':time,**sample} for time,sample in sorted(value.items())]
        for key,value in references.items()}),indent=2,allow_nan=False)+'\n')
    contrast_path=args.output_dir/'contrast_samples.json';contrast_path.write_text(json.dumps(encode(comparison_rows),indent=2,allow_nan=False)+'\n')
    report={'schema':'mitl-independent-width-power-oracle-v1','status':'passed','all_checks_passed':True,
        'new_scalar_cases':3,'unique_scalar_reference_samples':195,'unique_scalar_flux_references':195,
        'saved_scalar_rows_checked':195,'scalar_CSV_JSON_cells_checked':sum(row['CSV_JSON_scalar_cells_checked'] for row in scalar_results),
        'scalar_RHS_CSV_cells_checked':rhs_csv_cells,'scalar_area_once_checks':sum(row['area_once_checks'] for row in scalar_results),
        'expanded_patch_samples_checked':patch_count,'aggregate_samples_checked':130,'difference_samples_checked':65,
        'exact_quantity_projection_records_checked':quantity_records,'reference_precision_grids':6,
        'saved_state_flux_evaluations_across_two_precision_grids':390,'post_source_cache_records_verified':195,
        'independent_RHS_field_comparisons':1560,
        **csv_counts,'scalar_results':scalar_results,'reference_stability':stability,'instantaneous_rate_errors':rhs_maxima,
        'instantaneous_rate_scales':rhs_scales,
        'aggregate_errors':aggregate_errors,'aggregate_residuals':residual_maxima,
        'own_contrast_scales':contrast_scales,'own_contrast_errors':contrast_errors,
        'own_contrast_reference_stability':contrast_stability,'own_patch_temperature_contrast_errors':temperature_errors,
        'final_contrasts':comparison_rows[-1],'exact_common_input_power_w':hypothesis_power['uniform'],
        'exact_common_final_input_energy_j':hypothesis_power['uniform']*times[-1],
        'reference_checkpoint_sha256':checkpoints,'reference_samples_file':reference_path.name,
        'reference_samples_sha256':sha(reference_path),'contrast_samples_file':contrast_path.name,'contrast_samples_sha256':sha(contrast_path),
        'input_sha256':{str(args.run_dir/'report.json'):sha(args.run_dir/'report.json'),str(assembly_path):sha(assembly_path),
            str(HERE/'input_config.json'):sha(HERE/'input_config.json')},
        'producer_imports_or_calls':[],'old_case_or_oracle_runs':0,'new_independent_oracle_runs':1,
        'numerical_sign_flags_are_physical_or_statistical_confidence':False,
        'qualification':plan['qualification']}
    path=args.output_dir/'report.json';path.write_text(json.dumps(encode(report),indent=2,allow_nan=False)+'\n')
    print(json.dumps({'report':str(path),'sha256':sha(path),'new_cases':3,'unique_reference_samples':195,
        'expanded_patch_samples':patch_count,'own_contrast_errors':encode(contrast_errors)},indent=2))


if __name__=='__main__':
    main()
