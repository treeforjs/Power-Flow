"""Independent all-sample verification of saved manufactured positive-barrier forced trajectories.

Only local JSON/CSV and the fresh Decimal transformed Taylor reference are read.
There are no repository numerical, old solver, test or producer imports/calls.
"""
import argparse
import csv
import hashlib
import json
from decimal import Decimal, localcontext
from fractions import Fraction
from pathlib import Path

from decimal_forced_reference import reference_grid, represented, QE

D = Decimal
HERE = Path(__file__).resolve().parent
CHANNELS = ('coverage_m2', 'temperature_k', 'released_m2', 'input_energy_j_m2',
    'prescribed_input_energy_j_m2', 'binding_energy_j_m2', 'internal_energy_j_m2',
    'translational_energy_j_m2', 'total_wall_energy_debit_j_m2', 'gas_energy_j_m2',
    'wall_thermal_change_j_m2', 'adsorbate_reference_energy_j_m2',
    'adsorbate_reference_change_j_m2', 'adsorbate_reference_inventory_change_j_m2')


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def encode(value):
    if isinstance(value, D):
        return {'decimal': str(value), 'float_projection': float(value)}
    if isinstance(value, Fraction):
        return {'numerator': str(value.numerator), 'denominator': str(value.denominator), 'float_projection': float(value)}
    if isinstance(value, dict):
        return {key: encode(item) for key,item in value.items()}
    if isinstance(value, (tuple,list)):
        return [encode(item) for item in value]
    return value


def projected(value):
    if type(value) in (int,float):
        return ('float_input', float(value).hex())
    if isinstance(value,dict):
        return {key:projected(item) for key,item in value.items()}
    if isinstance(value,list):
        return [projected(item) for item in value]
    return value


def logical_grid(case, grid):
    records = [(0,0,Fraction(0))]
    for index,(segment,steps) in enumerate(zip(case['segments'],grid)):
        start,stop = (Fraction.from_float(float(segment[key])) for key in ('start_s','stop_s'))
        records.extend((index,step,start+(stop-start)*Fraction(step,steps)) for step in range(1,steps+1))
    return records


def schedule_for(case, grid):
    return {'duration_s':case['duration_s'], 'segments':[{**segment,'steps':steps} for segment,steps in zip(case['segments'],grid)]}


def fraction_input(case, time):
    value = Fraction(0)
    for segment in case['segments']:
        start,stop = (Fraction.from_float(float(segment[key])) for key in ('start_s','stop_s'))
        if start < time:
            value += Fraction.from_float(float(segment['power_w_m2']))*(min(stop,time)-start)
    return value


def normalized(error, scale):
    if scale:
        return abs(error)/scale
    require(error == 0, 'a structurally zero budget has nonzero error')
    return D(0)


def budget_scales(case, references):
    final = references[max(references)]
    t0 = represented(case['problem']['initial_temperature_k'])
    capacity = represented(case['problem']['areal_heat_capacity_j_m2_k'])
    excursion = max(abs(sample['temperature_k']-t0) for sample in references.values())
    scales = {key:abs(final[key]) for key in CHANNELS}
    scales['coverage_m2'] = scales['released_m2']
    scales['temperature_k'] = excursion
    scales['wall_thermal_change_j_m2'] = capacity*excursion
    scales['adsorbate_reference_energy_j_m2'] = scales['binding_energy_j_m2']
    return scales, {'temperature_excursion_k':excursion, 'thermal_excursion_j_m2':capacity*excursion,
        'gross_input_j_m2':final['input_energy_j_m2'], 'gross_wall_debit_j_m2':final['total_wall_energy_debit_j_m2'],
        'near_zero_net_convention':'Temperature and thermal errors use maximum resolved excursion over the case grid, separately from positive input/debit budgets. Exactly zero excursion requires exactly zero error.'}


def residuals(sample, case, scales):
    x = {key:represented(sample[key]) for key in CHANNELS}
    problem = case['problem']
    n0,t0,capacity = (represented(problem[key]) for key in ('initial_coverage_m2','initial_temperature_k','areal_heat_capacity_j_m2_k'))
    removal = represented(problem['reservoir']['desorption_energy_ev'])*QE
    internal = represented(problem['reservoir']['internal_energy_ev'])*QE
    thermal = capacity*(x['temperature_k']-t0)
    return {
        'N_plus_M_minus_N0_m2': (x['coverage_m2']+x['released_m2']-n0,scales['released_m2']),
        'thermal_minus_input_plus_wall_j_m2': (thermal-x['input_energy_j_m2']+x['total_wall_energy_debit_j_m2'],scales['wall_thermal_change_j_m2']),
        'wall_minus_binding_internal_translation_j_m2': (x['total_wall_energy_debit_j_m2']-x['binding_energy_j_m2']-x['internal_energy_j_m2']-x['translational_energy_j_m2'],scales['total_wall_energy_debit_j_m2']),
        'binding_minus_D_M_j_m2': (x['binding_energy_j_m2']-removal*x['released_m2'],scales['binding_energy_j_m2']),
        'internal_minus_I_M_j_m2': (x['internal_energy_j_m2']-internal*x['released_m2'],scales['internal_energy_j_m2']),
        'adsorbate_change_minus_inventory_change_j_m2': (x['adsorbate_reference_change_j_m2']-removal*(n0-x['coverage_m2']),scales['binding_energy_j_m2']),
        'gas_minus_internal_translation_j_m2': (x['gas_energy_j_m2']-x['internal_energy_j_m2']-x['translational_energy_j_m2'],scales['gas_energy_j_m2']),
        'saved_thermal_minus_C_deltaT_j_m2': (x['wall_thermal_change_j_m2']-thermal,scales['wall_thermal_change_j_m2']),
        'saved_adsorbate_energy_plus_D_N_j_m2': (x['adsorbate_reference_energy_j_m2']+removal*x['coverage_m2'],scales['binding_energy_j_m2']),
        'input_integrated_minus_prescribed_j_m2': (x['input_energy_j_m2']-x['prescribed_input_energy_j_m2'],scales['input_energy_j_m2']),
        'total_thermal_adsorbate_gas_minus_input_j_m2': (thermal+removal*(n0-x['coverage_m2'])+x['gas_energy_j_m2']-x['input_energy_j_m2'],
            max(scales['input_energy_j_m2'],scales['total_wall_energy_debit_j_m2']))}


def compare_trajectory(record,case,run_dir,references,plan):
    grid = record['segment_steps']
    logical = logical_grid(case,grid)
    history_path,csv_path = run_dir/record['history_file'],run_dir/record['csv_file']
    require(sha(history_path)==record['history_sha256'] and sha(csv_path)==record['csv_sha256'],'producer output pin differs')
    history = load(history_path)
    require(projected(history['problem'])==projected(case['problem'])==projected(record['input_parameters']),'problem input differs')
    require(len(history['schedule']['segments'])==len(case['segments']),'schedule count differs')
    for actual,expected,steps in zip(history['schedule']['segments'],case['segments'],grid):
        require(actual['steps']==steps and all(projected(actual[key])==projected(expected[key]) for key in expected),'schedule declaration differs')
    samples=history['samples']
    with csv_path.open(newline='') as stream:
        csv_rows=list(csv.DictReader(stream))
    require(len(samples)==len(csv_rows)==len(logical)==sum(grid)+1,'saved sample count differs')
    with localcontext() as context:
        context.prec=plan['refined_precision']
        scales,scale_notes=budget_scales(case,references)
        tolerance=D(plan['coarse_family_budget_tolerance'] if min(grid)<32 else plan['trajectory_budget_tolerance'])
        maxima={key:{'absolute_budget_fraction':D(-1)} for key in CHANNELS}
        ledgers={}
        csv_cells=area_checks=stamp_checks=0
        for index,(sample,csv_row,(segment,step,time)) in enumerate(zip(samples,csv_rows,logical)):
            require(sample['segment_index']==segment and sample['segment_step']==step,'logical sample identity differs')
            require(float(sample['time_s']).hex()==float(time).hex(),'rounded time stamp differs from exact logical grid')
            stamp_checks+=1
            for key in ('time_s','segment_index','segment_step',*CHANNELS):
                require(float(csv_row[key]).hex()==float(sample[key]).hex(),'CSV/JSON scalar differs: '+key)
                csv_cells+=1
            reference=references[time]
            for key in CHANNELS:
                error=represented(sample[key])-reference[key]
                fraction=normalized(error,scales[key])
                if fraction>maxima[key]['absolute_budget_fraction']:
                    maxima[key]={'signed_error':error,'absolute_budget_fraction':fraction,'budget_scale':scales[key],'sample_index':index}
                require(fraction<=tolerance,'independent all-row error exceeds budget: '+key)
            exact_input=fraction_input(case,time)
            require(float(sample['prescribed_input_energy_j_m2']).hex()==float(exact_input).hex(),'prescribed input is not exact schedule integral projection')
            for key,(residual,scale) in residuals(sample,case,scales).items():
                fraction=normalized(residual,scale)
                if fraction>ledgers.get(key,{}).get('absolute_budget_fraction',D(-1)):
                    ledgers[key]={'signed_residual':residual,'absolute_budget_fraction':fraction,'budget_scale':scale,'sample_index':index}
                require(fraction<=D(plan['ledger_budget_tolerance']),'independent signed ledger exceeds budget: '+key)
            area=Fraction.from_float(float(case['problem']['patch_area_m2']))
            mappings=[(key,key[:-3]) for key in CHANNELS if key.endswith('_j_m2')]
            mappings += [('coverage_m2','coverage_number'),('released_m2','released_number'),('inventory_residual_m2','inventory_residual_number')]
            for areal,extensive in mappings:
                expected=float(Fraction.from_float(float(sample[areal]))*area)
                require(float(sample['extensive'][extensive]).hex()==expected.hex(),'area-once projection differs: '+extensive)
                area_checks+=1
        final_reference=references[logical[-1][2]]
        return {'case_id':record['case_id'],'segment_steps':grid,'total_steps':sum(grid),'sample_rows':len(samples),
            'CSV_JSON_scalar_cells_checked':csv_cells,'rounded_stamp_projection_checks':stamp_checks,'area_once_checks':area_checks,
            'source_artifact_sha256':{str(history_path):sha(history_path),str(csv_path):sha(csv_path)},
            'budget_scales':scales,'scale_conventions':scale_notes,'declared_error_budget_fraction':tolerance,
            'all_row_maximum_errors':maxima,'independent_signed_ledger_maxima':ledgers,
            'endpoint_values':{key:represented(samples[-1][key]) for key in CHANNELS},
            'endpoint_reference':final_reference}


def order(a,b,c):
    coarse,fine=a-b,b-c
    if not coarse or not fine or coarse*fine<=0 or abs(coarse)<=abs(fine):
        return {'order':None,'status':'unresolved_zero_cancellation_sign_or_nonasymptotic_change','coarse_change':coarse,'fine_change':fine}
    return {'order':abs(coarse/fine).ln()/D(2).ln(),'status':'finite_self_difference_estimate','coarse_change':coarse,'fine_change':fine}


# Saved-output comparison helpers only; no main or numerical reference call.
