"""Freeze new verification code before any new reference calculation."""
import ast
import datetime
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
WORK=HERE.parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    target=HERE/'before_code_freeze.json'
    if target.exists() or (HERE/'oracle-initial').exists():
        raise RuntimeError('code freeze must precede reference evaluation')
    names=['decimal_forced_reference.py','width_reference.py','exact_width_math.py','scalar_checks.py',
        'width_science.py','verify_width_power.py','oracle_plan.json','input_config.json',
        'before_plan_freeze.json','contrast_plan_amendment.json','rhs_plan_amendment.json','freeze_code.py']
    for name in names:
        if name.endswith('.py'):
            ast.parse((HERE/name).read_text())
    amended=json.loads((HERE/'contrast_plan_amendment.json').read_text())
    assert sha(HERE/'oracle_plan.json')==amended['effective_plan_sha256']
    assert sha(HERE/'decimal_forced_reference.py')=='b6740c00a75b094ea36c9d6c1d941cbe31e19b8100a200613ef8961136c8da89'
    record={'schema':'mitl-independent-width-power-before-code-freeze-v1',
        'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'code_and_input_sha256':{name:sha(HERE/name) for name in names},
        'new_reference_evaluations_before_freeze':0,'old_reference_or_case_evaluations':0,
        'saved_producer_report_sha256':sha(WORK/'producer/reference-run/report.json'),
        'new_inputs_only':True,'retained_method_dependency':'Unchanged qualified0625 transformed mathematical code, new0710 forcing inputs only.'}
    target.write_text(json.dumps(record,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'code_freeze_sha256':sha(target),'code':record['code_and_input_sha256']},indent=2))


if __name__=='__main__':
    main()
