"""Freeze pre-run corrections separating exact readback from physical checks."""
import ast
import datetime
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    target=HERE/'pre_reference_definition_amendment.json'
    if target.exists() or (HERE/'oracle-initial').exists():
        raise RuntimeError('definition amendment must precede first reference evaluation')
    frozen=json.loads((HERE/'before_code_freeze.json').read_text())
    changed=('exact_width_math.py','verify_width_power.py')
    for name,digest in frozen['code_and_input_sha256'].items():
        if name in changed:
            assert sha(HERE/(Path(name).stem+'.initial.py'))==digest
            ast.parse((HERE/name).read_text())
        else:
            assert sha(HERE/name)==digest
    record={'schema':'mitl-independent-width-power-pre-reference-definition-amendment-v1',
        'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'original_code_freeze_sha256':sha(HERE/'before_code_freeze.json'),
        'initial_file_sha256':{name:frozen['code_and_input_sha256'][name] for name in changed},
        'changed_file_sha256':{name:sha(HERE/name) for name in changed},
        'corrections':[
            'Exact represented-source aggregate residual readback uses the represented wall_thermal_change_j_m2 field; separate budgeted physical checks retain unprojected C*(T-T0).',
            'Dedicated prescribed_input_difference_j checks exact area-times-power support identity. The signed difference of projected source prescribed channels remains independently checked in the full difference quantity map.'
        ],
        'physical_equations_inputs_geometry_tolerances_changed':False,
        'numerical_reference_evaluations_before_amendment':0}
    target.write_text(json.dumps(record,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'amendment_sha256':sha(target),'changed_file_sha256':record['changed_file_sha256']},indent=2))


if __name__=='__main__':
    main()
