"""Add the requested own-contrast error scales before any new numeric run."""
import datetime
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
WORK=HERE.parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    target=HERE/'contrast_plan_amendment.json'
    if target.exists() or (WORK/'producer/reference-run/report.json').exists():
        raise RuntimeError('contrast amendment must precede new producer/reference evaluations')
    initial=json.loads((HERE/'before_plan_freeze.json').read_text())
    assert sha(HERE/'oracle_plan.initial.json')==initial['independent_plan_and_input_sha256']['oracle_plan.json']
    for name,digest in initial['independent_plan_and_input_sha256'].items():
        if name!='oracle_plan.json':
            assert sha(HERE/name)==digest
    record={'schema':'mitl-independent-width-power-contrast-plan-amendment-v1',
        'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'original_plan_freeze_sha256':sha(HERE/'before_plan_freeze.json'),
        'original_plan_sha256':sha(HERE/'oracle_plan.initial.json'),
        'effective_plan_sha256':sha(HERE/'oracle_plan.json'),
        'change':'Add own resolved contrast scales max_t|Delta_ref| and2e-5 checks for physical count/flux/energy contrasts, separate from scalar/gross checks. Initial/prescribed-input zeros and signed integrated-input roundoff remain distinct. Crossing/nearzero pointwise signs are not forced.',
        'model_geometry_input_or_method_changed':False,
        'numerical_reference_or_producer_runs_before_amendment':0}
    target.write_text(json.dumps(record,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'amendment_sha256':sha(target),'effective_plan_sha256':record['effective_plan_sha256']},indent=2))


if __name__=='__main__':
    main()
