"""Freeze input, mathematical dependency and thresholds before new production."""
import datetime
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
WORK=HERE.parent
REPO=Path('/workspace/Power-Flow')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    target=HERE/'before_plan_freeze.json'
    if target.exists() or (WORK/'producer/reference-run/report.json').exists():
        raise RuntimeError('plan freeze must precede producer and reference evaluations')
    assert sha(HERE/'input_config.json')==sha(REPO/'configs/thermal_width_power_manufactured.json')=='22f21dae395f31f9a13186821c5364033b50f051aa7296f93839896c2fae4b56'
    assert sha(HERE/'decimal_forced_reference.py')=='b6740c00a75b094ea36c9d6c1d941cbe31e19b8100a200613ef8961136c8da89'
    record={'schema':'mitl-independent-width-power-before-plan-freeze-v1',
        'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'independent_plan_and_input_sha256':{name:sha(HERE/name) for name in
            ('oracle_plan.json','input_config.json','decimal_forced_reference.py','freeze_plan.py')},
        'new_scalar_cases':3,'new_unique_samples':195,'new_unique_flux_references':195,
        'expanded_patch_samples':390,'new_reference_calls_before_freeze':0,
        'producer_calls_by_oracle':0,'old_reference_or_case_calls':0,
        'reference_context':'Qualified mathematical code reused unchanged for NEW inputs only; no prior positive example/oracle is rerun.',
        'limits':'Plan/config/hash read only. New adapter-verifier code freezes separately before first reference call.'}
    target.write_text(json.dumps(record,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'plan_freeze_sha256':sha(target),'frozen':record['independent_plan_and_input_sha256']},indent=2))


if __name__=='__main__':
    main()
