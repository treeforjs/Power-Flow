"""New-input reference wrapper and independent flux for width controls."""
from decimal import localcontext
from fractions import Fraction

from decimal_forced_reference import KB, ReferenceParameters, reference_grid, represented


def scalar_case(config,declaration):
    return {'case_id':declaration['case_id'],'problem':config['common_scalar_problem'],
        'duration_s':config['duration_s'],
        'segments':[{'start_s':0.0,'stop_s':config['duration_s'],
            'power_w_m2':declaration['power_w_m2'],'power_provenance':declaration['power_provenance']}],
        'step_grids':[[config['steps']]]}


def new_reference(case,*,precision,order,subdivisions,quadrature_order):
    steps=case['step_grids'][0][0]
    stop=Fraction.from_float(float(case['duration_s']))
    times=[stop*Fraction(step,steps) for step in range(steps+1)]
    schedule={'duration_s':case['duration_s'],'segments':[dict(case['segments'][0],steps=steps)]}
    samples=reference_grid(case['problem'],schedule,times,precision=precision,order=order,
        subdivisions=subdivisions,quadrature_order=quadrature_order)
    with localcontext() as context:
        context.prec=precision
        parameters=ReferenceParameters.from_inputs(case['problem'])
        power=represented(case['segments'][0]['power_w_m2'])
        for sample in samples.values():
            n,temperature=sample['coverage_m2'],sample['temperature_k']
            barrier=parameters.activation*(1-parameters.alpha*n/parameters.nref)
            if not (barrier>=0 and n>=0 and temperature>0):
                raise ValueError('new reference flux outside supported domain')
            flux=parameters.nu*n*(-barrier/(KB*temperature)).exp()
            sample['release_flux_m2_s']=flux
            translation=2*KB*temperature*flux
            wall=(parameters.removal+parameters.internal+2*KB*temperature)*flux
            sample['rhs_reference']={'release_flux_m2_s':flux,'coverage_rate_m2_s':-flux,
                'temperature_rate_k_s':(power-wall)/parameters.capacity,'input_power_j_m2_s':power,
                'binding_power_j_m2_s':parameters.removal*flux,'internal_power_j_m2_s':parameters.internal*flux,
                'translational_power_j_m2_s':translation,'total_wall_power_j_m2_s':wall}
    return samples
