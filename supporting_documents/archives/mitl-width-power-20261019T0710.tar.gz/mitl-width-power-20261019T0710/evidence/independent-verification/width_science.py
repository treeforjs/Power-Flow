"""Independent physical-channel aggregation and resolved contrast scales."""
from decimal import Decimal, localcontext

from exact_width_math import decimal_area
from scalar_checks import CHANNELS, budget_scales, normalized

D=Decimal
QUANTITIES={key:(key[:-3] if key.endswith('_j_m2') else {'coverage_m2':'coverage_number',
    'released_m2':'released_number'}[key]) for key in CHANNELS if key!='temperature_k'}
QUANTITIES['release_flux_m2_s']='release_rate_s'
INPUTS={'input_energy_j','prescribed_input_energy_j'}


def case_scales(case,samples):
    scales,notes=budget_scales(case,samples)
    scales['release_flux_m2_s']=max(sample['release_flux_m2_s'] for sample in samples.values())
    return scales,notes


def aggregates(config,references,areas):
    times=sorted(next(iter(references.values())))
    result={}
    for hypothesis,assignment in config['hypotheses'].items():
        result[hypothesis]={time:{extensive:sum((decimal_area(area)*references[key][time][areal]
            for key,area in zip(assignment,areas)),D(0)) for areal,extensive in QUANTITIES.items()}
            for time in times}
    return result


def contrast_reference(config,references,areas):
    totals=aggregates(config,references,areas)
    times=sorted(totals['uniform'])
    contrasts={time:{key:totals['nonuniform'][time][key]-totals['uniform'][time][key]
        for key in totals['uniform'][time]} for time in times}
    scales={key:max(abs(contrasts[time][key]) for time in times) for key in contrasts[times[0]] if key not in INPUTS}
    temperatures={}
    for patch,(nonuniform,uniform) in enumerate(zip(config['hypotheses']['nonuniform'],config['hypotheses']['uniform'])):
        values={time:references[nonuniform][time]['temperature_k']-references[uniform][time]['temperature_k'] for time in times}
        temperatures[patch]={'values':values,'scale':max(map(abs,values.values()))}
    return totals,contrasts,scales,temperatures
