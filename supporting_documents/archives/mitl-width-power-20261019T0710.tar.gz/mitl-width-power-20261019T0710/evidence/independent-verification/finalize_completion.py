"""Static binding of the completed width oracle; no numerical replay."""
import datetime
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
WORK=HERE.parent
REPO=Path('/workspace/Power-Flow')
RUN=WORK/'producer/reference-run'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def display(value):
    return value['float_projection'] if isinstance(value,dict) and 'float_projection' in value else value


def main():
    if (HERE/'completion.json').exists() or (HERE/'summary.json').exists():
        raise RuntimeError('refuse replacement of completion/summary')
    report_path=HERE/'oracle-initial/report.json';report=load(report_path)
    assert report['schema']=='mitl-independent-width-power-oracle-v1'
    assert report['status']=='passed' and report['all_checks_passed'] is True
    expected={'new_scalar_cases':3,'unique_scalar_reference_samples':195,'unique_scalar_flux_references':195,
        'saved_scalar_rows_checked':195,'scalar_CSV_JSON_cells_checked':3315,'scalar_RHS_CSV_cells_checked':1755,
        'scalar_area_once_checks':2730,'expanded_patch_samples_checked':390,'aggregate_samples_checked':130,
        'difference_samples_checked':65,'exact_quantity_projection_records_checked':13910,
        'reference_precision_grids':6,'saved_state_flux_evaluations_across_two_precision_grids':390,
        'post_source_cache_records_verified':195,'independent_RHS_field_comparisons':1560,
        'expanded_patch_CSV_rows_checked':390,'aggregate_CSV_rows_checked':130,'comparison_CSV_rows_checked':65}
    assert all(report[key]==value for key,value in expected.items())
    assert report['producer_imports_or_calls']==[] and report['old_case_or_oracle_runs']==0 and report['new_independent_oracle_runs']==1
    frozen=load(HERE/'before_code_freeze.json');amendment=load(HERE/'pre_reference_definition_amendment.json')
    assert amendment['original_code_freeze_sha256']==sha(HERE/'before_code_freeze.json')
    for name,digest in frozen['code_and_input_sha256'].items():
        if name in amendment['changed_file_sha256']:
            assert sha(HERE/(Path(name).stem+'.initial.py'))==digest==amendment['initial_file_sha256'][name]
            digest=amendment['changed_file_sha256'][name]
        assert sha(HERE/name)==digest
    for name,digest in report['input_sha256'].items():
        assert sha(name)==digest
    for name,digest in report['reference_checkpoint_sha256'].items():
        assert sha(report_path.parent/name)==digest
    for file_key,digest_key in (('reference_samples_file','reference_samples_sha256'),('contrast_samples_file','contrast_samples_sha256')):
        assert sha(report_path.parent/report[file_key])==report[digest_key]
    producer=load(RUN/'report.json')
    assert sha(RUN/'report.json')==frozen['saved_producer_report_sha256']
    assert sha(HERE/'input_config.json')==sha(RUN/'input_config.json')==producer['config_sha256']
    for name,digest in producer['artifact_sha256'].items():
        assert sha(RUN/name)==digest
    for item in producer['scalar_histories']:
        assert sha(RUN/item['history_file'])==item['history_file_sha256']
        assert sha(RUN/item['csv_file'])==item['csv_sha256']
    executed_sources={}
    snapshots=list((WORK/'producer/source-versions').glob('*'))
    for name,digest in producer['code_sha256'].items():
        matches=[str(path.relative_to(WORK)) for path in snapshots if path.is_file() and sha(path)==digest]
        assert matches, ('executed source snapshot missing',name)
        executed_sources[name]={'sha256':digest,'preserved_executed_byte_paths':matches,
            'current_repository_sha256':sha(REPO/name),'current_repository_bytes_equal_execution':sha(REPO/name)==digest}
    plot_path=WORK/'producer/plot_correction.json'
    assert plot_path.is_file()
    command_records=[json.loads(line) for line in (WORK/'commands.jsonl').read_text().splitlines()]
    oracle_runs=[row for row in command_records if Path(row['log']).name=='independent-width-power-oracle-initial.log']
    assert len(oracle_runs)==1 and oracle_runs[0]['exit_code']==0
    assert sha(oracle_runs[0]['log'])==oracle_runs[0]['log_sha256']
    contrast=max((display(value),key) for key,value in report['own_contrast_errors'].items())
    contrast_stability=max((display(value),key) for key,value in report['own_contrast_reference_stability'].items())
    rate=max((display(value),case,key) for case,quantities in report['instantaneous_rate_errors'].items() for key,value in quantities.items())
    stability=max((display(value),case,key) for case,quantities in report['reference_stability'].items() for key,value in quantities.items())
    aggregate=max((display(value),hypothesis,key) for hypothesis,quantities in report['aggregate_errors'].items() for key,value in quantities.items())
    physics=max((display(value),hypothesis,key) for hypothesis,quantities in report['aggregate_physical_C_deltaT_residuals'].items() for key,value in quantities.items())
    final_contrasts={key:{name:display(value) for name,value in row.items()}
        for key,row in report['final_contrasts']['quantities'].items()}
    summary={'schema':'mitl-independent-width-power-summary-v1','status':'passed',**expected,
        'report_sha256':sha(report_path),'max_own_contrast_error_fraction':contrast,
        'max_own_contrast_reference_change_fraction':contrast_stability,'max_individual_rate_error_fraction':rate,
        'max_reference_change_fraction':stability,'max_aggregate_error_fraction':aggregate,
        'max_aggregate_physical_thermal_residual_fraction':physics,'final_contrasts':final_contrasts,
        'summary_uses_display_float_projections':True,'numerical_resolution_is_physical_or_statistical_confidence':False,
        'limits':'Signed manufactured width contrasts only. Own grid-resolved contrast scales supplement separate trajectory/gross checks; physical water, material, spectra, transport or host acceptance is not established.'}
    (HERE/'summary.json').write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n')
    artifacts=[path for path in HERE.glob('*.py')]+[path for path in HERE.glob('*.json') if path.name!='completion.json']
    artifacts+=[path for path in (HERE/'oracle-initial').glob('*.json')]
    artifacts.append(HERE/'method.md')
    record={'schema':'mitl-independent-width-power-completion-v1','status':'passed','all_checks_passed':True,
        'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),**expected,
        'grouped_quantity_projection_checks':13910,'additional_input_projection_checks':196,
        'total_exact_quantity_projection_checks':14106,'scalar_numeric_CSV_cells_checked':5070,
        'reference_checkpoint_files':6,'new_independent_oracle_runs':1,
        'old_case_or_oracle_runs':0,'producer_imports_or_calls':[],
        'independent_RHS_uses_one_flux_per_saved_state':True,'all_eight_RHS_fields_checked':True,
        'exact_area_and_power_identity_verified':True,'full_patch_mixtures_preserved':True,
        'own_resolved_contrast_scales_checked':True,'separate_gross_scalar_and_physical_ledger_checks_passed':True,
        'no_physical_or_statistical_sign_confidence_claimed':True,
        'physical_water_material_monolayer_spectra_FLASH_Hall_gap_or_host_verified':False,
        'dense_Taylor_coefficients_or_off_knot_queries_retained':False,
        'mathematical_dependency_reused_for_NEW_inputs_only':'b6740c00a75b094ea36c9d6c1d941cbe31e19b8100a200613ef8961136c8da89',
        'report':'independent-verification/oracle-initial/report.json','report_sha256':sha(report_path),
        'summary':'independent-verification/summary.json','summary_sha256':sha(HERE/'summary.json'),
        'producer_report_sha256':sha(RUN/'report.json'),'producer_executed_code_association':executed_sources,
        'plot_correction_lineage':str(plot_path.relative_to(WORK)),'plot_correction_lineage_sha256':sha(plot_path),
        'plot_only_final_CLI_change_is_not_a_numerical_execution':True,
        'artifact_sha256':{str(path.relative_to(WORK)):sha(path) for path in sorted(set(artifacts))},
        'artifact_map_base':'work_directory','command_records':oracle_runs,
        'qualification':report['qualification'],'limitations':summary['limits']}
    target=HERE/'completion.json';target.write_text(json.dumps(record,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'completion_sha256':sha(target),'summary_sha256':sha(HERE/'summary.json'),
        'report_sha256':sha(report_path),'max_own_contrast_error_fraction':contrast,
        'new_cases':3,'unique_reference_states':195,'expanded_patch_samples':390},indent=2))


if __name__=='__main__':
    main()
