"""Independent geometry and represented-quantity algebra for width checks."""
from decimal import Decimal
from fractions import Fraction as F
import hashlib
import json
import math
import sys


def canonical_sha(document):
    return hashlib.sha256(json.dumps(document,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()


def same(actual,expected):
    if type(actual) is not type(expected):
        raise RuntimeError('typed source association differs')
    if isinstance(expected,float):
        if actual.hex()!=expected.hex():
            raise RuntimeError('source float association differs')
    elif isinstance(expected,dict):
        if actual.keys()!=expected.keys():
            raise RuntimeError('source key association differs')
        for key in expected:
            same(actual[key],expected[key])
    elif isinstance(expected,list):
        if len(actual)!=len(expected):
            raise RuntimeError('source list association differs')
        for a,e in zip(actual,expected):
            same(a,e)
    elif actual!=expected:
        raise RuntimeError('source association differs')


def pair(record):
    n,d=record['numerator'],record['denominator']
    if type(n)is not str or type(d)is not str or n!=str(int(n)) or d!=str(int(d)) or int(d)<=0:
        raise RuntimeError('noncanonical rational declaration')
    value=F(int(n),int(d))
    if str(value.numerator)!=n or str(value.denominator)!=d:
        raise RuntimeError('nonreduced rational declaration')
    return value


def geometry(config):
    source=config['geometry']
    edges=[pair(record) for record in source['width_edges_m']]
    length=pair(source['common_length_m'])
    for record,value in zip([*source['width_edges_m'],source['common_length_m']],[*edges,length]):
        same(record['value'],float(value))
    if edges!=[F(-1,512),F(-1,1024),F(1,1024),F(1,512)] or length!=F(1,128):
        raise RuntimeError('frozen manufactured geometry differs')
    areas=[(b-a)*length for a,b in zip(edges,edges[1:])]
    if areas!=[F(1,131072),F(1,65536),F(1,131072)]:
        raise RuntimeError('independent dyadic areas differ')
    return edges,length,areas


def represented(value):
    if type(value) not in (float,int) or not math.isfinite(float(value)):
        raise RuntimeError('invalid represented scalar')
    return F.from_float(float(value))


def areal_mapping(sample):
    result={key:key[:-3] for key in sample if key.endswith('_j_m2')}
    result.update({'coverage_m2':'coverage_number','released_m2':'released_number',
        'inventory_residual_m2':'inventory_residual_number'})
    return result


def aggregate_represented(samples,fluxes,areas,flux_name):
    result={}
    for sample,flux,area in zip(samples,fluxes,areas):
        for areal,extensive in areal_mapping(sample).items():
            result[extensive]=result.get(extensive,F(0))+area*represented(sample[areal])
        result[flux_name]=result.get(flux_name,F(0))+area*represented(flux)
    return result


def check_projection(record,exact):
    if set(record)!={'exact','value','projection'} or pair(record['exact'])!=exact:
        raise RuntimeError('exact represented quantity differs')
    value=float(exact)
    same(record['value'],value)
    projected=F.from_float(value)
    flags={'exact_zero':exact==0,'positive':exact>0,'negative':exact<0,
        'finite':True,'underflowed':value==0 and exact!=0,'overflowed':False,
        'rounded':projected!=exact,'subnormal':0<abs(value)<sys.float_info.min}
    projection=record['projection']
    if set(projection)!={*flags,'exact_rounding_error'}:
        raise RuntimeError('projection qualification keys differ')
    for key,expected in flags.items():
        same(projection[key],expected)
    if pair(projection['exact_rounding_error'])!=projected-exact:
        raise RuntimeError('signed rounding error differs')


def recomputed_residuals(samples,areas,problem,*,physical_thermal=False):
    n0=represented(problem['initial_coverage_m2'])
    t0=represented(problem['initial_temperature_k'])
    capacity=represented(problem['areal_heat_capacity_j_m2_k'])
    qe=F('1.602176634e-19')
    removal=represented(problem['reservoir']['desorption_energy_ev'])*qe
    internal=represented(problem['reservoir']['internal_energy_ev'])*qe
    result={}
    for sample,area in zip(samples,areas):
        n,m,t=(represented(sample[key]) for key in ('coverage_m2','released_m2','temperature_k'))
        binding,gas_internal,translation,wall,ein,prescribed=(represented(sample[key]) for key in
            ('binding_energy_j_m2','internal_energy_j_m2','translational_energy_j_m2',
             'total_wall_energy_debit_j_m2','input_energy_j_m2','prescribed_input_energy_j_m2'))
        thermal=capacity*(t-t0) if physical_thermal else represented(sample['wall_thermal_change_j_m2'])
        values={'inventory_residual_number':n+m-n0,
            'adsorbate_reference_residual_j':removal*(n0-n-m),
            'wall_debit_residual_j':thermal-ein+wall,
            'wall_channel_residual_j':wall-binding-gas_internal-translation,
            'binding_allocation_residual_j':binding-removal*m,
            'internal_allocation_residual_j':gas_internal-internal*m,
            'total_energy_residual_j':thermal+removal*(n0-n)+gas_internal+translation-ein,
            'input_energy_residual_j':ein-prescribed}
        for key,value in values.items():
            result[key]=result.get(key,F(0))+area*value
    return result


def decimal_area(area):
    return Decimal(area.numerator)/Decimal(area.denominator)
