"""Correct finite-support plotting only, using saved scalar CSVs and config."""
import ast,csv,difflib,hashlib,importlib.util,json,pathlib,sys
W=pathlib.Path(__file__).resolve().parent;R=pathlib.Path('/workspace/Power-Flow');RUN=W/'reference-run';OUT=W/'plot-correction'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
report=load(RUN/'report.json');freeze=load(W/'freeze.json')
assert sha(RUN/'report.json')=='21031ac2ef2f1a59bff3ed2afa3efbf7de6b984a4b09fe7d64f0ad5ba2e44cd7'
for name,digest in report['artifact_sha256'].items():assert sha(RUN/name)==digest,name
initial=W/'source-versions/executed_cli_before_plot_support_fix.py';final=R/'tools/run_thermal_width_power_reference.py'
assert sha(initial)==report['code_sha256']['tools/run_thermal_width_power_reference.py']=='57e4717b48920d1657f3e4ad156bad7a72066c96137b971d47552570475ff72b'
a,b=ast.parse(initial.read_text()),ast.parse(final.read_text())
x={n.name:ast.dump(n,include_attributes=False) for n in a.body if isinstance(n,ast.FunctionDef)};y={n.name:ast.dump(n,include_attributes=False) for n in b.body if isinstance(n,ast.FunctionDef)}
assert [k for k in x if x[k]!=y[k]]==['_plots']
assert final.read_text()==initial.read_text().replace('ax.stairs(values, [x*1e3 for x in edges], label=name, linewidth=2)','ax.stairs(values, [x*1e3 for x in edges], label=name, linewidth=2, baseline=None)')
assert not OUT.exists();OUT.mkdir()
spec=importlib.util.spec_from_file_location('width_plot_only',final);cli=importlib.util.module_from_spec(spec);spec.loader.exec_module(cli)
config=load(RUN/'input_config.json');scalar_rows={};inputs={'reference-run/report.json':sha(RUN/'report.json'),'reference-run/input_config.json':sha(RUN/'input_config.json')}
for record in report['scalar_histories']:
 p=RUN/record['csv_file'];assert sha(p)==record['csv_sha256'];inputs['reference-run/'+p.name]=sha(p)
 with p.open() as stream:rows=list(csv.DictReader(stream))
 scalar_rows[record['case_id']]=[{key:float(row[key]) for key in ('time_s','temperature_k','released_m2','translational_energy_j_m2')} for row in rows]
cli._plots(config,scalar_rows,OUT)
assert not any(n in sys.modules for n in ('mhdlab.thermal_width_power_reference','mhdlab.thermal_forced_feedback_reference','mhdlab.thermal_power_reference','mhdlab.thermal_feedback_reference'))
for name,digest in report['artifact_sha256'].items():assert sha(RUN/name)==digest,name
(W/'plot_support_fix.diff').write_text(''.join(difflib.unified_diff(initial.read_text().splitlines(True),final.read_text().splitlines(True),fromfile='executed_numerical_cli.py',tofile='final_public_plot_only_cli.py')))
d={'schema':'mhdlab-width-power-plot-support-amendment-v1','status':'rerendered_from_saved_rows_only','reason':'Default stairs baseline0 closed finite-support profiles to zero at domain edges; baseline=None preserves the supported profile without inventing endpoint zeros.','numerical_run_report':'producer/reference-run/report.json','numerical_run_report_sha256':sha(RUN/'report.json'),'numerical_run_cli_sha256':sha(initial),'executed_cli_snapshot':'producer/source-versions/executed_cli_before_plot_support_fix.py','final_public_cli_sha256':sha(final),'changed_function':'_plots','exact_source_change':'Only append baseline=None to the width-profile ax.stairs call. All source text outside that replacement is byte-identical.','diff_path':'producer/plot_support_fix.diff','diff_sha256':sha(W/'plot_support_fix.diff'),'script_sha256':sha(pathlib.Path(__file__)),'saved_input_sha256':inputs,'input_path_base':'producer directory','original_plot_sha256':{n:report['artifact_sha256'][n] for n in ('width_profiles.png','width_profiles.pdf','scalar_histories.png','scalar_histories.pdf')},'corrected_plot_sha256':{'plot-correction/'+p.name:sha(p) for p in OUT.iterdir()},'corrected_plot_path_base':'producer directory','original_numerical_report_and_artifacts_unchanged':True,'model_rhs_adapter_or_evolution_imports_or_calls':False,'saved_scalar_rows_only':True,'positive_numerical_batch_repeated':False}
(W/'plot_correction.json').write_text(json.dumps(d,indent=2,allow_nan=False)+'\n')
print(json.dumps({'status':d['status'],'amendment_sha256':sha(W/'plot_correction.json'),'numerical_cli_sha256':sha(initial),'final_public_cli_sha256':sha(final),'corrected_plot_sha256':d['corrected_plot_sha256']},indent=2))
