"""Read saved exports and record completion; no model or adapter imports."""
import csv,datetime,hashlib,json,pathlib
from fractions import Fraction
W=pathlib.Path(__file__).resolve().parent;P=W.parent;R=pathlib.Path('/workspace/Power-Flow');RUN=W/'reference-run'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
def rows(p):
 with p.open() as f:return list(csv.DictReader(f))
def rat(v):return Fraction(int(v['numerator']),int(v['denominator']))
def record(row,prefix,v):
 assert float(row[prefix])==v['value']
 assert row[prefix+'__exact_numerator']==v['exact']['numerator']
 assert row[prefix+'__exact_denominator']==v['exact']['denominator']
 assert json.loads(row[prefix+'__projection_json'])==v['projection']
report=load(RUN/'report.json');freeze=load(W/'freeze.json');amend=load(W/'plot_correction.json');doc=load(RUN/'width_assembly.json')
assert report['artifact_path_base']=='directory containing report.json'
for name,digest in report['artifact_sha256'].items():assert sha(RUN/name)==digest,name
for name,digest in freeze['public_source_sha256'].items():
 p=W/'source-versions/executed_cli_before_plot_support_fix.py' if name=='tools/run_thermal_width_power_reference.py' else R/name
 assert sha(p)==digest,name
assert sha(R/'tools/run_thermal_width_power_reference.py')==amend['final_public_cli_sha256']
assert report['code_sha256']=={p:d for p,d in freeze['public_source_sha256'].items() if p.endswith('.py')}
commands=[json.loads(line) for line in (P/'commands.jsonl').read_text().splitlines()]
batches=[x for x in commands if 'tools/run_thermal_width_power_reference.py' in x['command']]
assert len(batches)==1 and batches[0]['exit_code']==0 and batches[0]['command']==freeze['production_command']
assert report['distinct_scalar_evolution_calls']==report['distinct_scalar_history_count']==3
assert report['unique_scalar_samples']==195
assert doc['cache']['distinct_scalar_histories']==3 and doc['cache']['scalar_samples']==195
assert doc['cache']['rhs_evaluations']==195 and doc['cache']['patch_history_references']==6 and doc['cache']['scalar_evolutions_by_assembly']==0
scalar_count=0
for item in report['scalar_histories']:
 key=item['case_id'];history=load(RUN/item['history_file']);tab=rows(RUN/item['csv_file']);cached=doc['scalar_histories'][key]
 canonical=hashlib.sha256(json.dumps(history,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
 assert canonical==item['canonical_history_sha256']==cached['history_sha256']
 assert history==cached['history'] and len(tab)==len(history['samples'])==65
 assert sha(RUN/item['history_file'])==item['history_file_sha256'] and sha(RUN/item['csv_file'])==item['csv_sha256']
 duration=Fraction.from_float(history['schedule']['duration_s'])
 for i,(row,sample,rhs,flux,logical) in enumerate(zip(tab,history['samples'],cached['rhs'],cached['release_flux_m2_s'],cached['logical_time_s'])):
  assert row['case_id']==key and int(row['sample_index'])==i
  assert int(row['segment_index'])==sample['segment_index']==0 and int(row['segment_step'])==sample['segment_step']==i
  assert rat(logical)==duration*i/64 and float(row['time_s'])==float(rat(logical))
  for name,value in sample.items():
   if name=='extensive':
    for ek,ev in value.items():assert float(row[ek])==ev
   else:assert float(row[name])==value
  assert row['state_id']==history['problem']['reservoir']['state_id']
  assert float(row['release_flux_m2_s'])==flux==rhs['release_flux_m2_s']
  for name,value in rhs.items():assert float(row['instantaneous__'+name])==value
 scalar_count+=len(tab)
assert scalar_count==195
patchtab=rows(RUN/'patch_samples.csv');totaltab=rows(RUN/'aggregate_samples.csv');difftab=rows(RUN/'width_comparison.csv')
assert (len(patchtab),len(totaltab),len(difftab))==(390,130,65)
pi=ti=0
for name,hypothesis in doc['hypotheses'].items():
 for patch in hypothesis['patches']:
  for i,sample in enumerate(patch['samples']):
   row=patchtab[pi];pi+=1
   assert row['hypothesis']==name and int(row['patch_index'])==patch['patch_index'] and int(row['sample_index'])==i
   for field in ('width_left_m','width_right_m','area_m2'):assert float(row[field])==patch[field]
   for field in ('state_id','scalar_history_id','history_sha256'):assert row[field]==patch[field]
   assert json.loads(row['area_exact_json'])==patch['area_exact_m2']
   assert json.loads(row['logical_time_json'])==sample['logical_time_s']
   assert float(row['time_s'])==sample['time_s']
   for k,v in sample['areal'].items():assert float(row['areal__'+k])==v
   for k,v in sample['extensive'].items():record(row,'extensive__'+k,v)
 for i,sample in enumerate(hypothesis['totals']):
  row=totaltab[ti];ti+=1
  assert row['hypothesis']==name and int(row['sample_index'])==i and row['state_id']==sample['state_id']
  assert float(row['time_s'])==sample['time_s'] and json.loads(row['logical_time_json'])==sample['logical_time_s']
  for section in ('extensive','recomputed_residuals'):
   for k,v in sample[section].items():record(row,section+'__'+k,v)
for i,(row,sample) in enumerate(zip(difftab,doc['comparison']['samples'])):
 assert int(row['sample_index'])==i and float(row['time_s'])==sample['time_s']
 assert json.loads(row['logical_time_json'])==sample['logical_time_s']
 for k,v in sample['difference_nonuniform_minus_uniform'].items():record(row,'difference__'+k,v)
 for k in ('exact_prescribed_input_energy_j','integrated_input_difference_j','prescribed_input_difference_j'):record(row,k,sample[k])
assert rat(doc['comparison']['exact_total_input_power_w']['exact'])==rat(report['exact_input_matching']['total_input_power_w'])
assert rat(doc['geometry']['total_area_exact_m2'])==rat(report['exact_input_matching']['total_area_m2'])
for name,digest in amend['corrected_plot_sha256'].items():assert sha(W/name)==digest,name
artifacts={str(p.relative_to(P)):sha(p) for p in W.rglob('*') if p.is_file() and p.name!='completion.json' and '__pycache__' not in p.parts}
final={k:v['value'] for k,v in doc['comparison']['samples'][-1]['difference_nonuniform_minus_uniform'].items()}
completion={'schema':'mhdlab-width-power-producer-completion-v1','status':'passed_production_and_saved_export_checks','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'report_path':'producer/reference-run/report.json','report_sha256':sha(RUN/'report.json'),'assembly_path':'producer/reference-run/width_assembly.json','assembly_sha256':sha(RUN/'width_assembly.json'),'config_sha256':report['config_sha256'],'numerical_run_code_sha256':report['code_sha256'],'final_public_cli_sha256':amend['final_public_cli_sha256'],'plot_support_amendment':{'path':'producer/plot_correction.json','sha256':sha(W/'plot_correction.json'),'original_numerical_report_and_artifacts_unchanged':True,'corrected_plot_path':'producer/plot-correction/width_profiles.png'},'export_only_preproduction_amendment':{'path':'producer/export_amendment.json','sha256':sha(W/'export_amendment.json'),'all_parser_ASTs_unchanged':True},'positive_batch_count':1,'batch':batches[0],'distinct_scalar_evolution_calls':3,'distinct_scalar_history_count':3,'unique_scalar_samples':195,'expanded_patch_samples':390,'aggregate_samples':130,'comparison_samples':65,'cache':doc['cache'],'reuse_map':report['reuse_map'],'exact_input_matching':report['exact_input_matching'],'accepted_prerequisite_sha256':freeze['accepted_prerequisite_sha256'],'new_adapter_test_history':freeze['new_adapter_test_history'],'new_unique_adapter_checks':34,'parser_evidence':freeze['parser_evidence'],'saved_readback':{'all_raw_and_canonical_input_history_hashes_verified':True,'all_scalar_cached_RHS_fields_and195logical_times_copied_exactly':True,'all390patch130aggregate65comparisonCSV_records_match_nativeJSON':True,'all_extensive_exact_values_and_signed_projection_diagnostics_retained':True,'exact_total_geometry_and_prescribed_power_match_config':True,'no_model_rhs_or_adapter_imports_or_calls':True},'final_signed_differences_nonuniform_minus_uniform':final,'independent_error_or_sign_qualification_included_here':False,'visual_inspection':'Original false zero-edge stair closure identified and retained; corrected finite-support width PNG viewed legible with baseline=None. Scalar histories PNG viewed legible.','artifact_sha256':artifacts,'artifact_path_base':'pass directory containing producer/','open_substantive_findings':[],'old_suites_sources_or_numerical_cases_replayed':False,'limits':['Manufactured independent width patches only; exact input matching is a represented-data identity.','Signed aggregate differences require separate independent trajectory/flux/channel error qualification; no physical observability is established here.','No actual water/material/monolayer inference, field heating, conduction, launch, gap, spectra, owner solver, Hall, FLASH or host transaction.']}
(W/'completion.json').write_text(json.dumps(completion,indent=2,allow_nan=False)+'\n')
print(json.dumps({'status':completion['status'],'completion_sha256':sha(W/'completion.json'),'report_sha256':completion['report_sha256'],'assembly_sha256':completion['assembly_sha256'],'numerical_run_cli_sha256':report['code_sha256']['tools/run_thermal_width_power_reference.py'],'final_public_cli_sha256':amend['final_public_cli_sha256'],'cache':doc['cache'],'counts':{'scalar195':scalar_count,'patch':len(patchtab),'aggregate':len(totaltab),'comparison':len(difftab)},'final_signed_differences':final},indent=2))
