"""Fresh width-reference input controls only; no model or adapter import."""
import copy,hashlib,importlib.util,json,pathlib,sys,tempfile
R=pathlib.Path('/workspace/Power-Flow');W=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('width_parser',R/'tools/run_thermal_width_power_reference.py');cli=importlib.util.module_from_spec(spec);spec.loader.exec_module(cli)
p=R/'configs/thermal_width_power_manufactured.json';raw=p.read_text();base=json.loads(raw);cases=[]
def mutation(name,edit):
 x=copy.deepcopy(base);edit(x);cases.append((name,json.dumps(x)))
def lexeme(name,key,old,new):
 needle=json.dumps(key)+': '+old;assert needle in raw
 cases.append((name,raw.replace(needle,json.dumps(key)+': '+new,1)))
lexeme('raw_geometry_alias_lost_by_float','value','-0.001953125','-0.00195312500000000000000001')
mutation('noncanonical_rational_integer',lambda x:x['geometry']['width_edges_m'][0].update(numerator='-01'))
mutation('unreduced_geometry_rational',lambda x:x['geometry']['width_edges_m'][0].update(numerator='-2',denominator='1024'))
mutation('nonincreasing_geometry',lambda x:x['geometry']['width_edges_m'].__setitem__(1,copy.deepcopy(x['geometry']['width_edges_m'][0])))
mutation('boolean_step_count',lambda x:x.update(steps=True))
mutation('wrong_bounded_grid',lambda x:x.update(steps=65))
mutation('scalar_reference_area_not_one',lambda x:x['common_scalar_problem'].update(patch_area_m2=.5))
mutation('unequal_power_no_normalization',lambda x:x['scalar_cases'][0].update(power_w_m2=60000001))
lexeme('raw_power_mismatch_erased_by_float','power_w_m2','90000000','90000000.00000000000000001')
mutation('physical_parameter_status_not_admitted',lambda x:x.update(parameter_status='physical'))
mutation('wrong_patch_history_reuse',lambda x:x['hypotheses']['nonuniform'].__setitem__(2,'middle_power'))
mutation('zero_base_activation',lambda x:x['common_scalar_problem']['reservoir'].update(activation_energy_ev=0))
lexeme('raw_negative_effective_barrier','coverage_coefficient','0.6','1.000000000000000000001')
lexeme('positive_cost_underflow','desorption_energy_ev','0.12','1e-1000')
lexeme('positive_duration_underflow','duration_s','2e-07','1e-100000000')
results=[]
with tempfile.TemporaryDirectory(prefix='width-parser-') as tmp:
 for name,text in cases:
  q=pathlib.Path(tmp)/(name+'.json');q.write_text(text)
  try:cli.load_config(q)
  except (ValueError,TypeError,OverflowError) as exc:results.append({'name':name,'outcome':'rejected','error_type':type(exc).__name__,'reason':str(exc)})
  else:raise RuntimeError(name+' was admitted')
 config=cli.load_config(p)
 assert len(config['scalar_cases'])==3 and config['steps']==64
 assert config['exact_input_matching']['raw_decimal_power_equality_checked']
 assert config['exact_input_matching']['represented_power_equality_checked']
 assert config['exact_input_matching']['total_input_power_w']['numerator']=='234375'
 assert config['exact_input_matching']['total_input_power_w']['denominator']=='128'
 results.append({'name':'approved_three_history_exact_input_plan','outcome':'accepted_without_evolution','distinct_histories':3,'unique_scalar_samples':195,'expanded_patch_samples':390})
assert not any(k in sys.modules for k in ('mhdlab.thermal_width_power_reference','mhdlab.thermal_forced_feedback_reference','mhdlab.thermal_power_reference','mhdlab.thermal_feedback_reference'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
report={'schema':'mhdlab-width-power-parser-checks-v1','status':'passed','script_sha256':sha(pathlib.Path(__file__)),'cli_sha256':sha(R/'tools/run_thermal_width_power_reference.py'),'config_sha256':sha(p),'rejected_configs':len(cases),'accepted_plans_without_evolution':1,'checks':results,'model_or_adapter_imports_or_calls':False,'raw_geometry_and_power_equality_checked_before_projection':True,'no_equality_repair_or_normalization':True}
(W/'parser_guard_checks.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps({'status':'passed','rejected_configs':len(cases),'accepted_plans_without_evolution':1,'report_sha256':sha(W/'parser_guard_checks.json')},indent=2))
