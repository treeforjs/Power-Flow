"""Static export-only amendment qualification; no model or adapter import."""
import ast,hashlib,json,pathlib
R=pathlib.Path('/workspace/Power-Flow');W=pathlib.Path(__file__).resolve().parent
initial=W/'source-versions/initial_cli_before_cached_rhs_export.py';final=R/'tools/run_thermal_width_power_reference.py'
a,b=ast.parse(initial.read_text()),ast.parse(final.read_text())
old={n.name:ast.dump(n,include_attributes=False) for n in a.body if isinstance(n,ast.FunctionDef)}
new={n.name:ast.dump(n,include_attributes=False) for n in b.body if isinstance(n,ast.FunctionDef)}
changed=[name for name in old if old[name]!=new[name]]
assert changed==['run'];compile(b,str(final),'exec')
assert 'cache["rhs"]' in final.read_text() and 'instantaneous__' in final.read_text()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
d={'schema':'mhdlab-width-power-cached-rhs-export-amendment-v1','status':'passed_static_export_check','initial_cli_sha256':sha(initial),'final_cli_sha256':sha(final),'script_sha256':sha(pathlib.Path(__file__)),'changed_functions':changed,'all_parser_and_validation_function_ASTs_unchanged':True,'purpose':'Export the already computed unique saved-state RHS/flux and state label into scalar CSVs; no new RHS evaluation or history evolution call added.','initial_parser_report_sha256':sha(W/'parser_guard_checks.json'),'initial_parser_executions':16,'final_parser_rerun':False,'model_or_adapter_import_or_call':False}
(W/'export_amendment.json').write_text(json.dumps(d,indent=2)+'\n')
print(json.dumps(d,indent=2));print('native_design',json.dumps(json.loads((W.parent/'core/design.json').read_text()),indent=2)[:10000])
