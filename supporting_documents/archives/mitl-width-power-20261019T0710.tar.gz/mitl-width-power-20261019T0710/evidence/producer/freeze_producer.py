"""Freeze exact input, source and accepted prerequisite bytes before sole new batch."""
import datetime,hashlib,json,pathlib,shutil
W=pathlib.Path(__file__).resolve().parent;P=W.parent;R=pathlib.Path('/workspace/Power-Flow')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
expected={'tools/run_thermal_width_power_reference.py':'57e4717b48920d1657f3e4ad156bad7a72066c96137b971d47552570475ff72b','configs/thermal_width_power_manufactured.json':'22f21dae395f31f9a13186821c5364033b50f051aa7296f93839896c2fae4b56','mhdlab/thermal_width_power_reference.py':'ed796e54e9a46a9981459aabc5a09d4da28479f776ef4ce601f85e108cba930c','mhdlab/thermal_forced_feedback_reference.py':'16033899c949896ca346eb6cfb6beb9cdd9d9253c1a110fa9f057a9b8bdeac4d','mhdlab/thermal_power_reference.py':'741ab61b45cc0440b2f133732df387e34bd7630d6b6d5eeb48be7f6e471f1e00','mhdlab/thermal_feedback_reference.py':'3fbded5bc801fac4e847195ecd5ad369142d3ab56e70848c4501ea1425d61cf8'}
for p,d in expected.items():assert sha(R/p)==d,p
pins={'independent-verification/before_plan_freeze.json':'8c52c040c55fbca159938460a214e3e25c925b6608bdb17d39a1f85da18f7c45','independent-verification/oracle_plan.json':'8cd66f5f4c3baa79192dfdc2e86849dfabcdfb2cabdfddb60a6dcd7d28521324','independent-verification/contrast_plan_amendment.json':'7d7c1b8d3016eb3ec83732f69cf9263bf70a0ea76d2afc84c810aecb94759e5d','oracle-review/plan_review.json':'ddf4f2d0daa932372dd05faa34025b5d5881e1b43c689dbd09e5b7ec5cb3ca25','core-review/completion.json':'0d816422583d085fd32de088b9fde173ec07b532b350fceb6ee12885cd70bd93'}
for p,d in pins.items():assert sha(P/p)==d,p
assert json.loads((P/'core-review/completion.json').read_text())['status']=='review_complete_no_substantive_issue_identified'
parser=json.loads((W/'parser_guard_checks.json').read_text());amend=json.loads((W/'export_amendment.json').read_text())
assert parser['status']=='passed' and parser['rejected_configs']==15 and parser['accepted_plans_without_evolution']==1
assert amend['all_parser_and_validation_function_ASTs_unchanged'] and amend['final_cli_sha256']==expected['tools/run_thermal_width_power_reference.py']
assert parser['cli_sha256']==amend['initial_cli_sha256'] and parser['config_sha256']==expected['configs/thermal_width_power_manufactured.json']
commands=[json.loads(line) for line in (P/'commands.jsonl').read_text().splitlines()]
gates=[x for x in commands if any(a.startswith('tests/test_thermal_width_power_reference.py') for a in x['command'])]
assert gates and gates[-1]['exit_code']==0,'final new adapter-only test gate not yet passed'
assert not any('tools/run_thermal_width_power_reference.py' in x['command'] for x in commands)
assert not (W/'reference-run').exists()
versions=W/'source-versions';versions.mkdir(exist_ok=True)
for p in expected:shutil.copyfile(R/p,versions/pathlib.Path(p).name)
report={'schema':'mhdlab-width-power-producer-freeze-v1','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'frozen_before_first_positive_batch','public_source_sha256':expected,'source_snapshots_sha256':{str(p.relative_to(W)):sha(p) for p in versions.iterdir()},'accepted_prerequisite_sha256':pins,'new_adapter_test_history':gates,'adapter_tests_use_synthetic_histories_not_scalar_evolution':True,'parser_evidence':{'path':'producer/parser_guard_checks.json','sha256':sha(W/'parser_guard_checks.json'),'source_version':amend['initial_cli_sha256'],'rejected_configs':15,'accepted_plans_without_evolution':1,'export_only_amendment_path':'producer/export_amendment.json','export_only_amendment_sha256':sha(W/'export_amendment.json'),'parser_ASTs_unchanged':True,'parser_rerun_for_export_change':False},'prior_positive_cli_batches':0,'planned_distinct_new_scalar_histories':3,'planned_steps_per_history':64,'planned_samples_per_history':65,'planned_unique_scalar_samples':195,'planned_expanded_patch_samples':390,'planned_aggregate_samples':130,'planned_comparison_samples':65,'planned_unique_cached_saved_state_rhs_evaluations':195,'old_case_or_old_producer_calls':False,'production_command':['.venv/bin/python','-W','error','tools/run_thermal_width_power_reference.py','--config','configs/thermal_width_power_manufactured.json','--output-dir',str(W/'reference-run'),'--plot']}
(W/'freeze.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps({'freeze':str(W/'freeze.json'),'sha256':sha(W/'freeze.json'),'status':report['status']},indent=2))
