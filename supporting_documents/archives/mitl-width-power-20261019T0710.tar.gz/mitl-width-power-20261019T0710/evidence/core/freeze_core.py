"""Freeze the new assembly source and declaration-only design evidence."""

from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
PASS = ROOT.parent
PUBLIC = Path("/workspace/Power-Flow")
SOURCE = PUBLIC / "mhdlab/thermal_width_power_reference.py"
EXPECTED = "ed796e54e9a46a9981459aabc5a09d4da28479f776ef4ce601f85e108cba930c"


def pin(path: Path) -> dict:
    return {"path": str(path), "sha256": sha256(path.read_bytes()).hexdigest()}


def write(name: str, record: dict) -> None:
    path = ROOT / name
    if path.exists():
        raise ValueError(f"refusing to replace freeze artifact: {name}")
    path.write_text(json.dumps(record, indent=2, allow_nan=False) + "\n")


if pin(SOURCE)["sha256"] != EXPECTED:
    raise ValueError("new assembly source changed before freeze")
snapshot = ROOT / "thermal_width_power_reference.frozen.py"
if snapshot.exists():
    raise ValueError("frozen source snapshot already exists")
snapshot.write_bytes(SOURCE.read_bytes())
design = {
    "schema": "mhdlab-thermal-width-power-core-design-v1",
    "scope": "Manufactured exact-area assembly of three distinct supplied unit-reference-area histories; no time integration is called.",
    "source": pin(SOURCE),
    "api": {
        "geometry": "WidthPowerGeometry(width_edges_m, common_length_m, parameter_status, parameter_provenance)",
        "hash": "scalar_history_sha256(history: ForcedFeedbackHistory) -> str",
        "assembly": "assemble_width_power_reference(histories, *, geometry, hypotheses, history_sha256, history_provenance, parameter_status, parameter_provenance) -> WidthPowerAssembly",
        "result": "WidthPowerAssembly.document is recursively immutable; .to_dict() returns a detached mutable JSON tree.",
    },
    "case_roles": {"uniform_power": 60000000.0, "edge_power": 90000000.0, "middle_power": 30000000.0},
    "hypotheses": {"uniform": ["uniform_power"]*3, "nonuniform": ["edge_power", "middle_power", "edge_power"]},
    "geometry": "Canonical finite exact float coordinates; exact positive areas with exact 1/4,1/2,1/4 weights. No actual-foil association.",
    "source_association": "Required lower-case SHA256 of json.dumps(history.to_dict(),sort_keys=True,separators=(',',':'),allow_nan=False).encode(); raw saved-file hashes remain separate producer metadata.",
    "admission": [
        "Typed scalar records are copied and their problem/reservoir/power data are reconstructed and revalidated.",
        "Each scalar problem has area exactly one and strictly positive base activation energy. Full problem/state/cost/energy-reference/provenance data and complete logical grids must agree.",
        "Each source has one exact finite constant-power schedule of its declared role; segment power provenance can differ but schedule status/common provenance must match.",
        "Indices are strict integers; samples use finite floats without negative zero; initial state, inventory/domain, monotone cumulative channels and complete source extensive mappings are checked.",
        "All derived scalar fields are reconstructed exactly from represented primary values and must match their canonical float projections.",
        "Inventory/energy residual admission uses the declared arithmetic-only 16*(steps+1)*sum relevant-scale ulps budget. This cannot establish ODE accuracy; the fresh independent reference does that.",
        "Original source hashes are rechecked after assembly; no input mutation is performed.",
    ],
    "cache": "One positive-barrier RHS call per source-history/sample identity, cached before assigning patches. All eight rate fields, including Tdot, are retained. The approved 3x65 batch has195 calls and six patch references; no scalar evolution is performed.",
    "aggregation": [
        "Patch extensives are exact Fraction(area)*Fraction(areal field), never source.extensive times area.",
        "Totals sum these unprojected products before one projection; signed nonuniform-minus-uniform differences subtract unprojected totals.",
        "Every extensive quantity retains exact numerator/denominator, float value and projection flags including exact rounding error.",
        "Exact prescribed area-times-power equality is mandatory. Integrated input and already projected prescribed-input channels may retain rounding differences.",
        "Recomputed total residuals are separate from sums of already rounded scalar residual fields.",
        "Full per-patch N,T,time,state,history and flux are exported without averaging temperature or substituting a single thermal velocity.",
    ],
    "output": {
        "schema": "mhdlab-thermal-width-power-reference-v1",
        "sections": ["geometry", "scalar_histories", "hypotheses", "comparison", "cache", "numerical_contract", "limits"],
        "projection_flags": ["exact_zero", "positive", "negative", "finite", "underflowed", "overflowed", "rounded", "subnormal", "exact_rounding_error"],
        "count_keys": ["coverage_number", "released_number", "inventory_residual_number", "release_rate_s"],
        "energy_keys": "All scalar *_j_m2 fields become extensive *_j fields.",
        "key_tree": {
            "root": ["schema", "model_identity", "parameter_status", "parameter_provenance", "geometry", "scalar_histories", "hypotheses", "comparison", "cache", "numerical_contract", "host_budget_accepted", "owner_implementation_verified", "limits"],
            "scalar_record": ["history_sha256", "parameter_provenance", "history", "logical_time_s", "release_flux_m2_s", "rhs"],
            "hypothesis": ["patches", "totals"],
            "patch": ["patch_index", "width_left_m", "width_right_m", "area_m2", "area_exact_m2", "state_id", "scalar_history_id", "history_sha256", "samples"],
            "patch_sample": ["segment_index", "segment_step", "time_s", "logical_time_s", "state_id", "scalar_history_id", "areal", "extensive"],
            "areal": "All ForcedFeedbackSample scalar quantity fields except indices/time/extensive, plus release_flux_m2_s.",
            "total_row": ["segment_index", "segment_step", "time_s", "logical_time_s", "state_id", "extensive", "recomputed_residuals"],
            "comparison": ["exact_total_input_power_w", "samples"],
            "comparison_row": ["time_s", "logical_time_s", "difference_nonuniform_minus_uniform", "exact_prescribed_input_energy_j", "integrated_input_difference_j", "prescribed_input_difference_j"],
            "recomputed_residuals": ["inventory_residual_number", "input_energy_residual_j", "adsorbate_reference_residual_j", "wall_debit_residual_j", "wall_channel_residual_j", "binding_allocation_residual_j", "internal_allocation_residual_j", "total_energy_residual_j"],
            "record": ["exact", "value", "projection"],
            "rational": ["numerator", "denominator"],
            "rhs": ["release_flux_m2_s", "coverage_rate_m2_s", "temperature_rate_k_s", "input_power_j_m2_s", "binding_power_j_m2_s", "internal_power_j_m2_s", "translational_power_j_m2_s", "total_wall_power_j_m2_s"],
        },
        "rhs_units": "coverage/release rates m^-2 s^-1; Tdot K s^-1; all power fields J m^-2 s^-1. RHS list order shares scalar sample indices and exact logical times.",
    },
    "author_numerical_execution": False,
    "physical_parameter_adoption": False,
    "host_budget_accepted": False,
    "owner_implementation_verified": False,
}
write("design.json", design)
freeze = {
    "schema": "mhdlab-thermal-width-power-core-freeze-v1",
    "frozen_utc": datetime.now(timezone.utc).isoformat(),
    "source": pin(SOURCE),
    "snapshot": pin(snapshot),
    "design": pin(ROOT / "design.json"),
    "selected_proposal": pin(PASS / "selected-proposal.json"),
    "preflight_log": pin(PASS / "width-core-final-preflight.log"),
    "data_and_rhs_dependencies": {
        relative: pin(PUBLIC / relative)
        for relative in (
            "mhdlab/thermal_forced_feedback_reference.py",
            "mhdlab/thermal_feedback_reference.py",
            "mhdlab/thermal_power_reference.py",
        )
    },
    "author_evolution_calls": 0,
    "author_rhs_calls": 0,
    "author_test_calls": 0,
    "syntax_and_AST_only": True,
    "production_and_targeted_tests_wait_for_static_review": True,
}
write("source-freeze.json", freeze)
print(json.dumps({"source": pin(SOURCE), "design": pin(ROOT / "design.json"), "freeze": pin(ROOT / "source-freeze.json")}, indent=2))
