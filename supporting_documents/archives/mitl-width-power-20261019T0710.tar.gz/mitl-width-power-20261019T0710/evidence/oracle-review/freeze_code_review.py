"""Freeze static new width-verifier review and pre-reference corrections."""
import datetime as dt
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ORACLE = ROOT.parent / 'independent-verification'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def load(path):
    return json.loads(path.read_text())

if (ROOT / 'pre_run_code_review.json').exists():
    raise RuntimeError('Refuse repeated full-code review freeze')
status = load(Path('/workspace/research_work/mitl-upstream-status.json'))
assert status['active_lease_owner'] == 'mitl-upstream-20261019T0710'
assert dt.datetime.fromisoformat(status['active_editing_lease_until_utc']) > dt.datetime.now(dt.timezone.utc)
assert sha(ROOT / 'plan_review.json') == 'ddf4f2d0daa932372dd05faa34025b5d5881e1b43c689dbd09e5b7ec5cb3ca25'
assert sha(ORACLE / 'before_code_freeze.json') == '7350251b51b59e5934dead4b414d56ff4dc49b57243a08016a976618fc6ee8c8'
assert sha(ORACLE / 'pre_reference_definition_amendment.json') == '40c69031186fb531fca1aaffc4d717bb309bcd8a95ef96f8d08997f0d9b8814e'
freeze = load(ORACLE / 'before_code_freeze.json')
amendment = load(ORACLE / 'pre_reference_definition_amendment.json')
pins = {**freeze['code_and_input_sha256'], **amendment['changed_file_sha256']}
assert all(sha(ORACLE / name) == digest for name, digest in pins.items())
for name, digest in amendment['initial_file_sha256'].items():
    initial = name[:-3] + '.initial.py'
    assert sha(ORACLE / initial) == digest
assert pins['verify_width_power.py'] == '2e287d2f1d554e25fc4ea65f0d7996ff528c1a32a6ea9301baceb71cda45f059'
assert pins['exact_width_math.py'] == '3194f4e0cb563d0325acd3e43337c06d280215293de456da5f477d1c80e1eb57'
findings = [
    {'id': 'represented-versus-unprojected-thermal-residual', 'status': 'repaired_before_first_reference',
     'initial_source': 'exact_width_math.py',
     'issue': 'Exact assembly readback initially reconstructed unprojected C*(T-T0), although the defined aggregate residual consumes the represented saved thermal field. These differ at a legitimate source projection boundary.',
     'correction': 'Exact record checks now use the represented thermal field; separately budgeted unprojected C-deltaT aggregate checks remain independent.',
     'repair_verified_by': 'Narrow frozen-source diff inspection only; no numerical execution.'},
    {'id': 'exact-input-identity-versus-projected-channel-difference', 'status': 'repaired_before_first_reference',
     'initial_source': 'verify_width_power.py',
     'issue': 'The dedicated exact prescribed-input identity was initially checked against a difference of projected scalar prescribed channels.',
     'correction': 'The identity now checks exact area-times-power difference times logical time. The full signed projected-channel difference remains separately checked.',
     'repair_verified_by': 'Narrow frozen-source diff inspection only; no numerical execution.'}
]
checks = [
    ('qualified_math_new_inputs', 'The qualified transformed mathematical dependency is byte-identical. Only the three new forcing inputs and two planned precision ladders are evaluated; no old case/output is reused.'),
    ('geometry_and_exact_source_algebra', 'Independent Fraction geometry derives patch areas and total power. Areal products, sums, differences and signed projection diagnostics are checked independently without production assembly imports.'),
    ('reference_aggregation', 'Independent Decimal channels receive exact areas once, retaining complete source/state/time/temperature association. Gross budgets and own contrast scales remain distinct.'),
    ('full_RHS_completeness', 'One independently computed Gamma per saved state supplies all eight reference rates. Each rate uses its own maximum absolute scale, including signed Tdot; no extra exponential or production RHS call is added.'),
    ('cache_counts', 'The report distinguishes 195 unique final saved-state references from 390 saved-state flux evaluations across two precision ladders. Reused patch copies require no new reference evolution or flux calculation.'),
    ('thermal_projection_definitions', 'Exact represented-source residual checks and unprojected thermal algebra checks now have separate meanings and budgets.'),
    ('input_identity', 'Exact prescribed power/support identity is separate from integrated input and projected prescribed-channel differences.'),
    ('OWN_contrast_and_zero_rules', 'Signed physical count/flux/energy differences use their own maximum absolute independent contrast; initial zeros and exact input identity are structural. Nearzero/crossing sign flags are descriptive numerical diagnostics.'),
    ('scope_and_independence', 'Fresh verification modules read saved JSON/CSV and local reference code only. No production numerical module or old positive example is imported/executed; qualifications exclude physical or owner acceptance.')
]
report = {
    'schema': 'mitl-width-power-oracle-pre-run-code-review-v1',
    'status': 'accepted',
    'completed_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
    'plan_review_sha256': sha(ROOT / 'plan_review.json'),
    'original_code_freeze_sha256': sha(ORACLE / 'before_code_freeze.json'),
    'pre_reference_definition_amendment_sha256': sha(ORACLE / 'pre_reference_definition_amendment.json'),
    'reviewed_code_and_input_sha256': pins,
    'initial_source_sha256': amendment['initial_file_sha256'],
    'full_new_verifier_and_helpers_read': True,
    'findings': findings,
    'checks': [{'area': name, 'static_review_complete': True, 'finding': finding} for name, finding in checks],
    'further_source_changes_requested': False,
    'actual_report_binding_pending': True,
    'scalar_evolution_or_flux_evaluation_executed': False,
    'numerical_models_or_tests_executed': False, 'scientific_module_imported': False,
    'producer_or_oracle_executed': False, 'old_case_or_oracle_replayed': False,
    'physical_parameters_validated': False, 'host_budget_accepted': False,
    'limits': ['Static source/interface/mathematical and claims review only.',
               'Two verifier definition issues were corrected before first reference evaluation; no production equations or tolerances changed.',
               'Actual new numerical comparisons and resolved contrasts still require their planned pass.',
               'Manufactured independent patches only; no real foil/water/ML/spectra/Hall/FLASH/gap/owner acceptance.']
}
path = ROOT / 'pre_run_code_review.json'
path.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'pre_run_code_review': str(path), 'sha256': sha(path), 'schema': report['schema'],
                  'status': report['status'], 'resolved_findings': len(findings)}, indent=2))
