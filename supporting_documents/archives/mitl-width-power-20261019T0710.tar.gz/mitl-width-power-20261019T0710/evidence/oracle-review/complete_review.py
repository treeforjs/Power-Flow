"""Bind actual width-reference results to static review; never replay numerics."""
import datetime as dt
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ORACLE = ROOT.parent / 'independent-verification'
REPORT = ORACLE / 'oracle-initial/report.json'
REPORT_SHA = '5a0b0cfce3fa594376718579645b8ee424bf80b6de0ac5ade0eeab829fc3d84c'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def load(path):
    return json.loads(path.read_text())

if (ROOT / 'completion.json').exists():
    raise RuntimeError('Refuse repeated width oracle-review completion')
status = load(Path('/workspace/research_work/mitl-upstream-status.json'))
assert status['active_lease_owner'] == 'mitl-upstream-20261019T0710'
assert dt.datetime.fromisoformat(status['active_editing_lease_until_utc']) > dt.datetime.now(dt.timezone.utc)
assert sha(ROOT / 'plan_review.json') == 'ddf4f2d0daa932372dd05faa34025b5d5881e1b43c689dbd09e5b7ec5cb3ca25'
assert sha(ROOT / 'pre_run_code_review.json') == '0fee7028be874a004a919dd9d5356c1102fdbbf7902eca0ec36904e3a50818a5'
code_review = load(ROOT / 'pre_run_code_review.json')
assert all(sha(ORACLE / name) == digest for name, digest in code_review['reviewed_code_and_input_sha256'].items())
assert sha(REPORT) == REPORT_SHA
report = load(REPORT)
plan = load(ORACLE / 'oracle_plan.json')
assert report['schema'] == 'mitl-independent-width-power-oracle-v1'
assert report['qualification'] == plan['qualification']
assert report['producer_imports_or_calls'] == []
assert report['old_case_or_oracle_runs'] == 0
assert report['numerical_sign_flags_are_physical_or_statistical_confidence'] is False
assert 'aggregate_physical_C_deltaT_residuals' in report and 'aggregate_residuals' in report
output_pins = {
    report['reference_samples_file']: report['reference_samples_sha256'],
    report['contrast_samples_file']: report['contrast_samples_sha256'],
    **report['reference_checkpoint_sha256']
}
assert len(report['reference_checkpoint_sha256']) == 6
assert all(sha(REPORT.parent / name) == digest for name, digest in output_pins.items())
notes = '''# Matched-width reference and results review

The prospective mathematical/fixture/threshold plan and new independent
adapter verifier were reviewed before the first reference evaluation. The
qualified scalar mathematical dependency was reused unchanged for three new
forcing inputs. No earlier positive case or saved reference supplied results.

Two exact-definition issues were identified before execution and corrected in
the verifier. Exact represented-source residual readback now consumes the
represented thermal field; separate budgeted unprojected C-deltaT checks remain
independent. The dedicated exact prescribed-input identity now uses exact
area-times-power support, while the signed difference of projected prescribed
source channels stays separate. Original sources, freeze and amendment remain
bound. No production equations, geometry, inputs or tolerances changed.

The final verifier preserves complete patch geometry, source/state/time and
temperature mixtures. It independently checks area-once products, unprojected
totals and signed differences, exact matched power and logical support. One
independent Gamma per saved state supplies the eight rate references, including
signed temperature rate. Counts distinguish 195 unique final state/flux
references from 390 saved-state flux evaluations across two precision ladders.
Each physical contrast has its own maximum resolved reference scale, separate
from gross/scalar budgets and exact initial/input controls.

The actual report, reference samples, contrast samples and six case/precision
checkpoints are associated by hash. Its reported passing status, counts, rate
scales and contrast results were read without numerical replay. The configured
manufactured case reports a negative final nonuniform-minus-uniform released
count and a positive expected translational-energy difference. Neither sign was
assumed. These are finite-grid numerical outcomes for supplied parameters, not
physical water, spectral or experimental findings.

The review ran no scalar evolution, flux evaluation, scientific import, test,
producer or oracle. Precision/method changes and descriptive sign flags do not
provide interval certification, statistical confidence or physical uncertainty.
No lateral conduction, real foil geometry/material, water inventory, monolayer,
state chemistry, velocity launch, spectrum, Hall, FLASH, gap or owner/host
acceptance is qualified.
'''
(ROOT / 'review.md').write_text(notes)
observed_fields = (
    'schema', 'status', 'all_checks_passed', 'new_scalar_cases',
    'unique_scalar_reference_samples', 'unique_scalar_flux_references',
    'saved_scalar_rows_checked', 'expanded_patch_samples_checked',
    'aggregate_samples_checked', 'difference_samples_checked',
    'exact_quantity_projection_records_checked', 'reference_precision_grids',
    'saved_state_flux_evaluations_across_two_precision_grids',
    'post_source_cache_records_verified', 'independent_RHS_field_comparisons',
    'expanded_patch_CSV_rows_checked', 'aggregate_CSV_rows_checked',
    'comparison_CSV_rows_checked', 'new_independent_oracle_runs'
)
final_quantities = report['final_contrasts']['quantities']
completion = {
    'schema': 'mitl-width-power-static-oracle-review-v1',
    'status': 'accepted',
    'completed_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
    'plan_review_sha256': sha(ROOT / 'plan_review.json'),
    'pre_run_code_review_sha256': sha(ROOT / 'pre_run_code_review.json'),
    'reviewed_source_sha256': code_review['reviewed_code_and_input_sha256']['verify_width_power.py'],
    'reviewed_reference_math_sha256': code_review['reviewed_code_and_input_sha256']['decimal_forced_reference.py'],
    'reviewed_code_and_input_sha256': code_review['reviewed_code_and_input_sha256'],
    'pre_reference_definition_amendment_sha256': code_review['pre_reference_definition_amendment_sha256'],
    'owner_report_path': str(REPORT), 'owner_report_sha256': REPORT_SHA,
    'actual_report_path': str(REPORT), 'actual_report_sha256': REPORT_SHA,
    'output_artifact_sha256': output_pins,
    'owner_report_observed_declarations': {key: report[key] for key in observed_fields},
    'owner_report_qualifications_match_frozen_plan': True,
    'actual_RHS_own_rate_scales_read': True,
    'actual_OWN_contrast_scales_and_errors_read': True,
    'represented_and_unprojected_thermal_residuals_remain_distinct': True,
    'observed_final_signed_outcomes': {key: final_quantities[key]['reference_difference']
                                       for key in ('released_number', 'translational_energy_j', 'wall_thermal_change_j', 'release_rate_s')},
    'findings': code_review['findings'],
    'review_checks': code_review['checks'],
    'further_changes_requested': False,
    'completed_report_bound_without_numerical_replay': True,
    'owner_report_numerics_recomputed_by_reviewer': False,
    'scalar_evolution_or_flux_evaluation_executed': False,
    'numerical_models_or_tests_executed': False, 'scientific_module_imported': False,
    'producer_or_oracle_executed': False, 'old_case_or_oracle_replayed': False,
    'physical_parameters_validated': False, 'host_budget_accepted': False,
    'limits': ['Static mathematical/source/interface/claims review and actual-result association only.',
               'Two verifier definition issues were corrected before first reference evaluation; no numerical comparison was replayed.',
               'Actual report status/counts/outcomes are observed declarations, not numerical recomputations by this review.',
               'Supplied manufactured independent-patch parameters only; no physical interpretation or spectral discrimination.',
               'No lateral conduction, real foil/H2O/ML/spectra/Hall/FLASH/gap or owner/host acceptance.'],
    'artifact_sha256': {p.name: sha(p) for p in sorted(ROOT.iterdir()) if p.is_file()}
}
path = ROOT / 'completion.json'
path.write_text(json.dumps(completion, indent=2) + '\n')
print(json.dumps({'completion': str(path), 'sha256': sha(path), 'schema': completion['schema'],
                  'status': completion['status'], 'actual_report_path': str(REPORT),
                  'actual_report_sha256': REPORT_SHA}, indent=2))
