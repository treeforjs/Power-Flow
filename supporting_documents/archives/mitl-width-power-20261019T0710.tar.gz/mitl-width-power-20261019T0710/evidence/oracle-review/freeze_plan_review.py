"""Freeze early width-power geometry/reference/contrast-plan review only."""
import datetime as dt
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ORACLE = ROOT.parent / 'independent-verification'
PINS = {
    'oracle_plan.json': '8cd66f5f4c3baa79192dfdc2e86849dfabcdfb2cabdfddb60a6dcd7d28521324',
    'input_config.json': '22f21dae395f31f9a13186821c5364033b50f051aa7296f93839896c2fae4b56',
    'decimal_forced_reference.py': 'b6740c00a75b094ea36c9d6c1d941cbe31e19b8100a200613ef8961136c8da89',
    'before_plan_freeze.json': '8c52c040c55fbca159938460a214e3e25c925b6608bdb17d39a1f85da18f7c45',
    'contrast_plan_amendment.json': '7d7c1b8d3016eb3ec83732f69cf9263bf70a0ea76d2afc84c810aecb94759e5d'
}

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

if (ROOT / 'plan_review.json').exists():
    raise RuntimeError('Refuse repeated width-power plan-review freeze')
status = json.loads(Path('/workspace/research_work/mitl-upstream-status.json').read_text())
assert status['active_lease_owner'] == 'mitl-upstream-20261019T0710'
assert dt.datetime.fromisoformat(status['active_editing_lease_until_utc']) > dt.datetime.now(dt.timezone.utc)
assert all(sha(ORACLE / name) == digest for name, digest in PINS.items())
plan = json.loads((ORACLE / 'oracle_plan.json').read_text())
config = json.loads((ORACLE / 'input_config.json').read_text())
report = {
    'schema': 'mitl-width-power-oracle-plan-review-v1',
    'status': 'plan_review_accepted_for_manufactured_verification',
    'completed_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
    'reviewed_artifact_sha256': PINS,
    'checks': [
        {'area': 'geometry_and_power', 'finding': 'Declared dyadic widths times common length give the stated areas with weights1/4,1/2,1/4. Uniform60 and nonuniform90/30/90 million W/m2 have the same exact area-weighted power over identical support; no fit or integrated-input repair is required.'},
        {'area': 'new_inputs_only', 'finding': 'Three new constant-power forcing cases use the unchanged qualified mathematical reference for new65-sample grids. No prior saved case or oracle output supplies a new reference.'},
        {'area': 'independent_reference', 'finding': 'The transformed coupled IVP retains fixed Nref, independently carried N/T and direct positive count/translation/gross-wall quadrature. New adapter verification must call no producer or production RHS.'},
        {'area': 'area_once_and_mixture', 'finding': 'Areal fields receive true patch area once. Each patch keeps its state/time/history/N/T/flux/channel association; no mean-temperature or velocity substitution is permitted.'},
        {'area': 'flux_reuse', 'finding': 'One independent Gamma per distinct reference saved state gives195 unique references reused across patch copies; no per-copy evolution or duplicate forcing reference is needed.'},
        {'area': 'independent_aggregation', 'finding': 'Exact Fraction producer-algebra checks and independent Decimal-reference aggregation remain separate, including signed conservation residuals and exact prescribed-input identity.'},
        {'area': 'own_contrast_scale', 'finding': 'Each physical count/flux/energy difference is tested on its own max_t absolute independent contrast, in addition to gross/scalar budgets. Initial and prescribed-input zeros and integrated-input roundoff have distinct rules.'},
        {'area': 'sign_and_nearzero_interpretation', 'finding': 'No enhancement/sign is assumed. Crossing or nearzero timestamps retain signed differences and descriptive discrepancy/reference-ladder comparisons without a confidence or forced-sign claim.'},
        {'area': 'prospective_tolerances', 'finding': 'Working precision/order/substep/quadrature changes and explicit2e-5,2e-10,1e-20 budgets are prospective checks. Failure must preserve evidence without clipping, floors, automatic retry or tolerance adjustment.'}
    ],
    'effective_plan_includes_preproduction_contrast_amendment': True,
    'manufactured_label_present': config['parameter_status'] == 'manufactured',
    'qualifications_reviewed': plan['qualification'],
    'full_new_adapter_verifier_review_pending': True,
    'actual_new_reference_results_pending': True,
    'numerical_models_or_tests_executed': False,
    'scalar_evolution_or_flux_evaluation_executed': False,
    'scientific_module_imported': False,
    'old_case_or_oracle_replayed': False,
    'physical_parameters_validated': False, 'host_budget_accepted': False,
    'limits': ['Prospective mathematical/fixture/threshold plan review only.',
               'New assembly source and independent adapter verifier still need separate pre-run review.',
               'Actual three new reference trajectories, fluxes, patch aggregates and contrast budgets must pass.',
               'No lateral conduction, real foil, physical water/monolayer/spectra, Hall/FLASH/gap/owner acceptance.']
}
path = ROOT / 'plan_review.json'
path.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'plan_review': str(path), 'sha256': sha(path), 'schema': report['schema'],
                  'status': report['status'], 'scalar_evolution_or_flux_evaluation_executed': False}, indent=2))
