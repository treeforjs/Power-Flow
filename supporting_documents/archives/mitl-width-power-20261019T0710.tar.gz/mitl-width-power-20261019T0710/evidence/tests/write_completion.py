"""Bind the single saved adapter-only test run; no numerical check is replayed."""
import ast
import hashlib
import json
from pathlib import Path
from xml.etree import ElementTree

WORK=Path(__file__).resolve().parents[1]
REPO=Path('/workspace/Power-Flow')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def main():
    core=REPO/'mhdlab/thermal_width_power_reference.py'
    target=REPO/'tests/test_thermal_width_power_reference.py'
    freeze=load(WORK/'tests/freeze.json')
    amendment=load(WORK/'tests/preexecution-amendment.json')
    assert sha(core)==freeze['public_source_sha256']['mhdlab/thermal_width_power_reference.py']
    assert sha(target)==freeze['public_source_sha256']['tests/test_thermal_width_power_reference.py']==amendment['final_test_sha256']
    old=ast.parse((WORK/'tests/test_thermal_width_power_reference.preexecution.py').read_text())
    new=ast.parse(target.read_text())
    functions=lambda tree:{node.name:ast.dump(node,include_attributes=False)
        for node in tree.body if isinstance(node,ast.FunctionDef)}
    before,after=functions(old),functions(new)
    assert before.keys()==after.keys()
    assert [name for name in before if before[name]!=after[name]]==['forbid_scalar_evolution']
    forbidden={'evolve_forced_feedback','evolve_feedback','evolve_power','forced_feedback_rhs'}
    calls=[ast.unparse(node.func) for node in ast.walk(new) if isinstance(node,ast.Call)]
    assert not any(name.rsplit('.',1)[-1] in forbidden for name in calls)
    root=ElementTree.parse(WORK/'tests/adapter-initial.xml').getroot()
    suites=list(root.findall('testsuite')) if root.tag=='testsuites' else [root]
    counts={key:sum(int(suite.attrib.get(key,'0')) for suite in suites)
        for key in ['tests','failures','errors','skipped']}
    assert counts=={'tests':34,'failures':0,'errors':0,'skipped':0}
    entries=[json.loads(line) for line in (WORK/'commands.jsonl').read_text().splitlines()]
    runs=[entry for entry in entries if Path(entry['log']).name=='width-power-adapter-initial.log']
    assert len(runs)==1 and runs[0]['exit_code']==0
    assert runs[0]['command'][1:3]==['-W','error']
    assert sha(runs[0]['log'])==runs[0]['log_sha256']
    review=WORK/'core-review/completion.json'
    assert sha(review)=='0d816422583d085fd32de088b9fde173ec07b532b350fceb6ee12885cd70bd93'
    assert load(review)['status']=='review_complete_no_substantive_issue_identified'
    artifacts=['tests/plan.json','tests/freeze.json','tests/freeze.initial.json','tests/freeze_test_plan.py',
        'tests/preexecution-amendment.json','tests/canonical_zero_preexecution.py',
        'tests/test_thermal_width_power_reference.preexecution.py','tests/adapter-initial.xml',
        'width-power-adapter-initial.log','width-power-canonical-zero-preexecution.log','tests/write_completion.py']
    result={'schema':'mitl-width-power-adapter-tests-v1','status':'passed','all_checks_passed':True,
        'new_adapter_tests_passed':34,'test_case_executions':34,'targeted_test_runs':1,
        'failed':0,'errors':0,'skipped':0,'warnings_as_errors':True,
        'actual_scalar_evolutions':0,'actual_scalar_RHS_evaluations':0,
        'mock_RHS_fields_per_record':8,'mock_RHS_evaluations_in_cache_control':9,
        'source_histories_in_cache_control':3,'patch_references_in_cache_control':6,
        'fixtures_are_assembly_only':True,'mock_fixture_is_production_truth':False,
        'preexecution_fixture_amendment_preserved':True,'initial_preexecution_source_was_run':False,
        'all_cases_ran_on_final_adapter_and_test_bytes':True,
        'public_source_sha256':{'mhdlab/thermal_width_power_reference.py':sha(core),
            'tests/test_thermal_width_power_reference.py':sha(target)},
        'source_versions':{'unexecuted_initial_test_sha256':amendment['initial_test_sha256'],
            'executed_test_sha256':sha(target),'executed_adapter_sha256':sha(core),
            'preexecution_changed_function':'forbid_scalar_evolution',
            'scientific_adapter_changed':False,'plan_changed':False},
        'plan_sha256':sha(WORK/'tests/plan.json'),'static_review_sha256':sha(review),
        'artifact_sha256':{name:sha(WORK/name) for name in artifacts},'command_records':runs,
        'old_suites_producers_or_oracles_repeated':False,'portable_test_execution_claimed':False,
        'physical_parameters_adopted':0,'actual_FLASH_run':False,'host_budget_accepted':False,
        'limits':'New adapter arithmetic, admission, projection and reuse controls only. Supplied synthetic histories satisfy ledger algebra, not the scalar kinetic IVP. Full mocked RHS records are labelled test inputs. Fresh actual histories and numerical reference accuracy are owned separately.'}
    (WORK/'tests/completion.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':
    main()
