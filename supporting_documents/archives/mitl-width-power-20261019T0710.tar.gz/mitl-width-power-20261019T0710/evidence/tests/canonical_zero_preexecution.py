"""Preserve a pre-execution fixture version and canonicalize its empty rate."""
import hashlib
import json
from pathlib import Path

WORK=Path(__file__).resolve().parents[1]
REPO=Path('/workspace/Power-Flow')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    target=REPO/'tests/test_thermal_width_power_reference.py'
    freeze=WORK/'tests/freeze.json'
    assert sha(target)=='830f7e5f38255869fc2ea394e0aad1bab3f5e12dfca66e8ccb6d8f5405122e2a'
    assert not (WORK/'tests/core-initial.xml').exists()
    initial=WORK/'tests/test_thermal_width_power_reference.preexecution.py'
    initial_freeze=WORK/'tests/freeze.initial.json'
    with initial.open('xb') as stream:
        stream.write(target.read_bytes())
    with initial_freeze.open('xb') as stream:
        stream.write(freeze.read_bytes())
    old='"coverage_rate_m2_s": -float(coverage_m2),'
    new='"coverage_rate_m2_s": -float(coverage_m2) if coverage_m2 else 0.0,'
    text=target.read_text()
    assert text.count(old)==1
    target.write_text(text.replace(old,new))
    document=json.loads(freeze.read_text())
    document['public_source_sha256']['tests/test_thermal_width_power_reference.py']=sha(target)
    document['initial_freeze_sha256']=sha(initial_freeze)
    document['initial_writer_sha256']=document['writer_sha256']
    document['writer_sha256']=sha(__file__)
    document['preexecution_amendment']='tests/preexecution-amendment.json'
    freeze.write_text(json.dumps(document,indent=2)+'\n')
    record={'schema':'mitl-width-power-preexecution-fixture-amendment-v1','status':'ready_before_first_test',
        'reason':'The empty synthetic RHS must return canonical positive zero for coverage_rate rather than unary-minus negative zero.',
        'tests_or_scalar_functions_executed_before_amendment':False,
        'plan_changed':False,'scientific_core_changed':False,
        'initial_test_sha256':sha(initial),'final_test_sha256':sha(target),
        'initial_freeze_sha256':sha(initial_freeze),'final_freeze_sha256':sha(freeze),
        'writer_sha256':sha(__file__)}
    (WORK/'tests/preexecution-amendment.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(record,indent=2))


if __name__=='__main__':
    main()
