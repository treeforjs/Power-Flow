"""Read and pin the adapter test plan without importing scientific modules."""
import argparse
import ast
import hashlib
import json
from pathlib import Path

WORK=Path(__file__).resolve().parents[1]
REPO=Path('/workspace/Power-Flow')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--expected-core-sha256',required=True)
    args=parser.parse_args()
    core=REPO/'mhdlab/thermal_width_power_reference.py'
    target=REPO/'tests/test_thermal_width_power_reference.py'
    assert sha(core)==args.expected_core_sha256
    ast.parse(core.read_text());tree=ast.parse(target.read_text())
    count=0
    for node in tree.body:
        if isinstance(node,ast.FunctionDef) and node.name.startswith('test_'):
            cardinality=1
            for decorator in node.decorator_list:
                if isinstance(decorator,ast.Call) and isinstance(decorator.func,ast.Attribute) and decorator.func.attr=='parametrize':
                    assert isinstance(decorator.args[1],(ast.List,ast.Tuple))
                    cardinality*=len(decorator.args[1].elts)
            count+=cardinality
    forbidden={'evolve_forced_feedback','evolve_feedback','evolve_power','forced_feedback_rhs'}
    calls=[ast.unparse(node.func) for node in ast.walk(tree) if isinstance(node,ast.Call)]
    assert not any(name.rsplit('.',1)[-1] in forbidden for name in calls)
    plan=json.loads((WORK/'tests/plan.json').read_text())
    assert count==plan['expected_new_test_cases']==34
    record={'schema':'mitl-width-power-adapter-test-freeze-v1','status':'frozen_before_first_test_run',
        'expected_new_test_cases':count,'public_source_sha256':{
            'mhdlab/thermal_width_power_reference.py':sha(core),
            'tests/test_thermal_width_power_reference.py':sha(target)},
        'plan_sha256':sha(WORK/'tests/plan.json'),'writer_sha256':sha(__file__),
        'test_source_contains_scalar_RHS_or_evolution_call':False,
        'core_or_tests_imported_or_executed':False,'mock_ledger_is_production_truth':False}
    (WORK/'tests/freeze.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(record,indent=2))


if __name__=='__main__':
    main()
