"""Prepare a five-file width-power comparison patch over an exact complete checkout."""
import argparse
import ast
from decimal import Decimal
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path
import re
import shutil
import subprocess

WORK = Path(__file__).resolve().parent
REPO = Path('/workspace/Power-Flow')
BASE = '3bd20e44ba617cca44cbac2df993e1face2ec221'
HEAD = 'df8eb7026b3a712bf641cbb4d136c497e8af50ba'
OUT = Path('/workspace/handoffs/mitl-width-power-20261019T0710')
PUBLIC = ('mhdlab/thermal_width_power_reference.py', 'tests/test_thermal_width_power_reference.py',
    'tools/run_thermal_width_power_reference.py', 'configs/thermal_width_power_manufactured.json',
    'docs/thermal_width_power_reference.md')
WRAPPERS = ('README.md', 'requirements.txt')
BASELINE_CONTEXT = ('requirements.txt', 'pyproject.toml', 'mhdlab/__init__.py', 'mhdlab/thermal_feedback_reference.py', 'mhdlab/thermal_power_reference.py', 'mhdlab/thermal_forced_feedback_reference.py')


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024*1024), b''):
            digest.update(block)
    return digest.hexdigest()


def object_pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('duplicate JSON key')
        result[key] = value
    return result


def finite_float(value):
    result = float(value)
    if not math.isfinite(result):
        raise ValueError('nonfinite JSON number')
    if result == 0 and Decimal(value) != 0:
        raise ValueError('nonzero JSON number underflows its representation')
    return result


def loads(data):
    return json.loads(data, object_pairs_hook=object_pairs, parse_float=finite_float,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def load(path):
    return loads(Path(path).read_text())


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False)+'\n')


def baseline_bytes(name):
    return subprocess.check_output(['git', 'show', BASE+':'+name], cwd=REPO)


def clean_head(expected):
    assert HEAD is not None and re.fullmatch('[0-9a-f]{40}', expected) and expected == HEAD
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == expected
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=REPO, text=True).strip()
    subprocess.run(['git', 'merge-base', '--is-ancestor', BASE, expected], cwd=REPO, check=True)
    changed = subprocess.check_output(['git', 'diff', '--name-only', BASE, expected], cwd=REPO, text=True).splitlines()
    assert set(changed) == set(PUBLIC) and len(changed) == len(PUBLIC)
    return expected


def dependency_context():
    pins = {}
    for name in BASELINE_CONTEXT:
        content = baseline_bytes(name)
        digest = hashlib.sha256(content).hexdigest()
        assert sha(REPO/name) == digest
        pins[name] = digest
    imports = {}
    for name in PUBLIC:
        if not name.endswith('.py'):
            continue
        tree = ast.parse((REPO/name).read_text())
        imports[name] = sorted({node.module or '' for node in ast.walk(tree) if isinstance(node, ast.ImportFrom)}
            | {alias.name for node in ast.walk(tree) if isinstance(node, ast.Import) for alias in node.names})
    return {'required_complete_baseline_checkout': True, 'baseline_commit': BASE,
        'standalone_source_subset': False, 'empty_initializer_added': False,
        'unchanged_context_sha256': pins, 'declared_imports': imports,
        'intentional_unchanged_numerical_dependency': 'mhdlab/thermal_forced_feedback_reference.py',
        'unchanged_record_dependencies': ['mhdlab/thermal_feedback_reference.py', 'mhdlab/thermal_power_reference.py'],
        'dependency_qualification': 'The scalar implementation is intentionally used for new histories; baseline case outputs and old suites are not replayed as new evidence.',
        'requirements_wrapper_origin': 'Exact bytes of baseline requirements.txt; complete checkout setup remains required.'}


def input_contract():
    """Bind frozen declarations without constructing or advancing a model."""
    name = 'configs/thermal_width_power_manufactured.json'
    config = load(REPO/name)
    assert config['schema'] == 'mhdlab-thermal-width-power-manufactured-config-v1'
    assert config['parameter_status'] == 'manufactured'
    assert all(isinstance(config[key], str) and config[key].strip()
               for key in ('provenance', 'scope', 'time_convention', 'geometry_convention'))

    def exact_geometry(record):
        assert set(record) == {'numerator', 'denominator', 'value'}
        assert all(isinstance(record[key], str) and re.fullmatch('-?(0|[1-9][0-9]*)', record[key])
                   for key in ('numerator', 'denominator'))
        result = Fraction(int(record['numerator']), int(record['denominator']))
        assert str(result.numerator) == record['numerator'] and str(result.denominator) == record['denominator']
        assert type(record['value']) in {int, float} and Fraction(record['value']) == result
        return result

    geometry = config['geometry']
    edges = [exact_geometry(item) for item in geometry['width_edges_m']]
    length = exact_geometry(geometry['common_length_m'])
    assert len(edges) == 4 and length > 0 and all(a < b for a, b in zip(edges, edges[1:]))
    areas = [(b-a)*length for a, b in zip(edges, edges[1:])]
    assert type(config['steps']) is int and config['steps'] == 64
    assert type(config['duration_s']) in {int, float} and config['duration_s'] > 0
    cases = config['scalar_cases']
    assert len(cases) == 3 and len({item['case_id'] for item in cases}) == 3
    powers = {}
    for item in cases:
        assert isinstance(item['case_id'], str) and item['case_id'].strip()
        assert type(item['power_w_m2']) in {int, float} and item['power_w_m2'] >= 0
        assert isinstance(item['power_provenance'], str) and item['power_provenance'].strip()
        powers[item['case_id']] = Fraction(item['power_w_m2'])
    hypotheses = config['hypotheses']
    assert set(hypotheses) == {'uniform', 'nonuniform'}
    assert all(len(ids) == len(areas) and all(case_id in powers for case_id in ids)
               for ids in hypotheses.values())
    assert len(set(hypotheses['uniform'])) == 1 and len(set(hypotheses['nonuniform'])) > 1
    totals = [sum((area*powers[case_id] for area, case_id in zip(areas, ids)), Fraction())
              for ids in hypotheses.values()]
    assert totals[0] == totals[1]
    problem = config['common_scalar_problem']
    reservoir = problem['reservoir']
    assert problem['parameter_status'] == 'manufactured' and problem['patch_area_m2'] == 1.0
    assert problem['parameter_provenance'].strip() and problem['energy_reference'].strip()
    assert type(reservoir['activation_energy_ev']) in {int, float} and reservoir['activation_energy_ev'] > 0
    assert reservoir['kinetic_provenance'].strip() and reservoir['energy_provenance'].strip()
    assert reservoir['reference_coverage_m2'] > 0 and reservoir['max_coverage_m2'] > 0
    assert 0 <= problem['initial_coverage_m2'] <= reservoir['max_coverage_m2']
    assert problem['areal_heat_capacity_j_m2_k'] > 0
    samples = config['steps']+1
    return {'config_path': name, 'config_sha256': sha(REPO/name), 'configuration': config,
        'declared_unique_scalar_histories': len(cases), 'declared_steps_per_scalar_history': config['steps'],
        'declared_unique_scalar_samples': len(cases)*samples,
        'declared_hypotheses': len(hypotheses), 'declared_width_patches_per_hypothesis': len(areas),
        'declared_expanded_patch_samples': len(hypotheses)*len(areas)*samples,
        'declared_aggregate_samples': len(hypotheses)*samples, 'declared_difference_samples': samples,
        'parameter_status': 'manufactured', 'exact_total_prescribed_power_matched_without_normalization': True,
        'physical_parameters_adopted': False, 'power_inferred_from_current_or_material': False,
        'host_or_production_feedback_installed': False,
        'raw_decimal_checks': 'Frozen parser evidence qualifies raw geometry, support and power equality before projection; this function binds saved declarations only.'}


def command_snapshot_prefix(snapshot, live):
    """Accept only an immutable newline-terminated prefix of complete JSONL records."""
    assert snapshot and snapshot.endswith(b'\n') and live.startswith(snapshot)
    assert all(isinstance(loads(line), dict) for line in snapshot.splitlines())
    return {'sha256': hashlib.sha256(snapshot).hexdigest(), 'bytes': len(snapshot),
        'complete_records': len(snapshot.splitlines()),
        'qualification': 'Exact complete-record byte prefix; later verification/completion records may append.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--expected-head', required=True)
    args = parser.parse_args()
    head = clean_head(args.expected_head)
    for name in PUBLIC:
        assert (REPO/name).is_file() and not (REPO/name).is_symlink()
    context = dependency_context()
    contract = input_contract()
    payload = WORK/'delivery-preparation/payload'
    assert not payload.exists() and not OUT.exists() and not OUT.with_suffix('.tar.gz').exists()
    source = payload/'source'
    source.mkdir(parents=True)
    for name in PUBLIC:
        target = source/name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(REPO/name, target)
    (source/'requirements.txt').write_bytes(baseline_bytes('requirements.txt'))
    (source/'README.md').write_text(f'''# Manufactured matched-total-input width comparison patch

Five new public files and a patch are pinned to the approved checkout. Apply the
patch to the complete baseline at `{BASE}` before importing, running or testing
this reference. This source/ review subset is not a standalone package. No
initializer replacement or portable execution is supplied. The requirements
wrapper copies baseline requirements.txt byte-for-byte; retain the complete
checkout setup and initializer.

The new adapter assembles independent stationary width patches from three NEW
scalar thermal/inventory histories using the unchanged qualified forced-feedback
implementation. Unique scalar histories and samples remain distinct from their
reuse across patches and hypotheses. Exact geometry and area weights qualify
matched total prescribed input; the resulting release and channel differences
remain numerical comparison outputs. No lateral transport or physical foil,
water, monolayer, spectrum, FLASH or host validation is supplied.

New adapter-only tests, parser controls, the sole new scalar batch, three fresh
independent scalar references, saved area/aggregate/difference checks and static
reviews remain separately pinned. Existing numerical cases and old suites are
not replayed. Actual failures, corrections and source versions are retained if
they occur. No error certificate or physical uncertainty is inferred.
''')
    save(payload/'source_file_list.json', {'byte_identical_public_files': list(PUBLIC), 'packaging_wrappers': list(WRAPPERS)})
    (payload/'source-files.sha256').write_text(''.join(f'{sha(source/name)}  {name}\n' for name in PUBLIC))
    (payload/'wrapper-files.sha256').write_text(''.join(f'{sha(source/name)}  {name}\n' for name in WRAPPERS))
    save(payload/'dependency_context.json', context)
    save(payload/'preparation.json', {'source_commit': head, 'base_commit': BASE,
        'input_contract': contract, 'dependency_context': context,
        'portable_execution_performed': False, 'physical_truth_validated': False,
        'public_source_sha256': {name: sha(REPO/name) for name in PUBLIC}})
    print(json.dumps({'payload': str(payload), 'source_commit': head, 'public_files': len(PUBLIC),
        'packaging_wrappers': len(WRAPPERS), 'complete_baseline_checkout_required': True}, indent=2))


if __name__ == '__main__':
    main()
