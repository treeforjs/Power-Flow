"""Associate accepted new width results and the completed visual inspection."""
from decimal import Decimal
from fractions import Fraction
from hashlib import sha256
import argparse
import datetime
import json
from pathlib import Path

WORK = Path(__file__).resolve().parent
REPO = Path('/workspace/Power-Flow')
RUN = WORK/'producer/reference-run'
PUBLIC = ('mhdlab/thermal_width_power_reference.py','tests/test_thermal_width_power_reference.py',
    'tools/run_thermal_width_power_reference.py','configs/thermal_width_power_manufactured.json',
    'docs/thermal_width_power_reference.md')

def digest(path):
    return sha256(path.read_bytes()).hexdigest()

def load(path):
    return json.loads(path.read_text())

def record(path):
    return {'path': str(path), 'sha256': digest(path)}

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--oracle-report',type=Path,required=True)
    parser.add_argument('--oracle-review',type=Path,required=True)
    parser.add_argument('--corrected-profile',type=Path,required=True)
    parser.add_argument('--plot-amendment',type=Path,required=True)
    args=parser.parse_args()
    oracle=load(args.oracle_report)
    assert oracle['schema']=='mitl-independent-width-power-oracle-v1'
    assert oracle['status']=='passed' and oracle['all_checks_passed'] is True
    review=load(args.oracle_review)
    assert 'review' in review['schema'] and review['status'] in ('review_complete_no_substantive_issue_identified','accepted')
    assert Path(review['actual_report_path']).resolve()==args.oracle_report.resolve()
    assert review['actual_report_sha256']==digest(args.oracle_report)
    producer=load(RUN/'report.json')
    amendment=load(args.plot_amendment)
    assert amendment['numerical_run_report_sha256']==digest(RUN/'report.json')
    assert amendment['numerical_run_cli_sha256']==producer['code_sha256']['tools/run_thermal_width_power_reference.py']
    assert amendment['final_public_cli_sha256']==digest(REPO/'tools/run_thermal_width_power_reference.py')
    assembly=load(RUN/'width_assembly.json')
    quantities=('released_number','release_rate_s','input_energy_j','binding_energy_j',
        'internal_energy_j','translational_energy_j','total_wall_energy_debit_j','wall_thermal_change_j')
    final={name:{key:data['totals'][-1]['extensive'][key]['value'] for key in quantities}
        for name,data in assembly['hypotheses'].items()}
    difference={key:assembly['comparison']['samples'][-1]['difference_nonuniform_minus_uniform'][key]['value']
        for key in quantities}
    relative={key:float(Fraction(difference[key])/Fraction(final['uniform'][key]))
        for key in quantities if final['uniform'][key]}
    errors={key:str(max(Decimal(value['decimal']) for value in oracle[key].values()))
        for key in ('own_contrast_errors','own_contrast_reference_stability','own_patch_temperature_contrast_errors')}
    plots=[RUN/'scalar_histories.png',RUN/'width_profiles.png',args.corrected_profile]
    result={'schema':'mitl-width-power-root-result-association-v1',
        'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'parameter_status':'manufactured','producer_report':record(RUN/'report.json'),
        'oracle_report':record(args.oracle_report),'oracle_review':record(args.oracle_review),
        'plot_amendment':record(args.plot_amendment),
        'final_hypotheses':final,'final_nonuniform_minus_uniform':difference,
        'final_difference_fraction_of_uniform':relative,'maximum_numerical_error_estimates':errors,
        'unique_scalar_samples':producer['unique_scalar_samples'],
        'expanded_record_counts':producer['expanded_record_counts'],
        'guide':record(REPO/'docs/thermal_width_power_reference.md'),
        'public_source_sha256':{name:digest(REPO/name) for name in PUBLIC},
        'visual_review':{'images':[record(p) for p in plots],
            'completed_by_direct_inspection':True,
            'original_profiles_issue':'Default stairs baseline draws an unsupported closure to zero at outer support, including temperature.',
            'correction':'Plot only: baseline=None; corrected saved-data profile inspected. Numerical run and original figure retained.',
            'scalar_histories':'Time units, temperature units, parent-release fraction, distinct case labels and manufactured scope readable.',
            'corrected_profile':'Final patch temperatures, parent release and cumulative expected translation retain piecewise patch support and distinct hypotheses without endpoint baseline closure.',
            'actual_experimental_plot_or_uncertainty_claim':False},
        'limits':['Manufactured source comparison only; actual water/material/geometry/monolayer and observed spectra are not qualified.',
            'Observed numerical discrepancies and finite reference changes are estimates, not certified bounds or physical/statistical confidence.',
            'No source or reference trajectory was repeated by this result association.']}
    target=WORK/'root-result-association.json'
    assert not target.exists()
    target.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'result':record(target),'final_difference_fraction_of_uniform':relative,
        'maximum_numerical_error_estimates':errors},indent=2))

if __name__=='__main__':
    main()
