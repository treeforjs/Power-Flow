"""Freeze new manufactured width-power evidence without replaying numerical work."""
import datetime
import csv
import hashlib
import io
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tarfile
from xml.etree import ElementTree

from prepare_delivery import WORK, REPO, BASE, OUT, PUBLIC, WRAPPERS, clean_head, dependency_context, input_contract, command_snapshot_prefix, load, save, sha

TEXT_SUFFIXES = {'.py', '.json', '.jsonl', '.log', '.xml', '.md', '.txt', '.patch', '.sha256', '.yaml', '.csv'}
EVIDENCE_DIRS = ('core', 'core-review', 'producer', 'tests', 'independent-verification', 'oracle-review', 'next-upstream-selection', 'delivery-preparation', 'completion-preparation')
REPORT_PATHS = {
    'producer_run': 'producer/reference-run/report.json',
    'producer_completion': 'producer/completion.json',
    'parser_guards': 'producer/parser_guard_checks.json',
    'export_amendment': 'producer/export_amendment.json',
    'plot_correction': 'producer/plot_correction.json',
    'producer_before_run': 'producer/freeze.json',
    'tests_completion': 'tests/completion.json',
    'core_freeze': 'core/source-freeze.json',
    'static_core_review': 'core-review/completion.json',
    'oracle_completion': 'independent-verification/completion.json',
    'oracle_report': 'independent-verification/oracle-initial/report.json',
    'oracle_summary': 'independent-verification/summary.json',
    'oracle_review': 'oracle-review/completion.json',
    'root_result_association': 'root-result-association.json',
    'selection': 'next-upstream-selection/selection.json',
}

PROJECTIONS = (
    (bytes.fromhex('2f6f70742f636f6465782f72756e74696d65732f636f6465782d7072696d6172792d72756e74696d652f646570656e64656e636965732f707974686f6e'), b'[runtime Python directory]'),
    (bytes.fromhex('2f6574632f636f6465782f'), b'[runtime policy directory]/'),
)


def excluded(relative, allowed_figures=()):
    path = Path(relative)
    if 'delivery-preparation' in path.parts and 'payload' in path.parts:
        return True
    if any(part in {'__pycache__', '.pytest_cache', '.venv', 'source-local', 'fulltexts', 'raw-fulltexts',
                    'pytest-temp', 'pytest-tmp', 'test-fixtures', 'fixtures'}
           or part.startswith('.thermal-width-power-reference-') for part in path.parts):
        return True
    if path.suffix == '.pyc':
        return True
    if 'source-acquisition' in path.parts:
        return 'raw' in path.parts or path.suffix not in {'.json', '.jsonl', '.py', '.md', '.log', '.sha256'}
    if path.suffix.lower() in {'.png', '.pdf', '.jpg', '.jpeg', '.tif', '.tiff'}:
        return str(path) not in set(allowed_figures)
    return False


def verify_contracts(records, configured_inputs, *, work_sha=None, public_sha=None, work_bytes=None):
    """Check saved metadata and byte identities without advancing any history."""
    h = work_sha or (lambda name: sha(WORK/name))
    p = public_sha or (lambda name: sha(REPO/name))
    b = work_bytes or (lambda name: (WORK/name).read_bytes())

    def artifacts(mapping, prefix=''):
        assert isinstance(mapping, dict) and mapping
        for name, digest in mapping.items():
            path = Path(name)
            assert not path.is_absolute() and '..' not in path.parts
            assert re.fullmatch('[0-9a-f]{64}', digest) and h(prefix+name) == digest

    def counts(record, expected):
        for key, value in expected.items():
            assert type(record[key]) is int and record[key] == value, key

    def reference(record):
        name = str(Path(record['path']).relative_to(WORK))
        assert h(name) == record['sha256']
        return name

    core_path = 'mhdlab/thermal_width_power_reference.py'
    test_path = 'tests/test_thermal_width_power_reference.py'
    cli_path = 'tools/run_thermal_width_power_reference.py'
    tests = records['tests_completion']
    assert tests['schema'] == 'mitl-width-power-adapter-tests-v1'
    assert tests['status'] == 'passed' and tests['all_checks_passed'] is True
    counts(tests, {'new_adapter_tests_passed': 34, 'test_case_executions': 34,
        'targeted_test_runs': 1, 'failed': 0, 'errors': 0, 'skipped': 0,
        'actual_scalar_evolutions': 0, 'actual_scalar_RHS_evaluations': 0})
    assert tests['warnings_as_errors'] is True and tests['fixtures_are_assembly_only'] is True
    assert tests['mock_fixture_is_production_truth'] is False
    assert tests['initial_preexecution_source_was_run'] is False
    assert tests['all_cases_ran_on_final_adapter_and_test_bytes'] is True
    assert tests['old_suites_producers_or_oracles_repeated'] is False
    assert tests['portable_test_execution_claimed'] is False and tests['host_budget_accepted'] is False
    assert all(p(name) == digest for name, digest in tests['public_source_sha256'].items())
    versions = tests['source_versions']
    assert versions['executed_adapter_sha256'] == p(core_path) and versions['executed_test_sha256'] == p(test_path)
    assert versions['unexecuted_initial_test_sha256'] == h('tests/test_thermal_width_power_reference.preexecution.py')
    assert versions['scientific_adapter_changed'] is False and versions['plan_changed'] is False
    artifacts(tests['artifact_sha256'])
    suites = list(ElementTree.fromstring(b('tests/adapter-initial.xml')).iter('testsuite'))
    assert sum(int(suite.attrib.get('tests', 0)) for suite in suites) == 34
    assert all(int(suite.attrib.get(key, 0)) == 0 for suite in suites for key in ('failures', 'errors', 'skipped'))
    for command in tests['command_records']:
        assert command['exit_code'] == 0 and h(str(Path(command['log']).relative_to(WORK))) == command['log_sha256']
    core = records['core_freeze']
    assert core['schema'] == 'mhdlab-thermal-width-power-core-freeze-v1'
    assert core['source']['sha256'] == p(core_path)
    assert reference(core['snapshot']) == 'core/thermal_width_power_reference.frozen.py'
    assert core['snapshot']['sha256'] == p(core_path)
    for key in ('design', 'selected_proposal', 'preflight_log'):
        reference(core[key])
    assert all(p(name) == item['sha256'] for name, item in core['data_and_rhs_dependencies'].items())
    counts(core, {'author_evolution_calls': 0, 'author_rhs_calls': 0, 'author_test_calls': 0})
    assert core['syntax_and_AST_only'] is True
    static = records['static_core_review']
    assert static['schema'] == 'mitl-width-power-static-core-review-v1'
    assert static['status'] == 'review_complete_no_substantive_issue_identified' and static['findings'] == []
    assert static['reviewed_source_sha256'] == p(core_path)
    assert static['source_changes_requested'] is False
    assert static['scalar_evolution_or_flux_evaluation_executed'] is False
    assert static['scientific_module_imported'] is False
    assert static['producer_or_oracle_executed'] is False
    assert static['physical_parameters_validated'] is False and static['host_budget_accepted'] is False
    artifacts(static['artifact_sha256'], 'core-review/')

    parser, amended = records['parser_guards'], records['export_amendment']
    assert parser['schema'] == 'mhdlab-width-power-parser-checks-v1' and parser['status'] == 'passed'
    counts(parser, {'rejected_configs': 15, 'accepted_plans_without_evolution': 1})
    assert len(parser['checks']) == 16 and parser['config_sha256'] == configured_inputs['config_sha256']
    assert parser['cli_sha256'] == h('producer/source-versions/initial_cli_before_cached_rhs_export.py')
    assert parser['model_or_adapter_imports_or_calls'] is False
    assert parser['raw_geometry_and_power_equality_checked_before_projection'] is True
    assert parser['no_equality_repair_or_normalization'] is True
    assert amended['schema'] == 'mhdlab-width-power-cached-rhs-export-amendment-v1'
    assert amended['status'] == 'passed_static_export_check'
    assert amended['initial_cli_sha256'] == parser['cli_sha256']
    assert amended['initial_parser_report_sha256'] == h(REPORT_PATHS['parser_guards'])
    assert amended['changed_functions'] == ['run']
    assert amended['all_parser_and_validation_function_ASTs_unchanged'] is True
    assert amended['initial_parser_executions'] == 16 and amended['final_parser_rerun'] is False
    assert amended['model_or_adapter_import_or_call'] is False
    return verify_final_records(records, configured_inputs, h, p, b, artifacts, counts, reference)


def verify_final_records(records, configured_inputs, h, p, b, artifacts, counts, reference):
    run = records['producer_run']
    assert run['schema'] == 'mhdlab-thermal-width-power-reference-run-v1'
    assert run['status'] == 'manufactured_reference_only' and run['parameter_status'] == 'manufactured'
    assert run['config_sha256'] == configured_inputs['config_sha256']
    assert run['artifact_path_base'] == 'directory containing report.json'
    counts(run, {'distinct_scalar_evolution_calls': 3, 'distinct_scalar_history_count': 3,
                 'unique_scalar_samples': 195})
    counts(run['expanded_record_counts'], {'expanded_patch_samples': 390, 'aggregate_samples': 130,
                                         'comparison_samples': 65})
    assert run['distinct_scalar_history_count'] == configured_inputs['declared_unique_scalar_histories']
    assert run['unique_scalar_samples'] == configured_inputs['declared_unique_scalar_samples']
    assert run['expanded_record_counts']['expanded_patch_samples'] == configured_inputs['declared_expanded_patch_samples']
    assert run['expanded_record_counts']['aggregate_samples'] == configured_inputs['declared_aggregate_samples']
    assert run['expanded_record_counts']['comparison_samples'] == configured_inputs['declared_difference_samples']
    numeric_cli = records['export_amendment']['final_cli_sha256']
    assert run['code_sha256']['tools/run_thermal_width_power_reference.py'] == numeric_cli
    for name, digest in run['code_sha256'].items():
        if name != 'tools/run_thermal_width_power_reference.py':
            assert p(name) == digest
    prefix = 'producer/reference-run/'
    artifacts(run['artifact_sha256'], prefix)
    assert load_json_bytes(b(prefix+'input_config.json')) == configured_inputs['configuration']
    assert run['reuse_map'] == configured_inputs['configuration']['hypotheses']
    assert set(item['case_id'] for item in run['scalar_histories']) == {
        item['case_id'] for item in configured_inputs['configuration']['scalar_cases']}
    sample_count = 0
    for item in run['scalar_histories']:
        assert item['steps'] == configured_inputs['declared_steps_per_scalar_history']
        assert item['sample_count'] == 65
        assert h(prefix+item['history_file']) == item['history_file_sha256']
        assert h(prefix+item['csv_file']) == item['csv_sha256']
        history = load_json_bytes(b(prefix+item['history_file']))
        assert history['schema'] == 'mhdlab-thermal-forced-feedback-reference-v1'
        assert history['problem'] == configured_inputs['configuration']['common_scalar_problem']
        assert len(history['samples']) == item['sample_count']
        for key in ('physical_parameters_validated', 'host_budget_accepted', 'owner_implementation_verified'):
            assert history[key] is False
        rows = list(csv.DictReader(io.StringIO(b(prefix+item['csv_file']).decode())))
        assert len(rows) == item['sample_count']
        assert all(row['case_id'] == item['case_id'] for row in rows)
        assert all(int(row['sample_index']) == i for i, row in enumerate(rows))
        assert all(float(row['time_s']) == sample['time_s'] for row, sample in zip(rows, history['samples']))
        assert all(row['state_id'] == history['problem']['reservoir']['state_id'] for row in rows)
        assert all('instantaneous__temperature_rate_k_s' in row and 'release_flux_m2_s' in row for row in rows)
        sample_count += len(rows)
    assert sample_count == 195
    for filename, nrows in (('patch_samples.csv', 390), ('aggregate_samples.csv', 130), ('width_comparison.csv', 65)):
        assert len(list(csv.DictReader(io.StringIO(b(prefix+filename).decode())))) == nrows
    assembly = load_json_bytes(b(prefix+run['assembly_file']))
    assert h(prefix+run['assembly_file']) == run['assembly_sha256']
    assert assembly['schema'] == 'mhdlab-thermal-width-power-reference-v1'
    assert assembly['parameter_status'] == 'manufactured'
    assert assembly['host_budget_accepted'] is False and assembly['owner_implementation_verified'] is False
    counts(assembly['cache'], {'distinct_scalar_histories': 3, 'scalar_samples': 195, 'rhs_evaluations': 195,
                              'patch_history_references': 6, 'scalar_evolutions_by_assembly': 0})
    reuse = load_json_bytes(b(prefix+'reuse_map.json'))
    assert reuse['hypotheses'] == run['reuse_map'] and reuse['native_cache_diagnostics'] == assembly['cache']
    assert reuse['no_re_evolution_for_reused_patches'] is True
    q = run['qualifications']
    for key in ('three_new_distinct_scalar_histories_only', 'no_re_evolution_for_reused_patch',
                'exact_matched_total_input_without_rescaling', 'full_time_state_temperature_mixture_retained',
                'instantaneous_flux_from_each_unique_saved_coupled_state'):
        assert q[key] is True
    for key in ('aggregate_or_difference_sign_assumed', 'independent_reference_error_computed_here',
                'old_case_or_old_producer_called', 'physical_water_monolayer_material_or_spectral_inference',
                'actual_MHD_Hall_FLASH_host_gap_or_owner_coupling'):
        assert q[key] is False
    allowed_figures = [prefix+name for name in run['artifact_sha256'] if Path(name).suffix in {'.png', '.pdf'}]
    return verify_remaining_records(records, configured_inputs, h, p, b, artifacts, counts, reference, allowed_figures)


def verify_remaining_records(records, configured_inputs, h, p, b, artifacts, counts, reference, allowed_figures):
    plot = records['plot_correction']
    assert plot['schema'] == 'mhdlab-width-power-plot-support-amendment-v1'
    assert plot['status'] == 'rerendered_from_saved_rows_only'
    assert plot['numerical_run_report'] == REPORT_PATHS['producer_run']
    assert plot['numerical_run_report_sha256'] == h(REPORT_PATHS['producer_run'])
    assert plot['numerical_run_cli_sha256'] == records['export_amendment']['final_cli_sha256']
    assert h(plot['executed_cli_snapshot']) == plot['numerical_run_cli_sha256']
    assert plot['final_public_cli_sha256'] == p('tools/run_thermal_width_power_reference.py')
    assert h(plot['diff_path']) == plot['diff_sha256']
    assert plot['changed_function'] == '_plots'
    assert plot['input_path_base'] == plot['corrected_plot_path_base'] == 'producer directory'
    artifacts(plot['saved_input_sha256'], 'producer/')
    artifacts(plot['original_plot_sha256'], 'producer/reference-run/')
    artifacts(plot['corrected_plot_sha256'], 'producer/')
    assert plot['original_numerical_report_and_artifacts_unchanged'] is True
    assert plot['model_rhs_adapter_or_evolution_imports_or_calls'] is False
    assert plot['saved_scalar_rows_only'] is True and plot['positive_numerical_batch_repeated'] is False
    initial = b(plot['executed_cli_snapshot'])
    old = b'ax.stairs(values, [x*1e3 for x in edges], label=name, linewidth=2)'
    new = b'ax.stairs(values, [x*1e3 for x in edges], label=name, linewidth=2, baseline=None)'
    assert initial.count(old) == 1 and hashlib.sha256(initial.replace(old, new)).hexdigest() == plot['final_public_cli_sha256']
    allowed_figures += ['producer/'+name for name in plot['corrected_plot_sha256']]
    before = records['producer_before_run']
    assert before['schema'] == 'mhdlab-width-power-producer-freeze-v1'
    assert before['status'] == 'frozen_before_first_positive_batch'
    assert before['public_source_sha256']['tools/run_thermal_width_power_reference.py'] == plot['numerical_run_cli_sha256']
    assert all(p(name) == digest for name, digest in before['public_source_sha256'].items()
               if name != 'tools/run_thermal_width_power_reference.py')
    artifacts(before['source_snapshots_sha256'], 'producer/')
    artifacts(before['accepted_prerequisite_sha256'])
    assert before['adapter_tests_use_synthetic_histories_not_scalar_evolution'] is True
    assert before['prior_positive_cli_batches'] == 0 and before['old_case_or_old_producer_calls'] is False
    assert before['parser_evidence']['sha256'] == h(REPORT_PATHS['parser_guards'])
    assert before['parser_evidence']['export_only_amendment_sha256'] == h(REPORT_PATHS['export_amendment'])
    assert before['parser_evidence']['parser_ASTs_unchanged'] is True
    return verify_independent_and_completion(records, configured_inputs, h, p, b, artifacts, counts, reference, allowed_figures)


def verify_independent_and_completion(records, configured_inputs, h, p, b, artifacts, counts, reference, allowed_figures):
    produced, run, plot = records['producer_completion'], records['producer_run'], records['plot_correction']
    assert produced['schema'] == 'mhdlab-width-power-producer-completion-v1'
    assert produced['status'] == 'passed_production_and_saved_export_checks'
    assert produced['report_path'] == REPORT_PATHS['producer_run']
    assert produced['report_sha256'] == h(produced['report_path'])
    assert produced['assembly_sha256'] == h(produced['assembly_path']) == run['assembly_sha256']
    assert produced['config_sha256'] == configured_inputs['config_sha256']
    assert produced['numerical_run_code_sha256'] == run['code_sha256']
    assert produced['final_public_cli_sha256'] == p('tools/run_thermal_width_power_reference.py')
    assert produced['plot_support_amendment']['path'] == REPORT_PATHS['plot_correction']
    assert produced['plot_support_amendment']['sha256'] == h(REPORT_PATHS['plot_correction'])
    assert produced['export_only_preproduction_amendment']['path'] == REPORT_PATHS['export_amendment']
    assert produced['export_only_preproduction_amendment']['sha256'] == h(REPORT_PATHS['export_amendment'])
    counts(produced, {'positive_batch_count': 1, 'distinct_scalar_evolution_calls': 3,
        'distinct_scalar_history_count': 3, 'unique_scalar_samples': 195, 'expanded_patch_samples': 390,
        'aggregate_samples': 130, 'comparison_samples': 65, 'new_unique_adapter_checks': 34})
    assert produced['cache'] == load_json_bytes(b(produced['assembly_path']))['cache']
    assert produced['reuse_map'] == run['reuse_map'] and produced['exact_input_matching'] == run['exact_input_matching']
    assert produced['saved_readback']['all_raw_and_canonical_input_history_hashes_verified'] is True
    assert produced['saved_readback']['all_scalar_cached_RHS_fields_and195logical_times_copied_exactly'] is True
    assert produced['saved_readback']['all390patch130aggregate65comparisonCSV_records_match_nativeJSON'] is True
    assert produced['saved_readback']['all_extensive_exact_values_and_signed_projection_diagnostics_retained'] is True
    assert produced['saved_readback']['no_model_rhs_or_adapter_imports_or_calls'] is True
    assert produced['independent_error_or_sign_qualification_included_here'] is False
    assert produced['old_suites_sources_or_numerical_cases_replayed'] is False
    assert produced['open_substantive_findings'] == []
    assert produced['artifact_path_base'] == 'pass directory containing producer/'
    artifacts(produced['artifact_sha256'])
    artifacts(produced['accepted_prerequisite_sha256'])
    command = produced['batch']
    assert command['exit_code'] == 0 and h(str(Path(command['log']).relative_to(WORK))) == command['log_sha256']
    return verify_independent_records(records, configured_inputs, h, p, b, artifacts, counts, reference, allowed_figures)


def verify_independent_records(records, configured_inputs, h, p, b, artifacts, counts, reference, allowed_figures):
    oracle, complete, summary = records['oracle_report'], records['oracle_completion'], records['oracle_summary']
    assert oracle['schema'] == 'mitl-independent-width-power-oracle-v1'
    assert oracle['status'] == 'passed' and oracle['all_checks_passed'] is True
    expected = {'new_scalar_cases': 3, 'unique_scalar_reference_samples': 195,
        'unique_scalar_flux_references': 195, 'saved_scalar_rows_checked': 195,
        'scalar_CSV_JSON_cells_checked': 3315, 'scalar_RHS_CSV_cells_checked': 1755,
        'scalar_area_once_checks': 2730, 'expanded_patch_samples_checked': 390,
        'aggregate_samples_checked': 130, 'difference_samples_checked': 65,
        'exact_quantity_projection_records_checked': 13910, 'reference_precision_grids': 6,
        'saved_state_flux_evaluations_across_two_precision_grids': 390,
        'post_source_cache_records_verified': 195, 'independent_RHS_field_comparisons': 1560,
        'expanded_patch_CSV_rows_checked': 390, 'aggregate_CSV_rows_checked': 130,
        'comparison_CSV_rows_checked': 65}
    counts(oracle, expected)
    assert oracle['producer_imports_or_calls'] == []
    counts(oracle, {'old_case_or_oracle_runs': 0, 'new_independent_oracle_runs': 1})
    assert oracle['numerical_sign_flags_are_physical_or_statistical_confidence'] is False
    artifacts(oracle['reference_checkpoint_sha256'], 'independent-verification/oracle-initial/')
    assert len(oracle['reference_checkpoint_sha256']) == 6
    for key in ('reference_samples', 'contrast_samples'):
        assert h('independent-verification/oracle-initial/'+oracle[key+'_file']) == oracle[key+'_sha256']
    for path, digest in oracle['input_sha256'].items():
        assert h(str(Path(path).relative_to(WORK))) == digest
    assert set(oracle['own_contrast_scales']) == set(oracle['own_contrast_errors']) == set(oracle['own_contrast_reference_stability'])
    assert len(oracle['own_contrast_scales']) == 12
    assert all(item['float_projection'] > 0 for item in oracle['own_contrast_scales'].values())
    assert all(item['float_projection'] >= 0 for item in oracle['own_contrast_errors'].values())
    assert len(oracle['own_patch_temperature_contrast_errors']) == 3
    assert set(oracle['reference_stability']) == {'uniform_power', 'edge_power', 'middle_power'}
    assert complete['schema'] == 'mitl-independent-width-power-completion-v1'
    assert complete['status'] == 'passed' and complete['all_checks_passed'] is True
    counts(complete, expected)
    counts(complete, {'grouped_quantity_projection_checks': 13910, 'additional_input_projection_checks': 196,
        'total_exact_quantity_projection_checks': 14106, 'scalar_numeric_CSV_cells_checked': 5070,
        'reference_checkpoint_files': 6, 'new_independent_oracle_runs': 1, 'old_case_or_oracle_runs': 0})
    assert complete['producer_imports_or_calls'] == []
    for key in ('independent_RHS_uses_one_flux_per_saved_state', 'all_eight_RHS_fields_checked',
                'exact_area_and_power_identity_verified', 'full_patch_mixtures_preserved',
                'own_resolved_contrast_scales_checked', 'separate_gross_scalar_and_physical_ledger_checks_passed',
                'no_physical_or_statistical_sign_confidence_claimed'):
        assert complete[key] is True
    assert complete['physical_water_material_monolayer_spectra_FLASH_Hall_gap_or_host_verified'] is False
    assert complete['dense_Taylor_coefficients_or_off_knot_queries_retained'] is False
    assert complete['mathematical_dependency_reused_for_NEW_inputs_only'] == h('independent-verification/decimal_forced_reference.py')
    assert complete['report'] == REPORT_PATHS['oracle_report'] and complete['report_sha256'] == h(complete['report'])
    assert complete['summary'] == REPORT_PATHS['oracle_summary'] and complete['summary_sha256'] == h(complete['summary'])
    assert complete['producer_report_sha256'] == h(REPORT_PATHS['producer_run'])
    for name, item in complete['producer_executed_code_association'].items():
        assert item['sha256'] == records['producer_run']['code_sha256'][name]
        assert item['current_repository_sha256'] == p(name)
        assert item['current_repository_bytes_equal_execution'] is (item['sha256'] == p(name))
        assert item['preserved_executed_byte_paths'] and all(h(path) == item['sha256'] for path in item['preserved_executed_byte_paths'])
    assert complete['plot_correction_lineage'] == REPORT_PATHS['plot_correction']
    assert complete['plot_correction_lineage_sha256'] == h(REPORT_PATHS['plot_correction'])
    assert complete['plot_only_final_CLI_change_is_not_a_numerical_execution'] is True
    assert complete['artifact_map_base'] == 'work_directory'
    artifacts(complete['artifact_sha256'])
    for command in complete['command_records']:
        assert command['exit_code'] == 0 and h(str(Path(command['log']).relative_to(WORK))) == command['log_sha256']
    assert summary['schema'] == 'mitl-independent-width-power-summary-v1' and summary['status'] == 'passed'
    counts(summary, expected)
    assert summary['report_sha256'] == h(REPORT_PATHS['oracle_report'])
    assert summary['summary_uses_display_float_projections'] is True
    assert summary['numerical_resolution_is_physical_or_statistical_confidence'] is False
    review = records['oracle_review']
    assert review['schema'] == 'mitl-width-power-static-oracle-review-v1' and review['status'] == 'accepted'
    assert review['actual_report_sha256'] == h(REPORT_PATHS['oracle_report']) == review['owner_report_sha256']
    assert review['reviewed_source_sha256'] == h('independent-verification/verify_width_power.py')
    artifacts(review['reviewed_code_and_input_sha256'], 'independent-verification/')
    artifacts(review['output_artifact_sha256'], 'independent-verification/oracle-initial/')
    artifacts(review['artifact_sha256'], 'oracle-review/')
    assert review['pre_reference_definition_amendment_sha256'] == h('independent-verification/pre_reference_definition_amendment.json')
    assert review['further_changes_requested'] is False
    assert review['completed_report_bound_without_numerical_replay'] is True
    assert review['owner_report_numerics_recomputed_by_reviewer'] is False
    assert review['actual_RHS_own_rate_scales_read'] is True and review['actual_OWN_contrast_scales_and_errors_read'] is True
    assert review['represented_and_unprojected_thermal_residuals_remain_distinct'] is True
    assert len(review['findings']) == 2 and all(item['status'] == 'repaired_before_first_reference' for item in review['findings'])
    for key in ('scalar_evolution_or_flux_evaluation_executed', 'producer_or_oracle_executed',
                'old_case_or_oracle_replayed', 'physical_parameters_validated', 'host_budget_accepted'):
        assert review[key] is False
    verify_root_and_selection(records, h, p, b, artifacts, counts, reference)
    relationships = {
        'adapter_tests': records['tests_completion']['source_versions'],
        'adapter_tests_called_scalar_evolution_or_actual_RHS': False,
        'parser_executed_cli_sha256': records['parser_guards']['cli_sha256'],
        'preproduction_export_only_amendment': records['export_amendment'],
        'numerical_run_code_sha256': records['producer_run']['code_sha256'],
        'plot_only_final_public_cli_amendment': records['plot_correction'],
        'independent_producer_executed_code_association': complete['producer_executed_code_association'],
        'independent_definition_amendment': load_json_bytes(b('independent-verification/pre_reference_definition_amendment.json')),
        'independent_math_dependency_sha256': complete['mathematical_dependency_reused_for_NEW_inputs_only'],
        'old_case_or_suite_results_replayed_as_new_evidence': False,
        'reference_numerical_runs': 1,
    }
    results = {'new_adapter_tests_passed': 34, 'adapter_test_case_executions': 34, 'adapter_targeted_test_runs': 1,
        'actual_scalar_evolutions_in_adapter_tests': 0, 'actual_scalar_RHS_evaluations_in_adapter_tests': 0,
        'parser_rejected_configurations': 15, 'parser_accepted_plans_without_evolution': 1,
        'positive_producer_batches': 1, 'distinct_new_scalar_histories': 3, 'unique_scalar_samples': 195,
        'expanded_patch_samples': 390, 'aggregate_samples': 130, 'comparison_samples': 65,
        'assembly_cached_saved_state_RHS_records': 195, 'assembly_scalar_evolutions': 0,
        'new_independent_oracle_runs': 1, 'unique_scalar_reference_samples': 195,
        'unique_scalar_flux_references': 195, 'reference_precision_grids': 6,
        'saved_state_flux_evaluations_across_two_precision_grids': 390, 'independent_RHS_field_comparisons': 1560,
        'scalar_numeric_CSV_cells_checked': 5070, 'scalar_area_once_checks': 2730,
        'grouped_quantity_projection_checks': 13910, 'additional_input_projection_checks': 196,
        'total_exact_quantity_projection_checks': 14106, 'own_contrast_scales_separately_qualified': True,
        'exact_total_prescribed_input_matched_without_normalization': True,
        'original_numerical_run_preserved_after_plot_only_correction': True,
        'old_cases_or_suites_replayed': False, 'scientific_numerics_reexecuted_during_packaging': False,
        'portable_executions_performed': False, 'physical_truth_validated': False,
        'host_budget_accepted': False, 'owner_implementation_verified': False}
    return {'results': results, 'source_version_relationships': relationships,
            'allowed_figure_paths': sorted(set(allowed_figures))}


def verify_root_and_selection(records, h, p, b, artifacts, counts, reference):
    root = records['root_result_association']
    assert root['schema'] == 'mitl-width-power-root-result-association-v1' and root['parameter_status'] == 'manufactured'
    assert set(root['public_source_sha256']) == set(PUBLIC)
    assert all(p(name) == digest for name, digest in root['public_source_sha256'].items())
    for key, role in (('producer_report', 'producer_run'), ('oracle_report', 'oracle_report'),
                      ('oracle_review', 'oracle_review'), ('plot_amendment', 'plot_correction')):
        assert reference(root[key]) == REPORT_PATHS[role]
    assert root['guide']['sha256'] == p('docs/thermal_width_power_reference.md')
    assert root['unique_scalar_samples'] == 195
    counts(root['expanded_record_counts'], {'expanded_patch_samples': 390, 'aggregate_samples': 130, 'comparison_samples': 65})
    assert root['visual_review']['completed_by_direct_inspection'] is True
    assert root['visual_review']['actual_experimental_plot_or_uncertainty_claim'] is False
    assert len(root['visual_review']['images']) == 3
    for image in root['visual_review']['images']:
        reference(image)
    selection_contract(records['selection'], h, p, b, artifacts, counts, reference)


def selection_contract(selection, h, p, b, artifacts, counts, reference):
    assert selection['schema'] == 'mhdlab-upstream-selected-task-v1'
    assert selection['status'] == 'selected_pending_fresh_bounded_lease'
    assert selection['task_id'] == 'constant-power-coupled-emission-window-interface'
    assert isinstance(selection['selected_task'], str) and selection['selected_task'].strip()
    assert selection['fresh_lease_required'] is True and selection['public_implementation_started'] is False
    assert selection['public_files_changed_by_selection'] == []
    assert selection['numerical_execution_by_selection'] is False
    for key in ('proposal', 'mathematical_notes', 'inventory', 'preserved_conditional_selection', 'predecessor_acceptance'):
        reference(selection[key])


def load_json_bytes(data):
    from prepare_delivery import loads
    return loads(data)


def main():
    payload = WORK/'delivery-preparation/payload'
    preparation = load(payload/'preparation.json')
    head = clean_head(preparation['source_commit'])
    assert preparation['base_commit'] == BASE
    assert not OUT.exists() and not OUT.with_suffix('.tar.gz').exists()
    assert load(payload/'source_file_list.json') == {'byte_identical_public_files': list(PUBLIC), 'packaging_wrappers': list(WRAPPERS)}
    assert len(PUBLIC) == 5 and len(WRAPPERS) == 2
    assert {str(path.relative_to(payload/'source')) for path in (payload/'source').rglob('*') if path.is_file()} == set(PUBLIC)|set(WRAPPERS)
    assert not (payload/'source/mhdlab/__init__.py').exists()
    for name in PUBLIC:
        assert (payload/'source'/name).read_bytes() == (REPO/name).read_bytes()
    context = dependency_context()
    assert context == preparation['dependency_context'] == load(payload/'dependency_context.json')
    configured_inputs = input_contract()
    assert configured_inputs == preparation['input_contract']
    records = {key: load(WORK/name) for key, name in REPORT_PATHS.items()}
    contract = verify_contracts(records, configured_inputs)
    allowed_figures = contract['allowed_figure_paths']
    next_task = records['selection']['selected_task']
    assert isinstance(next_task, str) and next_task.strip()
    shutil.copytree(payload, OUT)
    evidence = OUT/'evidence'
    evidence.mkdir()
    try:
        active_log = Path(os.readlink('/proc/self/fd/1')).resolve()
    except OSError:
        active_log = None
    copied_inputs, omitted, copied_root_files = [], [], []

    def copy(path, relative):
        assert not path.is_symlink()
        digest = sha(path)
        target = evidence/relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, target)
        assert sha(target) == digest
        copied_inputs.append({'source': str(path), 'archive': str(target.relative_to(OUT)), 'sha256': digest})

    for path in WORK.iterdir():
        if path.is_file() and path.suffix in TEXT_SUFFIXES and path.resolve() != active_log:
            copy(path, Path(path.name))
            copied_root_files.append(path.name)
    for folder in EVIDENCE_DIRS:
        for path in (WORK/folder).rglob('*'):
            assert not path.is_symlink()
            if not path.is_file():
                continue
            relative = path.relative_to(WORK)
            if excluded(relative, allowed_figures):
                omitted.append({'path': str(relative), 'sha256': sha(path), 'bytes': path.stat().st_size,
                    'reason': 'Cache, temporary fixture, failed staging data or unselected figure omitted from this new reference evidence.'})
            else:
                copy(path, relative)
    commands_raw = (evidence/'commands.jsonl').read_bytes()
    snapshot = command_snapshot_prefix(commands_raw, (WORK/'commands.jsonl').read_bytes())
    helper_pins = {name: sha(WORK/name) for name in ('prepare_delivery.py', 'freeze_delivery.py', 'verify_delivery.py', 'complete_pass.py')}
    projections = []
    for path in evidence.rglob('*'):
        if not path.is_file() or path.suffix not in TEXT_SUFFIXES:
            continue
        for prefix, replacement in PROJECTIONS:
            data = path.read_bytes()
            if prefix in data:
                assert replacement not in data
                path.write_bytes(data.replace(prefix, replacement))
                projections.append({'path': str(path.relative_to(OUT)), 'original_sha256': hashlib.sha256(data).hexdigest(),
                    'portable_sha256': sha(path), 'replacements': data.count(prefix), 'source_prefix_hex': prefix.hex(),
                    'replacement': replacement.decode(), 'scope': 'Archive-only machine-directory projection; local raw bytes unchanged.'})
    save(OUT/'portable_path_projections.json', projections)
    save(OUT/'excluded_evidence.json', omitted)
    with (OUT/'width-power-reference.patch').open('wb') as stream:
        subprocess.run(['git', 'diff', '--binary', BASE, head], cwd=REPO, stdout=stream, check=True)
    verification = {'schema': 'mitl-width-power-reference-verification-v1',
        'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'source_commit': head, 'base_commit': BASE, 'input_contract': configured_inputs,
        'dependency_context': context, 'package_kind': 'patch_over_exact_complete_baseline',
        'results': contract['results'], 'records': records, 'record_paths': REPORT_PATHS,
        'source_version_relationships': contract['source_version_relationships'],
        'record_sha256': {key: sha(WORK/name) for key, name in REPORT_PATHS.items()},
        'allowed_figure_paths': allowed_figures, 'copied_input_sha256': copied_inputs,
        'public_files_byte_identical': len(PUBLIC), 'packaging_wrappers': len(WRAPPERS),
        'commits': subprocess.check_output(['git', 'log', '--reverse', '--format=%H %s', BASE+'..'+head], cwd=REPO, text=True).splitlines(),
        'source_helper_sha256': helper_pins,
        'command_snapshot': {**snapshot, 'path': 'evidence/commands.jsonl',
            'copied_root_files': sorted(copied_root_files),
            'later_local_completion_repairs_may_exist': True,
            'historical_helper_policy': 'Archive helper bytes are immutable historical snapshots; later local repairs must explicitly bind them and preserve the initial failure.'},
        'next_task': next_task,
        'limits': ['Manufactured independent stationary width patches assembled from new scalar histories under explicit prescribed input.',
            'Exact area and matched input do not imply identical release or energy channels; differences are saved numerical outputs.',
            'The unchanged scalar implementation is intentionally called for three new histories; existing numerical cases and suites are not replayed.',
            'Adapter tests perform no scalar evolution; producer calls, independent references and saved assembly checks are separately recorded.',
            'No lateral conduction, physical water/material calibration, experimental heating, FLASH, gap, CR, spectrum or host transaction is supplied.',
            'Five-file patch requires the exact complete baseline. No standalone package, initializer workaround or portable execution is claimed.']}
    save(OUT/'verification.json', verification)
    save(OUT/'next_task.json', {'task': next_task, 'selection_evidence': 'evidence/'+REPORT_PATHS['selection']})
    (OUT/'systems-mitl-width-power-reference-10192026.md').write_text(f'''# Manufactured matched-total-input width comparison

Five public files are byte-identical to `{head}`. Apply the patch over the
complete checkout at `{BASE}`. README/requirements are wrappers; no initializer
replacement, standalone package or portable execution is claimed.

The unchanged qualified scalar forced-feedback implementation intentionally
produces three NEW histories. The adapter reuses these saved histories across
independent stationary patches and two width-power hypotheses, retaining exact
geometry, area-once totals and matched prescribed input separately from release
and channel differences. Unique scalar samples, expanded patch records and
aggregate comparisons are separate counters. New adapter tests do not evolve a
scalar history. Independent fresh references and saved assembly checks retain
their own evidence. Existing numerical cases and suites are not replayed.

This is a manufactured reference with prescribed power, no lateral conduction,
physical material/water calibration, spectrum, field-derived heating, FLASH or
host implementation. Finite numerical differences are estimates, not physical
uncertainty or a continuum error certificate.

Commands form an immutable complete-record byte prefix; later verification and
completion commands may append. Archived helper hashes are historical snapshots;
any later local repair must preserve its initial failure and bind that archived
hash. Reversible machine-directory projections leave raw local evidence unchanged.
Assembly runs no model, oracle, test suite or portable environment.

Next selected task: {next_task}
''')
    manifest = {str(path.relative_to(OUT)): sha(path) for path in OUT.rglob('*') if path.is_file() and path.name != 'manifest.sha256.json'}
    save(OUT/'manifest.sha256.json', manifest)
    words = [bytes.fromhex(value).decode() for value in ('6f70656e6169', '63686174677074', '636c61756465', '636f646578')]
    prohibited = re.compile(r'\b(?:'+'|'.join(words)+r')\b', re.I)
    allowed_archive_figures = {'evidence/'+name for name in allowed_figures}
    for path in OUT.rglob('*'):
        assert not path.is_symlink()
        if path.is_file():
            assert not excluded(path.relative_to(OUT), allowed_archive_figures)
            if path.suffix in TEXT_SUFFIXES:
                assert not prohibited.search(path.read_text()), str(path)
    clean_head(head)
    assert all(sha(REPO/name) == preparation['public_source_sha256'][name] for name in PUBLIC)
    assert all(sha(Path(item['source'])) == item['sha256'] for item in copied_inputs)
    assert all(sha(WORK/item['path']) == item['sha256'] for item in omitted)
    assert all(sha(WORK/name) == digest for name, digest in helper_pins.items())
    command_snapshot_prefix(commands_raw, (WORK/'commands.jsonl').read_bytes())
    archive = OUT.with_suffix('.tar.gz')
    with tarfile.open(archive, 'w:gz') as tar:
        tar.add(OUT, arcname=OUT.name)
    record = {'folder': str(OUT), 'archive': str(archive), 'sha256': sha(archive), 'bytes': archive.stat().st_size,
        'source_commit': head, 'base_commit': BASE, 'manifest_entries': len(manifest),
        'public_files_byte_identical': len(PUBLIC), 'packaging_wrappers': len(WRAPPERS),
        'manifest_sha256': sha(OUT/'manifest.sha256.json'), 'verification_sha256': sha(OUT/'verification.json')}
    save(WORK/'frozen_delivery.json', record)
    print(json.dumps(record, indent=2))


if __name__ == '__main__':
    main()
