"""Claim the selected coupled emission-window work after the saved checkpoint."""
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

root=Path('/workspace/research_work')
repo=Path('/workspace/Power-Flow')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def atomic(p,data):
    temp=p.with_name(p.name+'.new');assert not temp.exists()
    with temp.open('xb') as stream:stream.write(data);stream.flush();os.fsync(stream.fileno())
    os.replace(temp,p)
assert repo.is_dir()
with (root/'mitl-upstream-status.lock').open('a+') as lock:
    fcntl.flock(lock,fcntl.LOCK_EX)
    path=root/'mitl-upstream-status.json';before=path.read_bytes();status=json.loads(before)
    now=datetime.datetime.now(datetime.timezone.utc);until=status.get('active_editing_lease_until_utc')
    assert not until or datetime.datetime.fromisoformat(until)<=now,'Unexpired editing lease: do not overlap'
    assert not status.get('reserved_paths'),'Unreleased reservations require review'
    head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
    assert head==status['last_complete_commit']=='df8eb7026b3a712bf641cbb4d136c497e8af50ba'
    assert subprocess.check_output(['git','branch','--show-current'],cwd=repo,text=True).strip()=='research/flash-publication-foundation'
    assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip()
    assert status['last_completed_pass_id']=='mitl-upstream-20261019T0710'
    handoff=Path(status['handoff']);assert sha(handoff)==status['handoff_sha256']
    doc=Path(status['handoff_document']);print(doc.read_text())
    selected=status['next_work'][0];assert selected['priority']==1
    assert sha(selected['selection'])==selected['selection_sha256']
    selection=json.loads(Path(selected['selection']).read_text())
    assert selection['selected_task']==selected['task'] and selection['status']=='selected_pending_fresh_bounded_lease'
    proposal=Path(__file__).parent/'next-upstream-selection/coupled_emission_window_proposal.json'
    assert sha(proposal)==selection['proposal']['sha256']
    stamp=now.strftime('%Y%m%dT%H%M');work=root/('mitl-upstream-'+stamp)
    assert not work.exists();work.mkdir()
    public=['mhdlab/coupled_emission_windows.py','tests/test_coupled_emission_windows.py',
      'tools/export_coupled_emission_windows.py','configs/coupled_emission_windows_manufactured.json',
      'docs/coupled_emission_windows.md']
    assert all(not (repo/name).exists() for name in public)
    scope=public+[str(work),'/workspace/handoffs/mitl-coupled-windows-'+stamp+'*']
    lease={'utc':now.isoformat(),'event':'lease_claimed','pass_id':work.name,'baseline_commit':head,
      'status_before_sha256':hashlib.sha256(before).hexdigest(),'prior_handoff':str(handoff),
      'prior_handoff_sha256':status['handoff_sha256'],'prior_handoff_document':str(doc),
      'prior_handoff_document_sha256':sha(doc),'task':selected['task'],
      'selection':selected['selection'],'selection_sha256':selected['selection_sha256'],
      'proposal':str(proposal),'proposal_sha256':sha(proposal),'reserved_paths':scope,
      'lease_until_utc':(now+datetime.timedelta(hours=2)).isoformat(),
      'scope_limits':'New constant-power saved-data emission-window interface only, nine distinct source/window pairs and retained temperature mixtures. No source/RHS/assembly re-evaluation, unchanged full-state grid replay, physical water/material/ML/spectra/FLASH/Hall/Quark/owner/gap changes.'}
    (work/'lease.json').write_text(json.dumps(lease,indent=2)+'\n')
    (work/'status-before-lease.json').write_bytes(before)
    shutil.copyfile(Path(__file__).parent/'record_command.py',work/'record_command.py')
    shutil.copyfile(proposal,work/'selected-proposal.json')
    shutil.copyfile(Path(__file__),work/'claim_lease.py')
    status.update(active_lease_owner=work.name,active_editing_lease_until_utc=lease['lease_until_utc'],
      reserved_paths=scope,active_completed_subtasks=[],active_phase=selected['task'],last_update_utc=now.isoformat())
    atomic(path,(json.dumps(status,indent=2,allow_nan=False)+'\n').encode())
    with (root/'mitl-upstream-journal.jsonl').open('a') as stream:stream.write(json.dumps(lease)+'\n')
    print(json.dumps(lease,indent=2))
