# Manufactured matched-total-input width comparison patch

Five new public files and a patch are pinned to the approved checkout. Apply the
patch to the complete baseline at `3bd20e44ba617cca44cbac2df993e1face2ec221` before importing, running or testing
this reference. This source/ review subset is not a standalone package. No
initializer replacement or portable execution is supplied. The requirements
wrapper copies baseline requirements.txt byte-for-byte; retain the complete
checkout setup and initializer.

The new adapter assembles independent stationary width patches from three NEW
scalar thermal/inventory histories using the unchanged qualified forced-feedback
implementation. Unique scalar histories and samples remain distinct from their
reuse across patches and hypotheses. Exact geometry and area weights qualify
matched total prescribed input; the resulting release and channel differences
remain numerical comparison outputs. No lateral transport or physical foil,
water, monolayer, spectrum, FLASH or host validation is supplied.

New adapter-only tests, parser controls, the sole new scalar batch, three fresh
independent scalar references, saved area/aggregate/difference checks and static
reviews remain separately pinned. Existing numerical cases and old suites are
not replayed. Actual failures, corrections and source versions are retained if
they occur. No error certificate or physical uncertainty is inferred.
