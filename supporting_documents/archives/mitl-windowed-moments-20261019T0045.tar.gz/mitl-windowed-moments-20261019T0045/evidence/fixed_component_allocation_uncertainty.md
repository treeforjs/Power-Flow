# Fixed component allocation and packet uncertainty

Condition on the realized packet counts `n_c >= 1` in each positive source component. Let `N_c` be its qualified physical parent count, `alpha_c = N_c / sum(N_c)`, and the common component packet weight be `N_c/n_c`. Packet launch variates other than component refinement must be independent between packets and independent of the draws that selected those counts. The formulas below describe sampling uncertainty conditional on that allocation. They do not describe numerical source errors, quadrature errors, physical parameter uncertainty, or experimental noise.

For a vector observable `Y`, component mean `mu_c`, and component population covariance `Sigma_c`, the source mean and covariance of its packet estimate are

`mu = sum_c alpha_c mu_c`

`mu_hat = sum_c alpha_c mean_i(Y_ci)`

`Cov(mu_hat | n) = sum_c alpha_c^2 Sigma_c / n_c`.

The source population covariance additionally contains the between-component spread, `sum alpha_c (mu_c-mu)(mu_c-mu)^T`. That spread is not an additional conditional sampling-variance term: the fixed allocation represents every component. Conditioning on random refinement counts is legitimate when the other variate columns remain independent; the unconditional mean is still `mu`, and its variance averages the conditional expression over the count distribution.

For `n_c >= 2`, the usual within-component sample covariance `S_c`, with denominator `n_c-1`, is unbiased. Thus `sum alpha_c^2 S_c/n_c` is an unbiased estimate of the conditional mean-estimator covariance. A component with one packet cannot supply an empirical within-component covariance. It requires an independently specified component population covariance or an explicit unavailable-estimate result. Assigning zero to its empirical covariance is unsupported.

## Source covariance and finite sample correction

For scalar observables `A,B`, the direct weighted population-covariance estimate is

`C_plugin = sum_c alpha_c mean_i(A_ci B_ci) - mu_hat_A mu_hat_B`.

Its exact conditional expectation is

`E[C_plugin | n] = C - D`, where `D = sum_c alpha_c^2 sigma_AB,c / n_c`.

If the component covariances are supplied independently, `C_plugin + D` is unbiased. When all `n_c >= 2`, the empirical unbiased version is

`C_unbiased = C_plugin + sum_c alpha_c^2 S_AB,c/n_c`.

A single global weighted Bessel denominator generally fails for distinct component distributions: the bias depends on within-component covariance, whereas the source covariance also contains the between-component mixture. Such a denominator is justified only under its own common-distribution assumptions.

The correction changes the estimator. Reports must retain the direct estimate and identify whether a correction uses deterministic component moments or empirical within-component covariances. Neither correction forces a realized packet estimate to equal the deterministic source value.

## Variance of the covariance estimator

Second moments alone do not determine uncertainty in a covariance estimate. Conditional third and fourth moments are needed, or the report must clearly label a chosen approximation or resampling model. The following exact formulas are useful when those moments exist and are supplied.

Write `a=A-mu_A,c`, `b=B-mu_B,c`, `d_A,c=mu_A,c-mu_A`, and `d_B,c=mu_B,c-mu_B`. Let `sigma_AA,c=E[a^2]`, `sigma_BB,c=E[b^2]`, `sigma_AB,c=E[ab]`, and

`V_c(beta) = Var_c[beta*(ab-sigma_AB,c) + d_B,c*a + d_A,c*b]`.

This quantity requires `E[a^2 b^2]`, `E[a^2 b]`, and `E[a b^2]`. For the empirically corrected estimator, with every `n_c >= 2`,

`Var(C_unbiased | n) = sum_c alpha_c^2 V_c(1)/n_c`

`+ sum_c alpha_c^4 (sigma_AA,c sigma_BB,c + sigma_AB,c^2) / [n_c(n_c-1)]`

`+ sum_{c<d} alpha_c^2 alpha_d^2 [sigma_AA,c sigma_BB,d + sigma_BB,c sigma_AA,d + 2 sigma_AB,c sigma_AB,d]/(n_c n_d)`.

For the estimator corrected with independently known `D`, replace `V_c(1)` by `V_c(1-alpha_c/n_c)` and the within-component second line by

`sum_c alpha_c^4 (n_c-1) (sigma_AA,c sigma_BB,c + sigma_AB,c^2)/n_c^3`.

The cross-component line stays the same. This second expression permits `n_c=1`, because it uses independently known component covariances rather than inventing empirical ones. The first line by itself is only the leading delta-method approximation for the empirical covariance estimator. The remaining terms are finite sample contributions and can matter for sparse components.

These formulas follow by separating independent, centered single-packet terms from centered two-packet products. Cross terms vanish by conditional independence. A work-only finite discrete enumeration checks the exact expressions against the actual finite sample estimators without a Monte Carlo approximation.

For the particular cross observables considered here, conditional independence gives `sigma_AB,c=0`, `E[a^2 b]=E[a b^2]=0`, and `E[a^2 b^2]=sigma_AA,c sigma_BB,c`. Then `D=0`, so the direct covariance estimate is already unbiased. Use the known-correction variance formula above with `V_c(beta)=beta^2 sigma_AA,c sigma_BB,c + d_B,c^2 sigma_AA,c + d_A,c^2 sigma_BB,c`. This needs only component second moments and retains the finite sample terms, including for `n_c=1`. An empirical correction is unnecessary when the conditional independence is part of the specified source model. If `B` is component expected kinetic energy rather than a sampled kinetic energy, its within-component variance is zero; the covariance estimator becomes linear in the component mean estimates of `A`.

## Thermal and time conventions

At frozen wall temperature, the outward flux Maxwellian gives kinetic energy `K` with Gamma shape 2 and scale `theta=kB*T`: `E[K]=2*theta`, `Var(K)=2*theta^2`, and `E[K^r]=(r+1)!*theta^r`. Source kinetic-energy variance is therefore `sum alpha_c*2*theta_c^2 + Var_c(2*theta_c)`. The variance of component expected kinetic energy alone contains only the second term.

Velocity draws are independent of conditional emission time and uniform patch position within each frozen component. Thus any time–kinetic-energy covariance in this source model comes from the component mixture, with component mean kinetic energy `2*kB*T_c`. The activation barrier is not emitted kinetic energy. Supplied internal-state energy and removal cost retain their separate declared references.

Represent time as original interval origin, local window start, and conditional local delay. Global means and covariances must use a retained common reference or exact offset arithmetic; forming absolute float timestamps first can erase the variation being estimated. A source-emission restriction is not a photon observation gate. No transport, radiation, or experimental count model is implied by these formulas.
