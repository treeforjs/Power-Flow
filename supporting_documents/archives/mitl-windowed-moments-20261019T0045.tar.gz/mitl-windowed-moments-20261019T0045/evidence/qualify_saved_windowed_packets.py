"""Qualify fixed-allocation sampling of one preserved manufactured packet set."""
import csv
from fractions import Fraction as Q
import hashlib
import json
import math
from pathlib import Path

import numpy as np

work = Path(__file__).resolve().parent
example = work / 'windowed-moment-example'
inspection = json.loads((example / 'report.json').read_text())
reference = json.loads((example / 'moments_order_0032.json').read_text())
coarse = json.loads((example / 'moments_order_0016.json').read_text())
packet_report = json.loads((example / 'packet_export_report.json').read_text())
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert inspection['parameter_status'] == packet_report['parameter_status'] == 'manufactured'
assert reference['status'] == 'manufactured' and reference['host_budget_accepted'] is False
for name, digest in inspection['output_sha256'].items():
    assert sha(example / name) == digest, name
for name, digest in packet_report['output_sha256'].items():
    assert sha(example / ('packet_export_' + name)) == digest, name
with np.load(example / 'packet_export_boundary_packets.npz', allow_pickle=False) as archive:
    packets = {name: archive[name].copy() for name in archive.files}
assert json.loads(str(packets['metadata_json'])) == packet_report['packets']
components = reference['components']
assert len(components) == 48 and len(packets['particle_weight']) == 512
assert len(packet_report['conditioned_source']['components']) == 48
anchor = reference['mean_time_anchor']
time_base = Q(anchor['interval_origin_s']) + Q(anchor['window_start_offset_s'])
face_bounds = reference['source']['x_edges_m']
face_center = (Q(face_bounds[0]) + Q(face_bounds[-1])) / 2
KB = Q(1.380649e-23)
zero = Q(0)
names = ('time_offset_s', 'x_m', 'z_m', 'width_square_m2', 'kinetic_energy_j', 'component_expected_energy_j')
units = ('s', 'm', 'm', 'm^2', 'J', 'J')
reference_names = {
    'time_offset_s': ('mean_time_offset_s', 'variance_time_s2'),
    'x_m': ('mean_x_m', 'variance_x_m2'), 'z_m': ('mean_z_m', 'variance_z_m2'),
    'width_square_m2': ('mean_width_centered_square_m2', 'variance_width_centered_square_m4'),
    'kinetic_energy_j': ('mean_expected_translational_energy_j', 'variance_kinetic_energy_j2'),
    'component_expected_energy_j': ('mean_expected_translational_energy_j', 'variance_expected_translational_energy_j2'),
}
rows = []
observations = {name: [None] * len(packets['particle_weight']) for name in names}
for index, component in enumerate(components):
    assert component['component_index'] == index
    selected = np.flatnonzero(packets['component_index'] == index)
    count = len(selected)
    assert count >= 1 and count == int(packets['packet_counts'][index])
    weights = [Q(float(packets['particle_weight'][int(i)])) for i in selected]
    assert len(set(weights)) == 1
    actual_count = sum(weights, zero)
    ideal_count = Q(component['released_number'])
    assert float(actual_count - ideal_count) == packets['component_particle_balance_residual'][index]
    timing = component['timing']
    x0, x1 = map(Q, component['x_bounds_m'])
    z0, z1 = map(Q, component['z_bounds_m'])
    mean_x, mean_z = (x0+x1)/2, (z0+z1)/2
    width_x, width_z = x1-x0, z1-z0
    displacement = mean_x-face_center
    theta = KB*Q(component['temperature_k'])
    means = {
        'time_offset_s': Q(component['interval_origin_s']) + Q(component['window_start_offset_s']) + Q(timing['mean_local_delay_s']) - time_base,
        'x_m': mean_x, 'z_m': mean_z, 'width_square_m2': displacement**2 + width_x**2/12,
        'kinetic_energy_j': 2*theta, 'component_expected_energy_j': 2*theta,
    }
    variances = {
        'time_offset_s': Q(timing['variance_local_delay_s2']), 'x_m': width_x**2/12,
        'z_m': width_z**2/12, 'width_square_m2': displacement**2*width_x**2/3 + width_x**4/180,
        'kinetic_energy_j': 2*theta**2, 'component_expected_energy_j': zero,
    }
    for packet in selected:
        i = int(packet)
        for key, array_name in (('interval_index', 'interval_index'), ('reservoir_index', 'reservoir_index'),
                                ('current_index', 'source_current_index'), ('width_index', 'source_width_index'),
                                ('selection_index', 'selection_index')):
            assert int(packets[array_name][i]) == component[key]
        observations['time_offset_s'][i] = Q(float(packets['interval_origin_s'][i])) + Q(float(packets['window_start_offset_s'][i])) + Q(float(packets['local_time_delay_s'][i])) - time_base
        # Retain local offsets rather than first rounding a large position sum.
        observations['x_m'][i] = x0 + Q(float(packets['resolved_width_offset_m'][i]))
        observations['z_m'][i] = z0 + Q(float(packets['source_current_offset_m'][i]))
        observations['width_square_m2'][i] = (observations['x_m'][i]-face_center)**2
        observations['kinetic_energy_j'][i] = Q(float(packets['mass_kg'][i])) * sum((Q(float(v))**2 for v in packets['velocity_m_s'][i]), zero)/2
        observations['component_expected_energy_j'][i] = 2*theta
    rows.append({'index': index, 'n': count, 'actual_count': actual_count, 'ideal_count': ideal_count,
                 'means': means, 'variances': variances, 'packet_ids': list(map(int, selected))})
actual_total = sum((row['actual_count'] for row in rows), zero)
ideal_total = sum((row['ideal_count'] for row in rows), zero)
for row in rows:
    row['alpha'] = row['actual_count']/actual_total
    row['ideal_alpha'] = row['ideal_count']/ideal_total
packet_weights = [Q(float(value))/actual_total for value in packets['particle_weight']]
def average(values):
    return sum((weight*value for weight, value in zip(packet_weights, values)), zero)
def mixture(name, *, ideal=False):
    key = 'ideal_alpha' if ideal else 'alpha'
    mean = sum((row[key]*row['means'][name] for row in rows), zero)
    variance = sum((row[key]*(row['variances'][name] + (row['means'][name]-mean)**2) for row in rows), zero)
    return mean, variance
def mean_estimator_variance(name):
    return sum((row['alpha']**2 * row['variances'][name]/row['n'] for row in rows), zero)
means, mean_rows = {}, []
for name, unit in zip(names, units):
    target, variance = mixture(name)
    ideal_target, ideal_variance = mixture(name, ideal=True)
    mean_key, variance_key = reference_names[name]
    assert float(ideal_target) == reference['resolved'][mean_key]
    assert float(ideal_variance) == reference['resolved'][variance_key]
    observed = average(observations[name])
    plugin = average([(value-observed)**2 for value in observations[name]])
    variance_mean = mean_estimator_variance(name)
    standard_error = math.sqrt(float(variance_mean))
    difference = observed-target
    coarse_change = reference['resolved'][mean_key]-coarse['resolved'][mean_key]
    means[name] = {'target': target, 'variance': variance, 'sample': observed}
    mean_rows.append({
        'observable': name, 'units': unit, 'ideal_source_mean': float(ideal_target),
        'actual_weight_target': float(target), 'number_rounding_target_shift': float(target-ideal_target),
        'sample_mean': float(observed), 'signed_mean_difference': float(difference),
        'fixed_allocation_standard_error': standard_error,
        'standardized_mean_difference': float(difference)/standard_error if standard_error else None,
        'mean_deterministic_given_allocation': variance_mean == 0,
        'order16_to32_mean_change': coarse_change,
        'quadrature_change_over_sampling_se': abs(coarse_change)/standard_error if standard_error else None,
        'target_population_variance': float(variance), 'direct_population_variance_estimate': float(plugin),
        'known_within_component_variance_correction': float(variance_mean),
        'model_corrected_variance_estimate': float(plugin+variance_mean),
    })

# These pairs have independent fluctuations WITHIN each source component.
# The exact finite-n formula includes between-component mean differences,
# single-packet terms, within-component two-packet terms and cross components.
pairs = (('time_offset_s','x_m'), ('time_offset_s','z_m'), ('time_offset_s','width_square_m2'),
         ('time_offset_s','kinetic_energy_j'), ('time_offset_s','component_expected_energy_j'),
         ('kinetic_energy_j','width_square_m2'))
covariance_rows = []
for left, right in pairs:
    mean_left, mean_right = means[left]['target'], means[right]['target']
    target = sum((row['alpha']*(row['means'][left]-mean_left)*(row['means'][right]-mean_right) for row in rows), zero)
    observed = average([(a-means[left]['sample'])*(b-means[right]['sample'])
                        for a, b in zip(observations[left], observations[right])])
    variance = zero
    for row in rows:
        alpha, n = row['alpha'], row['n']
        aa, bb = row['variances'][left], row['variances'][right]
        da, db = row['means'][left]-mean_left, row['means'][right]-mean_right
        beta = 1-alpha/n
        variance += alpha**2/n * (beta**2*aa*bb + db**2*aa + da**2*bb)
        variance += alpha**4 * (n-1)/n**3 * aa*bb
    for index, row in enumerate(rows):
        for other in rows[index+1:]:
            variance += row['alpha']**2 * other['alpha']**2/(row['n']*other['n']) * (
                row['variances'][left]*other['variances'][right]
                + row['variances'][right]*other['variances'][left])
    assert variance >= 0
    standard_error = math.sqrt(float(variance))
    covariance_rows.append({'left': left, 'right': right, 'target_covariance': float(target),
                            'direct_covariance_estimate': float(observed), 'known_bias_correction': 0.,
                            'signed_difference': float(observed-target), 'exact_finite_n_standard_error': standard_error,
                            'standardized_difference': float(observed-target)/standard_error if standard_error else None,
                            'within_component_independence': True})

output = work / 'windowed-packet-qualification'
output.mkdir(exist_ok=False)
for filename, data in (('means.csv', mean_rows), ('cross_covariances.csv', covariance_rows)):
    with (output / filename).open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(data[0]), lineterminator='\n')
        writer.writeheader()
        writer.writerows(data)
result = {
    'schema': 'mitl-windowed-packet-fixed-allocation-qualification-v1', 'status': 'passed',
    'script_sha256': sha(__file__), 'inspection_report_sha256': sha(example/'report.json'),
    'moment_reference_sha256': sha(example/'moments_order_0032.json'),
    'packet_file_sha256': sha(example/'packet_export_boundary_packets.npz'),
    'parameter_status': 'manufactured', 'components': len(rows), 'packets': len(packet_weights),
    'singleton_components': sum(row['n'] == 1 for row in rows), 'mean_observables': len(mean_rows),
    'independent_cross_covariances': len(covariance_rows),
    'max_absolute_standardized_mean_difference': max(abs(row['standardized_mean_difference']) for row in mean_rows if row['standardized_mean_difference'] is not None),
    'max_absolute_standardized_covariance_difference': max(abs(row['standardized_difference']) for row in covariance_rows if row['standardized_difference'] is not None),
    'normalized_by_actual_represented_packet_weights': True,
    'ideal_released_number': float(ideal_total), 'actual_packet_number': float(actual_total),
    'signed_packet_number_residual': float(actual_total-ideal_total),
    'sampler_or_source_history_rerun': False, 'host_budget_accepted': False,
    'output_sha256': {p.name: sha(p) for p in output.iterdir()},
    'limits': [
        'One preserved manufactured packet realization and newly computed finite-order source moments; no source evolution, scalar law or sampler is called by this readback.',
        'Sampling covariances condition on actual component packet counts and independent nonallocation variates; between-component population spread is not extra random allocation variance.',
        'Actual represented component weight sums define comparison targets; ideal source targets and their signed rounding shifts remain separate.',
        'Within-component Gamma(shape2) kinetic-energy scatter is included. Supplied activation/internal/removal energies are not added to translation.',
        'Known source component variances supply model-based finite-sample corrections, including singleton components; no empirical variance is invented for a singleton.',
        'Cross-covariance standard errors use exact finite-n conditional-independence formulas. Standardized differences are descriptive; they do not define a statistical pass/fail threshold, experimental uncertainty or physical validation.',
        'Order16-to32 changes are finite quadrature changes, not certified bounds. Source-law numerical qualification, sampling uncertainty and physical/calibration uncertainty are separate.',
    ],
}
(output / 'report.json').write_text(json.dumps(result, indent=2, allow_nan=False)+'\n')
print(json.dumps(result, indent=2, allow_nan=False))
