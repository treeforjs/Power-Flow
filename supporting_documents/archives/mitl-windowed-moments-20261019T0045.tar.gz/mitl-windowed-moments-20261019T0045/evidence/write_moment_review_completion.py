"""Pin the independent moment review; no numerical models are executed."""
import datetime
import hashlib
import json
from pathlib import Path

work=Path(__file__).resolve().parent
repo=Path('/workspace/Power-Flow')
expected={
    'mhdlab/window_time_moments.py':'08f36b2de7a482643730718a33d9309702e534eb2feb10f5104a14061452181a',
    'mhdlab/windowed_joint_source_moments.py':'8fffb8f2adffbcc24dd286f4cb0b6018d3c7d6a90a90a15775b6098747a1cb1f',
}
def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
for path,sha in expected.items():
    if digest(repo/path)!=sha:
        raise SystemExit(f'Frozen code differs from owner notice: {path}')
files=(
    'fixed_component_allocation_uncertainty.md','moment_review_notes.md',
    'fixed_allocation_exact_check.py','fixed_allocation_exact_check.json','fixed_allocation_exact_check.log',
    'rare_component_joint_probe.py','rare_component_joint_probe.json','rare_component_joint_probe.log',
)
commands=[json.loads(line) for line in (work/'commands.jsonl').read_text().splitlines()]
own=[record for record in commands if Path(record['log']).name in {'fixed_allocation_exact_check.log','rare_component_joint_probe.log'}]
if len(own)!=2 or any(record['exit_code']!=0 or digest(record['log'])!=record['log_sha256'] for record in own):
    raise SystemExit('New focused command evidence mismatch')
report={
    'schema':'mhdlab-window-time-joint-moment-independent-review-v1',
    'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'reviewed_source_sha256':expected,
    'artifact_sha256':{name:digest(work/name) for name in files},
    'focused_commands':own,
    'new_focused_evidence':{
        'fixed_allocation_exact_rational_cases':3,
        'fixed_allocation_exact_enumerated_outcomes':120,
        'fixed_allocation_formulas_verified':[
            'Conditional weighted mean covariance',
            'Direct source-covariance finite sample bias',
            'Known conditional-covariance correction and exact estimator variance including n_c=1',
            'Empirical within-component correction and exact estimator variance when n_c>=2',
            'Failure of a single global weighted Bessel correction for distinct strata',
        ],
        'rare_component_aggregate_helper_checks_passed':6,
        'rare_helper_executed_module_sha256':'b0a9e4850608ef003b20c99b0e43c9b8e909e29025ea4985edcfb687e2ecea15',
        'rare_helper_final_revision_qualification':'Final changes add optional fourth-energy log diagnostics and range documentation; mixture helper arithmetic is unchanged and read-only reviewed. The helper was not rerun solely to refresh a pin.',
    },
    'closed_substantive_findings':[],
    'open_substantive_findings':[],
    'scientific_review_conclusions':[
        'Local log-quantile quadrature uses centered positive-weight variance, retains positive log moments and underflow flags, and separates quadrature changes from scalar query qualification.',
        'n-versus-2n changes are finite numerical estimates, not certified errors or physical uncertainties.',
        'Joint moments use qualified extensive source counts and exact rational normalization/centering; no rare-probability cutoff discards components.',
        'Required primitive local timing projections reject positive underflow before false-zero variance can enter the mixture.',
        'Original interval origin, local window start and conditional delay remain separate; global mean timing loss is explicitly flagged.',
        'Exact rectangle moments and matched-width mixture preserve all non-width conditional information.',
        'Full kinetic-energy population variance includes conditional2(kB*T)^2 as well as variation of2kB*T between components.',
        'Fixed-allocation uncertainty depends on within-component covariance; between-component population spread is not an extra conditional mean sampling variance term.',
        'For model-defined conditional independence of time versus position/fullKE, direct cross-covariance bias is zero; finite-n covariance sampling variance still includes the documented pair terms.',
    ],
    'representation_clarifications':[
        'Aggregate-only and per-component output requests have different explicit representation domains.',
        'The extreme helper fixture has unsupported standalone component energy variance/raw2; it verifies aggregate helper algebra only, not full public component admission.',
        'Optional fourth thermal-energy moments retain log/overflow/underflow diagnostics without restricting required moments.',
        'Sampling uncertainty, finite quadrature changes, source numerical qualification, physical parameter error and experimental measurement error remain distinct.',
    ],
    'old_suites_or_source_evolution_repeated':False,
    'old_oracles_repeated':False,
    'sampler_or_canonical_history_called_by_reviewer':False,
    'public_files_edited':False,
    'host_budget_accepted':False,
    'limits':[
        'Read-only scientific/numerical review plus two new bounded work-only probes; not an end-to-end source/export test.',
        'The owners independently ran their new implementation suites; reviewer did not rerun them.',
        'No source evolution, old manufactured source replay, packet generation, transport, chemistry, radiation, FLASH/Quark job, or physical spectrum was performed.',
        'Every numerical range fixture is manufactured and makes no experimental/material claim.',
        'This completion applies to exact reviewed code hashes; later changes require a scoped update.',
    ],
}
path=work/'moment_review_completion.json'
path.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps({'completion':str(path),'sha256':digest(path),
                  'reviewed_source_sha256':expected,'open_substantive_findings':[]},indent=2))
