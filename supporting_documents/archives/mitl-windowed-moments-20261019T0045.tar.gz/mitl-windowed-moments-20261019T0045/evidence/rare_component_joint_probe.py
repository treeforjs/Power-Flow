"""New mixture helper probe; no canonical history or sampler is executed."""
from fractions import Fraction as F
import hashlib
import json
import math
from pathlib import Path
import sys
from types import SimpleNamespace

ROOT=Path('/workspace/Power-Flow')
sys.path.insert(0,str(ROOT))
from mhdlab.constants import KB
from mhdlab import windowed_joint_source_moments as joint

minimum=float.fromhex('0x0.0000000000001p-1022')
numbers=(F(2),F(minimum))
total=sum(numbers,F(0))
origin=1e12
start=1e-5
localmeans=(F(.1),F(.2))
temperatures=(300.,1e308)
kbt=tuple(F(KB)*F(T) for T in temperatures)
energies=tuple(2*value for value in kbt)
records=[]
for c in range(2):
    component=SimpleNamespace(interval_origin_s=origin,
                              source_window=SimpleNamespace(start_s=start),
                              x_bounds_m=(0.,1.),z_bounds_m=(0.,1.))
    records.append({'index':c,'component':component,'number':numbers[c],
                    'time':F(origin)+F(start)+localmeans[c],
                    'time_variance':F(.01 if c==0 else .02),
                    'energy':energies[c],'energy_variance':2*kbt[c]**2})
resolved,anchor=joint._summarize(records,(0.,1.),1e-7,matched=False)
uniform,_=joint._summarize(records,(0.,1.),1e-7,matched=True)
pairweight=numbers[0]*numbers[1]/total**2
expected_covariance=pairweight*(localmeans[1]-localmeans[0])*(energies[1]-energies[0])
expected_between_variance=pairweight*(energies[1]-energies[0])**2
expected_within_variance=sum((numbers[c]*2*kbt[c]**2 for c in range(2)),F(0))/total
expected_total_variance=expected_between_variance+expected_within_variance
if float(numbers[1]/total)!=0:
    raise AssertionError('Fixture no longer has an underflowed normalized rare probability')
for name,expected in (
    ('cov_time_expected_translational_energy_s_j',expected_covariance),
    ('variance_expected_translational_energy_j2',expected_between_variance),
    ('mean_conditional_kinetic_energy_variance_j2',expected_within_variance),
    ('variance_kinetic_energy_j2',expected_total_variance),
):
    if not math.isclose(resolved[name],float(expected),rel_tol=1e-14):
        raise AssertionError((name,resolved[name],float(expected)))
    if resolved[name]!=uniform[name]:
        raise AssertionError('Matched width changed a time/energy moment')
if resolved['cov_time_expected_translational_energy_s_j']<=0:
    raise AssertionError('Rare component covariance was lost')
if anchor['global_mean_time_precision_qualified']:
    raise AssertionError('Huge-origin mean timestamp unexpectedly preserves local offset to tolerance')
if not math.isclose(anchor['mean_time_offset_s'],.1,rel_tol=1e-14):
    raise AssertionError(anchor)
report={
    'schema':'mhdlab-new-rare-component-joint-probe-v1',
    'module_sha256':hashlib.sha256((ROOT/'mhdlab/windowed_joint_source_moments.py').read_bytes()).hexdigest(),
    'rare_represented_count':minimum,'dominant_count':2.,'projected_rare_probability':0.,
    'cov_time_energy_s_j':resolved['cov_time_expected_translational_energy_s_j'],
    'between_component_energy_variance_j2':resolved['variance_expected_translational_energy_j2'],
    'mean_conditional_kinetic_energy_variance_j2':resolved['mean_conditional_kinetic_energy_variance_j2'],
    'full_kinetic_energy_variance_j2':resolved['variance_kinetic_energy_j2'],
    'time_anchor':anchor,
    'checks_passed':6,
    'scope':'New pure mixture helper; uses manufactured exact component records, no source qualification claim, canonical-history replay, sampler, transport or spectra.',
    'limitation':'The full public include_component_records=True interface intentionally rejects this fixture because individual fourth energy moments overflow; this probes only supported normalized aggregate algebra.'
}
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps(report,indent=2,allow_nan=False))
