"""Exact finite-distribution check of fixed-allocation estimator formulas."""
from fractions import Fraction as F
from itertools import product
import hashlib
import json
from pathlib import Path

work=Path(__file__).resolve().parent
atoms=(((F(0),F(1),F(1,2)),(F(2),F(-1),F(1,3)),(F(5),F(4),F(1,6))),
       ((F(-3),F(2),F(1,4)),(F(1),F(5),F(3,4))))
alpha=(F(2,5),F(3,5))
def expectation(c,fn):
    return sum((p*fn(a,b) for a,b,p in atoms[c]),F(0))
means=tuple((expectation(c,lambda a,b:a),expectation(c,lambda a,b:b)) for c in range(2))
mu=tuple(sum((alpha[c]*means[c][j] for c in range(2)),F(0)) for j in range(2))
cov=tuple((expectation(c,lambda a,b:(a-means[c][0])**2),
           expectation(c,lambda a,b:(b-means[c][1])**2),
           expectation(c,lambda a,b:(a-means[c][0])*(b-means[c][1]))) for c in range(2))
target=sum((alpha[c]*expectation(c,lambda a,b:a*b) for c in range(2)),F(0))-mu[0]*mu[1]
def variance_formula(n,empirical):
    result=F(0)
    for c in range(2):
        da,db=means[c][0]-mu[0],means[c][1]-mu[1]
        aa,bb,ab=cov[c]
        beta=F(1) if empirical else 1-alpha[c]/n[c]
        psi2=expectation(c,lambda A,B:(beta*((A-means[c][0])*(B-means[c][1])-ab)
                                     +db*(A-means[c][0])+da*(B-means[c][1]))**2)
        result+=alpha[c]**2*psi2/n[c]
        factor=F(1,n[c]*(n[c]-1)) if empirical else F(n[c]-1,n[c]**3)
        result+=alpha[c]**4*factor*(aa*bb+ab**2)
    result+=alpha[0]**2*alpha[1]**2/F(n[0]*n[1])*(cov[0][0]*cov[1][1]+cov[0][1]*cov[1][0]+2*cov[0][2]*cov[1][2])
    return result

rows=[]
for n in ((2,3),(2,2),(1,2)):
    D=sum((alpha[c]**2*cov[c][2]/n[c] for c in range(2)),F(0))
    all_samples=tuple(tuple(product(atoms[c],repeat=n[c])) for c in range(2))
    distributions={'mean_A':[],'plugin':[],'known_corrected':[],'global_bessel':[]}
    if min(n)>=2:
        distributions['empirically_corrected']=[]
    for selections in product(*all_samples):
        probability=F(1)
        for selection in selections:
            for _,_,p in selection:
                probability*=p
        samplemeans=tuple((sum((a for a,_,_ in selection),F(0))/n[c],
                           sum((b for _,b,_ in selection),F(0))/n[c]) for c,selection in enumerate(selections))
        empirical_mu=tuple(sum((alpha[c]*samplemeans[c][j] for c in range(2)),F(0)) for j in range(2))
        empirical_raw=sum((alpha[c]*sum((a*b for a,b,_ in selections[c]),F(0))/n[c] for c in range(2)),F(0))
        plugin=empirical_raw-empirical_mu[0]*empirical_mu[1]
        values={'mean_A':empirical_mu[0],'plugin':plugin,'known_corrected':plugin+D,
                'global_bessel':plugin/(1-sum((alpha[c]**2/n[c] for c in range(2)),F(0)))}
        if min(n)>=2:
            S=tuple(sum(((a-samplemeans[c][0])*(b-samplemeans[c][1]) for a,b,_ in selections[c]),F(0))/(n[c]-1) for c in range(2))
            values['empirically_corrected']=plugin+sum((alpha[c]**2*S[c]/n[c] for c in range(2)),F(0))
        for name,value in values.items():
            distributions[name].append((probability,value))
    summaries={}
    for name,distribution in distributions.items():
        total=sum((p for p,_ in distribution),F(0))
        if total!=1:
            raise AssertionError(total)
        mean=sum((p*v for p,v in distribution),F(0))
        variance=sum((p*(v-mean)**2 for p,v in distribution),F(0))
        summaries[name]={'mean':str(mean),'variance':str(variance)}
        if name=='mean_A':
            expectedvariance=sum((alpha[c]**2*cov[c][0]/n[c] for c in range(2)),F(0))
            assert mean==mu[0] and variance==expectedvariance
        elif name=='plugin':
            assert mean==target-D
            assert variance==variance_formula(n,False)
        elif name=='known_corrected':
            assert mean==target and variance==variance_formula(n,False)
        elif name=='empirically_corrected':
            assert mean==target and variance==variance_formula(n,True)
        elif name=='global_bessel':
            assert mean!=target
    rows.append({'n_c':n,'enumerated_outcomes':len(distributions['plugin']),
                 'target_source_covariance':str(target),'known_plugin_bias':str(-D),'estimators':summaries})

report={'schema':'mhdlab-fixed-allocation-exact-finite-check-v1',
        'arithmetic':'exact rational finite atom probabilities and observables; no Monte Carlo approximation',
        'cases':rows,'all_equalities_passed':True,
        'scope':'New work-only estimator mathematics, no source/sampler/history execution or old reference reuse',
        'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
path=work/'fixed_allocation_exact_check.json'
path.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
