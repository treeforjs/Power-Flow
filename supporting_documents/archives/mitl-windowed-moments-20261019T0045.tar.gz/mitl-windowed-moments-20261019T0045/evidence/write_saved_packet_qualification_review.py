"""Record a read-only code/formula/artifact review; no model is executed."""
import hashlib
import json
from pathlib import Path

work=Path(__file__).resolve().parent
script=work/'qualify_saved_windowed_packets.py'
folder=work/'windowed-packet-qualification'
report_path=folder/'report.json'
report=json.loads(report_path.read_text())
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
if sha(script)!=report['script_sha256']:
    raise SystemExit('Qualification script/report pin mismatch')
for name,digest in report['output_sha256'].items():
    if sha(folder/name)!=digest:
        raise SystemExit(f'Qualification output pin mismatch: {name}')
example=work/'windowed-moment-example'
for name,key in (
    ('report.json','inspection_report_sha256'),
    ('moments_order_0032.json','moment_reference_sha256'),
    ('packet_export_boundary_packets.npz','packet_file_sha256'),
):
    if sha(example/name)!=report[key]:
        raise SystemExit(f'Pinned existing input changed: {name}')
review={
    'schema':'mhdlab-saved-windowed-packet-qualification-readonly-review-v1',
    'status':'review_complete_no_substantive_findings',
    'reviewed_source_sha256':{'qualify_saved_windowed_packets.py':sha(script)},
    'reviewed_report_sha256':sha(report_path),
    'artifact_sha256':{
        'windowed-packet-qualification/report.json':sha(report_path),
        **{f'windowed-packet-qualification/{name}':digest for name,digest in report['output_sha256'].items()},
        'fixed_component_allocation_uncertainty.md':sha(work/'fixed_component_allocation_uncertainty.md'),
        'fixed_allocation_exact_check.json':sha(work/'fixed_allocation_exact_check.json'),
    },
    'existing_input_sha256':{
        'inspection_report':report['inspection_report_sha256'],
        'order32_reference':report['moment_reference_sha256'],
        'packet_npz':report['packet_file_sha256'],
    },
    'closed_substantive_findings':[],
    'open_substantive_findings':[],
    'review_conclusions':[
        'Component count n_c and common represented weight w_c give actual component mass n_c*w_c; alpha_c=(n_c*w_c)/sum(n*w) equals the sum of normalized packet weights in that component.',
        'Model targets and estimator variances use actual alpha; ideal source alpha and their signed rounding shifts are separate. Exact signed packet-number residual remains available even when total float projections coincide.',
        'Conditional weighted mean variance sum(alpha_c^2*sigma_c^2/n_c) matches the fixed-allocation derivation.',
        'Direct population variance estimates receive the known within-component mean-estimator variance correction. Component expected kinetic energy is deterministic given allocation and correctly has zero sampling standard error.',
        'All six reported cross pairs are independent within each frozen component. Their known direct-covariance bias is zero, and the exact finite-n variance includes beta=1-alpha_c/n_c single-observation terms, within-component pair terms and cross-component pair terms.',
        'Thirty-five singleton components use independently supplied conditional source moments. The script does not construct a false empirical singleton variance.',
        'Thermal kinetic-energy variance is2(kB*T)^2 within each component. Activation, state-internal, and removal energies are excluded from translational kinetic energy.',
        'Time and geometry observations reconstruct retained original origins/window starts/local delays and local position offsets before centering, avoiding premature absolute-coordinate rounding.',
        'CSV corrections, signs, covariance-pair definitions and units inferred from the companion observable-unit table are consistent with the inspected formulas.',
        'The listed standardized differences are descriptive conditional sampling comparisons. They do not establish a statistical threshold, experimental uncertainty or physical validation.',
    ],
    'scope_and_qualification':{
        'components':48,'packets':512,'singleton_components':35,
        'mean_observables':6,'conditionally_independent_cross_pairs':6,
        'parameter_status':'manufactured','host_budget_accepted':False,
        'script_status_passed_interpretation':'artifact and model-consistency assertions completed, not a physics or statistical significance threshold',
        'order16_to32_change_interpretation':'finite ideal-source quadrature change shown separately; not a certified bound or sampling uncertainty',
        'sampling_model':'conditional on realized allocation, independent nonallocation variates and the stated frozen-component model; numerical projection and source-law errors remain separate',
    },
    'qualification_calculation_recomputed':False,
    'old_cases_or_oracles_rerun':False,
    'source_history_or_sampler_called':False,
    'public_files_edited':False,
    'review_method':'Read-only inspection of source, existing JSON/CSV outputs and fixed-allocation derivation; metadata hashing only, without evaluating numerical estimates again.',
}
path=work/'saved_packet_qualification_review.json'
path.write_text(json.dumps(review,indent=2,allow_nan=False)+'\n')
print(json.dumps({'review':str(path),'sha256':sha(path),'reviewed_report_sha256':review['reviewed_report_sha256'],
                  'reviewed_source_sha256':review['reviewed_source_sha256'],'open_substantive_findings':[]},indent=2))
