"""Render the preserved manufactured packet comparison as shareable figures."""
import csv
import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

work = Path(__file__).resolve().parent
source = work/'windowed-packet-qualification'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
report = json.loads((source/'report.json').read_text())
for name, digest in report['output_sha256'].items():
    assert sha(source/name) == digest
with (source/'means.csv').open(newline='') as stream:
    means = list(csv.DictReader(stream))
with (source/'cross_covariances.csv').open(newline='') as stream:
    covariances = list(csv.DictReader(stream))
labels = {'time_offset_s':'time', 'x_m':'width position', 'z_m':'current position',
          'width_square_m2':'centered width squared', 'kinetic_energy_j':'kinetic energy',
          'component_expected_energy_j':'component mean energy'}
cov_labels = {'time_offset_s':'time', 'x_m':'width', 'z_m':'current',
              'width_square_m2':'centered width squared', 'kinetic_energy_j':'kinetic energy',
              'component_expected_energy_j':'component mean energy'}
stochastic_means = [row for row in means if row['standardized_mean_difference']]
mean_values = [float(row['standardized_mean_difference']) for row in stochastic_means]
cov_values = [float(row['standardized_difference']) for row in covariances]
figure, axes = plt.subplots(1, 2, figsize=(12.4, 5.2), layout='constrained')
for axis, values, text, title in (
    (axes[0], mean_values, [labels[row['observable']] for row in stochastic_means], 'Weighted means'),
    (axes[1], cov_values, [f"Cov({cov_labels[row['left']]}, {cov_labels[row['right']]})" for row in covariances], 'Cross covariances'),
):
    axis.errorbar(values, range(len(values)), xerr=1., fmt='o', color='#155e75', capsize=3)
    axis.axvline(0, color='#444444', linewidth=.8)
    axis.set_yticks(range(len(values)), text)
    axis.invert_yaxis()
    axis.set_xlabel('Deviation / conditional sampling standard error')
    axis.set_title(title, fontsize=11)
    axis.grid(axis='x', alpha=.18)
figure.suptitle('Manufactured window source: one preserved 512-packet realization', fontsize=14)
figure.supxlabel('Bars show one model-derived standard error, conditional on the realized component allocation.\n'
                  '35 of 48 components contain one packet; their variances come from the source model.\n'
                  'Component mean energy is fixed by allocation. Quadrature changes and experimental uncertainty are separate.',
                  fontsize=9)
output = work/'windowed-packet-figure-final'
output.mkdir(exist_ok=False)
for suffix in ('png', 'pdf'):
    figure.savefig(output/f'windowed_packet_sampling.{suffix}', dpi=180)
plt.close(figure)
result = {'schema':'mitl-windowed-packet-qualification-figure-v1', 'parameter_status':'manufactured',
          'input_qualification_sha256':sha(source/'report.json'), 'script_sha256':sha(__file__),
          'output_sha256':{p.name:sha(p) for p in output.iterdir()},
          'limits':['Single manufactured packet realization with fixed-allocation model uncertainties; no experimental spectra or physical calibration.',
                    'The bars are standard deviations of source sampling estimators under stated conditional assumptions, not acceptance limits or certified numerical error bounds.']}
(output/'report.json').write_text(json.dumps(result, indent=2, allow_nan=False)+'\n')
print(json.dumps(result, indent=2, allow_nan=False))
