"""Freeze the new deterministic window moments and saved-packet evidence."""
from collections import Counter
import datetime
import hashlib
import importlib.metadata
import io
import json
from pathlib import Path
import re
import shutil
import subprocess
import tarfile
import tokenize
import xml.etree.ElementTree as ET

repo = Path('/workspace/Power-Flow')
work = Path(__file__).resolve().parent
out = Path('/workspace/handoffs/mitl-windowed-moments-20261019T0045')
base = 'e9cd0425282de254e12b7683a197d40963ecd1eb'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert not subprocess.check_output(['git','status','--porcelain'], cwd=repo, text=True).strip()
commit = subprocess.check_output(['git','rev-parse','HEAD'], cwd=repo, text=True).strip()
listing = json.loads((out/'source_file_list.json').read_text())
for name in listing['byte_identical_public_files']:
    assert (out/'source'/name).read_bytes() == (repo/name).read_bytes(), name
tree = ET.parse(work/'isolated-results.xml').getroot()
cases = tree.findall('.//testcase')
counts = dict(Counter(case.attrib['classname'] for case in cases))
assert len(cases) == 105 and sorted(counts.values()) == [27,30,48]
assert not tree.findall('.//failure') and not tree.findall('.//error') and not tree.findall('.//skipped')
review = json.loads((work/'moment_review_completion.json').read_text())
assert not review['open_substantive_findings']
for name, digest in review['reviewed_source_sha256'].items():
    assert sha(repo/name) == digest, name
for name, digest in review['artifact_sha256'].items():
    assert sha(work/name) == digest, name
packet_review = json.loads((work/'saved_packet_qualification_review.json').read_text())
assert not packet_review['open_substantive_findings']
for name, digest in packet_review['reviewed_source_sha256'].items():
    assert sha(work/name) == digest, name
for name, digest in packet_review['artifact_sha256'].items():
    assert sha(work/name) == digest, name
example = json.loads((work/'windowed-moment-example/report.json').read_text())
assert example['orders'] == [8,16,32] and example['parameter_status'] == 'manufactured'
for name, digest in example['source_sha256'].items():
    assert sha(repo/name) == digest, name
for name, digest in example['output_sha256'].items():
    assert sha(work/'windowed-moment-example'/name) == digest, name
qualification = json.loads((work/'windowed-packet-qualification/report.json').read_text())
assert qualification['status'] == 'passed' and qualification['components'] == 48 and qualification['packets'] == 512
assert qualification['singleton_components'] == 35 and qualification['mean_observables'] == qualification['independent_cross_covariances'] == 6
assert qualification['inspection_report_sha256'] == sha(work/'windowed-moment-example/report.json')
assert qualification['script_sha256'] == sha(work/'qualify_saved_windowed_packets.py')
assert packet_review['reviewed_report_sha256'] == sha(work/'windowed-packet-qualification/report.json')
assert qualification['host_budget_accepted'] is False and qualification['sampler_or_source_history_rerun'] is False
for name, digest in qualification['output_sha256'].items():
    assert sha(work/'windowed-packet-qualification'/name) == digest, name
figure = json.loads((work/'windowed-packet-figure-final/report.json').read_text())
assert figure['input_qualification_sha256'] == sha(work/'windowed-packet-qualification/report.json')
assert figure['script_sha256'] == sha(work/'plot_windowed_packet_qualification.py')
for name, digest in figure['output_sha256'].items():
    assert sha(work/'windowed-packet-figure-final'/name) == digest, name
evidence = out/'evidence'
evidence.mkdir(exist_ok=True)
for path in work.iterdir():
    if path.is_file() and path.suffix in {'.py','.json','.jsonl','.log','.xml','.md'} and not path.name.startswith('freeze-moment-handoff'):
        shutil.copyfile(path,evidence/path.name)
for dirname in ('windowed-moment-example','windowed-packet-qualification','windowed-packet-figure','windowed-packet-figure-final'):
    shutil.copytree(work/dirname,evidence/dirname,dirs_exist_ok=True)
with (out/'windowed-moments.patch').open('wb') as stream:
    subprocess.run(['git','diff',base,'HEAD'],cwd=repo,stdout=stream,check=True)
record = {
    'schema':'mitl-windowed-moment-verification-v1',
    'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source_commit':commit,'base_commit':base,'branch':'research/flash-publication-foundation',
    'commits':subprocess.check_output(['git','log','--reverse','--format=%H %s',base+'..HEAD'],cwd=repo,text=True).splitlines(),
    'results':{'new_unique_tests':105,'isolated_passed':105,'isolated_skipped':0,'isolated_file_pass_counts':counts,
               'public_files_byte_identical':len(listing['byte_identical_public_files']),'packaging_wrappers':len(listing['packaging_wrappers']),
               'new_exact_allocation_cases':3,'new_exact_allocation_outcomes':120,'new_rare_component_helper_checks':6,
               'saved_components':48,'saved_packets':512,'singleton_components':35,
               'qualified_mean_observables':6,'qualified_independent_cross_covariances':6,
               'unchanged_project_suites_repeated':False,'previous_source_evolution_or_sampler_repeated':False,
               'saved_reference_oracles_repeated':False},
    'runtime':{'packages':{name:importlib.metadata.version(name) for name in ('numpy','scipy','h5py','matplotlib','pytest')}},
    'independent_review':review,'saved_qualification_review':packet_review,'saved_packet_qualification':qualification,
    'figure':figure,'commands':[json.loads(line) for line in (work/'commands.jsonl').read_text().splitlines()],
    'input_labels':{'tests':'manufactured','example':'preserved manufactured source and packet set; no physical water or foil default',
                    'quadrature':'new finite source-window estimates at orders8,16,32',
                    'sampling_uncertainty':'conditional on actual allocation and stated independent variate/source model; not experimental error'},
    'limitations':[
        'Finite quadrature changes and scalar query qualification are separate estimates, not certified interval bounds.',
        'Primitive log moments retain SI underflow; joint statistics require supported represented local moments and requested normalized outputs.',
        'Actual represented packet weights define sampling comparison targets. Signed source-number rounding shifts remain separate.',
        'Thirty-five singleton components require known conditional source variances; no empirical variance is inferred from one packet.',
        'Standardized deviations are descriptive conditional sampling comparisons, not a statistical acceptance criterion or physical validation.',
        'Within-component thermal kinetic variance is included; supplied activation/internal/removal energies remain separate references.',
        'Source-emission windows remain distinct from recorded photon gates. No physical spectra, monolayers or absolute VUV calibration are inferred.',
        'No separately owned solver/state-data development, Quark source/build/runner, actual FLASH execution, remote push/merge/publish or external message.',
    ],
    'next_task':'Qualify fixed physical SOURCE-emission window support across preserved refined histories. Build explicit intersection/rounding plans, compare partial release and joint moments across saved spatial/snapshot/integration resolutions, and separate new quadrature changes from source discretization. Reuse stored histories; no repeated evolution, old suites or saved oracles.',
}
(out/'verification.json').write_text(json.dumps(record,indent=2,allow_nan=False)+'\n')
(out/'systems-mitl-windowed-moments-10192026.md').write_text(f'''# MITL window-conditioned timing, geometry and thermal statistics

Power-Flow is pinned to `{commit}` on `research/flash-publication-foundation`.
Three local commits separate local timing quadrature, joint mixture statistics
and guarded inspection of saved exports. `windowed-moments.patch` contains this
pass's changes. The prior packet is
`/workspace/handoffs/mitl-windowed-boundary-20261018T2348.tar.gz`.

Open probability-space quadrature integrates the qualified source window's log
local delays. Centered scaled variance avoids raw-moment subtraction; logs retain
positive moments outside their SI projection range. Original interval origin,
window start and local mean stay separate in the joint calculation. A fixed
dominant-component anchor supports comparisons between quadrature orders without
first rounding away local timing at a large origin. Global mean time has its own
precision flag. The scalar law's numerical query qualification and finite-order
quadrature resolution remain distinct.

Joint statistics use exact rational arithmetic on represented component counts,
rectangle geometry and local moment estimates. Tiny displayed probabilities do
not delete components. Width redistribution changes only the x law and preserves
the time/current/state/temperature mixture. The full kinetic-energy variance is
`Var(2*kB*T) + E[2*(kB*T)^2]`; reporting only the first term would omit thermal
scatter. Supplied internal and removal costs remain separate from translation
and the kinetic activation barrier. Required unrepresented timing or final SI
statistics reject explicitly; optional fourth-energy diagnostics retain logs.

All 105 new checks passed, and all 105 passed in the portable subset: 48 timing,
27 joint-mixture and 30 inspection checks. One added analytic covariance
assertion reran only its affected existing test and adds no unique test count.
Three new exact-rational finite-allocation cases enumerate 120 outcomes; six
focused aggregate-helper checks retain rare-component effects. The latter's
extreme fixture does not qualify standalone component energy moments. Exact
scope and pins are in `verification.json` and the independent reviews. Earlier
passing suites and saved oracles were not rerun. The original saved source
evolution and packet generation were reused; new tests use fresh small fixtures.

The following bounded verification reused the saved 48-component, 512-packet
manufactured export. New moment estimates use orders 8/16/32. Six weighted means
and six conditionally independent cross-covariances use actual represented
packet-weight targets and exact finite-n allocation formulas. Thirty-five
components have one packet: their conditional variances come from the source
model, rather than a false empirical singleton variance. Signed count/target
rounding differences remain explicit. Maximum standardized deviations are about
1.04 for means and 1.59 for cross-covariances; these are descriptive values,
not a statistical pass/fail or physical validation. Quadrature changes remain
separate from sampling, source-parameter and experimental uncertainty.

`evidence/windowed-packet-qualification/` contains the reviewed JSON/CSVs.
`evidence/windowed-packet-figure-final/` contains the final PNG and vector PDF;
the earlier layout and its original script are preserved separately. All figures
are labeled manufactured. The source subset contains byte-identical public files
plus four named packaging wrappers. Exact commands, exits, input/code/output
hashes and archived payload verification are recorded. Commands after freezing
remain in the local pass's `commands.jsonl`.

The original saved packet export's files are preserved in
`evidence/windowed-moment-example/` with the prefix `packet_export_`. Removing
that prefix into a new directory restores the original export bytes; its report
and `input_export_sha256` bind their original names. Inspection validates the
stored packet schema, units, array dimensions and canonical source association;
it does not independently rerun each saved sample's realization.

Source-emission restrictions are separate from photon recording gates. No gap,
charged trajectory, collision/radiative calculation, molecular state data,
host transaction, wall feedback or actual FLASH run was added. Quark integration
remains an owner handoff. Nothing was pushed or published. Physical water
coverage, raw diagnostics, absolute VUV normalization and configured licensed
FLASH/workstation remain unresolved.

The selected next task is fixed physical SOURCE-window intersection and
resolution qualification across already preserved refined histories. New
partial-release/moment comparisons will separate quadrature changes from source
space/time discretization, while reusing the stored evolution. Read
`source/docs/windowed_source_moments.md` for the exact interfaces.
''')
for path in sorted(out.rglob('*'),key=lambda p:len(p.parts),reverse=True):
    if path.is_dir() and path.name in {'__pycache__','.pytest_cache'}:
        shutil.rmtree(path)
    elif path.is_symlink():
        raise ValueError('Unexpected delivery symlink')
words = [[65,73],[67,108,97,117,100,101],[67,104,97,116,71,80,84],[79,112,101,110,65,73],[67,111,100,101,120],[67,111,112,105,108,111,116],[76,76,77]]
pattern = re.compile(r'\b(?:'+'|'.join(''.join(map(chr,w)) for w in words)+r')\b',re.I)
for path in out.rglob('*'):
    if path.is_file() and path.suffix in {'.py','.md','.json','.jsonl','.log','.patch','.xml','.txt'}:
        content = path.read_text()
        if path.suffix == '.py':
            content = '\n'.join(t.string for t in tokenize.generate_tokens(io.StringIO(content).readline) if t.type in {tokenize.STRING,tokenize.COMMENT})
        assert not pattern.search(content),path
files = [p for p in sorted(out.rglob('*')) if p.is_file() and p.name != 'MANIFEST.sha256']
(out/'MANIFEST.sha256').write_text(''.join(f'{sha(p)}  {p.relative_to(out).as_posix()}\n' for p in files))
archive = out.with_suffix('.tar.gz')
with tarfile.open(archive,'w:gz') as stream:
    stream.add(out,arcname=out.name)
archive.with_suffix(archive.suffix+'.sha256').write_text(f'{sha(archive)}  {archive.name}\n')
print(json.dumps({'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,
                  'manifest_entries':len(files),'source_commit':commit,'results':record['results']},indent=2))
