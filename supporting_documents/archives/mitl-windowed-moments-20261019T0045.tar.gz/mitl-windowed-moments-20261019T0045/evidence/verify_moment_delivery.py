"""Verify the actual compressed moment handoff and all data/code bindings."""
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import subprocess
import tarfile

import numpy as np

work = Path(__file__).resolve().parent
out = Path('/workspace/handoffs/mitl-windowed-moments-20261019T0045')
repo = Path('/workspace/Power-Flow')
archive = out.with_suffix('.tar.gz')
sha = lambda value: hashlib.sha256(value).hexdigest()
with tarfile.open(archive,'r:gz') as stream:
    members = stream.getmembers()
    assert len({member.name for member in members}) == len(members)
    for member in members:
        name = PurePosixPath(member.name)
        assert not name.is_absolute() and '..' not in name.parts and name.parts[0] == out.name
        assert member.isdir() or member.isfile(),member.name
    payload = {PurePosixPath(member.name).relative_to(out.name).as_posix():stream.extractfile(member).read()
               for member in members if member.isfile()}
manifest = {}
for line in payload['MANIFEST.sha256'].decode().splitlines():
    digest,name = line.split('  ',1)
    assert name not in manifest
    manifest[name] = digest
assert set(payload) == set(manifest)|{'MANIFEST.sha256'}
for name,digest in manifest.items():
    assert sha(payload[name]) == digest,name
listing = json.loads(payload['source_file_list.json'])
for name in listing['byte_identical_public_files']:
    assert payload['source/'+name] == (repo/name).read_bytes(),name
changed = set(subprocess.check_output(['git','diff','--name-only','e9cd0425282de254e12b7683a197d40963ecd1eb','HEAD'],cwd=repo,text=True).splitlines())
assert changed == {'mhdlab/window_time_moments.py','mhdlab/windowed_joint_source_moments.py',
                   'tests/test_window_time_moments.py','tests/test_windowed_joint_source_moments.py',
                   'tests/test_windowed_moments_cli.py','tools/inspect_windowed_source_moments.py',
                   'docs/windowed_source_moments.md'}
assert changed.issubset(set(listing['byte_identical_public_files']))
record = json.loads(payload['verification.json'])
commit = subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert record['source_commit'] == commit
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip()
assert not record['independent_review']['open_substantive_findings']
assert not record['saved_qualification_review']['open_substantive_findings']
for name,digest in record['independent_review']['reviewed_source_sha256'].items():
    assert sha(payload['source/'+name]) == digest,name
for name,digest in record['saved_qualification_review']['reviewed_source_sha256'].items():
    assert sha(payload['evidence/'+name]) == digest,name
example_dir = 'evidence/windowed-moment-example/'
example = json.loads(payload[example_dir+'report.json'])
for name,digest in example['source_sha256'].items():
    assert sha(payload['source/'+name]) == digest,name
for name,digest in example['output_sha256'].items():
    assert sha(payload[example_dir+name]) == digest,name
for name,digest in example['input_export_sha256'].items():
    assert sha(payload[example_dir+'packet_export_'+name]) == digest,name
packet_report = json.loads(payload[example_dir+'packet_export_report.json'])
for name,digest in packet_report['output_sha256'].items():
    assert sha(payload[example_dir+'packet_export_'+name]) == digest,name
with np.load(io.BytesIO(payload[example_dir+'packet_export_boundary_packets.npz']),allow_pickle=False) as packets:
    assert json.loads(str(packets['metadata_json'])) == packet_report['packets']
    assert packets['particle_weight'].shape == (512,)
for order in (8,16,32):
    moments = json.loads(payload[example_dir+f'moments_order_{order:04d}.json'])
    assert moments['quadrature_order'] == order and len(moments['components']) == 48
    assert moments['host_budget_accepted'] is False and moments['status'] == 'manufactured'
qual_dir = 'evidence/windowed-packet-qualification/'
qualification = json.loads(payload[qual_dir+'report.json'])
assert qualification == record['saved_packet_qualification']
assert qualification['inspection_report_sha256'] == sha(payload[example_dir+'report.json'])
assert qualification['moment_reference_sha256'] == sha(payload[example_dir+'moments_order_0032.json'])
assert qualification['packet_file_sha256'] == sha(payload[example_dir+'packet_export_boundary_packets.npz'])
for name,digest in qualification['output_sha256'].items():
    assert sha(payload[qual_dir+name]) == digest,name
fig_dir = 'evidence/windowed-packet-figure-final/'
figure = json.loads(payload[fig_dir+'report.json'])
assert figure == record['figure'] and figure['input_qualification_sha256'] == sha(payload[qual_dir+'report.json'])
for name,digest in figure['output_sha256'].items():
    assert sha(payload[fig_dir+name]) == digest,name
result = {'archive':str(archive),'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,
          'manifest_entries':len(manifest),'archive_regular_files':len(payload),'unsafe_archive_entries':0,
          'public_files_byte_identical':len(listing['byte_identical_public_files']),'source_commit':commit,
          'public_paths_changed':sorted(changed),'verifier_script_sha256':sha(Path(__file__).read_bytes()),
          'results':record['results']}
(work/'delivery_verification.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps(result,indent=2,allow_nan=False))
