"""Record the verified moment/sampling milestone and release its editing lease."""
import datetime
import fcntl
import hashlib
import json
from pathlib import Path
import subprocess

work = Path(__file__).resolve().parent
repo = Path('/workspace/Power-Flow')
out = Path('/workspace/handoffs/mitl-windowed-moments-20261019T0045')
status_path = work.parent/'mitl-upstream-status.json'
journal_path = work.parent/'mitl-upstream-journal.jsonl'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
delivery = json.loads((work/'delivery_verification.json').read_text())
verification = json.loads((out/'verification.json').read_text())
qualification = json.loads((work/'windowed-packet-qualification/report.json').read_text())
commit = subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert commit == delivery['source_commit'] == verification['source_commit']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip()
assert sha(delivery['archive']) == delivery['sha256']
assert verification['results']['isolated_passed'] == 105 and qualification == verification['saved_packet_qualification']
now = datetime.datetime.now(datetime.timezone.utc).isoformat()
next_task = (
    'Qualify fixed physical SOURCE-emission window support across preserved refined histories. '
    'Implement explicit global-window/original-interval intersections with local-offset and '
    'rounding evidence, then compare partial released counts and joint moments across '
    'already saved spatial, snapshot and integration resolutions. Separate finite moment '
    'quadrature changes from source discretization. Reuse stored histories; do not repeat '
    'their evolution, previous passing suites, old audits or saved reference oracles. '
    'Source windows remain distinct from photon gates; no owned gap/chemistry/radiative solver edits.'
)
with (work.parent/'mitl-upstream-status.lock').open('a+') as lock:
    fcntl.flock(lock,fcntl.LOCK_EX)
    old_bytes = status_path.read_bytes()
    status = json.loads(old_bytes)
    assert status['active_lease_owner'] == work.name
    assert datetime.datetime.fromisoformat(status['active_editing_lease_until_utc']) > datetime.datetime.now(datetime.timezone.utc)
    if status['handoff'] not in status.setdefault('prior_handoffs',[]):
        status['prior_handoffs'].append(status['handoff'])
    history = status.setdefault('verification_history',[])
    if not any(item['pass_id'] == status['last_completed_pass_id'] for item in history):
        history.append({'pass_id':status['last_completed_pass_id'],'commit':status['last_complete_commit'],
                        'handoff':status['handoff'],'handoff_sha256':status['handoff_sha256'],
                        'verification':status['last_verified_suite']})
    status.update({
        'last_complete_commit':commit,'last_completed_pass_id':work.name,'last_update_utc':now,
        'handoff':delivery['archive'],'handoff_sha256':delivery['sha256'],'handoff_bytes':delivery['bytes'],
        'handoff_document':str(out/'systems-mitl-windowed-moments-10192026.md'),
        'active_lease_owner':None,'active_editing_lease_until_utc':None,'reserved_paths':[],
        'active_completed_subtasks':[],
        'active_phase':'Completed deterministic window moments and fixed-allocation saved-packet qualification; source-window resolution comparison selected next',
    })
    status['last_verified_suite'] = {
        **verification['results'],'targeted_unique_passed':105,
        'local_window_timing_checks':48,'joint_mixture_checks':27,'inspection_cli_checks':30,
        'targeted_execution':'Timing48; joint25 plus two new guard cases; CLI30 plus only one affected assertion rerun (no extra unique count). Final portable105 pass, no failures or skips.',
        'scope':'New local window quadrature, joint geometry/time/full thermal energy moments, guarded saved-export inspection, fixed-allocation sampling derivation and one preserved packet qualification; unchanged suites and saved source evolution not repeated',
        'statistical_acceptance_threshold_applied':False,
        'verification_record':str(out/'verification.json'),
        'delivery_manifest_entries':delivery['manifest_entries'],
        'physical_spectra_calculated':False,'host_budget_accepted':False,
        'previous_full_project_passed':721,'previous_full_project_skipped':2,
        'post_freeze_commands':str(work/'commands.jsonl'),
    }
    status['nonlinear_source_windows'].update({
        'conditional_timing_moments_implemented':True,
        'conditional_timing_moment_implementation':str(repo/'mhdlab/window_time_moments.py'),
        'joint_window_moments':str(repo/'mhdlab/windowed_joint_source_moments.py'),
        'moment_inspection_cli':str(repo/'tools/inspect_windowed_source_moments.py'),
        'moment_guide':str(repo/'docs/windowed_source_moments.md'),
        'moment_example':str(work/'windowed-moment-example/report.json'),
        'moment_example_sha256':sha(work/'windowed-moment-example/report.json'),
        'moment_quadrature_orders':[8,16,32],
        'full_within_component_kinetic_energy_scatter_included':True,
        'moment_qualification':'Finite log-quantile quadrature and exact rational mixture arithmetic on represented inputs; refinements are changes, not certified bounds. Required SI range and quantization failures reject, global time has separate precision flags.',
        'host_acceptance_qualified':False,
    })
    status['owner_response_controls'].update({
        'fixed_allocation_qualification':str(work/'windowed-packet-qualification/report.json'),
        'fixed_allocation_qualification_sha256':sha(work/'windowed-packet-qualification/report.json'),
        'fixed_allocation_derivation':str(work/'fixed_component_allocation_uncertainty.md'),
        'sampling_qualification_components':48,'sampling_qualification_packets':512,
        'sampling_qualification_singleton_components':35,
        'sampling_qualified_mean_observables':6,'sampling_qualified_independent_cross_covariances':6,
        'singleton_variance_source':'Known conditional source model; no invented empirical singleton variance.',
        'sampling_figure':str(work/'windowed-packet-figure-final/windowed_packet_sampling.pdf'),
        'physical_spectra_calculated':False,'owner_implementation_verified':False,
    })
    status['next_work'] = [{'priority':1,'task':next_task}] + [dict(item) for item in status['next_work'] if item['priority'] > 1]
    status['completed_milestones'].extend([
        'Deterministic partial-window local log-delay moments retain mean/second/variance logs, explicit SI underflow and independent scalar query qualification. Centered quadrature and fixed-origin joint time anchoring preserve small local timing; 48 new timing checks passed.',
        'Count-exact joint source mixtures preserve tiny represented populations, analytic rectangle geometry, source labels and width-only comparison. Full kinetic variance includes within-component2(kB*T)^2 plus between-component variation; 27 new joint and30 guarded saved-export checks passed.',
        'Three exact fixed-allocation finite-distribution cases enumerate120outcomes and six rare-component aggregate helper checks preserve projected-probability underflow effects. Formulas separate source population spread, allocation-conditional sampling covariance and finite-sample covariance bias.',
        'One preserved manufactured48-component512-packet realization was qualified against new order8/16/32 moments, with six means and six independent cross-covariances. Actual represented weights and signed source rounding shifts are explicit;35singleton components use known model variances. Standardized differences are descriptive, no statistical acceptance threshold or physical inference.',
        f'Three local commits through{commit[:7]};105 new targeted and105 portable checks passed, no skips. {delivery["public_files_byte_identical"]} public files and{delivery["manifest_entries"]} manifest entries verified in actual archive {delivery["sha256"]}. Final PNG/PDF numerical validation figure is labeled manufactured; original histories and packet generation were reused.',
    ])
    temporary = status_path.with_suffix('.json.new')
    temporary.write_text(json.dumps(status,indent=2,allow_nan=False)+'\n')
    temporary.replace(status_path)
    result = {
        'utc':now,'event':'completed_and_next_selected','pass_id':work.name,'commit':commit,
        'archive':delivery['archive'],'archive_sha256':delivery['sha256'],'archive_bytes':delivery['bytes'],
        'public_files_byte_identical':delivery['public_files_byte_identical'],
        'new_unique_checks':105,'portable_passed':105,'portable_skipped':0,
        'new_exact_allocation_cases':3,'new_exact_allocation_outcomes':120,'new_rare_helper_checks':6,
        'saved_components':48,'saved_packets':512,'singleton_components':35,
        'qualified_means':6,'qualified_cross_covariances':6,
        'exact_commands':str(work/'commands.jsonl'),
        'status_before_sha256':hashlib.sha256(old_bytes).hexdigest(),'status_after_sha256':sha(status_path),
        'lease_released':True,'reserved_paths':[],'next':next_task,
        'limits':'Finite quadrature estimates and manufactured sampling evidence; no experimental uncertainties, host transaction or physical spectra. Physical inventory/calibration and installed licensed FLASH/workstation remain unresolved.',
    }
    (work/'completion.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    with journal_path.open('a') as stream:
        stream.write(json.dumps(result,allow_nan=False)+'\n')
    print(json.dumps(result,indent=2,allow_nan=False))
