# Window-conditioned source moment verification subset

Named public files are byte-identical to the recorded commit. Four named
packaging wrappers isolate imports from unrelated downstream solvers.

```sh
python -W error -m pytest tests/test_window_time_moments.py tests/test_windowed_joint_source_moments.py tests/test_windowed_moments_cli.py
```

Inputs in the numerical examples are manufactured. Finite quadrature changes
are estimates, not certified bounds or experimental uncertainty. Full kinetic
energy variance includes within-component thermal scatter. Fixed-allocation
packet uncertainties use component conditional variances and do not invent an
empirical variance for singleton components. Read `docs/windowed_source_moments.md`.
