"""Portable upstream source-window moment verification subset."""
