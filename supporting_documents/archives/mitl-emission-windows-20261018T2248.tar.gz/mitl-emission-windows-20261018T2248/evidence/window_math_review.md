# Independent window mathematics review

This is a work-only review of new partial-emission-window work. No public code
is changed and neither saved eight-case nonlinear nor eleven-case linear
reference suites are rerun. The new runtime module was not yet available when
the following issue-specific calculations were recorded; they are mathematical
requirements, not acceptance of an implementation.

## Starting survival also changes the local release

For fixed original `c,r0` and a window of fixed duration `h`, set
`ca=c*exp(-sa)` and `ra=r0*exp(-c+ca)`. Let `I(delta,ca)=ra*h`, and
`M/N0=exp(-sa)*(1-exp(-delta))`. Differentiating the same physical law gives

```text
d(delta)/d(sa) = expm1(-ca*(-expm1(-delta)))
d(log M)/d(sa) = -1 + [d(delta)/d(sa)]/expm1(delta)
abs(d(log M)/d(sa)) <= 1+ca.
```

The identity follows from `d[g(v)]/dv=ca*exp(-v)*g(v)`, where
`g(v)=exp(ca*(1-exp(-v)))`. It explicitly includes the changing local rate and
coupling. An error budget covering only the explicit `-sa` term misses this
effect unless it already encloses local depletion with uncertain rebased
parameters. In the new manufactured `c=512, sa=.001, h=1e-9` check, the log-mass
derivative is about `-512.4881`, independently reproduced by a finite difference.

`window_start_sensitivity.py/.json` records three new cases. The captured
command exited zero with warnings as errors; its log SHA-256 is
`a794d2020d7939e8b636da662973f407dfc3abfa7c23adf830777d98b9100c6d`.

## An estimated quadrature error is not a global enclosure

The existing shared `_log_integral` is accurate in the finite-depletion source
range for which it was used, but its adaptive quadrature can miss a narrow
boundary layer when a new window asks for very large starting depletion.
At `c=512, s=1e5`, it returns log integral `523.5129254649702`, while an analytic
tail representation gives `523.5128573072446`: a discrepancy of `6.81577e-5`
without a quadrature warning. At `c=5, s=1e5`, the discrepancy is `2.18783e-5`.
This targeted extension-range probe does not show a defect in an accepted
baseline source calculation; that code caps its survivor calculation in a much
smaller range. It matters if the new window reuses the helper beyond that range.

Define `Ein(c)=integral_0^c (1-exp(-v))/v dv`. Then exactly

```text
I(s,c) = exp(c) * [s - Ein(c) + Ein(c*exp(-s))]
0 <= Ein(c*exp(-s)) <= c*exp(-s).
```

For `s>=80, c<=512`, omitting the last positive term changes log integral by at
most `log1p(c*exp(-s)/(s-Ein(c))) < 1.3e-34`. Floating-point evaluation and
uncertainty in `Ein(c)` still require their own allowance and a positive lower
denominator. `Ein(c)=gamma+log(c)+E1(c)` is suitable away from cancellation at
small `c`; a positive small-c integral or series handles that limit. This tail
formula retains actual starting survival and is distinct from the old
conditional-timing `s>=80` sentinel.

`window_integral_tail_probe.py/.json` records six new targeted helper checks,
including `s=1e4,1e5,1e6`. Its captured command exited zero with warnings as
errors; log SHA-256 is
`dbbbe513a07fbf1c0f2248a3672f8d2314ab627b37163f7f1c036f048e32d080`.

## Remaining implementation acceptance checks

The late start must be solved without converting the old timing sentinel into
zero source mass. Absolute start-depletion error must be propagated to log
mass, including input-log transforms and consistently rebased coefficients.
Quadrature estimates can support an explicitly conditional numerical
qualification; they are not automatically rigorous mathematical enclosures.

If rebased coupling is too small to represent, `I(delta,ca)` lies between
`delta` and `delta*exp(ca)`. Since
`d log(1-exp(-delta))/d log(delta)=delta/expm1(delta)<=1`, replacing that tiny
coupling by zero changes local log release by at most `ca`; a logarithmic upper
bound must be retained rather than reporting a rounded zero as an exact bound.

Local positive quantile delays and their logarithms must remain distinct from
rounded absolute timestamps. Mathematical log mass, represented areal amount,
represented area-integrated number and an accepted conservative launch budget
are distinct. Underflow of an intermediate fraction does not imply zero
physical number. Frozen-temperature energy per release remains `2*kB*T` plus
the supplied internal and binding energies; activation barrier affects kinetics
and is not the wall-energy debit. Source-emission windows do not select photon
observation times after separately owned transport and radiation.

## New implementation readback and targeted controls

The new reduced window implementation at SHA-256
`df478dd55d5eb4b366c7d3306a377fc32adac98962db8a68a24550e145a5cce6`
uses its own positive `Ein` correction, including the bounded large-depletion
tail. It does not use the old helper or the old `s>=80` timing sentinel. It
includes the conservative `1+original_coupling` starting-survival sensitivity
bound, preserves logarithmic rebased coupling underflow information, separates
local delays from the absolute origin and labels its envelopes estimated,
not certified. No substantive blocker was found in this readback.

Eighteen new independent analytic comparisons span the `s=32` transition,
couplings `1e-8`, `5`, `512`, and large depletion `1e5`. Their maximum absolute
comparison discrepancy is `0.0446` times the estimated envelope. New late-start
precision controls reject an unachievable `1e-7` log-mass tolerance and permit
a deliberately loose `.01` tolerance with a stated estimated qualification.
The command exited zero under warnings as errors, with log SHA-256
`dfe797cea6dc83b1eb80ebe6f26ba04fecba62a9e5f5ef866600ea09f68e87a6`.
Using `1+original_coupling` is conservative and may reject some late starts
that a tighter uncertain-local-coupling bound could support; this is a support
limitation, not a correctness issue.

The physical adapter at reviewed SHA-256
`34bad1a1ed1af6bc717e8cf7f6fe7bd43129b2ef69bf08aaea3bfbfa55c1e8e3`
uses actual area once for physical numbers and energies. It retains signed
`remaining_stop-remaining_start+release` number residuals and separate
`wall_debit-translation-internal-binding` energy residuals, without repair.
Its flags correctly distinguish individually represented fields from host
budget acceptance. The kinetic barrier is separate from the supplied removal
and gas internal costs; translation is expected flux energy `2*kB*T`.

One concrete portability issue was reported to the owner: direct per-particle
energy products rely on an extended exponent range for `np.longdouble`.
Isolated emulation of `longdouble` having float64 range changes a positive
represented thermal energy `8.62378e-47 J/m²` into a falsely qualified exact
zero. Inputs are positive subnormal temperature, initial density `1e300`, zero
activation/removal/internal energies, unit area and a unit constant-rate
interval. Combining positive raw-factor logs, or explicitly rejecting the
unqualified exponent range, resolves this representation risk. The current
Linux extended type produces the correct positive energy. The new probe's
captured exit is zero and log SHA-256 is
`2e913fd88355fde42e26373003e370061067159e283431e348d6681917deb939`.

## Portability finding closed after the targeted fix

The owner changed the adapter to form `log(2)+log(kB)+log(T)`, and
`log(QE)+log(supplied positive energy)`, before adding the release-population
logarithm. The total positive energy cost uses a pivoted log-sum-exp. Supplied
zero internal/removal energies remain distinct from underflowed positive costs.
The changed adapter SHA-256 is
`ccbafa86f189c8108204694e1105720abc23852302096c14b8ea959d1db1e33c`.

Only the issue-specific precision probe was repeated after this change. Native
extended intermediates give `8.623783610758515e-47 J/m²`; the emulated float64
intermediate range gives `8.623783610758585e-47 J/m²`. Both are positive,
qualified represented values with `exact_zero=false`. The isolated command
exited zero under warnings as errors; its captured log SHA-256 is
`6cdf152cabb98198ef75b6d0938fabf835f198ab2672b464b7f267962f6929e1`.
The owner also recorded two new independent Decimal-reference regressions for
tiny positive thermal and supplied energy costs. The previous eighteen branch
probes and saved reference suites were not repeated. No open substantive issue
remains from this bounded review; host budget acceptance and physical model
validation remain outside its scope.
