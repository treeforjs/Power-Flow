"""New independent derivative check; no old window-reference cases are rerun."""
import hashlib
import json
import math
from pathlib import Path

from scipy.integrate import quad
from scipy.optimize import brentq


def local_log_release(start, original_coupling, log_original_rate, duration):
    ca = original_coupling * math.exp(-start)
    log_ra = log_original_rate-original_coupling*(-math.expm1(-start))
    target = log_ra+math.log(duration)
    def residual(log_delta):
        delta=math.exp(log_delta)
        coefficient=quad(lambda u: math.exp(ca*(-math.expm1(-delta*u))),0.,1.,epsabs=0.,epsrel=2e-13)[0]
        return log_delta+math.log(coefficient)-target
    log_delta=brentq(residual,target-ca-1e-12,target+1e-12,xtol=1e-14)
    delta=math.exp(log_delta)
    return -start+math.log(-math.expm1(-delta)),delta,ca


results=[]
for c,start,duration,step in [(5.,.2,.3,1e-5),(512.,.001,1e-9,1e-7),(512.,10.,.1,1e-5)]:
    # Set the local initial rate at the nominal starting survival to one.
    log_r0=c*(-math.expm1(-start))
    center,delta,ca=local_log_release(start,c,log_r0,duration)
    lower=local_log_release(start-step,c,log_r0,duration)[0]
    upper=local_log_release(start+step,c,log_r0,duration)[0]
    finite_difference=(upper-lower)/(2*step)
    integrand=lambda u: math.exp(-delta*u+ca*(math.exp(-delta)-math.exp(-delta*u)))
    integral=delta*quad(integrand,0.,1.,epsabs=0.,epsrel=2e-13)[0]
    derivative=-1-ca*integral/math.expm1(delta)
    relative_error=abs(finite_difference-derivative)/abs(derivative)
    if relative_error>1e-7 or not 1<=abs(derivative)<=1+ca+1e-12:
        raise ValueError('new start-rebase derivative control failed')
    results.append({'original_coupling':c,'start_depletion':start,'local_duration':duration,
                    'local_depletion':delta,'rebased_coupling':ca,
                    'analytic_dlog_window_mass_dstart_depletion':derivative,
                    'independent_finite_difference':finite_difference,
                    'relative_difference':relative_error,'conservative_magnitude_bound':1+ca})
report={'schema':'mhdlab-window-start-rebase-sensitivity-v1','status':'passed',
        'scope':'new manufactured mathematical derivative controls; no source/physical solver validation',
        'derivation':'delta_prime=-ca*integral_0^delta exp(-v+ca*(1-exp(-v)))dv / exp(ca*(1-exp(-delta))); dlogM/dsa=-1+delta_prime/expm1(delta)',
        'bound':'abs(dlogM/dsa)<=1+ca when both local rate and local coupling are consistently rebased',
        'finding':'An error allowance applied only to the explicit -sa term omits local-rate/coupling sensitivity unless the local-depletion enclosure already propagates those correlated parameter uncertainties.',
        'cases':results,'old_reference_suites_rerun':False,
        'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps(report,indent=2,allow_nan=False))
