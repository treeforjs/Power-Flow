"""Prepare the new emission-window source subset for independent import checks."""
import ast
import hashlib
import json
from pathlib import Path
import shutil

repo=Path('/workspace/Power-Flow')
out=Path('/workspace/handoffs/mitl-emission-windows-20261018T2248')
assert not out.exists()
source=out/'source'
source.mkdir(parents=True)
names={'mhdlab/temkin_emission_window.py','mhdlab/temkin_source_window.py',
       'tests/test_temkin_emission_window.py','tests/test_temkin_source_window.py',
       'tests/test_temkin_emission_window_cli.py','tools/inspect_temkin_emission_window.py',
       'configs/temkin_window_manufactured.json','docs/temkin_emission_windows.md'}
pending=list(names)
while pending:
    name=pending.pop()
    if not name.endswith('.py'):
        continue
    tree=ast.parse((repo/name).read_text())
    needed=[]
    for node in ast.walk(tree):
        if isinstance(node,ast.ImportFrom) and node.module:
            if node.level:
                needed.append('mhdlab/'+node.module.replace('.','/')+'.py')
            elif node.module.startswith('mhdlab.'):
                needed.append(node.module.replace('.','/')+'.py')
    for node in tree.body:
        if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='CODE_PATHS' for t in node.targets):
            needed.extend(ast.literal_eval(node.value))
    for item in needed:
        if (repo/item).is_file() and item not in names:
            names.add(item);pending.append(item)
assert not names.intersection({'mhdlab/runner.py','mhdlab/chemistry.py','mhdlab/kinetic_gap.py','mhdlab/cr_data.py','mhdlab/bolsig.py'})
for name in sorted(names):
    target=source/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(repo/name,target)
wrappers={
 'mhdlab/__init__.py':'"""Portable upstream source-window verification subset."""\n',
 'pytest.ini':'[pytest]\npythonpath = .\n',
 'requirements.txt':'numpy\nscipy\nh5py\nmatplotlib\npytest\n',
 'README.md':'''# Partial source-emission window verification subset

Named public files are byte-identical to the recorded commit. Four packaging
wrappers isolate import and dependency boundaries from unrelated solvers.

```sh
python -W error -m pytest tests/test_temkin_emission_window.py tests/test_temkin_source_window.py tests/test_temkin_emission_window_cli.py
python tools/inspect_temkin_emission_window.py --demo --output-dir /tmp/source-window --plot --require-represented-budget
```

The default source, pool, energies and geometry are manufactured. The numerical
quadrature envelopes are estimates with explicit rounding assumptions. A
represented budget performs no host transaction. Source-emission windows and
later photon-observation gates are separate operations. Read
`docs/temkin_emission_windows.md` before coupling these interfaces to a host.
'''}
for name,body in wrappers.items():(source/name).write_text(body)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
listing={'byte_identical_public_files':sorted(names),'packaging_wrappers':sorted(wrappers)}
(out/'source_file_list.json').write_text(json.dumps(listing,indent=2)+'\n')
(out/'source-files.sha256').write_text(''.join(f'{sha(source/name)}  {name}\n' for name in sorted(names)))
print(json.dumps({'public_files':len(names),'packaging_wrappers':len(wrappers),'output':str(out)},indent=2))
