"""New explicit finite-precision-platform probe of represented energy costs."""
import hashlib
import json
from pathlib import Path
import sys

import numpy as np

REPO=Path('/workspace/Power-Flow')
sys.path.insert(0,str(REPO))
from mhdlab.temkin_release import TemkinReservoir
import mhdlab.temkin_source_window as adapter

pool=TemkinReservoir(name='manufactured_tiny_temperature',state_id='M:manufactured-ground',
                     attempt_frequency_s=1.,activation_energy_ev=0.,desorption_energy_ev=0.,
                     internal_energy_ev=0.,coverage_coefficient=0.,reference_coverage_m2=1e300,
                     max_coverage_m2=1e300,kinetic_provenance='manufactured constant-rate precision probe',
                     energy_provenance='manufactured zero removal/internal costs with positive thermal translation')
kwargs=dict(reservoir=pool,initial_coverage_m2=1e300,temperature_k=float(np.nextafter(0.,1.)),
            parent_duration_s=1.,start_s=0.,stop_s=1.,patch_area_m2=1.,
            log_mass_tolerance=1e-7,status='manufactured',provenance='work-only intermediate-range compensation probe')
original=adapter.LD
baseline=adapter.FrozenTemkinSourceWindow(**kwargs).manifest()
try:
    adapter.LD=np.float64
    with np.errstate(under='ignore'):
        projected=adapter.FrozenTemkinSourceWindow(**kwargs).manifest()
finally:
    adapter.LD=original
keys=['translational_energy_j_m2','total_wall_energy_debit_j_m2']
report={'schema':'mhdlab-source-window-extended-precision-platform-probe-v1',
        'scope':'new isolated emulation of a NumPy platform where longdouble has float64 range; no process environment changed',
        'native_longdouble_max_exponent':int(np.finfo(np.longdouble).maxexp),
        'emulated_max_exponent':int(np.finfo(np.float64).maxexp),
        'native_records':{key:baseline['quantities'][key] for key in keys},
        'emulated_records':{key:projected['quantities'][key] for key in keys},
        'emulated_all_budget_values_qualified':projected['all_budget_values_qualified'],
        'source_sha256':hashlib.sha256((REPO/'mhdlab/temkin_source_window.py').read_bytes()).hexdigest(),
        'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'finding':'Direct positive per-particle energy multiplication can underflow to zero before logarithmic rescaling if longdouble has float64 range. Qualify the extended-exponent requirement explicitly, or combine positive raw-factor energy logs before representation; positive temperature is not an exact-zero supplied energy cost.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps(report,indent=2,allow_nan=False))
