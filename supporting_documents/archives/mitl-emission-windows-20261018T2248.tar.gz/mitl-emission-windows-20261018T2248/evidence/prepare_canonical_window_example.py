"""Select one existing manufactured source component without reintegration."""
import hashlib
import json
from pathlib import Path
import h5py

work=Path(__file__).parent
source=work.parent/'mitl-upstream-20261018T2148/coverage-source-example/source_0003.h5'
with h5py.File(source) as handle:
    duration=float(handle['time_edges_s'][4]-handle['time_edges_s'][3])
config={'schema':'mhdlab-temkin-window-inspection-config-v1','parameter_status':'manufactured',
        'parameter_provenance':'Partial emission inspection of one hash-associated manufactured canonical source component; no physical foil or photon gate.',
        'component':{'interval_index':3,'reservoir_index':0,'current_index':1,'width_index':5},
        'window':{'start_s':.2*duration,'stop_s':.8*duration,'log_mass_tolerance':1e-7},
        'probabilities':[.01,.1,.25,.5,.75,.9,.99]}
output=work/'canonical-window-config.json'
assert not output.exists()
output.write_text(json.dumps(config,indent=2)+'\n')
print(json.dumps({'config':str(output),'config_sha256':hashlib.sha256(output.read_bytes()).hexdigest(),
                  'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'selected_parent_duration_s':duration}))
