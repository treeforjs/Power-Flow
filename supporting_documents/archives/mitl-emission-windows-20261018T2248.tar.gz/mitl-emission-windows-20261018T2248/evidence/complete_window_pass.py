"""Record the verified handoff and release this pass's bounded editing lease."""
import datetime
import fcntl
import hashlib
import json
from pathlib import Path
import subprocess

work = Path(__file__).resolve().parent
repo = Path('/workspace/Power-Flow')
status_path = work.parent / 'mitl-upstream-status.json'
journal_path = work.parent / 'mitl-upstream-journal.jsonl'
owner = work.name
out = Path('/workspace/handoffs/mitl-emission-windows-20261018T2248')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
delivery = json.loads((work / 'delivery_verification.json').read_text())
verification = json.loads((out / 'verification.json').read_text())
controls = json.loads((work / 'windowed-source-controls/artifacts/report.json').read_text())
commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
assert commit == delivery['source_commit'] == verification['source_commit']
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo, text=True).strip()
assert sha(delivery['archive']) == delivery['sha256']
assert controls == verification['windowed_source_controls']
assert controls['all_component_partition_checks_passed'] and not controls['rejected_associations']
assert verification['results']['isolated_passed'] == 185
now = datetime.datetime.now(datetime.timezone.utc).isoformat()
next_task = (
    'Implement the history/boundary contract and paired source-packet interface for '
    'qualified partial emission windows. Retain original component identities, '
    'partial counts, local delays/log delays, temperature, state, actual patch area '
    'and full velocity mixture. Keep source time separate from photon gates and '
    'make host budget acceptance explicit. No gap evolution or owned solver edits.'
)
with (work.parent / 'mitl-upstream-status.lock').open('a+') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX)
    old_bytes = status_path.read_bytes()
    status = json.loads(old_bytes)
    assert status['active_lease_owner'] == owner
    assert datetime.datetime.fromisoformat(status['active_editing_lease_until_utc']) > datetime.datetime.now(datetime.timezone.utc)
    old_handoff = status['handoff']
    if old_handoff not in status.setdefault('prior_handoffs', []):
        status['prior_handoffs'].append(old_handoff)
    history = status.setdefault('verification_history', [])
    if not any(item['pass_id'] == status['last_completed_pass_id'] for item in history):
        history.append({
            'pass_id': status['last_completed_pass_id'], 'commit': status['last_complete_commit'],
            'handoff': old_handoff, 'handoff_sha256': status['handoff_sha256'],
            'verification': status['last_verified_suite'],
        })
    status.update({
        'last_complete_commit': commit,
        'last_completed_pass_id': owner,
        'last_update_utc': now,
        'handoff': delivery['archive'],
        'handoff_sha256': delivery['sha256'],
        'handoff_bytes': delivery['bytes'],
        'handoff_document': str(out / 'systems-mitl-emission-windows-10182026.md'),
        'active_editing_lease_until_utc': None,
        'active_lease_owner': None,
        'reserved_paths': [],
        'active_completed_subtasks': [],
        'active_phase': 'Completed emission-window code and saved-source composition; next boundary-packet task selected',
    })
    status['last_verified_suite'] = {
        **verification['results'],
        'reduced_window_checks': 95,
        'physical_window_checks': 57,
        'inspection_cli_checks': 33,
        'scope': 'New partial source windows, physical accounting, canonical inspection and one saved manufactured history composition; unchanged suites and saved reference integrations not repeated',
        'saved_source_original_components': controls['original_components'],
        'conditioned_positive_components': controls['conditioned_positive_components'],
        'component_partition_checks': controls['component_partition_checks'],
        'partition_checks_passed': controls['all_component_partition_checks_passed'],
        'full_width_controls_exactly_equal': controls['fixed_width_independent_response_exactly_equal'],
        'manufactured_partial_width_response_differs': controls['manufactured_partial_width_response_differs'],
        'source_window_parameter_status': controls['parameter_status'],
        'physical_spectra_calculated': False,
        'host_budget_accepted': False,
        'verification_record': str(out / 'verification.json'),
        'delivery_manifest_entries': delivery['manifest_entries'],
        'previous_full_project_passed': 721,
        'previous_full_project_skipped': 2,
        'post_freeze_commands': str(work / 'commands.jsonl'),
    }
    status['nonlinear_source_windows'].update({
        'runtime_window_implemented': True,
        'runtime_implementation': str(repo / 'mhdlab/temkin_emission_window.py'),
        'physical_adapter': str(repo / 'mhdlab/temkin_source_window.py'),
        'inspection_cli': str(repo / 'tools/inspect_temkin_emission_window.py'),
        'guide': str(repo / 'docs/temkin_emission_windows.md'),
        'qualification': 'Positive integral quadrature and floating-point error estimates with explicit start-sensitivity and independent CDF/quantile rejection; estimated, not certified bounds.',
        'host_acceptance_qualified': False,
        'conditional_timing_moments_implemented': False,
        'window_conditioned_boundary_packets_implemented': False,
        'source_composition_evidence': str(work / 'windowed-source-controls/artifacts/report.json'),
        'source_composition_sha256': sha(work / 'windowed-source-controls/artifacts/report.json'),
        'saved_reference_integrations_repeated': False,
    })
    status['owner_response_controls'].update({
        'source_window_addendum': str(work / 'windowed-source-controls'),
        'source_window_report_sha256': sha(work / 'windowed-source-controls/artifacts/report.json'),
        'source_window_original_components': 192,
        'source_window_conditioned_components': 240,
        'source_window_partition_checks': 1920,
        'source_emission_is_not_photon_observation_gate': True,
        'physical_spectra_calculated': False,
        'owner_implementation_verified': False,
    })
    remaining = [dict(item) for item in status['next_work'] if item['priority'] > 1]
    status['next_work'] = [{'priority': 1, 'task': next_task}] + remaining
    status['completed_milestones'].extend([
        'Partial Temkin emission windows retain uncapped log survival, coherent local rebasing and qualified conditional timing; estimated mass envelopes include starting-depletion sensitivity and positive large-depletion integral corrections.',
        'Physical window accounting preserves fixed reservoir/state and true patch area; raw-factor log costs and log-sum-exp preserve represented population energy across narrow floating-point exponent ranges. No host transaction is accepted.',
        'Canonical source-component inspection carries exact code/input/status/provenance association, local-delay quantiles, representation flags and signed number/energy residuals; 185 new targeted and 185 portable checks passed with zero skips, plus 18 new independent branch/tail comparisons.',
        'One preserved manufactured source history partitioned 192 original components into 240 conditioned pieces with all 1920 number/energy checks passing within estimated numerical/interchange allowances. Exact fixed full-width responses match and a manufactured partial aperture differs. Report-only grid-dependent density totals were corrected using saved extensive quantities; no scalar or source integration was repeated.',
        f'Three local commits through{commit[:7]}; {delivery["public_files_byte_identical"]} public files and {delivery["manifest_entries"]} manifest entries verified in actual compressed archive {delivery["sha256"]}. No unchanged suites or saved reference integrations repeated.',
    ])
    temporary = status_path.with_suffix('.json.new')
    temporary.write_text(json.dumps(status, indent=2, allow_nan=False) + '\n')
    temporary.replace(status_path)
    result = {
        'utc': now, 'event': 'completed_and_next_selected', 'pass_id': owner,
        'commit': commit, 'archive': delivery['archive'], 'archive_sha256': delivery['sha256'],
        'archive_bytes': delivery['bytes'], 'public_files_byte_identical': delivery['public_files_byte_identical'],
        'targeted_passed': 185, 'portable_passed': 185, 'portable_skipped': 0,
        'saved_history_partition_checks': 1920,
        'exact_commands': str(work / 'commands.jsonl'),
        'status_before_sha256': hashlib.sha256(old_bytes).hexdigest(),
        'status_after_sha256': sha(status_path),
        'lease_released': True, 'reserved_paths': [], 'next': next_task,
        'limits': 'Estimated numerical envelopes, manufactured controls, no host acceptance or physical spectra. Physical inventory/calibration and installed licensed FLASH/workstation remain unresolved.',
    }
    (work / 'completion.json').write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
    with journal_path.open('a') as stream:
        stream.write(json.dumps(result, allow_nan=False) + '\n')
    print(json.dumps(result, indent=2, allow_nan=False))
