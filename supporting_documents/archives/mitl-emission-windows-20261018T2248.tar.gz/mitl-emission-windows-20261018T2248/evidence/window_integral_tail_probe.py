"""New targeted large-depletion integral check; no saved reference suite rerun."""
import hashlib
import json
import math
from pathlib import Path
import sys

from scipy.special import exp1

REPO=Path('/workspace/Power-Flow')
sys.path.insert(0,str(REPO))
from mhdlab.temkin_release import _log_integral

gamma=0.577215664901532860606512090082402431
cases=[]
for c in [5.,512.]:
    ein=gamma+math.log(c)+float(exp1(c))
    for s in [1e4,1e5,1e6]:
        actual=_log_integral(math.log(s),c)
        # Exact identity I=e^c[s-Ein(c)+Ein(c*e^-s)].  The omitted
        # positive term is <=c*e^-s, far below one float ulp here.
        reference=c+math.log(s-ein)
        cases.append({'coupling':c,'depletion':s,'helper_log_integral':actual,
                      'analytic_log_integral':reference,'log_integral_error':actual-reference,
                      'ein_constant':ein,'omitted_Ein_term_upper_bound_log':math.log(c)-s})
report={'schema':'mhdlab-window-large-depletion-integral-probe-v1',
        'scope':'new issue-specific helper check against an analytic asymptote with negligible positive remainder',
        'cases':cases,'old_reference_suites_rerun':False,
        'helper_source_sha256':hashlib.sha256((REPO/'mhdlab/temkin_release.py').read_bytes()).hexdigest(),
        'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'interpretation':'Adaptive quadrature estimated error is not a rigorous enclosure: a boundary layer can be missed at large s. A new window must reject such ranges or use a separately qualified tail representation before accepting a log-mass bound.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps(report,indent=2,allow_nan=False))
