"""New issue-specific branch/range probes of the partial-window implementation."""
import hashlib
import json
import math
from pathlib import Path
import sys

from scipy.special import exp1

REPO=Path('/workspace/Power-Flow')
sys.path.insert(0,str(REPO))
from mhdlab.temkin_emission_window import (
    ReducedTemkinEmissionWindow, TemkinWindowRangeError,
    _log_integral_estimate,
)

GAMMA=0.577215664901532860606512090082402431


def positive_ein_small(x):
    # Independent alternating series with a comfortably tiny remainder at x<1.
    term=x
    total=x
    for n in range(1,100):
        term *= -x*n/(n+1)**2
        total += term
        if abs(term)<1e-18*abs(total):break
    return total


def analytic_log_integral(s,c):
    ein=(GAMMA+math.log(c)+float(exp1(c))) if c>=1 else positive_ein_small(c)
    argument=c*math.exp(-s)
    remainder=positive_ein_small(argument) if argument else 0.
    return c+math.log(s-ein+remainder)


cases=[]
for c in [1e-8,5.,512.]:
    for intended_s in [31.5,math.nextafter(32.,0.),32.,math.nextafter(32.,math.inf),32.5,1e5]:
        log_s=math.log(intended_s)
        s=math.exp(log_s)
        estimate,envelope,method=_log_integral_estimate(log_s,c)
        reference=analytic_log_integral(s,c)
        discrepancy=abs(estimate-reference)
        if discrepancy>envelope+8*math.ulp(reference):
            raise ValueError('new integral estimate did not enclose analytic comparison within rounding')
        cases.append({'coupling':c,'intended_depletion':intended_s,'evaluated_depletion':s,
                      'method':method,'estimated_log_integral':estimate,
                      'independent_analytic_log_integral':reference,
                      'absolute_discrepancy':discrepancy,'estimated_log_envelope':envelope})

range_cases=[]
for sa in [32.,1e5]:
    c=512.
    log_rate=analytic_log_integral(sa,c)-math.log(.7)
    for tolerance in [1e-7,.01]:
        try:
            value=ReducedTemkinEmissionWindow(c,log_rate,1.,.7,1.,log_mass_tolerance=tolerance)
        except TemkinWindowRangeError as error:
            range_cases.append({'intended_start_depletion':sa,'log_mass_tolerance':tolerance,
                                'status':'explicitly_rejected','reason':str(error)})
        else:
            record=value.manifest()
            range_cases.append({'intended_start_depletion':sa,'log_mass_tolerance':tolerance,
                                'status':'numerically_qualified_under_estimated_envelopes',
                                'actual_start_depletion':value.start_depletion,
                                'estimated_log_source_fraction_error':record['numerical_diagnostics']['estimated_log_source_fraction_error'],
                                'source_log_fraction':value.log_source_fraction,
                                'certified_error_bound':record['numerical_diagnostics']['certified_error_bound']})
if not any(case['intended_start_depletion']==1e5 and case['log_mass_tolerance']==1e-7 and case['status']=='explicitly_rejected' for case in range_cases):
    raise ValueError('very late start was not rejected at a precision below the estimated mass uncertainty')

report={'schema':'mhdlab-new-window-branch-range-probes-v1','status':'passed',
        'scope':'new tail-switch and late-start range probes only; old reference suites not rerun',
        'integral_comparisons':cases,'late_start_precision_controls':range_cases,
        'source_sha256':hashlib.sha256((REPO/'mhdlab/temkin_emission_window.py').read_bytes()).hexdigest(),
        'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'interpretation':'Tail branch retains the missing positive Ein correction. Accepted precision remains conditional on the declared estimated quadrature/rounding allowances, not a rigorous certified enclosure.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps({'status':'passed','integral_comparisons':len(cases),
                  'max_comparison_to_estimated_envelope_ratio':max(case['absolute_discrepancy']/case['estimated_log_envelope'] for case in cases),
                  'late_start_precision_controls':range_cases,'source_sha256':report['source_sha256']},indent=2,allow_nan=False))
