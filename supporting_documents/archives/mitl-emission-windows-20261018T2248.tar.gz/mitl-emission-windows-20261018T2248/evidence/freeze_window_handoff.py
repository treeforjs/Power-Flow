"""Freeze qualified emission-window code and independent source evidence."""
import datetime
import hashlib
import importlib.metadata
import io
import json
from pathlib import Path
import re
import shutil
import subprocess
import tarfile
import tokenize
import xml.etree.ElementTree as ET
from collections import Counter

repo=Path('/workspace/Power-Flow')
work=Path(__file__).parent
out=Path('/workspace/handoffs/mitl-emission-windows-20261018T2248')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip()
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
listing=json.loads((out/'source_file_list.json').read_text())
for name in listing['byte_identical_public_files']:
    assert (out/'source'/name).read_bytes()==(repo/name).read_bytes(),name
root=ET.parse(work/'isolated-results.xml').getroot()
cases=root.findall('.//testcase')
assert len(cases)==185 and not root.findall('.//failure') and not root.findall('.//error')
assert not root.findall('.//skipped')
counts=dict(Counter(case.attrib['classname'] for case in cases))
review=json.loads((work/'window_review_completion.json').read_text())
assert not review['open_substantive_findings']
for name,digest in review['reviewed_source_sha256'].items():assert sha(repo/name)==digest,name
for dirname in ('source-window-example-final','canonical-window-example'):
    record=json.loads((work/dirname/'report.json').read_text())
    for name,digest in record['source_sha256'].items():assert sha(repo/name)==digest,name
    for name,digest in record['output_sha256'].items():assert sha(work/dirname/name)==digest,name
    assert record['represented_budget'] is not None
controls=json.loads((work/'windowed-source-controls/artifacts/report.json').read_text())
assert controls['status']=='passed' and controls['parameter_status']=='manufactured'
assert controls['original_components']==192 and controls['conditioned_positive_components']==240
assert controls['component_partition_checks']==1920 and controls['all_component_partition_checks_passed']
assert not controls['rejected_associations'] and controls['host_budget_accepted'] is False
assert controls['source_window_not_photon_gate'] is True
assert controls['fixed_width_independent_response_exactly_equal']
assert controls['manufactured_partial_width_response_differs']
assert controls['schema']=='mhdlab-windowed-source-composition-control-v2'
assert controls['actual_face_area_m2']==0.000125
for name,quantity in controls['quantity_partitions'].items():
    assert quantity['aggregate_passed']
    if name.endswith('_m2'):
        assert quantity['spatial_aggregation']=='actual_face_area_weighted_mean'
revision=controls['reporting_revision']
assert sha(work/'windowed-source-controls/artifacts'/revision['superseded_draft_report'])==revision['superseded_draft_report_sha256']
assert sha(work/'windowed-source-controls/compose_windowed_source.py')==revision['revised_composition_reporting_script_sha256']
assert sha(work/'windowed-source-controls/correct_reporting.py')==revision['reporting_projection_script_sha256']
for name,digest in controls['output_sha256'].items():
    assert sha(work/'windowed-source-controls/artifacts'/name)==digest,name
for name,digest in controls['window_implementation_sha256'].items():
    assert sha(repo/name)==digest,name
composition_review=json.loads((work/'windowed-source-controls/review_completion.json').read_text())
assert composition_review['status']=='closed_no_remaining_substantive_findings'
assert composition_review['reviewed_detailed_report_sha256']==sha(work/'windowed-source-controls/artifacts/report.json')
evidence=out/'evidence'
evidence.mkdir(exist_ok=True)
for path in work.iterdir():
    if path.is_file() and path.suffix in {'.py','.json','.jsonl','.log','.xml','.md'} and not path.name.startswith('freeze-window-handoff'):
        shutil.copyfile(path,evidence/path.name)
for dirname in ('source-window-example-final','canonical-window-example','windowed-source-controls'):
    shutil.copytree(work/dirname,evidence/dirname,dirs_exist_ok=True)
with (out/'emission-window.patch').open('wb') as stream:
    subprocess.run(['git','diff','5d60b963d7629f2d730bc033e0e4b7741bfb2167','HEAD'],cwd=repo,stdout=stream,check=True)
record={
 'schema':'mitl-emission-window-verification-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'source_commit':commit,'branch':'research/flash-publication-foundation',
 'commits':subprocess.check_output(['git','log','--reverse','--format=%H %s','5d60b963d7629f2d730bc033e0e4b7741bfb2167..HEAD'],cwd=repo,text=True).splitlines(),
 'results':{'targeted_unique_passed':185,'isolated_passed':185,'isolated_skipped':0,'isolated_file_pass_counts':counts,
            'public_files_byte_identical':len(listing['byte_identical_public_files']),'packaging_wrappers':len(listing['packaging_wrappers']),
            'new_independent_tail_comparisons':18,'unchanged_project_suites_repeated':False,
            'saved_8_nonlinear_and_11_constant_reference_integrations_repeated':False},
 'runtime':{'packages':{name:importlib.metadata.version(name) for name in ('numpy','scipy','h5py','matplotlib','pytest')}},
 'input_labels':{'demo':'manufactured scalar source','canonical_example':'hash-associated manufactured source component; previous source integration reused',
                 'source_composition':'one existing manufactured planar history, source-time windows only',
                 'reference_fixtures':'selected manufactured values from preserved high-precision references, no oracle reruns'},
 'independent_review':review,'windowed_source_controls':controls,'composition_review':composition_review,
 'commands':[json.loads(line) for line in (work/'commands.jsonl').read_text().splitlines()],
 'resolved_findings':[
    'Coherent rebase varies local rate and coupling with starting survival; source log-mass qualification includes amplified starting-depletion error.',
    'A new large-depletion use of the old integral helper can miss its early layer; the new window module uses a positive Ein correction and keeps existing implementations unchanged.',
    'Per-parent positive energy products can underflow where longdouble has float64 range; raw-factor logs and log-sum-exp preserve a representable population energy.',
    'The first composition draft summed patch densities as global totals. The corrected report uses actual-face-area means derived from unchanged physical totals, retaining the draft and exact reporting-only correction without new source/window evaluations.',
    'One subnormal test median was actually representable; only its probability fixture was corrected and affected test rerun.',
    'An initial example configuration used a system interpreter lacking h5py; the project interpreter generated it and the corrected canonical inspection passed.'],
 'limitations':[
    'Integral envelopes use explicit quadrature-error and rounding estimates, not certified mathematical enclosures or physical model validation.',
    'Supported construction does not guarantee every requested conditional CDF/quantile meets its separate numerical qualification.',
    'Initial inventories and windows must be positive; empty cases are explicit caller responsibilities.',
    'Finite log amounts and represented fields do not commit an inventory or establish host budget acceptance. Signed number/energy residuals need explicit owner ledger treatment.',
    'The windows condition source emission within frozen-temperature components, not photon times after transport, excitation and radiation.',
    'Prescribed temperature makes wall debit diagnostic; no thermal feedback, individual velocity sampling or molecular state branching is implemented.',
    'Physical monolayer inference, VUV absolute normalization and original diagnostics remain unresolved.',
    'No separately owned solver/state data, Quark source/build/runner, actual FLASH run, remote push/merge/publication or external message.'],
 'next_task':'Advance owner-only full-mixture source-window/response acceptance and source-grid subdivision/packet accounting with qualified local delays; retain actual collection and photon-time conditioning as separately owned requirements.'}
(out/'verification.json').write_text(json.dumps(record,indent=2,allow_nan=False)+'\n')
(out/'systems-mitl-emission-windows-10182026.md').write_text(f'''# MITL partial source-emission windows

Power-Flow is pinned to `{commit}` on `research/flash-publication-foundation`.
Three local commits separate reduced-law timing, physical source accounting and
the inspection/export interface. `emission-window.patch` contains this pass's
changes. The previous packet is
`/workspace/handoffs/mitl-inventory-observations-20261018T2148.tar.gz`.

The new reduced window retains uncapped starting survival, rebases the same
coverage-dependent source law and computes partial log mass without subtracting
nearly equal full CDF values. Conditional timing is a local delay from the
original source-window start. Starting survival and local release have explicit
estimated log-error qualification; requested precision outside the supported
range raises. Large-depletion evaluation preserves the early integral correction.
The eight nonlinear and eleven constant saved reference integrations were not
repeated. Selected scalar expectations are embedded in the new independent tests.

The physical adapter preserves the supplied reservoir/state, fixed kinetic
reference, initial density, frozen temperature and actual patch area. It reports
mathematical logs and independent representation flags for density, number and
translation/internal/removal/total diagnostic energies. Positive costs are formed
in logs before population scaling, preserving macroscopic energies even when a
single-parent cost is below a platform's exponent range. Signed inventory and
energy residuals remain explicit. No host transaction or residual repair occurs.
Outgoing mean translation remains `2*kB*T`; the supplied state/removal costs are
separate from the activation barrier. No thermal cooling feedback is solved.

The inspection CLI accepts an explicitly manufactured component or one selected
canonical planar history component. Exact source/run-summary hashes associate
declared status and provenance; absent a summary, external parameters remain
unvalidated. The source's original temperature/extraction metadata is retained.
Quantile CSVs use local delay/log delay; they do not imply precision in global
timestamps. A requested represented budget rejects unqualified number/energy
fields and still performs no host acceptance.

All 185 new targeted checks passed; all 185 also passed in the portable subset.
There are 95 reduced-law, 57 physical accounting and 33 CLI checks. Eighteen new
independent branch/tail comparisons and issue-specific precision probes are
recorded separately. The source subset contains byte-identical named public
files plus four explicit packaging wrappers. Earlier unchanged project suites
and saved reference solves were not rerun. Exact commands/exits/log and artifact
hashes, the corrected test fixture, pre-fix precision evidence and corrected
example interpreter failure remain recorded. Commands after freezing stay in
the local pass's `commands.jsonl`.

The following bounded verification applied partial windows over one preserved
manufactured source history. Its 192 original components produced 240 positive
conditioned pieces; all 1,920 component number/energy partition checks passed
within the explicitly estimated numerical/interchange allowances. Fixed linear
full-width controls retained exact equality; a declared manufactured partial
aperture broke it. Its work-only evidence is in
`evidence/windowed-source-controls/`. These are
source-emission gates, separate from photon recording gates: particles released
earlier can still radiate later. The owner handoff preserves exact component
labels and local timing rather than replacing the mixture with averaged source
moments. No gap evolution, collision/radiation or state-data development, Quark
source/build/runner, actual FLASH execution or remote publication was performed.

The selected next task is the history/boundary contract and paired source-packet
interface: retain conditioned component number, state, temperature, local delay,
launch geometry and velocity mixture while keeping host acceptance explicit.

The quadrature/error envelopes are explicitly estimated, not certified bounds.
Physical water parameters, absolute VUV normalization, original diagnostics and
actual FLASH/workstation setup remain independent limitations. Use
`source/docs/temkin_emission_windows.md` and `verification.json` for the exact
interfaces and the recorded scope of each numerical qualification.
''')
for path in sorted(out.rglob('*'),key=lambda p:len(p.parts),reverse=True):
    if path.is_dir() and path.name in {'__pycache__','.pytest_cache'}:shutil.rmtree(path)
    elif path.is_symlink():raise ValueError('Unexpected delivery symlink')
words=[[65,73],[67,108,97,117,100,101],[67,104,97,116,71,80,84],[79,112,101,110,65,73],[67,111,100,101,120],[67,111,112,105,108,111,116],[76,76,77]]
pattern=re.compile(r'\b(?:'+'|'.join(''.join(map(chr,w)) for w in words)+r')\b',re.I)
for path in out.rglob('*'):
    if path.is_file() and path.suffix in {'.py','.md','.json','.jsonl','.log','.patch','.xml','.txt'}:
        content=path.read_text()
        if path.suffix=='.py':content='\n'.join(t.string for t in tokenize.generate_tokens(io.StringIO(content).readline) if t.type in {tokenize.STRING,tokenize.COMMENT})
        assert not pattern.search(content),path
files=[p for p in sorted(out.rglob('*')) if p.is_file() and p.name!='MANIFEST.sha256']
(out/'MANIFEST.sha256').write_text(''.join(f'{sha(p)}  {p.relative_to(out).as_posix()}\n' for p in files))
archive=out.with_suffix('.tar.gz')
with tarfile.open(archive,'w:gz') as stream:stream.add(out,arcname=out.name)
digest=sha(archive)
archive.with_suffix(archive.suffix+'.sha256').write_text(f'{digest}  {archive.name}\n')
print(json.dumps({'archive':str(archive),'sha256':digest,'bytes':archive.stat().st_size,'manifest_entries':len(files),
                  'source_commit':commit,'results':record['results']},indent=2))
