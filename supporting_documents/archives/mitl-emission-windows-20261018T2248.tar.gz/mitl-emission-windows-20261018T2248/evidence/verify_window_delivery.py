"""Verify compressed handoff payload and public-source associations."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess
import tarfile

out=Path('/workspace/handoffs/mitl-emission-windows-20261018T2248')
repo=Path('/workspace/Power-Flow')
archive=out.with_suffix('.tar.gz')
sha=lambda value:hashlib.sha256(value).hexdigest()
with tarfile.open(archive,'r:gz') as stream:
    members=stream.getmembers()
    assert len({m.name for m in members})==len(members)
    for member in members:
        name=PurePosixPath(member.name)
        assert not name.is_absolute() and '..' not in name.parts and name.parts[0]==out.name
        assert member.isdir() or member.isfile(),member.name
    payload={PurePosixPath(m.name).relative_to(out.name).as_posix():stream.extractfile(m).read()
             for m in members if m.isfile()}
manifest={}
for line in payload['MANIFEST.sha256'].decode().splitlines():
    digest,name=line.split('  ',1)
    assert name not in manifest
    manifest[name]=digest
assert set(payload)==set(manifest)|{'MANIFEST.sha256'}
for name,digest in manifest.items():assert sha(payload[name])==digest,name
listing=json.loads(payload['source_file_list.json'])
for name in listing['byte_identical_public_files']:
    assert payload['source/'+name]==(repo/name).read_bytes(),name
expected={
 'mhdlab/temkin_emission_window.py','mhdlab/temkin_source_window.py',
 'tests/test_temkin_emission_window.py','tests/test_temkin_source_window.py',
 'tests/test_temkin_emission_window_cli.py','tools/inspect_temkin_emission_window.py',
 'configs/temkin_window_manufactured.json','docs/temkin_emission_windows.md'}
changed=set(subprocess.check_output(['git','diff','--name-only','5d60b963d7629f2d730bc033e0e4b7741bfb2167','HEAD'],cwd=repo,text=True).splitlines())
assert changed==expected and changed.issubset(set(listing['byte_identical_public_files']))
record=json.loads(payload['verification.json'])
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert record['source_commit']==commit
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip()
for dirname in ('source-window-example-final','canonical-window-example'):
    report=json.loads(payload[f'evidence/{dirname}/report.json'])
    for name,digest in report['output_sha256'].items():
        assert sha(payload[f'evidence/{dirname}/'+name])==digest,name
    for name,digest in report['source_sha256'].items():
        assert sha(payload['source/'+name])==digest,name
    assert report['window']['host_budget_accepted'] is False
    assert report['represented_budget']['host_budget_accepted'] is False
assert not record['independent_review']['open_substantive_findings']
controls=json.loads(payload['evidence/windowed-source-controls/artifacts/report.json'])
assert controls==record['windowed_source_controls']
assert controls['status']=='passed' and controls['parameter_status']=='manufactured'
assert controls['original_components']==192 and controls['conditioned_positive_components']==240
assert controls['component_partition_checks']==1920 and controls['all_component_partition_checks_passed']
assert not controls['rejected_associations'] and controls['host_budget_accepted'] is False
assert controls['source_window_not_photon_gate'] is True
for name,digest in controls['output_sha256'].items():
    assert sha(payload['evidence/windowed-source-controls/artifacts/'+name])==digest,name
for name,digest in controls['window_implementation_sha256'].items():
    assert sha(payload['source/'+name])==digest,name
result={'archive':str(archive),'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,
        'manifest_entries':len(manifest),'archive_regular_files':len(payload),'unsafe_archive_entries':0,
        'public_files_byte_identical':len(listing['byte_identical_public_files']),'source_commit':commit,
        'verifier_script_sha256':sha(Path(__file__).read_bytes()),'public_paths_changed':sorted(changed),
        'results':record['results']}
Path(__file__).with_name('delivery_verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
