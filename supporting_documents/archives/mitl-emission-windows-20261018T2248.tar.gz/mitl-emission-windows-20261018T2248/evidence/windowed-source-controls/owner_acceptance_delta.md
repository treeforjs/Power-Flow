# Acceptance delta: conditioned windows on one saved source

This extends the preceding full-interval source controls to **source-emission
time windows**, using only the pinned manufactured `source_0003.h5` at the
declared one-layer inventory knot. It does not select photon observation times.
The saved source history was read directly; no history loader, factory or
previous source integration was rerun.

Global cuts at 25 and 80 ns divide the 0–120 ns source into three disjoint
windows, including cuts inside original frozen-temperature intervals. The
192 original interval/pool/current/width components produce 240 positive
conditioned pieces, with no rejected associations or zero-inventory skips.
Every piece retains its original interval's initial coverage, temperature,
reservoir/exact state and actual patch area. Original time origin, local
window start and conditional delay remain separate; a rounded global timestamp
does not imply additional timing precision.

All 1,920 component number/diagnostic-energy partition checks pass against both
the stored canonical source and the whole-component scalar-window evaluation.
These checks use declared estimated numerical, representation and source
interchange allowances, not certified bounds or physical uncertainty bars.
Physical parent/J totals use actual area once. Global areal summaries are
actual face-area means, corrected after independent review; the original draft
and its reporting mistake are retained explicitly as superseded evidence.

For each source gate, fixed linear number kernels independent of launch width
give exact rational equality between resolved and matched-width controls. A
manufactured partial-width aperture breaks that equality. Matching moves only
launch width: the conditioned time/state/current/temperature mixture remains
attached to each original component.

The downstream owner should retain those labels and conditional timing laws,
first recover the stated complete-width linear invariance, then introduce
qualified finite losses, collection geometry or nonlinear feedback separately.
Do not substitute interval-averaged matched moment fields for the component
mixture. Do not discard earlier neutral emission solely because it precedes a
later photon gate. Overlapping windows, conservative inventory transactions,
particle allocation, transport, chemistry, radiation and instrument response
remain separately owned; this work accepts no host budget and predicts no
physical spectrum or experimental coverage.

The current detailed evidence is `artifacts/report.json`, schema
`mhdlab-windowed-source-composition-control-v2`; `report.json` in this directory
pins that report, the artifacts, captured commands and independent review.
