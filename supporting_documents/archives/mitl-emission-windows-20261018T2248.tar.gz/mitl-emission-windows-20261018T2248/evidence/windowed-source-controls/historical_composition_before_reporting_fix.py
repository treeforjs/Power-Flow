"""Compose qualified source-emission windows on one saved manufactured source.

Only the newly authorized scalar-window API is evaluated. No history loader,
source-history evolution, gap, chemistry, photon or host transaction is run.
"""
from __future__ import annotations

import argparse
import csv
from fractions import Fraction as Q
import hashlib
import json
import math
from pathlib import Path
import sys

import h5py
import numpy as np

REPO=Path('/workspace/Power-Flow')
HERE=Path(__file__).resolve().parent
SOURCE_DIR=Path('/workspace/research_work/mitl-upstream-20261018T2148/coverage-source-example')
sys.path.insert(0,str(REPO))

from mhdlab.constants import KB,QE
from mhdlab.temkin_release import INVERSION_LOG_RESIDUAL_TOLERANCE,TemkinReservoir
from mhdlab.temkin_source_window import FrozenTemkinSourceWindow

EPS=float(np.finfo(float).eps)
QUANTITIES={
    'released_m2':('released_m2',False),
    'released_number':('released_m2',True),
    **{name+suffix:(name+'_j_m2',suffix=='_j')
       for name in ['translational_energy','internal_energy','binding_energy','total_wall_energy_debit']
       for suffix in ['_j_m2','_j']},
}
KERNELS=('number','source_gate_weight','current_weight','state_weight','mixed_weight')
CODE_PATHS=('mhdlab/temkin_source_window.py','mhdlab/temkin_emission_window.py',
            'mhdlab/temkin_release.py','mhdlab/thermal_release.py','mhdlab/constants.py')
LIMITS=[
    'Manufactured source-emission windows only, not photon observation gates. Earlier neutral emission cannot be discarded merely because it precedes a later photon gate.',
    'This reads one existing source HDF and evaluates scalar windows from its original component inventories and frozen temperatures. No history factory, replay loader or previous source integration is rerun.',
    'The emitted-number and energy partition tests are conditional on the window estimated numerical envelopes and the stated original-source quadrature/residual/rounding allowance. They are not certified interval bounds or experimental errors.',
    'Every conditioned component retains its original interval, pool/exact state, current patch, temperature, physical area, local time law and origin. Width redistribution changes only launch x; no averaged temperature or new state yield is introduced.',
    'The number kernels are arbitrary fixed functions of SOURCE gate, exact state and current patch, constant within each selected window. The finite aperture assumes a uniform launch density inside each width patch and is manufactured, not recovered optics.',
    'Individually represented fields and partition closure do not accept a conservative host transaction. Signed residuals are retained; no residual repair, packet allocation, random sampling, gap transport, chemistry, radiation or physical spectrum is provided.',
]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read_dataset(handle,name,units):
    if not isinstance(handle.get(name,getlink=True),h5py.HardLink):
        raise ValueError('only local HDF datasets accepted')
    item=handle[name]
    if item.attrs.get('units')!=units:
        raise ValueError('wrong or missing units: '+name)
    value=np.asarray(item[...])
    if not np.all(np.isfinite(value)):
        raise ValueError('nonfinite stored source data')
    return value


def absolute_allowance(record,mass_error):
    if record['exact_zero']:
        return 0.
    if not record['qualified'] or record['value'] is None or record['value']<=0:
        raise ValueError('no qualified positive represented source amount')
    total=mass_error+record['log_rounding_error']+record['log_rounding_allowance']
    bound=record['value']*math.expm1(total)+128*EPS*record['value']
    if not math.isfinite(bound) or bound<=0:
        raise ValueError('estimated absolute amount allowance is not positively represented')
    return bound


def overlap(left,right,aperture):
    return max(Q(0),min(right,aperture[1])-max(left,aperture[0]))/(right-left)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-dir',type=Path,default=SOURCE_DIR)
    parser.add_argument('--output-dir',type=Path,default=HERE/'artifacts')
    parser.add_argument('--log-mass-tolerance',type=float,default=1e-7)
    args=parser.parse_args()
    if args.output_dir.exists():raise ValueError('use a new work-only artifact directory')
    if not math.isfinite(args.log_mass_tolerance) or args.log_mass_tolerance<=0:
        raise ValueError('explicit positive finite numerical allowance required')
    report_path=args.source_dir/'report.json'
    source_report=json.loads(report_path.read_text())
    if source_report['parameter_status']!='manufactured':raise ValueError('fixture must be explicitly manufactured')
    source_entry=next(item for item in source_report['sources'] if item['source_file']=='source_0003.h5')
    source_path=args.source_dir/source_entry['source_file']
    if sha(source_path)!=source_entry['source_sha256'] or sha(source_path)!=source_report['output_sha256'][source_path.name]:
        raise ValueError('saved source bytes do not match the existing export report')
    if any(sha(REPO/name)!=digest for name,digest in source_report['source_sha256'].items()):
        raise ValueError('source implementation pins differ from the existing export')
    current_pins={name:sha(REPO/name) for name in CODE_PATHS}
    with h5py.File(source_path,'r') as h:
        if h.attrs.get('schema')!='mhdlab-temkin-planar-release-v1':raise ValueError('wrong source schema')
        times=read_dataset(h,'time_edges_s','s');x=read_dataset(h,'x_edges_m','m');z=read_dataset(h,'z_edges_m','m')
        temperature=read_dataset(h,'temperature_k','K');area=read_dataset(h,'patch_areas_m2','m^2')
        coverage=read_dataset(h,'coverage_m2','m^-2')
        source={name:read_dataset(h,name,'m^-2' if name=='released_m2' else 'J m^-2')
                for name in {dataset for dataset,_ in QUANTITIES.values()}}
        residual=read_dataset(h,'inversion_log_time_residual','1')
        regimes=read_dataset(h,'inversion_regime','1')
        pools=tuple(TemkinReservoir(**row) for row in json.loads(h.attrs['reservoirs_json']))
        law_identity=str(h.attrs['law_identity'])
        provenance=str(h.attrs['parameter_provenance'])
        canonical_replay_tolerance=float(h.attrs['history_replay_relative_tolerance'])
        canonical_inverse_tolerance=float(h.attrs['inversion_log_residual_tolerance'])
        if canonical_inverse_tolerance!=INVERSION_LOG_RESIDUAL_TOLERANCE or canonical_replay_tolerance<0:
            raise ValueError('stored source numerical qualifications differ from the pinned implementation')
    nt,nr,nz,nx=source['released_m2'].shape
    if coverage.shape!=(nt+1,nr,nz,nx) or temperature.shape!=(nt,nz,nx) or area.shape!=(nz,nx):
        raise ValueError('saved source shapes disagree with component axes')
    cuts=np.array([float(times[0]),2.5e-8,8e-8,float(times[-1])])
    if not np.all(np.diff(cuts)>0) or not all(times[0]<cut<times[-1] and cut not in times for cut in cuts[1:-1]):
        raise ValueError('manufactured source cuts must be internal and off snapshot knots')
    state_codes={state:index for index,state in enumerate(sorted({pool.state_id for pool in pools}))}
    aperture=(Q(float(x[0]))+Q(29,100)*(Q(float(x[-1]))-Q(float(x[0]))),
              Q(float(x[0]))+Q(61,100)*(Q(float(x[-1]))-Q(float(x[0]))))
    width=Q(float(x[-1]))-Q(float(x[0]))
    response_resolved=np.full((len(cuts)-1,2,len(KERNELS)),Q(0),dtype=object)
    response_matched=response_resolved.copy()
    component_records=[];comparisons=[];rejections=[];skipped=[]
    gate_totals=[{name:Q(0) for name in QUANTITIES} for _ in range(len(cuts)-1)]
    gate_allowances=[{name:Q(0) for name in QUANTITIES} for _ in range(len(cuts)-1)]
    canonical_totals={name:Q(0) for name in QUANTITIES}
    whole_totals={name:Q(0) for name in QUANTITIES}
    canonical_allowance_totals={name:Q(0) for name in QUANTITIES}
    units=None
    for t in range(nt):
        origin,global_stop=float(times[t]),float(times[t+1]);dt=global_stop-origin
        for r,pool in enumerate(pools):
            for zi in range(nz):
                for xi in range(nx):
                    initial=float(coverage[t,r,zi,xi]);temp=float(temperature[t,zi,xi]);patch_area=float(area[zi,xi])
                    label={'original_interval_index':t,'pool_index':r,'pool_name':pool.name,'state_id':pool.state_id,
                           'current_patch_index':zi,'width_patch_index':xi,
                           'original_start_global_s':origin,'original_stop_global_s':global_stop,
                           'original_parent_duration_s':dt,'initial_coverage_m2':initial,'temperature_k':temp,
                           'patch_area_m2':patch_area,'source_file_sha256':source_entry['source_sha256']}
                    if initial==0:
                        if any(source[name][t,r,zi,xi]!=0 for name in source):raise ValueError('zero initial component has stored release')
                        skipped.append({**label,'reason':'exact_zero_original_inventory_explicitly_skipped'})
                        continue
                    if initial<0 or temp<=0 or patch_area<=0:raise ValueError('invalid original component')
                    common=dict(reservoir=pool,initial_coverage_m2=initial,temperature_k=temp,parent_duration_s=dt,
                                patch_area_m2=patch_area,log_mass_tolerance=args.log_mass_tolerance,
                                status='manufactured',provenance='work-only source-emission partition of pinned canonical manufactured component')
                    try:
                        whole=FrozenTemkinSourceWindow(start_s=0.,stop_s=dt,**common)
                        whole_manifest=whole.manifest();whole.represented_budget()
                    except ValueError as error:
                        rejections.append({**label,'scope':'whole_original_component_window','reason':str(error)})
                        continue
                    units=whole_manifest['quantity_units']
                    pieces=[]
                    for gate,(left,right) in enumerate(zip(cuts[:-1],cuts[1:])):
                        intersection_left=max(Q(origin),Q(float(left)));intersection_right=min(Q(global_stop),Q(float(right)))
                        if intersection_left>=intersection_right:continue
                        local_left=intersection_left-Q(origin);local_right=intersection_right-Q(origin)
                        start,stop=float(local_left),float(local_right)
                        if Q(start)!=local_left or Q(stop)!=local_right:
                            rejections.append({**label,'scope':'local_offset_projection','source_gate_index':gate,
                                               'reason':'intended exact float-endpoint intersection does not have exact local float offsets'})
                            continue
                        try:
                            window=FrozenTemkinSourceWindow(start_s=start,stop_s=stop,**common)
                            manifest=window.manifest();window.represented_budget()
                            median_log=float(window.time_law.log_quantile(.5))
                            median=float(window.time_law.quantile(.5))
                        except ValueError as error:
                            rejections.append({**label,'scope':'positive_intersection_source_window','source_gate_index':gate,
                                               'source_window_local_start_s':start,'source_window_local_stop_s':stop,'reason':str(error)})
                            continue
                        record={**label,'source_gate_index':gate,'source_gate_global_bounds_s':[float(left),float(right)],
                                'source_window_local_start_s':start,'source_window_local_stop_s':stop,
                                'conditional_median_log_delay_from_window_start_s':median_log,
                                'conditional_median_delay_from_window_start_s':median,
                                'global_median_best_float_s':origin+start+median,
                                'time_representation':'retain original origin, source-window local start and conditional delay separately; best-float sum does not imply absolute subtime resolution',
                                'window_manifest':manifest,'host_budget_accepted':False}
                        component_records.append(record);pieces.append(record)
                        mass_error=manifest['time_window']['numerical_diagnostics']['estimated_log_source_fraction_error']
                        for name in QUANTITIES:
                            represented=manifest['quantities'][name]
                            gate_totals[gate][name]+=Q(represented['value'])
                            gate_allowances[gate][name]+=Q(absolute_allowance(represented,mass_error))
                        code=state_codes[pool.state_id]
                        current_weight=1+(Q(float(z[zi]))+Q(float(z[zi+1]))-2*Q(float(z[0])))/(2*(Q(float(z[-1]))-Q(float(z[0]))))
                        weights=(Q(1),Q([1,2,4][gate]),current_weight,Q(1+code),1+Q((3*gate+5*code+7*zi)%13,13))
                        amount=Q(manifest['quantities']['released_number']['value'])
                        fractions=(Q(1),overlap(Q(float(x[xi])),Q(float(x[xi+1])),aperture))
                        matched_fractions=(Q(1),(aperture[1]-aperture[0])/width)
                        for ai in range(2):
                            for ki,weight in enumerate(weights):
                                response_resolved[gate,ai,ki]+=amount*weight*fractions[ai]
                                response_matched[gate,ai,ki]+=amount*weight*matched_fractions[ai]
                    expected_intersections=sum(max(Q(origin),Q(float(left)))<min(Q(global_stop),Q(float(right))) for left,right in zip(cuts[:-1],cuts[1:]))
                    if len(pieces)!=expected_intersections:
                        continue  # explicit rejection records above; never substitute a whole-window fallback
                    whole_mass_error=whole_manifest['time_window']['numerical_diagnostics']['estimated_log_source_fraction_error']
                    # Original source's declared inverse residual and accepted positive
                    # quadrature allowance, plus explicit elementary-operation scale.
                    # This is an estimated numerical assumption, not a certified bound.
                    operation_scale=1+sum(abs(math.log(value)) for value in (initial,temp,dt,patch_area,KB,QE))
                    canonical_log_allowance=(math.log1p(canonical_replay_tolerance)+abs(float(residual[t,r,zi,xi]))+canonical_inverse_tolerance
                                             +256*EPS*operation_scale)
                    for name,(dataset_name,extensive) in QUANTITIES.items():
                        canonical=Q(float(source[dataset_name][t,r,zi,xi]))*(Q(patch_area) if extensive else 1)
                        represented=whole_manifest['quantities'][name]
                        whole_value=Q(represented['value'])
                        part_value=sum(Q(piece['window_manifest']['quantities'][name]['value']) for piece in pieces)
                        part_bound=sum(Q(absolute_allowance(piece['window_manifest']['quantities'][name],piece['window_manifest']['time_window']['numerical_diagnostics']['estimated_log_source_fraction_error'])) for piece in pieces)
                        whole_bound=Q(absolute_allowance(represented,whole_mass_error))
                        canonical_bound=Q(float(canonical)*math.expm1(canonical_log_allowance)+128*EPS*float(canonical)) if canonical else Q(0)
                        canonical_difference=part_value-canonical;whole_difference=part_value-whole_value
                        bound=part_bound+canonical_bound;whole_comparison_bound=part_bound+whole_bound
                        passed=abs(canonical_difference)<=bound and abs(whole_difference)<=whole_comparison_bound
                        comparisons.append({**{key:label[key] for key in ('original_interval_index','pool_index','pool_name','state_id','current_patch_index','width_patch_index')},
                                            'quantity':name,'units':units[name],'canonical_from_hdf':float(canonical),
                                            'whole_scalar_window_api':float(whole_value),'sum_disjoint_windows':float(part_value),
                                            'partition_minus_canonical_signed':float(canonical_difference),
                                            'partition_minus_whole_api_signed':float(whole_difference),
                                            'combined_estimated_allowance_vs_canonical':float(bound),
                                            'combined_estimated_allowance_vs_whole_api':float(whole_comparison_bound),
                                            'canonical_declared_numerical_log_allowance':canonical_log_allowance,
                                            'canonical_inversion_regime':int(regimes[t,r,zi,xi]),'passed':passed})
                        canonical_totals[name]+=canonical;whole_totals[name]+=whole_value;canonical_allowance_totals[name]+=canonical_bound
    full_exact=all(response_resolved[g,0,k]==response_matched[g,0,k] for g in range(len(cuts)-1) for k in range(len(KERNELS)))
    partial_difference=any(response_resolved[g,1,k]!=response_matched[g,1,k] for g in range(len(cuts)-1) for k in range(len(KERNELS)))
    accepted=not rejections and bool(comparisons) and all(item['passed'] for item in comparisons) and full_exact and partial_difference
    args.output_dir.mkdir(parents=True)
    with (args.output_dir/'conditioned_source_components.jsonl').open('w') as stream:
        for record in component_records:stream.write(json.dumps(record,allow_nan=False)+'\n')
    with (args.output_dir/'component_partition_checks.csv').open('w',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(comparisons[0]) if comparisons else ['passed'],lineterminator='\n')
        writer.writeheader();writer.writerows(comparisons)
    with (args.output_dir/'source_only_response_controls.csv').open('w',newline='') as stream:
        writer=csv.writer(stream,lineterminator='\n')
        writer.writerow(['source_gate_index','aperture','kernel','resolved_linear_number','matched_component_linear_number','resolved_minus_matched_signed'])
        for gate in range(len(cuts)-1):
            for ai,aperture_name in enumerate(['full_width','manufactured_partial_width']):
                for ki,kernel in enumerate(KERNELS):
                    a=response_resolved[gate,ai,ki];b=response_matched[gate,ai,ki]
                    writer.writerow([gate,aperture_name,kernel,float(a),float(b),float(a-b)])
    summary={}
    for name in QUANTITIES:
        rows=[row for row in comparisons if row['quantity']==name]
        total=sum(gate[name] for gate in gate_totals)
        difference=total-canonical_totals[name]
        allowance=sum(gate[name] for gate in gate_allowances)+canonical_allowance_totals[name]
        summary[name]={'units':units[name] if units else None,'canonical_total':float(canonical_totals[name]),
                       'whole_scalar_api_total':float(whole_totals[name]),'disjoint_source_gate_totals':[float(gate[name]) for gate in gate_totals],
                       'sum_disjoint_total':float(total),'partition_minus_canonical_signed':float(difference),
                       'combined_estimated_absolute_allowance':float(allowance),
                       'max_component_fraction_of_estimated_allowance':max((abs(row['partition_minus_canonical_signed'])/row['combined_estimated_allowance_vs_canonical'] if row['combined_estimated_allowance_vs_canonical'] else 0. for row in rows),default=0.),
                       'aggregate_passed':abs(difference)<=allowance}
        if not summary[name]['aggregate_passed']:accepted=False
    report={'schema':'mhdlab-windowed-source-composition-control-v1','status':'passed' if accepted else 'explicit_rejection_or_partition_failure',
            'parameter_status':'manufactured','source_window_not_photon_gate':True,'host_budget_accepted':False,
            'source_report_sha256':sha(report_path),'source_hdf_sha256':sha(source_path),'source_file':str(source_path),
            'source_coverage_ml':source_entry['coverage_ml'],'source_law_identity':law_identity,'source_provenance':provenance,
            'original_export_source_sha256':source_report['source_sha256'],'window_implementation_sha256':current_pins,
            'composition_script_sha256':sha(Path(__file__)),'source_shape_interval_pool_current_width':[nt,nr,nz,nx],
            'source_gate_global_edges_s':cuts.tolist(),'log_mass_tolerance':args.log_mass_tolerance,
            'original_components':nt*nr*nz*nx,'exact_zero_initial_components_skipped':skipped,
            'conditioned_positive_components':len(component_records),'rejected_associations':rejections,
            'component_partition_checks':len(comparisons),'all_component_partition_checks_passed':bool(comparisons) and all(item['passed'] for item in comparisons),
            'quantity_partitions':summary,'fixed_width_independent_response_exactly_equal':full_exact,
            'manufactured_partial_width_response_differs':partial_difference,
            'partial_aperture_m':[float(v) for v in aperture],'response_kernels':list(KERNELS),
            'source_only_number_response_per_gate':{'resolved_full_width':[float(response_resolved[g,0,0]) for g in range(len(cuts)-1)],
                                                  'matched_full_width':[float(response_matched[g,0,0]) for g in range(len(cuts)-1)],
                                                  'resolved_partial_width':[float(response_resolved[g,1,0]) for g in range(len(cuts)-1)],
                                                  'matched_partial_width':[float(response_matched[g,1,0]) for g in range(len(cuts)-1)]},
            'canonical_history_replay_relative_tolerance':canonical_replay_tolerance,
            'canonical_inverse_log_residual_tolerance':canonical_inverse_tolerance,
            'canonical_allowance_assumption':'log1p(stored source interchange replay relative tolerance) + stored inverse log-time residual + producer inverse/positive-quadrature qualification + 256eps elementary-log scale; additive 128eps amount rounding. Conditional numerical/interchange allowance, not a rigorous enclosure or experimental error.',
            'window_allowance_assumption':'each represented amount times expm1(estimated window log-mass error + representation log-rounding error + declared rounding allowance), plus 128eps amount rounding; triangle sums across disjoint windows. Exact Fraction sums are used for represented amounts.',
            'output_sha256':{p.name:sha(p) for p in args.output_dir.iterdir() if p.is_file()},'limits':LIMITS}
    (args.output_dir/'report.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    if current_pins!={name:sha(REPO/name) for name in CODE_PATHS} or sha(source_path)!=source_entry['source_sha256']:
        raise ValueError('input or implementation changed during new window composition')
    print(json.dumps({'status':report['status'],'report_sha256':sha(args.output_dir/'report.json'),
                      'original_components':report['original_components'],'conditioned_positive_components':len(component_records),
                      'component_partition_checks':len(comparisons),'rejected_associations':len(rejections),
                      'exact_full_width_closure':full_exact,'finite_aperture_difference':partial_difference,
                      'max_component_allowance_fraction':max(item['max_component_fraction_of_estimated_allowance'] for item in summary.values())},indent=2))
    if not accepted:raise SystemExit(2)


if __name__=='__main__':main()
