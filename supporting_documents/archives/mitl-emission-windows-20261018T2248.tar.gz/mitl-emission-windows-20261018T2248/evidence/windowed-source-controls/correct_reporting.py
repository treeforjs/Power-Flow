"""Correct spatial summary measures using saved artifacts only; no window calls."""
from fractions import Fraction as Q
import hashlib
import json
from pathlib import Path

import h5py

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'artifacts'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
historical=OUT/'historical_pre_review_report.json'
draft=json.loads(historical.read_text())
for name,digest in draft['output_sha256'].items():
    if sha(OUT/name)!=digest:raise ValueError('saved output bytes changed before the reporting correction')
source=Path(draft['source_file'])
if sha(source)!=draft['source_hdf_sha256']:raise ValueError('canonical HDF changed')
with h5py.File(source,'r') as h:
    face_area=sum(Q(float(value)) for value in h['patch_areas_m2'][...].flat)
records=[json.loads(line) for line in (OUT/'conditioned_source_components.jsonl').read_text().splitlines()]
groups={}
for record in records:
    key=tuple(record[field] for field in ('original_interval_index','pool_index','current_patch_index','width_patch_index'))
    groups.setdefault(key,[]).append(record)
for group in groups.values():
    ordered=sorted(group,key=lambda item:item['source_window_local_start_s'])
    if ordered[0]['source_window_local_start_s']!=0 or ordered[-1]['source_window_local_stop_s']!=ordered[0]['original_parent_duration_s']:
        raise ValueError('saved disjoint windows do not span the original component')
    if any(left['source_window_local_stop_s']!=right['source_window_local_start_s'] for left,right in zip(ordered[:-1],ordered[1:])):
        raise ValueError('saved local windows overlap or leave a gap')
    for field in ('initial_coverage_m2','temperature_k','state_id','pool_name','patch_area_m2','original_start_global_s'):
        if any(item[field]!=ordered[0][field] for item in ordered):raise ValueError('retained component association changed')
if len(records)!=240 or len(groups)!=192:raise ValueError('fixture component count changed')

summary={}
for name,item in draft['quantity_partitions'].items():
    extensive=name=='released_number' or name.endswith('_j')
    counterpart=name if extensive else ('released_number' if name=='released_m2' else name.removesuffix('_m2'))
    physical=draft['quantity_partitions'][counterpart]
    divisor=Q(1) if extensive else face_area
    convert=lambda key:float(Q(physical[key])/divisor)
    summary[name]={
        'units':item['units'],
        'spatial_aggregation':'physical_surface_integral' if extensive else 'actual_face_area_weighted_mean',
        'temporal_aggregation':'cumulative_disjoint_source_windows',
        'canonical_value':convert('canonical_total'),
        'whole_scalar_api_value':convert('whole_scalar_api_total'),
        'source_gate_values':[float(Q(value)/divisor) for value in physical['disjoint_source_gate_totals']],
        'sum_disjoint_value':convert('sum_disjoint_total'),
        'partition_minus_canonical_signed':convert('partition_minus_canonical_signed'),
        'combined_estimated_absolute_allowance':convert('combined_estimated_absolute_allowance'),
        'max_component_fraction_of_estimated_allowance':item['max_component_fraction_of_estimated_allowance'],
        'aggregate_passed':physical['aggregate_passed'],
    }
    if extensive:
        # The peer found no problem in actual parent/J totals; preserve their
        # original represented values exactly, changing only field names.
        for old,new in [('canonical_total','canonical_value'),('whole_scalar_api_total','whole_scalar_api_value'),
                        ('sum_disjoint_total','sum_disjoint_value')]:
            if physical[old]!=summary[name][new]:raise ValueError('extensive totals changed')
corrected={**draft,'schema':'mhdlab-windowed-source-composition-control-v2',
           'quantity_partitions':summary,'actual_face_area_m2':float(face_area),
           'spatial_summary_rule':'Integrated parent and J values use actual patch area once. Areal summaries are corresponding physical extensive values divided by actual total face area, never unweighted sums of patch densities.',
           'reporting_revision':{
               'scope':'report-only correction from saved quantities and canonical actual areas; no scalar-window or source integration rerun',
               'superseded_draft_report':'historical_pre_review_report.json','superseded_draft_report_sha256':sha(historical),
               'superseded_draft_issue':'Unweighted sums of patch densities had been labeled as global density totals. Per-component checks, physical parent/J totals and response controls were correct.',
               'original_composition_script_sha256':draft['composition_script_sha256'],
               'historical_composition_script_sha256':sha(ROOT/'historical_composition_before_reporting_fix.py'),
               'revised_composition_reporting_script_sha256':sha(ROOT/'compose_windowed_source.py'),
               'reporting_projection_script_sha256':sha(Path(__file__)),
               'saved_component_cover_check':{'components':len(groups),'positive_windows':len(records),'no_gaps_or_overlaps':True,'retained_associations_unchanged':True},
               'rounding':'Face-area means divide saved represented extensive summaries by the exact rational sum of actual stored float patch areas and round once to float64; existing numerical allowances remain conditional estimates.'}}
(OUT/'report.json').write_text(json.dumps(corrected,indent=2,allow_nan=False)+'\n')
result={'status':'corrected_reporting_only','schema':corrected['schema'],'report_sha256':sha(OUT/'report.json'),
        'superseded_draft_report_sha256':sha(historical),'actual_face_area_m2':float(face_area),
        'source_number_total_unchanged':summary['released_number']['canonical_value'],
        'mean_cumulative_areal_release_m2':summary['released_m2']['canonical_value'],
        'no_scalar_evaluations':True}
(ROOT/'reporting_correction.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps(result,indent=2,allow_nan=False))
