"""Portable upstream source-window verification subset."""
