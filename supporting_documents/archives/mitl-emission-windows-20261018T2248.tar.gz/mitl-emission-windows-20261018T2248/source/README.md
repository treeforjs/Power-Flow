# Partial source-emission window verification subset

Named public files are byte-identical to the recorded commit. Four packaging
wrappers isolate import and dependency boundaries from unrelated solvers.

```sh
python -W error -m pytest tests/test_temkin_emission_window.py tests/test_temkin_source_window.py tests/test_temkin_emission_window_cli.py
python tools/inspect_temkin_emission_window.py --demo --output-dir /tmp/source-window --plot --require-represented-budget
```

The default source, pool, energies and geometry are manufactured. The numerical
quadrature envelopes are estimates with explicit rounding assumptions. A
represented budget performs no host transaction. Source-emission windows and
later photon-observation gates are separate operations. Read
`docs/temkin_emission_windows.md` before coupling these interfaces to a host.
