# Manufactured prescribed-power reference patch

This handoff contains five new public files and a patch over the complete checkout
at `e38b819c77ccf9439c82732987e4551c722fbd2d`. Apply the patch to that exact baseline before importing the module,
running the CLI or evaluating the tests. The source/ directory is a review subset,
not a standalone package. No package initializer or dependency closure is supplied.
The requirements wrapper copies the baseline requirements.txt byte-for-byte;
follow the complete checkout's setup instructions and retained package initializer.

The new reference is a stationary manufactured patch with a finite parent pool,
zero activation barrier, supplied constant areal heat capacity and an explicitly
bounded piecewise-constant nonnegative power schedule. Input energy, gross removal,
internal and continuum expected translation remain separate ledgers. This power
is supplied manufactured data, not inferred from recovered current, a circuit,
actual foil properties or a magnetic/heating solution.

Saved fresh tests, parser controls, trajectories, input-power ledger, independent
integrating-factor/translation oracle and refinement are preserved. Numerical
changes are qualified estimates, not certified errors or physical validation.
Nonzero-barrier kinetics require a fresh independently verified forced reference.
No old zero-power suite, producer, oracle, source history or owner code is replayed
by packaging. No portable environment, initializer workaround or standalone
execution is claimed.
