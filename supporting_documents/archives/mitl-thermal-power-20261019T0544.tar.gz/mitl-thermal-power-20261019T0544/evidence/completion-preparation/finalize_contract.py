"""Pin the root-approved metadata contract without importing or executing it."""
import argparse
import ast
import hashlib
import json
from pathlib import Path
import subprocess

WORK=Path(__file__).resolve().parents[1]
REPO=Path('/workspace/Power-Flow')
BASE='e38b819c77ccf9439c82732987e4551c722fbd2d'
PUBLIC={'mhdlab/thermal_power_reference.py','tests/test_thermal_power_reference.py',
    'tools/run_thermal_power_reference.py','configs/thermal_power_manufactured.json','docs/thermal_power_reference.md'}
APPROVED_RECORDS={
    'documentation_association':'1f8c0c988879d4dcb4cd4b8ae66723af80fb433a07e29731c5d023b9fcab7992',
    'visual_review':'8c56bde4cd72da718fc7d08ed386ef266850eaf69b0c72f5456cfc8a660ea280',
    'selection':'8ef9ecce5542316bd25d453572630cea4f8978b230d382b6342f00ff6aeb5de8',
    'oracle_completion':'13733416ec7bdaaee495a45d2547e411441d9df12ad0f307567cda5d4ae2f0f4',
    'oracle_review':'bc72c2c9dc1e6623c8970cd591089060aa9e79881a04942c0b958aad93771940',
    'tests_completion':'4a506b5eb479dccda982b259cac1e7b75cd6ea8f94378009bc2aabc6ae08aa98'}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def save(path,value):
    Path(path).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')


def assignment(tree,name):
    matches=[node.value for node in ast.walk(tree) if isinstance(node,ast.Assign)
        and any(isinstance(target,ast.Name) and target.id==name for target in node.targets)]
    assert len(matches)==1,name
    return ast.literal_eval(matches[0])


def git(*args):
    return subprocess.check_output(['git',*args],cwd=REPO).decode().strip()


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--approved-head',required=True)
    parser.add_argument('--helper-sha256',action='append',required=True)
    args=parser.parse_args()
    status_path=WORK.parent/'mitl-upstream-status.json'
    status_before=sha(status_path)
    assert git('rev-parse','HEAD')==args.approved_head
    assert git('branch','--show-current')=='research/flash-publication-foundation'
    assert git('status','--porcelain')==''
    assert set(git('diff','--name-only',BASE,args.approved_head).splitlines())==PUBLIC
    helpers={name:sha(WORK/name) for name in ['prepare_delivery.py','freeze_delivery.py','verify_delivery.py']}
    expected_helpers=dict(item.split('=',1) for item in args.helper_sha256)
    assert helpers==expected_helpers and len(args.helper_sha256)==3
    trees={name:ast.parse((WORK/name).read_text(),filename=name)
        for name in [*helpers,'complete_pass.py']}
    freezer=trees['freeze_delivery.py']
    roles=assignment(freezer,'REPORT_PATHS')
    assert len(roles)==14 and roles['oracle_review']=='oracle-review/completion.json'
    results=assignment(freezer,'results')
    assert results['new_core_tests_passed']==37 and results['saved_trajectories']==7
    assert results['old_test_suites_repeated'] is False
    assert results['nonzero_barrier_forced_reference_qualified'] is False
    assert not any(isinstance(node,ast.Raise) and isinstance(node.exc,ast.Call)
        and isinstance(node.exc.func,ast.Name) and node.exc.func.id=='RuntimeError'
        and node.exc.args and isinstance(node.exc.args[0],ast.Constant)
        and 'pending' in str(node.exc.args[0].value).lower() for node in ast.walk(freezer))
    public={name:sha(REPO/name) for name in sorted(PUBLIC)}
    records={role:load(WORK/name) for role,name in roles.items()}
    pins={role:sha(WORK/name) for role,name in roles.items()}
    assert all(pins[role]==digest for role,digest in APPROVED_RECORDS.items())
    assert records['oracle_completion']['all_checks_passed'] is True
    assert records['oracle_completion']['status']=='passed'
    assert records['documentation_association']['public_sha256']==public
    assert records['selection']['selected'] is True
    assert records['selection']['status']=='selected_coarse_signed_magnetic_gap_recovery'
    contract={
        'schema':'mitl-thermal-power-completion-contract-v1',
        'ready_for_root_execution':True,'approved_head':args.approved_head,
        'public_source_sha256':public,'metadata_helpers_sha256':helpers,
        'record_paths':roles,'record_sha256':pins,'result_values':results,'pending':[],
        'execution_limit':'Prepared and AST-checked only; root alone may execute after actual archive verification.'}
    save(WORK/'completion-preparation/contract.json',contract)
    notes={
        'schema':'mitl-thermal-power-completion-preparation-v1','status':'ready_root_execution_pending_archive',
        'approved_head':args.approved_head,'baseline_commit':BASE,
        'AST_parse_only':True,'completion_helper_imported_or_executed':False,
        'scientific_core_CLI_or_oracle_imported_or_executed':False,
        'tests_or_producers_or_oracles_repeated':False,'source_queries_performed':False,
        'status_or_lease_mutated':False,'actual_archive_required_at_eventual_execution':True,
        'prior_queue_priorities_2_through_7_preserved':True,
        'physical_surface_VUV_owner_FLASH_fulltext_gates_preserved':True,
        'completed_zero_power_and_current_evidence_preserved':True,
        'forced_nonzero_activation_branch_qualified':False,
        'next_selection':records['selection']['selected_task'],
        'metadata_validation':'Eventual root helper reuses pinned pure saved-record validator; it does not replay numerical work.'}
    save(WORK/'completion-preparation/notes.json',notes)
    assert sha(status_path)==status_before
    report={
        'schema':'mitl-thermal-power-completion-AST-readiness-v1','status':'passed',
        'approved_head':args.approved_head,'AST_parse_only':True,
        'completion_helper_imported_or_executed':False,'status_or_lease_mutated':False,
        'status_before_sha256':status_before,'status_after_sha256':sha(status_path),
        'scientific_core_CLI_or_oracle_imported_or_executed':False,
        'old_or_new_scientific_suites_repeated':False,'record_role_count':len(roles),
        'public_file_count':len(public),'public_source_sha256':public,
        'metadata_helpers_sha256':helpers,'record_sha256':pins,
        'artifact_sha256':{name:sha(WORK/name) for name in ['complete_pass.py',
            'completion-preparation/finalize_contract.py','completion-preparation/contract.json',
            'completion-preparation/notes.json']}}
    save(WORK/'completion-preparation/AST-readiness.json',report)
    print(json.dumps(report,indent=2))


if __name__=='__main__':
    main()
