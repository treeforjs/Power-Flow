"""Commit the frozen prescribed-power interface and reviewed guide."""
import hashlib
import json
from pathlib import Path
import subprocess

repo = Path('/workspace/Power-Flow')
work = Path(__file__).resolve().parent
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def run(*args):
    print(json.dumps(list(args)), flush=True)
    subprocess.run(args, cwd=repo, check=True)
assert subprocess.check_output(['git','rev-parse','HEAD'], cwd=repo, text=True).strip() == '03477367c802ee731d600179229cf2b22f4cc6a6'
assert not subprocess.check_output(['git','diff','--cached','--name-only'], cwd=repo, text=True)
assert sha(work/'documentation-association.json') == '1f8c0c988879d4dcb4cd4b8ae66723af80fb433a07e29731c5d023b9fcab7992'
association = json.loads((work/'documentation-association.json').read_text())
assert association['status'] == 'passed'
pins = {
    'tools/run_thermal_power_reference.py':'64cdfacefcf5397829f2620a316b7419b9d72e89b8a59fa8fbf6f4a35887245e',
    'configs/thermal_power_manufactured.json':'f7718849aa08f5ce2ed85836c0ab1747583eb01fee3ef932b5c73c64c4c305dc',
    'docs/thermal_power_reference.md':'bf6a0106c82d30c4e0a06b7ac670b5e9b7f0fb25f778d9afcca437e7881f243f',
}
for path,digest in pins.items():
    assert sha(repo/path) == digest
run('git','add','--',*pins)
run('git','diff','--cached','--check')
run('git','-c','user.name=Research Development','-c','user.email=research@local.invalid','commit','-m','Expose finite power schedules and independent verification evidence')
run('git','show','--format=fuller','--stat','HEAD')
run('git','status','--short')
