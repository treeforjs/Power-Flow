"""Bind the prescribed-power guide to frozen, independently checked results."""
import datetime
import hashlib
import json
from pathlib import Path

repo = Path('/workspace/Power-Flow')
work = Path(__file__).resolve().parent
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
pins = {
    'core/source-freeze.json':'0f40c9005c77697e74b778f9326629d7c006c898de39b4b0ca2cf3c256064327',
    'core-review/completion.json':'6410c23b56de1dca09ec3a551bfa6854cf39696c6af5207e2a2b3c5740700549',
    'tests/completion.json':'4a506b5eb479dccda982b259cac1e7b75cd6ea8f94378009bc2aabc6ae08aa98',
    'producer/parser_guard_checks.json':'d41958db49984c538a736a40802d297fb55b3fffd54ef08d0ef53fbe2b38835b',
    'producer/completion.json':'1f43c376b292faabcfce73695a5f197210edc84121bab61b7333bc2e70f8389e',
    'producer/reference-run/report.json':'e58e67ec896035a94ecc24e1bbe4dd43a0276c7729fddeb8d97b376f4f780300',
    'independent-verification/completion.json':'13733416ec7bdaaee495a45d2547e411441d9df12ad0f307567cda5d4ae2f0f4',
    'independent-verification/oracle-initial/report.json':'692f286b65d4d3c43b58b512b113432bdf8b84ba2b0670fb87deadea3965afb7',
    'oracle-review/completion.json':'bc72c2c9dc1e6623c8970cd591089060aa9e79881a04942c0b958aad93771940',
    'next-upstream-selection/selection.json':'8ef9ecce5542316bd25d453572630cea4f8978b230d382b6342f00ff6aeb5de8',
}
for name,digest in pins.items():
    assert sha(work/name) == digest, name
reference = json.loads((work/'independent-verification/oracle-initial/report.json').read_text())
assert reference['all_checks_passed'] is True
assert (reference['cases'],reference['saved_trajectories'],reference['saved_sample_rows_checked']) == (4,7,463)
assert (reference['CSV_JSON_scalar_cells_checked'],reference['area_once_checks'],reference['logical_time_stamp_checks']) == (7871,6482,463)
assert not reference['source_model_imports']
assert reference['positive_core_or_CLI_calls'] == reference['old_solver_or_suite_calls'] == 0
producer = json.loads((work/'producer/reference-run/report.json').read_text())
assert producer['case_count'] == 4 and producer['numerical_trajectory_count'] == 7 and producer['sample_count'] == 463
assert producer['parameter_status'] == 'manufactured'
assert producer['qualifications']['zero_activation_energy_only'] is True
paths = ['mhdlab/thermal_power_reference.py','tests/test_thermal_power_reference.py',
    'tools/run_thermal_power_reference.py','configs/thermal_power_manufactured.json','docs/thermal_power_reference.md']
public = {p:sha(repo/p) for p in paths}
assert public[paths[0]] == '741ab61b45cc0440b2f133732df387e34bd7630d6b6d5eeb48be7f6e471f1e00'
assert public[paths[1]] == 'f322a602e9d3005a2956ff375179fc687eadf49a580ed25c844b14d3ba5c4e90'
assert set(producer['code_sha256'].values()) >= {public[paths[0]],public[paths[2]]}
assert producer['config_sha256'] == public[paths[3]]
case = next(t for t in reference['trajectories'] if t['case_id']=='scheduled_power' and t['segment_steps']==[64,64,64])
endpoint = case['endpoint_reference']
assert round(endpoint['temperature_k']['float_projection'],6) == 896.565673
assert round(endpoint['total_wall_energy_debit_j_m2']['float_projection'],6) == 6.171716
guide = (repo/paths[-1]).read_text()
for text in ('**zero activation barrier**','37 new focused tests','Thirteen malformed','463 saved rows',
    '7,871 CSV/JSON','6,482 area projections','6.16 × 10⁻¹¹','9.66 × 10⁻¹²','7.44 × 10⁻¹²',
    '64 steps **per segment**','896.565673 K','not certified error bounds'):
    assert text in guide, text
visual = {'schema':'mitl-thermal-power-root-visual-review-v1',
    'reviewed':{p:sha(work/'producer/reference-run'/p) for p in ('trajectories.png','energy_channels.png')},
    'observations':['All four cases and their manufactured status are legible.',
        'Scheduled temperature remains continuous at both power jumps and changes direction across the on/off intervals.',
        'Gross input and wall debit remain separate from signed net thermal change; input is flat during the off interval.'],
    'limits':['Visual legibility only; independent reference supplies arithmetic and allocation checks.',
        'Zero-barrier manufactured input, without a temperature-dependent release or physical material claim.'],
    'numerical_execution_performed':False}
(work/'visual-review.json').write_text(json.dumps(visual,indent=2)+'\n')
report = {'schema':'mitl-thermal-power-documentation-association-v1','status':'passed',
    'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'script_sha256':sha(__file__),
    'public_sha256':public,'evidence_sha256':pins,'visual_review_sha256':sha(work/'visual-review.json'),
    'manufactured_example':{'case_id':'scheduled_power','steps_per_segment':[64,64,64],
        'source':'independent integrating-factor temperature and direct translation quadrature',
        'temperature_k':endpoint['temperature_k'],'input_energy_j_m2':endpoint['input_energy_j_m2'],
        'gross_wall_debit_j_m2':endpoint['total_wall_energy_debit_j_m2'],
        'signed_thermal_change_j_m2':endpoint['wall_thermal_change_j_m2']},
    'old_suites_or_producers_repeated':False,'core_CLI_or_oracle_called_here':False,
    'nonzero_barrier_qualified':False,'physical_parameters_or_host_acceptance_verified':False}
(work/'documentation-association.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':'passed','public_sha256':public,'documentation_association_sha256':sha(work/'documentation-association.json'),
    'visual_review_sha256':sha(work/'visual-review.json')},indent=2))
