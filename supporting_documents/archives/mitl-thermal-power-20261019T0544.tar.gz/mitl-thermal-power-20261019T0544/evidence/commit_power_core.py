"""Commit the independently checked manufactured power evolution and tests."""
import hashlib
import json
from pathlib import Path
import subprocess

repo = Path('/workspace/Power-Flow')
work = Path(__file__).resolve().parent
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def run(*args):
    print(json.dumps(list(args)),flush=True)
    subprocess.run(args,cwd=repo,check=True)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip() == 'e38b819c77ccf9439c82732987e4551c722fbd2d'
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=repo,text=True)
pins = {
    'mhdlab/thermal_power_reference.py':'741ab61b45cc0440b2f133732df387e34bd7630d6b6d5eeb48be7f6e471f1e00',
    'tests/test_thermal_power_reference.py':'f322a602e9d3005a2956ff375179fc687eadf49a580ed25c844b14d3ba5c4e90'}
for path,digest in pins.items():
    assert sha(repo/path) == digest
oracle = work/'independent-verification/oracle-initial/report.json'
assert sha(oracle) == '692f286b65d4d3c43b58b512b113432bdf8b84ba2b0670fb87deadea3965afb7'
assert json.loads(oracle.read_text())['all_checks_passed'] is True
assert sha(work/'tests/completion.json') == '4a506b5eb479dccda982b259cac1e7b75cd6ea8f94378009bc2aabc6ae08aa98'
run('git','add','--',*pins)
run('git','diff','--cached','--check')
run('git','-c','user.name=Research Development','-c','user.email=research@local.invalid','commit','-m','Add manufactured prescribed-power thermal reference and input ledger')
run('git','show','--format=fuller','--stat','HEAD')
