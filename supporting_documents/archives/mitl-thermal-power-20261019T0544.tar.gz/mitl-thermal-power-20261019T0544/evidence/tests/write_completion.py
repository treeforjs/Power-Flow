"""Freeze one completed new prescribed-power test run without replaying it."""
import datetime
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parent
WORK=ROOT.parent
REPO=Path('/workspace/Power-Flow')
CORE='mhdlab/thermal_power_reference.py'
CORE_SHA='741ab61b45cc0440b2f133732df387e34bd7630d6b6d5eeb48be7f6e471f1e00'
TEST='tests/test_thermal_power_reference.py'
DATA='mhdlab/thermal_feedback_reference.py'
DATA_SHA='3fbded5bc801fac4e847195ecd5ad369142d3ab56e70848c4501ea1425d61cf8'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

assert not (ROOT/'completion.json').exists()
assert sha(REPO/CORE)==CORE_SHA and sha(REPO/DATA)==DATA_SHA
commands=[json.loads(line) for line in (WORK/'commands.jsonl').read_text().splitlines()]
matches=[entry for entry in commands if Path(entry['log']).name=='thermal-power-core-initial.log']
assert len(matches)==1
command=matches[0]
assert command['exit_code']==0 and sha(Path(command['log']))==command['log_sha256']
assert command['command'][4:7]==['pytest','-q',TEST]
tree=ET.parse(ROOT/'core-initial.xml').getroot()
cases=tree.findall('.//testcase')
assert len(cases)==37 and len({(case.attrib['classname'],case.attrib['name']) for case in cases})==37
assert not tree.findall('.//failure') and not tree.findall('.//error') and not tree.findall('.//skipped')
public={CORE:CORE_SHA,TEST:sha(REPO/TEST)}
result={'schema':'mitl-thermal-power-core-tests-v1','status':'passed','all_checks_passed':True,
    'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'public_source_sha256':public,
    'unchanged_baseline_parameter_data_sha256':{DATA:DATA_SHA},
    'required_complete_baseline_commit':'e38b819c77ccf9439c82732987e4551c722fbd2d',
    'artifact_sha256':{'tests/core-initial.xml':sha(ROOT/'core-initial.xml'),
        'tests/write_completion.py':sha(Path(__file__)),'thermal-power-core-initial.log':command['log_sha256']},
    'targeted_test_runs':1,'new_core_tests_passed':37,'new_core_tests_failed':0,
    'new_core_tests_errors':0,'new_core_tests_skipped':0,'warnings_as_errors':True,
    'manufactured_trajectory_families':4,'area_rescaling_trajectory_controls':1,
    'instantaneous_exact_gross_balance_controls':1,
    'old_suites_repeated':False,'old_producers_repeated':False,
    'old_numerical_evolution_called':False,'portable_test_execution_claimed':False,
    'physical_parameters_adopted':0,'actual_FLASH_run':False,'host_budget_accepted':False,
    'command':command,'test_cases':[case.attrib['name'] for case in cases],
    'scope':['The four approved manufactured families cover empty constant heating, nonempty constant-power cooling and heating, and a complete three-segment on/off/change-power schedule.',
        'An independently derived40-term convergent series of the scaled integrating-factor kernel checks forced temperature, while exponential inventory is checked separately. No core or separate oracle reference helper is used.',
        'Exact prescribed input is reconstructed from declared segment boundaries and logical segment-step fractions rather than rounded stored timestamps. All boundary states are unique and carry the just-completed segment index; the next sample carries the new segment.',
        'The exact-SI instantaneous balanced state retains positive input and translation/gross withdrawal with zero net temperature derivative. It is not evolved as a constant-temperature trajectory.',
        'Removal, internal and translation channels, signed energy residuals and one area conversion are checked separately. A doubled-area control leaves areal dynamics unchanged.',
        'New nonzero-barrier, finite schedule, canonical-time, negative-exact-Real, boolean, nonfinite, stage-domain and positive-gross-transfer representation guards reject explicitly.'],
    'limits':['All inputs and trajectories are manufactured local zero-barrier references. No physical material, water, surface inventory, collision/radiative state data or source-history/host/MHD coupling is supplied.',
        'The independently derived series and declared finite comparison tolerances are unit-test evidence, not interval-certified error bounds or physical uncertainty.',
        'The independently owned saved seven-trajectory CLI batch, quadrature/translation oracle and temporal refinement remain separate evidence; this record does not claim their completion.',
        'Existing immutable parameter records are reused as data only. No previous zero-power suite, numerical producer, oracle, source evolution, Quark runner, gap solver or actual FLASH run is replayed.']}
target=ROOT/'completion.json';target.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps({'completion':str(target),'sha256':sha(target),'public_source_sha256':public,
    'all_checks_passed':True,'new_core_tests_passed':37},indent=2))
