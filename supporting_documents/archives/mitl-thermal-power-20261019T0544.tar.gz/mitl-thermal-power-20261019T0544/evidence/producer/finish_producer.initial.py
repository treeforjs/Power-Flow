"""Read saved artifacts and record production completion; never evolve a model."""
import csv,datetime,hashlib,json,math,pathlib
from fractions import Fraction
WORK=pathlib.Path(__file__).resolve().parent
PASS=WORK.parent
ROOT=pathlib.Path('/workspace/Power-Flow')
RUN=WORK/'reference-run'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
freeze=load(WORK/'freeze.json');report=load(RUN/'report.json');parser=load(WORK/'parser_guard_checks.json')
assert freeze['prior_positive_cli_batches']==0
for p,digest in freeze['public_source_sha256'].items():assert sha(ROOT/p)==digest,p
assert report['code_sha256']=={p:d for p,d in freeze['public_source_sha256'].items() if p.endswith('.py')}
assert report['config_sha256']==freeze['public_source_sha256']['configs/thermal_power_manufactured.json']
assert report['artifact_path_base']=='directory containing report.json'
for p,digest in report['artifact_sha256'].items():assert sha(RUN/p)==digest,p
assert report['case_count']==4 and report['numerical_trajectory_count']==7 and report['sample_count']==463
commands=[json.loads(line) for line in (PASS/'commands.jsonl').read_text().splitlines()]
batches=[r for r in commands if 'tools/run_thermal_power_reference.py' in r['command']]
assert len(batches)==1 and batches[0]['exit_code']==0
assert batches[0]['command']==freeze['production_command']
config=load(RUN/'input_config.json');cases={c['case_id']:c for c in config['cases']}
row_count=boundary_count=0;trajectories=[]
for tr in report['trajectories']:
 rows=list(csv.DictReader((RUN/tr['csv_file']).open()))
 history=load(RUN/tr['history_file'])
 assert len(rows)==tr['sample_count']==len(history['samples'])==sum(tr['segment_steps'])+1
 assert sha(RUN/tr['csv_file'])==tr['csv_sha256'] and sha(RUN/tr['history_file'])==tr['history_sha256']
 case=cases[tr['case_id']]; area=Fraction.from_float(case['problem']['patch_area_m2'])
 expected_indices=[(0,0)]+[(i,j) for i,n in enumerate(tr['segment_steps']) for j in range(1,n+1)]
 for row,saved,(i,j) in zip(rows,history['samples'],expected_indices):
  assert int(row['segment_index'])==saved['segment_index']==i
  assert int(row['segment_step'])==saved['segment_step']==j
  for key,value in saved.items():
   if key=='extensive':
    for ek,ev in value.items():assert float(row[ek])==ev
   else:assert float(row[key])==value
  segment=case['segments'][i]
  a,b=map(Fraction.from_float,(float(segment['start_s']),float(segment['stop_s'])))
  logical_time=a+(b-a)*j/tr['segment_steps'][i]
  assert float(row['time_s'])==float(logical_time)
  input_energy=sum((Fraction.from_float(float(s['power_w_m2']))*(Fraction.from_float(float(s['stop_s']))-Fraction.from_float(float(s['start_s']))) for s in case['segments'][:i]),Fraction())
  input_energy+=Fraction.from_float(float(segment['power_w_m2']))*(logical_time-a)
  assert float(row['prescribed_input_energy_j_m2'])==float(input_energy)
  for key,value in saved.items():
   if key.endswith('_j_m2'):
    assert saved['extensive'][key[:-3]]==float(Fraction.from_float(value)*area)
  if j==tr['segment_steps'][i]:boundary_count+=1
 final=tr['final_sample']
 trajectories.append({'case_id':tr['case_id'],'segment_steps':tr['segment_steps'],'sample_count':len(rows),
                      'final_temperature_k':final['temperature_k'],'final_input_energy_j_m2':final['input_energy_j_m2'],
                      'final_total_wall_energy_debit_j_m2':final['total_wall_energy_debit_j_m2'],
                      'final_wall_thermal_change_j_m2':final['wall_thermal_change_j_m2'],
                      'max_absolute_residuals':tr['max_absolute_residuals']})
 row_count+=len(rows)
assert row_count==463 and boundary_count==15
refinement=list(csv.DictReader((RUN/'temporal_refinement.csv').open()))
assert len(refinement)==len(report['temporal_refinement'])==30
orders=[r['observed_self_order'] for r in report['temporal_refinement'] if r['observed_self_order'] is not None]
assert orders and all(math.isfinite(x) for x in orders)
artifacts={str(p.relative_to(PASS)):sha(p) for p in RUN.iterdir() if p.is_file()}
for name in ('freeze.json','parser_guard_checks.json','check_parser_guards.py','freeze_producer.py','finish_producer.py'):
 artifacts[str((WORK/name).relative_to(PASS))]=sha(WORK/name)
for p in (WORK/'source-versions').iterdir():artifacts[str(p.relative_to(PASS))]=sha(p)
completion={'schema':'mhdlab-thermal-power-producer-completion-v1','status':'passed_production_and_parser_checks',
 'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'report_path':'producer/reference-run/report.json',
 'report_sha256':sha(RUN/'report.json'),'producer_cli_sha256':sha(ROOT/'tools/run_thermal_power_reference.py'),
 'config_sha256':sha(ROOT/'configs/thermal_power_manufactured.json'),'reviewed_source_sha256':freeze['public_source_sha256'],
 'parser_guard_report':'producer/parser_guard_checks.json','parser_guard_report_sha256':sha(WORK/'parser_guard_checks.json'),
 'parser_checks':{'rejected_configurations':13,'accepted_plans_without_evolution':1,'raw_decimal_schedule_checks_before_projection':True},
 'core_gate':freeze['core_test_gate'],'core_unique_new_checks':37,'positive_batch_count':1,'batch':batches[0],
 'case_count':4,'numerical_trajectory_count':7,'saved_sample_count':463,'temporal_refinement_rows':30,
 'saved_readback':{'all_artifact_hashes_verified':True,'all_463_csv_samples_match_history_json':True,
                  'logical_segment_step_stamps_checked':True,'prescribed_input_checked_on_exact_logical_grid':True,
                  'every_energy_extensive_copy_applies_area_once':True,'shared_completed_segment_boundaries':boundary_count},
 'source_versions':{'corrections_or_retries':0,'original_frozen_source_snapshots_retained':True,'parser_and_production_cli_same_bytes':True},
 'trajectories':trajectories,'resolved_finite_grid_self_order_min':min(orders),'resolved_finite_grid_self_order_max':max(orders),
 'plot_inspection':{'energy_channels.png':'read at native saved image; labels legible, gross input/debit and signed thermal channel remain separate',
                    'trajectories.png':'read at native saved image; all four explicitly manufactured cases shown'},
 'artifact_sha256':artifacts,'artifact_path_base':'pass directory containing producer/',
 'open_substantive_findings':[],'old_suites_or_source_evolution_repeated':False,'old_feedback_evolution_called':False,
 'independent_oracle_result_included_here':False,
 'limits':['Manufactured zero-activation-energy stationary single-patch prescribed-power numerical reference only.',
           'Finite-grid changes are descriptive; independent saved-only reference checks remain separate.',
           'No physical-water or material parameters, source history, conduction, phase change, actual MHD or host coupling inferred.']}
(WORK/'completion.json').write_text(json.dumps(completion,indent=2,allow_nan=False)+'\n')
print(json.dumps({'status':completion['status'],'completion_sha256':sha(WORK/'completion.json'),'report_sha256':completion['report_sha256'],'positive_batch_count':1,'trajectories':7,'samples':463,'refinement_rows':30,'resolved_self_order_range':[min(orders),max(orders)]},indent=2))
