"""Freeze bytes and prerequisite evidence before the sole reference batch."""
import datetime,hashlib,json,pathlib,shutil
WORK=pathlib.Path(__file__).resolve().parent
PASS=WORK.parent
ROOT=pathlib.Path('/workspace/Power-Flow')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
expected={'tools/run_thermal_power_reference.py':'64cdfacefcf5397829f2620a316b7419b9d72e89b8a59fa8fbf6f4a35887245e','configs/thermal_power_manufactured.json':'f7718849aa08f5ce2ed85836c0ab1747583eb01fee3ef932b5c73c64c4c305dc','mhdlab/thermal_power_reference.py':'741ab61b45cc0440b2f133732df387e34bd7630d6b6d5eeb48be7f6e471f1e00'}
for p,d in expected.items():assert sha(ROOT/p)==d,p
parser=json.loads((WORK/'parser_guard_checks.json').read_text())
assert parser['status']=='passed' and parser['rejected_configurations']==13
assert parser['cli_sha256']==expected['tools/run_thermal_power_reference.py']
assert parser['config_sha256']==expected['configs/thermal_power_manufactured.json']
commands=[json.loads(line) for line in (PASS/'commands.jsonl').read_text().splitlines()]
gates=[r for r in commands if any('tests/test_thermal_power_reference.py'==s for s in r['command'])]
assert len(gates)==1 and gates[0]['exit_code']==0
assert gates[0]['log_sha256']=='153df6346e5ac4c4d8cc7e7be3bae5eb361c16a397910dad56486a9f1ca8062e'
assert not any('tools/run_thermal_power_reference.py' in r['command'] for r in commands)
assert not (WORK/'reference-run').exists()
versions=WORK/'source-versions';versions.mkdir()
for p in (*expected,'mhdlab/thermal_feedback_reference.py'):
 shutil.copyfile(ROOT/p,versions/pathlib.Path(p).name)
report={'schema':'mhdlab-thermal-power-producer-freeze-v1','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'frozen_before_first_positive_batch','public_source_sha256':{p:sha(ROOT/p) for p in (*expected,'mhdlab/thermal_feedback_reference.py')},'saved_source_sha256':{str(p.relative_to(WORK)):sha(p) for p in versions.iterdir()},'parser_checks_file':'parser_guard_checks.json','parser_checks_sha256':sha(WORK/'parser_guard_checks.json'),'parser_check_count':14,'core_test_gate':gates[0],'core_unique_new_checks':37,'static_review_gate':'author reported completed read-only review with no substantive finding against core741ab61b','prior_positive_cli_batches':0,'planned_case_count':4,'planned_numerical_trajectory_count':7,'planned_sample_count':463,'old_evolution_or_producer_calls':False,'production_command':['.venv/bin/python','-W','error','tools/run_thermal_power_reference.py','--config','configs/thermal_power_manufactured.json','--output-dir',str(WORK/'reference-run'),'--plot']}
(WORK/'freeze.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps({'freeze':str(WORK/'freeze.json'),'sha256':sha(WORK/'freeze.json'),'status':report['status']},indent=2))
