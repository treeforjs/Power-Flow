"""Prepare a five-file thermal-power patch over an exact complete checkout."""
import argparse
import ast
from decimal import Decimal
import hashlib
import json
import math
from pathlib import Path
import re
import shutil
import subprocess

WORK = Path(__file__).resolve().parent
REPO = Path('/workspace/Power-Flow')
BASE = 'e38b819c77ccf9439c82732987e4551c722fbd2d'
HEAD = 'b50d65198bfe53b46716dd04b6a434bcd9d0d986'
OUT = Path('/workspace/handoffs/mitl-thermal-power-20261019T0544')
PUBLIC = ('mhdlab/thermal_power_reference.py', 'tests/test_thermal_power_reference.py',
    'tools/run_thermal_power_reference.py', 'configs/thermal_power_manufactured.json',
    'docs/thermal_power_reference.md')
WRAPPERS = ('README.md', 'requirements.txt')
BASELINE_CONTEXT = ('requirements.txt', 'pyproject.toml', 'mhdlab/__init__.py', 'mhdlab/thermal_feedback_reference.py')


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024*1024), b''):
            digest.update(block)
    return digest.hexdigest()


def object_pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('duplicate JSON key')
        result[key] = value
    return result


def finite_float(value):
    result = float(value)
    if not math.isfinite(result):
        raise ValueError('nonfinite JSON number')
    if result == 0 and Decimal(value) != 0:
        raise ValueError('nonzero JSON number underflows its representation')
    return result


def loads(data):
    return json.loads(data, object_pairs_hook=object_pairs, parse_float=finite_float,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def load(path):
    return loads(Path(path).read_text())


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False)+'\n')


def baseline_bytes(name):
    return subprocess.check_output(['git', 'show', BASE+':'+name], cwd=REPO)


def clean_head(expected):
    assert HEAD is not None and re.fullmatch('[0-9a-f]{40}', expected) and expected == HEAD
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == expected
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=REPO, text=True).strip()
    subprocess.run(['git', 'merge-base', '--is-ancestor', BASE, expected], cwd=REPO, check=True)
    changed = subprocess.check_output(['git', 'diff', '--name-only', BASE, expected], cwd=REPO, text=True).splitlines()
    assert set(changed) == set(PUBLIC) and len(changed) == len(PUBLIC)
    return expected


def dependency_context():
    pins = {}
    for name in BASELINE_CONTEXT:
        content = baseline_bytes(name)
        digest = hashlib.sha256(content).hexdigest()
        assert sha(REPO/name) == digest
        pins[name] = digest
    imports = {}
    for name in PUBLIC:
        if not name.endswith('.py'):
            continue
        tree = ast.parse((REPO/name).read_text())
        imports[name] = sorted({node.module or '' for node in ast.walk(tree) if isinstance(node, ast.ImportFrom)}
            | {alias.name for node in ast.walk(tree) if isinstance(node, ast.Import) for alias in node.names})
    return {'required_complete_baseline_checkout': True, 'baseline_commit': BASE,
        'standalone_source_subset': False, 'empty_initializer_added': False,
        'unchanged_context_sha256': pins, 'declared_imports': imports,
        'requirements_wrapper_origin': 'Exact bytes of baseline requirements.txt; complete checkout setup remains required.'}


def input_contract():
    name = 'configs/thermal_power_manufactured.json'
    config = load(REPO/name)
    assert config['schema'] == 'mhdlab-thermal-power-manufactured-config-v1'
    assert config['parameter_status'] == 'manufactured'
    assert config['provenance'].strip() and config['scope'].strip() and config['schedule_time_convention'].strip()
    assert len(config['cases']) == 4
    case_ids = [case['case_id'] for case in config['cases']]
    assert len(case_ids) == len(set(case_ids)) and config['refinement_case_id'] == 'scheduled_power'
    assert config['refinement_case_id'] in case_ids
    trajectories = samples = 0
    for case in config['cases']:
        assert case['purpose'].strip() and type(case['duration_s']) in {int, float} and case['duration_s'] > 0
        segments = case['segments']
        assert segments and segments[0]['start_s'] == 0 and segments[-1]['stop_s'] == case['duration_s']
        assert all(a['stop_s'] == b['start_s'] for a, b in zip(segments, segments[1:]))
        for segment in segments:
            assert type(segment['power_w_m2']) in {int, float} and segment['power_w_m2'] >= 0
            assert segment['stop_s'] > segment['start_s'] and segment['power_provenance'].strip()
        problem = case['problem']
        assert problem['parameter_status'] == 'manufactured' and problem['parameter_provenance'].strip()
        assert problem['energy_reference'].strip()
        reservoir = problem['reservoir']
        assert type(reservoir['activation_energy_ev']) in {int, float} and reservoir['activation_energy_ev'] == 0
        assert reservoir['reference_coverage_m2'] > 0 and reservoir['reference_coverage_m2'] != problem['initial_coverage_m2']
        assert reservoir['kinetic_provenance'].strip() and reservoir['energy_provenance'].strip()
        for grid in case['step_grids']:
            assert len(grid) == len(segments) and all(type(step) is int and step > 0 for step in grid)
            trajectories += 1
            samples += sum(grid)+1
    assert trajectories == 7 and samples == 463
    return {'config_path': name, 'config_sha256': sha(REPO/name), 'configuration': config,
        'case_count': 4, 'trajectory_count': 7, 'sample_count': 463,
        'refinement_case_id': config['refinement_case_id'], 'parameter_status': 'manufactured',
        'zero_activation_barrier_only': True, 'physical_parameters_adopted': False,
        'power_inferred_from_current_or_material': False, 'host_or_production_feedback_installed': False,
        'raw_decimal_schedule_checks': 'Frozen CLI parser evidence binds raw decimal adjacency and support before binary64 projection.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--expected-head', required=True)
    args = parser.parse_args()
    head = clean_head(args.expected_head)
    for name in PUBLIC:
        assert (REPO/name).is_file() and not (REPO/name).is_symlink()
    context = dependency_context()
    contract = input_contract()
    payload = WORK/'delivery-preparation/payload'
    assert not payload.exists() and not OUT.exists() and not OUT.with_suffix('.tar.gz').exists()
    source = payload/'source'
    source.mkdir(parents=True)
    for name in PUBLIC:
        target = source/name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(REPO/name, target)
    (source/'requirements.txt').write_bytes(baseline_bytes('requirements.txt'))
    (source/'README.md').write_text(f'''# Manufactured prescribed-power reference patch

This handoff contains five new public files and a patch over the complete checkout
at `{BASE}`. Apply the patch to that exact baseline before importing the module,
running the CLI or evaluating the tests. The source/ directory is a review subset,
not a standalone package. No package initializer or dependency closure is supplied.
The requirements wrapper copies the baseline requirements.txt byte-for-byte;
follow the complete checkout's setup instructions and retained package initializer.

The new reference is a stationary manufactured patch with a finite parent pool,
zero activation barrier, supplied constant areal heat capacity and an explicitly
bounded piecewise-constant nonnegative power schedule. Input energy, gross removal,
internal and continuum expected translation remain separate ledgers. This power
is supplied manufactured data, not inferred from recovered current, a circuit,
actual foil properties or a magnetic/heating solution.

Saved fresh tests, parser controls, trajectories, input-power ledger, independent
integrating-factor/translation oracle and refinement are preserved. Numerical
changes are qualified estimates, not certified errors or physical validation.
Nonzero-barrier kinetics require a fresh independently verified forced reference.
No old zero-power suite, producer, oracle, source history or owner code is replayed
by packaging. No portable environment, initializer workaround or standalone
execution is claimed.
''')
    save(payload/'source_file_list.json', {'byte_identical_public_files': list(PUBLIC), 'packaging_wrappers': list(WRAPPERS)})
    (payload/'source-files.sha256').write_text(''.join(f'{sha(source/name)}  {name}\n' for name in PUBLIC))
    (payload/'wrapper-files.sha256').write_text(''.join(f'{sha(source/name)}  {name}\n' for name in WRAPPERS))
    save(payload/'dependency_context.json', context)
    save(payload/'preparation.json', {'source_commit': head, 'base_commit': BASE,
        'input_contract': contract, 'dependency_context': context,
        'portable_execution_performed': False, 'physical_truth_validated': False,
        'public_source_sha256': {name: sha(REPO/name) for name in PUBLIC}})
    print(json.dumps({'payload': str(payload), 'source_commit': head, 'public_files': len(PUBLIC),
        'packaging_wrappers': len(WRAPPERS), 'complete_baseline_checkout_required': True}, indent=2))


if __name__ == '__main__':
    main()
