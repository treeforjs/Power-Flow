"""Freeze a read-only mathematical review of the new independent oracle."""
import datetime as dt
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ORACLE = ROOT.parent / 'independent-verification'
PINS = {
    'before_run_freeze.json': 'b07ee19b0bf2ad70d66c8a9cef85dffe36d514a53937613f05da16a648d31927',
    'decimal_power_reference.py': '94a8bfef9530034c4e95346bfcd1cbaa0c285f63a406a107b9c940780502d7f2',
    'verify_saved_power.py': '91d478ea21fb5c2af2ad7ee67b268ab64e5ca87c271405000bc0a41fe0bcb5c6',
    'oracle_plan.json': '5e6bbd89c5b780521f2ef44d481a1b9417437fb6fa2f220d20c19fbe07d6ae59',
    'oracle-initial/report.json': '692f286b65d4d3c43b58b512b113432bdf8b84ba2b0670fb87deadea3965afb7',
    'oracle-initial/reference_samples.json': 'ca02d4baf42341d653fa467fbc371e6252e3b0877fb229d96dc0e67ecb780962'
}

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

if (ROOT / 'completion.json').exists():
    raise RuntimeError('Refuse repeated oracle-review freeze')
status = json.loads(Path('/workspace/research_work/mitl-upstream-status.json').read_text())
assert status['active_lease_owner'] == 'mitl-upstream-20261019T0544'
assert dt.datetime.fromisoformat(status['active_editing_lease_until_utc']) > dt.datetime.now(dt.timezone.utc)
assert all(sha(ORACLE / name) == digest for name, digest in PINS.items())
freeze = json.loads((ORACLE / 'before_run_freeze.json').read_text())
plan = json.loads((ORACLE / 'oracle_plan.json').read_text())
owner_report = json.loads((ORACLE / 'oracle-initial/report.json').read_text())
assert owner_report['schema'] == 'mitl-independent-thermal-power-oracle-v1'
assert owner_report['numeric_method'] == plan['numeric_method']
assert owner_report['qualification'] == plan['qualification']
assert owner_report['source_model_imports'] == []
assert owner_report['positive_core_or_CLI_calls'] == 0
assert owner_report['old_solver_or_suite_calls'] == 0
assert freeze['independent_oracle_numerical_run_count_before_freeze'] == 0
for name in ('decimal_power_reference.py', 'verify_saved_power.py', 'oracle_plan.json'):
    assert freeze['independent_code_and_plan_sha256'][name] == PINS[name]
checks = [
    ('integrating_factor_shift_and_sign',
     'For C*Tdot=P-nu*N*(D+I+2*kB*T), shifting T by A=(D+I)/(2*kB) gives a positive damping coefficient. B(t)=2*kB*M(t)/C leads to the implemented exp(B(s)-B(t)) kernel, whose exponent is nonpositive for s<=t.'),
    ('stable_temperature_form',
     'T0+(T0+A)*expm1(-B) is algebraically (T0+A)*exp(-B)-A. This avoids a growing integrating factor and retains a small cooling change through expm1.'),
    ('zero_barrier_inventory',
     'N=N0*exp(-nu*t) and M=-N0*expm1(-nu*t) match exactly zero activation barrier; nonzero barrier rejects. Empty inventory uses the analytic prescribed-input temperature only.'),
    ('logical_time_and_power_jumps',
     'The verifier reconstructs logical times as exact represented-Fractions from segment index and local step count. Reference translation intervals include the union of all observation times and all power boundaries. Rounded time_s is checked separately.'),
    ('finite_input_integral',
     'Input is the finite sum of segment power times clipped elapsed segment length. The verifier independently forms that integral with Fractions and compares its nearest-float projection to every saved prescribed-input value.'),
    ('independent_positive_translation',
     'Translation accumulates direct positive quadrature of 2*kB*T_reference*nu*N_reference over logical intervals. It is not derived from thermal-energy subtraction. The energy residual is a separate consistency check.'),
    ('independence_of_numerical_core',
     'Only fresh local oracle code and standard-library modules are imported. Saved JSON/CSV are read; no core, old solver, test, producer, subprocess or runtime evolution call appears.'),
    ('precision_and_quadrature_claims',
     '80/120 are working Decimal precisions and 16/32 are quadrature orders. Binary cosine seeds are Decimal Newton-refined. Changes are numerical estimates, not interval certificates or physical uncertainty; the plan and report state that limit.'),
    ('error_scales_and_near_zero_thermal_budget',
     'Temperature uses the maximum resolved reference excursion over the case, and thermal change uses C times that excursion. Gross input/debit scales remain separate; structurally zero budgets require exactly zero error.'),
    ('finite_self_order',
     'Reported orders use three successive saved endpoint values with sign/decrease checks. No order is fabricated from a finite-reference error ratio, and unresolved channels retain an explicit status.'),
    ('reported_artifact_association',
     'The completed report matches the pre-run frozen method and qualification text; report/reference-sample hashes are bound here without re-evaluation.')
]
notes = '''# Independent prescribed-power oracle mathematical review

The fresh Decimal reference, saved-output verifier and pre-run plan were read
in full at their frozen hashes. No substantive mathematical or claims issue was
identified, and no code changes were requested. Clearance was sent before the
owner started its planned independent pass. The completed report is bound by
hash as an output association; this review does not reproduce its numerics.

For zero barrier, N=N0*exp(-nu*t), M=N0-N and Gamma=nu*N. The declared thermal
equation is C*Tdot=P-Gamma*(D+I+2*kB*T). Define A=(D+I)/(2*kB) and
B(t)=2*kB*M(t)/C. Then the shifted integrating-factor solution is

    T(t)=(T0+A)*exp(-B(t))-A
         +(1/C)*integral_0^t P(s)*exp(B(s)-B(t)) ds.

The implemented kernel has the correct sign and is bounded by one for s<=t.
Its expm1 cooling form is algebraically equivalent and avoids a growing
integrating factor. The power integral is split at every jump. Logical times
come from exact represented-Fraction segment coordinates and local step counts;
the rounded display stamp does not redefine support. A separate Fraction sum
checks every saved prescribed-input projection.

Translation is independently integrated as the positive quantity
2*kB*T_reference*Gamma. It is accumulated over the union of observation and
power-boundary intervals, rather than recovered by subtracting a tested wall
energy ledger. Thermal plus binding plus internal plus translation minus
external input is then an independent consistency residual.

The report keeps each emitted/gross channel scale and the maximum resolved
temperature excursion distinct. Working precision/order changes are numerical
estimates; neither the plan nor report claims an interval error certificate,
physical noise scale or extra significant physical digits. Orders come from
three successive saved endpoint values, with unresolved cases represented
explicitly. The reported finite-grid results do not certify all mathematical
inputs or a continuum global error bound.

No oracle, scientific core, producer, test or numerical model was executed by
this review. No scientific module was imported. The report's passing status and
counts are observed declarations bound to its hash, not independently
recomputed results. This review covers only the manufactured zero-barrier
single-patch prescribed-power model and does not qualify physical water,
foil materials, current-to-heating closure, state chemistry or owner coupling.
'''
(ROOT / 'review.md').write_text(notes)
observed_fields = ('schema', 'status', 'all_checks_passed', 'cases', 'saved_trajectories',
                   'saved_sample_rows_checked', 'distinct_reference_samples',
                   'CSV_JSON_scalar_cells_checked', 'area_once_checks', 'logical_time_stamp_checks')
report = {
    'schema': 'mitl-thermal-power-static-oracle-review-v1',
    'status': 'review_complete_no_substantive_issue_identified',
    'completed_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
    'reviewed_artifact_sha256': PINS,
    'oracle_root': str(ORACLE),
    'pre_run_code_and_plan_freeze_bound': True,
    'completed_owner_report_bound_without_numerical_replay': True,
    'owner_report_observed_declarations': {key: owner_report[key] for key in observed_fields},
    'owner_report_numerics_recomputed_by_reviewer': False,
    'checks': [{'area': name, 'static_review_complete': True, 'finding': finding} for name, finding in checks],
    'findings': [], 'source_changes_requested': False,
    'numerical_models_or_tests_executed': False,
    'oracle_core_or_producer_executed': False, 'scientific_module_imported': False,
    'old_audit_or_network_repeated': False, 'public_or_oracle_source_edits_by_reviewer': False,
    'physical_parameters_validated': False, 'host_budget_accepted': False,
    'limits': ['Read-only mathematical, interface and claims inspection only.',
               'Completed report is associated by hash; no numerical result or convergence estimate was reproduced.',
               'Working precision/order differences are estimates rather than interval or physical error certificates.',
               'Manufactured zero-barrier prescribed-power model only; no water/foil/state-chemistry qualification.'],
    'artifact_sha256': {p.name: sha(p) for p in sorted(ROOT.iterdir()) if p.is_file()}
}
(ROOT / 'completion.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'completion': str(ROOT / 'completion.json'), 'completion_sha256': sha(ROOT / 'completion.json'),
                  'reviewed_owner_report_sha256': PINS['oracle-initial/report.json'],
                  'status': report['status'], 'numerical_models_or_tests_executed': False}, indent=2))
