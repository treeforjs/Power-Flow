# Independent prescribed-power oracle mathematical review

The fresh Decimal reference, saved-output verifier and pre-run plan were read
in full at their frozen hashes. No substantive mathematical or claims issue was
identified, and no code changes were requested. Clearance was sent before the
owner started its planned independent pass. The completed report is bound by
hash as an output association; this review does not reproduce its numerics.

For zero barrier, N=N0*exp(-nu*t), M=N0-N and Gamma=nu*N. The declared thermal
equation is C*Tdot=P-Gamma*(D+I+2*kB*T). Define A=(D+I)/(2*kB) and
B(t)=2*kB*M(t)/C. Then the shifted integrating-factor solution is

    T(t)=(T0+A)*exp(-B(t))-A
         +(1/C)*integral_0^t P(s)*exp(B(s)-B(t)) ds.

The implemented kernel has the correct sign and is bounded by one for s<=t.
Its expm1 cooling form is algebraically equivalent and avoids a growing
integrating factor. The power integral is split at every jump. Logical times
come from exact represented-Fraction segment coordinates and local step counts;
the rounded display stamp does not redefine support. A separate Fraction sum
checks every saved prescribed-input projection.

Translation is independently integrated as the positive quantity
2*kB*T_reference*Gamma. It is accumulated over the union of observation and
power-boundary intervals, rather than recovered by subtracting a tested wall
energy ledger. Thermal plus binding plus internal plus translation minus
external input is then an independent consistency residual.

The report keeps each emitted/gross channel scale and the maximum resolved
temperature excursion distinct. Working precision/order changes are numerical
estimates; neither the plan nor report claims an interval error certificate,
physical noise scale or extra significant physical digits. Orders come from
three successive saved endpoint values, with unresolved cases represented
explicitly. The reported finite-grid results do not certify all mathematical
inputs or a continuum global error bound.

No oracle, scientific core, producer, test or numerical model was executed by
this review. No scientific module was imported. The report's passing status and
counts are observed declarations bound to its hash, not independently
recomputed results. This review covers only the manufactured zero-barrier
single-patch prescribed-power model and does not qualify physical water,
foil materials, current-to-heating closure, state chemistry or owner coupling.
