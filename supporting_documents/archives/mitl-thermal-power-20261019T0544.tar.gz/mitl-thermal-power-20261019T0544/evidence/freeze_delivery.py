"""Freeze new manufactured prescribed-power evidence without replaying the reference."""
import datetime
import csv
import hashlib
import io
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tarfile
from xml.etree import ElementTree

from prepare_delivery import WORK, REPO, BASE, OUT, PUBLIC, WRAPPERS, clean_head, dependency_context, input_contract, load, save, sha

TEXT_SUFFIXES = {'.py', '.json', '.jsonl', '.log', '.xml', '.md', '.txt', '.patch', '.sha256', '.yaml', '.csv'}
EVIDENCE_DIRS = ('core', 'core-review', 'producer', 'tests', 'independent-verification', 'oracle-review', 'next-upstream-selection', 'completion-preparation')
REPORT_PATHS = {
    'producer_run': 'producer/reference-run/report.json',
    'producer_completion': 'producer/completion.json',
    'parser_guards': 'producer/parser_guard_checks.json',
    'producer_before_run': 'producer/freeze.json',
    'tests_completion': 'tests/completion.json',
    'core_freeze': 'core/source-freeze.json',
    'static_core_review': 'core-review/completion.json',
    'oracle_completion': 'independent-verification/completion.json',
    'oracle_report': 'independent-verification/oracle-initial/report.json',
    'oracle_summary': 'independent-verification/summary.json',
    'oracle_review': 'oracle-review/completion.json',
    'documentation_association': 'documentation-association.json',
    'visual_review': 'visual-review.json',
    'selection': 'next-upstream-selection/selection.json',
}
PROJECTIONS = (
    (bytes.fromhex('2f6f70742f636f6465782f72756e74696d65732f636f6465782d7072696d6172792d72756e74696d652f646570656e64656e636965732f707974686f6e'), b'[runtime Python directory]'),
    (bytes.fromhex('2f6574632f636f6465782f'), b'[runtime policy directory]/'),
)


def excluded(relative, allowed_figures=()):
    path = Path(relative)
    if any(part in {'__pycache__', '.pytest_cache', '.venv', 'source-local', 'fulltexts', 'raw-fulltexts',
                    'pytest-temp', 'pytest-tmp', 'test-fixtures', 'fixtures'}
           or part.startswith('.thermal-power-reference-') for part in path.parts):
        return True
    if path.suffix == '.pyc':
        return True
    if 'source-acquisition' in path.parts:
        return 'raw' in path.parts or path.suffix not in {'.json', '.jsonl', '.py', '.md', '.log', '.sha256'}
    if path.suffix.lower() in {'.png', '.pdf', '.jpg', '.jpeg', '.tif', '.tiff'}:
        return str(path) not in set(allowed_figures)
    return False


def verify_contracts(records, configured_inputs, *, work_sha=None, public_sha=None, work_bytes=None):
    """Check saved metadata, exact byte pins and table associations; no model imports."""
    h = work_sha or (lambda name: sha(WORK/name))
    p = public_sha or (lambda name: sha(REPO/name))
    b = work_bytes or (lambda name: (WORK/name).read_bytes())

    def artifacts(mapping, prefix=''):
        assert isinstance(mapping, dict) and mapping
        for name, digest in mapping.items():
            path = Path(name)
            assert not path.is_absolute() and '..' not in path.parts
            assert re.fullmatch('[0-9a-f]{64}', digest) and h(prefix+name) == digest

    def rows(name):
        return list(csv.DictReader(io.StringIO(b(name).decode())))

    def counts(record, expected):
        for key, value in expected.items():
            assert type(record[key]) is int and record[key] == value, key

    core_path = 'mhdlab/thermal_power_reference.py'
    test_path = 'tests/test_thermal_power_reference.py'
    cli_path = 'tools/run_thermal_power_reference.py'
    data_path = 'mhdlab/thermal_feedback_reference.py'
    tests = records['tests_completion']
    assert tests['schema'] == 'mitl-thermal-power-core-tests-v1'
    assert tests['status'] == 'passed' and tests['all_checks_passed'] is True
    counts(tests, {'targeted_test_runs': 1, 'new_core_tests_passed': 37,
        'new_core_tests_failed': 0, 'new_core_tests_errors': 0, 'new_core_tests_skipped': 0,
        'manufactured_trajectory_families': 4, 'area_rescaling_trajectory_controls': 1,
        'instantaneous_exact_gross_balance_controls': 1})
    assert set(tests['public_source_sha256']) == {core_path, test_path}
    assert all(p(name) == digest for name, digest in tests['public_source_sha256'].items())
    assert tests['unchanged_baseline_parameter_data_sha256'] == {data_path: p(data_path)}
    assert tests['required_complete_baseline_commit'] == BASE
    assert tests['warnings_as_errors'] is True
    for key in ('old_suites_repeated', 'old_producers_repeated', 'old_numerical_evolution_called',
                'portable_test_execution_claimed', 'actual_FLASH_run', 'host_budget_accepted'):
        assert tests[key] is False
    assert tests['physical_parameters_adopted'] == 0
    artifacts(tests['artifact_sha256'])
    suites = list(ElementTree.fromstring(b('tests/core-initial.xml')).iter('testsuite'))
    assert sum(int(suite.attrib.get('tests', 0)) for suite in suites) == 37
    assert all(int(suite.attrib.get(key, 0)) == 0 for suite in suites for key in ('failures', 'errors', 'skipped'))

    core = records['core_freeze']
    assert core['schema'] == 'mhdlab-thermal-power-core-freeze-v1'
    assert core['source'] == core_path and core['source_sha256'] == p(core_path)
    assert core['frozen_before_first_meaningful_verification'] is True
    assert core['model_or_test_executions_by_author'] == 0
    preflight = core['preflight_evidence']
    assert preflight['combined_exit_code'] == 1 and preflight['focused_exit_code'] == 0
    assert h(preflight['combined_scope_and_compile_log']) == preflight['combined_log_sha256']
    assert h(preflight['focused_correct_handoff_log']) == preflight['focused_correct_handoff_log_sha256']
    static = records['static_core_review']
    assert static['schema'] == 'mitl-thermal-power-static-core-review-v1'
    assert static['status'] == 'review_complete_no_substantive_issue_identified'
    assert static['reviewed_source_sha256'] == p(core_path) and static['findings'] == []
    assert static['full_new_module_read'] is True and static['source_changes_requested'] is False
    for key in ('numerical_models_or_tests_executed', 'scientific_module_imported', 'producer_or_oracle_executed',
                'old_modules_or_audits_repeated', 'network_used', 'public_source_edits_by_reviewer',
                'physical_parameters_validated', 'host_budget_accepted'):
        assert static[key] is False
    artifacts(static['artifact_sha256'], 'core-review/')

    parser = records['parser_guards']
    assert parser['schema'] == 'mhdlab-thermal-power-parser-checks-v1' and parser['status'] == 'passed'
    counts(parser, {'rejected_configurations': 13, 'accepted_configuration_plans': 1})
    assert len(parser['checks']) == 14
    assert sum(row['outcome'] == 'rejected' for row in parser['checks']) == 13
    assert parser['cli_sha256'] == p(cli_path) and parser['config_sha256'] == configured_inputs['config_sha256']
    assert parser['script_sha256'] == h('producer/check_parser_guards.py')
    assert parser['evolution_or_core_imports_called'] is False
    assert parser['raw_gap_overlap_checks_precede_binary64_projection'] is True

    run = records['producer_run']
    produced = records['producer_completion']
    before = records['producer_before_run']
    assert run['schema'] == 'mhdlab-thermal-power-reference-run-v1' and run['status'] == 'manufactured_reference_only'
    assert run['parameter_status'] == 'manufactured' and run['config_sha256'] == configured_inputs['config_sha256']
    assert run['artifact_path_base'] == 'directory containing report.json'
    counts(run, {'case_count': 4, 'numerical_trajectory_count': 7, 'sample_count': 463})
    assert all(p(name) == digest for name, digest in run['code_sha256'].items())
    assert run['schedule_time_convention'] == configured_inputs['configuration']['schedule_time_convention']
    cases = {case['case_id']: case for case in configured_inputs['configuration']['cases']}
    expected_pairs = {(case['case_id'], tuple(grid)) for case in cases.values() for grid in case['step_grids']}
    assert {(item['case_id'], tuple(item['segment_steps'])) for item in run['trajectories']} == expected_pairs
    assert len(run['trajectories']) == 7
    prefix = 'producer/reference-run/'
    artifacts(run['artifact_sha256'], prefix)
    allowed_figures = [prefix+name for name in run['artifact_sha256'] if Path(name).suffix in {'.png', '.pdf'}]
    sample_count = 0
    channels = {'coverage_m2', 'temperature_k', 'released_m2', 'input_energy_j_m2', 'prescribed_input_energy_j_m2',
        'input_energy_residual_j_m2', 'binding_energy_j_m2', 'internal_energy_j_m2', 'translational_energy_j_m2',
        'total_wall_energy_debit_j_m2', 'gas_energy_j_m2', 'wall_thermal_change_j_m2',
        'adsorbate_reference_energy_j_m2', 'adsorbate_reference_change_j_m2',
        'adsorbate_reference_inventory_change_j_m2', 'inventory_residual_m2',
        'adsorbate_reference_residual_j_m2', 'wall_debit_residual_j_m2', 'wall_channel_residual_j_m2',
        'binding_allocation_residual_j_m2', 'internal_allocation_residual_j_m2', 'total_energy_residual_j_m2'}
    for item in run['trajectories']:
        assert h(prefix+item['csv_file']) == item['csv_sha256']
        assert h(prefix+item['history_file']) == item['history_sha256']
        history = load_json_bytes(b(prefix+item['history_file']))
        assert history['schema'] == 'mhdlab-thermal-power-reference-v1'
        assert history['model_identity'] == core['model_identity'] and history['zero_activation_barrier_only'] is True
        for key in ('physical_parameters_validated', 'host_budget_accepted', 'owner_implementation_verified'):
            assert history[key] is False
        case = cases[item['case_id']]
        assert item['input_parameters'] == history['problem'] == case['problem']
        assert item['input_segments'] == case['segments'] and item['duration_s'] == case['duration_s']
        assert item['segment_steps'] == case['step_grids'][item['grid_index']]
        assert item['total_steps'] == sum(item['segment_steps'])
        assert len(history['samples']) == item['sample_count'] == item['total_steps']+1
        assert [segment['steps'] for segment in history['schedule']['segments']] == item['segment_steps']
        assert history['schedule']['duration_s'] == case['duration_s']
        data = rows(prefix+item['csv_file'])
        assert len(data) == item['sample_count'] and channels <= set(data[-1])
        assert channels <= set(item['final_sample']) and channels <= set(history['samples'][-1])
        assert all(key in item['max_absolute_residuals'] for key in channels if 'residual' in key)
        # These are saved-file equality checks, not a repeated integration or energy oracle.
        for index, (row, sample) in enumerate(zip(data, history['samples'])):
            flat = {key: value for key, value in sample.items() if key != 'extensive'}
            flat.update(sample['extensive'])
            assert row['case_id'] == item['case_id'] and int(row['sample_index']) == index
            assert int(row['grid_index']) == item['grid_index'] and int(row['total_steps']) == item['total_steps']
            assert all(float(row[key]) == value for key, value in flat.items())
        assert all((data[-1][key] == value if isinstance(value, str) else float(data[-1][key]) == value)
                   for key, value in item['final_sample'].items())
        sample_count += len(data)
    assert sample_count == 463
    assert len(run['temporal_refinement']) == len(rows(prefix+'temporal_refinement.csv')) == 30
    assert len(run['raw_schedule_validation']) == 4
    assert all(row['raw_adjacency_and_support_checked'] is True for row in run['raw_schedule_validation'])
    for key in ('explicit_finite_prescribed_power', 'zero_activation_energy_only', 'gross_input_and_debit_separate',
                'signed_net_thermal_change_preserved', 'expected_flux_translation_2kBT'):
        assert run['qualifications'][key] is True
    for key in ('independent_reference_error_computed_here', 'old_source_or_feedback_evolution_called',
                'physical_parameters_or_water_inferred', 'actual_FLASH_or_host_coupling', 'floor_clamp_or_unsupported_fallback'):
        assert run['qualifications'][key] is False
    assert produced['schema'] == 'mhdlab-thermal-power-producer-completion-v1'
    assert produced['status'] == 'passed_production_and_parser_checks'
    counts(produced, {'core_unique_new_checks': 37, 'positive_batch_count': 1, 'case_count': 4,
        'numerical_trajectory_count': 7, 'saved_sample_count': 463, 'temporal_refinement_rows': 30})
    assert produced['report_path'] == REPORT_PATHS['producer_run'] and produced['report_sha256'] == h(REPORT_PATHS['producer_run'])
    assert produced['producer_cli_sha256'] == p(cli_path) and produced['config_sha256'] == configured_inputs['config_sha256']
    assert all(p(name) == digest for name, digest in produced['reviewed_source_sha256'].items())
    assert produced['open_substantive_findings'] == [] and produced['batch']['exit_code'] == 0
    assert produced['saved_readback']['all_artifact_hashes_verified'] is True
    assert produced['saved_readback']['all_463_csv_samples_match_history_json'] is True
    assert produced['saved_readback']['logical_segment_step_stamps_checked'] is True
    assert produced['saved_readback']['prescribed_input_checked_on_exact_logical_grid'] is True
    assert produced['saved_readback']['every_energy_extensive_copy_applies_area_once'] is True
    assert produced['source_versions']['corrections_or_retries'] == 0
    assert produced['source_versions']['parser_and_production_cli_same_bytes'] is True
    assert produced['old_suites_or_source_evolution_repeated'] is False and produced['old_feedback_evolution_called'] is False
    artifacts(produced['artifact_sha256'])
    assert produced['work_readback_correction']['initial_exit_code'] == 0
    assert h('producer/finish_producer.initial.py') == produced['work_readback_correction']['initial_script_sha256']
    assert h('producer/completion.initial.json') == produced['work_readback_correction']['initial_completion_sha256']
    assert before['schema'] == 'mhdlab-thermal-power-producer-freeze-v1'
    counts(before, {'prior_positive_cli_batches': 0, 'planned_case_count': 4,
        'planned_numerical_trajectory_count': 7, 'planned_sample_count': 463, 'core_unique_new_checks': 37})
    assert before['public_source_sha256'] == produced['reviewed_source_sha256']
    assert before['parser_checks_sha256'] == h(REPORT_PATHS['parser_guards'])
    assert before['old_evolution_or_producer_calls'] is False
    artifacts(before['saved_source_sha256'], 'producer/')

    return verify_final_reports(records, configured_inputs, h, p, b, artifacts, counts, allowed_figures)


def verify_final_reports(records, configured_inputs, h, p, b, artifacts, counts, allowed_figures):
    oracle = records['oracle_completion']
    reference = records['oracle_report']
    summary = records['oracle_summary']
    run = records['producer_run']
    assert oracle['schema'] == 'mitl-independent-thermal-power-completion-v1'
    assert oracle['status'] == 'passed' and oracle['all_checks_passed'] is True
    expected = {'cases': 4, 'saved_trajectories': 7, 'saved_sample_rows_checked': 463,
        'CSV_JSON_scalar_cells_checked': 7871, 'area_once_checks': 6482, 'logical_time_stamp_checks': 463,
        'distinct_reference_samples': 292, 'refinement_quantities_checked': 9, 'resolved_self_order_estimates': 18,
        'independent_oracle_numerical_runs': 1, 'positive_core_or_CLI_calls_by_oracle': 0, 'old_solver_or_suite_calls': 0}
    counts(oracle, expected)
    assert oracle['report'] == REPORT_PATHS['oracle_report'] and oracle['report_sha256'] == h(REPORT_PATHS['oracle_report'])
    assert oracle['summary'] == REPORT_PATHS['oracle_summary'] and oracle['summary_sha256'] == h(REPORT_PATHS['oracle_summary'])
    assert oracle['producer_report'] == REPORT_PATHS['producer_run']
    assert oracle['producer_report_sha256'] == h(REPORT_PATHS['producer_run'])
    assert oracle['producer_code_sha256'] == run['code_sha256']
    assert oracle['input_config_sha256'] == configured_inputs['config_sha256']
    assert oracle['refinement_family_steps_per_segment'] == [8, 16, 32, 64]
    assert oracle['refinement_family_total_steps'] == [24, 48, 96, 192]
    assert oracle['core_imports_in_oracle'] == [] and oracle['artifact_map_base'] == 'work_directory'
    for key in ('predeclared_budget_checks_passed', 'individual_energy_channel_checks_passed',
                'direct_positive_translation_quadrature', 'exact_fraction_logical_times',
                'temperature_and_thermal_excursion_scales_separate_from_gross_channels',
                'empty_inventory_analytic_branch_checked', 'zero_activation_energy_only'):
        assert oracle[key] is True
    for key in ('source_evolution_repeated', 'old_test_suites_repeated',
                'interval_certification_or_physical_uncertainty_claimed', 'water_or_material_or_state_data_adopted',
                'host_or_gap_or_MHD_coupling_verified'):
        assert oracle[key] is False
    artifacts(oracle['artifact_sha256'])
    assert len(oracle['command_records']) == 1
    command = oracle['command_records'][0]
    assert command['exit_code'] == 0
    assert h(str(Path(command['log']).relative_to(WORK))) == command['log_sha256']
    assert reference['schema'] == 'mitl-independent-thermal-power-oracle-v1'
    assert reference['status'] == 'passed' and reference['all_checks_passed'] is True
    counts(reference, {key: expected[key] for key in ('cases', 'saved_trajectories', 'saved_sample_rows_checked',
        'CSV_JSON_scalar_cells_checked', 'area_once_checks', 'logical_time_stamp_checks', 'distinct_reference_samples')})
    assert reference['source_model_imports'] == []
    assert reference['positive_core_or_CLI_calls'] == reference['old_solver_or_suite_calls'] == 0
    assert len(reference['trajectories']) == 7 and len(reference['temporal_self_orders']) == 9
    assert h('independent-verification/oracle-initial/'+reference['reference_samples_file']) == reference['reference_samples_sha256']
    for name, digest in reference['input_sha256'].items():
        assert h(str(Path(name).relative_to(WORK))) == digest
    before = load_json_bytes(b('independent-verification/before_run_freeze.json'))
    assert before['schema'] == 'mitl-thermal-power-independent-before-run-freeze-v1'
    assert before['independent_oracle_numerical_run_count_before_freeze'] == 0
    assert before['positive_core_or_CLI_calls_by_oracle'] == 0
    assert before['public_input_config_sha256'] == configured_inputs['config_sha256']
    assert before['saved_producer_report_sha256'] == h(REPORT_PATHS['producer_run'])
    artifacts(before['independent_code_and_plan_sha256'], 'independent-verification/')
    assert summary['schema'] == 'mitl-thermal-power-independent-summary-v1' and summary['status'] == 'passed'
    assert summary['oracle_report_sha256'] == h(REPORT_PATHS['oracle_report'])
    assert summary['source_producer_report_sha256'] == h(REPORT_PATHS['producer_run'])
    assert summary['precision_or_self_order_is_certified_bound'] is False
    for key in ('temperature_scale_is_resolved_excursion', 'thermal_scale_is_heat_capacity_times_resolved_excursion',
                'gross_input_or_debit_does_not_replace_temperature_scale'):
        assert summary[key] is True
    review = records['oracle_review']
    assert review['schema'] == 'mitl-thermal-power-static-oracle-review-v1'
    assert review['status'] == 'review_complete_no_substantive_issue_identified' and review['findings'] == []
    assert review['pre_run_code_and_plan_freeze_bound'] is True
    assert review['completed_owner_report_bound_without_numerical_replay'] is True
    for key in ('owner_report_numerics_recomputed_by_reviewer', 'source_changes_requested',
                'numerical_models_or_tests_executed', 'oracle_core_or_producer_executed', 'scientific_module_imported',
                'old_audit_or_network_repeated', 'public_or_oracle_source_edits_by_reviewer',
                'physical_parameters_validated', 'host_budget_accepted'):
        assert review[key] is False
    artifacts(review['reviewed_artifact_sha256'], 'independent-verification/')
    artifacts(review['artifact_sha256'], 'oracle-review/')

    verify_documentation_reports(records, h, p, artifacts)
    selection = records['selection']
    assert selection['schema'] == 'mhdlab-next-upstream-scientific-task-selection-v1'
    assert selection['status'] == 'selected_coarse_signed_magnetic_gap_recovery' and selection['selected'] is True
    assert selection['current_power_pass_gate']['oracle_report_sha256'] == h(REPORT_PATHS['oracle_report'])
    assert selection['current_power_pass_gate']['current_core_sha256'] == p('mhdlab/thermal_power_reference.py')
    for field in ('proposal', 'source_inventory', 'prior_conditional_record'):
        assert h('next-upstream-selection/'+selection[field]) == selection[field+'_sha256']
    for key in ('public_files_edited', 'network_used', 'source_parser_or_image_extraction_executed',
                'new_pixel_inventory_or_axis_fit_performed', 'curve_digitization_performed',
                'numerical_producer_or_model_executed', 'old_suites_source_producers_or_audits_repeated'):
        assert selection[key] is False
    relationships = {
        'new_core_and_tests': {'core_source_sha256': p('mhdlab/thermal_power_reference.py'),
            'test_source_sha256': p('tests/test_thermal_power_reference.py'),
            'passed_test_cases': 37, 'targeted_runs': 1, 'all_tests_ran_against_final_core_bytes': True},
        'new_cli_and_config': {'cli_sha256': p('tools/run_thermal_power_reference.py'),
            'config_sha256': configured_inputs['config_sha256'], 'parser_checks': 14,
            'parser_and_production_same_cli_bytes': True, 'positive_batches': 1, 'saved_trajectories': 7},
        'baseline_parameter_data': {'source_sha256': p('mhdlab/thermal_feedback_reference.py'),
            'same_as_exact_baseline': True, 'old_numerical_evolution_reused_or_replayed': False},
        'work_only_corrections': {'preflight_prior_handoff_filename_corrected_without_model_execution': True,
            'saved_readback_context_managers_corrected_without_public_source_or_trajectory_replay': True,
            'public_scientific_source_corrections': 0}}
    results = {'new_core_tests_passed': 37, 'targeted_test_runs': 1, 'new_test_failures_errors_skips': 0,
        'parser_checks': 14, 'parser_rejections': 13, 'parser_accepted_plans': 1,
        'actual_positive_cli_batches': 1, 'manufactured_cases': 4, 'saved_trajectories': 7,
        'saved_sample_rows': 463, 'producer_refinement_rows': 30,
        'independent_oracle_runs': 1, 'oracle_csv_json_cells_checked': 7871,
        'oracle_area_once_checks': 6482, 'oracle_logical_time_stamp_checks': 463,
        'oracle_distinct_reference_samples': 292, 'oracle_refinement_quantities_checked': 9,
        'oracle_resolved_self_order_estimates': 18, 'per_channel_checks_passed': True,
        'prescribed_power_zero_barrier_manufactured_reference_only': True,
        'gross_positive_input_and_debit_separate': True, 'signed_net_thermal_change_preserved': True,
        'physical_truth_validated': False, 'current_to_power_mapping_inferred': False,
        'nonzero_barrier_forced_reference_qualified': False, 'host_or_owner_implementation_verified': False,
        'interval_certification_claimed': False, 'portable_executions_performed': False,
        'packaging_reference_test_or_oracle_repeated': False, 'old_test_suites_repeated': False,
        'standalone_source_subset': False, 'complete_baseline_checkout_required': True}
    return {'allowed_figure_paths': sorted(allowed_figures), 'results': results,
            'source_version_relationships': relationships}


def verify_documentation_reports(records, h, p, artifacts):
    documentation = records['documentation_association']
    assert documentation['schema'] == 'mitl-thermal-power-documentation-association-v1'
    assert documentation['status'] == 'passed' and set(documentation['public_sha256']) == set(PUBLIC)
    assert all(p(name) == digest for name, digest in documentation['public_sha256'].items())
    artifacts(documentation['evidence_sha256'])
    assert documentation['visual_review_sha256'] == h(REPORT_PATHS['visual_review'])
    for key in ('old_suites_or_producers_repeated', 'core_CLI_or_oracle_called_here',
                'nonzero_barrier_qualified', 'physical_parameters_or_host_acceptance_verified'):
        assert documentation[key] is False
    visual = records['visual_review']
    assert visual['schema'] == 'mitl-thermal-power-root-visual-review-v1'
    assert visual['numerical_execution_performed'] is False
    artifacts(visual['reviewed'], 'producer/reference-run/')


def load_json_bytes(data):
    from prepare_delivery import loads
    return loads(data)


def main():
    payload = WORK/'delivery-preparation/payload'
    preparation = load(payload/'preparation.json')
    head = clean_head(preparation['source_commit'])
    assert preparation['base_commit'] == BASE
    assert not OUT.exists() and not OUT.with_suffix('.tar.gz').exists()
    assert load(payload/'source_file_list.json') == {'byte_identical_public_files': list(PUBLIC), 'packaging_wrappers': list(WRAPPERS)}
    assert len(PUBLIC) == 5 and len(WRAPPERS) == 2
    assert {str(path.relative_to(payload/'source')) for path in (payload/'source').rglob('*') if path.is_file()} == set(PUBLIC)|set(WRAPPERS)
    assert not (payload/'source/mhdlab/__init__.py').exists()
    for name in PUBLIC:
        assert (payload/'source'/name).read_bytes() == (REPO/name).read_bytes()
    context = dependency_context()
    assert context == preparation['dependency_context'] == load(payload/'dependency_context.json')
    configured_inputs = input_contract()
    assert configured_inputs == preparation['input_contract']
    records = {key: load(WORK/name) for key, name in REPORT_PATHS.items()}
    contract = verify_contracts(records, configured_inputs)
    allowed_figures = contract['allowed_figure_paths']
    next_task = records['selection']['selected_task']
    assert isinstance(next_task, str) and next_task.strip()
    shutil.copytree(payload, OUT)
    evidence = OUT/'evidence'
    evidence.mkdir()
    try:
        active_log = Path(os.readlink('/proc/self/fd/1')).resolve()
    except OSError:
        active_log = None
    copied_inputs, omitted, copied_root_files = [], [], []

    def copy(path, relative):
        assert not path.is_symlink()
        digest = sha(path)
        target = evidence/relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, target)
        assert sha(target) == digest
        copied_inputs.append({'source': str(path), 'archive': str(target.relative_to(OUT)), 'sha256': digest})

    for path in WORK.iterdir():
        if path.is_file() and path.suffix in TEXT_SUFFIXES and path.resolve() != active_log:
            copy(path, Path(path.name))
            copied_root_files.append(path.name)
    for folder in EVIDENCE_DIRS:
        for path in (WORK/folder).rglob('*'):
            assert not path.is_symlink()
            if not path.is_file():
                continue
            relative = path.relative_to(WORK)
            if excluded(relative, allowed_figures):
                omitted.append({'path': str(relative), 'sha256': sha(path), 'bytes': path.stat().st_size,
                    'reason': 'Cache, temporary fixture, failed staging data or unselected figure omitted from this new reference evidence.'})
            else:
                copy(path, relative)
    projections = []
    for path in evidence.rglob('*'):
        if not path.is_file() or path.suffix not in TEXT_SUFFIXES:
            continue
        for prefix, replacement in PROJECTIONS:
            data = path.read_bytes()
            if prefix in data:
                assert replacement not in data
                path.write_bytes(data.replace(prefix, replacement))
                projections.append({'path': str(path.relative_to(OUT)), 'original_sha256': hashlib.sha256(data).hexdigest(),
                    'portable_sha256': sha(path), 'replacements': data.count(prefix), 'source_prefix_hex': prefix.hex(),
                    'replacement': replacement.decode(), 'scope': 'Archive-only machine-directory projection; local raw bytes unchanged.'})
    save(OUT/'portable_path_projections.json', projections)
    save(OUT/'excluded_evidence.json', omitted)
    with (OUT/'thermal-power-reference.patch').open('wb') as stream:
        subprocess.run(['git', 'diff', '--binary', BASE, head], cwd=REPO, stdout=stream, check=True)
    verification = {'schema': 'mitl-thermal-power-reference-verification-v1',
        'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'source_commit': head, 'base_commit': BASE, 'input_contract': configured_inputs,
        'dependency_context': context, 'package_kind': 'patch_over_exact_complete_baseline',
        'results': contract['results'], 'records': records, 'record_paths': REPORT_PATHS,
        'source_version_relationships': contract['source_version_relationships'],
        'record_sha256': {key: sha(WORK/name) for key, name in REPORT_PATHS.items()},
        'allowed_figure_paths': allowed_figures, 'copied_input_sha256': copied_inputs,
        'public_files_byte_identical': len(PUBLIC), 'packaging_wrappers': len(WRAPPERS),
        'commits': subprocess.check_output(['git', 'log', '--reverse', '--format=%H %s', BASE+'..'+head], cwd=REPO, text=True).splitlines(),
        'command_snapshot': {'scope': 'Completed new-pass records before freezing; later archive/verification/completion records remain local.',
                             'copied_root_files': sorted(copied_root_files)},
        'next_task': next_task,
        'limits': ['Manufactured stationary one-patch finite-inventory reference with supplied constant heat capacity and finite prescribed nonnegative power.',
            'Only the zero-activation-barrier branch is qualified. Nonzero barriers need a fresh independent forced coupled-IVP reference.',
            'Gross external input, removal, internal, continuum expected translation and signed net thermal changes are separately retained.',
            'Finite reference precision/refinement changes are numerical estimates, not rigorous interval certificates.',
            'No measured power/current conversion, physical water/foil closure, FLASH, source history, gap, CR or owner transaction is supplied.',
            'Five-file patch requires the exact complete baseline; no standalone package, initializer workaround or portable execution is claimed.']}
    save(OUT/'verification.json', verification)
    save(OUT/'next_task.json', {'task': next_task, 'selection_evidence': 'evidence/'+REPORT_PATHS['selection']})
    (OUT/'systems-mitl-thermal-power-reference-10192026.md').write_text(f'''# Manufactured prescribed-power reference

Five new public files are byte-identical to `{head}`. Apply the patch to the
complete checkout at `{BASE}`. The source subset is not standalone; the README
and unchanged baseline requirements are wrappers, with no initializer replacement
or portable execution claim.

This new zero-barrier reference evolves a finite parent inventory and one wall
patch under a fully supported manufactured piecewise-constant power schedule.
The gross input-energy ledger is distinct from gross desorption channels and
signed net wall change. Independent exponential inventory, integrating-factor
temperature and separately quadratured translation checks qualify the saved
trajectories and explicit discontinuities under declared manufactured conditions.
Refinement and precision changes are numerical evidence, not certified errors.

Source/code/test/parser versions, configurations, ledgers, residuals, figures,
commands, failed attempts and focused corrections are retained. Existing 0515
passes are not rerun or promoted to evidence for the new operator. No recovered
current is converted to physical heating power and no nonzero-barrier, actual
foil, water, state, spectral, FLASH, host or source-history claim is inferred.
Assembly runs no model, oracle, test suite or portable environment.

Next selected task: {next_task}
''')
    manifest = {str(path.relative_to(OUT)): sha(path) for path in OUT.rglob('*') if path.is_file() and path.name != 'manifest.sha256.json'}
    save(OUT/'manifest.sha256.json', manifest)
    words = [bytes.fromhex(value).decode() for value in ('6f70656e6169', '63686174677074', '636c61756465', '636f646578')]
    prohibited = re.compile(r'\b(?:'+'|'.join(words)+r')\b', re.I)
    allowed_archive_figures = {'evidence/'+name for name in allowed_figures}
    for path in OUT.rglob('*'):
        assert not path.is_symlink()
        if path.is_file():
            assert not excluded(path.relative_to(OUT), allowed_archive_figures)
            if path.suffix in TEXT_SUFFIXES:
                assert not prohibited.search(path.read_text()), str(path)
    clean_head(head)
    assert all(sha(REPO/name) == preparation['public_source_sha256'][name] for name in PUBLIC)
    assert all(sha(Path(item['source'])) == item['sha256'] for item in copied_inputs)
    archive = OUT.with_suffix('.tar.gz')
    with tarfile.open(archive, 'w:gz') as tar:
        tar.add(OUT, arcname=OUT.name)
    record = {'folder': str(OUT), 'archive': str(archive), 'sha256': sha(archive), 'bytes': archive.stat().st_size,
        'source_commit': head, 'base_commit': BASE, 'manifest_entries': len(manifest),
        'public_files_byte_identical': len(PUBLIC), 'packaging_wrappers': len(WRAPPERS),
        'manifest_sha256': sha(OUT/'manifest.sha256.json'), 'verification_sha256': sha(OUT/'verification.json')}
    save(WORK/'frozen_delivery.json', record)
    print(json.dumps(record, indent=2))


if __name__ == '__main__':
    main()
