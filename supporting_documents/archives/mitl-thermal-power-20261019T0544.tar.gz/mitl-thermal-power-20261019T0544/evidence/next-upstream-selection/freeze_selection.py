"""Freeze cached-source queue selection after the saved power-oracle pass."""
import datetime
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
PASS = HERE.parent
REPO = Path('/workspace/Power-Flow')
ORACLE_PIN = '692f286b65d4d3c43b58b512b113432bdf8b84ba2b0670fb87deadea3965afb7'
CORE_PIN = '741ab61b45cc0440b2f133732df387e34bd7630d6b6d5eeb48be7f6e471f1e00'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


oracle_path = PASS / 'independent-verification/oracle-initial/report.json'
assert sha(oracle_path) == ORACLE_PIN
oracle = json.loads(oracle_path.read_text())
assert oracle['status'] == 'passed' and oracle['all_checks_passed'] is True
assert oracle['cases'] == 4 and oracle['saved_trajectories'] == 7
assert oracle['saved_sample_rows_checked'] == 463
assert oracle['source_model_imports'] == []
assert oracle['positive_core_or_CLI_calls'] == 0 and oracle['old_solver_or_suite_calls'] == 0
assert sha(REPO / 'mhdlab/thermal_power_reference.py') == CORE_PIN
proposal_path = HERE / 'magnetic_gap_recovery_proposal.json'
proposal = json.loads(proposal_path.read_text())
assert sha(proposal_path) == '6eb2d0487bfef3849adbd2577310de278e1108165ba06726c05ba72f1b389c63'
conditional = HERE / 'conditional-selection.json'
inventory = {
    'schema': 'mhdlab-cached-magnetic-gap-source-inventory-v1',
    'status': 'genuinely_pending_quantity_from_cached_metadata',
    'pending_evidence': proposal['pending_evidence'],
    'cached_source_identity': proposal['cached_source_identity'],
    'prior_candidate_metadata_not_a_new_calibration': proposal['prior_candidate_metadata_not_a_new_calibration'],
    'quantity': 'Four coarse signed B_x gap profiles: edge and middle at nominal 40 and60 ns.',
    'current_work': 'Read-only cached manifest, guide and metadata declarations only; no source extraction, new pixel inventory, axis fit, digitization or old audit.',
    'future_recovery_gate': 'Freshly inspect the magnetic panels and fit their own axes under a new bounded lease; do not adopt candidate colors/ticks or any old calibration without that new verification.',
    'physical_normalization_verified': False, 'Hall_or_host_acceptance_inferred': False,
    'new_digitization_or_axis_fit_performed': False
}
inventory_path = HERE / 'source_inventory.json'
assert not inventory_path.exists()
inventory_path.write_text(json.dumps(inventory, indent=2, allow_nan=False)+'\n')
document = {
    'schema': 'mhdlab-next-upstream-scientific-task-selection-v1',
    'status': 'selected_coarse_signed_magnetic_gap_recovery', 'selected': True,
    'selected_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'selected_task': 'Recover four separately qualified coarse signed B_x gap profiles from the explicitly pending magnetic panels of dissertation Figures4.28/4.29, preserving native provenance, finite support and unverified literal units.',
    'why_new_and_useful': proposal['why_new'],
    'proposal': proposal_path.name, 'proposal_sha256': sha(proposal_path),
    'source_inventory': inventory_path.name, 'source_inventory_sha256': sha(inventory_path),
    'prior_conditional_record': conditional.name, 'prior_conditional_record_sha256': sha(conditional),
    'current_power_pass_gate': {
        'status': 'passed_before_selection',
        'oracle_report': 'independent-verification/oracle-initial/report.json',
        'oracle_report_sha256': ORACLE_PIN, 'oracle_schema': oracle['schema'],
        'all_checks_passed': True, 'cases': 4, 'saved_trajectories': 7,
        'saved_sample_rows_checked': 463,
        'oracle_source_model_imports': [], 'oracle_positive_core_or_CLI_calls': 0,
        'oracle_old_solver_or_suite_calls': 0, 'oracle_input_sha256': oracle['input_sha256'],
        'current_core': 'mhdlab/thermal_power_reference.py', 'current_core_sha256': CORE_PIN,
        'qualification': 'Manufactured zero-activation-barrier prescribed-power reference only; no physical current-to-power mapping or forced nonzero-barrier acceptance.'
    },
    'source_recovery_scope': {
        'published_legacy_simulation_only': True, 'actual_FLASH_result': False,
        'profiles': ['4.28 edge40ns', '4.28 middle40ns', '4.29 edge60ns', '4.29 middle60ns'],
        'primary_quantity': 'Signed literal B_x [100 Tesla] axis value versus gap-centred distance [mm].',
        'SI_conversion': 'Only explicitly literal_conditional factor100 tesla columns, with original electromagnetic normalization unverified.',
        'resolution_limit': 'Coarse gap-field shape only; nominal foil occupies roughly8nativepixels and does not resolve a skin derivative or exact surface field.',
        'no_inferences': proposal['not_inferred'],
        'suggested_new_public_paths': proposal['suggested_new_public_paths']
    },
    'separate_queue_gates': proposal['separate_queue_gates'],
    'implementation_authorization': 'Queue selection only. Root must complete the current pass and claim a fresh bounded source-recovery lease before any new public implementation or digitization.',
    'public_files_edited': False, 'network_used': False,
    'source_parser_or_image_extraction_executed': False,
    'new_pixel_inventory_or_axis_fit_performed': False,
    'curve_digitization_performed': False,
    'numerical_producer_or_model_executed': False,
    'old_suites_source_producers_or_audits_repeated': False,
    'physical_parameters_adopted': 0,
    'status_read_sha256': sha(Path('/workspace/research_work/mitl-upstream-status.json')),
    'lease_sha256': sha(PASS / 'lease.json'), 'writer_sha256': sha(Path(__file__)),
    'selection_limit': 'Cached evidence inventory and planning only. No new magnetic samples, axis fit, normalization, field acceptance or physical inference is supplied.'
}
target = HERE / 'selection.json'
assert not target.exists()
target.write_text(json.dumps(document, indent=2, allow_nan=False)+'\n')
print(json.dumps({'selection': str(target), 'selection_sha256': sha(target),
                  'proposal_sha256': sha(proposal_path), 'source_inventory_sha256': sha(inventory_path),
                  'oracle_gate_sha256': ORACLE_PIN, 'selected_task': document['selected_task'],
                  'source_or_model_execution': False}, indent=2))
