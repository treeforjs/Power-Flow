"""Freeze fresh independent power-reference code and fixtures before evaluation."""
import ast
import datetime
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
WORK=HERE.parent
CONFIG=Path('/workspace/Power-Flow/configs/thermal_power_manufactured.json')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    target=HERE/'before_run_freeze.json'
    if target.exists() or (HERE/'input_config.json').exists():
        raise RuntimeError('refuse to replace a pre-run freeze')
    status=json.loads((WORK.parent/'mitl-upstream-status.json').read_text())
    assert status['active_lease_owner']==WORK.name
    assert datetime.datetime.fromisoformat(status['active_editing_lease_until_utc'])>datetime.datetime.now(datetime.timezone.utc)
    for name in ('decimal_power_reference.py','verify_saved_power.py'):
        tree=ast.parse((HERE/name).read_text())
        for node in ast.walk(tree):
            names=[alias.name.split('.')[0] for alias in node.names] if isinstance(node,ast.Import) else [(node.module or '').split('.')[0]] if isinstance(node,ast.ImportFrom) else []
            assert not set(names)&{'mhdlab','tools','numpy','scipy','mpmath'}
    config=json.loads(CONFIG.read_text())
    assert config['schema']=='mhdlab-thermal-power-manufactured-config-v1' and len(config['cases'])==4
    assert sum(len(case['step_grids']) for case in config['cases'])==7
    (HERE/'input_config.json').write_bytes(CONFIG.read_bytes())
    files=('decimal_power_reference.py','verify_saved_power.py','oracle_plan.json','input_config.json','freeze_oracle.py')
    result={'schema':'mitl-thermal-power-independent-before-run-freeze-v1',
        'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'independent_code_and_plan_sha256':{name:sha(HERE/name) for name in files},
        'public_input_config':str(CONFIG),'public_input_config_sha256':sha(CONFIG),
        'cases':4,'expected_saved_trajectories':7,'expected_saved_sample_rows':463,
        'independent_oracle_numerical_run_count_before_freeze':0,'positive_core_or_CLI_calls_by_oracle':0,
        'saved_producer_report_already_available':True,
        'saved_producer_report_sha256':sha(WORK/'producer/reference-run/report.json'),
        'input_and_tolerance_selection':'Fixture coefficients agreed with producer owner before production; reference tolerances/code fixed before first independent numerical evaluation. No saved numerical trajectory values were used to tune these tolerances.',
        'limits':'Fresh self-contained Decimal oracle; no old model imports or tests, no dependency installation, physical data, host coupling or certified error claim.'}
    target.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'freeze':str(target),'sha256':sha(target),'independent_code_and_plan_sha256':result['independent_code_and_plan_sha256']},indent=2))


if __name__=='__main__':
    main()
