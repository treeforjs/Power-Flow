"""Fresh independent zero-barrier prescribed-power reference.

The temperature uses a scaled integrating factor split at power jumps.
Translation is a separate direct positive integral of 2*kB*T_reference*Gamma;
it is never obtained by subtracting the tested thermal-energy ledger.
No repository numerical module is imported.
"""
from dataclasses import dataclass
from decimal import Decimal, getcontext, localcontext
from functools import lru_cache
from fractions import Fraction
import math

D = Decimal
KB = D('1.380649e-23')
QE = D('1.602176634e-19')


def represented(value):
    return D.from_float(float(value))


def expm1(value):
    if abs(value) >= D('0.1'):
        return value.exp()-1
    term = total = value
    threshold = D(10)**(-getcontext().prec+8)
    for n in range(2, 10000):
        term *= value/n
        updated = total+term
        if updated == total or abs(term) <= abs(updated)*threshold:
            return updated
        total = updated
    raise RuntimeError('Decimal exponential series unresolved')


@lru_cache(maxsize=8)
def probability_rule(order, precision):
    if type(order) is not int or order < 2 or order % 2:
        raise ValueError('positive even quadrature order required')
    with localcontext() as context:
        context.prec = precision
        tolerance = D(10)**(-precision+12)
        rule = []
        for j in range(1, order//2+1):
            root = D.from_float(math.cos(math.pi*(j-.25)/(order+.5)))
            for _ in range(100):
                previous, current = D(1), root
                for n in range(2, order+1):
                    previous, current = current, ((2*n-1)*root*current-(n-1)*previous)/n
                derivative = order*(root*current-previous)/(root*root-1)
                change = current/derivative
                root -= change
                if abs(change) <= tolerance:
                    break
            else:
                raise RuntimeError('Decimal Legendre root unresolved')
            previous, current = D(1), root
            for n in range(2, order+1):
                previous, current = current, ((2*n-1)*root*current-(n-1)*previous)/n
            derivative = order*(root*current-previous)/(root*root-1)
            weight = 1/((1-root*root)*derivative*derivative)
            rule.extend((((1-root)/2, weight), ((1+root)/2, weight)))
        rule.sort()
        if abs(sum(weight for _, weight in rule)-1) > D(10)**(-precision+10):
            raise RuntimeError('Decimal quadrature normalization unresolved')
        return tuple(rule)


def quadrature(function, start, stop, *, order, precision):
    if start == stop:
        return D(0)
    if not start < stop:
        raise ValueError('strict quadrature interval required')
    width = stop-start
    return width*sum(weight*function(start+width*node) for node, weight in probability_rule(order, precision))


@dataclass(frozen=True)
class ForcedReference:
    n0: D
    t0: D
    capacity: D
    area: D
    nu: D
    removal: D
    internal: D
    tmin: D
    tmax: D
    segments: tuple
    precision: int
    order: int

    @classmethod
    def from_inputs(cls, problem, schedule, *, precision, order):
        reservoir = problem['reservoir']
        if represented(reservoir['activation_energy_ev']) != 0:
            raise ValueError('independent integrating-factor reference requires exactly zero kinetic barrier')
        segments = tuple((represented(item['start_s']), represented(item['stop_s']), represented(item['power_w_m2']))
            for item in schedule['segments'])
        if not (segments and segments[0][0] == 0 and all(a < b and power >= 0 for a,b,power in segments)
                and all(left[1] == right[0] for left,right in zip(segments,segments[1:]))):
            raise ValueError('invalid independent finite power schedule')
        result = cls(represented(problem['initial_coverage_m2']), represented(problem['initial_temperature_k']),
            represented(problem['areal_heat_capacity_j_m2_k']), represented(problem['patch_area_m2']),
            represented(reservoir['attempt_frequency_s']), represented(reservoir['desorption_energy_ev'])*QE,
            represented(reservoir['internal_energy_ev'])*QE, represented(problem['temperature_min_k']),
            represented(problem['temperature_max_k']), segments, precision, order)
        if not (result.n0 >= 0 and result.nu > 0 and result.capacity > 0 and result.area > 0
                and result.removal >= 0 and result.internal >= 0 and 0 < result.tmin <= result.t0 <= result.tmax):
            raise ValueError('invalid independent problem coefficients')
        return result

    @property
    def shift(self):
        return (self.removal+self.internal)/(2*KB)

    def active_segments(self, time):
        if not 0 <= time <= self.segments[-1][1]:
            raise ValueError('query outside finite declared support')
        return tuple((start, min(stop,time), power) for start,stop,power in self.segments if start < time)

    def released(self, time):
        return -self.n0*expm1(-self.nu*time)

    def inventory(self, time):
        return self.n0*(-self.nu*time).exp()

    def exponent(self, time):
        return 2*KB*self.released(time)/self.capacity

    def input_energy(self, time):
        return sum(((stop-start)*power for start,stop,power in self.active_segments(time)), D(0))

    @lru_cache(maxsize=65536)
    def temperature(self, time):
        if self.n0 == 0:
            temperature = self.t0+self.input_energy(time)/self.capacity
        else:
            exponent = self.exponent(time)
            temperature = self.t0+(self.t0+self.shift)*expm1(-exponent)
            for start, stop, power in self.active_segments(time):
                if power:
                    temperature += power/self.capacity*quadrature(
                        lambda source_time: (self.exponent(source_time)-exponent).exp(), start, stop,
                        order=self.order, precision=self.precision)
        if not self.tmin <= temperature <= self.tmax:
            raise ValueError('independent temperature outside declared domain')
        return temperature

    def translation_rate(self, time):
        if self.n0 == 0:
            return D(0)
        return 2*KB*self.temperature(time)*self.nu*self.inventory(time)

    def sample(self, time, translation):
        inventory, emitted, temperature = self.inventory(time), self.released(time), self.temperature(time)
        binding, internal = self.removal*emitted, self.internal*emitted
        input_energy = self.input_energy(time)
        thermal = self.capacity*(temperature-self.t0)
        return {'time_s': time, 'coverage_m2': inventory, 'temperature_k': temperature, 'released_m2': emitted,
            'input_energy_j_m2': input_energy, 'binding_energy_j_m2': binding, 'internal_energy_j_m2': internal,
            'prescribed_input_energy_j_m2': input_energy,
            'translational_energy_j_m2': translation, 'total_wall_energy_debit_j_m2': binding+internal+translation,
            'gas_energy_j_m2': internal+translation, 'wall_thermal_change_j_m2': thermal,
            'adsorbate_reference_energy_j_m2': -self.removal*inventory,
            'adsorbate_reference_change_j_m2': binding, 'adsorbate_reference_inventory_change_j_m2': binding,
            'independent_total_energy_residual_j_m2': thermal+binding+internal+translation-input_energy}


def reference_grid(problem, schedule, times, *, precision, order):
    """Accumulate direct translation once over the union observation grid."""
    with localcontext() as context:
        context.prec = precision
        reference = ForcedReference.from_inputs(problem, schedule, precision=precision, order=order)
        if any(not isinstance(time, Fraction) for time in times):
            raise TypeError('exact represented-Fraction logical observation times required')
        edges = {Fraction.from_float(float(item[key])) for item in schedule['segments'] for key in ('start_s','stop_s')}
        queries = sorted(set(times)|{Fraction(0)}|edges)
        if queries[-1] != Fraction.from_float(float(schedule['duration_s'])):
            raise ValueError('observation grid must cover exactly the declared schedule')
        translation, previous = D(0), D(0)
        samples = {}
        for logical_time in queries:
            time = D(logical_time.numerator)/D(logical_time.denominator)
            translation += quadrature(reference.translation_rate, previous, time, order=order, precision=precision)
            samples[logical_time] = reference.sample(time, translation)
            previous = time
        return samples
