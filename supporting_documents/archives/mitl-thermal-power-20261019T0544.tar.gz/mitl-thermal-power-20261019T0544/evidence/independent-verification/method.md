# Independent prescribed-power reference

This reference checks four manufactured stationary-patch cases and seven saved trajectories of the zero-activation-energy model. It reads the saved output; it imports and executes no numerical core, source evolution, CLI, kinetic transport, reaction model or earlier suite.

With rate constant `nu`, inventory is `N(t)=N0 exp(-nu t)` and released inventory is `M(t)=N0-N(t)`. Let `C` be areal heat capacity, `D` the separately supplied wall-removal energy, `I` the supplied internal energy, `A=(D+I)/(2 kB)` and `B(t)=2 kB M(t)/C`. The reference evaluates

`T(t)=(T0+A) exp(-B(t))-A + sum P/C integral exp(B(s)-B(t)) ds`.

Each forcing integral is restricted to its declared segment and split at every power change. The scaled kernel avoids a growing integrating factor. Translation is independently integrated as the positive integral `integral 2 kB T(s) nu N0 exp(-nu s) ds`; it is never inferred by subtracting the tested thermal or total energy ledger. Binding/removal, internal, gas, wall debit, adsorbate reference and prescribed input channels retain separate values and signed residual checks. The empty-inventory branch has zero release and `T=T0+Einput/C`.

Problem coefficients and schedule endpoints/powers are exact representations of their supplied float64 projections. The SI constants are the declared decimal values `kB=1.380649e-23 J/K` and `1 eV=1.602176634e-19 J`. Logical times use exact rational arithmetic on represented segment endpoints and integer step fractions. The output time stamp is checked separately as a rounded projection; it does not redefine support.

Legendre roots and weights are generated in Decimal at 80 and 120 digits with 16 and 32 nodes respectively. Binary cosine seeds are refined before weights are evaluated. One reference grid per distinct case and precision/order is reused across its temporal family. Translation is accumulated over the union of exact logical observation intervals, split at all power changes. Reference-order changes are estimates rather than certified bounds or physical uncertainties. High precision does not remove float input/output or operational rounding floors.

Temperature errors use the maximum resolved reference temperature excursion over the case. Thermal-energy errors use that excursion times `C`; a small final net thermal change does not replace these scales with gross input or wall debit. Each count and energy channel has its own emitted or positive channel scale. An exactly zero scale requires exactly zero error. All selected budgets and minimum resolved self-orders were frozen before the sole numerical reference run.

Only the supplied zero-barrier mathematical model is checked. The coefficients, fixed emitted-state energy and powers are manufactured. No water, material heat-capacity, phase, state-chemistry, actual foil, gap, MHD or host-transaction validation is claimed. Nonzero activation energy requires a separate independent forced coupled-IVP reference.
