"""Static hash/readback aggregation; executes no numerical reference or model."""
import datetime
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
WORK = HERE.parent
REPO = Path('/workspace/Power-Flow')
RUN = WORK/'producer/reference-run'
ORACLE = HERE/'oracle-initial/report.json'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def display(record):
    return record['float_projection']


def main():
    if (HERE/'completion.json').exists() or (HERE/'summary.json').exists():
        raise RuntimeError('refuse to overwrite saved completion or summary')
    reference = load(ORACLE)
    producer = load(RUN/'report.json')
    freeze = load(HERE/'before_run_freeze.json')
    assert reference['schema'] == 'mitl-independent-thermal-power-oracle-v1'
    assert reference['status'] == 'passed' and reference['all_checks_passed'] is True
    expected = {'cases': 4, 'saved_trajectories': 7, 'saved_sample_rows_checked': 463,
        'CSV_JSON_scalar_cells_checked': 7871, 'area_once_checks': 6482,
        'logical_time_stamp_checks': 463, 'distinct_reference_samples': 292}
    assert all(reference[key] == value for key, value in expected.items())
    assert reference['source_model_imports'] == []
    assert reference['positive_core_or_CLI_calls'] == reference['old_solver_or_suite_calls'] == 0
    assert freeze['independent_oracle_numerical_run_count_before_freeze'] == 0
    assert freeze['saved_producer_report_sha256'] == sha(RUN/'report.json')
    for name, digest in freeze['independent_code_and_plan_sha256'].items():
        assert sha(HERE/name) == digest
    assert sha(HERE/'input_config.json') == sha(RUN/'input_config.json') == producer['config_sha256']
    assert sha(REPO/'configs/thermal_power_manufactured.json') == producer['config_sha256']
    for name, digest in producer['artifact_sha256'].items():
        assert sha(RUN/name) == digest
    for name, digest in producer['code_sha256'].items():
        assert sha(REPO/name) == digest
    for trajectory in producer['trajectories']:
        assert sha(RUN/trajectory['csv_file']) == trajectory['csv_sha256']
        assert sha(RUN/trajectory['history_file']) == trajectory['history_sha256']
    for name, digest in reference['input_sha256'].items():
        assert sha(name) == digest
    for trajectory in reference['trajectories']:
        for name, digest in trajectory['source_artifact_sha256'].items():
            assert sha(name) == digest
    assert sha(ORACLE.parent/reference['reference_samples_file']) == reference['reference_samples_sha256']
    commands = [json.loads(line) for line in (WORK/'commands.jsonl').read_text().splitlines()]
    executions = [row for row in commands if Path(row['log']).name == 'independent-power-oracle-initial.log']
    assert len(executions) == 1 and executions[0]['exit_code'] == 0
    assert sha(executions[0]['log']) == executions[0]['log_sha256']
    all_row = max((display(v['absolute_budget_fraction']), t['case_id'], t['segment_steps'], key)
        for t in reference['trajectories'] for key, v in t['all_row_maximum_errors'].items())
    ledger = max((display(v['absolute_budget_fraction']), t['case_id'], t['segment_steps'], key)
        for t in reference['trajectories'] for key, v in t['independent_signed_ledger_maxima'].items())
    precision = max((display(v['absolute_budget_fraction']), case, key)
        for case, quantities in reference['all_row_reference_precision_order_changes'].items()
        for key, v in quantities.items())
    orders = [display(row['order']) for estimates in reference['temporal_self_orders'].values()
        for row in estimates if row['order'] is not None]
    assert len(reference['temporal_self_orders']) == 9 and len(orders) == 18
    assert sum(t['sample_rows'] for t in reference['trajectories']) == 463
    assert sum(t['area_once_checks'] for t in reference['trajectories']) == 6482
    final_cases = {}
    for trajectory in reference['trajectories']:
        final_cases[trajectory['case_id']] = {key: display(value)
            for key, value in trajectory['endpoint_reference'].items()}
    summary = {'schema': 'mitl-thermal-power-independent-summary-v1', 'status': 'passed',
        'oracle_report_sha256': sha(ORACLE), 'source_producer_report_sha256': sha(RUN/'report.json'),
        **expected, 'max_all_row_error_budget_fraction': all_row,
        'max_signed_ledger_absolute_budget_fraction': ledger,
        'max_reference_precision_order_budget_fraction': precision,
        'finite_self_order_range': [min(orders), max(orders)],
        'final_reference_cases': final_cases,
        'summary_uses_display_float_projections': True,
        'precision_or_self_order_is_certified_bound': False,
        'temperature_scale_is_resolved_excursion': True,
        'thermal_scale_is_heat_capacity_times_resolved_excursion': True,
        'gross_input_or_debit_does_not_replace_temperature_scale': True,
        'roundoff_qualification': 'These estimates resolve the manufactured mathematical model of represented inputs and exact decimal SI constants. They do not remove float input/output or operational rounding floors or establish physical parameter uncertainty.'}
    (HERE/'summary.json').write_text(json.dumps(summary, indent=2, allow_nan=False)+'\n')
    artifact_names = ['decimal_power_reference.py', 'verify_saved_power.py', 'freeze_oracle.py',
        'oracle_plan.json', 'input_config.json', 'before_run_freeze.json', 'method.md',
        'finalize_completion.py', 'oracle-initial/report.json', 'oracle-initial/reference_samples.json', 'summary.json']
    record = {'schema': 'mitl-independent-thermal-power-completion-v1', 'status': 'passed',
        'all_checks_passed': True, 'completed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'report': str(ORACLE.relative_to(WORK)), 'report_sha256': sha(ORACLE),
        'summary': 'independent-verification/summary.json', 'summary_sha256': sha(HERE/'summary.json'),
        'producer_report': 'producer/reference-run/report.json',
        'producer_report_sha256': sha(RUN/'report.json'), 'producer_code_sha256': producer['code_sha256'],
        'input_config_sha256': producer['config_sha256'], **expected,
        'refinement_family_steps_per_segment': [8, 16, 32, 64],
        'refinement_family_total_steps': [24, 48, 96, 192],
        'refinement_quantities_checked': 9, 'resolved_self_order_estimates': 18,
        'self_order_min': min(orders), 'self_order_max': max(orders),
        'predeclared_budget_checks_passed': True, 'individual_energy_channel_checks_passed': True,
        'direct_positive_translation_quadrature': True, 'exact_fraction_logical_times': True,
        'temperature_and_thermal_excursion_scales_separate_from_gross_channels': True,
        'empty_inventory_analytic_branch_checked': True, 'zero_activation_energy_only': True,
        'independent_oracle_numerical_runs': 1, 'positive_core_or_CLI_calls_by_oracle': 0,
        'core_imports_in_oracle': [], 'old_solver_or_suite_calls': 0,
        'source_evolution_repeated': False, 'old_test_suites_repeated': False,
        'interval_certification_or_physical_uncertainty_claimed': False,
        'water_or_material_or_state_data_adopted': False,
        'host_or_gap_or_MHD_coupling_verified': False,
        'artifact_map_base': 'work_directory',
        'artifact_sha256': {str((HERE/name).relative_to(WORK)): sha(HERE/name) for name in artifact_names},
        'command_records': executions, 'qualification': reference['qualification'],
        'limits': 'Four manufactured stationary-patch zero-barrier power cases with fixed supplied internal/removal costs. The independent integrating-factor/translation references and finite refinement qualify the declared mathematical model; nonzero barriers, physical water/material parameters, actual foil thermodynamics, gap response and host transactions require separate evidence.'}
    (HERE/'completion.json').write_text(json.dumps(record, indent=2, allow_nan=False)+'\n')
    print(json.dumps({'completion': str(HERE/'completion.json'), 'completion_sha256': sha(HERE/'completion.json'),
        'summary_sha256': sha(HERE/'summary.json'), **expected, 'independent_oracle_runs': 1,
        'positive_core_or_CLI_calls': 0}, indent=2))


if __name__ == '__main__':
    main()
