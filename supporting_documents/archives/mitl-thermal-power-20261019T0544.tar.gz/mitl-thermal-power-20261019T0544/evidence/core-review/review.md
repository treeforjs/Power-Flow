# Prescribed-power thermal-reference static review

The new `thermal_power_reference.py` was read in full at the frozen source hash
recorded in `completion.json`. No substantive source correctness issue was
identified in this bounded review, and no source changes were requested.

Gross input and desorption channels remain separate exact rational stage
quantities when their signed net thermal increment is zero. Temperature may
heat, cool or remain exactly unchanged without clipping; nonzero changes lost
in the float state reject. The four RK4 stages stay inside their own constant
power segment, including the final stage at its right endpoint. The following
segment starts with its new power and the carried-forward state. Exact finite
support, adjacency and advancing output times prevent a silent gap, overlap or
held power tail.

Energy signs use wall thermal change plus bound-reference change plus gas
energy minus external input. The supplied desorption cost is independent of
the explicitly rejected nonzero kinetic barrier. Bound reference energy is
`-D*N`; gas energy contains supplied internal energy and the flux-Maxwellian
translation expectation. The patch area is applied once only in extensive
output. Residuals expose independent state/channel projection errors.

Stage arithmetic is rational until emitted states and cumulative channels are
projected to floats. The original-negative-Real, positive-underflow,
nonadvancing-state/time, finite-inventory and temperature support guards are
explicit. Exactly zero signed net balance is allowed without deleting gross
positive energy transfer.

This is source inspection only. No scientific module was imported and no
numerical model, test, oracle, producer, convergence study, old source audit or
network acquisition was performed. Numerical accuracy and trajectory/channel
verification belong to separate evidence. The reviewed scope is a manufactured
stationary single patch, zero activation barrier, constant supplied areal heat
capacity and finite nonnegative prescribed power. It does not qualify physical
water kinetics, a real foil, current-to-heating closure or owner integration.
