"""Freeze a bounded static source review without importing scientific code."""
import datetime as dt
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = Path('/workspace/Power-Flow/mhdlab/thermal_power_reference.py')
EXPECTED_SHA = '741ab61b45cc0440b2f133732df387e34bd7630d6b6d5eeb48be7f6e471f1e00'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

if (ROOT / 'completion.json').exists():
    raise RuntimeError('Refuse repeated static review freeze')
status = json.loads(Path('/workspace/research_work/mitl-upstream-status.json').read_text())
assert status['active_lease_owner'] == 'mitl-upstream-20261019T0544'
assert dt.datetime.fromisoformat(status['active_editing_lease_until_utc']) > dt.datetime.now(dt.timezone.utc)
assert sha(SOURCE) == EXPECTED_SHA
checks = [
    ('gross_positive_channels_at_zero_net_balance',
     'Exact Fraction stage amounts separately retain input, binding, internal, translation and wall energy. Net thermal cancellation does not zero their cumulative additions.'),
    ('signed_temperature_updates',
     'Thermal increments are signed (input minus wall debit)/areal heat capacity. Exact zero is allowed; a nonzero increment that cannot change the float temperature rejects. No clipping appears.'),
    ('joint_state_evolution',
     'Coverage and temperature are independently advanced through all four RK4 stages. No analytic N-to-T relation or old evolution method is called.'),
    ('power_jump_endpoint_rule',
     'Each segment passes its own constant power to all four stages, including its final stage. The next segment uses its new power and carries forward the same evolved N/T and cumulative state.'),
    ('finite_support_and_single_boundary_state',
     'Segments must exactly cover [0,duration] with float-equal adjacency and no gap or overlap. Each shared boundary is sampled only after the preceding segment. Prescribed input rejects times outside support.'),
    ('time_representation',
     'Logical step times use exact rational start+(stop-start)*step/steps. Nearest-float sample times must advance; segment index/step preserve the logical coordinate. No held or extrapolated power tail is created.'),
    ('negative_exact_Real_and_positive_underflow',
     '_real rejects the original negative value before float conversion, then rejects nonfinite values and positive input underflow. _time rejects loss of exact caller-supplied coordinates.'),
    ('output_representation_and_stage_domain',
     'Nonzero float projections reject underflow/overflow; positive cumulative stagnation, nonzero state stagnation, exhaustion and intermediate temperature/coverage domain exits reject. Exact Fraction stage products are retained until projection.'),
    ('energy_signs_and_references',
     'Wall thermal change minus external input plus total wall debit is reported as a residual. Bound reference is -D*N; gas receives supplied internal plus 2*k_B*T translation. Total residual is wall thermal plus bound-reference change plus gas minus input.'),
    ('SI_cost_and_area_once',
     'Per-parent eV costs use the exact declared elementary-charge conversion. Dynamics and channels are per area; patch area enters once in extensive sample output.'),
    ('explicit_zero_barrier_gate',
     '_problem rejects every nonzero activation_energy_ev before RHS or evolution. Nonnegative manufactured power and manufactured problem/schedule status are required.'),
    ('owned_scope_and_claims',
     'Only existing immutable problem/reservoir data classes are imported. No old source evolution, state chemistry, gap, host, owner transaction, physical material or observed-drive inference is called or claimed.')
]
notes = '''# Prescribed-power thermal-reference static review

The new `thermal_power_reference.py` was read in full at the frozen source hash
recorded in `completion.json`. No substantive source correctness issue was
identified in this bounded review, and no source changes were requested.

Gross input and desorption channels remain separate exact rational stage
quantities when their signed net thermal increment is zero. Temperature may
heat, cool or remain exactly unchanged without clipping; nonzero changes lost
in the float state reject. The four RK4 stages stay inside their own constant
power segment, including the final stage at its right endpoint. The following
segment starts with its new power and the carried-forward state. Exact finite
support, adjacency and advancing output times prevent a silent gap, overlap or
held power tail.

Energy signs use wall thermal change plus bound-reference change plus gas
energy minus external input. The supplied desorption cost is independent of
the explicitly rejected nonzero kinetic barrier. Bound reference energy is
`-D*N`; gas energy contains supplied internal energy and the flux-Maxwellian
translation expectation. The patch area is applied once only in extensive
output. Residuals expose independent state/channel projection errors.

Stage arithmetic is rational until emitted states and cumulative channels are
projected to floats. The original-negative-Real, positive-underflow,
nonadvancing-state/time, finite-inventory and temperature support guards are
explicit. Exactly zero signed net balance is allowed without deleting gross
positive energy transfer.

This is source inspection only. No scientific module was imported and no
numerical model, test, oracle, producer, convergence study, old source audit or
network acquisition was performed. Numerical accuracy and trajectory/channel
verification belong to separate evidence. The reviewed scope is a manufactured
stationary single patch, zero activation barrier, constant supplied areal heat
capacity and finite nonnegative prescribed power. It does not qualify physical
water kinetics, a real foil, current-to-heating closure or owner integration.
'''
(ROOT / 'review.md').write_text(notes)
report = {
    'schema': 'mitl-thermal-power-static-core-review-v1',
    'status': 'review_complete_no_substantive_issue_identified',
    'completed_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
    'reviewed_source_path': str(SOURCE), 'reviewed_source_sha256': EXPECTED_SHA,
    'full_new_module_read': True, 'source_changes_requested': False,
    'findings': [],
    'checks': [{'area': name, 'static_review_complete': True, 'finding': finding} for name, finding in checks],
    'numerical_models_or_tests_executed': False,
    'scientific_module_imported': False, 'producer_or_oracle_executed': False,
    'old_modules_or_audits_repeated': False, 'network_used': False,
    'public_source_edits_by_reviewer': False,
    'physical_parameters_validated': False, 'host_budget_accepted': False,
    'limits': ['Static source inspection only; no numerical accuracy or convergence certificate.',
               'Manufactured stationary single-patch zero-barrier reference with constant supplied areal heat capacity.',
               'Finite nonnegative prescribed power only; no observed drive, real-foil heating closure or physical chemistry qualification.',
               'No owner integration, gap evolution or host acceptance.'],
    'artifact_sha256': {p.name: sha(p) for p in sorted(ROOT.iterdir()) if p.is_file()}
}
(ROOT / 'completion.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'completion': str(ROOT / 'completion.json'), 'completion_sha256': sha(ROOT / 'completion.json'),
                  'reviewed_source_sha256': EXPECTED_SHA, 'status': report['status'],
                  'numerical_models_or_tests_executed': False}, indent=2))
