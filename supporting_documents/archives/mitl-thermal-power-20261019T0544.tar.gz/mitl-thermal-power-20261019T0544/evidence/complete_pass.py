"""Root-owned completion of the manufactured zero-barrier power reference.

Draft only. Reuses pinned pure metadata validation and reads actual archive
bytes; it does not run tests, producers, oracles, source requests or owner code.
"""
import datetime
import fcntl
import hashlib
import importlib
import json
import os
from pathlib import Path,PurePosixPath
import re
import subprocess
import tarfile

WORK=Path(__file__).resolve().parent
REPO=Path('/workspace/Power-Flow')
OUT=Path('/workspace/handoffs/mitl-thermal-power-20261019T0544')
BASE='e38b819c77ccf9439c82732987e4551c722fbd2d'
PUBLIC={'mhdlab/thermal_power_reference.py','tests/test_thermal_power_reference.py',
    'tools/run_thermal_power_reference.py','configs/thermal_power_manufactured.json','docs/thermal_power_reference.md'}


def require(condition,message):
    if not condition:
        raise RuntimeError(message)


def sha(path):
    digest=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):
            digest.update(block)
    return digest.hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def relative(name):
    require(type(name) is str and name,'missing relative path')
    path=PurePosixPath(name)
    require(not path.is_absolute() and '..' not in path.parts and str(path)==name,'unsafe relative path')
    return path


def git(*arguments):
    return subprocess.check_output(['git',*arguments],cwd=REPO)


def clean_head(contract):
    head=contract['approved_head']
    require(type(head) is str and re.fullmatch('[0-9a-f]{40}',head),'root-approved final HEAD is pending')
    require(git('rev-parse','HEAD').decode().strip()==head,'final HEAD changed')
    require(git('branch','--show-current').decode().strip()=='research/flash-publication-foundation','wrong branch')
    require(not git('status','--porcelain').strip(),'repository must be clean')
    subprocess.run(['git','merge-base','--is-ancestor',BASE,head],cwd=REPO,check=True)
    require(set(git('diff','--name-only',BASE,head).decode().splitlines())==PUBLIC,'committed scope changed')
    for name,digest in contract['public_source_sha256'].items():
        require(sha(REPO/name)==digest==hashlib.sha256(git('show',head+':'+name)).hexdigest(),'public/commit bytes changed')
    return head


def verify_archive(contract):
    frozen=load(WORK/'frozen_delivery.json');delivery=load(WORK/'delivery_verification.json')
    verification=load(OUT/'verification.json')
    require(delivery['status']=='passed' and delivery['repository_clean'] is True
        and delivery['input_code_output_bindings_verified'] is True and delivery['unsafe_or_duplicate_members']==0,'delivery has not passed')
    for key in ['folder','archive','sha256','bytes','source_commit','base_commit','manifest_sha256','verification_sha256']:
        require(delivery[key]==frozen[key],'delivery/freeze association changed')
    require(delivery['folder']==str(OUT) and delivery['source_commit']==verification['source_commit']==contract['approved_head']
        and delivery['base_commit']==verification['base_commit']==BASE,'delivery identity changed')
    require(verification['schema']=='mitl-thermal-power-reference-verification-v1'
        and verification['package_kind']=='patch_over_exact_complete_baseline','package contract changed')
    require(delivery['complete_baseline_checkout_required'] is True and delivery['source_subset_standalone'] is False
        and delivery['empty_initializer_added'] is False,'baseline dependency qualification changed')
    require(delivery['reference_test_oracle_or_old_suites_reexecuted'] is False
        and delivery['portable_execution_performed'] is False,'unexpected packaging execution')
    archive=Path(delivery['archive'])
    require(archive==OUT.with_suffix('.tar.gz') and sha(archive)==delivery['sha256']
        and archive.stat().st_size==delivery['bytes'],'actual archive changed')
    hashes={};seen=set();allowed={'evidence/'+str(relative(name)) for name in verification['allowed_figure_paths']}
    with tarfile.open(archive,'r:gz') as stream:
        for member in stream:
            path=PurePosixPath(member.name)
            require(not path.is_absolute() and '..' not in path.parts and path.parts and path.parts[0]==OUT.name,'unsafe archive path')
            require(member.name not in seen and not member.issym() and not member.islnk(),'duplicate/linked archive member')
            seen.add(member.name)
            if member.isdir():
                continue
            require(member.isfile() and len(path.parts)>1,'nonregular archive payload')
            name=str(PurePosixPath(*path.parts[1:]));parts=relative(name).parts
            require(name not in hashes and not any(part in {'source-local','fulltexts','raw-fulltexts','__pycache__','.venv','.pytest_cache','fixtures','test-fixtures'} for part in parts),'excluded/duplicate payload')
            require(PurePosixPath(name).suffix.lower() not in {'.pdf','.png','.jpg','.jpeg','.tif','.tiff'} or name in allowed,'unlisted source image/fulltext')
            data=stream.extractfile(member).read();hashes[name]=hashlib.sha256(data).hexdigest()
            require((OUT/name).is_file() and not (OUT/name).is_symlink() and sha(OUT/name)==hashes[name],'archive/folder bytes differ')
    manifest=load(OUT/'manifest.sha256.json')
    require(set(hashes)==set(manifest)|{'manifest.sha256.json'} and all(hashes[name]==digest for name,digest in manifest.items()),'archive manifest mismatch')
    require(len(manifest)==delivery['manifest_entries'] and len(hashes)==delivery['actual_archive_regular_files'],'archive counts changed')
    require(sha(OUT/'manifest.sha256.json')==delivery['manifest_sha256'] and sha(OUT/'verification.json')==delivery['verification_sha256'],'manifest/verification pin changed')
    require({name[7:] for name in hashes if name.startswith('source/')}==PUBLIC|{'README.md','requirements.txt'}
        and 'source/mhdlab/__init__.py' not in hashes,'public/wrapper source scope changed')
    require(delivery['public_files_byte_identical']==5 and delivery['packaging_wrappers']==2,'public/wrapper count changed')
    for name,digest in contract['public_source_sha256'].items():
        require(hashes['source/'+name]==digest,'archived public bytes changed')
    require(hashes['thermal-power-reference.patch']==hashlib.sha256(git('diff','--binary',BASE,contract['approved_head'])).hexdigest(),'patch does not match final commit')
    original_hashes=dict(hashes);restored={}
    for projection in reversed(load(OUT/'portable_path_projections.json')):
        name=projection['path'];relative(name)
        data=restored.get(name,(OUT/name).read_bytes())
        require(hashlib.sha256(data).hexdigest()==projection['portable_sha256'],'portable projection changed')
        replacement=projection['replacement'].encode()
        require(data.count(replacement)==projection['replacements'],'portable projection count changed')
        data=data.replace(replacement,bytes.fromhex(projection['source_prefix_hex']))
        require(hashlib.sha256(data).hexdigest()==projection['original_sha256'],'original projection pin changed')
        restored[name]=data;original_hashes[name]=projection['original_sha256']
    for item in verification['copied_input_sha256']:
        require(original_hashes[item['archive']]==item['sha256']==sha(item['source']),'copied original input changed')
    return delivery,verification,original_hashes


def verify_metadata(contract,verification,archive_hashes):
    for name,digest in contract['metadata_helpers_sha256'].items():
        require(sha(WORK/relative(name))==digest,'pure metadata helper changed')
    freezer=importlib.import_module('freeze_delivery')
    require(Path(freezer.__file__).resolve()==WORK/'freeze_delivery.py','wrong metadata helper imported')
    require(freezer.REPORT_PATHS==contract['record_paths']==verification['record_paths'],'report roles changed')
    records={}
    for role,name in contract['record_paths'].items():
        path=WORK/relative(name);digest=contract['record_sha256'][role]
        require(sha(path)==digest==verification['record_sha256'][role]==archive_hashes['evidence/'+name],'saved report bytes changed: '+role)
        records[role]=load(path)
        require(records[role]==verification['records'][role],'saved report declaration changed')
    # This existing helper checks saved metadata/bytes only, never numerical work.
    declared=freezer.verify_contracts(records,verification['input_contract'])
    require(declared['results']==contract['result_values']==verification['results'],'qualified result fields changed')
    require(declared['allowed_figure_paths']==verification['allowed_figure_paths'],'allowed figure scope changed')
    require(declared['source_version_relationships']==verification['source_version_relationships'],'source-version qualification changed')
    require(records['tests_completion']['new_core_tests_passed']==37,'new targeted test count changed')
    oracle=records['oracle_completion'];selection=records['selection']
    require(oracle['all_checks_passed'] is True and oracle['status']=='passed','oracle is not complete')
    require(selection.get('selected') is True or str(selection.get('status','')).startswith('selected'),'next selection is only conditional')
    require(type(selection.get('selected_task')) is str and selection['selected_task'].strip(),'next task missing')
    require(load(OUT/'next_task.json')['task']==verification['next_task']==selection['selected_task'],'next task association changed')
    return records


def atomic_write(path,data):
    temporary=path.with_name(path.name+'.new')
    require(not temporary.exists(),'unresolved temporary file exists')
    with temporary.open('xb') as stream:
        stream.write(data);stream.flush();os.fsync(stream.fileno())
    os.replace(temporary,path)


def main():
    contract_path=WORK/'completion-preparation/contract.json';contract=load(contract_path)
    require(contract['schema']=='mitl-thermal-power-completion-contract-v1'
        and contract['ready_for_root_execution'] is True and contract['pending']==[],'completion contract is pending')
    require(set(contract['public_source_sha256'])==PUBLIC and set(contract['record_paths'])==set(contract['record_sha256']),'contract scope changed')
    for mapping in ['public_source_sha256','metadata_helpers_sha256','record_sha256']:
        require(all(type(value) is str and re.fullmatch('[0-9a-f]{64}',value) for value in contract[mapping].values()),'final byte pins are pending')
    status_path=WORK.parent/'mitl-upstream-status.json'
    with (WORK.parent/'mitl-upstream-status.lock').open('a+') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        before=status_path.read_bytes();status=json.loads(before);lease=load(WORK/'lease.json')
        now=datetime.datetime.now(datetime.timezone.utc)
        require(status['active_lease_owner']==lease['pass_id']==WORK.name
            and datetime.datetime.fromisoformat(status['active_editing_lease_until_utc'])>now,'lease changed or expired')
        require(status['last_complete_commit']==lease['baseline_commit']==BASE and status['handoff']==lease['prior_handoff']
            and not (WORK/'completion.json').exists(),'prior checkpoint changed or completion replay attempted')
        remaining=[json.loads(json.dumps(item)) for item in status['next_work'] if 2<=item['priority']<=7]
        require([item['priority'] for item in remaining]==[2,3,4,5,6,7],'prior queue priorities changed')
        changed={'last_complete_commit','last_completed_pass_id','last_update_utc','handoff','handoff_sha256','handoff_bytes','handoff_document',
            'active_lease_owner','active_editing_lease_until_utc','reserved_paths','active_completed_subtasks','active_phase',
            'last_verified_suite','next_work','verification_history','prior_handoffs','completed_milestones','manufactured_thermal_power_reference'}
        preserved=json.loads(json.dumps({key:value for key,value in status.items() if key not in changed}))
        head=clean_head(contract);delivery,verification,archive_hashes=verify_archive(contract)
        records=verify_metadata(contract,verification,archive_hashes)
        clean_head(contract);now=datetime.datetime.now(datetime.timezone.utc)
        require(datetime.datetime.fromisoformat(status['active_editing_lease_until_utc'])>now,'lease expired during verification')
        history=status.setdefault('verification_history',[]);prior=status.setdefault('prior_handoffs',[])
        if status['handoff'] not in prior:
            prior.append(status['handoff'])
        if not any(item['pass_id']==status['last_completed_pass_id'] for item in history):
            history.append({'pass_id':status['last_completed_pass_id'],'commit':status['last_complete_commit'],
                'handoff':status['handoff'],'handoff_sha256':status['handoff_sha256'],'verification':status['last_verified_suite']})
        selection=records['selection']
        status.update(last_complete_commit=head,last_completed_pass_id=WORK.name,last_update_utc=now.isoformat(),
            handoff=delivery['archive'],handoff_sha256=delivery['sha256'],handoff_bytes=delivery['bytes'],
            handoff_document=str(OUT/'systems-mitl-thermal-power-reference-10192026.md'),active_lease_owner=None,
            active_editing_lease_until_utc=None,reserved_paths=[],active_completed_subtasks=[],
            active_phase='Completed manufactured zero-barrier prescribed-power reference; fresh published magnetic-gap evidence recovery selected next')
        status['last_verified_suite']={**verification['results'],'scope':'New zero-barrier prescribed-power reference,37 new targeted tests,single saved batch and independent integrating-factor/channel oracle; no earlier numerical replay or physical acceptance',
            'verification_record':str(OUT/'verification.json'),'delivery_manifest_entries':delivery['manifest_entries'],
            'public_files_byte_identical':5,'packaging_wrappers':2,'post_freeze_commands':str(WORK/'commands.jsonl')}
        status['manufactured_thermal_power_reference']={'core':str(REPO/'mhdlab/thermal_power_reference.py'),
            'public_source_sha256':contract['public_source_sha256'],'parameter_status':'manufactured','qualified_activation_energy_ev':0,
            'record_paths':{role:str(WORK/name) for role,name in contract['record_paths'].items()},'record_sha256':contract['record_sha256'],
            'new_core_tests_passed':37,'physical_parameters_adopted':0,'host_budget_accepted':False,
            'source_history_feedback_installed':False,'actual_flash_run':False,'physical_spectra_calculated':False,
            'nonzero_activation_forced_branch':{'qualified':False,'separate_gate':True,
                'required':'A fresh independently verified high-precision forced coupled-IVP reference with per-channel and precision/step checks; the zero-barrier oracle does not qualify it.'},
            'limits':'Manufactured stationary single patch,constant supplied areal heat capacity,finite nonnegative power schedule and zero activation barrier only. Input and separate gross outgoing channels remain explicit; no real foil/water,material/phase,host,gap,CR or MHD coupling is inferred.'}
        status['next_work']=[{'priority':1,'task':selection['selected_task'],
            'selection':str(WORK/contract['record_paths']['selection']),'selection_sha256':contract['record_sha256']['selection'],
            'limits':'Fresh bounded published magnetic-gap recovery only; forced nonzero-barrier kinetics and all physical/owner acceptance remain separately gated.'}]+remaining
        require(status['next_work'][1:]==remaining and all(status[key]==value for key,value in preserved.items()),'earlier evidence,gates or queue changed')
        status['completed_milestones'].extend([
            'New manufactured zero-barrier prescribed-power operator preserves exact finite schedules and breakpoint stage semantics,independent gross input/removal/internal/translation channels,and signed thermal/reference residuals;37 new focused tests passed once.',
            'One saved four-case/seven-trajectory power batch is qualified by a fresh independent integrating-factor/channel oracle and finite refinement. Exact positive gross transfers can coexist with zero instantaneous net thermal change; no forced constant-temperature trajectory is inferred.',
            f'Five new public files through {head[:7]} and actual archive {delivery["sha256"]} require the complete e38b819 baseline; no standalone,portable,old-suite or physical parameter acceptance claim.'
        ])
        history.append({'pass_id':WORK.name,'commit':head,'handoff':delivery['archive'],'handoff_sha256':delivery['sha256'],'verification':status['last_verified_suite']})
        encoded=(json.dumps(status,indent=2,allow_nan=False)+'\n').encode()
        result={'utc':now.isoformat(),'event':'completed_and_next_selected','pass_id':WORK.name,'commit':head,
            'archive':delivery['archive'],'archive_sha256':delivery['sha256'],'archive_bytes':delivery['bytes'],
            'actual_archive_reverified':True,'public_scope_sha256':contract['public_source_sha256'],
            'completion_contract_sha256':sha(contract_path),'record_sha256':contract['record_sha256'],
            'new_core_tests_passed':37,'independent_power_oracle_passed':True,'qualified_activation_energy_ev':0,
            'forced_nonzero_activation_qualified':False,'physical_parameters_adopted':0,'host_budget_accepted':False,
            'actual_flash_run':False,'portable_executions_performed':False,'old_suites_or_producers_repeated':False,
            'exact_commands':str(WORK/'commands.jsonl'),'status_before_sha256':hashlib.sha256(before).hexdigest(),
            'status_after_sha256':hashlib.sha256(encoded).hexdigest(),'lease_released':True,'reserved_paths':[],
            'next':selection['selected_task'],'next_selection_sha256':contract['record_sha256']['selection']}
        require(not (WORK/'status-before-completion.json').exists(),'prior completion snapshot exists')
        (WORK/'status-before-completion.json').write_bytes(before)
        atomic_write(status_path,encoded)
        atomic_write(WORK/'completion.json',(json.dumps(result,indent=2,allow_nan=False)+'\n').encode())
        with (WORK.parent/'mitl-upstream-journal.jsonl').open('a') as stream:
            stream.write(json.dumps(result,allow_nan=False)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':
    main()
