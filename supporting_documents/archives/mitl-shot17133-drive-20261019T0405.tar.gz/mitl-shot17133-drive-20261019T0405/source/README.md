# Shot 17133 published-current display recovery

The nine named public files are byte-identical to commit `bea74a0e08bb531cf790a73bc67f97eb1d6de97b`.
Three explicit packaging wrappers provide this readme, dependency list and an
empty package initializer. No portable test environment or additional recovery
execution is claimed for this packaging step.

The CSV contains published encoded display vertices. It is a reconstructed
current trace, not original acquisition data. Display-envelope bounds are not
measurement uncertainty. The source time coordinate is retained; a physical
trigger, pre-pulse zero and tail are not supplied or extrapolated.

From this source directory, the existing inspector can be run explicitly:

```sh
python tools/inspect_current_drive.py --csv data/dissertation/shot_17133_current.csv --provenance data/dissertation/shot_17133_current.json --preserve-source-axis
```

That command is provided for the recipient; packaging does not execute it.
Recovery requires the separately obtained source dissertation PDF identified by
its hash in the sidecar. The full PDF and raw extracted page PDF are excluded.
QA figures and retained source geometry accompany the independent readback.
Read `docs/shot_17133_current_recovery.md` before using the trace as a drive.
No material law, circuit, trigger alignment, MHD result or spectral agreement is
established by this recovery.
