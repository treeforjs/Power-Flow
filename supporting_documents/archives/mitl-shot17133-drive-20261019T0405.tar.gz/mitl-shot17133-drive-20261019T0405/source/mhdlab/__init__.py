"""Compact published-current input and inspection subset."""
