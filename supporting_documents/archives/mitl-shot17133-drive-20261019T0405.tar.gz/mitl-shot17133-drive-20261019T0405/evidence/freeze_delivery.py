"""Freeze completed shot-17133 recovery evidence without rerunning recovery."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tarfile

from prepare_delivery import WORK, REPO, BASE, OUT, PDF_SHA256, clean_head, dataset_bindings, load, save, sha

TEXT_SUFFIXES = {'.py', '.json', '.jsonl', '.log', '.xml', '.md', '.txt', '.patch', '.sha256', '.yaml', '.csv'}
EVIDENCE_DIRS = ('recovery', 'independent-verification', 'next-upstream-selection')


def excluded(relative):
    parts = Path(relative).parts
    return (any(p in {'__pycache__', '.pytest_cache', '.venv', 'source-local'} or p.startswith('pytest_') for p in parts)
            or Path(relative).name in {'smtrevor_1.pdf', 'page190.pdf'} or Path(relative).suffix == '.pyc')


def main():
    payload = WORK/'delivery-preparation/payload'
    preparation = load(payload/'preparation.json')
    head = clean_head(preparation['source_commit'])
    assert preparation['base_commit'] == BASE
    assert not OUT.exists() and not OUT.with_suffix('.tar.gz').exists()
    listing = load(payload/'source_file_list.json')
    public, wrappers = listing['byte_identical_public_files'], listing['packaging_wrappers']
    assert len(public) == 9 and len(wrappers) == 3
    assert {str(p.relative_to(payload/'source')) for p in (payload/'source').rglob('*') if p.is_file()} == set(public)|set(wrappers)
    for name in public:
        assert (payload/'source'/name).read_bytes() == (REPO/name).read_bytes(), name
    dataset = preparation['dataset']
    assert dataset_bindings(REPO/dataset['csv_path'], REPO/dataset['metadata_path'], REPO/dataset['producer_path']) == dataset
    completion_path = WORK/'independent-verification/completion.json'
    completion = load(completion_path)
    assert completion['schema'] == 'mitl-independent-shot17133-recovery-completion-v1'
    assert completion['all_checks_passed'] is True and completion['status'] == 'passed'
    expected_controls = {'native_vertices': 134, 'retained_vertices': 132, 'numeric_csv_cells_checked': 1320,
        'tick_anchors_checked': 17, 'loader_knot_queries_checked': 132, 'loader_interior_queries_checked': 131,
        'inspector_cli_runs': 1, 'outside_support_rejections': 4, 'source_guard_rejections': 3,
        'successful_recovery_replays': 0}
    assert all(type(completion[k]) is int and completion[k] == value for k, value in expected_controls.items())
    assert completion['old_suites_repeated'] is False
    assert set(completion['public_source_sha256']) == {dataset['producer_path'], dataset['csv_path'], dataset['metadata_path']}
    recovery = load(WORK/'recovery/recovery_record.json')
    assert recovery['schema'] == 'mitl-shot17133-vector-recovery-record-v1'
    assert recovery['input_pdf_sha256'] == PDF_SHA256 and recovery['retained_vertices'] == dataset['retained_rows']
    assert recovery['canonical_current_path_sha256'] == dataset['vector_path']['canonical_geometry_sha256']
    assert recovery['native_vertices'] == dataset['vector_path']['encoded_vertices']
    assert recovery['decoded_page_content_sha256'] == dataset['source']['decoded_page_content_stream_sha256']
    assert recovery['successful_new_recovery_runs'] == 1 and recovery['old_recovery_or_numerical_history_runs'] == 0
    assert recovery['QA_inspection']['native_page_and_two_panel_plot_viewed'] is True
    for name, digest in recovery['public_sha256'].items():
        assert sha(REPO/name) == digest
    for name, digest in recovery['work_artifact_sha256'].items():
        if not excluded(Path('recovery')/name):
            assert sha(WORK/'recovery'/name) == digest
    selection = load(WORK/'next-upstream-selection/selection.json')
    assert selection['status'].startswith('selected')
    for mapping in ('source_sha256', 'public_source_sha256', 'reviewed_source_sha256'):
        for name, digest in completion.get(mapping, {}).items():
            path = Path(name) if Path(name).is_absolute() else REPO/name
            assert sha(path) == digest, name
    for name, digest in completion.get('artifact_sha256', {}).items():
        path = Path(name) if Path(name).is_absolute() else WORK/name
        assert sha(path) == digest, name
    shutil.copytree(payload, OUT)
    evidence = OUT/'evidence'
    evidence.mkdir()
    try:
        active_log = Path(os.readlink('/proc/self/fd/1')).resolve()
    except OSError:
        active_log = None
    root_files = []
    for path in WORK.iterdir():
        if path.is_file() and path.suffix in TEXT_SUFFIXES and path.resolve() != active_log:
            assert not path.is_symlink()
            shutil.copyfile(path, evidence/path.name)
            root_files.append(path.name)
    omitted = []
    for folder in EVIDENCE_DIRS:
        for path in (WORK/folder).rglob('*'):
            relative = path.relative_to(WORK)
            if path.is_file() and excluded(relative):
                omitted.append({'path': str(relative), 'sha256': sha(path), 'bytes': path.stat().st_size,
                                'reason': 'Raw page PDF, prospective source-local panel or cache excluded from this compact delivery.'})
            elif path.is_file():
                assert not path.is_symlink() and sha(path) != PDF_SHA256
                target = evidence/relative
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(path, target)
    prefix = bytes.fromhex('2f6f70742f636f6465782f72756e74696d65732f636f6465782d7072696d6172792d72756e74696d652f646570656e64656e636965732f707974686f6e')
    replacement = b'[runtime Python directory]'
    projections = []
    for path in evidence.rglob('*'):
        if path.is_file() and path.suffix in TEXT_SUFFIXES:
            data = path.read_bytes()
            if prefix in data:
                assert replacement not in data
                projected = data.replace(prefix, replacement)
                path.write_bytes(projected)
                projections.append({'path': str(path.relative_to(OUT)), 'original_sha256': hashlib.sha256(data).hexdigest(),
                    'portable_sha256': sha(path), 'replacements': data.count(prefix), 'source_prefix_hex': prefix.hex(),
                    'replacement': replacement.decode(), 'scope': 'Machine runtime directory prefix only; local raw records remain unchanged.'})
    save(OUT/'portable_path_projections.json', projections)
    save(OUT/'excluded_evidence.json', omitted)
    with (OUT/'shot17133-drive.patch').open('wb') as stream:
        subprocess.run(['git', 'diff', '--binary', BASE, head], cwd=REPO, stdout=stream, check=True)
    next_task = selection.get('selected_task', selection.get('task'))
    assert isinstance(next_task, str) and next_task.strip()
    results = {'new_dataset_rows': dataset['retained_rows'], 'csv_column_count': len(dataset['columns']),
        'independent_readback_passed': True, 'portable_executions_performed': False,
        'new_dataset_loader_and_extrapolation_controls_passed': True, **expected_controls,
        'packaging_source_recovery_repeated': False, 'old_recoveries_repeated': False, 'old_test_suites_repeated': False,
        'full_source_pdf_included': False, 'raw_page_pdf_included': False, 'prospective_source_local_panels_included': False}
    record = {'schema': 'mitl-shot17133-drive-recovery-verification-v1', 'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'source_commit': head, 'base_commit': BASE, 'dataset': dataset, 'results': results,
        'commits': subprocess.check_output(['git', 'log', '--reverse', '--format=%H %s', BASE+'..'+head], cwd=REPO, text=True).splitlines(),
        'independent_completion': completion, 'recovery_record': recovery,
        'independent_completion_sha256': sha(completion_path), 'selection_sha256': sha(WORK/'next-upstream-selection/selection.json'),
        'command_snapshot': {'scope': 'All completed pass records before freezing; later freeze/verification/completion records remain local.',
                             'copied_root_files': sorted(root_files)},
        'public_files_byte_identical': len(public), 'packaging_wrappers': len(wrappers),
        'limits': ['Published display vertices and source-coordinate current only; original acquisition samples and physical trigger are unavailable.',
            'Digitization envelopes describe display geometry, not measurement uncertainty or bounds between retained vertices.',
            'No padding, extrapolation, smoothing, RL fit, derivative or source-zero assumption is supplied.',
            'No new MHD/source/transport/CR result, absolute calibration or physical thermal/material closure is inferred.',
            'The compact package is assembled without a new portable environment or an extra inspector/recovery execution.'],
        'next_task': next_task}
    save(OUT/'verification.json', record)
    save(OUT/'next_task.json', {'task': next_task, 'selection_evidence': 'evidence/next-upstream-selection/selection.json'})
    (OUT/'systems-mitl-shot17133-drive-10192026.md').write_text(f'''# Shot 17133 published average-current recovery

The public subset is pinned to `{head}`; the patch starts at `{BASE}`.
Nine named public files are byte-identical. Three explicit wrappers provide
the readme, dependency list and empty package initializer. No additional portable
environment or standalone inspector execution is claimed for packaging.

The newly recovered Fig.C.19 trace retains {dataset['retained_rows']} published
display vertices. The original source-coordinate time, signed current, explicit
SI conversion, displayed stroke envelope and legend-occlusion flags remain in
the CSV and sidecar. These are reconstructed drawing commands, not original
acquisition samples. The source PDF and raw extracted page PDF are excluded;
their identity remains recorded with source geometry and QA render/figure pins.

Independent source readback and the new dataset loader/outside-support controls
are preserved with exact commands, exits and hashes. Failed attempts and focused
corrections, if any, remain in the evidence. No old recovery, old test suite or
source producer was repeated by packaging. QA figures are scientific artifacts,
not a new waveform fit. Archive-only machine-directory projections are reversible
and preserve original hashes; raw local records remain unchanged.

The published time axis does not recover a physical trigger. No pre-pulse zero,
tail, extrapolation, material law, circuit fit, MHD solution or spectral agreement
is inferred. A physical drive consumer must document its alignment and support.

Next selected task: {next_task}
Prospective raster panels for that separate task are excluded from this archive.
''')
    manifest = {str(p.relative_to(OUT)): sha(p) for p in OUT.rglob('*') if p.is_file() and p.name != 'manifest.sha256.json'}
    save(OUT/'manifest.sha256.json', manifest)
    words = [bytes.fromhex(x).decode() for x in ('6f70656e6169', '63686174677074', '636c61756465', '636f646578')]
    prohibited = re.compile(r'\b(?:'+'|'.join(words)+r')\b', re.I)
    for path in OUT.rglob('*'):
        assert not path.is_symlink()
        if path.is_file():
            assert sha(path) != PDF_SHA256 and not excluded(path.relative_to(OUT))
            if path.suffix in TEXT_SUFFIXES:
                assert not prohibited.search(path.read_text()), str(path)
    archive = OUT.with_suffix('.tar.gz')
    with tarfile.open(archive, 'w:gz') as tar:
        tar.add(OUT, arcname=OUT.name)
    frozen = {'folder': str(OUT), 'archive': str(archive), 'sha256': sha(archive), 'bytes': archive.stat().st_size,
        'source_commit': head, 'base_commit': BASE, 'manifest_entries': len(manifest),
        'public_files_byte_identical': len(public), 'packaging_wrappers': len(wrappers),
        'manifest_sha256': sha(OUT/'manifest.sha256.json'), 'verification_sha256': sha(OUT/'verification.json')}
    save(WORK/'frozen_delivery.json', frozen)
    print(json.dumps(frozen, indent=2))


if __name__ == '__main__':
    main()
