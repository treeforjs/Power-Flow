"""Prepare a compact public shot-17133 recovery subset after the final commit."""
import argparse
import ast
import csv
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess

WORK = Path(__file__).resolve().parent
REPO = Path('/workspace/Power-Flow')
BASE = '079bddf9f81021ee4f3d79c42011185511d53747'
HEAD = 'bea74a0e08bb531cf790a73bc67f97eb1d6de97b'
OUT = Path('/workspace/handoffs/mitl-shot17133-drive-20261019T0405')
PDF_SHA256 = '1d7b1f9c191a37e94f1cc3634587750f1af35b07eb13e0b94c60f3da47495ed7'
COMMON_PUBLIC = ('docs/dissertation_recovery.md', 'docs/flash_drive_inputs.md',
                 'docs/shot_17133_current_recovery.md', 'data/dissertation/recovery_manifest.yaml',
                 'mhdlab/drive_trace.py', 'tools/inspect_current_drive.py')
NEW_PUBLIC = ('tools/recover_dissertation_drive_17133.py', 'data/dissertation/shot_17133_current.csv',
              'data/dissertation/shot_17133_current.json')


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024*1024), b''):
            digest.update(block)
    return digest.hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False)+'\n')


def clean_head(expected):
    assert re.fullmatch('[0-9a-f]{40}', expected) and expected == HEAD
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == expected
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=REPO, text=True).strip()
    subprocess.run(['git', 'merge-base', '--is-ancestor', BASE, expected], cwd=REPO, check=True)
    return expected


def dataset_bindings(csv_path, metadata_path, producer_path):
    metadata = load(metadata_path)
    assert metadata['schema_version'] == 1 and metadata['status'] == 'reconstructed_published_vector_polyline'
    assert metadata['source']['pdf_sha256'] == PDF_SHA256 and metadata['source']['figure'] == 'C.19'
    assert metadata['source']['printed_page'] == 165 and metadata['source']['pdf_page'] == 190
    assert metadata['experiment']['shot'] == 17133 and metadata['experiment']['foil_material'] == 'SS304'
    assert metadata['experiment']['foil_thickness_um'] == 200
    assert metadata['observable']['raw_oscilloscope_data'] is False
    assert metadata['observable']['trigger_or_current_start_offset_recovered'] is False
    assert metadata['observable']['time_origin_reference'] is None
    output = metadata['output']
    assert output['csv_filename'] == csv_path.name and output['csv_sha256'] == sha(csv_path)
    assert output['generator'] == str(producer_path.relative_to(REPO)) and output['generator_sha256'] == sha(producer_path)
    with csv_path.open(newline='') as stream:
        reader = csv.DictReader(stream)
        columns = reader.fieldnames
        rows = list(reader)
    assert columns == output['columns'] and len(rows) == output['samples'] and len(rows) >= 2
    return {'csv_path': str(csv_path.relative_to(REPO)), 'metadata_path': str(metadata_path.relative_to(REPO)),
            'producer_path': str(producer_path.relative_to(REPO)), 'csv_sha256': sha(csv_path),
            'metadata_sha256': sha(metadata_path), 'producer_sha256': sha(producer_path),
            'retained_rows': len(rows), 'columns': columns, 'source': metadata['source'],
            'experiment': metadata['experiment'], 'observable': metadata['observable'],
            'vector_path': metadata['vector_path'], 'status': metadata['status'], 'schema_version': metadata['schema_version'],
            'limits': metadata['limits']}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--expected-head', required=True)
    parser.add_argument('--producer', required=True)
    parser.add_argument('--csv', required=True)
    parser.add_argument('--metadata', required=True)
    args = parser.parse_args()
    clean_head(args.expected_head)
    new = (args.producer, args.csv, args.metadata)
    assert new == NEW_PUBLIC
    for name in new+COMMON_PUBLIC:
        path = PurePosixPath(name)
        assert not path.is_absolute() and path.as_posix() == name and '..' not in path.parts
        assert path.parts[0] in {'tools', 'data', 'docs', 'mhdlab'}
        assert (REPO/name).is_file() and not (REPO/name).is_symlink()
    assert args.producer.startswith('tools/') and args.producer.endswith('.py')
    assert args.csv.startswith('data/dissertation/') and args.csv.endswith('.csv')
    assert args.metadata.startswith('data/dissertation/') and args.metadata.endswith('.json')
    public = sorted(set(new+COMMON_PUBLIC))
    assert len(public) == 9
    for name in (args.producer, 'mhdlab/drive_trace.py', 'tools/inspect_current_drive.py'):
        for node in ast.walk(ast.parse((REPO/name).read_text())):
            if isinstance(node, ast.ImportFrom) and node.module and node.module.startswith(('mhdlab.', 'tools.')):
                assert node.module.replace('.', '/')+'.py' in public, node.module
    bindings = dataset_bindings(REPO/args.csv, REPO/args.metadata, REPO/args.producer)
    payload = WORK/'delivery-preparation/payload'
    assert not payload.exists()
    payload.mkdir(parents=True)
    for name in public:
        target = payload/'source'/name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(REPO/name, target)
    wrappers = {
        'mhdlab/__init__.py': '"""Compact published-current input and inspection subset."""\n',
        'requirements.txt': 'numpy\nmatplotlib\npymupdf\n',
        'README.md': f'''# Shot 17133 published-current display recovery

The nine named public files are byte-identical to commit `{args.expected_head}`.
Three explicit packaging wrappers provide this readme, dependency list and an
empty package initializer. No portable test environment or additional recovery
execution is claimed for this packaging step.

The CSV contains published encoded display vertices. It is a reconstructed
current trace, not original acquisition data. Display-envelope bounds are not
measurement uncertainty. The source time coordinate is retained; a physical
trigger, pre-pulse zero and tail are not supplied or extrapolated.

From this source directory, the existing inspector can be run explicitly:

```sh
python tools/inspect_current_drive.py --csv {args.csv} --provenance {args.metadata} --preserve-source-axis
```

That command is provided for the recipient; packaging does not execute it.
Recovery requires the separately obtained source dissertation PDF identified by
its hash in the sidecar. The full PDF and raw extracted page PDF are excluded.
QA figures and retained source geometry accompany the independent readback.
Read `docs/shot_17133_current_recovery.md` before using the trace as a drive.
No material law, circuit, trigger alignment, MHD result or spectral agreement is
established by this recovery.
''',
    }
    for name, body in wrappers.items():
        path = payload/'source'/name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(body)
    listing = {'byte_identical_public_files': public, 'packaging_wrappers': sorted(wrappers)}
    save(payload/'source_file_list.json', listing)
    (payload/'source-files.sha256').write_text(''.join(f'{sha(REPO/name)}  {name}\n' for name in public))
    (payload/'wrapper-files.sha256').write_text(''.join(f'{sha(payload/"source"/name)}  {name}\n' for name in sorted(wrappers)))
    save(payload/'preparation.json', {'source_commit': args.expected_head, 'base_commit': BASE,
          'dataset': bindings, 'portable_execution_performed': False,
          'public_source_sha256': {name: sha(REPO/name) for name in public}})
    print(json.dumps({'payload': str(payload), 'source_commit': args.expected_head,
                      'public_files': len(public), 'wrappers': len(wrappers), 'dataset_rows': bindings['retained_rows']}, indent=2))


if __name__ == '__main__':
    main()
