"""Check new drive documentation bindings and preserve prior manifest evidence."""
import hashlib
import json
from pathlib import Path
import subprocess
import yaml

repo = Path('/workspace/Power-Flow')
work = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
base = json.loads((work/'lease-claim.json').read_text())['base_commit']
name = 'data/dissertation/recovery_manifest.yaml'
before = yaml.safe_load(subprocess.check_output(['git', 'show', base+':'+name], cwd=repo))
after = yaml.safe_load((repo/name).read_text())
metadata = json.loads((repo/'data/dissertation/shot_17133_current.json').read_text())
targets = after['reconstruction_targets']
added = [item for item in targets if item['id'] == 'fig_c_19']
assert len(added) == 1 and len(targets) == len(before['reconstruction_targets'])+1
entry = added[0]
assert entry['source'] == metadata['source']['figure'].replace('C.19', 'Fig. C.19')
assert entry['shot'] == metadata['experiment']['shot'] == 17133
assert entry['plot_title_thickness_um'] == entry['caption_thickness_um'] == metadata['experiment']['foil_thickness_um'] == 200
artifact = entry['recovered_artifacts'][0]
assert artifact['status'] == 'vector_recovered'
assert artifact['csv_sha256'] == metadata['output']['csv_sha256'] == sha(repo/'data/dissertation'/artifact['file'])
for key in ('time_extent_ns', 'current_extent_A'):
    assert artifact[key] == metadata['output'][key]
assert artifact['time_origin_reference'] is None and artifact['breakdown_time_ns'] is None
assert artifact['gate_rectangle_time_bounds_ns'] == metadata['VUV_gate']['plotted_time_bounds_ns']

old_targets = {item['id']: item for item in before['reconstruction_targets']}
new_targets = {item['id']: item for item in targets if item['id'] != 'fig_c_19'}
assert old_targets.keys() == new_targets.keys()
changed = []
for key, old in old_targets.items():
    new = new_targets[key]
    if old != new:
        assert set(old) == set(new)
        assert all(old[field] == new[field] for field in old if field != 'still_pending')
        assert len(old['still_pending']) == len(new['still_pending'])
        pairs = [(a, b) for a, b in zip(old['still_pending'], new['still_pending']) if a != b]
        assert len(pairs) == 1 and 'recovered 17133' in pairs[0][0] and 'clock' not in pairs[0][1]
        assert 'timing registration' in pairs[0][1] and 'Fig. C.19' in pairs[0][1]
        changed.append(key)
assert len(changed) == 1
assert before['source'] == after['source']
for name in ('docs/shot_17133_current_recovery.md', 'docs/dissertation_recovery.md', 'docs/flash_drive_inputs.md'):
    contents = (repo/name).read_text()
    assert '17133' in contents and 'shot_17133_current' in contents
    assert 'clock' in contents and 'same-shot' in contents
report = {'schema': 'mitl-documentation-drive-binding-verification-v1', 'passed': True,
    'script_sha256': sha(__file__), 'base_commit': base,
    'manifest_sha256': sha(repo/'data/dissertation/recovery_manifest.yaml'),
    'new_drive_entry': 'fig_c_19', 'old_target_count': len(old_targets),
    'prior_targets_preserved_except_pending_drive_description': changed,
    'source_record_unchanged': True, 'new_artifact_and_clock_labels_verified': True,
    'source_evolution_or_old_recovery_run': False}
(work/'documentation-verification.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps(report, indent=2))
