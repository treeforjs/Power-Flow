"""Associate the newly recovered drive with its published heating context."""
import csv
import hashlib
import json
from pathlib import Path
import yaml

repo = Path('/workspace/Power-Flow')
work = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
metadata_path = repo / 'data/dissertation/shot_17133_current.json'
csv_path = repo / 'data/dissertation/shot_17133_current.csv'
m = json.loads(metadata_path.read_text())
assert m['source']['figure'] == 'C.19' and m['experiment']['shot'] == 17133
assert m['status'] == 'reconstructed_published_vector_polyline'
assert m['output']['csv_sha256'] == sha(csv_path)
with csv_path.open() as stream:
    rows = list(csv.DictReader(stream))
assert len(rows) == m['output']['samples']
peak = max(rows, key=lambda row: float(row['current_A']))
times = [float(row['time_ns']) for row in rows]
current = [float(row['current_A']) for row in rows]
bound = m['calibration']['digitization_bounds']
gate = m['VUV_gate']['plotted_time_bounds_ns']
occluded = sum(int(row['occluded_by_legend']) for row in rows)
stats = (f"The recovery retains {len(rows)} vertices over approximately "
    f"{min(times):.6g}–{max(times):.6g} ns. The largest retained current is "
    f"{float(peak['current_A'])/1e6:.6g} MA at {float(peak['time_ns']):.6g} ns; "
    f"{occluded} vertices lie inside the later legend's bounding rectangle. "
    f"The display bounds are approximately +/-{bound['time_plus_minus_ns']:.6g} ns "
    f"and +/-{bound['current_plus_minus_A']:.6g} A. The independent gate rectangle "
    f"spans approximately {gate[0]:.6g}–{gate[1]:.6g} ns. These are published "
    "display quantities, with physical trigger and simulation-clock alignment unresolved.")

paths = [repo / name for name in ('docs/shot_17133_current_recovery.md',
    'docs/dissertation_recovery.md', 'docs/flash_drive_inputs.md',
    'data/dissertation/recovery_manifest.yaml')]
before = {str(p.relative_to(repo)): sha(p) for p in paths}
prepared = {}
guide = paths[0].read_text()
needle = 'The shared ordinate is “Signal Height”'
assert guide.count(needle) == 1
prepared[paths[0]] = guide.replace(needle, stats+'\n\n'+needle)

text = paths[1].read_text()
old = ('The magnetic-field/current-density depth panels in Figs. 4.28 and 4.29, '
       'and the 17133 drive, remain unrecovered.')
assert text.count(old) == 1
text = text.replace(old, 'The magnetic-field/current-density depth panels in Figs. 4.28 and 4.29 remain unrecovered. '
    'The shot 17133 current display has since been recovered from Fig. C.19, as described below.')
old = 'Loading a trace does not install a FLASH boundary condition, infer a circuit voltage or restore the missing 17133 drive.'
assert text.count(old) == 1
text = text.replace(old, 'Loading a trace does not install a FLASH boundary condition, infer a circuit voltage or establish a missing physical timing reference.')
section = ('## Recovered shot 17133 current\n\n'
    'The [shot 17133 CSV](../data/dissertation/shot_17133_current.csv) and '
    '[provenance](../data/dissertation/shot_17133_current.json) recover the red current curve from '
    '**Fig. C.19, printed p. 165 / PDF p. 190**. The title and caption both identify a 200 um SS304 foil. '
    'This supplies same-shot current context for the legacy Figs. 4.28–4.30. '
    'It does not recover the original simulation drive file or register their separate clocks.\n\n'
    + stats + '\n\n'
    'See the [recovery guide](shot_17133_current_recovery.md) for reproduction, bounded SI queries and '
    'the distinction between source geometry, readout bounds and physical uncertainty. '
    'Shot 15210 remains a separate input.\n\n')
assert text.count('## Published estimates from Table 4.1') == 1
prepared[paths[1]] = text.replace('## Published estimates from Table 4.1', section+'## Published estimates from Table 4.1')

text = paths[2].read_text().replace('Inspect the recovered shot with an explicit choice of time coordinate:',
    'Inspect the default shot 15210 input with an explicit choice of time coordinate:')
old = ('Shot 15210 belongs to the VUV campaign. The legacy heating profiles in\n'
       'Figs. 4.28–4.30 used drive shot 17133. These inputs cannot be combined and labeled\n'
       'a same-shot reproduction. Their role is separate source/thermal benchmarking\n'
       'until a consistent heating drive and material setup are available.')
assert text.count(old) == 1
new = ('The separately recovered [shot 17133 current](../data/dissertation/shot_17133_current.csv) '
    'supplies the same-shot published drive context for legacy heating Figs. 4.28–4.30. '
    'Its [provenance](../data/dissertation/shot_17133_current.json) and '
    '[recovery guide](shot_17133_current_recovery.md) retain the finite support and timing limits. '
    'Select it explicitly; the command defaults above remain shot 15210.\n\n'
    '```sh\npython tools/inspect_current_drive.py --csv data/dissertation/shot_17133_current.csv '
    '--provenance data/dissertation/shot_17133_current.json --preserve-source-axis '
    '--json-out runs/current_17133/summary.json --plot runs/current_17133/current.png\n```\n\n'
    'The two shots remain distinct. Same-shot display recovery does not restore the original '
    'simulation drive, register the current and simulation clocks, validate the published '
    'current-density normalization or establish a same-shot thermal reproduction. '
    'Material, geometry and timing evidence are still required before an actual FLASH comparison.')
prepared[paths[2]] = text.replace(old, new)

text = paths[3].read_text()
assert 'id: fig_c_19' not in text
entry = {'id': 'fig_c_19', 'source': 'Fig. C.19', 'printed_page': 165, 'pdf_page': 190,
    'kind': 'electrical_trace', 'availability': 'published_only', 'digitization_status': 'partially_digitized',
    'quantities': ['Average Current [MA]', 'V_bank - L_0 dI/dt [MV]', 'VUV gate rectangle', 'normalized APD 2'],
    'shot': 17133, 'reported_material': 'SS304', 'plot_title_thickness_um': 200, 'caption_thickness_um': 200,
    'recovered_artifacts': [{'file': csv_path.name, 'metadata': metadata_path.name,
        'generator': 'tools/recover_dissertation_drive_17133.py', 'status': 'vector_recovered',
        'csv_sha256': sha(csv_path), 'content': f"{len(rows)} native vector vertices inside the displayed axes; no inserted endpoints or resampling",
        'original_units': {'time': 'ns', 'current': 'MA'}, 'SI_columns': {'time': 'time_s', 'current': 'current_A'},
        'time_extent_ns': m['output']['time_extent_ns'], 'current_extent_A': m['output']['current_extent_A'],
        'legend_covered_vertices': occluded, 'time_origin_reference': None,
        'gate_rectangle_time_bounds_ns': gate, 'breakdown_time_ns': None,
        'digitization_estimates': {'time_plus_minus_ns': bound['time_plus_minus_ns'],
            'current_plus_minus_A': bound['current_plus_minus_A'],
            'meaning': 'Half published stroke width plus maximum tick-fit residual; correlated display readout bounds, not physical uncertainty.'}}],
    'still_pending': ['Original current waveform, filtering and diagnostic calibration',
        'Original simulation drive input and current-to-simulation clock registration',
        'Voltage/APD curves and an independently established breakdown time'],
    'unresolved_metadata': ['The shared ordinate is Signal Height; current units are taken from its separate MA legend.',
        'The gate rectangle is not breakdown, a trigger or a simulation timing reference.',
        'Same shot as legacy heating Figs. 4.28–4.30; no complete thermal reproduction, electromagnetic normalization or Joule closure.']}
fragment = yaml.safe_dump([entry], sort_keys=False, allow_unicode=True, width=108)
assert text.count('source_conflicts:\n') == 1
text = text.replace('source_conflicts:\n', fragment+'source_conflicts:\n')
text = text.replace('and an encoded current polyline;', 'and encoded current polylines;')
old = '- original simulation arrays and a recovered 17133 drive history'
assert text.count(old) == 1
text = text.replace(old, '- original simulation arrays and original simulation drive input/timing registration (published 17133 current recovered from Fig. C.19)')
old = ('- Figures 4.28–4.30 are legacy simulation temperature profiles driven by shot 17133; the separately recovered\n'
       '    current polyline is shot 15210. They do not constitute a same-shot thermal/current reconstruction.')
assert text.count(old) == 1
text = text.replace(old, '- Figures 4.28–4.30 and recovered Fig. C.19 current share shot 17133, but original drive inputs and clock registration remain missing; no same-shot thermal reproduction is established. Shot 15210 remains separate.')
parsed = yaml.safe_load(text)
assert parsed['source']['sha256'] == m['source']['pdf_sha256']
prepared[paths[3]] = text
for path, contents in prepared.items():
    path.write_text(contents)
report = {'schema': 'mitl-drive-recovery-documentation-association-v1',
    'script_sha256': sha(__file__),
    'source_metadata_sha256': sha(metadata_path), 'csv_sha256': sha(csv_path),
    'summary': stats, 'files_before_sha256': before,
    'files_after_sha256': {str(p.relative_to(repo)): sha(p) for p in paths},
    'same_shot_context_only': True, 'physical_trigger_or_simulation_clock_registered': False,
    'original_simulation_drive_recovered': False, 'actual_flash_run': False}
(work / 'documentation-association.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps(report, indent=2))
