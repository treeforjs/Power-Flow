"""Independent native-PDF evidence for the published shot 17133 current trace."""
import hashlib
import json
from pathlib import Path

import fitz

HERE=Path(__file__).resolve().parent
PDF=Path('/workspace/research_sources/smtrevor_1.pdf')
EXPECTED='1d7b1f9c191a37e94f1cc3634587750f1af35b07eb13e0b94c60f3da47495ed7'

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def plain(value):
    if isinstance(value,(fitz.Point,fitz.Rect,fitz.Quad)): return [plain(item) for item in value]
    if isinstance(value,(tuple,list)): return [plain(item) for item in value]
    if isinstance(value,dict): return {str(key):plain(item) for key,item in value.items()}
    return value

assert sha(PDF)==EXPECTED
with fitz.open(PDF) as document:
    page=document[189]
    drawings=page.get_drawings()
    text=page.get_text('dict')
    words=page.get_text('words')
    assert len(drawings)==33
    result={'schema':'mitl-independent-fig-c19-native-source-v1','source_file':str(PDF),'source_sha256':EXPECTED,
        'pdf_page_index':189,'pdf_page':190,'printed_page':165,'page_rect':list(page.rect),
        'page_text':page.get_text(),'words':plain(words),'text_blocks':plain(text),
        'drawings':plain(drawings),'script_sha256':sha(__file__),
        'limits':'Published vector/text geometry only; no original acquisition arrays, physical uncertainty, shot trigger alignment or spectral gate/current amplitude convention is inferred.'}
    page.get_pixmap(matrix=fitz.Matrix(2,2),alpha=False).save(HERE/'native-page190.png')
target=HERE/'native-source.json'
with target.open('x') as handle: handle.write(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps({'native_source':str(target),'sha256':sha(target),'image_sha256':sha(HERE/'native-page190.png'),
    'drawings':len(drawings),'page_text':result['page_text'],
    'selected_drawings':[{key:plain(drawings[index].get(key)) for key in ('seqno','color','fill','rect','width')}
        | {'index':index,'item_count':len(drawings[index]['items']),'first_items':plain(drawings[index]['items'][:3])}
        for index in (1,2,20,27,28)]},indent=2))
