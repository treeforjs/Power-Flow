"""Independent native-vector, calibration and decimal/SI recovery checks."""
import csv
from decimal import Decimal
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
ROOT=Path('/workspace/Power-Flow')
CSV=ROOT/'data/dissertation/shot_17133_current.csv'
META=CSV.with_suffix('.json')
TOOL=ROOT/'tools/recover_dissertation_drive_17133.py'
EXPECTED={CSV:'2c54d2dbaec6b6c8fcf2e45b5abd837aa72999f5fd14217f530277ffd5949076',
    META:'3e278a763cb95890f01580528857bda13c2d1ddb2fa9e9c9f7b32ce715fdc3e3',
    TOOL:'07c0426ea28e91d09d48d683c55cdc96c3444396fce74ae78518e1f8dc4fae96'}
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def f(record):return Fraction(int(record['numerator']),int(record['denominator']))
def half12(value):
    if not value:return Fraction()
    exponent=Decimal.from_float(abs(float(value))).adjusted()
    return Fraction(Decimal(5).scaleb(exponent-12))

for path,digest in EXPECTED.items():assert sha(path)==digest
reference_path=HERE/'coordinate-reference.json'
native_path=HERE/'native-source.json'
ref=json.loads(reference_path.read_text())
native=json.loads(native_path.read_text())
metadata=json.loads(META.read_text())
with CSV.open(newline='') as handle:
    reader=csv.DictReader(handle)
    headers=reader.fieldnames
    rows=list(reader)
assert headers==metadata['output']['columns'] and len(headers)==12 and len(rows)==132
assert metadata['status']=='reconstructed_published_vector_polyline'
assert metadata['source']['pdf_sha256']==ref['source_sha256']
assert metadata['source']['figure']=='C.19' and metadata['source']['pdf_page']==190 and metadata['source']['printed_page']==165
assert metadata['source']['pdf_page_index_zero_based']==189
assert metadata['experiment']['shot']==17133 and metadata['experiment']['foil_material']=='SS304'
assert metadata['experiment']['foil_thickness_um']==200 and len(metadata['experiment']['thickness_evidence'])==2
assert metadata['output']['generator_sha256']==EXPECTED[TOOL] and metadata['output']['csv_sha256']==EXPECTED[CSV]
assert metadata['observable']['original_units']=='MA' and metadata['observable']['output_units']=='A'
for name in ('raw_oscilloscope_data','independent_samples','trigger_or_current_start_offset_recovered'):
    assert metadata['observable'][name] is False
assert metadata['observable']['time_origin_reference'] is None
vector=metadata['vector_path']
assert vector['encoded_vertices']==134 and vector['retained_vertices']==132 and vector['segments']==133
assert vector['drawing_index_zero_based']==20 and vector['drawing_sequence']==55
assert vector['vertices_behind_legend']==0 and vector['later_legend_drawing_index_zero_based']==27
assert vector['legend_current_sample_drawing_index_zero_based']==28
assert [row['source_vertex_index'] for row in vector['excluded_vertices']]==[0,133]
assert all(row['reason']=='outside_displayed_axes' for row in vector['excluded_vertices'])
assert vector['axes_rectangle_pt']==ref['frame_pt']
geometry={'color':native['drawings'][20]['color'],'width':native['drawings'][20]['width'],
    'points':[[row['pdf_x_pt'],row['pdf_y_pt']] for row in ref['vertices']]}
geometry_sha=hashlib.sha256(json.dumps(geometry,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest()
assert geometry_sha==vector['canonical_geometry_sha256']
time_axis=metadata['calibration']['time_axis']
current_axis=metadata['calibration']['current_axis']
assert time_axis['tick_page_x_pt']==ref['time_axis']['native_positions_pt']
assert current_axis['tick_page_y_pt']==ref['current_axis']['native_positions_pt']
assert time_axis['tick_values_ns']==list(range(0,201,20))
assert current_axis['tick_values_MA']==[0.,.2,.4,.6,.8,1.]
assert current_axis['label']=='Signal Height' and current_axis['legend']=='Average Current [MA]'
assert current_axis['literal_extracted_legend_text']=='Average Current [MA '
assert 'closing bracket' in current_axis['legend_identifier_interpretation']
assert current_axis['frame_bottom_is_zero_current'] is False
assert current_axis['zero_current_tick_page_y_pt']==477.6004333496094
assert time_axis['seconds_per_ns']==1e-9 and current_axis['A_per_MA']==1e6
mt,bt=map(Fraction,(time_axis['ns_per_pt'],time_axis['intercept_ns']))
mi,bi=map(Fraction,(current_axis['MA_per_pt'],current_axis['intercept_MA']))
tm,tb=f(ref['time_axis']['slope_ns_per_pt']),f(ref['time_axis']['intercept_ns'])
im,ib=f(ref['current_axis']['slope_ma_per_pt']),f(ref['current_axis']['intercept_ma'])
assert abs(float(mt-tm))<1e-14 and abs(float(bt-tb))<1e-11
assert abs(float(mi-im))<1e-15 and abs(float(bi-ib))<1e-13
time_residuals=[Fraction(value)-(mt*Fraction(x)+bt) for x,value in zip(time_axis['tick_page_x_pt'],time_axis['tick_values_ns'])]
current_residuals=[Fraction(value)-(mi*Fraction(y)+bi) for y,value in zip(current_axis['tick_page_y_pt'],current_axis['tick_values_MA'])]
half_width=Fraction(vector['stroke_width_pt'])/2
time_bound=abs(mt)*half_width+max(map(abs,time_residuals))
current_bound=(abs(mi)*half_width+max(map(abs,current_residuals)))*10**6
declared=metadata['calibration']['digitization_bounds']
assert abs(float(time_bound)-declared['time_plus_minus_ns'])<1e-12
assert abs(float(current_bound)-declared['current_plus_minus_A'])<1e-8
assert declared['native_pixel_readout_uncertainty_applicable'] is False
assert 'not physical uncertainty' in declared['interpretation']
checked=0
maximum={name:0. for name in ('coordinate_pt','time_ns','time_s','current_ma','current_a')}
retained=[row for row in ref['vertices'] if row['retained_original_vertex']]
for row,point in zip(rows,retained):
    assert int(row['source_vertex_index'])==point['native_vertex_index']
    assert row['occluded_by_legend']=='0'
    x,y=map(Fraction,(point['pdf_x_pt'],point['pdf_y_pt']))
    t,i=f(point['time_ns']),f(point['current_ma'])
    meta_t,meta_i=mt*x+bt,mi*y+bi
    # Calibration differences are explicit and separate from decimal export
    # rounding. The small arithmetic allowance bounds float multiply/add, not
    # a source or measurement uncertainty.
    time_arithmetic=8*Fraction(sys.float_info.epsilon)*(abs(mt*x)+abs(bt))
    current_arithmetic=8*Fraction(sys.float_info.epsilon)*(abs(mi*y)+abs(bi))
    columns={
        'page_x_pt':(x,Fraction(),'coordinate_pt'), 'page_y_pt':(y,Fraction(),'coordinate_pt'),
        'time_ns':(t,abs(meta_t-t)+time_arithmetic,'time_ns'),
        'time_s':(t*Fraction('1e-9'),(abs(meta_t-t)+time_arithmetic)*Fraction('1e-9'),'time_s'),
        'current_MA':(i,abs(meta_i-i)+current_arithmetic,'current_ma'),
        'current_A':(i*10**6,(abs(meta_i-i)+current_arithmetic)*10**6,'current_a'),
        'time_digitization_lower_ns':(meta_t-Fraction(declared['time_plus_minus_ns']),time_arithmetic,'time_ns'),
        'time_digitization_upper_ns':(meta_t+Fraction(declared['time_plus_minus_ns']),time_arithmetic,'time_ns'),
        'current_digitization_lower_A':(meta_i*10**6-Fraction(declared['current_plus_minus_A']),current_arithmetic*10**6,'current_a'),
        'current_digitization_upper_A':(meta_i*10**6+Fraction(declared['current_plus_minus_A']),current_arithmetic*10**6,'current_a'),
    }
    for name,(expected,calibration_allowance,kind) in columns.items():
        literal=Decimal(row[name])
        assert literal.is_finite() and len(literal.as_tuple().digits)<=12,(name,row[name])
        error=abs(Fraction(literal)-expected)
        assert error<=half12(expected)+calibration_allowance,(point['native_vertex_index'],name,float(error),float(half12(expected)+calibration_allowance))
        maximum[kind]=max(maximum[kind],float(error))
        checked+=1
    assert float(row['time_digitization_lower_ns'])<float(row['time_ns'])<float(row['time_digitization_upper_ns'])
    assert float(row['current_digitization_lower_A'])<float(row['current_A'])<float(row['current_digitization_upper_A'])
assert all(float(a['time_s'])<float(b['time_s']) for a,b in zip(rows,rows[1:]))
assert sum(float(row['current_A'])<0 for row in rows)==0
gate=metadata['VUV_gate']
assert gate['kind']=='published_gate_rectangle_not_breakdown'
for name in ('table_4_1_published_acquisition_time_ns','table_4_1_relative_to_breakdown','actual_breakdown_time_ns','exact_trigger_reference'):
    assert gate[name] is None
for value,target in zip(gate['plotted_time_bounds_ns'],ref['gate_graphic_plot_time_ns']):
    assert abs(value-target['value'])<1e-12
result={'schema':'mitl-independent-shot17133-vector-readback-v1','all_checks_passed':True,
    'input_sha256':{str(path):sha(path) for path in (*EXPECTED,reference_path,native_path)},
    'script_sha256':sha(__file__),'source_pdf_sha256':ref['source_sha256'],'native_geometry_sha256':geometry_sha,
    'retained_vertices_checked':len(rows),'native_vertices_accounted':len(ref['vertices']),
    'numeric_csv_cells_with_12_significant_digit_bounds_checked':checked,'maximum_absolute_cell_differences':maximum,
    'support_csv_s':[float(rows[0]['time_s']),float(rows[-1]['time_s'])],
    'support_reference_ns':ref['retained_support_ns'],'legend_covered_vertices':0,'legend_intersecting_centerline_segments':0,
    'signed_negative_vertices':0,'no_new_recovery_or_model_calls':True,
    'limits':['The data are reconstructed published vector geometry, not independent raw diagnostic samples or a manufactured waveform.',
        'Exact rational tick fits independently check the numerical coordinate map. CSV decimal, native tick and stroke bounds are display effects, not physical uncertainty.',
        'The source plot time, VUV gate rectangle and current maximum do not identify an actual trigger, breakdown or acquisition-relative time.',
        'No clipped endpoints, zero padding, tail, smoothing, extrapolation, response, spectra or FLASH execution is supplied.']}
target=HERE/'readback.json'
with target.open('x') as handle:handle.write(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps({'readback':str(target),'sha256':sha(target),'retained_vertices':len(rows),'numeric_cells':checked,
    'support_s':result['support_csv_s'],'maximum_absolute_cell_differences':maximum},indent=2))
