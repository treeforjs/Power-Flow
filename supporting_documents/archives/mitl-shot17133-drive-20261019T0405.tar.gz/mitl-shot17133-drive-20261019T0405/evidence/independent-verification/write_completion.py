"""Bind completed independent Fig. C.19 checks without repeating them."""

import datetime
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
WORK = ROOT.parent
REPO = Path('/workspace/Power-Flow')
PDF = Path('/workspace/research_sources/smtrevor_1.pdf')
PDF_SHA = '1d7b1f9c191a37e94f1cc3634587750f1af35b07eb13e0b94c60f3da47495ed7'
PUBLIC_PINS = {
    'tools/recover_dissertation_drive_17133.py': '07c0426ea28e91d09d48d683c55cdc96c3444396fce74ae78518e1f8dc4fae96',
    'data/dissertation/shot_17133_current.csv': '2c54d2dbaec6b6c8fcf2e45b5abd837aa72999f5fd14217f530277ffd5949076',
    'data/dissertation/shot_17133_current.json': '3e278a763cb95890f01580528857bda13c2d1ddb2fa9e9c9f7b32ce715fdc3e3',
}
EVIDENCE_PINS = {
    'native-source.json': '930fca123fe39db62319b34e4c332701b7b8403059235c043e99cc08bed28879',
    'coordinate-reference.json': '532742892491d202fca1db68b1ed751ca80e9ccab415d1885fe6c2bd9af36717',
    'readback.json': '073286d30a3bf966678a00aec8a3c6b650bed9ef7e114911dd36b3571b1e97bb',
    'drive-and-guards.json': '56359610ef30715dad8ce555256972ecc2600a48f25cb5714ce4ffef35f530a6',
}
COMMAND_LABELS = (
    'c19-independent-native-inspection',
    'c19-independent-coordinate-reference',
    'c19-independent-final-readback',
    'c19-new-drive-inspector',
    'c19-drive-api-and-source-negative-controls',
)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_text())


def main():
    target = ROOT/'completion.json'
    assert not target.exists(), 'Completion already exists; preserve completed evidence'
    assert sha(PDF) == PDF_SHA
    for name, digest in PUBLIC_PINS.items():
        assert sha(REPO/name) == digest, name
    for name, digest in EVIDENCE_PINS.items():
        assert sha(ROOT/name) == digest, name
    native = load(ROOT/'native-source.json')
    reference = load(ROOT/'coordinate-reference.json')
    readback = load(ROOT/'readback.json')
    controls = load(ROOT/'drive-and-guards.json')
    inspection = load(ROOT/'drive_inspection.json')
    metadata = load(REPO/'data/dissertation/shot_17133_current.json')
    assert native['source_sha256'] == reference['source_sha256'] == readback['source_pdf_sha256'] == PDF_SHA
    assert readback['all_checks_passed'] and controls['all_checks_passed']
    assert reference['retained_count'] == readback['retained_vertices_checked'] == 132
    assert readback['native_vertices_accounted'] == len(reference['vertices']) == 134
    assert readback['numeric_csv_cells_with_12_significant_digit_bounds_checked'] == 1320
    assert len(reference['time_axis']['native_positions_pt']) + len(reference['current_axis']['native_positions_pt']) == 17
    assert reference['retained_native_indices'] == list(range(1, 133))
    assert readback['legend_covered_vertices'] == readback['legend_intersecting_centerline_segments'] == 0
    assert readback['no_new_recovery_or_model_calls'] is True
    assert controls['loader_knot_queries_checked'] == 132
    assert controls['loader_interior_queries_checked'] == 131
    assert len(controls['outside_support_controls']) == 4
    assert all(item['rejected'] for item in controls['outside_support_controls'])
    assert len(controls['new_source_guard_controls']) == 3
    assert all(item['rejected_before_calibration'] for item in controls['new_source_guard_controls'])
    assert controls['successful_recovery_calls_by_controls'] == 0
    assert inspection['waveform']['samples'] == 132
    assert inspection['alignment']['physical_trigger_alignment_established'] is False
    assert inspection['alignment']['applied_time_offset_s'] == 0
    assert inspection['source_kind'] == 'reconstructed'
    assert inspection['interpolation_integrals']['is_heat'] is False
    assert metadata['status'] == 'reconstructed_published_vector_polyline'
    assert metadata['observable']['raw_oscilloscope_data'] is False
    assert metadata['observable']['independent_samples'] is False

    entries = [json.loads(line) for line in (WORK/'commands.jsonl').read_text().splitlines()]
    selected = []
    for label in COMMAND_LABELS:
        matches = [entry for entry in entries if Path(entry['log']).name == label+'.log']
        assert len(matches) == 1, (label, len(matches))
        entry = matches[0]
        assert entry['exit_code'] == 0 and sha(Path(entry['log'])) == entry['log_sha256']
        selected.append(entry)
    inspector_commands = [entry for entry in entries if 'tools/inspect_current_drive.py' in entry['command'] and 'data/dissertation/shot_17133_current.csv' in entry['command']]
    assert len(inspector_commands) == 1
    assert controls['input_sha256'][str(ROOT/'drive_inspection.json')] == sha(ROOT/'drive_inspection.json')

    artifact_names = (
        'inspect_native.py', 'native-source.json', 'native-page190.png',
        'coordinate_reference.py', 'coordinate-reference.json',
        'readback.py', 'readback.json', 'drive_inspection.json', 'drive_inspection.png',
        'drive_and_guards.py', 'drive-and-guards.json', 'wrong-source-control.pdf',
        'write_completion.py', 'write_completion.initial.py',
    )
    artifact_pins = {str((ROOT/name).relative_to(WORK)): sha(ROOT/name) for name in artifact_names}
    for entry in selected:
        artifact_pins[Path(entry['log']).name] = entry['log_sha256']
    initial_completion = [entry for entry in entries if Path(entry['log']).name == 'c19-independent-completion.log']
    assert len(initial_completion) == 1 and initial_completion[0]['exit_code'] == 1
    assert sha(Path(initial_completion[0]['log'])) == initial_completion[0]['log_sha256']
    artifact_pins['c19-independent-completion.log'] = initial_completion[0]['log_sha256']
    result = {
        'schema': 'mitl-independent-shot17133-recovery-completion-v1',
        'status': 'passed',
        'all_checks_passed': True,
        'completed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'public_source_sha256': PUBLIC_PINS,
        'artifact_sha256': artifact_pins,
        'source_pdf_sha256': PDF_SHA,
        'source_content_stream_sha256': controls['source_content_stream_sha256'],
        'native_geometry_sha256': readback['native_geometry_sha256'],
        'source': {'figure': 'C.19', 'printed_page': 165, 'pdf_page': 190,
                   'pdf_page_index': 189, 'shot': 17133, 'facility': 'Mykonos'},
        'input_status': 'reconstructed_published_vector_polyline',
        'source_kind': 'reconstructed',
        'raw_oscilloscope_data': False,
        'independent_acquisition_samples': False,
        'native_vertices': 134,
        'retained_vertices': 132,
        'excluded_original_vertices': [0, 133],
        'numeric_csv_cells_checked': 1320,
        'tick_anchors_checked': 17,
        'loader_knot_queries_checked': 132,
        'loader_interior_queries_checked': 131,
        'inspector_cli_runs': 1,
        'outside_support_rejections': 4,
        'source_guard_rejections': 3,
        'successful_recovery_replays': 0,
        'old_suites_repeated': False,
        'portable_test_execution_claimed': False,
        'source_evolution_or_solver_calls': 0,
        'support_csv_s': readback['support_csv_s'],
        'retained_peak': inspection['waveform']['peak'],
        'outside_support_controls': controls['outside_support_controls'],
        'new_source_guard_controls': controls['new_source_guard_controls'],
        'physical_trigger_alignment_established': False,
        'physical_uncertainty_established': False,
        'independent_interpolation_integrals': controls['independent_interpolation_integrals'],
        'commands': selected,
        'completion_aggregation_correction': {
            'initial_command': initial_completion[0],
            'cause': 'Completion-only draft looked for observable.status; the preserved metadata declares status at the top level.',
            'correction': 'Read metadata.status. No recovery, loader, CSV readback or other completed check was rerun or changed.',
            'initial_script_sha256': sha(ROOT/'write_completion.initial.py'),
        },
        'limits': [
            'The reference checks native published vector geometry using an independent exact-rational tick map; it does not recover raw acquisition samples, diagnostic calibration or physical uncertainty.',
            'The shared Signal Height axis has a zero-current tick above the frame bottom. The literal MA legend supplies the displayed current unit; a missing closing bracket in extracted text is explicitly recorded and normalized.',
            'Only original in-frame vertices 1 through 132 are retained. Zero and 200 ns are outside this bounded dataset; no intersections, padding, extrapolation, tail or smoothing were added.',
            'The VUV gate is independently recovered plot geometry. Trigger, breakdown, acquisition registration and Table 4.1 timing remain unknown.',
            'All three deliberately invalid source controls reject before calibration and write no recovery output. Their monkeypatches are process-local; original public files retain their frozen hashes.',
            'Exactly one new-data inspector command ran. Piecewise-linear current and squared-current integrals are diagnostics, not Joule heat, a circuit fit or a FLASH boundary.',
            'No old recovery, prior passing suite, source evolution, kinetic model, spectrum calculation, external job or actual FLASH execution was repeated or supplied.',
        ],
    }
    target.write_text(json.dumps(result, indent=2, allow_nan=False)+'\n')
    print(json.dumps({'completion': str(target), 'sha256': sha(target),
                      'all_checks_passed': True, 'retained_vertices': 132,
                      'outside_support_rejections': 4, 'source_guard_rejections': 3}, indent=2))


if __name__ == '__main__':
    main()
