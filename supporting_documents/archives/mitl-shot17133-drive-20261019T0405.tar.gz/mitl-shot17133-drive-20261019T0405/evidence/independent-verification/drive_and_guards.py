"""New-data drive consumption and bounded negative source-guard controls."""
import csv
from fractions import Fraction
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import sys

HERE=Path(__file__).resolve().parent
ROOT=Path('/workspace/Power-Flow')
sys.path.insert(0,str(ROOT))
from mhdlab.drive_trace import load_current_csv
import pymupdf

CSV=ROOT/'data/dissertation/shot_17133_current.csv'
META=CSV.with_suffix('.json')
TOOL=ROOT/'tools/recover_dissertation_drive_17133.py'
PDF=Path('/workspace/research_sources/smtrevor_1.pdf')
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def exact(value):return {'value':float(value),'numerator':str(value.numerator),'denominator':str(value.denominator)}
pins={str(path):sha(path) for path in (CSV,META,TOOL,PDF,HERE/'drive_inspection.json')}
metadata=json.loads(META.read_text())
inspection=json.loads((HERE/'drive_inspection.json').read_text())
with CSV.open(newline='') as handle:rows=list(csv.DictReader(handle))
times=[float(row['time_s']) for row in rows]
currents=[float(row['current_A']) for row in rows]
assert inspection['input']['csv_sha256']==sha(CSV) and inspection['input']['provenance_sha256']==sha(META)
assert inspection['source_kind']=='reconstructed' and inspection['waveform']['samples']==132
assert inspection['alignment']['mode']=='preserve_source_axis' and inspection['alignment']['applied_time_offset_s']==0.
assert inspection['alignment']['physical_trigger_alignment_established'] is False
assert inspection['waveform']['selected_time_support_s']==[times[0],times[-1]]
assert inspection['waveform']['negative_values']['count']==0 and inspection['waveform']['legend_covered_vertices']==0
assert inspection['waveform']['resampling_or_smoothing_applied'] is False and inspection['waveform']['extrapolation_supplied'] is False
assert inspection['display_bounds']['physical_uncertainty'] is False
assert inspection['VUV_gate']['actual_breakdown_time_s'] is None and inspection['VUV_gate']['exact_trigger_reference'] is None
assert inspection['VUV_gate']['table_4_1_source_time_ns'] is None and inspection['VUV_gate']['table_4_1_relative_to_breakdown'] is None
trace=load_current_csv(CSV,time_column='time_s',current_column='current_A',time_scale_to_s=1.,current_scale_to_a=1.,
    diagnostic_time_offset_s=0.,source_kind='reconstructed',shot_id='Mykonos 17133',
    source_reference=metadata['source']['title'],figure_reference='Figure C.19, Average Current [MA]')
assert trace.csv_import_metadata['sha256']==sha(CSV)
assert all(float(actual)==expected for actual,expected in zip(trace.current_at(times),currents))
midpoints=[a+(b-a)/2 for a,b in zip(times,times[1:])]
expected=[]
for query,a,b,ia,ib in zip(midpoints,times,times[1:],currents,currents[1:]):
    fraction=(Fraction(query)-Fraction(a))/(Fraction(b)-Fraction(a))
    expected.append((1-fraction)*Fraction(ia)+fraction*Fraction(ib))
midpoint_errors=[abs(float(value)-float(target)) for value,target in zip(trace.current_at(midpoints),expected)]
assert max(midpoint_errors)<2e-9
outside=[]
for name,query in (('one_ulp_before_support',math.nextafter(times[0],-math.inf)),
                   ('one_ulp_after_support',math.nextafter(times[-1],math.inf)),
                   ('unrepresented_zero_ns_endpoint',0.),('unrepresented_two_hundred_ns_endpoint',200e-9)):
    try:trace.current_at(query)
    except ValueError as error:
        assert 'extrapolation is forbidden' in str(error)
        outside.append({'case':name,'query_s':query,'rejected':True,'reason':str(error)})
    else:raise AssertionError('unsupported new-drive query accepted: '+name)
integral=Fraction()
integral_squared=Fraction()
for a,b,ia,ib in zip(times,times[1:],currents,currents[1:]):
    dt=Fraction(b)-Fraction(a)
    ia,ib=Fraction(ia),Fraction(ib)
    integral+=dt*(ia+ib)/2
    integral_squared+=dt*(ia*ia+ia*ib+ib*ib)/3
for key,target in (('integral_I_A_s',integral),('integral_I_squared_A2_s',integral_squared)):
    assert math.isclose(inspection['interpolation_integrals'][key],float(target),rel_tol=3e-15)
assert inspection['interpolation_integrals']['is_heat'] is False
with pymupdf.open(PDF) as document:
    page=document[189]
    assert len(document)==203 and page.get_contents()==metadata['source']['page_content_stream_xrefs']
    assert not page.get_images(full=True)
    content_sha=hashlib.sha256(page.read_contents()).hexdigest()
    assert content_sha==metadata['source']['decoded_page_content_stream_sha256']
spec=importlib.util.spec_from_file_location('new_shot17133_source_guards',TOOL)
recovery=importlib.util.module_from_spec(spec)
spec.loader.exec_module(recovery)
bad_pdf=HERE/'wrong-source-control.pdf'
with bad_pdf.open('xb') as handle:handle.write(b'%PDF-1.7\nwrong source control; no dissertation data\n')
negative=[]
real_polyfit=recovery.np.polyfit
def forbid_calibration(*args,**kwargs):raise AssertionError('negative guard reached calibration')
recovery.np.polyfit=forbid_calibration
try:
    for label,pdf,change,reason in (
        ('wrong_pdf_pin',bad_pdf,None,'PDF differs from the inspected dissertation'),
        ('wrong_native_path_pin',PDF,'path','Current vector geometry changed'),
        ('wrong_native_tick_anchor',PDF,'ticks','Inspected tick coordinates changed')):
        old_path=recovery.PATH_SHA256
        old_ticks=recovery.X_TICKS_PT
        try:
            if change=='path':recovery.PATH_SHA256='0'*64
            elif change=='ticks':
                recovery.X_TICKS_PT=old_ticks.copy()
                recovery.X_TICKS_PT[0]+=1.
            try:recovery.recover(pdf)
            except ValueError as error:
                assert reason in str(error)
                negative.append({'case':label,'rejected_before_calibration':True,'reason':str(error)})
            else:raise AssertionError('new source guard accepted '+label)
        finally:
            recovery.PATH_SHA256=old_path
            recovery.X_TICKS_PT=old_ticks
finally:recovery.np.polyfit=real_polyfit
assert all(sha(Path(path))==digest for path,digest in pins.items())
result={'schema':'mitl-shot17133-new-drive-and-source-guards-v1','all_checks_passed':True,
    'input_sha256':pins,'script_sha256':sha(__file__),'drive_trace_code_sha256':sha(ROOT/'mhdlab/drive_trace.py'),
    'source_content_stream_sha256':content_sha,'loader_knot_queries_checked':len(times),
    'loader_interior_queries_checked':len(midpoints),'maximum_midpoint_rounding_difference_a':max(midpoint_errors),
    'outside_support_controls':outside,'independent_interpolation_integrals':{
        'integral_I_A_s':exact(integral),'integral_I_squared_A2_s':exact(integral_squared),'is_heat':False},
    'new_source_guard_controls':negative,'successful_recovery_calls_by_controls':0,
    'wrong_source_control_sha256':sha(bad_pdf),'physical_trigger_alignment_established':False,
    'limits':['One inspector command consumed this new reconstructed dataset. No older recovery or passing project suite was rerun.',
        'The three new source controls call only the new guarded recovery entry with deliberately wrong input or guard declarations; every control rejects before calibration and writes no recovered output.',
        'Piecewise-linear interpolation and integrals describe the encoded curve, not raw dI/dt, Joule heat, a current-tail model or a FLASH boundary.',
        'Original source/data files are unchanged; zero and 200 ns remain outside the retained source support.']}
target=HERE/'drive-and-guards.json'
with target.open('x') as handle:handle.write(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps({'result':str(target),'sha256':sha(target),'knot_queries':len(times),'interior_queries':len(midpoints),
    'outside_rejections':len(outside),'source_guard_rejections':len(negative),
    'integral_I_A_s':float(integral),'integral_I_squared_A2_s':float(integral_squared)},indent=2))
