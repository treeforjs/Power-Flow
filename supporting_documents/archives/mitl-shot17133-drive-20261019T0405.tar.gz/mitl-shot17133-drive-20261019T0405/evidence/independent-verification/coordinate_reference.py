"""Exact-rational axis fits and vector support, independent of the recovery tool."""
from fractions import Fraction
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def rational(value): return {'numerator':str(value.numerator),'denominator':str(value.denominator),'value':float(value)}
def fit(xs,ys):
    xs,ys=list(map(Fraction,xs)),list(map(Fraction,ys))
    n=len(xs)
    slope=(n*sum((x*y for x,y in zip(xs,ys)),Fraction())-sum(xs)*sum(ys))/(n*sum((x*x for x in xs),Fraction())-sum(xs)**2)
    intercept=(sum(ys)-slope*sum(xs))/n
    return slope,intercept
def intersects(a,b,rectangle):
    # Exact Liang-Barsky clipping of a centerline against a closed rectangle.
    x,y=map(Fraction,a)
    dx,dy=Fraction(b[0])-x,Fraction(b[1])-y
    left,bottom,right,top=map(Fraction,rectangle)
    lo,hi=Fraction(),Fraction(1)
    for p,q in ((-dx,x-left),(dx,right-x),(-dy,y-bottom),(dy,top-y)):
        if p==0:
            if q<0:return False
        elif p<0:lo=max(lo,q/p)
        else:hi=min(hi,q/p)
        if lo>hi:return False
    return True

source_path=HERE/'native-source.json'
source=json.loads(source_path.read_text())
drawings=source['drawings']
assert source['pdf_page_index']==189 and source['printed_page']==165 and len(drawings)==33
page_text=source['page_text']
for literal in ('17133','Figure C.19','Signal Height','Time (ns)','Average Current [MA ','VUV Gate Window','200-'):
    assert literal in page_text,literal
frame=drawings[1]['rect']
time_positions=[drawings[index]['items'][0][1][0] for index in range(3,14)]
time_values=list(range(0,201,20))
current_positions=[drawings[index]['items'][0][1][1] for index in range(14,20)]
current_values=[Fraction(index,5) for index in range(6)]
for index in range(3,14):
    item=drawings[index]['items'][0]
    assert len(drawings[index]['items'])==1 and item[0]=='l' and item[1][0]==item[2][0]
    assert item[1][1]==frame[3]
for index in range(14,20):
    item=drawings[index]['items'][0]
    assert len(drawings[index]['items'])==1 and item[0]=='l' and item[1][1]==item[2][1]
    assert item[1][0]==frame[0]
time_slope,time_intercept=fit(time_positions,time_values)
current_slope,current_intercept=fit(current_positions,current_values)
time_endpoint_slope=Fraction(200)/(Fraction(time_positions[-1])-Fraction(time_positions[0]))
time_endpoint_intercept=-time_endpoint_slope*Fraction(time_positions[0])
current_endpoint_slope=Fraction(1)/(Fraction(current_positions[-1])-Fraction(current_positions[0]))
current_endpoint_intercept=-current_endpoint_slope*Fraction(current_positions[0])
time_residuals=[time_slope*Fraction(x)+time_intercept-Fraction(value) for x,value in zip(time_positions,time_values)]
current_residuals=[current_slope*Fraction(y)+current_intercept-value for y,value in zip(current_positions,current_values)]
assert max(map(abs,time_residuals))<Fraction('0.002')
assert max(map(abs,current_residuals))<Fraction('0.000002')
text_matches=[]
for x,value in zip(time_positions,time_values):
    candidates=[w for w in source['words'] if w[4]==str(value) and w[1]>frame[3]-2]
    assert len(candidates)==1
    text_center=(candidates[0][0]+candidates[0][2])/2
    assert abs(text_center-x)<.01
    text_matches.append({'axis':'time','literal':str(value),'native_tick_point':x,'text_center':text_center})
for y,value in zip(current_positions,current_values):
    literal=f'{float(value):.1f}'
    candidates=[w for w in source['words'] if w[4]==literal and w[2]<frame[0]]
    assert len(candidates)==1
    text_center=(candidates[0][1]+candidates[0][3])/2
    assert abs(text_center-y)<.04
    text_matches.append({'axis':'shared_signal_height','literal':literal,'native_tick_point':y,'text_center':text_center})
trace=drawings[20]
assert trace['seqno']==55 and len(trace['items'])==133 and all(item[0]=='l' for item in trace['items'])
vertices=[trace['items'][0][1]]+[item[2] for item in trace['items']]
assert all(left[2]==right[1] for left,right in zip(trace['items'],trace['items'][1:]))
assert all(a[0]<b[0] for a,b in zip(vertices,vertices[1:]))
legend=drawings[28]
assert legend['color']==trace['color'] and len(legend['items'])==1 and legend['seqno']==65
occluder=drawings[27]
assert occluder['fill']==[1.,1.,1.] and occluder['seqno']==63 and occluder['seqno']>trace['seqno']
occluded_segments=[i for i,(a,b) in enumerate(zip(vertices,vertices[1:])) if intersects(a,b,occluder['rect'])]
assert not occluded_segments
rows=[]
retained=[]
for index,(x,y) in enumerate(vertices):
    inside=frame[0]<=x<=frame[2] and frame[1]<=y<=frame[3]
    time=time_slope*Fraction(x)+time_intercept
    current=current_slope*Fraction(y)+current_intercept
    row={'native_vertex_index':index,'pdf_x_pt':x,'pdf_y_pt':y,'retained_original_vertex':inside,
        'time_ns':rational(time),'current_ma':rational(current),
        'time_s':rational(time*Fraction('1e-9')),'current_a':rational(current*10**6),
        'endpoint_time_ns':rational(time_endpoint_slope*Fraction(x)+time_endpoint_intercept),
        'endpoint_current_ma':rational(current_endpoint_slope*Fraction(y)+current_endpoint_intercept)}
    rows.append(row)
    if inside:retained.append(row)
assert len(vertices)==134 and [row['native_vertex_index'] for row in retained]==list(range(1,133))
gate=drawings[2]
assert gate['seqno']==2 and gate['rect'][1:4:2]==frame[1:4:2]
gate_times=[time_slope*Fraction(gate['rect'][index])+time_intercept for index in (0,2)]
peak=max(retained,key=lambda row:Fraction(int(row['current_ma']['numerator']),int(row['current_ma']['denominator'])))
result={'schema':'mitl-independent-fig-c19-coordinate-reference-v1','source_sha256':source['source_sha256'],
    'native_source_json_sha256':sha(source_path),'script_sha256':sha(__file__),
    'page_index':189,'pdf_page':190,'printed_page':165,'figure':'C.19','shot':17133,
    'time_axis':{'native_positions_pt':time_positions,'literal_values_ns':time_values,
        'slope_ns_per_pt':rational(time_slope),'intercept_ns':rational(time_intercept),
        'native_tick_residuals_ns':list(map(rational,time_residuals))},
    'current_axis':{'label':'Signal Height','red_legend_rendered':'Average Current [MA]',
        'literal_extracted_legend_text':'Average Current [MA ',
        'native_positions_pt':current_positions,'literal_values':list(map(str,current_values)),
        'slope_ma_per_pt':rational(current_slope),'intercept_ma':rational(current_intercept),
        'native_tick_residuals_ma':list(map(rational,current_residuals)),
        'plot_frame_bottom_ordinate':rational(current_slope*Fraction(frame[3])+current_intercept)},
    'native_tick_text_associations':text_matches,'frame_pt':frame,'trace_index':20,'trace_seqno':55,
    'legend_index':28,'legend_seqno':65,'later_legend_occluder_index':27,'occluded_centerline_segments':occluded_segments,
    'vertices':rows,'retained_count':len(retained),'retained_native_indices':[row['native_vertex_index'] for row in retained],
    'retained_support_ns':[retained[0]['time_ns']['value'],retained[-1]['time_ns']['value']],
    'retained_peak':peak,'gate_graphic_plot_time_ns':[rational(value) for value in gate_times],
    'gate_graphic_width_ns':rational(gate_times[1]-gate_times[0]),
    'original_acquisition_samples_recovered':False,'boundary_vertices_inserted':False,
    'limits':['Independent exact-rational least squares uses the printed tick numerals and native tick-line positions; endpoint maps are separate representation checks.',
        'PDF tick placement and twelve-significant-digit export rounding are numerical display effects, not physical uncertainty estimates.',
        'The red series MA label supplies the current unit; the shared Signal Height label is not interpreted as an independent instrument calibration.',
        'The gate graphic uses the figure time coordinate; no raw trigger alignment, acquisition timing or physical breakdown time is established.',
        'Only original in-frame current vertices are retained. No clipped intersection, synthetic zero, extrapolation or smoothing is supplied.']}
target=HERE/'coordinate-reference.json'
with target.open('x') as handle:handle.write(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps({'coordinate_reference':str(target),'sha256':sha(target),
    'retained':len(retained),'retained_support_ns':result['retained_support_ns'],
    'peak_time_ns':peak['time_ns']['value'],'peak_current_ma':peak['current_ma']['value'],
    'max_time_tick_residual_ns':float(max(map(abs,time_residuals))),
    'max_current_tick_residual_ma':float(max(map(abs,current_residuals))),
    'frame_bottom_ordinate':result['current_axis']['plot_frame_bottom_ordinate']['value'],
    'occluded_segments':occluded_segments,'gate_graphic_plot_time_ns':[float(value) for value in gate_times]},indent=2))
