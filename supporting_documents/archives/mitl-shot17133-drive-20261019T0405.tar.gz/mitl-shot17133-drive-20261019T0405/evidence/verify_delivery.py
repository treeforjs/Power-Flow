"""Verify actual compact recovery archive bytes and provenance bindings."""
import csv
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import tarfile

from prepare_delivery import WORK, REPO, BASE, OUT, PDF_SHA256, clean_head, load, save, sha
from freeze_delivery import excluded


def main():
    frozen = load(WORK/'frozen_delivery.json')
    clean_head(frozen['source_commit'])
    archive = Path(frozen['archive'])
    assert sha(archive) == frozen['sha256'] and archive.stat().st_size == frozen['bytes']
    assert frozen['base_commit'] == BASE
    hashes, members = {}, {}
    with tarfile.open(archive, 'r:gz') as tar:
        seen = set()
        for member in tar.getmembers():
            name = PurePosixPath(member.name)
            assert not name.is_absolute() and '..' not in name.parts and name.parts[0] == OUT.name
            assert member.name not in seen and not member.issym() and not member.islnk()
            seen.add(member.name)
            if member.isdir():
                continue
            assert member.isfile()
            relative = PurePosixPath(*name.parts[1:]).as_posix()
            assert relative not in members and relative != '.' and not excluded(relative)
            digest = hashlib.sha256()
            stream = tar.extractfile(member)
            for block in iter(lambda: stream.read(1024*1024), b''):
                digest.update(block)
            value = digest.hexdigest()
            assert value != PDF_SHA256
            hashes[relative], members[relative] = value, member

        def raw(name):
            data = tar.extractfile(members[name]).read()
            assert hashlib.sha256(data).hexdigest() == hashes[name]
            return data

        def document(name):
            return json.loads(raw(name))

        manifest = document('manifest.sha256.json')
        assert set(hashes) == set(manifest)|{'manifest.sha256.json'}
        assert all(hashes[name] == digest for name, digest in manifest.items())
        assert hashes['manifest.sha256.json'] == frozen['manifest_sha256']
        assert hashes['verification.json'] == frozen['verification_sha256']
        assert {str(p.relative_to(OUT)) for p in OUT.rglob('*') if p.is_file()} == set(hashes)
        assert all(sha(OUT/name) == digest for name, digest in hashes.items())
        listing = document('source_file_list.json')
        public, wrappers = listing['byte_identical_public_files'], listing['packaging_wrappers']
        assert len(public) == 9 and len(wrappers) == 3
        assert {n[7:] for n in hashes if n.startswith('source/')} == set(public)|set(wrappers)
        for name in public:
            assert hashes['source/'+name] == sha(REPO/name)
        for line in raw('source-files.sha256').decode().splitlines():
            digest, name = line.split('  ', 1)
            assert digest == hashes['source/'+name] == sha(REPO/name)
        verification = document('verification.json')
        assert verification['source_commit'] == frozen['source_commit'] and verification['base_commit'] == BASE
        assert verification['results']['portable_executions_performed'] is False
        dataset = verification['dataset']
        csv_bytes = raw('source/'+dataset['csv_path'])
        metadata = document('source/'+dataset['metadata_path'])
        output = metadata['output']
        assert hashlib.sha256(csv_bytes).hexdigest() == output['csv_sha256'] == dataset['csv_sha256']
        assert hashes['source/'+dataset['metadata_path']] == dataset['metadata_sha256']
        assert hashes['source/'+dataset['producer_path']] == output['generator_sha256'] == dataset['producer_sha256']
        assert output['generator'] == dataset['producer_path']
        reader = csv.DictReader(io.StringIO(csv_bytes.decode()))
        rows = list(reader)
        assert reader.fieldnames == dataset['columns'] == output['columns']
        assert len(rows) == dataset['retained_rows'] == output['samples']
        assert metadata['source'] == dataset['source'] and metadata['experiment'] == dataset['experiment']
        assert metadata['observable'] == dataset['observable'] and metadata['limits'] == dataset['limits']
        assert metadata['schema_version'] == dataset['schema_version'] == 1
        assert metadata['status'] == dataset['status'] == 'reconstructed_published_vector_polyline'
        assert metadata['vector_path'] == dataset['vector_path'] and metadata['source']['pdf_sha256'] == PDF_SHA256
        assert metadata['experiment']['shot'] == 17133 and metadata['source']['figure'] == 'C.19'
        recovery = document('evidence/recovery/recovery_record.json')
        assert recovery == verification['recovery_record'] and recovery['input_pdf_sha256'] == PDF_SHA256
        assert recovery['retained_vertices'] == len(rows)
        assert recovery['canonical_current_path_sha256'] == metadata['vector_path']['canonical_geometry_sha256']
        assert recovery['decoded_page_content_sha256'] == metadata['source']['decoded_page_content_stream_sha256']
        for name, digest in recovery['public_sha256'].items():
            assert hashes['source/'+name] == digest
        for name, digest in recovery['work_artifact_sha256'].items():
            if not excluded(Path('recovery')/name):
                assert hashes['evidence/recovery/'+name] == digest
        original_hashes = dict(hashes)
        for projection in document('portable_path_projections.json'):
            name = projection['path']
            data = raw(name)
            assert hashes[name] == projection['portable_sha256']
            replacement = projection['replacement'].encode()
            assert data.count(replacement) == projection['replacements']
            restored = data.replace(replacement, bytes.fromhex(projection['source_prefix_hex']))
            assert hashlib.sha256(restored).hexdigest() == projection['original_sha256']
            original_hashes[name] = projection['original_sha256']
        completion_name = 'evidence/independent-verification/completion.json'
        completion = document(completion_name)
        assert completion['schema'] == 'mitl-independent-shot17133-recovery-completion-v1'
        assert completion['all_checks_passed'] is True and completion['status'] == 'passed'
        assert completion['retained_vertices'] == len(rows) and completion['native_vertices'] == recovery['native_vertices']
        assert completion['outside_support_rejections'] == 4 and completion['source_guard_rejections'] == 3
        assert completion['successful_recovery_replays'] == 0 and completion['old_suites_repeated'] is False
        assert original_hashes[completion_name] == verification['independent_completion_sha256']
        for name, digest in completion.get('artifact_sha256', {}).items():
            source = Path(name)
            if source.is_absolute():
                assert sha(source) == digest
            else:
                archive_name = 'evidence/'+name
                if archive_name in original_hashes:
                    assert original_hashes[archive_name] == digest
                else:
                    assert sha(WORK/name) == digest
        selection = document('evidence/next-upstream-selection/selection.json')
        assert original_hashes['evidence/next-upstream-selection/selection.json'] == verification['selection_sha256']
        task = selection.get('selected_task', selection.get('task'))
        assert document('next_task.json')['task'] == task == verification['next_task']
        result = {**frozen, 'status': 'passed', 'actual_archive_regular_files': len(hashes),
            'unsafe_or_duplicate_members': 0, 'input_code_output_bindings_verified': True, 'repository_clean': True,
            'dataset_rows_verified': len(rows), 'source_pdf_included': False, 'raw_page_pdf_included': False,
            'source_recovery_or_loader_reexecuted': False}
    save(WORK/'delivery_verification.json', result)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
