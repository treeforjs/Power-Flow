"""Record the new Figure C.19 recovery artifacts without recovering the curve again."""
import csv
import hashlib
import json
from pathlib import Path

ROOT = Path('/workspace/Power-Flow')
WORK = Path(__file__).resolve().parent
PDF = Path('/workspace/research_sources/smtrevor_1.pdf')
names = ['tools/recover_dissertation_drive_17133.py', 'data/dissertation/shot_17133_current.csv',
         'data/dissertation/shot_17133_current.json']
digest = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
metadata = json.loads((ROOT/names[2]).read_text())
with (ROOT/names[1]).open(newline='') as stream:
    rows = list(csv.DictReader(stream))
assert len(rows) == 132
assert metadata['output']['generator_sha256'] == digest(ROOT/names[0])
assert metadata['output']['csv_sha256'] == digest(ROOT/names[1])
assert metadata['source']['pdf_sha256'] == digest(PDF)
assert [int(row['source_vertex_index']) for row in rows] == list(range(1, 133))
assert all(float(b['time_s']) > float(a['time_s']) for a, b in zip(rows, rows[1:]))
assert sum(int(row['occluded_by_legend']) for row in rows) == 0
assert sum(float(row['current_A']) < 0 for row in rows) == 0
artifact_names = ['source_geometry.json', 'page190.png', 'page190.pdf',
                  'shot_17133_current_qa.png', 'shot_17133_current_qa.pdf', 'inspect_vector.py']
peak = max(rows, key=lambda row: float(row['current_A']))
record = {
    'schema': 'mitl-shot17133-vector-recovery-record-v1',
    'public_sha256': {name: digest(ROOT/name) for name in names},
    'input_pdf_sha256': digest(PDF),
    'page_index_zero_based': 189, 'printed_page': 165, 'figure': 'C.19',
    'decoded_page_content_sha256': metadata['source']['decoded_page_content_stream_sha256'],
    'canonical_current_path_sha256': metadata['vector_path']['canonical_geometry_sha256'],
    'retained_source_indices': [1, 132], 'retained_vertices': len(rows),
    'native_vertices': metadata['vector_path']['encoded_vertices'],
    'excluded_source_indices': [item['source_vertex_index'] for item in metadata['vector_path']['excluded_vertices']],
    'csv_time_support_ns': [float(rows[0]['time_ns']), float(rows[-1]['time_ns'])],
    'native_time_support_ns': metadata['output']['time_extent_ns'],
    'csv_peak': {key: (int(peak[key]) if key == 'source_vertex_index' else float(peak[key]))
                 for key in ('source_vertex_index', 'time_ns', 'current_A')},
    'native_current_extent_A': metadata['output']['current_extent_A'],
    'negative_current_vertex_count': 0, 'legend_occlusion_count': 0,
    'display_readout_bounds': metadata['calibration']['digitization_bounds'],
    'VUV_gate': metadata['VUV_gate'],
    'metadata_schema_version': metadata['schema_version'], 'CSV_columns': list(rows[0]),
    'successful_new_recovery_runs': 1, 'old_recovery_or_numerical_history_runs': 0,
    'public_data_changed_after_recovery': False,
    'QA_inspection': {
        'native_page_and_two_panel_plot_viewed': True,
        'observations': [
            'Recovered vertices align with the red source current curve.',
            'The peak is below the later white legend, and no current vertices are legend-occluded.',
            'The published VUV rectangle is separate from the current trace and any breakdown claim.',
            'The reconstructed support preserves only native in-frame vertices with no endpoint padding.',
        ],
    },
    'work_artifact_sha256': {name: digest(WORK/name) for name in artifact_names},
    'raw_page_excerpt_delivery': 'page190.pdf is retained locally for source inspection and excluded from delivery',
}
(WORK/'recovery_record.json').write_text(json.dumps(record, indent=2, allow_nan=False)+'\n')
print(json.dumps({'record': str(WORK/'recovery_record.json'), 'record_sha256': digest(WORK/'recovery_record.json'),
                  'public_sha256': record['public_sha256'], 'display_readout_bounds': record['display_readout_bounds'],
                  'work_artifact_sha256': record['work_artifact_sha256']}, indent=2))
