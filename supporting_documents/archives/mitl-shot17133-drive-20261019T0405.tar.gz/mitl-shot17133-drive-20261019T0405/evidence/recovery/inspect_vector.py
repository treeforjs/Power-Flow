"""Inspect the native source commands for dissertation Figure C.19."""
import hashlib
import json
from pathlib import Path
import pymupdf

PDF = Path('/workspace/research_sources/smtrevor_1.pdf')
OUT = Path(__file__).resolve().parent

def normalized(value):
    if isinstance(value, (pymupdf.Point, pymupdf.Rect)):
        return list(value)
    if isinstance(value, dict):
        return {key: normalized(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [normalized(item) for item in value]
    return value

with pymupdf.open(PDF) as document:
    page = document[189]
    drawings = page.get_drawings()
    record = {'pdf_sha256': hashlib.sha256(PDF.read_bytes()).hexdigest(),
              'page_index': 189, 'page_size_pt': list(page.rect),
              'parser_version': pymupdf.VersionBind,
              'content_xrefs': page.get_contents(),
              'decoded_content_sha256': hashlib.sha256(page.read_contents()).hexdigest(),
              'text': page.get_text(), 'images': page.get_images(full=True),
              'drawings': normalized(drawings), 'text_dictionary': page.get_text('dict')}
    pix = page.get_pixmap(matrix=pymupdf.Matrix(1.5, 1.5), alpha=False)
    pix.save(OUT/'page190.png')
    page_document = pymupdf.open()
    page_document.insert_pdf(document, from_page=189, to_page=189)
    page_document.save(OUT/'page190.pdf')
(OUT/'source_geometry.json').write_text(json.dumps(record, indent=2, allow_nan=False)+'\n')
print(record['text'])
print(json.dumps({key:record[key] for key in ('pdf_sha256','parser_version','content_xrefs','decoded_content_sha256')},indent=2))
for index, drawing in enumerate(drawings):
    print(index, drawing['seqno'], drawing['type'], 'width', drawing['width'], 'color',drawing['color'],
          'fill',drawing['fill'],'rect',list(drawing['rect']),'items',len(drawing['items']),
          normalized(drawing['items'][:2]))
