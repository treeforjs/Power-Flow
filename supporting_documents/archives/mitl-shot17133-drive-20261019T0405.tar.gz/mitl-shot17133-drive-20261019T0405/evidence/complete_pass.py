"""Complete the bounded shot17133 display recovery after verified delivery.

Draft only until explicitly run. No recovery, inspector, previous tests or
portable environment is executed here. Completion checks already recorded
evidence, actual archive bytes and the root-selected committed public scope.
"""
import csv
import datetime
import fcntl
import hashlib
import json
import math
from pathlib import Path, PurePosixPath
import re
import subprocess
import tarfile


WORK = Path(__file__).resolve().parent
REPO = Path('/workspace/Power-Flow')
OUT = Path('/workspace/handoffs/mitl-shot17133-drive-20261019T0405')
BASE = '079bddf9f81021ee4f3d79c42011185511d53747'
EXPECTED_HEAD = 'bea74a0e08bb531cf790a73bc67f97eb1d6de97b'
DOC_NAME = 'systems-mitl-shot17133-drive-10192026.md'
PRODUCER = 'tools/recover_dissertation_drive_17133.py'
CSV = 'data/dissertation/shot_17133_current.csv'
METADATA = 'data/dissertation/shot_17133_current.json'
PINNED = {
    PRODUCER: '07c0426ea28e91d09d48d683c55cdc96c3444396fce74ae78518e1f8dc4fae96',
    CSV: '2c54d2dbaec6b6c8fcf2e45b5abd837aa72999f5fd14217f530277ffd5949076',
    METADATA: '3e278a763cb95890f01580528857bda13c2d1ddb2fa9e9c9f7b32ce715fdc3e3',
}
PDF_SHA = '1d7b1f9c191a37e94f1cc3634587750f1af35b07eb13e0b94c60f3da47495ed7'
INDEPENDENT_SHA = 'b1f3fe19e8f22cd3a89233c1f037cbf0ff056cb623a0e36d882f1639faa66754'
NEW_SCOPE = {PRODUCER, CSV, METADATA, 'data/dissertation/recovery_manifest.yaml',
             'docs/dissertation_recovery.md', 'docs/flash_drive_inputs.md', 'docs/shot_17133_current_recovery.md'}
PUBLIC = NEW_SCOPE|{'mhdlab/drive_trace.py', 'tools/inspect_current_drive.py'}


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024*1024), b''):
            digest.update(block)
    return digest.hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def safe(name):
    value = PurePosixPath(name)
    require(not value.is_absolute() and name and str(value) == name and '..' not in value.parts, 'unsafe relative evidence path')
    return value


def clean_head(expected):
    require(expected == EXPECTED_HEAD, 'final commit differs from the root-approved completed scope')
    require(re.fullmatch('[0-9a-f]{40}', expected) is not None, 'final commit pin is absent')
    require(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == expected, 'final root-selected source commit changed')
    require(not subprocess.check_output(['git', 'status', '--porcelain'], cwd=REPO, text=True).strip(), 'repository must be clean')
    require(subprocess.check_output(['git', 'branch', '--show-current'], cwd=REPO, text=True).strip() == 'research/flash-publication-foundation', 'unexpected branch')
    subprocess.run(['git', 'merge-base', '--is-ancestor', BASE, expected], cwd=REPO, check=True)
    require(subprocess.check_output(['git', 'rev-list', '--count', BASE+'..'+expected], cwd=REPO, text=True).strip() == '2', 'expected two bounded local commits')
    changed = subprocess.check_output(['git', 'diff', '--name-only', BASE, expected], cwd=REPO, text=True).splitlines()
    require(set(changed) == NEW_SCOPE, 'committed scope differs from the claimed source recovery')


def verify_delivery(delivery, frozen, verification):
    require(delivery['status'] == 'passed' and delivery['repository_clean'] is True
            and delivery['input_code_output_bindings_verified'] is True and delivery['unsafe_or_duplicate_members'] == 0, 'delivery verification incomplete')
    for name in ('folder', 'archive', 'sha256', 'bytes', 'source_commit', 'base_commit', 'manifest_sha256', 'verification_sha256'):
        require(delivery[name] == frozen[name], 'delivery/freeze identity mismatch: '+name)
    require(delivery['folder'] == str(OUT) and delivery['base_commit'] == verification['base_commit'] == BASE, 'unexpected delivery destination/base')
    head = delivery['source_commit']
    require(head == verification['source_commit'], 'frozen verification commit mismatch')
    clean_head(head)
    archive = Path(delivery['archive'])
    require(archive == OUT.with_suffix('.tar.gz') and sha(archive) == delivery['sha256'] and archive.stat().st_size == delivery['bytes'], 'actual archive bytes changed')
    hashes, seen = {}, set()
    with tarfile.open(archive, 'r:gz') as stream:
        for member in stream:
            path = PurePosixPath(member.name)
            require(not path.is_absolute() and '..' not in path.parts and path.parts and path.parts[0] == OUT.name, 'unsafe archive member')
            require(member.name not in seen and not member.issym() and not member.islnk(), 'duplicate or linked archive member')
            seen.add(member.name)
            if member.isdir():
                continue
            require(member.isfile() and len(path.parts) > 1, 'nonregular archive member')
            name = str(PurePosixPath(*path.parts[1:]))
            safe(name)
            require('source-local' not in PurePosixPath(name).parts and PurePosixPath(name).name not in {'smtrevor_1.pdf', 'page190.pdf'}, 'excluded original/prospective source included')
            digest = hashlib.sha256()
            with stream.extractfile(member) as payload:
                for block in iter(lambda: payload.read(1024*1024), b''):
                    digest.update(block)
            hashes[name] = digest.hexdigest()
            require(hashes[name] != PDF_SHA and (OUT/name).is_file() and not (OUT/name).is_symlink() and sha(OUT/name) == hashes[name], 'actual archive/directory bytes differ: '+name)
    manifest = load(OUT/'manifest.sha256.json')
    require(set(hashes) == set(manifest)|{'manifest.sha256.json'}, 'actual archive manifest member mismatch')
    require(sha(OUT/'manifest.sha256.json') == delivery['manifest_sha256'] and sha(OUT/'verification.json') == delivery['verification_sha256'], 'manifest/verification pins changed')
    for name, digest in manifest.items():
        safe(name)
        require(type(digest) is str and re.fullmatch('[0-9a-f]{64}', digest) is not None and hashes[name] == digest, 'archive manifest digest mismatch')
    require(len(manifest) == delivery['manifest_entries'] and len(hashes) == delivery['actual_archive_regular_files'], 'archive count mismatch')
    listing = load(OUT/'source_file_list.json')
    public, wrappers = listing['byte_identical_public_files'], listing['packaging_wrappers']
    require(len(public) == 9 and set(public) == PUBLIC and len(set(wrappers)) == len(wrappers) == 3 and not set(public)&set(wrappers), 'public/wrapper scope mismatch')
    require({name[7:] for name in hashes if name.startswith('source/')} == set(public)|set(wrappers), 'archive source listing mismatch')
    require(delivery['public_files_byte_identical'] == 9 and delivery['packaging_wrappers'] == 3, 'delivery source count mismatch')
    public_pins = {}
    for name in public:
        committed = subprocess.check_output(['git', 'show', head+':'+name], cwd=REPO)
        digest = hashlib.sha256(committed).hexdigest()
        require(hashes['source/'+name] == sha(REPO/name) == digest, 'public bytes disagree with committed source: '+name)
        public_pins[name] = digest
    lines = {}
    for line in (OUT/'source-files.sha256').read_text().splitlines():
        digest, name = line.split('  ', 1)
        require(name not in lines, 'duplicate public hash inventory entry')
        lines[name] = digest
    require(lines == public_pins, 'public hash inventory mismatch')
    require(delivery['dataset_rows_verified'] == 132 and delivery['source_pdf_included'] is False
            and delivery['raw_page_pdf_included'] is False and delivery['source_recovery_or_loader_reexecuted'] is False,
            'delivery claims unsupported source or execution')
    return head, public_pins


def validate_maps(record):
    for mapping in ('source_sha256', 'public_source_sha256', 'reviewed_source_sha256'):
        for name, digest in record.get(mapping, {}).items():
            path = Path(name) if Path(name).is_absolute() else REPO/name
            require(sha(path) == digest, 'independent source pin changed: '+name)
    for name, digest in record.get('artifact_sha256', {}).items():
        path = Path(name) if Path(name).is_absolute() else WORK/name
        require(sha(path) == digest, 'independent artifact pin changed: '+name)


def verify_evidence(verification):
    for name, digest in PINNED.items():
        require(sha(REPO/name) == digest, 'frozen new dataset/producer pin changed')
    metadata = load(REPO/METADATA)
    with (REPO/CSV).open(newline='') as stream:
        reader = csv.DictReader(stream)
        rows = list(reader)
    require(len(rows) == metadata['output']['samples'] == 132 and reader.fieldnames == metadata['output']['columns'], 'CSV row/column association mismatch')
    require(metadata['output']['csv_sha256'] == PINNED[CSV] and metadata['output']['generator'] == PRODUCER
            and metadata['output']['generator_sha256'] == PINNED[PRODUCER], 'CSV/sidecar/producer association mismatch')
    require(metadata['status'] == 'reconstructed_published_vector_polyline' and metadata['source']['pdf_sha256'] == PDF_SHA
            and metadata['source']['figure'] == 'C.19' and metadata['source']['pdf_page'] == 190
            and metadata['experiment']['shot'] == 17133 and metadata['experiment']['foil_material'] == 'SS304', 'source identity/label mismatch')
    require(metadata['vector_path']['encoded_vertices'] == 134 and metadata['vector_path']['retained_vertices'] == 132
            and len(metadata['vector_path']['excluded_vertices']) == 2, 'retained original support mismatch')
    require(metadata['observable']['raw_oscilloscope_data'] is False and metadata['observable']['independent_samples'] is False
            and metadata['observable']['trigger_or_current_start_offset_recovered'] is False, 'published source promoted to raw/registered evidence')
    dataset = verification['dataset']
    for key, expected in (('csv_path', CSV), ('metadata_path', METADATA), ('producer_path', PRODUCER),
                          ('csv_sha256', PINNED[CSV]), ('metadata_sha256', PINNED[METADATA]), ('producer_sha256', PINNED[PRODUCER]), ('retained_rows', 132)):
        require(dataset[key] == expected, 'frozen dataset verification mismatch: '+key)
    for key in ('source', 'experiment', 'observable', 'limits'):
        require(dataset[key] == metadata[key], 'frozen dataset declarations mismatch')
    docs = load(WORK/'documentation-association.json')
    require(docs['csv_sha256'] == PINNED[CSV] and docs['source_metadata_sha256'] == PINNED[METADATA]
            and docs['same_shot_context_only'] is True and docs['physical_trigger_or_simulation_clock_registered'] is False
            and docs['original_simulation_drive_recovered'] is False and docs['actual_flash_run'] is False, 'documentation/source limits mismatch')
    for name, digest in docs['files_after_sha256'].items():
        require(sha(REPO/name) == digest, 'documentation association changed: '+name)
    doc_verification = load(WORK/'documentation-verification.json')
    require(doc_verification['passed'] is True and doc_verification['base_commit'] == BASE
            and doc_verification['manifest_sha256'] == sha(REPO/'data/dissertation/recovery_manifest.yaml')
            and doc_verification['old_target_count'] == 44 and doc_verification['new_drive_entry'] == 'fig_c_19'
            and doc_verification['prior_targets_preserved_except_pending_drive_description'] == ['fig_4_30']
            and doc_verification['source_record_unchanged'] is True and doc_verification['new_artifact_and_clock_labels_verified'] is True
            and doc_verification['source_evolution_or_old_recovery_run'] is False, 'documentation/source association verification incomplete')
    independent = load(WORK/'independent-verification/completion.json')
    require(independent['schema'] == 'mitl-independent-shot17133-recovery-completion-v1'
            and independent['all_checks_passed'] is True and independent['status'] == 'passed', 'independent completion has not passed')
    require(sha(WORK/'independent-verification/completion.json') == verification['independent_completion_sha256'] == INDEPENDENT_SHA
            and verification['independent_completion'] == independent, 'independent completion pin/declaration mismatch')
    for key, expected in (('native_vertices', 134), ('retained_vertices', 132), ('numeric_csv_cells_checked', 1320),
                          ('tick_anchors_checked', 17), ('loader_knot_queries_checked', 132), ('loader_interior_queries_checked', 131),
                          ('inspector_cli_runs', 1), ('outside_support_rejections', 4), ('source_guard_rejections', 3),
                          ('successful_recovery_replays', 0), ('source_evolution_or_solver_calls', 0)):
        require(type(independent[key]) is int and independent[key] == expected, 'independent completion counter mismatch: '+key)
    require(independent['source_pdf_sha256'] == PDF_SHA and independent['input_status'] == metadata['status']
            and independent['source_kind'] == 'reconstructed' and independent['old_suites_repeated'] is False
            and independent['portable_test_execution_claimed'] is False and independent['raw_oscilloscope_data'] is False
            and independent['independent_acquisition_samples'] is False and independent['physical_trigger_alignment_established'] is False
            and independent['physical_uncertainty_established'] is False, 'independent completion source/claim mismatch')
    validate_maps(independent)
    readback = load(WORK/'independent-verification/readback.json')
    require(readback['all_checks_passed'] is True and readback['retained_vertices_checked'] == 132
            and readback['native_vertices_accounted'] == 134 and readback['numeric_csv_cells_with_12_significant_digit_bounds_checked'] == 1320
            and readback['no_new_recovery_or_model_calls'] is True, 'independent native-coordinate readback incomplete')
    for name, digest in readback['input_sha256'].items():
        require(sha(name) == digest, 'independent readback input pin changed')
    inspection = load(WORK/'independent-verification/drive_inspection.json')
    require(inspection['input']['csv_sha256'] == PINNED[CSV] and inspection['input']['provenance_sha256'] == PINNED[METADATA]
            and inspection['source_kind'] == 'reconstructed' and inspection['waveform']['samples'] == 132
            and inspection['alignment']['mode'] == 'preserve_source_axis' and inspection['alignment']['physical_trigger_alignment_established'] is False
            and inspection['waveform']['extrapolation_supplied'] is False and inspection['waveform']['resampling_or_smoothing_applied'] is False
            and inspection['display_bounds']['physical_uncertainty'] is False, 'new input inspector context is unsupported')
    controls = load(WORK/'independent-verification/drive-and-guards.json')
    require(controls['all_checks_passed'] is True and controls['loader_knot_queries_checked'] == 132
            and controls['loader_interior_queries_checked'] == 131 and len(controls['outside_support_controls']) == 4
            and all(item['rejected'] is True for item in controls['outside_support_controls'])
            and len(controls['new_source_guard_controls']) == 3
            and all(item['rejected_before_calibration'] is True for item in controls['new_source_guard_controls'])
            and controls['successful_recovery_calls_by_controls'] == 0 and controls['physical_trigger_alignment_established'] is False,
            'new bounded input/source controls incomplete')
    for name, digest in controls['input_sha256'].items():
        require(sha(name) == digest, 'new bounded control input pin changed')
    require(sha(REPO/'mhdlab/drive_trace.py') == controls['drive_trace_code_sha256'], 'bounded input consumer implementation changed')
    visual = load(WORK/'visual-review.json')
    require(sha(visual['artifact']) == visual['artifact_sha256'] and visual['source_recovery_repeated'] is False, 'QA visual association changed')
    results = verification['results']
    require(results['new_dataset_rows'] == 132 and results['csv_column_count'] == len(reader.fieldnames)
            and results['independent_readback_passed'] is True, 'delivery dataset evidence incomplete')
    for name in ('portable_executions_performed', 'packaging_source_recovery_repeated', 'old_recoveries_repeated', 'old_test_suites_repeated',
                 'full_source_pdf_included', 'raw_page_pdf_included', 'prospective_source_local_panels_included'):
        require(results[name] is False, 'unsupported execution/source-inclusion claim: '+name)
    require(not any('test' in key and key not in {'old_test_suites_repeated'} for key in results), 'this recovery pass must not invent test counts')
    peak = max(rows, key=lambda row: float(row['current_A']))
    require(all(math.isfinite(float(row['time_s'])) and math.isfinite(float(row['current_A'])) for row in rows), 'nonfinite CSV input')
    return metadata, inspection, {'source_time_support_s': [float(rows[0]['time_s']), float(rows[-1]['time_s'])],
                                  'retained_peak_current_A': float(peak['current_A']), 'retained_peak_source_time_s': float(peak['time_s'])}


def main():
    status_path = WORK.parent/'mitl-upstream-status.json'
    with (WORK.parent/'mitl-upstream-status.lock').open('a+') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        before = status_path.read_bytes()
        status = json.loads(before)
        now = datetime.datetime.now(datetime.timezone.utc)
        require(status['active_lease_owner'] == WORK.name and datetime.datetime.fromisoformat(status['active_editing_lease_until_utc']) > now, 'active bounded lease is absent, changed or expired')
        require(status['last_complete_commit'] == BASE and not (WORK/'completion.json').exists(), 'completed checkpoint changed or completion replay attempted')
        delivery, frozen, verification = load(WORK/'delivery_verification.json'), load(WORK/'frozen_delivery.json'), load(OUT/'verification.json')
        head, public_pins = verify_delivery(delivery, frozen, verification)
        metadata, inspection, numerical_summary = verify_evidence(verification)
        selection_path = WORK/'next-upstream-selection/selection.json'
        selection = load(selection_path)
        require(selection['status'] == 'selected_with_resolution_and_units_limits' and selection['source_recovery_performed'] is False
                and selection['curve_digitization_or_axis_fit_performed'] is False, 'next task has not remained a qualified selection')
        require(selection['primary_source']['pdf_sha256'] == PDF_SHA and sha(selection['primary_source']['pdf_path']) == PDF_SHA, 'next task primary source changed')
        require([value['figure'] for value in selection['primary_source']['figures']] == ['4.28', '4.29'], 'unexpected next selected depth-profile task')
        next_task = selection['selected_task']
        require(load(OUT/'next_task.json')['task'] == verification['next_task'] == next_task, 'delivery next task differs from selection')
        remaining = [dict(value) for value in status['next_work'] if 2 <= value['priority'] <= 6]
        require([value['priority'] for value in remaining] == [2, 3, 4, 5, 6], 'pending queue2..6 changed')
        require('source_ledger_admission' in status, 'prior admission milestone missing')
        now = datetime.datetime.now(datetime.timezone.utc)
        require(datetime.datetime.fromisoformat(status['active_editing_lease_until_utc']) > now, 'lease expired during completion verification')
        clean_head(head)
        history = status.setdefault('verification_history', [])
        old_id = status['last_completed_pass_id']
        if not any(value['pass_id'] == old_id for value in history):
            history.append({'pass_id': old_id, 'commit': status['last_complete_commit'], 'handoff': status['handoff'],
                            'handoff_sha256': status['handoff_sha256'], 'verification': status['last_verified_suite']})
        prior = status.setdefault('prior_handoffs', [])
        if status['handoff'] not in prior:
            prior.append(status['handoff'])
        status.update(last_complete_commit=head, last_completed_pass_id=WORK.name, last_update_utc=now.isoformat(), handoff=delivery['archive'],
                      handoff_sha256=delivery['sha256'], handoff_bytes=delivery['bytes'], handoff_document=str(OUT/DOC_NAME),
                      active_lease_owner=None, active_editing_lease_until_utc=None, reserved_paths=[], active_completed_subtasks=[],
                      active_phase='Completed same-shot17133 published current recovery; signed J_z depth curves with optional separately qualified coarse B_x selected next')
        status['last_verified_suite'] = {**verification['results'], 'scope': 'New source-pinned Fig.C.19 published-vector recovery, independent native-coordinate/CSV readback and bounded drive input controls; no previous tests or source runs repeated',
            'verification_record': str(OUT/'verification.json'), 'delivery_manifest_entries': delivery['manifest_entries'],
            'public_files_byte_identical': 9, 'packaging_wrappers': 3, 'actual_flash_run': False,
            'physical_trigger_or_simulation_clock_registered': False, 'physical_spectra_calculated': False,
            'post_freeze_commands': str(WORK/'commands.jsonl')}
        status['reconstructed_current_17133'] = {'csv': str(REPO/CSV), 'csv_sha256': PINNED[CSV],
            'metadata': str(REPO/METADATA), 'metadata_sha256': PINNED[METADATA], 'recovery_tool': str(REPO/PRODUCER), 'recovery_tool_sha256': PINNED[PRODUCER],
            'guide': str(REPO/'docs/shot_17133_current_recovery.md'), 'source_figure': 'C.19', 'pdf_page': 190, 'printed_page': 165,
            'shot': 17133, 'material': 'SS304', 'source_foil_thickness_um': 200, 'input_status': metadata['status'],
            'retained_original_vertices': 132, 'encoded_original_vertices': 134, 'excluded_out_of_frame_vertices': 2,
            **numerical_summary, 'display_time_bound_ns': metadata['calibration']['digitization_bounds']['time_plus_minus_ns'],
            'display_current_bound_A': metadata['calibration']['digitization_bounds']['current_plus_minus_A'],
            'display_bounds_are_physical_uncertainty': False, 'VUV_gate_source_time_bounds_ns': metadata['VUV_gate']['plotted_time_bounds_ns'],
            'independent_completion': str(WORK/'independent-verification/completion.json'),
            'independent_completion_sha256': sha(WORK/'independent-verification/completion.json'),
            'drive_inspection': str(WORK/'independent-verification/drive_inspection.json'),
            'drive_inspection_sha256': sha(WORK/'independent-verification/drive_inspection.json'),
            'bounded_input_and_source_controls': str(WORK/'independent-verification/drive-and-guards.json'),
            'bounded_input_and_source_controls_sha256': sha(WORK/'independent-verification/drive-and-guards.json'),
            'loader_knot_queries_checked': 132, 'loader_interior_queries_checked': 131,
            'outside_support_rejections': 4, 'wrong_source_identity_rejections_before_calibration': 3,
            'successful_recovery_calls_by_controls': 0,
            'documentation_association': str(WORK/'documentation-association.json'), 'documentation_association_sha256': sha(WORK/'documentation-association.json'),
            'same_shot_legacy_EM_context_only': True, 'original_acquisition_data': False, 'physical_trigger_alignment_established': False,
            'simulation_clock_alignment_established': False, 'original_simulation_drive_recovered': False, 'extrapolation_supplied': False,
            'actual_flash_run': False, 'physical_spectra_calculated': False,
            'limits': 'Reconstructed published display vertices in source plotted time; no synthetic endpoints, zero/tail, smoothing, extrapolation, trigger registration, electromagnetic/Joule closure or physical measurement uncertainty. Existing Allegra fields and molecular/diagnostic gaps remain unresolved.'}
        status['next_work'] = [{'priority': 1, 'task': next_task, 'selection': str(selection_path), 'selection_sha256': sha(selection_path)}]+remaining
        status['completed_milestones'].extend([
            'Published same-shot17133 Fig.C.19 average-current vector recovery retains132of134 original vertices with source point/clock/SI columns, stroke/tick readout bounds, independent gate rectangle and explicit original support. No synthetic boundary vertices, zero/tail, sign floor, smoothing, trigger or simulation-clock registration.',
            'Independent native-PDF geometry and exact-rational tick mapping readback checks132retained/134encoded vertices and1320CSV numeric cells. New source/provenance loader and out-of-support controls retain input hashes and reconstructed labels; no old recovery or prior test suite repeated.',
            f'Two local commits through{head[:7]};9 public files and3 named wrappers with{delivery["manifest_entries"]} manifest entries verify against actual archive{delivery["sha256"]}. Packaging performs no new portable execution or recovery/inspector run. Same-shot legacy EM context remains limited; next source recovery selects signed J_z depth curves in4.28/4.29 and optional separately qualified coarse B_x gap curves.'
        ])
        history.append({'pass_id': WORK.name, 'commit': head, 'handoff': delivery['archive'], 'handoff_sha256': delivery['sha256'],
                        'verification': status['last_verified_suite']})
        encoded = (json.dumps(status, indent=2, allow_nan=False)+'\n').encode()
        result = {'utc': now.isoformat(), 'event': 'completed_and_next_selected', 'pass_id': WORK.name, 'commit': head,
            'archive': delivery['archive'], 'archive_sha256': delivery['sha256'], 'archive_bytes': delivery['bytes'],
            'actual_archive_reverified': True, 'public_scope_sha256': public_pins, 'dataset_rows_verified': 132, 'encoded_vertices': 134,
            'independent_readback_passed': True, 'portable_executions_performed': False, 'old_test_suites_repeated': False,
            'exact_commands': str(WORK/'commands.jsonl'), 'status_before_sha256': hashlib.sha256(before).hexdigest(),
            'status_after_sha256': hashlib.sha256(encoded).hexdigest(), 'lease_released': True, 'reserved_paths': [],
            'next': next_task, 'next_selection_sha256': sha(selection_path),
            'limits': 'Published source-coordinate current only; raw diagnostics, trigger/simulation-clock registration, original EM normalization, material/circuit closure, physical source parameters and configured licensed FLASH remain unresolved.'}
        (WORK/'status-before-completion.json').write_bytes(before)
        temporary = status_path.with_suffix('.json.new')
        temporary.write_bytes(encoded)
        temporary.replace(status_path)
        (WORK/'completion.json').write_text(json.dumps(result, indent=2, allow_nan=False)+'\n')
        with (WORK.parent/'mitl-upstream-journal.jsonl').open('a') as stream:
            stream.write(json.dumps(result, allow_nan=False)+'\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
