"""Portable upstream window-conditioned boundary verification subset."""
