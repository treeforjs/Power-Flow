# Window-conditioned upstream boundary verification subset

Named public files are byte-identical to the recorded commit. Four packaging
wrappers isolate imports from unrelated downstream solvers.

```sh
python -W error -m pytest tests/test_temkin_windowed_source.py tests/test_temkin_windowed_boundary.py tests/test_temkin_windowed_cli.py
```

The test inputs are manufactured. The numerical envelopes are estimates with
explicit floating-point assumptions. A represented source and launch packet set
perform no host transaction. Source emission and photon recording gates have
separate meanings. Read `docs/temkin_windowed_boundary.md` before coupling.
