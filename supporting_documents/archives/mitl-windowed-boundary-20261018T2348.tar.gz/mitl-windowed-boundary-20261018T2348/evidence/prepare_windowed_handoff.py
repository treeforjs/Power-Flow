"""Prepare a public upstream boundary subset for independent import checks."""
import ast
import hashlib
import json
from pathlib import Path
import shutil

repo = Path('/workspace/Power-Flow')
out = Path('/workspace/handoffs/mitl-windowed-boundary-20261018T2348')
assert not out.exists()
source = out / 'source'
source.mkdir(parents=True)
names = {
    'mhdlab/temkin_windowed_source.py', 'mhdlab/temkin_windowed_boundary.py',
    'tests/test_temkin_windowed_source.py', 'tests/test_temkin_windowed_boundary.py',
    'tests/test_temkin_windowed_cli.py', 'tools/sample_temkin_source_windows.py',
    'configs/temkin_windowed_packets_manufactured.json', 'docs/temkin_windowed_boundary.md',
}
pending = list(names)
while pending:
    name = pending.pop()
    if not name.endswith('.py'):
        continue
    tree = ast.parse((repo / name).read_text())
    needed = []
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom) and node.module:
            if node.level:
                needed.append('mhdlab/' + node.module.replace('.', '/') + '.py')
            elif node.module.startswith(('mhdlab.', 'tools.')):
                needed.append(node.module.replace('.', '/') + '.py')
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'CODE_PATHS' for t in node.targets):
            needed.extend(ast.literal_eval(node.value))
    for item in needed:
        if (repo / item).is_file() and item not in names:
            names.add(item)
            pending.append(item)
assert not names.intersection({'mhdlab/runner.py', 'mhdlab/chemistry.py', 'mhdlab/kinetic_gap.py', 'mhdlab/cr_data.py', 'mhdlab/bolsig.py'})
for name in sorted(names):
    target = source / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(repo / name, target)
wrappers = {
    'mhdlab/__init__.py': '"""Portable upstream window-conditioned boundary verification subset."""\n',
    'pytest.ini': '[pytest]\npythonpath = .\n',
    'requirements.txt': 'numpy\nscipy\nh5py\npytest\n',
    'README.md': '''# Window-conditioned upstream boundary verification subset

Named public files are byte-identical to the recorded commit. Four packaging
wrappers isolate imports from unrelated downstream solvers.

```sh
python -W error -m pytest tests/test_temkin_windowed_source.py tests/test_temkin_windowed_boundary.py tests/test_temkin_windowed_cli.py
```

The test inputs are manufactured. The numerical envelopes are estimates with
explicit floating-point assumptions. A represented source and launch packet set
perform no host transaction. Source emission and photon recording gates have
separate meanings. Read `docs/temkin_windowed_boundary.md` before coupling.
''',
}
for name, body in wrappers.items():
    (source / name).write_text(body)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
listing = {'byte_identical_public_files': sorted(names), 'packaging_wrappers': sorted(wrappers)}
(out / 'source_file_list.json').write_text(json.dumps(listing, indent=2) + '\n')
(out / 'source-files.sha256').write_text(''.join(f'{sha(source/name)}  {name}\n' for name in sorted(names)))
print(json.dumps({'public_files': len(names), 'packaging_wrappers': len(wrappers), 'output': str(out)}, indent=2))
