"""Issue-specific checks of new signed/exp projections and time flags."""
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path
import sys

ROOT=Path('/workspace/Power-Flow')
sys.path.insert(0,str(ROOT))
from mhdlab import temkin_windowed_boundary as boundary
from mhdlab.constants import KB

minimum=float.fromhex('0x0.0000000000001p-1022')
tolerance=1e-7
checks=[]
def expect_range(name,call):
    try:
        value=call()
    except boundary.TemkinWindowedBoundaryRangeError as error:
        checks.append({'name':name,'passed':True,'rejected_reason':str(error)})
    else:
        raise AssertionError(f'{name} accepted unsupported product: {value!r}')

# This is the exact new signed expression used for stored momentum/Cartesian
# tangent components. The diagnostic-only finite helper remains unrestricted.
def signed_projection(value,name):
    return math.copysign(boundary._positive_fraction(abs(value),name,tolerance),value) if value else 0.

for velocity in (.75,-.75,.53125,-.53125):
    product=Fraction(minimum)*Fraction(velocity)
    expect_range(f'coarse momentum m=minsub,v={velocity}',lambda product=product:signed_projection(product,'sampled momentum'))
for factor in (.25,-.25,.75,-.75):
    product=Fraction(minimum)*Fraction(factor)
    expect_range(f'tiny/coarse Cartesian tangent factor={factor}',lambda product=product:signed_projection(product,'tangential velocity component'))
for value in (minimum,-minimum,2*minimum,-2*minimum,0.):
    actual=signed_projection(Fraction(value),'exact represented signed product')
    if actual != value:
        raise AssertionError((actual,value))
checks.append({'name':'exact represented signed products remain accepted','passed':True})

sigma_log=.5*math.fsum((math.log(KB),math.log(minimum),-math.log(1e301)))
speed_log=sigma_log+.5*math.log(-2*math.log1p(-.5))
expect_range('coarse finite positive normal-speed log projection',lambda:boundary._positive_exp(speed_log,'outgoing normal speed',tolerance))
normal=boundary._positive_exp(math.log(123.45),'ordinary normal speed',tolerance)
if not math.isclose(normal,123.45,rel_tol=1e-14):
    raise AssertionError(normal)
checks.append({'name':'ordinary normal-speed projection remains accepted','passed':True})

timestamp_rows=[]
for delay in (1e-6,2e-6):
    time,flag,error=boundary._global_time(1e12,1e-5,delay,tolerance)
    if flag or time != 1e12 or error <= 0:
        raise AssertionError((time,flag,error))
    timestamp_rows.append({'origin_s':1e12,'window_start_s':1e-5,'local_delay_s':delay,
                           'best_effort_time_s':time,'precision_qualified':flag,
                           'absolute_rounding_error_s':error})
time,flag,error=boundary._global_time(0.,0.,1e-250,tolerance)
if time != 1e-250 or not flag or error != 0:
    raise AssertionError((time,flag,error))
checks.append({'name':'global collapsed times unqualified; exact tiny local time retained','passed':True})

report={
    'schema':'mhdlab-windowed-boundary-projection-review-v1',
    'module_sha256':hashlib.sha256((ROOT/'mhdlab/temkin_windowed_boundary.py').read_bytes()).hexdigest(),
    'checks':checks,'check_count':len(checks),'timestamp_rows':timestamp_rows,
    'scope':'Only new changed product projections and new global-time helper; no source/history execution, old suites, old oracles, host or gap physics.',
    'closed_findings':['Coarse signed momentum projection','Coarse positive speed and tangential-component projection'],
    'open_substantive_findings':[]
}
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps(report,indent=2,allow_nan=False))
