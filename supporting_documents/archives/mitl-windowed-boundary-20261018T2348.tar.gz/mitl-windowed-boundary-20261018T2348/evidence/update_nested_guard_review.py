"""Refresh reviewed source authority metadata after the owner's final notice."""
import hashlib
import json
from pathlib import Path

work=Path(__file__).resolve().parent
repo=Path('/workspace/Power-Flow')
expected={
    'mhdlab/temkin_windowed_source.py':'7dca511618a3d91e55742f96d121dfb1ecf5acdb4dda18a16e6bf45958552736',
    'mhdlab/temkin_windowed_boundary.py':'0e59a54a8138a92bcbe9121034e17ded8e43e4777486a66c9a690995178e8229',
    'tests/test_temkin_windowed_source.py':'2247d64df312bac8f418f229c2e799f834122b5dbed551e664b0afda2ac22a46',
}
def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
for name,sha in expected.items():
    if digest(repo/name)!=sha:
        raise SystemExit(f'Unexpected final bytes: {name}')
log=work/'windowed-source-nested-pool-guards.log'
logsha='0b4e5a3b49b0f0ed6e35ffd2b64c575775888b1e3fa16879d38cf5b094dea14a'
if digest(log)!=logsha:
    raise SystemExit('Owner regression log hash mismatch')
commands=[json.loads(line) for line in (work/'commands.jsonl').read_text().splitlines()]
records=[r for r in commands if Path(r['log']).name==log.name]
if len(records)!=1 or records[0]['exit_code']!=0 or records[0]['log_sha256']!=logsha:
    raise SystemExit('Owner recorded command mismatch')
path=work/'windowed_boundary_review_completion.json'
prior=path.read_bytes()
historical=work/'windowed_boundary_review_completion_projection_only.json'
if historical.exists():
    raise SystemExit('Historical projection-only completion already exists')
historical.write_bytes(prior)
report=json.loads(prior)
report['reviewed_source_sha256']={name:sha for name,sha in expected.items() if name.startswith('mhdlab/')}
report['artifact_sha256'].update({
    historical.name:digest(historical),
    'windowed_packet_review.md':digest(work/'windowed_packet_review.md'),
    log.name:logsha,
    'update_nested_guard_review.py':digest(__file__),
})
report['reviewed_source_test_sha256']={'tests/test_temkin_windowed_source.py':expected['tests/test_temkin_windowed_source.py']}
report['closed_substantive_findings'].append({
    'id':'forged_nested_reservoir_authority',
    'discovery':'Source owner identified invalid nested reservoir declarations reaching canonical replay arithmetic.',
    'resolution':'Shared source helper revalidates every nested reservoir constructor before canonical history replay in both factory and record validation.',
    'verification':'Read-only bounded diff inspection and inspection of owner-recorded three new regression outcomes; reviewer did not rerun tests.',
})
report['source_owner_new_regressions']={
    'passed':3,'deselected':64,'owner_recorded_command':records[0],
    'log_sha256':logsha,'reviewer_reran':False,
}
report['new_projection_checks_passed']=12
report['projection_checks_repeated_after_authority_only_change']=False
report['metadata_update_scope']='After source-author final notification; source guard only, numerical boundary bytes unchanged.'
report['open_substantive_findings']=[]
path.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps({'completion':str(path),'sha256':digest(path),
                  'reviewed_source_sha256':report['reviewed_source_sha256'],
                  'new_projection_checks_passed':12,'source_owner_new_regressions_passed':3,
                  'open_substantive_findings':[]},indent=2))
