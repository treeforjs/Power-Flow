"""Record the verified source-packet handoff and release this bounded lease."""
import datetime
import fcntl
import hashlib
import json
from pathlib import Path
import subprocess

work = Path(__file__).resolve().parent
repo = Path('/workspace/Power-Flow')
out = Path('/workspace/handoffs/mitl-windowed-boundary-20261018T2348')
status_path = work.parent / 'mitl-upstream-status.json'
journal_path = work.parent / 'mitl-upstream-journal.jsonl'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
delivery = json.loads((work / 'delivery_verification.json').read_text())
verification = json.loads((out / 'verification.json').read_text())
readback = json.loads((work / 'windowed-packet-readback/report.json').read_text())
commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
assert commit == delivery['source_commit'] == verification['source_commit']
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo, text=True).strip()
assert sha(delivery['archive']) == delivery['sha256']
assert readback == verification['independent_readback'] and readback['status'] == 'passed'
assert verification['results']['isolated_passed'] == 134
next_task = (
    'Implement deterministic conditional-window timing and joint source moments, '
    'then qualify the new weighted windowed launches against those expectations '
    'with explicit allocation/sampling uncertainty. Preserve original component '
    'mixtures, anchored local/log timing, representation flags, estimated '
    'quadrature errors and true geometry. Reuse saved histories and packets; '
    'do not rerun their unchanged evolution, suites or saved reference oracles. '
    'Source-emission moments remain separate from photon gates and owned gap/chemistry/radiative solvers.'
)
now = datetime.datetime.now(datetime.timezone.utc).isoformat()
with (work.parent / 'mitl-upstream-status.lock').open('a+') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX)
    old_bytes = status_path.read_bytes()
    status = json.loads(old_bytes)
    assert status['active_lease_owner'] == work.name
    assert datetime.datetime.fromisoformat(status['active_editing_lease_until_utc']) > datetime.datetime.now(datetime.timezone.utc)
    if status['handoff'] not in status.setdefault('prior_handoffs', []):
        status['prior_handoffs'].append(status['handoff'])
    history = status.setdefault('verification_history', [])
    if not any(item['pass_id'] == status['last_completed_pass_id'] for item in history):
        history.append({'pass_id': status['last_completed_pass_id'], 'commit': status['last_complete_commit'],
                        'handoff': status['handoff'], 'handoff_sha256': status['handoff_sha256'],
                        'verification': status['last_verified_suite']})
    status.update({
        'last_complete_commit': commit, 'last_completed_pass_id': work.name, 'last_update_utc': now,
        'handoff': delivery['archive'], 'handoff_sha256': delivery['sha256'], 'handoff_bytes': delivery['bytes'],
        'handoff_document': str(out / 'systems-mitl-windowed-boundary-10182026.md'),
        'active_lease_owner': None, 'active_editing_lease_until_utc': None, 'reserved_paths': [],
        'active_completed_subtasks': [],
        'active_phase': 'Completed qualified window-conditioned boundary packets and saved-artifact owner controls; deterministic window moments selected next',
    })
    status['last_verified_suite'] = {
        **verification['results'], 'targeted_unique_passed': 134,
        'conditioned_source_checks': 67, 'paired_boundary_checks': 37, 'export_cli_checks': 30,
        'new_independent_projection_checks': 12,
        'targeted_execution': 'Source63+1+3 passes; boundary initially26 passed/6 failed/5 fixture errors, then only affected11 passed after fixture corrections; CLI30 passed before final nested-pool validation guard. Final portable134 tests pass on exact frozen code.',
        'scope': 'New original-history source-window association, paired weighted 3D boundary injection, source export and independent saved-packet readback; previous passing suites and source evolution not rerun',
        'verification_record': str(out / 'verification.json'),
        'delivery_manifest_entries': delivery['manifest_entries'],
        'host_budget_accepted': False, 'physical_spectra_calculated': False,
        'previous_full_project_passed': 721, 'previous_full_project_skipped': 2,
        'post_freeze_commands': str(work / 'commands.jsonl'),
    }
    status['nonlinear_source_windows'].update({
        'window_conditioned_boundary_packets_implemented': True,
        'conditioned_history_interface': str(repo / 'mhdlab/temkin_windowed_source.py'),
        'paired_packet_interface': str(repo / 'mhdlab/temkin_windowed_boundary.py'),
        'packet_export_cli': str(repo / 'tools/sample_temkin_source_windows.py'),
        'packet_guide': str(repo / 'docs/temkin_windowed_boundary.md'),
        'packet_example_report': str(work / 'windowed-packet-example/report.json'),
        'packet_example_report_sha256': sha(work / 'windowed-packet-example/report.json'),
        'conditional_timing_moments_implemented': False, 'host_acceptance_qualified': False,
        'packet_projection_qualification': 'Individually estimated log-rounding allowances reject unsupported weights, positive/cartesian speeds, momentum, energy and required local delays. Best-effort global time has separate precision flags.',
    })
    status['owner_response_controls'].update({
        'windowed_packet_handoff': str(out / 'systems-mitl-windowed-boundary-10182026.md'),
        'windowed_packet_readback': str(work / 'windowed-packet-readback/report.json'),
        'windowed_packet_readback_sha256': sha(work / 'windowed-packet-readback/report.json'),
        'windowed_packet_components': 48, 'windowed_packet_count': 512,
        'windowed_packet_exact_full_width_controls': 10,
        'windowed_packet_manufactured_aperture_differs': True,
        'owner_implementation_verified': False, 'physical_spectra_calculated': False,
    })
    remaining = [dict(item) for item in status['next_work'] if item['priority'] > 1]
    status['next_work'] = [{'priority': 1, 'task': next_task}] + remaining
    status['completed_milestones'].extend([
        'Original-history source window components preserve canonical initial populations, frozen temperatures, geometry and exact states, with explicit zero skips and bounded disjoint selections. Canonical nested reservoir declarations are revalidated before law replay; 67 new source checks passed.',
        'Paired window-conditioned 3D packets retain original interval origin, local start/delay/log delay, source state/temperature/velocity/current mixture and actual area. Mandatory components plus exact count CDF refinement preserve tiny represented populations; 37 new boundary and 30 export checks passed.',
        'Independent review caught and fixed coarse subnormal velocity and momentum projections; 12 new focused checks passed. Float64 weights, speeds, momenta and energy fields are range-qualified; signed number and sampled-energy residuals remain explicit with no host acceptance or forced thermal repair.',
        'One preserved manufactured HDF produced 48 conditioned components and 512 packets. Independent saved NPZ/HDF readback verified all associations, draws, velocities/momenta and weighted energy ledgers without source or sampler replay. Ten exact fixed full-width launch functionals match; a manufactured partial aperture differs. No physical spectrum inference.',
        f'Four local commits through{commit[:7]}; 134 final portable checks passed with zero skips. {delivery["public_files_byte_identical"]} byte-identical public files and {delivery["manifest_entries"]} manifest entries verified in actual archive {delivery["sha256"]}. Earlier suites, source evolution and saved oracles were not rerun.',
    ])
    temporary = status_path.with_suffix('.json.new')
    temporary.write_text(json.dumps(status, indent=2, allow_nan=False) + '\n')
    temporary.replace(status_path)
    result = {
        'utc': now, 'event': 'completed_and_next_selected', 'pass_id': work.name, 'commit': commit,
        'archive': delivery['archive'], 'archive_sha256': delivery['sha256'], 'archive_bytes': delivery['bytes'],
        'public_files_byte_identical': delivery['public_files_byte_identical'], 'new_unique_checks': 134,
        'portable_passed': 134, 'portable_skipped': 0, 'independent_projection_checks': 12,
        'example_components': 48, 'example_packets': 512, 'exact_full_width_controls': 10,
        'exact_commands': str(work / 'commands.jsonl'), 'status_before_sha256': hashlib.sha256(old_bytes).hexdigest(),
        'status_after_sha256': sha(status_path), 'lease_released': True, 'reserved_paths': [], 'next': next_task,
        'limits': 'Manufactured source/response evidence and estimated numerical allowances; no host transaction or physical spectra. Physical inventory/calibration and installed licensed FLASH/workstation remain unresolved.',
    }
    (work / 'completion.json').write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
    with journal_path.open('a') as stream:
        stream.write(json.dumps(result, allow_nan=False) + '\n')
    print(json.dumps(result, indent=2, allow_nan=False))
