"""Read one saved packet export without replaying any source or sampler."""
import csv
from fractions import Fraction as Q
import hashlib
import json
import math
from pathlib import Path

import h5py
import numpy as np

work = Path(__file__).resolve().parent
example = work / 'windowed-packet-example'
report = json.loads((example / 'report.json').read_text())
manifest = report['packets']
source = report['conditioned_source']
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert report['parameter_status'] == report['mass_status'] == 'manufactured'
assert report['host_budget_accepted'] is manifest['host_budget_accepted'] is source['host_budget_accepted'] is False
for name, digest in report['output_sha256'].items():
    assert sha(example / name) == digest, name
for name, digest in report['source_sha256'].items():
    assert sha(Path('/workspace/Power-Flow') / name) == digest, name
assert sha(example / 'source_input.h5') == report['input_source_sha256']
assert manifest['source'] == source
draws = np.load(example / 'uniforms.npy', allow_pickle=False)
with np.load(example / 'boundary_packets.npz', allow_pickle=False) as archive:
    arrays = {name: archive[name].copy() for name in archive.files}
assert json.loads(str(arrays.pop('metadata_json'))) == manifest
states, pool_names = arrays.pop('state_ids'), arrays.pop('reservoir_names')
assert set(arrays) == set(manifest['array_units'])
assert all(np.all(np.isfinite(values)) for values in arrays.values())
assert draws.shape == (manifest['packets'], 7) and np.all((draws > 0) & (draws < 1))
np.testing.assert_array_equal(arrays['resolved_position_m'][:, 1:], arrays['uniform_width_position_m'][:, 1:])
np.testing.assert_array_equal(arrays['resolved_position_m'][:, 0], arrays['resolved_x_m'])
np.testing.assert_array_equal(arrays['uniform_width_position_m'][:, 0], arrays['uniform_x_m'])
indices = arrays['component_index']
assert len(source['components']) == len(manifest['components']) == 48
assert len(draws) == 512 and not source['skipped_zero_initials']
checks = 0
component_rows = []
signed_weight_residuals = []
thermal_terms, internal_terms, removal_terms = [], [], []
with h5py.File(example / 'source_input.h5', 'r') as h:
    pools = json.loads(h.attrs['reservoirs_json'])
    times, temperatures, coverage = (h[name][...] for name in ('time_edges_s', 'temperature_k', 'coverage_m2'))
    areas = h['patch_areas_m2'][...]
    KB, QE = 1.380649e-23, 1.602176634e-19
    for index, component in enumerate(source['components']):
        packet_ids = np.flatnonzero(indices == index)
        assert len(packet_ids) >= 1
        window = component['source_window']
        t, r, z, x = (component[name] for name in ('interval_index', 'reservoir_index', 'current_index', 'width_index'))
        assert window['initial_coverage_m2'] == coverage[t, r, z, x]
        assert window['temperature_k'] == temperatures[t, z, x]
        assert window['patch_area_m2'] == areas[z, x]
        assert window['reservoir'] == pools[r]
        quantities = window['quantities']
        target = Q(quantities['released_number']['value'])
        actual = sum((Q(float(arrays['particle_weight'][i])) for i in packet_ids), Q(0))
        residual = actual - target
        assert float(residual) == arrays['component_particle_balance_residual'][index]
        signed_weight_residuals.append(float(residual))
        translation, internal, removal = Q(0), Q(0), Q(0)
        for packet in packet_ids:
            i = int(packet)
            for name, expected in (('interval_index', t), ('reservoir_index', r), ('source_current_index', z),
                                   ('source_width_index', x), ('selection_index', component['selection_index'])):
                assert arrays[name][i] == expected
            assert states[i] == pools[r]['state_id'] and pool_names[i] == pools[r]['name']
            assert arrays['temperature_k'][i] == temperatures[t, z, x]
            assert arrays['interval_origin_s'][i] == times[t]
            assert arrays['window_start_offset_s'][i] == window['start_s']
            assert arrays['window_stop_offset_s'][i] == window['stop_s']
            assert 0 < arrays['local_time_delay_s'][i] <= window['stop_s'] - window['start_s']
            assert abs(math.log(arrays['local_time_delay_s'][i]) - arrays['log_local_time_delay_s'][i]) < 1e-7
            mass, temperature = float(arrays['mass_kg'][i]), float(arrays['temperature_k'][i])
            sigma = math.sqrt(KB * temperature / mass)
            radius = sigma * math.sqrt(-2 * math.log(float(draws[i, 4])))
            angle = 2 * math.pi * float(draws[i, 5])
            expected_velocity = (radius * math.cos(angle),
                                 manifest['outward_normal_sign'] * sigma * math.sqrt(-2 * math.log1p(-float(draws[i, 3]))),
                                 radius * math.sin(angle))
            np.testing.assert_allclose(arrays['velocity_m_s'][i], expected_velocity, rtol=3e-14, atol=0)
            np.testing.assert_allclose(arrays['momentum_kg_m_s'][i], mass * arrays['velocity_m_s'][i], rtol=3e-14, atol=0)
            assert manifest['outward_normal_sign'] * arrays['velocity_m_s'][i, 1] > 0
            weight = Q(float(arrays['particle_weight'][i]))
            translation += weight * Q(mass) * sum((Q(float(v))**2 for v in arrays['velocity_m_s'][i]), Q(0)) / 2
            internal += weight * Q(QE) * Q(pools[r]['internal_energy_ev'])
            removal += weight * Q(QE) * Q(pools[r]['desorption_energy_ev'])
            checks += 1
        for name, value in (('component_sampled_translational_energy_j', translation),
                            ('component_weighted_internal_energy_j', internal),
                            ('component_weighted_binding_energy_j', removal),
                            ('component_sampled_total_wall_energy_debit_j', translation + internal + removal)):
            assert arrays[name][index] == float(value)
        for name, source_key in (('component_expected_translational_energy_j', 'translational_energy_j'),
                                 ('component_expected_internal_energy_j', 'internal_energy_j'),
                                 ('component_expected_binding_energy_j', 'binding_energy_j'),
                                 ('component_expected_total_wall_energy_debit_j', 'total_wall_energy_debit_j')):
            assert arrays[name][index] == quantities[source_key]['value']
        thermal_terms.append(translation)
        internal_terms.append(internal)
        removal_terms.append(removal)
        component_rows.append({'component': index, 'selection': component['selection_index'], 'interval': t,
                               'reservoir': r, 'current': z, 'width': x, 'packets': len(packet_ids),
                               'released_number': float(target), 'packet_number_residual': float(residual),
                               'expected_translation_j': quantities['translational_energy_j']['value'],
                               'sampled_translation_j': float(translation)})
assert manifest['totals']['sampled_translational_energy_j'] == float(sum(thermal_terms, Q(0)))
assert manifest['totals']['weighted_internal_energy_j'] == float(sum(internal_terms, Q(0)))
assert manifest['totals']['weighted_binding_energy_j'] == float(sum(removal_terms, Q(0)))
assert manifest['totals']['sampled_total_wall_energy_debit_j'] == float(sum(thermal_terms + internal_terms + removal_terms, Q(0)))

# Fixed linear launch observables and one explicitly manufactured aperture.
# No collision, radiation, photon-gate or instrument-response model is invoked.
response_rows = []
aperture = (-.00105, .00055)
for selection in sorted(set(map(int, arrays['selection_index']))):
    selected = np.flatnonzero(arrays['selection_index'] == selection)
    for kernel in ('number', 'local_delay', 'temperature', 'state_current', 'kinetic_energy'):
        def response(position, partial):
            total = Q(0)
            for packet in selected:
                i = int(packet)
                if partial and not aperture[0] <= position[i, 0] < aperture[1]:
                    continue
                factor = {'number': Q(1), 'local_delay': Q(float(arrays['local_time_delay_s'][i])),
                          'temperature': Q(float(arrays['temperature_k'][i])),
                          'state_current': Q(1 + int(arrays['reservoir_index'][i]) + 2 * int(arrays['source_current_index'][i])),
                          'kinetic_energy': Q(float(arrays['mass_kg'][i])) *
                              sum((Q(float(v))**2 for v in arrays['velocity_m_s'][i]), Q(0)) / 2}[kernel]
                total += Q(float(arrays['particle_weight'][i])) * factor
            return total
        resolved = response(arrays['resolved_position_m'], False)
        uniform = response(arrays['uniform_width_position_m'], False)
        assert resolved == uniform
        partial_resolved = response(arrays['resolved_position_m'], True)
        partial_uniform = response(arrays['uniform_width_position_m'], True)
        response_rows.append({'selection': selection, 'kernel': kernel, 'full_width_equal_exactly': True,
                              'full_width_response': float(resolved), 'partial_resolved': float(partial_resolved),
                              'partial_uniform': float(partial_uniform), 'partial_differs': partial_resolved != partial_uniform})
assert any(row['partial_differs'] for row in response_rows)
output = work / 'windowed-packet-readback'
output.mkdir(exist_ok=False)
for name, rows in (('components.csv', component_rows), ('responses.csv', response_rows)):
    with (output / name).open('w', newline='') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]), lineterminator='\n')
        writer.writeheader()
        writer.writerows(rows)
result = {
    'schema': 'mitl-windowed-packet-independent-readback-v1', 'status': 'passed',
    'input_report_sha256': sha(example / 'report.json'), 'input_packet_sha256': sha(example / 'boundary_packets.npz'),
    'script_sha256': sha(__file__), 'parameter_status': 'manufactured', 'components': len(component_rows),
    'packets_checked': checks, 'full_width_functional_controls': len(response_rows),
    'full_width_equal_exactly': True, 'manufactured_aperture_m': aperture,
    'manufactured_partial_aperture_differs': any(row['partial_differs'] for row in response_rows),
    'host_budget_accepted': False, 'physical_spectra_calculated': False,
    'sampled_translation_j': manifest['totals']['sampled_translational_energy_j'],
    'expected_translation_j': manifest['totals']['expected_translational_energy_j'],
    'translation_sampling_residual_j': manifest['totals']['translational_energy_sampling_residual_j'],
    'output_sha256': {p.name: sha(p) for p in output.iterdir()},
    'limits': [
        'Reads one saved manufactured packet export and original HDF; no history loader, evolution, scalar window or packet sampler is called.',
        'The response kernels are fixed linear SOURCE launch observables, not physical spectra, photon gates or reconstructed optics.',
        'The manufactured partial aperture tests sampled paired launch positions only; no gap evolution, collisions, radiation or charged-particle trajectories.',
        'Signed component weight and sampled-energy residuals remain explicit; neither this readback nor represented packets accept a host transaction.',
    ],
}
(output / 'report.json').write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
print(json.dumps(result, indent=2, allow_nan=False))
