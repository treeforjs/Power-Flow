"""Pin the read-only review evidence without executing any source models."""
import datetime
import hashlib
import json
from pathlib import Path

work=Path(__file__).resolve().parent
repo=Path('/workspace/Power-Flow')
def pin(path):
    path=Path(path)
    return {'path':str(path),'bytes':path.stat().st_size,
            'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}

evidence=[
    'windowed_packet_review.md',
    'momentum_quantization_probe.py','momentum_quantization_probe.json','momentum_quantization_initial.log',
    'velocity_quantization_probe.py','velocity_quantization_probe.json','velocity_quantization_initial.log',
    'fixed_projection_review.py','fixed_projection_review.json','fixed_projection_review.log',
]
report={
    'schema':'mhdlab-windowed-source-packet-independent-review-v1',
    'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'reviewed_code':[pin(repo/'mhdlab/temkin_windowed_source.py'),pin(repo/'mhdlab/temkin_windowed_boundary.py')],
    'evidence':[pin(work/name) for name in evidence],
    'new_focused_checks':12,
    'commands':[
        record for record in (json.loads(line) for line in (work/'commands.jsonl').read_text().splitlines())
        if Path(record['log']).name in {'momentum_quantization_initial.log','velocity_quantization_initial.log','fixed_projection_review.log'}
    ],
    'closed_substantive_findings':[
        {'id':'coarse_signed_momentum_projection',
         'initial_code_sha256':'849e83b452b2669c56b1636c7088e2617fca50d1751bb2651616f579ba2289ab',
         'initial_behavior':'Finite nonzero products accepted with 33.3–88.2 percent relative rounding error.',
         'resolution':'Stored signed momentum products use the positive magnitude quantization guard.'},
        {'id':'coarse_positive_and_cartesian_speed_projection',
         'initial_code_sha256':'849e83b452b2669c56b1636c7088e2617fca50d1751bb2651616f579ba2289ab',
         'initial_behavior':'Positive finite normal speed accepted with 60.7 percent error while its momentum stayed normal-range.',
         'resolution':'Normal/radius exponentiation checks its log projection; signed Cartesian tangent products are qualified before momentum construction.'}
    ],
    'open_substantive_findings':[],
    'read_only_contract_conclusions':[
        'Original canonical history authority, local initial density, temperature, reservoir, patch area, and origin/window offsets remain associated.',
        'Every selected component is retained or explicitly omitted only for an exact-zero canonical initial density; disjoint original selections preserve distinct labels.',
        'Packet admission consumes individually qualified extensive count/energy quantities instead of requiring underflowed areal values.',
        'Mandatory component allocation and exact rational count CDF prevent silent loss of tiny components; displayed probability underflow is explicit.',
        'Weights and product/energy projections are qualified; signed closure and stochastic energy residuals are retained without inventory or velocity repair.',
        'Resolved and matched-width records change only width position and share the full original time/state/temperature/current/velocity/momentum/weight mixture.',
        'Global timestamps are best effort with explicit precision flags; local origin/start/delay fields remain authoritative.'
    ],
    'scope_limits':[
        'This is independent code review plus new helper probes, not an end-to-end packet test.',
        'No previous passing suite, source history, saved oracle, or material/calibration audit was rerun.',
        'No public file was edited; no source evolution, old HDF integration, host transaction, gap/field/chemistry/radiation solver or physical spectrum was run.',
        'New numerical range probes are manufactured and carry no experimental/material claim.',
        'Completion applies to the exact reviewed code hashes; later code changes require a scoped review update.'
    ],
    'host_budget_accepted':False
}
path=work/'windowed_packet_review_completion.json'
path.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps({'completion':pin(path),'reviewed_code':report['reviewed_code'],
                  'new_focused_checks':12,'open_substantive_findings':[]},indent=2))
