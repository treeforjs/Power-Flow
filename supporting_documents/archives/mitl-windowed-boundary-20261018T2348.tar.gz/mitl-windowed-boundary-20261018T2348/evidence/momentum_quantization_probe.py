"""New work-only product-qualification probe; no source/history is evolved."""
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path
import sys

ROOT = Path('/workspace/Power-Flow')
sys.path.insert(0, str(ROOT))
from mhdlab import temkin_windowed_boundary as boundary

minimum = float.fromhex('0x0.0000000000001p-1022')
cases = []
for velocity in (.75, -.75, .53125, -.53125):
    exact = Fraction(minimum) * Fraction(velocity)
    try:
        represented = boundary._finite_fraction(exact, 'sampled momentum')
        relative = float(Fraction(represented) / exact) - 1.
        outcome = {'accepted': True, 'value': represented,
                   'signed_relative_rounding_error': relative}
    except boundary.TemkinWindowedBoundaryRangeError as error:
        outcome = {'accepted': False, 'reason': str(error)}
    try:
        magnitude = boundary._positive_fraction(abs(exact), 'momentum magnitude', 1e-7)
        strict = {'accepted': True, 'value': magnitude}
    except boundary.TemkinWindowedBoundaryRangeError as error:
        strict = {'accepted': False, 'reason': str(error)}
    cases.append({'mass_kg': minimum, 'velocity_m_s': velocity,
                  'exact_momentum_over_min_subnormal': velocity,
                  'current_momentum_path': outcome,
                  'existing_positive_product_qualification': strict})

report = {
    'schema': 'mhdlab-windowed-packet-momentum-quantization-probe-v1',
    'module': str(ROOT/'mhdlab/temkin_windowed_boundary.py'),
    'module_sha256': hashlib.sha256((ROOT/'mhdlab/temkin_windowed_boundary.py').read_bytes()).hexdigest(),
    'cases': cases,
    'scope': 'New numerical product helper probe only; no source evolution, canonical history replay, prior tests, gap physics or spectra.',
    'finding': 'Finite nonzero momentum products can be accepted despite 33–88 percent quantization error; signed magnitude qualification is needed.'
}
path = Path(__file__).with_suffix('.json')
path.write_text(json.dumps(report, indent=2, allow_nan=False)+'\n')
print(json.dumps(report, indent=2, allow_nan=False))
