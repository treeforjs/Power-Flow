"""New tiny-speed projection probe without a source/history execution."""
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path
import sys

ROOT=Path('/workspace/Power-Flow')
sys.path.insert(0,str(ROOT))
from mhdlab import temkin_windowed_boundary as boundary
from mhdlab.constants import KB

minimum=float.fromhex('0x0.0000000000001p-1022')
temperature=minimum
mass=1e301
parents=1e300
sigma_log=.5*math.fsum((math.log(KB),math.log(temperature),-math.log(mass)))
speed_log=sigma_log+.5*math.log(-2*math.log1p(-.5))
try:
    speed=boundary._positive_exp(speed_log,'outgoing normal speed')
    log_error=abs(math.log(speed)-speed_log)
    projection={'accepted':True,'speed_m_s':speed,'absolute_log_rounding_error':log_error,
                'relative_rounding_error':math.expm1(math.log(speed)-speed_log)}
except boundary.TemkinWindowedBoundaryRangeError as error:
    projection={'accepted':False,'reason':str(error)}

report={
    'schema':'mhdlab-windowed-packet-velocity-quantization-probe-v1',
    'module_sha256':hashlib.sha256((ROOT/'mhdlab/temkin_windowed_boundary.py').read_bytes()).hexdigest(),
    'temperature_k':temperature,'mass_kg':mass,'released_parents':parents,
    'normal_speed_log_m_s':speed_log,'normal_projection':projection,
    'expected_macroscopic_flux_thermal_energy_j':float(2*Fraction(KB)*Fraction(temperature)*Fraction(parents)),
    'momentum_of_rounded_normal_speed_kg_m_s':float(Fraction(mass)*Fraction(projection.get('speed_m_s',minimum))),
    'scope':'New exponential-projection helper probe; no source/history replay, previous suite, gap physics or spectra.',
    'finding':'A positive finite speed alone does not qualify its projection from the thermal draw; momentum can remain normal-range while velocity has coarse subnormal rounding.'
}
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps(report,indent=2,allow_nan=False))
