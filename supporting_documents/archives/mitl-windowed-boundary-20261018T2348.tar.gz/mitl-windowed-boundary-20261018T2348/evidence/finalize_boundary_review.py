"""Record the coordinator's final review schema without rerunning probes."""
import hashlib
import json
from pathlib import Path

work=Path(__file__).resolve().parent
prior=json.loads((work/'windowed_packet_review_completion.json').read_text())
pins={str(Path(record['path']).relative_to('/workspace/Power-Flow')):record['sha256']
      for record in prior['reviewed_code']}
for relative,digest in pins.items():
    if hashlib.sha256((Path('/workspace/Power-Flow')/relative).read_bytes()).hexdigest()!=digest:
        raise SystemExit(f'Reviewed file changed: {relative}')
artifacts={str(Path(record['path']).relative_to(work)):record['sha256'] for record in prior['evidence']}
artifacts['windowed_packet_review_completion.json']=hashlib.sha256((work/'windowed_packet_review_completion.json').read_bytes()).hexdigest()
report={
    'schema':'mhdlab-windowed-boundary-independent-review-completion-v1',
    'reviewed_source_sha256':pins,
    'artifact_sha256':artifacts,
    'new_projection_checks_passed':12,
    'open_substantive_findings':[],
    'closed_substantive_findings':prior['closed_substantive_findings'],
    'pre_fix_evidence':{
        name:artifacts[name] for name in (
            'momentum_quantization_probe.py','momentum_quantization_probe.json','momentum_quantization_initial.log',
            'velocity_quantization_probe.py','velocity_quantization_probe.json','velocity_quantization_initial.log')},
    'old_suites_or_source_evolution_repeated':False,
    'ordinary_examples_repeated':False,
    'host_budget_accepted':False,
    'limits':prior['scope_limits'],
    'contract_conclusions':prior['read_only_contract_conclusions']
}
path=work/'windowed_boundary_review_completion.json'
path.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps({'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
                  'reviewed_source_sha256':pins,'new_projection_checks_passed':12,
                  'open_substantive_findings':[]},indent=2))
