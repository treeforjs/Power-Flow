"""Freeze the verified partial-source boundary interfaces and new evidence."""
from collections import Counter
import datetime
import hashlib
import importlib.metadata
import io
import json
from pathlib import Path
import re
import shutil
import subprocess
import tarfile
import tokenize
import xml.etree.ElementTree as ET

repo = Path('/workspace/Power-Flow')
work = Path(__file__).resolve().parent
out = Path('/workspace/handoffs/mitl-windowed-boundary-20261018T2348')
base = '5038bcbfaaf5eb8b270353fb2bdfac6d25eb926d'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo, text=True).strip()
commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
listing = json.loads((out / 'source_file_list.json').read_text())
for name in listing['byte_identical_public_files']:
    assert (out / 'source' / name).read_bytes() == (repo / name).read_bytes(), name
tree = ET.parse(work / 'isolated-results.xml').getroot()
cases = tree.findall('.//testcase')
assert cases and not tree.findall('.//failure') and not tree.findall('.//error') and not tree.findall('.//skipped')
counts = dict(Counter(case.attrib['classname'] for case in cases))
assert len(counts) == 3
assert next(value for name, value in counts.items() if name.endswith('test_temkin_windowed_source')) == 67
review = json.loads((work / 'windowed_boundary_review_completion.json').read_text())
assert not review['open_substantive_findings']
for name, digest in review['reviewed_source_sha256'].items():
    assert sha(repo / name) == digest, name
example = json.loads((work / 'windowed-packet-example/report.json').read_text())
for name, digest in example['source_sha256'].items():
    assert sha(repo / name) == digest, name
for name, digest in example['output_sha256'].items():
    assert sha(work / 'windowed-packet-example' / name) == digest, name
assert example['host_budget_accepted'] is False and example['parameter_status'] == 'manufactured'
readback = json.loads((work / 'windowed-packet-readback/report.json').read_text())
assert readback['status'] == 'passed' and readback['components'] == 48 and readback['packets_checked'] == 512
assert readback['input_report_sha256'] == sha(work / 'windowed-packet-example/report.json')
for name, digest in readback['output_sha256'].items():
    assert sha(work / 'windowed-packet-readback' / name) == digest, name
evidence = out / 'evidence'
evidence.mkdir(exist_ok=True)
for path in work.iterdir():
    if path.is_file() and path.suffix in {'.py', '.json', '.jsonl', '.log', '.xml', '.md'} and not path.name.startswith('freeze-windowed-handoff'):
        shutil.copyfile(path, evidence / path.name)
for dirname in ('windowed-packet-example', 'windowed-packet-readback'):
    shutil.copytree(work / dirname, evidence / dirname, dirs_exist_ok=True)
with (out / 'windowed-boundary.patch').open('wb') as stream:
    subprocess.run(['git', 'diff', base, 'HEAD'], cwd=repo, stdout=stream, check=True)
record = {
    'schema': 'mitl-windowed-boundary-verification-v1',
    'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source_commit': commit, 'branch': 'research/flash-publication-foundation', 'base_commit': base,
    'commits': subprocess.check_output(['git', 'log', '--reverse', '--format=%H %s', base + '..HEAD'], cwd=repo, text=True).splitlines(),
    'results': {'new_unique_tests': len(cases), 'isolated_passed': len(cases), 'isolated_skipped': 0,
                'isolated_file_pass_counts': counts, 'public_files_byte_identical': len(listing['byte_identical_public_files']),
                'packaging_wrappers': len(listing['packaging_wrappers']),
                'source_example_conditioned_components': 48, 'source_example_packets': 512,
                'independent_readback_full_width_controls': readback['full_width_functional_controls'],
                'unchanged_project_suites_repeated': False, 'previous_source_history_evolution_repeated': False,
                'saved_reference_oracles_repeated': False},
    'runtime': {'packages': {name: importlib.metadata.version(name) for name in ('numpy', 'scipy', 'h5py', 'pytest')}},
    'independent_review': review, 'independent_readback': readback,
    'commands': [json.loads(line) for line in (work / 'commands.jsonl').read_text().splitlines()],
    'input_labels': {'tests': 'manufactured', 'example': 'one preserved manufactured source HDF; arbitrary generic-state masses, no physical water inputs',
                     'response_controls': 'fixed source-launch functionals and manufactured finite aperture; no physical spectra'},
    'limitations': [
        'Numerical/error allowances are estimated and representation-specific, not certified interval bounds or experimental uncertainty.',
        'Canonical history validation replays its existing contract; the old source evolution driver and saved oracles were not rerun.',
        'Positive partial density can underflow while its physical count is represented; every positive original component is retained or the packet call fails explicitly.',
        'Local source delay is required to be represented; best-effort global time has independent precision flags. Source emission and recorded photon gates have separate meanings.',
        'Velocities and momentum have projection/quantization guards. Sampled energy is reported separately from expected 2*kB*T and is never repaired by rescaling.',
        'Unequal packet weights, signed number closure and actual launch-energy treatment require an owner ledger. No host transaction or feedback is accepted.',
        'Physical water parameters, physical monolayer inference, absolute VUV normalization and original diagnostics remain unresolved.',
        'No separately owned solver/state-data development, Quark source/build/runner, actual FLASH run, remote push/merge/publish or external messages.',
    ],
    'next_task': 'Implement deterministic conditional-window timing/joint moments and use them to qualify weighted windowed-launch sampling; preserve component mixtures and estimated quadrature/range limits. Continue owner-only response acceptance when actual collection/loss/field definitions are supplied.',
}
(out / 'verification.json').write_text(json.dumps(record, indent=2, allow_nan=False) + '\n')
(out / 'systems-mitl-windowed-boundary-10182026.md').write_text(f'''# MITL boundary launches from partial source windows

Power-Flow is pinned to `{commit}` on `research/flash-publication-foundation`.
Local commits separate canonical source conditioning, paired packet sampling and
the export interface. `windowed-boundary.patch` contains this pass's changes.
The previous packet is
`/workspace/handoffs/mitl-emission-windows-20261018T2248.tar.gz`.

The conditioner retains each original interval/pool/current/width association,
actual patch area, initial population, exact supplied state and frozen local
temperature. Explicit selections use offsets inside original intervals; repeated
and overlapping selections are rejected. An authoritative immutable canonical
history supports revalidation of original densities, temperatures, geometry,
metadata and exact-zero skips. No new history is evolved. Positive partial
components remain present even when a density underflows; physical counts and
energies keep independent representation qualifications.

The paired sampler changes only launch width position. Component, source time,
state, temperature, current/normal position, mass, weight, velocity and momentum
remain the same in each pair. Mandatory packets retain every positive component;
exact represented-count CDF refinement avoids discarding tiny components through
probability underflow. Per-component weights may differ and retain signed number
closure. Expected translation, sampled translation, supplied internal/removal
costs and actual weighted wall debit are reported separately. No velocity or
inventory repair forces the sampled energy to its expectation.

Original interval origin, window start, local delay and log delay stay separate.
Best-effort global times have explicit precision flags. Local position offsets
remain available alongside projected positions. Projection/quantization guards
reject unsupported positive packet weights, speeds, Cartesian velocities and
momenta. Independent review found and closed coarse-subnormal velocity and
momentum distortions before freeze; the original focused evidence remains.

All {len(cases)} new checks passed in the portable subset. File counts and exact
commands/exits/log hashes appear in `verification.json`; earlier passing suites,
the previous source evolution and saved reference oracles were not rerun.
The source subset contains byte-identical public files and four named packaging
wrappers. The compressed archive and every manifest payload are verified by
the recorded delivery check. Commands after freezing remain in the local pass's
`commands.jsonl`.

After the bounded implementation, one preserved manufactured source HDF was
conditioned on two partial windows, retaining 48 components in 512 packets. An
independent NPZ/HDF readback checked original associations, explicit variates,
velocities, momenta, weighted number and expected/sampled energies without
calling a history loader, source evolution, scalar window or packet sampler.
Ten exact-rational fixed linear full-width launch controls match. A manufactured
partial aperture distinguishes the paired launch positions. These are numerical
source controls; they do not establish spectral distinguishability.

The error envelopes are estimates, not certified bounds. Source-emission windows
are separate from photon recording gates. Unequal weights and actual sampled
energy require explicit downstream support and ledger acceptance;
`host_budget_accepted` remains false. No gap, collision, radiation, molecular
state data, thermal feedback, charged trajectory or actual FLASH run was added.
Quark integration remains an owner handoff. Nothing was pushed or published.

The selected next task is deterministic window-conditioned timing/joint moments
and weighted sampling qualification. Actual response/collection/loss/field
definitions remain owner inputs. Physical water coverage, absolute VUV
normalization, original diagnostics and installed FLASH/workstation setup remain
unresolved. Read `source/docs/temkin_windowed_boundary.md` for the exact API.
''')
for path in sorted(out.rglob('*'), key=lambda p: len(p.parts), reverse=True):
    if path.is_dir() and path.name in {'__pycache__', '.pytest_cache'}:
        shutil.rmtree(path)
    elif path.is_symlink():
        raise ValueError('Unexpected delivery symlink')
words = [[65,73],[67,108,97,117,100,101],[67,104,97,116,71,80,84],[79,112,101,110,65,73],[67,111,100,101,120],[67,111,112,105,108,111,116],[76,76,77]]
pattern = re.compile(r'\b(?:' + '|'.join(''.join(map(chr, w)) for w in words) + r')\b', re.I)
for path in out.rglob('*'):
    if path.is_file() and path.suffix in {'.py', '.md', '.json', '.jsonl', '.log', '.patch', '.xml', '.txt'}:
        content = path.read_text()
        if path.suffix == '.py':
            content = '\n'.join(t.string for t in tokenize.generate_tokens(io.StringIO(content).readline) if t.type in {tokenize.STRING, tokenize.COMMENT})
        assert not pattern.search(content), path
files = [p for p in sorted(out.rglob('*')) if p.is_file() and p.name != 'MANIFEST.sha256']
(out / 'MANIFEST.sha256').write_text(''.join(f'{sha(p)}  {p.relative_to(out).as_posix()}\n' for p in files))
archive = out.with_suffix('.tar.gz')
with tarfile.open(archive, 'w:gz') as stream:
    stream.add(out, arcname=out.name)
archive.with_suffix(archive.suffix + '.sha256').write_text(f'{sha(archive)}  {archive.name}\n')
print(json.dumps({'archive': str(archive), 'sha256': sha(archive), 'bytes': archive.stat().st_size,
                  'manifest_entries': len(files), 'source_commit': commit, 'results': record['results']}, indent=2))
