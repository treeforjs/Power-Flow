"""Verify the actual compressed delivery and its public/input associations."""
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import subprocess
import tarfile

import numpy as np

work = Path(__file__).resolve().parent
out = Path('/workspace/handoffs/mitl-windowed-boundary-20261018T2348')
archive = out.with_suffix('.tar.gz')
repo = Path('/workspace/Power-Flow')
sha = lambda value: hashlib.sha256(value).hexdigest()
with tarfile.open(archive, 'r:gz') as stream:
    members = stream.getmembers()
    assert len({member.name for member in members}) == len(members)
    for member in members:
        name = PurePosixPath(member.name)
        assert not name.is_absolute() and '..' not in name.parts and name.parts[0] == out.name
        assert member.isdir() or member.isfile(), member.name
    payload = {PurePosixPath(member.name).relative_to(out.name).as_posix(): stream.extractfile(member).read()
               for member in members if member.isfile()}
manifest = {}
for line in payload['MANIFEST.sha256'].decode().splitlines():
    digest, name = line.split('  ', 1)
    assert name not in manifest
    manifest[name] = digest
assert set(payload) == set(manifest) | {'MANIFEST.sha256'}
for name, digest in manifest.items():
    assert sha(payload[name]) == digest, name
listing = json.loads(payload['source_file_list.json'])
for name in listing['byte_identical_public_files']:
    assert payload['source/' + name] == (repo / name).read_bytes(), name
expected = {
    'mhdlab/temkin_windowed_source.py', 'mhdlab/temkin_windowed_boundary.py',
    'tests/test_temkin_windowed_source.py', 'tests/test_temkin_windowed_boundary.py',
    'tests/test_temkin_windowed_cli.py', 'tools/sample_temkin_source_windows.py',
    'configs/temkin_windowed_packets_manufactured.json', 'docs/temkin_windowed_boundary.md',
}
changed = set(subprocess.check_output(['git', 'diff', '--name-only', '5038bcbfaaf5eb8b270353fb2bdfac6d25eb926d', 'HEAD'], cwd=repo, text=True).splitlines())
assert changed == expected and changed.issubset(set(listing['byte_identical_public_files']))
record = json.loads(payload['verification.json'])
commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
assert commit == record['source_commit']
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=repo, text=True).strip()
review = record['independent_review']
assert not review['open_substantive_findings']
for name, digest in review['reviewed_source_sha256'].items():
    assert sha(payload['source/' + name]) == digest, name
example_dir = 'evidence/windowed-packet-example/'
example = json.loads(payload[example_dir + 'report.json'])
for name, digest in example['source_sha256'].items():
    assert sha(payload['source/' + name]) == digest, name
for name, digest in example['output_sha256'].items():
    assert sha(payload[example_dir + name]) == digest, name
assert example['host_budget_accepted'] is False
assert example['conditioned_source']['host_budget_accepted'] is False
assert example['packets']['host_budget_accepted'] is False
with np.load(io.BytesIO(payload[example_dir + 'boundary_packets.npz']), allow_pickle=False) as packets:
    metadata = json.loads(str(packets['metadata_json']))
    assert metadata == example['packets']
    assert set(packets.files) == set(metadata['array_units']) | {'metadata_json', 'state_ids', 'reservoir_names'}
    assert packets['particle_weight'].shape == (512,)
    assert packets['component_released_particles'].shape == (48,)
readback_dir = 'evidence/windowed-packet-readback/'
readback = json.loads(payload[readback_dir + 'report.json'])
assert readback == record['independent_readback'] and readback['status'] == 'passed'
assert readback['input_report_sha256'] == sha(payload[example_dir + 'report.json'])
for name, digest in readback['output_sha256'].items():
    assert sha(payload[readback_dir + name]) == digest, name
result = {
    'archive': str(archive), 'sha256': sha(archive.read_bytes()), 'bytes': archive.stat().st_size,
    'manifest_entries': len(manifest), 'archive_regular_files': len(payload), 'unsafe_archive_entries': 0,
    'public_files_byte_identical': len(listing['byte_identical_public_files']), 'source_commit': commit,
    'public_paths_changed': sorted(changed), 'verifier_script_sha256': sha(Path(__file__).read_bytes()),
    'results': record['results'],
}
(work / 'delivery_verification.json').write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
print(json.dumps(result, indent=2, allow_nan=False))
