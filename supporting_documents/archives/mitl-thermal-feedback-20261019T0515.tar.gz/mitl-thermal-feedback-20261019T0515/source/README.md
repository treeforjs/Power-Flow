# Manufactured thermal/desorption-feedback reference patch

This handoff contains five new public files and a patch over the complete checkout
at `b27b04fb38238c831e12bf2f3cdfe945e5834d58`. Apply the patch to that exact baseline before importing the module,
running the CLI or evaluating the tests. The source/ directory is a review subset,
not a standalone package. No package initializer or dependency closure is supplied.
The requirements wrapper copies the baseline requirements.txt byte-for-byte;
follow the complete checkout's setup instructions and retained package initializer.

The new reference is a zero-power, stationary single manufactured patch with a
supplied constant areal heat capacity and a finite Temkin parent inventory. It
tracks wall temperature and separate removal, gas internal and expected thermal
translation channels. Supplied manufactured coefficients do not establish actual
foil properties, physical water coverage, phase behavior, external heating,
FLASH/source feedback, host acceptance or an observed spectrum.

Saved new targeted tests, independent analytic/time-map oracle, producer inputs,
trajectories, refinement and per-channel signed residuals are preserved. Finite
quadrature/refinement changes are numerical evidence under their declared ranges,
not certified error bounds. Packaging executes no reference, test, oracle, old
suite or portable environment. The archived reports state the actual new commands.
