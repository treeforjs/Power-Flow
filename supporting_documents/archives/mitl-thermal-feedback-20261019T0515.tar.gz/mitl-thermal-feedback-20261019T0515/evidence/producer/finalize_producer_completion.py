"""Bind one saved production batch and its input/parser evidence; no model calls."""
from pathlib import Path
import csv,datetime,hashlib,json
work=Path(__file__).resolve().parent;root=work.parent;repo=Path('/workspace/Power-Flow');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
output=work/'reference-run';report=json.loads((output/'report.json').read_text());freeze=json.loads((work/'before_run_freeze.json').read_text())
for p,h in freeze['public_source_sha256'].items():assert sha(repo/p)==h
assert report['code_sha256']=={p:h for p,h in freeze['public_source_sha256'].items() if p!='configs/thermal_feedback_manufactured.json'}
assert report['config_sha256']==freeze['public_source_sha256']['configs/thermal_feedback_manufactured.json']
assert sha(output/'input_config.json')==report['config_sha256']
for name,h in report['artifact_sha256'].items():assert sha(output/name)==h
assert report['case_count']==6 and report['numerical_trajectory_count']==9 and len(report['temporal_refinement'])==30
pairs={(item['case_id'],item['steps']) for item in report['trajectories']};expected={(case,n) for case,steps in freeze['planned_grids'].items() for n in steps};assert pairs==expected
rowcount=0
for item in report['trajectories']:
 with (output/item['csv_file']).open(newline='') as stream:rows=list(csv.DictReader(stream))
 assert len(rows)==item['sample_count']==item['steps']+1;rowcount+=len(rows)
 for key,value in item['final_sample'].items():
  actual=rows[-1][key]
  assert actual==value if type(value) is str else float(actual)==value
assert rowcount==289
entries=[json.loads(s) for s in (root/'commands.jsonl').read_text().splitlines()]
runs=[entry for entry in entries if 'tools/run_thermal_feedback_reference.py' in entry['command'] and '--output-dir' in entry['command']]
assert len(runs)==1 and runs[0]['exit_code']==0
parser1=json.loads((work/'config_guard_checks.json').read_text());parser2=json.loads((work/'numeric_lexeme_checks.json').read_text())
assert parser1['check_count']==9 and parser2['check_count']==5 and parser1['all_expectations_passed'] and parser2['all_expectations_passed']
versions=json.loads((work/'source_versions.json').read_text());assert versions['final_cli_sha256']==freeze['public_source_sha256']['tools/run_thermal_feedback_reference.py']
artifacts={str(p.relative_to(root)):sha(p) for p in work.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='completion.json'}
for name in ('thermal-feedback-first-reference-batch.log','feedback-cli-config-parser-guards.log','feedback-cli-new-json-number-guards.log','feedback-producer-freeze-before-first-batch.log','feedback-cli-preserve-version-evidence.log'):artifacts[name]=sha(root/name)
record={'schema':'mhdlab-feedback-producer-completion-v1','status':'passed_production_and_parser_checks','completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Saved manufactured production and parser/artifact binding only. Numerical oracle agreement is recorded separately; no physical validation or host acceptance is claimed.','public_source_sha256':freeze['public_source_sha256'],'producer_report':'producer/reference-run/report.json','producer_report_sha256':sha(output/'report.json'),'actual_positive_CLI_batch_count':1,'distinct_trajectory_count':9,'case_count':6,'saved_CSV_sample_count':289,'temporal_refinement_row_count':30,'positive_batch':runs[0],'parser_checks':{'initial_count':9,'initial_CLI_sha256':parser1['script_sha256'],'initial_record_sha256':sha(work/'config_guard_checks.json'),'final_numeric_lexeme_count':5,'final_CLI_sha256':parser2['script_sha256'],'final_record_sha256':sha(work/'numeric_lexeme_checks.json'),'core_trajectory_calls_in_parser_checks':0,'initial_source_capture':versions['initial_version_capture']},'all_output_hashes_reopened_and_verified':True,'CSV_final_rows_match_saved_summary':True,'PNG_QA_visually_inspected':True,'numerical_reference_oracle_recomputed_here':False,'maintained_temperature_control_evolved_here':False,'physical_parameters_or_water_validated':False,'host_or_FLASH_coupling':False,'unsupported_domain_fallback':False,'old_suites_or_source_evolution_repeated':False,'open_producer_findings':[],'artifact_sha256':artifacts,'archive_excluded_paths':['producer/__pycache__/'],'limits':report['limits']}
p=work/'completion.json';p.write_text(json.dumps(record,indent=2,allow_nan=False)+'\n');print(json.dumps({'completion':str(p),'completion_sha256':sha(p),'report_sha256':sha(output/'report.json'),'status':record['status'],'actual_batches':1,'trajectories':9,'CSV_samples':289,'oracle_recomputed_here':False},indent=2))
