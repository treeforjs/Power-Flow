"""Only new raw-number parser regressions; no core import or numerical calls."""
import hashlib,importlib.util,json,sys,tempfile
from pathlib import Path
repo=Path('/workspace/Power-Flow');script=repo/'tools/run_thermal_feedback_reference.py';config=repo/'configs/thermal_feedback_manufactured.json'
spec=importlib.util.spec_from_file_location('new_feedback_json_lexeme_guards',script);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
raw=config.read_text();assert raw.count('"external_power_w_m2": 0')==1
rows=[]
for token in ('1e-1000','-1e-1000','1e1000','-1e1000'):
 changed=raw.replace('"external_power_w_m2": 0','"external_power_w_m2": '+token)
 with tempfile.TemporaryDirectory() as td:
  p=Path(td)/'input.json';p.write_text(changed)
  try:m.load_config(p)
  except ValueError as exc:rows.append({'raw_lexeme':token,'rejected':True,'error':str(exc)})
  else:raise AssertionError(token)
valid=m.load_config(config);assert len(valid['cases'])==6 and sum(len(c['steps']) for c in valid['cases'])==9
rows.append({'case':'normal explicit manufactured configuration','accepted':True,'planned_trajectories':9})
assert 'mhdlab.thermal_feedback_reference' not in sys.modules
out=Path(__file__).resolve().parent/'numeric_lexeme_checks.json';report={'schema':'mhdlab-feedback-cli-json-number-guards-v1','script_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),'config_sha256':hashlib.sha256(config.read_bytes()).hexdigest(),'checks':rows,'check_count':5,'all_expectations_passed':True,'core_imported_or_called':False,'feedback_trajectories_evaluated':0};out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'checks':5,'all_expectations_passed':True,'core_imported_or_called':False,'report_sha256':hashlib.sha256(out.read_bytes()).hexdigest()},indent=2))
