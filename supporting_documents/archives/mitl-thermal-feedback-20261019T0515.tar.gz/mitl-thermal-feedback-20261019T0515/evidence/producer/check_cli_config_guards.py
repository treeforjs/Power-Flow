"""New parser-only checks; no core import or feedback trajectory is evaluated."""
import copy,hashlib,importlib.util,json,sys,tempfile
from pathlib import Path
root=Path('/workspace/Power-Flow');script=root/'tools/run_thermal_feedback_reference.py'
spec=importlib.util.spec_from_file_location('new_feedback_cli_parser_only',script);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
config=root/'configs/thermal_feedback_manufactured.json';original=json.loads(config.read_text());rows=[]
valid=m.load_config(config);assert len(valid['cases'])==6 and sum(len(c['steps']) for c in valid['cases'])==9
rows.append({'case':'explicit valid manufactured plan','accepted':True,'case_count':6,'distinct_planned_trajectories':9})
def reject(name,change):
 d=copy.deepcopy(original);change(d)
 with tempfile.TemporaryDirectory() as td:
  p=Path(td)/'input.json';p.write_text(json.dumps(d))
  try:m.load_config(p)
  except ValueError as exc:rows.append({'case':name,'accepted':False,'error':str(exc)})
  else:raise AssertionError(name)
reject('nonzero heating power unsupported',lambda d:d.__setitem__('external_power_w_m2',1.))
reject('boolean power cannot alias zero',lambda d:d.__setitem__('external_power_w_m2',False))
reject('physical status unsupported',lambda d:d.__setitem__('parameter_status','sourced'))
reject('boolean duration unsupported',lambda d:d['cases'][0].__setitem__('duration_s',True))
reject('boolean step unsupported',lambda d:d['cases'][0].__setitem__('steps',[True]))
reject('unordered or duplicate step grid unsupported',lambda d:d['cases'][0].__setitem__('steps',[32,16,32]))
reject('unsafe case path unsupported',lambda d:d['cases'][0].__setitem__('case_id','../case'))
reject('unknown case keys unsupported',lambda d:d['cases'][0].__setitem__('auto_water_defaults',True))
assert 'mhdlab.thermal_feedback_reference' not in sys.modules
out=Path(__file__).resolve().parent/'config_guard_checks.json';out.write_text(json.dumps({'schema':'mhdlab-feedback-cli-parser-guards-v1','script_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),'config_sha256':hashlib.sha256(config.read_bytes()).hexdigest(),'checks':rows,'check_count':len(rows),'all_expectations_passed':True,'core_imported_or_called':False,'feedback_trajectories_evaluated':0},indent=2)+'\n')
print(json.dumps({'checks':len(rows),'all_expectations_passed':True,'core_imported_or_called':False,'feedback_trajectories_evaluated':0,'report_sha256':hashlib.sha256(out.read_bytes()).hexdigest()},indent=2))
