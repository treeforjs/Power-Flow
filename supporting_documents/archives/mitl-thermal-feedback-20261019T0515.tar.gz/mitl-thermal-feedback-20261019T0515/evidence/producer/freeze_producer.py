"""Pin the manufactured plan after core tests, before any CLI trajectories."""
from pathlib import Path
import datetime,hashlib,json
r=Path('/workspace/Power-Flow');w=Path(__file__).resolve().parent;root=w.parent;sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
config=json.loads((r/'configs/thermal_feedback_manufactured.json').read_text());assert len(config['cases'])==6 and sum(len(c['steps']) for c in config['cases'])==9
assert sha(r/'mhdlab/thermal_feedback_reference.py')=='3fbded5bc801fac4e847195ecd5ad369142d3ab56e70848c4501ea1425d61cf8'
entries=[json.loads(line) for line in (root/'commands.jsonl').read_text().splitlines()]
runs=[row for row in entries if 'tools/run_thermal_feedback_reference.py' in row['command'] and '--output-dir' in row['command']]
assert not runs
for name in ('config_guard_checks.json','numeric_lexeme_checks.json'):
 d=json.loads((w/name).read_text());assert d['all_expectations_passed'] and not d['core_imported_or_called']
record={'schema':'mhdlab-feedback-producer-before-run-freeze-v1','frozen_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'public_source_sha256':{p:sha(r/p) for p in ('tools/run_thermal_feedback_reference.py','configs/thermal_feedback_manufactured.json','mhdlab/thermal_feedback_reference.py')},'case_ids':[c['case_id'] for c in config['cases']],'planned_distinct_trajectories':9,'planned_grids':{c['case_id']:c['steps'] for c in config['cases']},'positive_CLI_batches_before_freeze':0,'output':'producer/reference-run','core_test_gate':{'initial_targeted_passed':34,'initial_log_sha256':'28e0bf7bda0f2584337dc33adf153458ed9935b490e154ad1903447d1a9838ca','changed_guard_targeted_passed':6,'changed_guard_log_sha256':'bdc1acba3f67a587514f140b9659260e2528e27548a6edb541e2fda90635ceac'},'parser_guard_checks':14,'reference_control':'Independent oracle only; no maintained-T source replay by CLI.'}
p=w/'before_run_freeze.json';p.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
