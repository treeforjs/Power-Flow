"""Preserve exact CLI versions without rerunning parser or reference checks."""
from pathlib import Path
import difflib,hashlib,json
r=Path('/workspace/Power-Flow');w=Path(__file__).resolve().parent
p=r/'tools/run_thermal_feedback_reference.py';current=p.read_text();old=current.replace('from decimal import Decimal, InvalidOperation\n','')
start=old.index('def _json_float(token):\n');end=old.index('def _object(pairs):\n',start);old=old[:start]+old[end:]
a='    config = json.loads(path.read_text(), object_pairs_hook=_object,\n                        parse_float=_json_float, parse_constant=_reject_constant)'
b='    config = json.loads(path.read_text(), object_pairs_hook=_object, parse_constant=_reject_constant)'
assert old.count(a)==1;old=old.replace(a,b)
sha=lambda data:hashlib.sha256(data).hexdigest()
initial_record=json.loads((w/'config_guard_checks.json').read_text());final_record=json.loads((w/'numeric_lexeme_checks.json').read_text())
assert sha(old.encode())==initial_record['script_sha256'],(sha(old.encode()),initial_record['script_sha256'])
assert sha(current.encode())==final_record['script_sha256']
out=w/'source-versions';out.mkdir(exist_ok=True)
(out/'initial_cli_before_numeric_lexeme_guard.py').write_text(old)
(out/'final_cli.py').write_text(current)
(out/'numeric_lexeme_guard.diff').write_text(''.join(difflib.unified_diff(old.splitlines(keepends=True),current.splitlines(keepends=True),fromfile='initial_cli_before_numeric_lexeme_guard.py',tofile='final_cli.py')))
record={'schema':'mhdlab-feedback-cli-source-version-evidence-v1','initial_cli_sha256':sha(old.encode()),'initial_version_capture':'Byte-exact reconstruction by reversing only the recorded numeric-lexeme guard patch; verified against source SHA256 captured during the original nine parser checks. Not claimed as an original pre-edit file capture.','final_cli_sha256':sha(current.encode()),'initial_parser_record_sha256':sha((w/'config_guard_checks.json').read_bytes()),'final_parser_record_sha256':sha((w/'numeric_lexeme_checks.json').read_bytes()),'source_files_sha256':{str(p.relative_to(w)):sha(p.read_bytes()) for p in out.iterdir()},'parser_or_reference_checks_repeated':False}
(w/'source_versions.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record,indent=2))
