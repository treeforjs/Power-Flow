"""Freeze a planning selection after the already-saved independent pass gate."""
import datetime
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
PASS = HERE.parent
REPO = Path('/workspace/Power-Flow')
ORACLE_PIN = '5502b5a2c9496d2701d28cfaa4986b5d1e88e472d55d3a8e21e6fbe21541551b'
CORE_PIN = '3fbded5bc801fac4e847195ecd5ad369142d3ab56e70848c4501ea1425d61cf8'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


oracle_path = PASS / 'independent-verification/oracle-initial/report.json'
assert sha(oracle_path) == ORACLE_PIN
oracle = json.loads(oracle_path.read_text())
assert oracle['status'] == 'passed' and oracle['all_checks_passed'] is True
assert oracle['parameter_status'] == 'manufactured'
assert oracle['distinct_cases'] == 6 and oracle['distinct_saved_trajectories'] == 9
assert oracle['saved_sample_rows_checked'] == 289
assert oracle['source_model_imports'] == []
assert oracle['positive_core_or_CLI_calls'] == 0 and oracle['source_or_old_suite_calls'] == 0
core = REPO / 'mhdlab/thermal_feedback_reference.py'
assert sha(core) == CORE_PIN
proposal = HERE / 'power_reference_proposal.json'
conditional = HERE / 'conditional-selection.json'
lead_path = PASS / 'source-acquisition/completion.json'
lead = json.loads(lead_path.read_text())
assert lead['status'] == 'metadata_verified_no_public_fulltext_location'
document = {
    'schema': 'mhdlab-next-upstream-scientific-task-selection-v1',
    'status': 'selected_manufactured_prescribed_power_reference',
    'selected': True,
    'selected_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'selected_task': 'Implement and independently verify a separate manufactured single-patch prescribed-power reference with an explicit external-input energy ledger, first qualified at zero activation barrier.',
    'why_new_and_useful': 'The current reference explicitly has zero input power. This adds finite constant/piecewise-constant manufactured heating and an independently checkable forced thermal trajectory without installing physical foil or source-history coupling.',
    'proposal': proposal.name, 'proposal_sha256': sha(proposal),
    'prior_conditional_record': conditional.name, 'prior_conditional_record_sha256': sha(conditional),
    'current_pass_gate': {
        'status': 'passed_before_selection',
        'oracle_report': 'independent-verification/oracle-initial/report.json',
        'oracle_report_sha256': ORACLE_PIN,
        'oracle_schema': oracle['schema'], 'all_checks_passed': True,
        'distinct_cases': 6, 'distinct_saved_trajectories': 9, 'saved_sample_rows_checked': 289,
        'oracle_source_model_imports': [], 'oracle_positive_core_or_CLI_calls': 0,
        'oracle_old_suite_or_source_calls': 0,
        'oracle_input_sha256': oracle['input_sha256'],
        'existing_core': 'mhdlab/thermal_feedback_reference.py', 'existing_core_sha256': CORE_PIN,
        'existing_core_scope': 'Manufactured zero-power joint N/T RK4 with explicit channels and strict domain/representation guards.'
    },
    'first_qualified_branch': {
        'zero_activation_barrier_only': True,
        'power': 'Explicit finite constant or piecewise-constant nonnegative areal P(t), with breakpoint-aligned numerical stages and independent exact segment input-energy integrals.',
        'independent_reference': 'Exact exponential inventory and a fresh forced-temperature integrating-factor quadrature; independent translation quadrature, not recovery from the energy residual.',
        'nonzero_barrier_gate': 'Reject in the first qualified implementation unless fresh independent coupled-IVP, precision/refinement and channel evidence is supplied for that actual forced problem.',
        'temperature_effect_on_release_claimed': False,
        'physical_input_or_host_acceptance_claimed': False
    },
    'source_lead_gate': {
        'doi': lead['doi'], 'verified_title': lead['title'],
        'record': 'source-acquisition/completion.json', 'record_sha256': sha(lead_path),
        'status': lead['status'], 'full_text_acquired': False, 'physical_parameters_adopted': 0,
        'target_304_foil_transfer_established': False,
        'next_gate': 'A newly verified legitimate full-text location or supplied copy, followed by preparation/adsorbate/inventory/protocol and target-material assessment.'
    },
    'implementation_authorization': 'Queue selection only. A fresh bounded editing lease and assigned paths are required before the next public implementation starts.',
    'current_scope_unmodified': 'No changes to the completed zero-power core or its saved data, existing source/history/host/CR/gap modules or physical material inputs.',
    'public_files_edited': False, 'network_used': False,
    'numerical_producer_or_model_executed': False,
    'old_suites_or_source_evolution_repeated': False, 'physical_parameters_adopted': 0,
    'status_read_sha256': sha(Path('/workspace/research_work/mitl-upstream-status.json')),
    'lease_sha256': sha(PASS / 'lease.json'),
    'writer_sha256': sha(Path(__file__)),
    'selection_limit': 'Planning and read-only saved-pass association checks. Proposed forced-power equations are not an executed trajectory, physical wall model or validated nonzero-barrier feedback branch.'
}
target = HERE / 'selection.json'
assert not target.exists()
target.write_text(json.dumps(document, indent=2, allow_nan=False)+'\n')
print(json.dumps({'selection': str(target), 'selection_sha256': sha(target),
                  'proposal_sha256': sha(proposal), 'oracle_gate_sha256': ORACLE_PIN,
                  'selected_task': document['selected_task'], 'public_edits': False,
                  'numerical_model_execution': False}, indent=2))
