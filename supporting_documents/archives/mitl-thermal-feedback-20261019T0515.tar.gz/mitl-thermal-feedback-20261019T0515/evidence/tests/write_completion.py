"""Freeze one completed new core-test run without repeating it."""
import datetime
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parent
WORK=ROOT.parent
REPO=Path('/workspace/Power-Flow')
CORE='mhdlab/thermal_feedback_reference.py'
CORE_SHA='2b200b66da0774db07bdbdcd4bc23180029bb26532e1c24ae0b3b21692ec2cd4'
TEST='tests/test_thermal_feedback_reference.py'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

assert not (ROOT/'completion.json').exists()
assert sha(REPO/CORE)==CORE_SHA
entries=[json.loads(line) for line in (WORK/'commands.jsonl').read_text().splitlines()]
matches=[row for row in entries if Path(row['log']).name=='thermal-feedback-core-initial.log']
assert len(matches)==1
command=matches[0]
assert command['exit_code']==0 and sha(Path(command['log']))==command['log_sha256']
assert command['command'][4:7]==['pytest','-q',TEST]
suite=ET.parse(ROOT/'core-initial.xml').getroot()
cases=suite.findall('.//testcase')
assert len(cases)==34 and not suite.findall('.//failure') and not suite.findall('.//error') and not suite.findall('.//skipped')
assert len({(case.attrib['classname'],case.attrib['name']) for case in cases})==34
for row in suite.findall('testsuite'):
    assert int(row.attrib['failures'])==int(row.attrib['errors'])==int(row.attrib['skipped'])==0
public={CORE:CORE_SHA,TEST:sha(REPO/TEST)}
artifacts={'tests/core-initial.xml':sha(ROOT/'core-initial.xml'),
    'tests/write_completion.py':sha(Path(__file__)),
    'thermal-feedback-core-initial.log':command['log_sha256']}
result={'schema':'mitl-thermal-feedback-core-tests-v1','status':'passed','all_checks_passed':True,
    'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'public_source_sha256':public,'artifact_sha256':artifacts,
    'targeted_test_runs':1,'new_core_tests_passed':34,'new_core_tests_failed':0,
    'new_core_tests_errors':0,'new_core_tests_skipped':0,'warnings_as_errors':True,
    'old_suites_repeated':False,'old_source_evolution_repeated':False,
    'portable_test_execution_claimed':False,
    'manufactured_only':True,'physical_parameters_adopted':0,'actual_FLASH_run':False,
    'command':command,'test_cases':[case.attrib['name'] for case in cases],
    'scope':['One zero-barrier joint trajectory is checked against independent exponential inventory and analytic T(N), with thermal, bound-reference, emitted translation, internal and removal channels checked separately.',
        'The fixed kinetic reference and rate barrier are checked independently of initial coverage and removal/internal costs using positive-barrier and zero-barrier RHS states.',
        'A binary area rescaling checks the extensive count and every emitted/thermal/reference energy exactly once, with immutable and detached outputs.',
        'The empty initial pool remains stationary with exact-zero budgets. Invalid parameters, booleans, time grids, domain exits, oversized stages and positive-flow/feedback representation failures reject.',
        'Only the new test file ran; no nonlinear time-map oracle, source evolution, previous suite or CLI production was repeated by this test pass.'],
    'limits':['These are manufactured local zero-power model controls, not target-material thermodynamics, physical water parameters, measured desorption or actual field/heating inputs.',
        'The shared CLI trajectories, independent time-inversion oracle and temporal refinement are separately owned evidence; this record does not claim their completion.',
        'No production host, FLASH, Quark, Boltzmann, collisional-radiative or kinetic gap solver is modified or executed.']}
target=ROOT/'completion.json';target.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps({'completion':str(target),'sha256':sha(target),'public_source_sha256':public,
    'all_checks_passed':True,'new_core_tests_passed':34},indent=2))
