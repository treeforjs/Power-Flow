"""Bind changed-input guard evidence to final and preserved initial source bytes."""
import ast
import datetime
import difflib
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parent
WORK=ROOT.parent
REPO=Path('/workspace/Power-Flow')
CORE='mhdlab/thermal_feedback_reference.py'
TEST='tests/test_thermal_feedback_reference.py'
INITIAL_CORE=WORK/'core/thermal_feedback_reference.initial.py'
INITIAL_TEST=ROOT/'test_thermal_feedback_reference.initial.py'
FINAL_CORE_SHA='3fbded5bc801fac4e847195ecd5ad369142d3ab56e70848c4501ea1425d61cf8'
INITIAL_COMPLETION_SHA='be663f5bf6135070ce3ccf144a29a61f12db0fe7dfa135d15d361597cb57ee77'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def identity(path):
    return {(case.attrib['classname'],case.attrib['name']) for case in ET.parse(path).getroot().findall('.//testcase')}

assert not (ROOT/'guard-completion.json').exists()
assert sha(ROOT/'completion.json')==INITIAL_COMPLETION_SHA
initial=json.loads((ROOT/'completion.json').read_text())
assert sha(INITIAL_CORE)==initial['public_source_sha256'][CORE]=='2b200b66da0774db07bdbdcd4bc23180029bb26532e1c24ae0b3b21692ec2cd4'
assert sha(INITIAL_TEST)==initial['public_source_sha256'][TEST]=='540e77bf9d435a59e464ab1d1bab589f01cd5c90b990ecd3f37679398be693ec'
assert sha(REPO/CORE)==FINAL_CORE_SHA
old_tree=ast.parse(INITIAL_CORE.read_text());new_tree=ast.parse((REPO/CORE).read_text())
strip=lambda tree:[ast.dump(node,include_attributes=False) for node in tree.body if not isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)) or node.name!='_real']
assert strip(old_tree)==strip(new_tree),'Change extends beyond _real input validation'
old_functions={node.name:ast.dump(node,include_attributes=False) for node in ast.parse(INITIAL_TEST.read_text()).body if isinstance(node,ast.FunctionDef)}
new_functions={node.name:ast.dump(node,include_attributes=False) for node in ast.parse((REPO/TEST).read_text()).body if isinstance(node,ast.FunctionDef)}
assert all(new_functions[key]==value for key,value in old_functions.items()),'An existing test changed'
diff=''.join(difflib.unified_diff(INITIAL_CORE.read_text().splitlines(keepends=True),
    (REPO/CORE).read_text().splitlines(keepends=True),fromfile='initial/thermal_feedback_reference.py',tofile='final/thermal_feedback_reference.py'))
assert diff
diff_path=ROOT/'core-input-guard.diff'
assert not diff_path.exists();diff_path.write_text(diff)
guard_xml=ROOT/'core-guard.xml'
guard_tree=ET.parse(guard_xml).getroot()
assert not guard_tree.findall('.//failure') and not guard_tree.findall('.//error') and not guard_tree.findall('.//skipped')
first=identity(ROOT/'core-initial.xml');changed=identity(guard_xml)
assert len(first)==34 and len(changed)==6 and len(first|changed)==39
repeated=first&changed
assert len(repeated)==1 and next(iter(repeated))[1]=='test_empty_inventory_remains_stationary_with_exact_zero_channels'
assert len(changed-first)==5
commands=[json.loads(line) for line in (WORK/'commands.jsonl').read_text().splitlines()]
matches=[entry for entry in commands if Path(entry['log']).name=='thermal-feedback-negative-exact-real-guards.log']
assert len(matches)==1
command=matches[0]
assert command['exit_code']==0 and sha(Path(command['log']))==command['log_sha256']
artifacts={'tests/core-initial.xml':sha(ROOT/'core-initial.xml'),
    'tests/core-guard.xml':sha(guard_xml),'tests/completion.json':INITIAL_COMPLETION_SHA,
    'tests/test_thermal_feedback_reference.initial.py':sha(INITIAL_TEST),
    'core/thermal_feedback_reference.initial.py':sha(INITIAL_CORE),
    'tests/core-input-guard.diff':sha(diff_path),'tests/write_guard_completion.py':sha(Path(__file__)),
    'thermal-feedback-negative-exact-real-guards.log':command['log_sha256']}
result={'schema':'mitl-thermal-feedback-changed-input-guards-v1','status':'passed','all_checks_passed':True,
    'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'public_source_sha256':{CORE:FINAL_CORE_SHA,TEST:sha(REPO/TEST)},'artifact_sha256':artifacts,
    'historical_completion_sha256':INITIAL_COMPLETION_SHA,
    'historical_source_binding':{CORE:{'preserved_path':'core/thermal_feedback_reference.initial.py','sha256':sha(INITIAL_CORE)},
        TEST:{'preserved_path':'tests/test_thermal_feedback_reference.initial.py','sha256':sha(INITIAL_TEST)}},
    'historical_tests_passed':34,'new_guard_tests_passed':5,'affected_normal_rechecks_passed':1,
    'changed_scope_tests_passed':6,'unique_tests_passed':39,'test_case_executions':40,
    'targeted_test_runs':2,'changed_scope_failures':0,'changed_scope_errors':0,'changed_scope_skips':0,
    'unaffected_core_AST_unchanged':True,'existing_test_function_AST_unchanged':True,
    'core_change_scope':'_real original-value negativity rejection before float conversion only',
    'repeated_test':next(iter(repeated))[1],'command':command,
    'warnings_as_errors':True,'old_suites_repeated':False,'portable_test_execution_claimed':False,
    'limits':['The initial34-pass record remains a historical claim against its original source and test bytes, retained verbatim.',
        'A static review found negative exact Real values could round to accepted negative zero. Five new input guards check original-value rejection; one affected empty-state normal control was intentionally rerun.',
        'No full34-case repeat or blanket final-byte suite execution is claimed. The source AST outside _real and every pre-existing test-function AST are unchanged.',
        'All parameters and trajectories remain manufactured; no physical material, molecular state data, host/MHD coupling or actual FLASH execution is introduced.']}
target=ROOT/'guard-completion.json';target.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps({'completion':str(target),'sha256':sha(target),'public_source_sha256':result['public_source_sha256'],
    'unique_tests_passed':39,'changed_scope_tests_passed':6},indent=2))
