"""Freeze metadata-only primary-source qualification without another request."""
from __future__ import annotations
import datetime as dt
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
WORK = ROOT.parent
DOI = "10.1016/0039-6028(86)90500-5"

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    if (ROOT / "completion.json").exists():
        raise RuntimeError("Refuse repeated completion freeze")
    status = json.loads(Path("/workspace/research_work/mitl-upstream-status.json").read_text())
    assert status["active_lease_owner"] == "mitl-upstream-20261019T0515"
    assert dt.datetime.fromisoformat(status["active_editing_lease_until_utc"]) > dt.datetime.now(dt.timezone.utc)
    acquisition = json.loads((ROOT / "metadata_acquisition.json").read_text())
    crossref = json.loads((ROOT / "hendewerk_1986_crossref.json").read_text())["message"]
    openalex = json.loads((ROOT / "hendewerk_1986_openalex.json").read_text())
    assert crossref["DOI"].lower() == DOI.lower()
    assert openalex["doi"].lower() == ("https://doi.org/" + DOI).lower()
    assert crossref["title"][0] == openalex["title"]
    assert all(x["http_status"] == 200 and x["json_parse_passed"] and not x["body_truncated"]
               and x["retry_count"] == 0 for x in acquisition["requests"])
    assert acquisition["logical_request_count"] == 2 and acquisition["retries"] == 0
    assert openalex["open_access"] == {"is_oa": False, "oa_status": "closed", "oa_url": None,
                                        "any_repository_has_fulltext": False}
    assert openalex["best_oa_location"] is None
    assert not any(x.get("pdf_url") or x.get("is_oa") for x in openalex["locations"])
    for request in acquisition["requests"]:
        assert sha(ROOT / request["body_path"]) == request["body_sha256"]
    lead = Path("/workspace/research_work/mitl-upstream-20261019T0505/next-upstream-selection/cached_primary_lead.json")
    assert sha(lead) == "8cb6cd7da902111bfb211e59ab58853f02f39d325a363d6307a3721fb025c486"
    readiness = {
        "schema": "mitl-source-request-runtime-readiness-v1",
        "observations_current": True, "observed_phase": "running", "connectivity": "connected",
        "spec_revision": "52", "observed_spec_revision": "52",
        "http_network_policy": {"mode": "unrestricted", "state": "enforced"},
        "configured_secrets": [], "configured_runtime_variables": [], "configured_outbound_identities": [],
        "local_policy_version": 1, "vpn_configured": False, "tcp_grants": [],
        "inherited_http_proxy_preserved": True, "configured_ca_trust_preserved": True,
        "tls_verification_enabled": True, "direct_routes_or_authentication_bypass_used": False,
        "readiness_observed_before_requests": True,
        "scope": "Bounded public metadata GET requests only; readiness is not publisher authorization."
    }
    (ROOT / "runtime_readiness.json").write_text(json.dumps(readiness, indent=2) + "\n")
    notes = """# Hendewerk–Salmeron–Somorjai primary-source identity

The previously cached reference is verified as M. Hendewerk, M. Salmeron and
G. A. Somorjai, “Water adsorption on the (001) plane of Fe2O3: An XPS, UPS,
Auger, and TPD study,” *Surface Science* 172(3), 544–556 (July 1986),
DOI: [10.1016/0039-6028(86)90500-5](https://doi.org/10.1016/0039-6028(86)90500-5).
The Crossref and OpenAlex titles agree, as do the DOI and cited authors.

The declared surface is the crystallographic (001) plane of Fe2O3. This is not
a study of the actual 304-alloy foil or a transferable qualification of its
surface oxide. Surface preparation, oxide phase, defects, dose convention,
molecular-water versus hydroxyl inventory, heating protocol and observed versus
inferred desorption energy cannot be assessed without the paper. The title
supports relevance as a separate oxide-water experiment only. No rate, barrier,
monolayer count, state allocation or wall-energy input has been adopted.

One Crossref metadata GET and one OpenAlex public-location GET returned HTTP 200
on 2026-10-19; the request records preserve exact URLs, UTC times, statuses,
headers, byte counts and SHA-256 hashes. There were no retries or redirects.
OpenAlex lists this work as closed, with no OA URL, best OA location, PDF URL or
repository full-text location. This catalog result does not prove no legitimate
copy exists elsewhere. The Crossref links are publisher text-mining endpoints;
their presence does not establish unrestricted full-text access. No full-text
request was made, and no previously blocked route was retried.

Further source assessment is gated on a newly verified legitimate full-text
location or supplied copy. The local thermal/desorption-feedback reference can
advance with explicitly manufactured inputs while that gate remains closed.
The next source task should use a genuinely new location or source lead rather
than repeat these unchanged catalog queries.

The inherited proxy and CA trust were retained with TLS verification. No
credentials, alternate routing, browser bypass, solver, runner or production
job was used. The retained bodies contain registry metadata only; no full text
or native source page is included in this packet.
"""
    (ROOT / "source_identity.md").write_text(notes)
    command_lines = [json.loads(line) for line in (WORK / "commands.jsonl").read_text().splitlines()]
    command = [x for x in command_lines if x["log"].endswith("/acquire-hendewerk-primary-metadata.log")]
    assert len(command) == 1 and command[0]["exit_code"] == 0
    assert sha(Path(command[0]["log"])) == command[0]["log_sha256"]
    report = {
        "schema": "mitl-primary-desorption-lead-completion-v1",
        "status": "metadata_verified_no_public_fulltext_location",
        "completed_utc": dt.datetime.now(dt.timezone.utc).isoformat(),
        "doi": DOI, "title": crossref["title"][0], "title_verified": True,
        "citation": {"authors": crossref["author"], "journal": crossref["container-title"][0],
                     "volume": crossref["volume"], "issue": crossref["issue"], "pages": crossref["page"],
                     "published_date_parts": crossref["published"]["date-parts"]},
        "cached_lead_path": str(lead), "cached_lead_sha256": sha(lead),
        "surface_qualification": {
            "title_surface": "Fe2O3 (001)", "title_surface_verified": True,
            "target_304_alloy_experiment": False, "actual_foil_surface_qualified": False,
            "surface_preparation_or_oxide_phase_verified": False,
            "physical_rate_or_inventory_or_energy_transfer_qualified": False
        },
        "access": {"openalex_id": openalex["id"], "open_access": openalex["open_access"],
                   "best_oa_location": openalex["best_oa_location"], "locations": openalex["locations"],
                   "crossref_links": crossref.get("link", []), "full_text_requests": 0,
                   "full_text_acquired": False,
                   "no_public_location_observed_does_not_prove_no_copy_exists": True},
        "request_counts": {"crossref_metadata": 1, "openalex_public_locations": 1,
                           "full_text": 0, "retries": 0, "redirects": 0,
                           "old_blocked_route_requests": 0},
        "request_command": command[0],
        "physical_parameters_adopted": 0,
        "monolayer_convention_adopted": False,
        "wall_removal_energy_adopted": False,
        "public_files_edited": False,
        "solver_or_owned_dataset_accessed": False,
        "numerical_models_or_tests_executed": False,
        "archive_excluded_paths": [],
        "full_text_omission": "No full text was acquired, so no full-text body or body hash exists to omit.",
        "next_source_task": "Assess this paper only when a newly verified legitimate full-text location or supplied copy is available; do not repeat unchanged catalog or blocked publisher routes.",
        "next_unblocked_local_task": "Continue the manufactured thermal/desorption-feedback reference under the current root lease.",
        "limits": ["Metadata title and access-catalog evidence only; full paper uninspected.",
                   "Fe2O3 crystallographic surface is not the target 304-alloy foil.",
                   "No physical chemistry, surface inventory or energy parameter is supplied or adopted."],
        "artifact_sha256": {str(p.relative_to(ROOT)): sha(p) for p in sorted(ROOT.rglob("*")) if p.is_file()}
    }
    (ROOT / "completion.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"completion": str(ROOT / "completion.json"), "sha256": sha(ROOT / "completion.json"),
                      "status": report["status"], "title": report["title"],
                      "request_counts": report["request_counts"], "physical_parameters_adopted": 0}, indent=2))

if __name__ == "__main__":
    main()
