"""Acquire one new primary-paper identity and public-location record, once."""
from __future__ import annotations
import concurrent.futures
import datetime as dt
import hashlib
import json
from pathlib import Path
import urllib.error
import urllib.parse
import urllib.request

ROOT = Path(__file__).resolve().parent
DOI = "10.1016/0039-6028(86)90500-5"
MAX_BYTES = 4 * 1024 * 1024

def now():
    return dt.datetime.now(dt.timezone.utc).isoformat()

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def fetch(label, url):
    path = ROOT / (label + ".json")
    if path.exists() or (ROOT / (label + "_request.json")).exists():
        raise RuntimeError("Refuse repeated acquisition: " + label)
    redirects = []
    class RedirectRecorder(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, request, response, code, message, headers, newurl):
            redirects.append({"from": request.full_url, "to": newurl, "http_status": code})
            return super().redirect_request(request, response, code, message, headers, newurl)
    headers = {"User-Agent": "MITL-publication-source-review/1.0", "Accept": "application/json"}
    record = {"label": label, "requested_url": url, "method": "GET", "request_headers": headers,
              "start_utc": now(), "logical_request_count": 1, "retry_count": 0,
              "inherited_proxy_and_ca_preserved": True, "tls_verification_enabled": True,
              "response_body_limit_bytes": MAX_BYTES, "redirects": redirects}
    body = b""
    try:
        response = urllib.request.build_opener(RedirectRecorder()).open(
            urllib.request.Request(url, headers=headers), timeout=45)
        with response:
            body = response.read(MAX_BYTES + 1)
            record.update(http_status=response.status, final_url=response.geturl(),
                          response_headers=dict(response.headers.items()))
    except urllib.error.HTTPError as exc:
        body = exc.read(MAX_BYTES + 1)
        record.update(http_status=exc.code, final_url=exc.geturl(),
                      response_headers=dict(exc.headers.items()), error_type=type(exc).__name__, error=str(exc))
    except Exception as exc:
        record.update(http_status=None, final_url=None, response_headers={},
                      error_type=type(exc).__name__, error=str(exc))
    record.update(end_utc=now(), body_bytes=len(body), body_sha256=digest(body), body_path=path.name,
                  body_truncated=len(body) > MAX_BYTES)
    path.write_bytes(body)
    if record.get("http_status") == 200 and not record["body_truncated"]:
        try:
            json.loads(body)
            record["json_parse_passed"] = True
        except Exception as exc:
            record["json_parse_passed"] = False
            record["json_parse_error"] = str(exc)
    (ROOT / (label + "_request.json")).write_text(json.dumps(record, indent=2) + "\n")
    return record

def main():
    status = json.loads(Path("/workspace/research_work/mitl-upstream-status.json").read_text())
    assert status["active_lease_owner"] == "mitl-upstream-20261019T0515"
    assert dt.datetime.fromisoformat(status["active_editing_lease_until_utc"]) > dt.datetime.now(dt.timezone.utc)
    assert "/workspace/research_work/mitl-upstream-20261019T0515" in status["reserved_paths"]
    jobs = [
        ("hendewerk_1986_crossref", "https://api.crossref.org/works/" + urllib.parse.quote(DOI, safe="")),
        ("hendewerk_1986_openalex", "https://api.openalex.org/works/https://doi.org/" + urllib.parse.quote(DOI, safe="/")),
    ]
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        records = list(pool.map(lambda pair: fetch(*pair), jobs))
    summary = {"schema": "mitl-primary-lead-metadata-acquisition-v1", "doi": DOI,
               "requests": records, "logical_request_count": 2, "retries": 0,
               "full_text_acquired": False, "physical_parameters_adopted": 0}
    (ROOT / "metadata_acquisition.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps(summary, indent=2))
    if not all(x.get("json_parse_passed") and x.get("http_status") == 200 for x in records):
        raise SystemExit(1)

if __name__ == "__main__":
    main()
