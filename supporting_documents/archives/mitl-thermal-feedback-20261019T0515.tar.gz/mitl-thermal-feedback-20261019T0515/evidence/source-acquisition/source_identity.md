# Hendewerk–Salmeron–Somorjai primary-source identity

The previously cached reference is verified as M. Hendewerk, M. Salmeron and
G. A. Somorjai, “Water adsorption on the (001) plane of Fe2O3: An XPS, UPS,
Auger, and TPD study,” *Surface Science* 172(3), 544–556 (July 1986),
DOI: [10.1016/0039-6028(86)90500-5](https://doi.org/10.1016/0039-6028(86)90500-5).
The Crossref and OpenAlex titles agree, as do the DOI and cited authors.

The declared surface is the crystallographic (001) plane of Fe2O3. This is not
a study of the actual 304-alloy foil or a transferable qualification of its
surface oxide. Surface preparation, oxide phase, defects, dose convention,
molecular-water versus hydroxyl inventory, heating protocol and observed versus
inferred desorption energy cannot be assessed without the paper. The title
supports relevance as a separate oxide-water experiment only. No rate, barrier,
monolayer count, state allocation or wall-energy input has been adopted.

One Crossref metadata GET and one OpenAlex public-location GET returned HTTP 200
on 2026-10-19; the request records preserve exact URLs, UTC times, statuses,
headers, byte counts and SHA-256 hashes. There were no retries or redirects.
OpenAlex lists this work as closed, with no OA URL, best OA location, PDF URL or
repository full-text location. This catalog result does not prove no legitimate
copy exists elsewhere. The Crossref links are publisher text-mining endpoints;
their presence does not establish unrestricted full-text access. No full-text
request was made, and no previously blocked route was retried.

Further source assessment is gated on a newly verified legitimate full-text
location or supplied copy. The local thermal/desorption-feedback reference can
advance with explicitly manufactured inputs while that gate remains closed.
The next source task should use a genuinely new location or source lead rather
than repeat these unchanged catalog queries.

The inherited proxy and CA trust were retained with TLS verification. No
credentials, alternate routing, browser bypass, solver, runner or production
job was used. The retained bodies contain registry metadata only; no full text
or native source page is included in this packet.
