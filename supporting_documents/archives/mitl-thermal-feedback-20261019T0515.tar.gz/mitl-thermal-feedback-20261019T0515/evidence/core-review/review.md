# Manufactured thermal-feedback core review

The new standalone core was read in full at its initial frozen source hash.
The final source differs only by an original-value negativity guard in `_real`.
The guard was checked by exact text reconstruction; no model, test or producer
was executed during this review.

One substantive issue was found: `_real` originally checked negativity only
after converting an arbitrary `numbers.Real` to float. An exact negative value
such as `Fraction(-1, 10**1000)` rounds to negative zero, bypassing `result < 0`
and the positive-underflow check. That would silently accept a mathematically
negative coverage or energy input as zero. The author added `if value < 0`
before conversion. This resolves the identified hole by source inspection;
numerical/regression evidence belongs to the separate verification record.

The joint RK4 evolution, kinetic-versus-removal separation, channel signs,
per-area-to-extensive conversion and explicit representation/domain rejection
paths are consistent with the declared manufactured zero-power patch scope.
No second substantive source correctness issue was identified in this bounded
review. This is a static review, not a numerical accuracy, convergence, physical
chemistry, material, owner integration or host acceptance certificate.
