"""Record a bounded read-only source review; no scientific code is imported."""
import datetime as dt
import difflib
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = Path('/workspace/Power-Flow/mhdlab/thermal_feedback_reference.py')
INITIAL = ROOT.parent / 'core/thermal_feedback_reference.initial.py'
INITIAL_SHA = '2b200b66da0774db07bdbdcd4bc23180029bb26532e1c24ae0b3b21692ec2cd4'
FINAL_SHA = '3fbded5bc801fac4e847195ecd5ad369142d3ab56e70848c4501ea1425d61cf8'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

if (ROOT / 'completion.json').exists():
    raise RuntimeError('Refuse repeated review completion')
status = json.loads(Path('/workspace/research_work/mitl-upstream-status.json').read_text())
assert status['active_lease_owner'] == 'mitl-upstream-20261019T0515'
assert dt.datetime.fromisoformat(status['active_editing_lease_until_utc']) > dt.datetime.now(dt.timezone.utc)
assert sha(INITIAL) == INITIAL_SHA and sha(SOURCE) == FINAL_SHA
before = INITIAL.read_text()
after = SOURCE.read_text()
anchor = '    try:\n        result = float(value)\n    except (OverflowError, ValueError) as exc:\n'
guard = '    if value < 0:\n        raise ValueError(f"{name} must be nonnegative before floating-point conversion")\n'
assert before.count(anchor) == 1
assert before.replace(anchor, guard + anchor) == after
patch = ''.join(difflib.unified_diff(before.splitlines(keepends=True), after.splitlines(keepends=True),
                                    fromfile='reviewed-initial/thermal_feedback_reference.py',
                                    tofile='reviewed-final/thermal_feedback_reference.py'))
(ROOT / 'initial-to-final.patch').write_text(patch)
checks = [
    ('joint_RK4_state_evolution', 'Coverage and temperature advance separately through four stage increments. The analytic T(N) relation is absent from the core.'),
    ('kinetic_barrier', 'The coverage-dependent kinetic complement and eV-to-J exponent numerator use exact Fractions before the one float projection. The kinetic barrier is not an energy debit.'),
    ('wall_energy_channels', 'Stage wall removal sums the separately supplied D and internal energy plus the continuum flux-Maxwellian translation expectation 2*k_B*T.'),
    ('bound_gas_wall_signs', 'Bound adsorbate reference energy is -D*N; its release change is positive D*dN_released. Gas receives internal plus translation, and wall thermal change is negative.'),
    ('residual_reporting', 'Independent floating-point state/channel roundings remain visible in inventory, allocation and energy residuals rather than being repaired.'),
    ('area_once', 'Dynamics and cumulative channels are per area; patch area enters only once when projecting extensive sample fields.'),
    ('state_support', 'Initial and intermediate coverage/temperature domains are explicit; positive-inventory exhaustion and out-of-support stages reject.'),
    ('positive_increment_representation', 'Nonzero projections, positive-flow underflow, unchanged state debits, cumulative stagnation and nonadvancing sample times reject explicitly.'),
    ('manufactured_scope', 'Required manufactured status, supplied scalar heat capacity and explicit provenance prevent physical/material/host acceptance claims.'),
    ('owned_scope', 'No activation-barrier debit, source-evolution method, state-resolved chemistry, gap, host or owner transaction call appears.'),
    ('original_negative_real_guard', 'The final two-line pre-conversion sign guard closes the original exact-negative-Real underflow-to-negative-zero acceptance hole.')
]
notes = '''# Manufactured thermal-feedback core review

The new standalone core was read in full at its initial frozen source hash.
The final source differs only by an original-value negativity guard in `_real`.
The guard was checked by exact text reconstruction; no model, test or producer
was executed during this review.

One substantive issue was found: `_real` originally checked negativity only
after converting an arbitrary `numbers.Real` to float. An exact negative value
such as `Fraction(-1, 10**1000)` rounds to negative zero, bypassing `result < 0`
and the positive-underflow check. That would silently accept a mathematically
negative coverage or energy input as zero. The author added `if value < 0`
before conversion. This resolves the identified hole by source inspection;
numerical/regression evidence belongs to the separate verification record.

The joint RK4 evolution, kinetic-versus-removal separation, channel signs,
per-area-to-extensive conversion and explicit representation/domain rejection
paths are consistent with the declared manufactured zero-power patch scope.
No second substantive source correctness issue was identified in this bounded
review. This is a static review, not a numerical accuracy, convergence, physical
chemistry, material, owner integration or host acceptance certificate.
'''
(ROOT / 'review.md').write_text(notes)
report = {
    'schema': 'mitl-thermal-feedback-static-core-review-v1',
    'status': 'review_complete_identified_domain_hole_repaired',
    'completed_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
    'reviewed_source_path': str(SOURCE), 'reviewed_source_sha256': FINAL_SHA,
    'initial_reviewed_source_sha256': INITIAL_SHA,
    'initial_source_copy': str(INITIAL),
    'only_source_change_after_full_review': 'Two-line rejection of original value<0 before float conversion in _real.',
    'finding': {
        'id': 'negative-exact-real-underflow', 'status': 'repaired_source_inspected',
        'affected_entry': '_real',
        'argument': 'A mathematically negative Real can round to -0.0; checking result<0 afterward loses its sign-domain violation.',
        'hypothetical_input': 'Fraction(-1, 10**1000)',
        'hypothetical_input_executed_by_reviewer': False,
        'repair': 'Reject value<0 before converting to float.',
        'repair_diff_exactly_checked': True
    },
    'bookkeeping_guard_correction': {
        'failed_command_log': str(ROOT.parent / 'complete-thermal-feedback-static-review.log'),
        'failed_command_log_sha256': 'd0a4e43aa469e14212bb66e4f35ebb44e198999e41b22310dffec52fd82aa79c',
        'failed_command_exit_code': 1,
        'reason': 'The first exact-text anchor also matched _project; the completion guard rejected before producing review artifacts.',
        'correction': 'Narrowed the anchor to the distinctive _real exception clause; no scientific source or numerical execution changed.'
    },
    'checks': [{'area': area, 'static_review_complete': True, 'finding': finding} for area, finding in checks],
    'numerical_models_or_tests_executed': False,
    'producer_executed': False, 'scientific_module_imported': False,
    'old_modules_or_audits_repeated': False, 'public_source_edits_by_reviewer': False,
    'physical_parameters_validated': False, 'host_budget_accepted': False,
    'limits': ['Static source inspection only.', 'No numerical convergence or accuracy evidence supplied by this review.',
               'Manufactured stationary single patch with constant supplied areal heat capacity only.',
               'No physical water/foil qualification or owner integration acceptance.'],
    'artifact_sha256': {p.name: sha(p) for p in sorted(ROOT.iterdir()) if p.is_file()}
}
(ROOT / 'completion.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'completion': str(ROOT / 'completion.json'), 'completion_sha256': sha(ROOT / 'completion.json'),
                  'reviewed_source_sha256': FINAL_SHA, 'status': report['status'],
                  'numerical_models_or_tests_executed': False}, indent=2))
