"""Commit only the qualified manufactured local evolution and focused tests."""
import hashlib
import json
from pathlib import Path
import subprocess

repo = Path('/workspace/Power-Flow')
work = Path(__file__).resolve().parent
def run(*args):
    print(json.dumps(list(args)),flush=True)
    subprocess.run(args,cwd=repo,check=True)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip() == 'b27b04fb38238c831e12bf2f3cdfe945e5834d58'
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=repo,text=True)
record = json.loads((work/'documentation-association.json').read_text())
assert record['status'] == 'passed'
for path,digest in record['public_sha256'].items():
    assert hashlib.sha256((repo/path).read_bytes()).hexdigest() == digest
assert json.loads((work/'independent-verification/completion.json').read_text())['all_checks_passed'] is True
paths = ['mhdlab/thermal_feedback_reference.py','tests/test_thermal_feedback_reference.py']
run('git','add','--',*paths)
run('git','diff','--cached','--check')
run('git','-c','user.name=Research Development','-c','user.email=research@local.invalid','commit','-m','Add manufactured joint surface cooling and inventory reference')
run('git','show','--format=fuller','--stat','HEAD')
