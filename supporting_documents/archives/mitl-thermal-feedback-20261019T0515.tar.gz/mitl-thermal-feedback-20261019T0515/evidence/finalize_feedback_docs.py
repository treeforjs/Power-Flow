"""Bind the reference guide to saved execution and independent verification."""
from decimal import Decimal, localcontext
import datetime
import hashlib
import json
from pathlib import Path

repo = Path('/workspace/Power-Flow')
work = Path(__file__).resolve().parent
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
pins = {
    'core/source-freeze-final.json':'1d5b5629117f19be2ba1b3fb9b917946008005a698fa0b0b4f4ae4223406f167',
    'core-review/completion.json':'ca4d7ac0d1caf8787721e8f2538adc3fb8f3bb7fbb4fdc51f73c7e260bdf026b',
    'tests/completion.json':'be663f5bf6135070ce3ccf144a29a61f12db0fe7dfa135d15d361597cb57ee77',
    'tests/guard-completion.json':'da36c9a11ba8a1338c98b13cbd0c25c11e595d1e366966efdd0c2541bcef38a5',
    'producer/completion.json':'203cf5d79313dd3af9f360a61b6032f4e79faf5164a750baf6ad48051c27c537',
    'producer/reference-run/report.json':'ef42a676818bd41905c26da80283fbf2348962a7c67fa48084838f7ba02431e6',
    'independent-verification/completion.json':'e1e61da7436633dcf2efd3f140c55fec3def4b691377ed3166f6c436e3652069',
    'independent-verification/oracle-initial/report.json':'5502b5a2c9496d2701d28cfaa4986b5d1e88e472d55d3a8e21e6fbe21541551b',
    'source-acquisition/completion.json':'017bcfa5ba9b46bbb1f0cca7776bf5b28520efdc552bdb5a5f8d6398c08d842e',
    'next-upstream-selection/selection.json':'343555c0c0e3992d811ab3a39b7967498aa01cc22514b4fff152ea6023ad9dfd',
}
for name,digest in pins.items():
    assert sha(work/name) == digest, name
oracle = json.loads((work/'independent-verification/oracle-initial/report.json').read_text())
assert oracle['all_checks_passed'] is True
assert oracle['saved_sample_rows_checked'] == 289
assert oracle['CSV_JSON_scalar_cells_checked'] == 3757
assert oracle['positive_core_or_CLI_calls'] == 0
assert oracle['source_model_imports'] == []
run = json.loads((work/'producer/reference-run/report.json').read_text())
assert run['case_count'] == 6 and run['numerical_trajectory_count'] == 9
assert run['parameter_status'] == 'manufactured' and run['external_power_w_m2'] == 0
public = ['mhdlab/thermal_feedback_reference.py','tests/test_thermal_feedback_reference.py',
    'tools/run_thermal_feedback_reference.py','configs/thermal_feedback_manufactured.json',
    'docs/thermal_feedback_reference.md']
public_sha = {name:sha(repo/name) for name in public}
assert public_sha[public[0]] == '3fbded5bc801fac4e847195ecd5ad369142d3ab56e70848c4501ea1425d61cf8'
assert public_sha[public[1]] == '0150de7c30eb07cd9d8cf2464513a7b132809cce8ce7b551b45d7ac78ecc3c9c'
assert public_sha[public[2]] == '129f5c6b0c3bb383f7a66ba33e429133056f20d478b86acbe13d8643549fab9d'
assert run['config_sha256'] == public_sha[public[3]]
with localcontext() as context:
    context.prec = 80
    cooled = Decimal(oracle['cases']['nonlinear_costs']['reference']['released_m2']['decimal'])
    maintained = Decimal(oracle['maintained_temperature_controls']['nonlinear_costs']['reference']['released_m2']['decimal'])
    fraction = (maintained-cooled)/maintained
    percentage = fraction*100
guide = (repo/public[-1]).read_text()
assert f'about {percentage:.1f}%' in guide
assert '34 cases passed before' in guide and 'five new negative-exact-value' in guide
assert '8, 16, 32 and 64 steps' in guide
assert 'general accuracy certificate' in guide and 'no measured water-release effect' in guide
assert 'Gamma = nu*N*exp' in guide
assert 'C_A*dT/dt = -Gamma*(D + I + 2*k_B*T)' in guide
assert 'Uads = -D*N' in guide
visual_paths = ['trajectories.png','energy_channels.png']
visual = {'schema':'mitl-thermal-feedback-root-visual-review-v1',
    'reviewed':{name:sha(work/'producer/reference-run'/name) for name in visual_paths},
    'observations':['Both figures explicitly label their manufactured zero-power inputs.',
        'All six case trajectories are legible; weak-release temperature uses the displayed axis offset.',
        'The energy figure keeps removal, gas internal, expected translation, wall debit and thermal decrease distinct.'],
    'limitations':['Visual legibility only; independent oracle supplies arithmetic/timing/energy verification.',
        'Plots do not supply measured water behavior, actual material inputs or host acceptance.'],
    'producer_or_oracle_reexecuted':False}
(work/'visual-review.json').write_text(json.dumps(visual,indent=2)+'\n')
report = {'schema':'mitl-thermal-feedback-documentation-association-v1','status':'passed',
    'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'script_sha256':sha(__file__),
    'public_sha256':public_sha,'evidence_sha256':pins,'visual_review_sha256':sha(work/'visual-review.json'),
    'manufactured_example':{'case_id':'nonlinear_costs','source':'independent time-inversion reference',
        'cooling_released_m2':str(cooled),'maintained_temperature_released_m2':str(maintained),
        'reduction_fraction_relative_to_maintained':str(fraction),'reduction_percent':str(percentage),
        'physical_water_release_claim':False},
    'test_version_qualification':'Initial34 on initial core2b200b66;5 new negative-value guards and1 affected existing control on corrected core3fbded5b. Initial/final parser checks retain separate code versions. Final saved batch/oracle bind corrected code; no claim of blanket39 execution on final bytes.',
    'old_suites_or_source_producers_reexecuted':False,'numerical_core_or_CLI_or_oracle_called_here':False,
    'physical_surface_calibration_or_host_acceptance_established':False}
(work/'documentation-association.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':'passed','public_sha256':public_sha,'documentation_association_sha256':sha(work/'documentation-association.json'),
    'visual_review_sha256':sha(work/'visual-review.json'),'manufactured_release_reduction_percent':str(percentage)},indent=2))
