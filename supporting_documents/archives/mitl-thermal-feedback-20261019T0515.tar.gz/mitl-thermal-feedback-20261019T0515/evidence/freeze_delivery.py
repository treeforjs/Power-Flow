"""Freeze new manufactured feedback evidence without replaying the reference."""
import datetime
import csv
import hashlib
import io
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tarfile
from xml.etree import ElementTree

from prepare_delivery import WORK, REPO, BASE, OUT, PUBLIC, WRAPPERS, clean_head, dependency_context, input_contract, load, save, sha

TEXT_SUFFIXES = {'.py', '.json', '.jsonl', '.log', '.xml', '.md', '.txt', '.patch', '.sha256', '.yaml', '.csv'}
EVIDENCE_DIRS = ('core', 'core-review', 'producer', 'tests', 'independent-verification', 'next-upstream-selection', 'source-acquisition', 'completion-preparation')
REPORT_PATHS = {
    'producer_run': 'producer/reference-run/report.json',
    'producer_completion': 'producer/completion.json',
    'parser_guards': 'producer/config_guard_checks.json',
    'numeric_lexeme_guards': 'producer/numeric_lexeme_checks.json',
    'cli_source_versions': 'producer/source_versions.json',
    'producer_before_run': 'producer/before_run_freeze.json',
    'tests_completion': 'tests/completion.json',
    'tests_guard_completion': 'tests/guard-completion.json',
    'initial_core_freeze': 'core/source-freeze.json',
    'final_core_freeze': 'core/source-freeze-final.json',
    'static_core_review': 'core-review/completion.json',
    'oracle_completion': 'independent-verification/completion.json',
    'oracle_report': 'independent-verification/oracle-initial/report.json',
    'oracle_summary': 'independent-verification/summary.json',
    'documentation_association': 'documentation-association.json',
    'documentation_guard_correction': 'documentation-guard-correction.json',
    'visual_review': 'visual-review.json',
    'source_acquisition': 'source-acquisition/completion.json',
    'selection': 'next-upstream-selection/selection.json',
}
EXPECTED_CONTROLS = {}
PROJECTIONS = (
    (bytes.fromhex('2f6f70742f636f6465782f72756e74696d65732f636f6465782d7072696d6172792d72756e74696d652f646570656e64656e636965732f707974686f6e'), b'[runtime Python directory]'),
    (bytes.fromhex('2f6574632f636f6465782f'), b'[runtime policy directory]/'),
)


def excluded(relative, allowed_figures=()):
    path = Path(relative)
    if any(part in {'__pycache__', '.pytest_cache', '.venv', 'source-local', 'fulltexts', 'raw-fulltexts',
                    'pytest-temp', 'pytest-tmp', 'test-fixtures', 'fixtures'}
           or part.startswith('.thermal-feedback-reference-') for part in path.parts):
        return True
    if path.suffix == '.pyc':
        return True
    if 'source-acquisition' in path.parts:
        return 'raw' in path.parts or path.suffix not in {'.json', '.jsonl', '.py', '.md', '.log', '.sha256'}
    if path.suffix.lower() in {'.png', '.pdf', '.jpg', '.jpeg', '.tif', '.tiff'}:
        return str(path) not in set(allowed_figures)
    return False


def verify_contracts(records, configured_inputs, *, work_sha=None, public_sha=None, work_bytes=None):
    """Validate saved declarations and byte associations; never import the model."""
    h = work_sha or (lambda name: sha(WORK/name))
    p = public_sha or (lambda name: sha(REPO/name))
    b = work_bytes or (lambda name: (WORK/name).read_bytes())

    def artifacts(mapping, prefix=''):
        for name, digest in mapping.items():
            path = Path(name)
            assert not path.is_absolute() and '..' not in path.parts
            assert h(prefix+name) == digest

    def rows(name):
        return list(csv.DictReader(io.StringIO(b(name).decode())))

    core_path = 'mhdlab/thermal_feedback_reference.py'
    test_path = 'tests/test_thermal_feedback_reference.py'
    cli_path = 'tools/run_thermal_feedback_reference.py'
    initial = records['tests_completion']
    assert initial['schema'] == 'mitl-thermal-feedback-core-tests-v1'
    assert initial['status'] == 'passed' and initial['all_checks_passed'] is True
    for key, value in {'targeted_test_runs': 1, 'new_core_tests_passed': 34,
                       'new_core_tests_failed': 0, 'new_core_tests_errors': 0, 'new_core_tests_skipped': 0}.items():
        assert type(initial[key]) is int and initial[key] == value
    assert initial['warnings_as_errors'] is True and initial['old_suites_repeated'] is False
    assert initial['portable_test_execution_claimed'] is False
    artifacts(initial['artifact_sha256'])
    guarded = records['tests_guard_completion']
    assert guarded['schema'] == 'mitl-thermal-feedback-changed-input-guards-v1'
    assert guarded['status'] == 'passed' and guarded['all_checks_passed'] is True
    for key, value in {'historical_tests_passed': 34, 'new_guard_tests_passed': 5,
            'affected_normal_rechecks_passed': 1, 'changed_scope_tests_passed': 6, 'unique_tests_passed': 39,
            'test_case_executions': 40, 'targeted_test_runs': 2, 'changed_scope_failures': 0,
            'changed_scope_errors': 0, 'changed_scope_skips': 0}.items():
        assert type(guarded[key]) is int and guarded[key] == value
    assert guarded['unaffected_core_AST_unchanged'] is True and guarded['existing_test_function_AST_unchanged'] is True
    assert guarded['warnings_as_errors'] is True and guarded['old_suites_repeated'] is False
    assert guarded['portable_test_execution_claimed'] is False
    assert guarded['historical_completion_sha256'] == h(REPORT_PATHS['tests_completion'])
    for name, binding in guarded['historical_source_binding'].items():
        assert initial['public_source_sha256'][name] == binding['sha256'] == h(binding['preserved_path'])
    assert set(guarded['public_source_sha256']) == {core_path, test_path}
    assert all(p(name) == digest for name, digest in guarded['public_source_sha256'].items())
    artifacts(guarded['artifact_sha256'])
    for name, count in (('tests/core-initial.xml', 34), ('tests/core-guard.xml', 6)):
        suites = list(ElementTree.fromstring(b(name)).iter('testsuite'))
        assert sum(int(suite.attrib.get('tests', 0)) for suite in suites) == count
        assert all(int(suite.attrib.get(key, 0)) == 0 for suite in suites for key in ('failures', 'errors', 'skipped'))

    initial_core = records['initial_core_freeze']
    final_core = records['final_core_freeze']
    assert initial_core['schema'] == 'mhdlab-thermal-feedback-core-freeze-v1'
    assert initial_core['source_sha256'] == initial['public_source_sha256'][core_path]
    assert final_core['schema'] == 'mhdlab-thermal-feedback-core-final-freeze-v1'
    assert final_core['source_sha256'] == p(core_path)
    assert final_core['initial_source_sha256'] == h(final_core['initial_source']) == initial_core['source_sha256']
    assert final_core['initial_freeze_record_sha256'] == h(final_core['initial_freeze_record'])
    assert final_core['review_finding']['equations_or_numerical_method_changed'] is False
    assert final_core['review_finding']['API_or_output_schema_changed'] is False
    assert final_core['focused_final_guard_verification']['initial_unaffected_scope_rerun'] is False
    assert final_core['new_core_numerical_runs_by_author'] == 0
    static = records['static_core_review']
    assert static['schema'] == 'mitl-thermal-feedback-static-core-review-v1'
    assert static['status'] == 'review_complete_identified_domain_hole_repaired'
    assert static['reviewed_source_sha256'] == p(core_path)
    assert static['initial_reviewed_source_sha256'] == initial_core['source_sha256']
    assert static['finding']['status'] == 'repaired_source_inspected'
    for key in ('numerical_models_or_tests_executed', 'producer_executed', 'scientific_module_imported',
                'old_modules_or_audits_repeated', 'physical_parameters_validated', 'host_budget_accepted'):
        assert static[key] is False
    artifacts(static['artifact_sha256'], 'core-review/')

    parser = records['parser_guards']
    numbers = records['numeric_lexeme_guards']
    versions = records['cli_source_versions']
    assert parser['schema'] == 'mhdlab-feedback-cli-parser-guards-v1'
    assert numbers['schema'] == 'mhdlab-feedback-cli-json-number-guards-v1'
    assert versions['schema'] == 'mhdlab-feedback-cli-source-version-evidence-v1'
    assert parser['check_count'] == len(parser['checks']) == 9 and parser['all_expectations_passed'] is True
    assert numbers['check_count'] == len(numbers['checks']) == 5 and numbers['all_expectations_passed'] is True
    for record in (parser, numbers):
        assert record['config_sha256'] == configured_inputs['config_sha256']
        assert record['core_imported_or_called'] is False and record['feedback_trajectories_evaluated'] == 0
    assert parser['script_sha256'] == versions['initial_cli_sha256']
    assert numbers['script_sha256'] == versions['final_cli_sha256'] == p(cli_path)
    assert versions['initial_parser_record_sha256'] == h(REPORT_PATHS['parser_guards'])
    assert versions['final_parser_record_sha256'] == h(REPORT_PATHS['numeric_lexeme_guards'])
    assert versions['parser_or_reference_checks_repeated'] is False
    artifacts(versions['source_files_sha256'], 'producer/')

    run = records['producer_run']
    produced = records['producer_completion']
    before = records['producer_before_run']
    assert run['schema'] == 'mhdlab-thermal-feedback-reference-run-v1' and run['status'] == 'manufactured_reference_only'
    assert run['config_sha256'] == configured_inputs['config_sha256']
    assert run['parameter_status'] == 'manufactured' and run['external_power_w_m2'] == 0
    assert run['case_count'] == 6 and run['numerical_trajectory_count'] == len(run['trajectories']) == 9
    assert all(p(name) == digest for name, digest in run['code_sha256'].items())
    expected_pairs = {(case['case_id'], step) for case in configured_inputs['cases'] for step in case['steps']}
    assert {(item['case_id'], item['steps']) for item in run['trajectories']} == expected_pairs
    artifacts(run['artifact_sha256'], 'producer/reference-run/')
    allowed_figures = ['producer/reference-run/'+name for name in run['artifact_sha256'] if Path(name).suffix in {'.png', '.pdf'}]
    sample_count = 0
    channels = {'coverage_m2', 'temperature_k', 'released_m2', 'binding_energy_j_m2', 'internal_energy_j_m2',
        'translational_energy_j_m2', 'total_wall_energy_debit_j_m2', 'gas_energy_j_m2', 'wall_thermal_change_j_m2',
        'adsorbate_reference_energy_j_m2', 'inventory_residual_m2', 'adsorbate_reference_residual_j_m2',
        'wall_debit_residual_j_m2', 'wall_channel_residual_j_m2', 'binding_allocation_residual_j_m2',
        'internal_allocation_residual_j_m2', 'total_energy_residual_j_m2'}
    for item in run['trajectories']:
        prefix = 'producer/reference-run/'
        assert h(prefix+item['csv_file']) == item['csv_sha256']
        assert h(prefix+item['history_file']) == item['history_sha256']
        history = load_json_bytes(b(prefix+item['history_file']))
        assert history['schema'] == 'mhdlab-thermal-feedback-reference-v1'
        assert history['zero_input_power'] is True
        for key in ('physical_parameters_validated', 'host_budget_accepted', 'owner_implementation_verified'):
            assert history[key] is False
        assert history['steps'] == item['steps'] and len(history['samples']) == item['sample_count'] == item['steps']+1
        data = rows(prefix+item['csv_file'])
        assert len(data) == item['sample_count']
        assert channels <= set(item['final_sample']) and channels <= set(data[-1]) and channels <= set(history['samples'][-1])
        assert all(key in item['max_absolute_residuals'] for key in channels if 'residual' in key)
        case = next(case for case in configured_inputs['cases'] if case['case_id'] == item['case_id'])
        assert item['input_parameters'] == case['problem'] and item['duration_s'] == case['duration_s']
        sample_count += len(data)
    assert sample_count == 289 and len(run['temporal_refinement']) == len(rows('producer/reference-run/temporal_refinement.csv')) == 30
    for key in ('zero_external_power', 'explicit_inputs_only', 'fixed_kinetic_reference', 'expected_flux_translation_2kBT'):
        assert run['qualifications'][key] is True
    for key in ('independent_reference_error_computed_here', 'old_source_or_recovery_producer_called',
                'physical_parameters_or_water_inferred', 'actual_FLASH_or_host_coupling', 'floor_clamp_or_unsupported_domain_fallback'):
        assert run['qualifications'][key] is False
    assert produced['schema'] == 'mhdlab-feedback-producer-completion-v1' and produced['status'] == 'passed_production_and_parser_checks'
    for key, value in {'actual_positive_CLI_batch_count': 1, 'distinct_trajectory_count': 9,
                       'case_count': 6, 'saved_CSV_sample_count': 289, 'temporal_refinement_row_count': 30}.items():
        assert type(produced[key]) is int and produced[key] == value
    assert produced['producer_report_sha256'] == h(REPORT_PATHS['producer_run'])
    assert produced['open_producer_findings'] == [] and produced['PNG_QA_visually_inspected'] is True
    assert all(p(name) == digest for name, digest in produced['public_source_sha256'].items())
    artifacts(produced['artifact_sha256'])
    assert before['schema'] == 'mhdlab-feedback-producer-before-run-freeze-v1'
    assert before['positive_CLI_batches_before_freeze'] == 0 and before['planned_distinct_trajectories'] == 9
    assert before['public_source_sha256'] == produced['public_source_sha256']

    oracle = records['oracle_completion']
    reference = records['oracle_report']
    summary = records['oracle_summary']
    assert oracle['schema'] == 'mitl-independent-thermal-feedback-completion-v1'
    assert oracle['status'] == 'passed' and oracle['all_checks_passed'] is True
    for key, value in {'cases': 6, 'saved_trajectories': 9, 'saved_sample_rows_checked': 289,
        'CSV_JSON_scalar_cells_checked': 3757, 'area_once_checks': 3468, 'selected_forward_time_checks': 32,
        'refinement_quantities_checked': 8, 'independent_final_time_inverse_cases': 6,
        'independent_oracle_numerical_runs': 1, 'positive_core_or_CLI_calls_by_oracle': 0, 'source_or_old_suite_calls': 0}.items():
        assert type(oracle[key]) is int and oracle[key] == value
    assert oracle['report_sha256'] == h(REPORT_PATHS['oracle_report'])
    assert oracle['summary_sha256'] == h(REPORT_PATHS['oracle_summary'])
    assert oracle['producer_report_sha256'] == h(REPORT_PATHS['producer_run'])
    assert oracle['producer_code_sha256'] == run['code_sha256']
    assert oracle['input_config_sha256'] == configured_inputs['config_sha256']
    for key in ('predeclared_budget_checks_passed', 'individual_energy_channel_checks_passed', 'zero_barrier_branch_exact', 'empty_control_exact'):
        assert oracle[key] is True
    for key in ('source_evolution_repeated', 'old_test_suites_repeated', 'interval_certification_or_physical_uncertainty_claimed',
                'water_or_material_or_state_data_adopted', 'host_or_gap_or_MHD_coupling_verified'):
        assert oracle[key] is False
    artifacts(oracle['artifact_sha256'])
    assert reference['schema'] == 'mitl-independent-thermal-feedback-oracle-v1'
    assert reference['status'] == 'passed' and reference['all_checks_passed'] is True
    assert reference['parameter_status'] == 'manufactured' and reference['distinct_saved_trajectories'] == 9
    assert reference['source_model_imports'] == []
    assert reference['positive_core_or_CLI_calls'] == reference['source_or_old_suite_calls'] == 0
    assert summary['schema'] == 'mitl-thermal-feedback-independent-summary-v1' and summary['status'] == 'passed'
    assert summary['oracle_report_sha256'] == h(REPORT_PATHS['oracle_report'])
    assert summary['precision_or_self_order_is_certified_bound'] is False

    acquired = records['source_acquisition']
    assert acquired['schema'] == 'mitl-primary-desorption-lead-completion-v1'
    assert acquired['status'] == 'metadata_verified_no_public_fulltext_location' and acquired['title_verified'] is True
    assert acquired['physical_parameters_adopted'] == 0 and acquired['monolayer_convention_adopted'] is False
    assert acquired['wall_removal_energy_adopted'] is False
    assert acquired['access']['full_text_acquired'] is False and acquired['request_counts']['full_text'] == 0
    assert acquired['request_counts']['retries'] == 0 and acquired['request_counts']['old_blocked_route_requests'] == 0
    assert acquired['surface_qualification']['actual_foil_surface_qualified'] is False
    artifacts(acquired['artifact_sha256'], 'source-acquisition/')
    documentation = records['documentation_association']
    assert documentation['schema'] == 'mitl-thermal-feedback-documentation-association-v1' and documentation['status'] == 'passed'
    doc_pins = documentation.get('public_source_sha256', documentation.get('public_sha256'))
    assert isinstance(doc_pins, dict) and set(doc_pins) == set(PUBLIC)
    assert all(p(name) == digest for name, digest in doc_pins.items())
    artifacts(documentation['evidence_sha256'])
    assert documentation['visual_review_sha256'] == h(REPORT_PATHS['visual_review'])
    for key in ('old_suites_or_source_producers_reexecuted', 'numerical_core_or_CLI_or_oracle_called_here',
                'physical_surface_calibration_or_host_acceptance_established'):
        assert documentation[key] is False
    correction = records['documentation_guard_correction']
    assert correction['event'] == 'documentation_guard_corrected' and correction['failed_exit'] == 1 and correction['corrected_exit'] == 0
    assert correction['failed_log_sha256'] == h(correction['failed_command_log'])
    assert correction['source_data_test_producer_or_oracle_changed_or_replayed'] is False
    visual = records['visual_review']
    assert visual['schema'] == 'mitl-thermal-feedback-root-visual-review-v1'
    assert visual['producer_or_oracle_reexecuted'] is False
    artifacts(visual['reviewed'], 'producer/reference-run/')
    selection = records['selection']
    assert selection['schema'] == 'mhdlab-next-upstream-scientific-task-selection-v1'
    assert selection['status'].startswith('selected')

    relationships = {
        'core_initial': {'source_sha256': initial['public_source_sha256'][core_path],
            'test_source_sha256': initial['public_source_sha256'][test_path], 'passed_cases': 34,
            'executed_against_final_source': False},
        'core_final': {'source_sha256': p(core_path), 'test_source_sha256': p(test_path),
            'new_guard_cases_passed': 5, 'affected_normal_rechecks_passed': 1, 'initial_34_scope_repeated': False},
        'cli_initial': {'source_sha256': parser['script_sha256'], 'parser_checks': 9,
            'snapshot_provenance': versions['initial_version_capture'], 'core_trajectory_calls': 0},
        'cli_final': {'source_sha256': p(cli_path), 'numeric_lexeme_checks': 5,
            'saved_positive_batches': 1, 'saved_trajectories': 9}}
    results = {'historical_initial_core_tests_passed': 34, 'final_core_new_guard_tests_passed': 5,
        'final_core_affected_normal_rechecks_passed': 1, 'unique_new_test_cases': 39,
        'test_case_executions': 40, 'initial_34_tests_repeated_on_final_source': False,
        'initial_cli_parser_checks': 9, 'final_cli_numeric_lexeme_checks': 5,
        'actual_positive_cli_batches': 1, 'manufactured_cases': 6, 'saved_trajectories': 9,
        'saved_sample_rows': 289, 'producer_refinement_rows': 30,
        'independent_oracle_runs': 1, 'oracle_csv_json_cells_checked': 3757,
        'oracle_area_once_checks': 3468, 'oracle_forward_time_checks': 32,
        'oracle_final_time_inverse_cases': 6, 'oracle_refinement_quantities_checked': 8,
        'per_channel_checks_passed': True, 'zero_power_manufactured_reference_only': True,
        'physical_truth_validated': False, 'host_or_owner_implementation_verified': False,
        'interval_certification_claimed': False, 'portable_executions_performed': False,
        'packaging_reference_test_or_oracle_repeated': False, 'old_test_suites_repeated': False,
        'standalone_source_subset': False, 'complete_baseline_checkout_required': True}
    return {'allowed_figure_paths': sorted(allowed_figures), 'results': results,
            'source_version_relationships': relationships}


def load_json_bytes(data):
    from prepare_delivery import loads
    return loads(data)


def main():
    payload = WORK/'delivery-preparation/payload'
    preparation = load(payload/'preparation.json')
    head = clean_head(preparation['source_commit'])
    assert preparation['base_commit'] == BASE
    assert not OUT.exists() and not OUT.with_suffix('.tar.gz').exists()
    assert load(payload/'source_file_list.json') == {'byte_identical_public_files': list(PUBLIC), 'packaging_wrappers': list(WRAPPERS)}
    assert len(PUBLIC) == 5 and len(WRAPPERS) == 2
    assert {str(path.relative_to(payload/'source')) for path in (payload/'source').rglob('*') if path.is_file()} == set(PUBLIC)|set(WRAPPERS)
    assert not (payload/'source/mhdlab/__init__.py').exists()
    for name in PUBLIC:
        assert (payload/'source'/name).read_bytes() == (REPO/name).read_bytes()
    context = dependency_context()
    assert context == preparation['dependency_context'] == load(payload/'dependency_context.json')
    configured_inputs = input_contract()
    assert configured_inputs == preparation['input_contract']
    records = {key: load(WORK/name) for key, name in REPORT_PATHS.items()}
    contract = verify_contracts(records, configured_inputs)
    allowed_figures = contract['allowed_figure_paths']
    next_task = records['selection']['selected_task']
    assert isinstance(next_task, str) and next_task.strip()
    shutil.copytree(payload, OUT)
    evidence = OUT/'evidence'
    evidence.mkdir()
    try:
        active_log = Path(os.readlink('/proc/self/fd/1')).resolve()
    except OSError:
        active_log = None
    copied_inputs, omitted, copied_root_files = [], [], []

    def copy(path, relative):
        assert not path.is_symlink()
        digest = sha(path)
        target = evidence/relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, target)
        assert sha(target) == digest
        copied_inputs.append({'source': str(path), 'archive': str(target.relative_to(OUT)), 'sha256': digest})

    for path in WORK.iterdir():
        if path.is_file() and path.suffix in TEXT_SUFFIXES and path.resolve() != active_log:
            copy(path, Path(path.name))
            copied_root_files.append(path.name)
    for folder in EVIDENCE_DIRS:
        for path in (WORK/folder).rglob('*'):
            assert not path.is_symlink()
            if not path.is_file():
                continue
            relative = path.relative_to(WORK)
            if excluded(relative, allowed_figures):
                omitted.append({'path': str(relative), 'sha256': sha(path), 'bytes': path.stat().st_size,
                    'reason': 'Cache, temporary fixture, failed staging data or unselected figure omitted from this new reference evidence.'})
            else:
                copy(path, relative)
    projections = []
    for path in evidence.rglob('*'):
        if not path.is_file() or path.suffix not in TEXT_SUFFIXES:
            continue
        for prefix, replacement in PROJECTIONS:
            data = path.read_bytes()
            if prefix in data:
                assert replacement not in data
                path.write_bytes(data.replace(prefix, replacement))
                projections.append({'path': str(path.relative_to(OUT)), 'original_sha256': hashlib.sha256(data).hexdigest(),
                    'portable_sha256': sha(path), 'replacements': data.count(prefix), 'source_prefix_hex': prefix.hex(),
                    'replacement': replacement.decode(), 'scope': 'Archive-only machine-directory projection; local raw bytes unchanged.'})
    save(OUT/'portable_path_projections.json', projections)
    save(OUT/'excluded_evidence.json', omitted)
    with (OUT/'thermal-feedback-reference.patch').open('wb') as stream:
        subprocess.run(['git', 'diff', '--binary', BASE, head], cwd=REPO, stdout=stream, check=True)
    verification = {'schema': 'mitl-thermal-feedback-reference-verification-v1',
        'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'source_commit': head, 'base_commit': BASE, 'input_contract': configured_inputs,
        'dependency_context': context, 'package_kind': 'patch_over_exact_complete_baseline',
        'results': contract['results'], 'records': records, 'record_paths': REPORT_PATHS,
        'source_version_relationships': contract['source_version_relationships'],
        'record_sha256': {key: sha(WORK/name) for key, name in REPORT_PATHS.items()},
        'allowed_figure_paths': allowed_figures, 'copied_input_sha256': copied_inputs,
        'public_files_byte_identical': len(PUBLIC), 'packaging_wrappers': len(WRAPPERS),
        'commits': subprocess.check_output(['git', 'log', '--reverse', '--format=%H %s', BASE+'..'+head], cwd=REPO, text=True).splitlines(),
        'command_snapshot': {'scope': 'Completed new-pass records before freezing; later archive/verification/completion records remain local.',
                             'copied_root_files': sorted(copied_root_files)},
        'next_task': next_task,
        'limits': ['Zero-external-power manufactured stationary one-patch thermal/inventory reference with a supplied constant areal heat capacity.',
            'Kinetic activation barrier, constant removal cost, fixed gas internal energy and continuum expected translational energy remain distinct.',
            'Saved finite temporal changes, quadrature and inversion diagnostics are numerical estimates under declared ranges, not certified bounds.',
            'No physical water parameters, actual foil material/phase closure, source-history feedback, FLASH, gap, CR or owner transaction is supplied.',
            'The five-file source subset requires the exact complete baseline checkout. No initializer workaround, standalone deployment or portable execution is claimed.',
            'Packaging repeats no new reference, test, oracle, prior passing suite or owner implementation.']}
    save(OUT/'verification.json', verification)
    save(OUT/'next_task.json', {'task': next_task, 'selection_evidence': 'evidence/'+REPORT_PATHS['selection']})
    (OUT/'systems-mitl-thermal-feedback-reference-10192026.md').write_text(f'''# Manufactured single-patch thermal feedback reference

The five new public files are byte-identical to `{head}`. The patch starts at
`{BASE}` and requires that complete checkout. Two wrappers provide a README and
the unchanged baseline requirements. The source subset is not a standalone
package. No initializer replacement or portable execution is supplied.

The reference evolves wall temperature and one finite parent inventory under
zero external power with explicitly manufactured inputs. Supplied areal heat
capacity, fixed kinetic reference coverage, coverage-dependent activation barrier,
constant removal cost, fixed internal energy and expected thermal translation
remain separately identified. Patch area converts areal budgets once.

New targeted tests, saved trajectories, an independent analytic temperature–
inventory/time-map oracle, temporal refinement and per-channel signed residuals
are retained with code, input, command, exit and hash associations. Estimates and
finite changes are not certified error bounds or physical validation. The archive
does not install feedback into any source history, material model or owner code.
No actual-water, foil, phase, power-feed or spectral result is inferred.

The initial 34 tests ran on the preserved initial core, not the corrected bytes.
Five new negative-value guards and one affected empty control checked the final
core after a two-line input-domain correction. The historical test source and
both core versions are retained. The initial nine CLI parser checks and five
final numeric-lexeme checks likewise retain separate source pins. The initial
CLI snapshot is an exact hash-checked reconstruction, not an original pre-edit
capture. The one saved batch and independent oracle bind the corrected final code.

Assembly does not rerun the new reference, tests, oracle, old suites or source
producers. Machine-directory projections, when needed, are reversible and leave
local raw records unchanged. Failed commands and focused corrections are retained.

Next selected task: {next_task}
''')
    manifest = {str(path.relative_to(OUT)): sha(path) for path in OUT.rglob('*') if path.is_file() and path.name != 'manifest.sha256.json'}
    save(OUT/'manifest.sha256.json', manifest)
    words = [bytes.fromhex(value).decode() for value in ('6f70656e6169', '63686174677074', '636c61756465', '636f646578')]
    prohibited = re.compile(r'\b(?:'+'|'.join(words)+r')\b', re.I)
    allowed_archive_figures = {'evidence/'+name for name in allowed_figures}
    for path in OUT.rglob('*'):
        assert not path.is_symlink()
        if path.is_file():
            assert not excluded(path.relative_to(OUT), allowed_archive_figures)
            if path.suffix in TEXT_SUFFIXES:
                assert not prohibited.search(path.read_text()), str(path)
    clean_head(head)
    assert all(sha(REPO/name) == preparation['public_source_sha256'][name] for name in PUBLIC)
    assert all(sha(Path(item['source'])) == item['sha256'] for item in copied_inputs)
    archive = OUT.with_suffix('.tar.gz')
    with tarfile.open(archive, 'w:gz') as tar:
        tar.add(OUT, arcname=OUT.name)
    record = {'folder': str(OUT), 'archive': str(archive), 'sha256': sha(archive), 'bytes': archive.stat().st_size,
        'source_commit': head, 'base_commit': BASE, 'manifest_entries': len(manifest),
        'public_files_byte_identical': len(PUBLIC), 'packaging_wrappers': len(WRAPPERS),
        'manifest_sha256': sha(OUT/'manifest.sha256.json'), 'verification_sha256': sha(OUT/'verification.json')}
    save(WORK/'frozen_delivery.json', record)
    print(json.dumps(record, indent=2))


if __name__ == '__main__':
    main()
