"""Commit the explicit manufactured batch, command interface and verified guide."""
import hashlib
import json
from pathlib import Path
import subprocess

repo = Path('/workspace/Power-Flow')
work = Path(__file__).resolve().parent
def run(*args):
    print(json.dumps(list(args)),flush=True)
    subprocess.run(args,cwd=repo,check=True)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip() == 'dd880d61ba008d3abfb31b999755debc41afb1e1'
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=repo,text=True)
r = json.loads((work/'documentation-association.json').read_text())
assert r['status'] == 'passed'
for path,digest in r['public_sha256'].items():
    assert hashlib.sha256((repo/path).read_bytes()).hexdigest() == digest
paths = ['tools/run_thermal_feedback_reference.py','configs/thermal_feedback_manufactured.json','docs/thermal_feedback_reference.md']
run('git','add','--',*paths)
run('git','diff','--cached','--check')
run('git','-c','user.name=Research Development','-c','user.email=research@local.invalid','commit','-m','Expose manufactured thermal feedback cases and verification evidence')
run('git','show','--format=fuller','--stat','HEAD')
run('git','status','--short','--branch')
