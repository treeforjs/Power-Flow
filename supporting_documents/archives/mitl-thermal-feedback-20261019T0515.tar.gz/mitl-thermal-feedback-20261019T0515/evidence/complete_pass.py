"""Complete the manufactured zero-power reference after root-approved delivery.

Draft only. No tests, numerical producers, source requests or owner code run here.
The root-approved contract must be final before this program can execute.
"""
import csv
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path,PurePosixPath
import re
import subprocess
import tarfile

WORK=Path(__file__).resolve().parent
REPO=Path('/workspace/Power-Flow')
OUT=Path('/workspace/handoffs/mitl-thermal-feedback-20261019T0515')
BASE='b27b04fb38238c831e12bf2f3cdfe945e5834d58'
BRANCH='research/flash-publication-foundation'
CORE='mhdlab/thermal_feedback_reference.py'
TEST='tests/test_thermal_feedback_reference.py'
CLI='tools/run_thermal_feedback_reference.py'
CONFIG='configs/thermal_feedback_manufactured.json'
DOC='docs/thermal_feedback_reference.md'
PUBLIC={CORE,TEST,CLI,CONFIG,DOC}
INITIAL_CORE_SHA='2b200b66da0774db07bdbdcd4bc23180029bb26532e1c24ae0b3b21692ec2cd4'
INITIAL_TEST_SHA='540e77bf9d435a59e464ab1d1bab589f01cd5c90b990ecd3f37679398be693ec'
FINAL_CORE_SHA='3fbded5bc801fac4e847195ecd5ad369142d3ab56e70848c4501ea1425d61cf8'


def require(condition,message):
    if not condition:
        raise RuntimeError(message)


def sha(path):
    digest=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):
            digest.update(block)
    return digest.hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def relative(name):
    require(type(name) is str and bool(name),'missing relative path')
    path=PurePosixPath(name)
    require(not path.is_absolute() and '..' not in path.parts and str(path)==name,'unsafe relative path: '+name)
    return path


def git(*arguments):
    return subprocess.check_output(['git',*arguments],cwd=REPO)


def clean_head(contract):
    head=contract['approved_head']
    require(type(head) is str and re.fullmatch('[0-9a-f]{40}',head),'root-approved final HEAD is pending')
    require(git('rev-parse','HEAD').decode().strip()==head,'final HEAD changed')
    require(git('branch','--show-current').decode().strip()==BRANCH,'unexpected branch')
    require(not git('status','--porcelain').strip(),'repository must be clean')
    subprocess.run(['git','merge-base','--is-ancestor',BASE,head],cwd=REPO,check=True)
    require(set(git('diff','--name-only',BASE,head).decode().splitlines())==PUBLIC,'committed scope differs from five new public files')
    for name,digest in contract['public_source_sha256'].items():
        require(sha(REPO/name)==digest==hashlib.sha256(git('show',head+':'+name)).hexdigest(),'public/commit pin changed: '+name)
    return head


def verify_maps(record,base=WORK,public=True):
    if public:
        for name,digest in record.get('public_source_sha256',{}).items():
            require(sha(REPO/relative(name))==digest,'public record pin changed: '+name)
    for name,digest in record.get('artifact_sha256',{}).items():
        path=Path(name) if Path(name).is_absolute() else base/relative(name)
        require(path.is_file() and not path.is_symlink() and sha(path)==digest,'artifact pin changed: '+name)


def verify_command(command,expected_exit=0):
    require(command['exit_code']==expected_exit and sha(command['log'])==command['log_sha256'],'recorded command or log changed')


def verify_archive(contract):
    frozen=load(WORK/'frozen_delivery.json')
    delivery=load(WORK/'delivery_verification.json')
    verification=load(OUT/'verification.json')
    require(delivery['status']=='passed' and delivery['input_code_output_bindings_verified'] is True
        and delivery['repository_clean'] is True and delivery['unsafe_or_duplicate_members']==0,'actual delivery has not passed')
    for name in ['folder','archive','sha256','bytes','source_commit','base_commit','manifest_sha256','verification_sha256']:
        require(delivery[name]==frozen[name],'delivery/freeze mismatch: '+name)
    require(delivery['folder']==str(OUT) and delivery['source_commit']==verification['source_commit']==contract['approved_head']
        and delivery['base_commit']==verification['base_commit']==BASE,'delivery identity changed')
    require(verification['schema']=='mitl-thermal-feedback-reference-verification-v1'
        and verification['package_kind']=='patch_over_exact_complete_baseline','unsupported package contract')
    require(verification['results']==contract['result_values'],'qualified result counts or claims changed')
    relationships=verification['source_version_relationships']
    require(relationships['core_initial']=={'source_sha256':INITIAL_CORE_SHA,'test_source_sha256':INITIAL_TEST_SHA,
        'passed_cases':34,'executed_against_final_source':False},'historical source/test relationship changed')
    require(relationships['core_final']=={'source_sha256':FINAL_CORE_SHA,'test_source_sha256':contract['public_source_sha256'][TEST],
        'new_guard_cases_passed':5,'affected_normal_rechecks_passed':1,'initial_34_scope_repeated':False},'final changed-scope relationship changed')
    require(delivery['complete_baseline_checkout_required'] is True and delivery['source_subset_standalone'] is False
        and delivery['empty_initializer_added'] is False,'complete baseline dependency requirement changed')
    require(delivery['reference_test_oracle_or_old_suites_reexecuted'] is False
        and delivery['portable_execution_performed'] is False,'unsupported packaging execution claim')
    archive=Path(delivery['archive'])
    require(archive==OUT.with_suffix('.tar.gz') and sha(archive)==delivery['sha256']
        and archive.stat().st_size==delivery['bytes'],'actual archive changed')
    allowed={'evidence/'+str(relative(name)) for name in verification['allowed_figure_paths']}
    hashes={};seen=set()
    with tarfile.open(archive,'r:gz') as stream:
        for member in stream:
            path=PurePosixPath(member.name)
            require(not path.is_absolute() and '..' not in path.parts and path.parts and path.parts[0]==OUT.name,'unsafe archive member')
            require(member.name not in seen and not member.issym() and not member.islnk(),'duplicate/linked archive member')
            seen.add(member.name)
            if member.isdir():
                continue
            require(member.isfile() and len(path.parts)>1,'nonregular archive payload')
            name=str(PurePosixPath(*path.parts[1:]));parts=relative(name).parts
            require(name not in hashes,'duplicate normalized archive path')
            require(not any(part in {'source-local','fulltexts','raw-fulltexts','__pycache__','.venv','.pytest_cache','fixtures','test-fixtures'} for part in parts),'excluded source/cache included')
            require(PurePosixPath(name).suffix.lower() not in {'.pdf','.png','.jpg','.jpeg','.tif','.tiff'} or name in allowed,'unlisted original source image/fulltext included')
            digest=hashlib.sha256()
            with stream.extractfile(member) as data:
                for block in iter(lambda:data.read(1024*1024),b''):
                    digest.update(block)
            hashes[name]=digest.hexdigest()
            require((OUT/name).is_file() and not (OUT/name).is_symlink() and sha(OUT/name)==hashes[name],'archive/folder byte mismatch: '+name)
    manifest=load(OUT/'manifest.sha256.json')
    require(set(hashes)==set(manifest)|{'manifest.sha256.json'} and all(hashes[name]==digest for name,digest in manifest.items()),'archive manifest mismatch')
    require(len(manifest)==delivery['manifest_entries'] and len(hashes)==delivery['actual_archive_regular_files'],'archive count mismatch')
    require(sha(OUT/'manifest.sha256.json')==delivery['manifest_sha256'] and sha(OUT/'verification.json')==delivery['verification_sha256'],'manifest/verification changed')
    listing=load(OUT/'source_file_list.json')
    require(set(listing['byte_identical_public_files'])==PUBLIC and listing['packaging_wrappers']==['README.md','requirements.txt'],'source/wrapper listing changed')
    require({name[7:] for name in hashes if name.startswith('source/')}==PUBLIC|{'README.md','requirements.txt'},'unexpected public payload')
    require('source/mhdlab/__init__.py' not in hashes,'standalone initializer workaround included')
    for name,digest in contract['public_source_sha256'].items():
        require(hashes['source/'+name]==digest,'archived public file changed: '+name)
    require(delivery['public_files_byte_identical']==verification['public_files_byte_identical']==5
        and delivery['packaging_wrappers']==verification['packaging_wrappers']==2,'public/wrapper count changed')
    context=verification['dependency_context']
    require(context['required_complete_baseline_checkout'] is True and context['baseline_commit']==BASE
        and context['standalone_source_subset'] is False and context['empty_initializer_added'] is False,'baseline dependency contract changed')
    for name,digest in context['unchanged_context_sha256'].items():
        require(sha(REPO/name)==digest==hashlib.sha256(git('show',BASE+':'+name)).hexdigest(),'unchanged baseline context changed')
    require(hashes['source/requirements.txt']==context['unchanged_context_sha256']['requirements.txt'],'baseline requirements wrapper changed')
    require(hashes['thermal-feedback-reference.patch']==hashlib.sha256(git('diff','--binary',BASE,contract['approved_head'])).hexdigest(),'patch does not match final commit')
    return delivery,verification


def verify_records(contract,verification):
    paths=contract['record_paths'];pins=contract['record_sha256']
    require(paths==verification['record_paths'] and set(paths)==set(pins),'saved record role contract changed')
    records={}
    for role,name in paths.items():
        path=WORK/relative(name)
        require(sha(path)==pins[role]==verification['record_sha256'][role],'saved record pin changed: '+role)
        record=load(path)
        require(record==verification['records'][role],'saved report declaration differs: '+role)
        records[role]=record
    initial=records['tests_completion'];guards=records['tests_guard_completion']
    require(initial['schema']=='mitl-thermal-feedback-core-tests-v1' and initial['all_checks_passed'] is True
        and initial['targeted_test_runs']==1 and initial['new_core_tests_passed']==34,'initial test evidence changed')
    require(initial['public_source_sha256'][CORE]==INITIAL_CORE_SHA and initial['public_source_sha256'][TEST]==INITIAL_TEST_SHA,'historical test source identity changed')
    require(sha(WORK/'core/thermal_feedback_reference.initial.py')==INITIAL_CORE_SHA
        and sha(WORK/'tests/test_thermal_feedback_reference.initial.py')==INITIAL_TEST_SHA,'preserved historical source changed')
    verify_maps(initial,public=False);verify_command(initial['command'])
    require(guards['schema']=='mitl-thermal-feedback-changed-input-guards-v1' and guards['all_checks_passed'] is True,'final input guards did not pass')
    for key,value in {'historical_tests_passed':34,'new_guard_tests_passed':5,'affected_normal_rechecks_passed':1,
        'changed_scope_tests_passed':6,'unique_tests_passed':39,'test_case_executions':40,'targeted_test_runs':2}.items():
        require(guards[key]==value,'qualified test counts changed: '+key)
    require(guards['historical_completion_sha256']==pins['tests_completion'] and guards['unaffected_core_AST_unchanged'] is True
        and guards['existing_test_function_AST_unchanged'] is True,'initial/final changed-scope relationship changed')
    verify_maps(guards);verify_command(guards['command'])
    require(records['initial_core_freeze']['source_sha256']==INITIAL_CORE_SHA
        and records['final_core_freeze']['source_sha256']==FINAL_CORE_SHA,'freeze source versions changed')
    review=records['static_core_review']
    require(review['schema']=='mitl-thermal-feedback-static-core-review-v1'
        and review['status']=='review_complete_identified_domain_hole_repaired'
        and review['reviewed_source_sha256']==FINAL_CORE_SHA and review['numerical_models_or_tests_executed'] is False
        and review['host_budget_accepted'] is False,'corrected static review incomplete')
    verify_maps(review,WORK/'core-review')
    review_correction=review['bookkeeping_guard_correction']
    require(review_correction['failed_command_exit_code']==1
        and sha(review_correction['failed_command_log'])==review_correction['failed_command_log_sha256'],
        'preserved static-review bookkeeping failure changed')
    producer=records['producer_run'];completion=records['producer_completion']
    require(producer['schema']=='mhdlab-thermal-feedback-reference-run-v1' and producer['status']=='manufactured_reference_only'
        and producer['parameter_status']=='manufactured' and producer['external_power_w_m2']==0
        and producer['case_count']==6 and producer['numerical_trajectory_count']==9,'manufactured producer scope changed')
    require(producer['code_sha256']=={CLI:contract['public_source_sha256'][CLI],CORE:FINAL_CORE_SHA}
        and producer['config_sha256']==contract['public_source_sha256'][CONFIG],'saved trajectory code/config changed')
    verify_maps(producer,WORK/'producer/reference-run')
    require(completion['schema']=='mhdlab-feedback-producer-completion-v1'
        and completion['status']=='passed_production_and_parser_checks'
        and completion['actual_positive_CLI_batch_count']==1 and completion['distinct_trajectory_count']==9
        and completion['case_count']==6 and completion['saved_CSV_sample_count']==289
        and completion['producer_report_sha256']==pins['producer_run'] and completion['open_producer_findings']==[],'single saved production batch incomplete')
    verify_maps(completion);verify_command(completion['positive_batch'])
    before_run=records['producer_before_run']
    require(before_run['planned_distinct_trajectories']==9 and before_run['positive_CLI_batches_before_freeze']==0
        and before_run['core_test_gate']['initial_targeted_passed']==34
        and before_run['core_test_gate']['changed_guard_targeted_passed']==6,'producer test/freeze gate changed')
    verify_maps(before_run)
    for key in ['numerical_reference_oracle_recomputed_here','maintained_temperature_control_evolved_here',
        'physical_parameters_or_water_validated','host_or_FLASH_coupling','unsupported_domain_fallback','old_suites_or_source_evolution_repeated']:
        require(completion[key] is False,'unsupported producer claim: '+key)
    total_rows=0
    for trajectory in producer['trajectories']:
        for filename,digest in [(trajectory['csv_file'],trajectory['csv_sha256']),(trajectory['history_file'],trajectory['history_sha256'])]:
            require(sha(WORK/'producer/reference-run'/relative(filename))==digest,'saved trajectory bytes changed')
        with (WORK/'producer/reference-run'/trajectory['csv_file']).open(newline='') as stream:
            rows=list(csv.DictReader(stream))
        history=load(WORK/'producer/reference-run'/trajectory['history_file'])
        require(len(rows)==len(history['samples'])==trajectory['sample_count']==trajectory['steps']+1,'saved trajectory row association changed')
        require(trajectory['input_parameters']['parameter_status']=='manufactured','trajectory parameter status promoted')
        total_rows+=len(rows)
    require(total_rows==289 and len(producer['temporal_refinement'])==completion['temporal_refinement_row_count']==30,'trajectory/refinement inventory changed')
    parser=records['parser_guards'];numbers=records['numeric_lexeme_guards'];versions=records['cli_source_versions']
    require(parser['all_expectations_passed'] is True and parser['check_count']==9
        and numbers['all_expectations_passed'] is True and numbers['check_count']==5,'parser guards incomplete')
    require(parser['feedback_trajectories_evaluated']==numbers['feedback_trajectories_evaluated']==0,'parser checks ran trajectories')
    require(versions['initial_parser_record_sha256']==pins['parser_guards'] and versions['final_parser_record_sha256']==pins['numeric_lexeme_guards']
        and versions['final_cli_sha256']==contract['public_source_sha256'][CLI]
        and versions['initial_cli_sha256']==parser['script_sha256'],'parser source-version relationship changed')
    for name,digest in versions['source_files_sha256'].items():
        require(sha(WORK/'producer'/relative(name))==digest,'preserved parser source evidence changed')
    oracle=records['oracle_completion']
    require(oracle['schema']=='mitl-independent-thermal-feedback-completion-v1' and oracle['all_checks_passed'] is True
        and oracle['status']=='passed','independent oracle has not passed')
    for key,value in {'cases':6,'saved_trajectories':9,'saved_sample_rows_checked':289,'CSV_JSON_scalar_cells_checked':3757,
        'area_once_checks':3468,'selected_forward_time_checks':32,'refinement_quantities_checked':8,
        'independent_oracle_numerical_runs':1,'positive_core_or_CLI_calls_by_oracle':0,'source_or_old_suite_calls':0}.items():
        require(oracle[key]==value,'independent oracle counter changed: '+key)
    require(oracle['refinement_family_steps']==[8,16,32,64] and oracle['core_imports_in_oracle']==[]
        and oracle['predeclared_budget_checks_passed'] is True and oracle['individual_energy_channel_checks_passed'] is True,'oracle timing/channel/refinement gates incomplete')
    require(oracle['report_sha256']==pins['oracle_report'] and oracle['summary_sha256']==pins['oracle_summary']
        and oracle['producer_report_sha256']==pins['producer_run'] and oracle['producer_code_sha256']==producer['code_sha256']
        and oracle['input_config_sha256']==producer['config_sha256'],'oracle input/code/report association changed')
    for key in ['source_evolution_repeated','old_test_suites_repeated','interval_certification_or_physical_uncertainty_claimed',
        'water_or_material_or_state_data_adopted','host_or_gap_or_MHD_coupling_verified']:
        require(oracle[key] is False,'unsupported oracle claim: '+key)
    verify_maps(oracle)
    for command in oracle['command_records']:
        verify_command(command)
    verify_command(oracle['missing_dependency_probe'],expected_exit=1)
    acquisition=records['source_acquisition']
    require(acquisition['status']=='metadata_verified_no_public_fulltext_location' and acquisition['title_verified'] is True
        and acquisition['doi']=='10.1016/0039-6028(86)90500-5' and acquisition['physical_parameters_adopted']==0
        and acquisition['access']['full_text_acquired'] is False and acquisition['request_counts']=={
            'crossref_metadata':1,'openalex_public_locations':1,'full_text':0,'retries':0,'redirects':0,'old_blocked_route_requests':0},'primary metadata/access limits changed')
    require(acquisition['surface_qualification']['actual_foil_surface_qualified'] is False
        and acquisition['surface_qualification']['physical_rate_or_inventory_or_energy_transfer_qualified'] is False,'unqualified source parameters promoted')
    verify_maps(acquisition,WORK/'source-acquisition');verify_command(acquisition['request_command'])
    docs=records['documentation_association'];selection=records['selection']
    require(docs['schema']=='mitl-thermal-feedback-documentation-association-v1'
        and docs['status']=='passed','root documentation association has not passed')
    for key in ['old_suites_or_source_producers_reexecuted','numerical_core_or_CLI_or_oracle_called_here',
        'physical_surface_calibration_or_host_acceptance_established']:
        require(docs[key] is False,'unsupported documentation claim: '+key)
    for name,digest in docs['public_sha256'].items():
        require(sha(REPO/name)==digest,'documentation binding changed')
    visual=records['visual_review']
    require(visual['producer_or_oracle_reexecuted'] is False,'visual review replayed numerical work')
    for name,digest in visual['reviewed'].items():
        require(sha(WORK/'producer/reference-run'/relative(name))==digest,'visually reviewed plot changed')
    correction=records['documentation_guard_correction']
    require(correction['failed_exit']==1 and correction['corrected_exit']==0
        and correction['source_data_test_producer_or_oracle_changed_or_replayed'] is False,'documentation-only correction qualification changed')
    require(sha(WORK/relative(correction['failed_command_log']))==correction['failed_log_sha256'],'preserved failed documentation log changed')
    corrected_commands=[json.loads(line) for line in (WORK/'commands.jsonl').read_text().splitlines()
        if json.loads(line).get('log_sha256')==correction['corrected_log_sha256']]
    require(len(corrected_commands)==1,'corrected documentation command association changed')
    verify_command(corrected_commands[0])
    require(type(selection.get('selected_task')) is str and selection['selected_task'].strip()
        and (selection.get('selected') is True or str(selection.get('status','')).startswith('selected')),'next task is only conditional or unfrozen')
    require('manufactured' in selection['selected_task'].lower(),'next task lacks its manufactured qualification')
    gate=selection['current_pass_gate']
    require(gate['status']=='passed_before_selection' and gate['all_checks_passed'] is True
        and gate['oracle_report_sha256']==pins['oracle_report'] and gate['existing_core_sha256']==FINAL_CORE_SHA
        and gate['oracle_source_model_imports']==[] and gate['oracle_positive_core_or_CLI_calls']==0
        and gate['oracle_old_suite_or_source_calls']==0,'next selection was not gated by the qualified current oracle')
    for key in ['public_files_edited','network_used','numerical_producer_or_model_executed','old_suites_or_source_evolution_repeated']:
        require(selection[key] is False,'next proposal exceeded planning scope: '+key)
    require(selection['physical_parameters_adopted']==0,'next proposal adopted physical defaults')
    require(sha(WORK/'next-upstream-selection'/relative(selection['proposal']))==selection['proposal_sha256']
        and sha(WORK/'next-upstream-selection'/relative(selection['prior_conditional_record']))==selection['prior_conditional_record_sha256'],
        'conditional-to-selected planning record changed')
    require(load(OUT/'next_task.json')['task']==verification['next_task']==selection['selected_task'],'next task archive association changed')
    return records


def atomic_write(path,data):
    temporary=path.with_name(path.name+'.new')
    require(not temporary.exists(),'unresolved temporary status file exists')
    with temporary.open('xb') as stream:
        stream.write(data);stream.flush();os.fsync(stream.fileno())
    os.replace(temporary,path)


def main():
    contract_path=WORK/'completion-preparation/contract.json'
    contract=load(contract_path)
    require(contract['schema']=='mitl-thermal-feedback-completion-contract-v1'
        and contract['ready_for_root_execution'] is True and contract['pending']==[],'completion contract is still a draft')
    require(set(contract['public_source_sha256'])==PUBLIC
        and all(type(value) is str and re.fullmatch('[0-9a-f]{64}',value) for value in contract['public_source_sha256'].values())
        and all(type(value) is str and re.fullmatch('[0-9a-f]{64}',value) for value in contract['record_sha256'].values()),'final byte pins are pending')
    status_path=WORK.parent/'mitl-upstream-status.json'
    with (WORK.parent/'mitl-upstream-status.lock').open('a+') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        before=status_path.read_bytes();status=json.loads(before);lease=load(WORK/'lease.json')
        now=datetime.datetime.now(datetime.timezone.utc)
        require(status['active_lease_owner']==lease['pass_id']==WORK.name
            and datetime.datetime.fromisoformat(status['active_editing_lease_until_utc'])>now,'lease changed or expired')
        require(status['last_complete_commit']==lease['baseline_commit']==BASE and status['handoff']==lease['prior_handoff']
            and not (WORK/'completion.json').exists(),'prior checkpoint changed or completion replay attempted')
        remaining=[json.loads(json.dumps(item)) for item in status['next_work'] if 2<=item['priority']<=7]
        require([item['priority'] for item in remaining]==[2,3,4,5,6,7],'preserved queue priorities changed')
        preserved=json.loads(json.dumps({key:value for key,value in status.items() if key not in {
            'last_complete_commit','last_completed_pass_id','last_update_utc','handoff','handoff_sha256','handoff_bytes','handoff_document',
            'active_lease_owner','active_editing_lease_until_utc','reserved_paths','active_completed_subtasks','active_phase',
            'last_verified_suite','next_work','verification_history','prior_handoffs','completed_milestones',
            'manufactured_thermal_feedback_reference','source_desorption_metadata_leads'}}))
        old_metadata_leads=json.loads(json.dumps(status.get('source_desorption_metadata_leads',[])))
        head=clean_head(contract)
        delivery,verification=verify_archive(contract)
        records=verify_records(contract,verification)
        clean_head(contract)
        now=datetime.datetime.now(datetime.timezone.utc)
        require(datetime.datetime.fromisoformat(status['active_editing_lease_until_utc'])>now,'lease expired during final verification')
        history=status.setdefault('verification_history',[]);prior=status.setdefault('prior_handoffs',[])
        if status['handoff'] not in prior:
            prior.append(status['handoff'])
        if not any(item['pass_id']==status['last_completed_pass_id'] for item in history):
            history.append({'pass_id':status['last_completed_pass_id'],'commit':status['last_complete_commit'],
                'handoff':status['handoff'],'handoff_sha256':status['handoff_sha256'],'verification':status['last_verified_suite']})
        oracle=records['oracle_completion'];selection=records['selection']
        status.update(last_complete_commit=head,last_completed_pass_id=WORK.name,last_update_utc=now.isoformat(),
            handoff=delivery['archive'],handoff_sha256=delivery['sha256'],handoff_bytes=delivery['bytes'],
            handoff_document=str(OUT/'systems-mitl-thermal-feedback-reference-10192026.md'),
            active_lease_owner=None,active_editing_lease_until_utc=None,reserved_paths=[],active_completed_subtasks=[],
            active_phase='Completed manufactured zero-power local thermal/desorption feedback reference; separate manufactured prescribed-power reference selected next')
        status['last_verified_suite']={**verification['results'],'scope':'Manufactured single-patch zero-power feedback: historical34 tests,5 new guards+1 affected repeat,one9-trajectory production batch and independent timing/channel oracle; no physical or owner acceptance',
            'verification_record':str(OUT/'verification.json'),'delivery_manifest_entries':delivery['manifest_entries'],
            'public_files_byte_identical':5,'packaging_wrappers':2,'post_freeze_commands':str(WORK/'commands.jsonl')}
        status['manufactured_thermal_feedback_reference']={'core':str(REPO/CORE),'core_sha256':FINAL_CORE_SHA,
            'guide':str(REPO/DOC),'config':str(REPO/CONFIG),'config_sha256':contract['public_source_sha256'][CONFIG],
            'parameter_status':'manufactured','external_power_w_m2':0,'case_count':6,'saved_trajectories':9,'saved_sample_rows':289,
            'historical_tests_passed':34,'new_final_guard_tests_passed':5,'affected_normal_rechecks':1,'unique_tests_passed':39,
            'total_test_case_executions':40,'initial_source_sha256':INITIAL_CORE_SHA,
            'record_paths':{key:str(WORK/name) for key,name in contract['record_paths'].items()},'record_sha256':contract['record_sha256'],
            'refinement_steps':oracle['refinement_family_steps'],'self_order_range':[oracle['self_order_min'],oracle['self_order_max']],
            'predeclared_budget_checks_passed':True,'individual_energy_channel_checks_passed':True,
            'primary_lead':{'doi':records['source_acquisition']['doi'],'title_verified':True,'full_text_acquired':False,
                'actual_foil_surface_qualified':False,'physical_parameters_adopted':0},
            'host_budget_accepted':False,'source_history_feedback_installed':False,'physical_water_or_material_parameters_validated':False,
            'actual_flash_run':False,'physical_spectra_calculated':False,
            'limits':'Supplied manufactured constant areal heat capacity, fixed reference coverage and independent removal/internal costs only. Finite quadrature/refinement estimates are not certified bounds, material/Cp/Cv/phase closure, actual surface evidence or production coupling.'}
        acquisition=records['source_acquisition']
        status['source_desorption_metadata_leads']=old_metadata_leads+[{
            'doi':acquisition['doi'],'title':acquisition['title'],'status':acquisition['status'],
            'record':str(WORK/contract['record_paths']['source_acquisition']),
            'record_sha256':contract['record_sha256']['source_acquisition'],'title_verified':True,
            'title_surface':acquisition['surface_qualification']['title_surface'],
            'full_text_acquired':False,'actual_foil_surface_qualified':False,
            'physical_parameters_adopted':0,'monolayer_convention_adopted':False,'wall_removal_energy_adopted':False,
            'repeat_unchanged_catalog_or_blocked_routes':False,'next':acquisition['next_source_task']}]
        status['next_work']=[{'priority':1,'task':selection['selected_task'],
            'selection':str(WORK/contract['record_paths']['selection']),'selection_sha256':contract['record_sha256']['selection'],
            'limits':'Separate manufactured prescribed-power branch only after this zero-power evidence; physical surface/owner/MHD/CR/gap gates remain.'}]+remaining
        require(status['next_work'][1:]==remaining and status['source_desorption_metadata_leads'][:-1]==old_metadata_leads
            and all(status[key]==value for key,value in preserved.items()),'prior gates, evidence or queue changed')
        status['completed_milestones'].extend([
            'Manufactured stationary one-patch zero-power model jointly evolves finite Temkin inventory and temperature; fixed kinetic reference, activation barrier, removal/internal costs, expected translation, area and signed residuals remain separate.',
            'Historical34 focused tests retain original source bytes. Five new exact-negative input guards plus one affected empty control qualify the validation-only correction;39 unique cases,40 executions are reported without a full unchanged-suite repeat.',
            'One saved six-case/nine-trajectory batch and an independent analytic temperature/integral-time oracle check289 rows,individual energy channels and8/16/32/64 temporal refinement. No physical material/water, host, source-history or actual FLASH acceptance is inferred.',
            f'Five reviewable new public files through {head[:7]} and the actual archive {delivery["sha256"]} are byte-verified against the exact complete baseline. Existing owner, surface, VUV and licensed-FLASH gates remain.'
        ])
        history.append({'pass_id':WORK.name,'commit':head,'handoff':delivery['archive'],
            'handoff_sha256':delivery['sha256'],'verification':status['last_verified_suite']})
        encoded=(json.dumps(status,indent=2,allow_nan=False)+'\n').encode()
        result={'utc':now.isoformat(),'event':'completed_and_next_selected','pass_id':WORK.name,'commit':head,
            'archive':delivery['archive'],'archive_sha256':delivery['sha256'],'archive_bytes':delivery['bytes'],
            'actual_archive_reverified':True,'public_scope_sha256':contract['public_source_sha256'],
            'completion_contract_sha256':sha(contract_path),'record_sha256':contract['record_sha256'],
            'historical_tests_passed':34,'new_final_guard_tests_passed':5,'affected_normal_rechecks':1,
            'unique_tests_passed':39,'test_case_executions':40,'positive_CLI_batches':1,'saved_trajectories':9,'saved_sample_rows':289,
            'independent_oracle_passed':True,'physical_parameters_adopted':0,'host_budget_accepted':False,
            'actual_flash_run':False,'portable_executions_performed':False,'old_test_suites_repeated':False,
            'exact_commands':str(WORK/'commands.jsonl'),'status_before_sha256':hashlib.sha256(before).hexdigest(),
            'status_after_sha256':hashlib.sha256(encoded).hexdigest(),'lease_released':True,'reserved_paths':[],
            'next':selection['selected_task'],'next_selection_sha256':contract['record_sha256']['selection']}
        require(not (WORK/'status-before-completion.json').exists(),'prior completion snapshot exists')
        (WORK/'status-before-completion.json').write_bytes(before)
        atomic_write(status_path,encoded)
        atomic_write(WORK/'completion.json',(json.dumps(result,indent=2,allow_nan=False)+'\n').encode())
        with (WORK.parent/'mitl-upstream-journal.jsonl').open('a') as stream:
            stream.write(json.dumps(result,allow_nan=False)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':
    main()
