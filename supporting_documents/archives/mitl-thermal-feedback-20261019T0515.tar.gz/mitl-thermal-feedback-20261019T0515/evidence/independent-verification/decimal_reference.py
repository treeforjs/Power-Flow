"""Independent zero-power single-patch reference using Decimal arithmetic.

No repository model is imported. Decimal Legendre roots and weights are generated
at the selected arithmetic precision. Finite precision/order changes are
diagnostics, not rigorous error bounds or physical uncertainties.
"""
from dataclasses import dataclass
from decimal import Decimal, getcontext, localcontext
from functools import lru_cache
import math

D = Decimal
KB = D('1.380649e-23')
QE = D('1.602176634e-19')


def represented(value):
    """Interpret a JSON number through the public float64 input projection."""
    return D.from_float(float(value))


def expm1(value):
    if abs(value) >= D('0.1'):
        return value.exp()-1
    term = total = value
    threshold = D(10)**(-getcontext().prec+8)
    for k in range(2, 10000):
        term *= value/D(k)
        new = total+term
        if new == total or abs(term) <= abs(new)*threshold:
            return new
        total = new
    raise RuntimeError('Decimal exponential series did not converge')


@lru_cache(maxsize=12)
def probability_rule(order, precision):
    """Build the Gauss-Legendre rule in Decimal; float cosine is only a seed."""
    if type(order) is not int or order < 2 or order % 2:
        raise ValueError('this bounded oracle requires an even order>=2')
    with localcontext() as context:
        context.prec = precision
        threshold = D(10)**(-precision+12)
        result = []
        for j in range(1, order//2+1):
            root = D.from_float(math.cos(math.pi*(j-0.25)/(order+0.5)))
            for _ in range(100):
                previous, current = D(1), root
                for n in range(2, order+1):
                    previous, current = current, ((2*n-1)*root*current-(n-1)*previous)/D(n)
                derivative = D(order)*(root*current-previous)/(root*root-1)
                update = current/derivative
                root -= update
                if abs(update) <= threshold:
                    break
            else:
                raise RuntimeError('Decimal Legendre root did not converge')
            # Reevaluate at the final root rather than reuse the prior derivative.
            previous, current = D(1), root
            for n in range(2, order+1):
                previous, current = current, ((2*n-1)*root*current-(n-1)*previous)/D(n)
            derivative = D(order)*(root*current-previous)/(root*root-1)
            weight = 1/((1-root*root)*derivative*derivative)
            result.extend((((1-root)/2, weight), ((1+root)/2, weight)))
        result.sort()
        if abs(sum(weight for _, weight in result)-1) > D(10)**(-precision+10):
            raise RuntimeError('Decimal quadrature weights do not sum to unity')
        return tuple(result)


def integrate(function, upper, order):
    if upper == 0:
        return D(0)
    if upper < 0:
        raise ValueError('positive integral upper endpoint required')
    return upper*sum(weight*function(upper*node) for node, weight in probability_rule(order, getcontext().prec))


@dataclass(frozen=True)
class Parameters:
    n0: D
    t0: D
    capacity: D
    area: D
    tmin: D
    tmax: D
    nu: D
    activation: D
    removal: D
    internal: D
    alpha: D
    nref: D

    @classmethod
    def from_problem(cls, problem):
        pool = problem['reservoir']
        result = cls(*(represented(problem[key]) for key in ('initial_coverage_m2', 'initial_temperature_k',
            'areal_heat_capacity_j_m2_k', 'patch_area_m2', 'temperature_min_k', 'temperature_max_k')),
            represented(pool['attempt_frequency_s']), represented(pool['activation_energy_ev'])*QE,
            represented(pool['desorption_energy_ev'])*QE, represented(pool['internal_energy_ev'])*QE,
            represented(pool['coverage_coefficient']), represented(pool['reference_coverage_m2']))
        if not (result.n0 >= 0 and result.nu > 0 and result.capacity > 0 and result.area > 0
                and result.tmin <= result.t0 <= result.tmax and result.tmin > 0
                and result.activation >= 0 and result.removal >= 0 and result.internal >= 0
                and result.alpha >= 0 and result.nref > 0):
            raise ValueError('oracle parameter domain exceeded')
        if result.activation*(1-result.alpha*result.n0/result.nref) < 0:
            raise ValueError('oracle requires a nonnegative barrier on admitted inventory')
        return result

    @property
    def shift(self):
        return (self.removal+self.internal)/(2*KB)

    def temperature_from_release(self, released):
        if not 0 <= released <= self.n0:
            raise ValueError('reference inventory domain exceeded')
        exponent = -2*KB*released/self.capacity
        temperature = self.t0+(self.t0+self.shift)*expm1(exponent)
        if not self.tmin <= temperature <= self.tmax:
            raise ValueError('analytic thermal curve leaves declared temperature domain')
        return temperature

    def release_from_s(self, depletion):
        return -self.n0*expm1(-depletion)

    def temperature_from_s(self, depletion):
        return self.temperature_from_release(self.release_from_s(depletion))

    def barrier(self, number):
        return self.activation*(1-self.alpha*number/self.nref)

    def time_derivative(self, depletion, maintained_temperature=False):
        temperature = self.t0 if maintained_temperature else self.temperature_from_s(depletion)
        number = self.n0*(-depletion).exp()
        return (self.barrier(number)/(KB*temperature)).exp()/self.nu

    def time_from_s(self, depletion, order, maintained_temperature=False):
        return integrate(lambda value: self.time_derivative(value, maintained_temperature), depletion, order)

    def time_from_inventory(self, number, order, maintained_temperature=False):
        if not 0 < number <= self.n0:
            raise ValueError('positive remaining inventory required for forward time map')
        return self.time_from_s((self.n0/number).ln(), order, maintained_temperature)

    def invert_time(self, time, order, maintained_temperature=False):
        if time < 0:
            raise ValueError('time must be nonnegative')
        if self.n0 == 0 or time == 0:
            return D(0), {'method': 'empty_or_time_zero', 'iterations': 0, 'relative_time_residual': D(0)}
        if self.activation == 0:
            depletion = self.nu*time
            if not maintained_temperature:
                self.temperature_from_s(depletion)
            return depletion, {'method': 'zero_barrier_exact_s_equals_nu_times_t', 'iterations': 0, 'relative_time_residual': D(0)}
        if maintained_temperature and self.alpha == 0:
            depletion = self.nu*(-self.activation/(KB*self.t0)).exp()*time
            return depletion, {'method': 'maintained_temperature_constant_barrier_exact_hazard', 'iterations': 0, 'relative_time_residual': D(0)}
        # For nonnegative alpha, Ea increases as N falls, while T decreases.
        # The per-parent hazard therefore decreases, giving s(t)<=r(0)*t.
        initial_rate = self.nu*(-self.barrier(self.n0)/(KB*self.t0)).exp()
        lower, upper = D(0), initial_rate*time
        if not maintained_temperature:
            available_release = -(self.capacity/(2*KB))*((self.tmin+self.shift)/(self.t0+self.shift)).ln()
            if available_release < self.n0:
                thermal_end = -(1-available_release/self.n0).ln()
                if upper >= thermal_end:
                    upper = thermal_end*(1-D(10)**(-getcontext().prec//2))
        if self.time_from_s(upper, order, maintained_temperature) < time:
            raise ValueError('requested time not bracketed within declared thermal domain')
        candidate = upper/2
        target = D(10)**(-min(45, getcontext().prec-25))
        residual = None
        for iteration in range(1, 200):
            mapped = self.time_from_s(candidate, order, maintained_temperature)
            residual = (mapped-time)/time
            if abs(residual) <= target:
                return candidate, {'method': 'safeguarded_Newton_with_monotone_positive_Decimal_quadrature',
                    'iterations': iteration, 'relative_time_residual': residual}
            if mapped > time:
                upper = candidate
            else:
                lower = candidate
            proposal = candidate-(mapped-time)/self.time_derivative(candidate, maintained_temperature)
            if not lower < proposal < upper:
                proposal = (lower+upper)/2
            if proposal == candidate:
                break
            candidate = proposal
        raise RuntimeError('independent monotone inverse did not converge: '+str(residual))

    def channels(self, number):
        released = self.n0-number
        temperature = self.temperature_from_release(released)
        translation = self.capacity*(self.t0+self.shift)*(-expm1(-2*KB*released/self.capacity))-(self.removal+self.internal)*released
        return {'coverage_m2': number, 'temperature_k': temperature, 'released_m2': released,
            'binding_energy_j_m2': self.removal*released, 'internal_energy_j_m2': self.internal*released,
            'translational_energy_j_m2': translation,
            'total_wall_energy_debit_j_m2': self.capacity*(self.t0-temperature),
            'gas_energy_j_m2': translation+self.internal*released,
            'wall_thermal_change_j_m2': self.capacity*(temperature-self.t0),
            'adsorbate_reference_energy_j_m2': -self.removal*number,
            'adsorbate_reference_change_j_m2': self.removal*released,
            'adsorbate_reference_inventory_change_j_m2': self.removal*released}

    def translation_by_positive_quadrature(self, number, order):
        released = self.n0-number
        return integrate(lambda amount: 2*KB*self.temperature_from_release(amount), released, order)


def final_reference(problem, time, *, precision, order, maintained_temperature=False):
    with localcontext() as context:
        context.prec = precision
        parameters = Parameters.from_problem(problem)
        depletion, diagnostic = parameters.invert_time(represented(time), order, maintained_temperature)
        number = parameters.n0*(-depletion).exp() if parameters.n0 else D(0)
        if maintained_temperature:
            released = parameters.n0-number
            channels = {'coverage_m2': number, 'temperature_k': parameters.t0, 'released_m2': released,
                'translational_energy_j_m2': 2*KB*parameters.t0*released,
                'internal_energy_j_m2': parameters.internal*released,
                'binding_energy_j_m2': parameters.removal*released}
        else:
            channels = parameters.channels(number)
        return channels, diagnostic
