"""Bind saved oracle results, source/CLI outputs and recorded commands.

This is a static readback/aggregation step. It executes no oracle, source,
numerical core, CLI, acquisition or test.
"""
import datetime
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
WORK = HERE.parent
REPO = Path('/workspace/Power-Flow')
RUN = WORK/'producer/reference-run'
ORACLE = HERE/'oracle-initial/report.json'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def value(record):
    return record['float_projection']


def main():
    if (HERE/'completion.json').exists():
        raise RuntimeError('refuse to overwrite independent completion')
    reference, producer, freeze = load(ORACLE), load(RUN/'report.json'), load(HERE/'before_run_freeze.json')
    assert reference['all_checks_passed'] is True and reference['status'] == 'passed'
    assert reference['distinct_cases'] == 6 and reference['distinct_saved_trajectories'] == 9
    assert reference['saved_sample_rows_checked'] == 289 and reference['CSV_JSON_scalar_cells_checked'] == 3757
    assert reference['source_model_imports'] == [] and reference['positive_core_or_CLI_calls'] == 0 and reference['source_or_old_suite_calls'] == 0
    for name, digest in freeze['independent_code_and_plan_sha256'].items():
        assert sha(HERE/name) == digest
    assert sha(HERE/'input_config.json') == sha(RUN/'input_config.json') == producer['config_sha256']
    for name, digest in producer['artifact_sha256'].items():
        assert sha(RUN/name) == digest
    for name, digest in producer['code_sha256'].items():
        assert sha(REPO/name) == digest
    for trajectory in producer['trajectories']:
        assert sha(RUN/trajectory['csv_file']) == trajectory['csv_sha256']
        assert sha(RUN/trajectory['history_file']) == trajectory['history_sha256']
    for name, digest in reference['input_sha256'].items():
        assert sha(name) == digest
    for trajectory in reference['trajectories']:
        for name, digest in trajectory['artifact_sha256'].items():
            assert sha(name) == digest
    commands = [json.loads(line) for line in (WORK/'commands.jsonl').read_text().splitlines()]
    executions = [record for record in commands if Path(record['log']).name == 'independent-feedback-oracle-initial.log']
    assert len(executions) == 1 and executions[0]['exit_code'] == 0
    assert sha(executions[0]['log']) == executions[0]['log_sha256']
    environment = [record for record in commands if Path(record['log']).name == 'independent-oracle-environment.log']
    assert len(environment) == 1 and environment[0]['exit_code'] == 1
    assert sha(environment[0]['log']) == environment[0]['log_sha256']
    trajectories = reference['trajectories']
    endpoint = max((value(v['absolute_budget_fraction']), t['case_id'], t['steps'], key)
        for t in trajectories for key, v in t['endpoint_errors_against_independent_time_inverse'].items())
    relation = max((value(v), t['case_id'], t['steps'], key)
        for t in trajectories for key, v in t['maximum_all_row_relation_budget_fractions'].items())
    ledger = max((value(v['absolute_budget_fraction']), t['case_id'], t['steps'], key)
        for t in trajectories for key, v in t['independently_recomputed_signed_ledger_maxima'].items())
    forward = max((value(v['local_number_equivalent_budget_fraction']), t['case_id'], t['steps'], v['sample_index'])
        for t in trajectories for v in t['selected_forward_time_checks'])
    precision = max((value(v['absolute_budget_fraction']), case_id, key)
        for case_id, case in reference['cases'].items() for key, v in case['coarse_refined_changes'].items())
    orders = [value(item['order']) for estimates in reference['temporal_self_orders'].values() for item in estimates]
    summary = {'schema': 'mitl-thermal-feedback-independent-summary-v1', 'status': 'passed',
        'oracle_report_sha256': sha(ORACLE), 'source_producer_report_sha256': sha(RUN/'report.json'),
        'cases': 6, 'saved_trajectories': 9, 'sample_rows': 289, 'CSV_JSON_scalar_cells': 3757,
        'area_once_checks': sum(t['area_once_extensive_projection_checks'] for t in trajectories),
        'forward_time_checks': sum(len(t['selected_forward_time_checks']) for t in trajectories),
        'max_endpoint_budget_fraction': endpoint, 'max_all_row_relation_budget_fraction': relation,
        'max_signed_ledger_absolute_budget_fraction': ledger, 'max_forward_local_number_equivalent_budget_fraction': forward,
        'max_reference_precision_order_budget_fraction': precision, 'finite_self_order_range': [min(orders), max(orders)],
        'final_reference_cases': {case_id: {'temperature_k': value(case['reference']['temperature_k']),
            'released_m2': value(case['reference']['released_m2']),
            'cooling_minus_maintained_emission_m2': value(reference['maintained_temperature_controls'][case_id]['signed_cooling_minus_maintained_emission_m2'])}
            for case_id, case in reference['cases'].items()},
        'summary_uses_display_float_projections': True,
        'precision_or_self_order_is_certified_bound': False,
        'roundoff_qualification': 'High-precision comparisons resolve the declared manufactured mathematical model of represented inputs and exact decimal SI constants. They do not remove float input/output or operational rounding floors; weak-release residuals use emitted/channel scales.'}
    assert summary['area_once_checks'] == 3468 and summary['forward_time_checks'] == 32
    (HERE/'summary.json').write_text(json.dumps(summary, indent=2, allow_nan=False)+'\n')
    artifact_names = ['decimal_reference.py', 'verify_saved_feedback.py', 'freeze_oracle.py', 'oracle_plan.json',
        'input_config.json', 'before_run_freeze.json', 'method.md', 'finalize_completion.py', 'oracle-initial/report.json', 'summary.json']
    record = {'schema': 'mitl-independent-thermal-feedback-completion-v1', 'status': 'passed', 'all_checks_passed': True,
        'completed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'report': str(ORACLE.relative_to(WORK)), 'report_sha256': sha(ORACLE), 'summary': str((HERE/'summary.json').relative_to(WORK)),
        'summary_sha256': sha(HERE/'summary.json'), 'producer_report': str((RUN/'report.json').relative_to(WORK)),
        'producer_report_sha256': sha(RUN/'report.json'), 'producer_code_sha256': producer['code_sha256'],
        'input_config_sha256': producer['config_sha256'],
        'cases': 6, 'saved_trajectories': 9, 'saved_sample_rows_checked': 289, 'CSV_JSON_scalar_cells_checked': 3757,
        'area_once_checks': 3468, 'selected_forward_time_checks': 32, 'refinement_family_steps': [8, 16, 32, 64],
        'refinement_quantities_checked': len(reference['temporal_self_orders']), 'self_order_min': min(orders), 'self_order_max': max(orders),
        'predeclared_budget_checks_passed': True, 'individual_energy_channel_checks_passed': True,
        'independent_final_time_inverse_cases': 6, 'zero_barrier_branch_exact': True, 'empty_control_exact': True,
        'independent_oracle_numerical_runs': 1, 'positive_core_or_CLI_calls_by_oracle': 0, 'core_imports_in_oracle': [],
        'source_or_old_suite_calls': 0, 'source_evolution_repeated': False, 'old_test_suites_repeated': False,
        'interval_certification_or_physical_uncertainty_claimed': False,
        'water_or_material_or_state_data_adopted': False, 'host_or_gap_or_MHD_coupling_verified': False,
        'artifact_sha256': {str((HERE/name).relative_to(WORK)): sha(HERE/name) for name in artifact_names},
        'command_records': executions, 'missing_dependency_probe': environment[0],
        'qualification': reference['qualification'],
        'limits': 'One manufactured stationary patch with fixed supplied internal/removal costs and zero external power. Independent analytic/integral checks and finite numerical refinement do not qualify physical water parameters, actual foil thermodynamics, wall transactions or gap response.'}
    path = HERE/'completion.json'
    path.write_text(json.dumps(record, indent=2, allow_nan=False)+'\n')
    print(json.dumps({'completion': str(path), 'sha256': sha(path), 'summary_sha256': sha(HERE/'summary.json'),
        'cases': 6, 'saved_trajectories': 9, 'rows': 289, 'independent_oracle_runs': 1, 'positive_core_or_CLI_calls': 0}, indent=2))


if __name__ == '__main__':
    main()
