"""Compare saved manufactured feedback trajectories with an independent oracle.

Only saved JSON/CSV and the local Decimal reference are read. No repository
module or source/thermal/transport producer is imported or executed.
"""
import argparse
import csv
import hashlib
import json
from decimal import Decimal, localcontext
from fractions import Fraction
from pathlib import Path

from decimal_reference import Parameters, final_reference, represented, KB

D = Decimal
HERE = Path(__file__).resolve().parent
CHANNELS = ('coverage_m2', 'temperature_k', 'released_m2', 'binding_energy_j_m2',
    'internal_energy_j_m2', 'translational_energy_j_m2', 'total_wall_energy_debit_j_m2',
    'gas_energy_j_m2', 'wall_thermal_change_j_m2', 'adsorbate_reference_energy_j_m2',
    'adsorbate_reference_change_j_m2', 'adsorbate_reference_inventory_change_j_m2')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def encode(value):
    if isinstance(value, D):
        return {'decimal': str(value), 'float_projection': float(value)}
    if isinstance(value, dict):
        return {key: encode(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [encode(item) for item in value]
    return value


def projected(value):
    if type(value) in (int, float):
        return ('float_input', float(value).hex())
    if isinstance(value, dict):
        return {key: projected(item) for key, item in value.items()}
    if isinstance(value, list):
        return [projected(item) for item in value]
    return value


def reference_scales(problem, reference):
    p = Parameters.from_problem(problem)
    scales = {key: abs(reference[key]) for key in CHANNELS}
    scales['coverage_m2'] = scales['released_m2']
    scales['temperature_k'] = abs(p.t0-reference['temperature_k'])
    scales['adsorbate_reference_energy_j_m2'] = abs(reference['binding_energy_j_m2'])
    return scales


def normalized(error, scale):
    if scale:
        return abs(error)/scale
    require(error == 0, 'structurally zero channel is not exactly zero')
    return D(0)


def metric_error(saved, expected, scale):
    error = represented(saved)-expected
    return {'signed_error': error, 'budget_scale': scale, 'absolute_budget_fraction': normalized(error, scale)}


def ledger_residuals(sample, p):
    x = {key: represented(sample[key]) for key in CHANNELS}
    thermal = p.capacity*(x['temperature_k']-p.t0)
    return {
        'inventory_N_plus_emitted_minus_initial_m2': x['coverage_m2']+x['released_m2']-p.n0,
        'adsorbate_change_from_M_minus_inventory_change_j_m2': x['adsorbate_reference_change_j_m2']-p.removal*(p.n0-x['coverage_m2']),
        'thermal_plus_wall_debit_j_m2': thermal+x['total_wall_energy_debit_j_m2'],
        'wall_debit_minus_separate_channels_j_m2': x['total_wall_energy_debit_j_m2']-x['binding_energy_j_m2']-x['internal_energy_j_m2']-x['translational_energy_j_m2'],
        'binding_minus_D_times_emitted_j_m2': x['binding_energy_j_m2']-p.removal*x['released_m2'],
        'internal_minus_I_times_emitted_j_m2': x['internal_energy_j_m2']-p.internal*x['released_m2'],
        'total_thermal_plus_adsorbate_inventory_change_plus_gas_j_m2': thermal+p.removal*(p.n0-x['coverage_m2'])+x['gas_energy_j_m2'],
        'total_thermal_plus_emitted_adsorbate_change_plus_gas_j_m2': thermal+x['adsorbate_reference_change_j_m2']+x['gas_energy_j_m2'],
        'gas_minus_internal_minus_translation_j_m2': x['gas_energy_j_m2']-x['internal_energy_j_m2']-x['translational_energy_j_m2'],
        'saved_thermal_change_minus_C_deltaT_j_m2': x['wall_thermal_change_j_m2']-thermal,
        'saved_adsorbate_energy_plus_D_N_j_m2': x['adsorbate_reference_energy_j_m2']+p.removal*x['coverage_m2'],
    }


def verify_trajectory(record, case, run_dir, final, plan):
    history_path, csv_path = run_dir/record['history_file'], run_dir/record['csv_file']
    history = load(history_path)
    require(projected(history['problem']) == projected(case['problem']), 'saved history problem differs from frozen input')
    require(projected(record['input_parameters']) == projected(case['problem']), 'producer report problem differs from frozen input')
    samples = history['samples']
    require(len(samples) == record['steps']+1 and len(samples) > 1, 'trajectory sample count mismatch')
    with csv_path.open(newline='') as stream:
        reader = csv.DictReader(stream)
        csv_rows = list(reader)
    require(len(csv_rows) == len(samples), 'CSV/JSON row count mismatch')
    csv_cells = 0
    for csv_row, sample in zip(csv_rows, samples):
        for key in ('time_s', *CHANNELS):
            require(float(csv_row[key]).hex() == float(sample[key]).hex(), 'saved CSV/JSON scalar differs: '+key)
            csv_cells += 1
    with localcontext() as context:
        context.prec = plan['refined_precision']
        p = Parameters.from_problem(case['problem'])
        scales = reference_scales(case['problem'], final)
        tolerance = D(plan['family_budget_tolerance'] if record['steps'] < 32 else plan['single_trajectory_budget_tolerance'])
        relation_max = {key: D(0) for key in CHANNELS}
        signed_max = {key: D(0) for key in CHANNELS}
        residual_max = {}
        selected = sorted({0, len(samples)//4, len(samples)//2, (3*len(samples))//4, len(samples)-1})
        forward = []
        extensive_checks = 0
        reference_channel_tolerance = D(plan['reference_change_tolerance'])
        for index, sample in enumerate(samples):
            # The all-row relation test uses the saved N as an independent argument.
            # Actual time accuracy is tested separately below and against final inversion.
            expected = p.channels(represented(sample['coverage_m2']))
            for key in CHANNELS:
                result = metric_error(sample[key], expected[key], scales[key])
                if result['absolute_budget_fraction'] > relation_max[key]:
                    relation_max[key], signed_max[key] = result['absolute_budget_fraction'], result['signed_error']
                require(result['absolute_budget_fraction'] <= tolerance, 'all-row independent relation exceeds declared budget: '+key)
            residuals = ledger_residuals(sample, p)
            for key, residual in residuals.items():
                scale = scales['released_m2'] if key.endswith('_m2') and not key.endswith('_j_m2') else scales['total_wall_energy_debit_j_m2']
                fraction = normalized(residual, scale)
                if fraction > residual_max.get(key, {}).get('absolute_budget_fraction', D(-1)):
                    residual_max[key] = {'signed_residual': residual, 'budget_scale': scale, 'absolute_budget_fraction': fraction, 'sample_index': index}
                require(fraction <= D(plan['ledger_budget_tolerance']), 'saved channel ledger exceeds declared budget: '+key)
            # The core declares one final projection after multiplying each saved
            # areal diagnostic by area; verify that convention without recomputing
            # or importing any source quantity.
            area_fraction = Fraction.from_float(float(case['problem']['patch_area_m2']))
            pairs = [(key, key[:-3]) for key in CHANNELS if key.endswith('_j_m2')]
            pairs += [('coverage_m2', 'coverage_number'), ('released_m2', 'released_number'),
                      ('inventory_residual_m2', 'inventory_residual_number')]
            for areal_key, extensive_key in pairs:
                expected_extensive = float(Fraction.from_float(float(sample[areal_key]))*area_fraction)
                require(float(sample['extensive'][extensive_key]).hex() == expected_extensive.hex(), 'extensive area-once projection differs: '+extensive_key)
                extensive_checks += 1
            if index in selected and index and p.n0:
                n = represented(sample['coverage_m2'])
                time = represented(sample['time_s'])
                coarse_time = p.time_from_inventory(n, plan['coarse_order'])
                refined_time = p.time_from_inventory(n, plan['refined_order'])
                quadrature_change = abs(refined_time-coarse_time)/represented(case['duration_s'])
                require(quadrature_change <= reference_channel_tolerance, 'forward-time finite-order change unresolved')
                # A local derivative converts the time residual into a number scale;
                # this is a sensitivity diagnostic, not a global error bound.
                s = (p.n0/n).ln()
                rate = n/p.time_derivative(s)
                number_equivalent = (refined_time-time)*rate
                forward.append({'sample_index': index, 'saved_time_s': time, 'mapped_time_s': refined_time,
                    'signed_time_residual_s': refined_time-time, 'time_residual_over_duration': (refined_time-time)/represented(case['duration_s']),
                    'coarse_refined_time_change_over_duration': quadrature_change,
                    'signed_local_number_equivalent_m2': number_equivalent,
                    'local_number_equivalent_budget_fraction': normalized(number_equivalent, scales['released_m2'])})
                require(normalized(number_equivalent, scales['released_m2']) <= tolerance, 'forward time-map residual exceeds declared emitted budget')
                qtranslation = p.translation_by_positive_quadrature(n, plan['refined_order'])
                primitive = expected['translational_energy_j_m2']
                require(normalized(qtranslation-primitive, scales['translational_energy_j_m2']) <= reference_channel_tolerance,
                        'positive translation quadrature disagrees with independent primitive')
        endpoint_errors = {key: metric_error(samples[-1][key], final[key], scales[key]) for key in CHANNELS}
        require(all(item['absolute_budget_fraction'] <= tolerance for item in endpoint_errors.values()), 'final inversion reference exceeds declared endpoint budget')
        return {'case_id': record['case_id'], 'steps': record['steps'], 'saved_samples': len(samples),
            'CSV_JSON_scalar_cells_checked': csv_cells, 'input_parameters_sha256': hashlib.sha256(json.dumps(case['problem'], sort_keys=True).encode()).hexdigest(),
            'area_once_extensive_projection_checks': extensive_checks,
            'artifact_sha256': {str(history_path): sha(history_path), str(csv_path): sha(csv_path)},
            'budget_scales': scales, 'declared_maximum_budget_fraction': tolerance,
            'maximum_all_row_relation_budget_fractions': relation_max, 'signed_errors_at_relation_maxima': signed_max,
            'independently_recomputed_signed_ledger_maxima': residual_max, 'selected_forward_time_checks': forward,
            'endpoint_errors_against_independent_time_inverse': endpoint_errors,
            'endpoint_values': {key: represented(samples[-1][key]) for key in CHANNELS}}


def observed_order(a, b, c):
    first, second = a-b, b-c
    if not first or not second or first*second <= 0 or abs(first) <= abs(second):
        return {'order': None, 'status': 'unresolved_zero_cancellation_sign_or_nonasymptotic_change',
            'coarse_change': first, 'fine_change': second}
    return {'order': (abs(first/second)).ln()/D(2).ln(), 'status': 'finite_self_difference_estimate',
        'coarse_change': first, 'fine_change': second}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-dir', type=Path, required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    require(not args.output_dir.exists(), 'fresh oracle output directory required')
    freeze, plan = load(HERE/'before_run_freeze.json'), load(HERE/'oracle_plan.json')
    for name, digest in freeze['independent_code_and_plan_sha256'].items():
        require(sha(HERE/name) == digest, 'frozen independent code or plan changed')
    config = load(HERE/'input_config.json')
    require(config['schema'] == 'mhdlab-thermal-feedback-manufactured-config-v1' and len(config['cases']) == 6, 'manufactured fixture contract changed')
    report = load(args.run_dir/'report.json')
    require(report['schema'] == 'mhdlab-thermal-feedback-reference-run-v1' and len(report['trajectories']) == 9, 'saved producer inventory differs')
    cases = {case['case_id']: case for case in config['cases']}
    require({(record['case_id'], record['steps']) for record in report['trajectories']} == {(case['case_id'], steps) for case in cases.values() for steps in case['steps']}, 'case/step selection differs')
    references, comparisons, controls = {}, [], {}
    for case_id, case in cases.items():
        coarse, coarse_diagnostic = final_reference(case['problem'], case['duration_s'], precision=plan['coarse_precision'], order=plan['coarse_order'])
        refined, refined_diagnostic = final_reference(case['problem'], case['duration_s'], precision=plan['refined_precision'], order=plan['refined_order'])
        with localcontext() as context:
            context.prec = plan['refined_precision']
            scales = reference_scales(case['problem'], refined)
            # Coarse Decimal results must not be projected through float64 here.
            changes = {key: {'signed_change': coarse[key]-refined[key], 'budget_scale': scales[key],
                'absolute_budget_fraction': normalized(coarse[key]-refined[key], scales[key])} for key in CHANNELS}
            require(all(item['absolute_budget_fraction'] <= D(plan['reference_change_tolerance']) for item in changes.values()), 'final-reference precision/order change unresolved')
        references[case_id] = {'reference': refined, 'coarse_inverse': coarse_diagnostic, 'refined_inverse': refined_diagnostic,
            'coarse_refined_changes': changes, 'precision_order_change_is_certified_bound': False}
        maintained, diagnostic = final_reference(case['problem'], case['duration_s'], precision=plan['refined_precision'], order=plan['refined_order'], maintained_temperature=True)
        controls[case_id] = {'model': 'externally maintained T0; extra heat needed is not supplied by the isolated reference',
            'reference': maintained, 'inverse': diagnostic,
            'signed_cooling_minus_maintained_emission_m2': refined['released_m2']-maintained['released_m2']}
    for record in report['trajectories']:
        comparisons.append(verify_trajectory(record, cases[record['case_id']], args.run_dir, references[record['case_id']]['reference'], plan))
    family = sorted((item for item in comparisons if item['case_id'] == config['refinement_case_id']), key=lambda item: item['steps'])
    require([item['steps'] for item in family] == [8, 16, 32, 64], 'refinement family changed')
    orders = {}
    with localcontext() as context:
        context.prec = plan['refined_precision']
        for key in ('coverage_m2', 'temperature_k', 'released_m2', 'binding_energy_j_m2', 'internal_energy_j_m2',
                    'translational_energy_j_m2', 'total_wall_energy_debit_j_m2', 'gas_energy_j_m2'):
            values = [item['endpoint_values'][key] for item in family]
            orders[key] = [observed_order(*values[:3]), observed_order(*values[1:])]
            require(all(item['order'] is not None and item['order'] >= D(plan['minimum_resolved_self_order']) for item in orders[key]), 'temporal self-order unresolved or too low: '+key)
    args.output_dir.mkdir(parents=True)
    result = {'schema': 'mitl-independent-thermal-feedback-oracle-v1', 'status': 'passed', 'all_checks_passed': True,
        'parameter_status': 'manufactured', 'cases': references, 'trajectories': comparisons,
        'maintained_temperature_controls': controls, 'temporal_self_orders': orders,
        'distinct_cases': len(cases), 'distinct_saved_trajectories': len(comparisons),
        'saved_sample_rows_checked': sum(item['saved_samples'] for item in comparisons),
        'CSV_JSON_scalar_cells_checked': sum(item['CSV_JSON_scalar_cells_checked'] for item in comparisons),
        'input_sha256': {str(HERE/'input_config.json'): sha(HERE/'input_config.json'), str(args.run_dir/'report.json'): sha(args.run_dir/'report.json')},
        'source_model_imports': [], 'positive_core_or_CLI_calls': 0, 'source_or_old_suite_calls': 0,
        'numeric_method': plan['numeric_method'], 'qualification': plan['qualification'],
        'no_physical_water_or_material_or_state_data_adopted': True, 'host_acceptance_verified': False}
    path = args.output_dir/'report.json'
    path.write_text(json.dumps(encode(result), indent=2, allow_nan=False)+'\n')
    print(json.dumps({'report': str(path), 'sha256': sha(path), 'cases': len(cases), 'saved_trajectories': len(comparisons),
        'rows': result['saved_sample_rows_checked'], 'self_orders': encode(orders)}, indent=2))


if __name__ == '__main__':
    main()
