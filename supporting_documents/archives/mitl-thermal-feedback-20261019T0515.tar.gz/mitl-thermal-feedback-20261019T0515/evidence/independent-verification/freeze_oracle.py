"""Freeze independent code, declared fixtures and tolerances before evaluation."""
import ast
import datetime
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
WORK = HERE.parent
CONFIG = Path('/workspace/Power-Flow/configs/thermal_feedback_manufactured.json')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    target = HERE/'before_run_freeze.json'
    if target.exists() or (HERE/'input_config.json').exists():
        raise RuntimeError('refuse to replace the pre-run freeze')
    status = json.loads((WORK.parent/'mitl-upstream-status.json').read_text())
    assert status['active_lease_owner'] == WORK.name
    assert datetime.datetime.fromisoformat(status['active_editing_lease_until_utc']) > datetime.datetime.now(datetime.timezone.utc)
    for name in ('decimal_reference.py', 'verify_saved_feedback.py'):
        tree = ast.parse((HERE/name).read_text())
        for node in ast.walk(tree):
            if isinstance(node, ast.Import):
                assert not any(alias.name.split('.')[0] in {'mhdlab', 'tools', 'numpy', 'scipy', 'mpmath'} for alias in node.names)
            elif isinstance(node, ast.ImportFrom):
                assert (node.module or '').split('.')[0] not in {'mhdlab', 'tools', 'numpy', 'scipy', 'mpmath'}
    config = json.loads(CONFIG.read_text())
    assert len(config['cases']) == 6 and sum(len(case['steps']) for case in config['cases']) == 9
    (HERE/'input_config.json').write_bytes(CONFIG.read_bytes())
    paths = ('decimal_reference.py', 'verify_saved_feedback.py', 'oracle_plan.json', 'input_config.json', 'freeze_oracle.py')
    record = {'schema': 'mitl-thermal-feedback-independent-before-run-freeze-v1',
        'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'independent_code_and_plan_sha256': {name: sha(HERE/name) for name in paths},
        'public_input_config': str(CONFIG), 'public_input_config_sha256': sha(CONFIG),
        'case_ids': [case['case_id'] for case in config['cases']],
        'distinct_cases': 6, 'expected_distinct_saved_trajectories': 9,
        'independent_numerical_oracle_run_count_before_freeze': 0,
        'positive_core_or_CLI_calls_by_oracle': 0,
        'missing_mpmath_environment_probe': {'exit_code': 1, 'log': str(WORK/'independent-oracle-environment.log'),
            'log_sha256': sha(WORK/'independent-oracle-environment.log'),
            'interpretation': 'Dependency availability only; no oracle, model or package installation ran.'},
        'limits': 'Independent Decimal reference only; no repository numerical module imports or physical data adoption. Finite precision/order changes are estimates, not certified enclosures.'}
    target.write_text(json.dumps(record, indent=2, allow_nan=False)+'\n')
    print(json.dumps({'freeze': str(target), 'sha256': sha(target), 'code_and_plan_sha256': record['independent_code_and_plan_sha256']}, indent=2))


if __name__ == '__main__':
    main()
