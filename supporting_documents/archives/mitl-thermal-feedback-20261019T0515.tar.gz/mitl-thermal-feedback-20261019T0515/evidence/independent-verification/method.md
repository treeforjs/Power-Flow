# Independent manufactured feedback reference

This reference reads saved trajectories. It does not import the numerical core,
run its CLI, reconstruct a source history or add physical material/water data.
All coefficients describe a supplied stationary single-patch manufactured model.

For remaining areal inventory `N`, release rate `Gamma`, positive areal thermal
capacity `C_A`, independent removal cost `D` and fixed gas internal energy `I`,

```
dN/dt = -Gamma(N,T)
C_A dT/dt = -Gamma(N,T) (D + I + 2 kB T)
```

The adsorption reference is `-D*N`. Its increase as inventory leaves is distinct
from emitted internal and translational energy. Eliminating time gives

```
A = (D+I)/(2 kB)
T(N) = (T0+A) exp[2 kB (N-N0)/C_A] - A
```

This relation does not assume a constant rate or a constant kinetic barrier.
Writing `s=-ln(N/N0)` leaves a positive monotone time map,

```
t(s) = integral_0^s exp[Ea(N0 exp(-v))/(kB T(v))] / nu dv.
```

The zero-barrier branch is exact: `s=nu*t`, even while the wall cools. An empty
initial inventory has no release and retains its initial temperature. The
separate maintained-temperature control evaluates the same declared rate at
`T0`. It requires external heat and is not the isolated-wall conservation model.

The final inverse is evaluated once per distinct case at each declared
precision/order and reused across the nonlinear temporal-refinement family.
Analytic temperature and each energy-channel relation are checked at every
saved sample's remaining inventory. Selected samples also pass through the
forward time map; endpoint values are compared against the independent time
inverse. Those timing tests are distinct from checking the thermal invariant.
The positive integral of `2*kB*T` over emitted inventory checks its analytic
primitive independently. Signed inventory, thermal, adsorption, gas and
allocation residuals are retained separately.

Problem/time parameters first receive the core's float64 input projection, then
`Decimal.from_float` retains that represented number. The exact declared SI
decimals are `kB=1.380649e-23 J/K` and `1 eV=1.602176634e-19 J`. Decimal precision
does not recover information already lost at input/output projection, and the
operational numerical core may reach a float rounding floor. The 80/120-digit,
24/48-node comparisons are numerical estimates, not interval certificates or
physical error bars. Legendre roots and weights are generated in Decimal;
binary cosine supplies only starting guesses for root refinement.

Accuracy scales use emitted inventory and each separate final energy channel,
not the much larger initial wall/inventory baseline. Temperature uses the final
temperature decrease; adsorption baseline errors use its removal change.
Structurally zero channels require zero error. Temporal self-order uses actual
three-grid differences, with cancellation/zero/nonasymptotic cases reported as
unresolved rather than assigned an order.

`oracle_plan.json` fixes the cases, tolerances and qualifications before numerical
evaluation; `before_run_freeze.json` fixes its code and supplied configuration.
The missing `mpmath` probe is preserved separately. No dependency was installed.
