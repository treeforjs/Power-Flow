"""Independent material and conservative boundary-source references."""
