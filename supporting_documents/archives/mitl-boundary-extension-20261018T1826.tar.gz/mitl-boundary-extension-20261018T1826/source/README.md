# Conservative boundary and bounded transport source subset

Source files are byte-identical to the public commit in the parent handoff.
This initializer intentionally imports no legacy runner. This guide, initializer,
pytest settings and dependency list are extraction wrappers.

Use Python3.11 or newer with requirements.txt, then run:

```sh
python -m pytest -q -W error
python tools/run_temkin_release.py --demo --output-dir runs/source
python tools/sample_temkin_boundary.py --source runs/source/temkin_release.h5 --source-run-summary runs/source/summary.json --masses configs/manufactured_boundary_masses.json --interval 20 --packets 4096 --output-dir runs/packets
```

For the complete planar workflow and physical/numerical qualifications see
`docs/temkin_boundary_interface.md`. The example heating, mass and release
parameters are manufactured. No water mechanism or measured spectrum is supplied.
`docs/material_transport_inputs.md` describes the bounded253.15–423.15K input
contract; it is not a high-temperature foil model or an automatically selected
FLASH input. No gap evolution, collisions or radiation are invoked.

Recovered data and input adapters do not require the original source PDF.
The optional recovery integration test skips when its external PDF is absent.
Install a reviewed PyMuPDF version and retrieve the hash-identified official PDF
only when rerunning `tools/recover_flynn_304_transport.py`. Source papers are not
redistributed. The historical audit may reference files in the complete repo.
