import csv,hashlib,json,pathlib,sys
sys.path.insert(0,'/workspace/Power-Flow')
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mhdlab.constants import KB,QE
from mhdlab.temkin_release import TemkinReservoir
from mhdlab.temkin_emission_time import FrozenTemkinEmission
repo=pathlib.Path('/workspace/Power-Flow');out=repo/'runs/temkin_time_illustration_20261018T1826';out.mkdir(exist_ok=False)
pool=TemkinReservoir('manufactured','M:ground',1e9,.3,.2,0.,.7,1e18,1e18,'manufactured rate','manufactured independent cost')
law=FrozenTemkinEmission(pool,1e18,700.,1e-7)
time=np.linspace(0,law.dt_s,301);cdf=law.cdf(time)
initial_rate=pool.attempt_frequency_s*np.exp(-pool.activation_energy_ev*(1-pool.coverage_coefficient)*QE/(KB*700.))
fixed_cdf=-np.expm1(-initial_rate*time)/(-np.expm1(-initial_rate*law.dt_s))
with (out/'cdf.csv').open('w',newline='') as f:
 w=csv.writer(f);w.writerow(['time_offset_s','temkin_conditional_cdf','constant_initial_rate_conditional_cdf']);w.writerows(zip(time,cdf,fixed_cdf))
fig,ax=plt.subplots(figsize=(7,4.5));ax.plot(time*1e9,cdf,label='Coverage-dependent release');ax.plot(time*1e9,fixed_cdf,'--',label='Constant initial-rate comparison');ax.set(xlabel='Emission offset [ns]',ylabel='Conditional emitted-population CDF',title='Manufactured timing verification example');ax.legend();fig.tight_layout();fig.savefig(out/'conditional_cdf.png',dpi=180);plt.close(fig)
summary={'scope':'manufactured numerical illustration; no physical material or water fit','parameters':{'initial_coverage_m2':1e18,'temperature_k':700.,'dt_s':law.dt_s,'attempt_frequency_s':1e9,'activation_energy_ev':.3,'coverage_coefficient':.7,'reference_coverage_m2':1e18},'law_identity':law.law_identity,'time_identity':law.time_identity,'maximum_cdf_difference_from_constant_initial_rate':float(abs(cdf-fixed_cdf).max()),'source_sha256':{name:hashlib.sha256((repo/name).read_bytes()).hexdigest() for name in ['mhdlab/temkin_emission_time.py','mhdlab/temkin_release.py','mhdlab/thermal_release.py','mhdlab/constants.py']},'artifacts_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in out.iterdir()}}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
