import csv,hashlib,json,pathlib,sys
sys.path.insert(0,'/workspace/Power-Flow')
from mhdlab.material_transport import load_flynn_304_transport
r=pathlib.Path('/workspace/Power-Flow');out=r/'runs/material_inputs_20261018T1826';out.mkdir(exist_ok=False)
t=load_flynn_304_transport(r/'data/materials/flynn_1968_304_transport.csv',r/'data/materials/flynn_1968_304_transport.json',expected_material_grade='AISI Type 304')
v=t.evaluate([253.15,293.15,300.,423.15])
with(out/'transport_values.csv').open('w',newline='')as f:
 w=csv.writer(f);w.writerow(['temperature_K','electrical_resistivity_ohm_m','electrical_conductivity_S_m','thermal_conductivity_W_m_K']);w.writerows(zip(v.temperature_k,v.resistivity_ohm_m,v.electrical_conductivity_s_m,v.thermal_conductivity_w_m_k))
try:t.evaluate(700.)
except ValueError as exc:outside=str(exc)
else:raise AssertionError('Out-of-domain temperature was accepted')
s={'scope':'bounded published smoothed304 specimen input; no runtime model selected','table_metadata':t.metadata,'out_of_domain_query_K':700.,'out_of_domain_rejected':True,'out_of_domain_error':outside,'source_sha256':{p:hashlib.sha256((r/p).read_bytes()).hexdigest()for p in ['mhdlab/material_transport.py','data/materials/flynn_1968_304_transport.csv','data/materials/flynn_1968_304_transport.json']},'artifacts_sha256':{'transport_values.csv':hashlib.sha256((out/'transport_values.csv').read_bytes()).hexdigest()}}
(out/'summary.json').write_text(json.dumps(s,indent=2)+'\n');print(json.dumps({'output':str(out),'domain_K':t.supported_temperature_range_k,'query700_rejected':True,'rho_at293_15_ohm_m':float(v.resistivity_ohm_m[1]),'kappa_at293_15_W_m_K':float(v.thermal_conductivity_w_m_k[1])},indent=2))
