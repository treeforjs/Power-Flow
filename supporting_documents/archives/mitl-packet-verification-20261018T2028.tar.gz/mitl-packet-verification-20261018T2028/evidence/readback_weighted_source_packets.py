"""Reopen saved launch samples and reduce them without sampling again."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sys

import numpy as np

REPO = Path('/workspace/Power-Flow')
sys.path.insert(0, str(REPO))
from mhdlab.constants import KB
from mhdlab.temkin_planar_io import load_temkin_planar_release_history

WORK = Path(__file__).parent
SOURCE = Path('/workspace/research_work/mitl-upstream-20261018T1947/joint-source-q8/source_input.h5')
REFERENCE = Path('/workspace/research_work/mitl-upstream-20261018T1947/joint-source-q32/report.json')
MASSES = REPO / 'configs/manufactured_boundary_masses.json'
LD = np.longdouble
SEEDS = [1729, 2718, 3141, 5772, 8111, 104729, 130363, 155921]
BUDGETS = [1024, 4096, 16384]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def mean(values, weights):
    return np.sum(np.asarray(values, dtype=LD) * weights, dtype=LD)


def centered_cov(left, right, weights):
    left, right = np.asarray(left, dtype=LD), np.asarray(right, dtype=LD)
    return mean(left - mean(left, weights), weights * (right - mean(right, weights)))


def close(actual, expected, *, rtol=4e-13, scale=0.):
    actual, expected = np.asarray(actual, dtype=LD), np.asarray(expected, dtype=LD)
    tolerance = LD(rtol) * np.maximum(np.abs(expected), LD(scale))
    assert np.all(np.abs(actual - expected) <= tolerance), (actual, expected, tolerance)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--packet-dir', type=Path, required=True)
    parser.add_argument('--output', type=Path, default=WORK / 'packet_readback.json')
    args = parser.parse_args()
    assert not args.output.exists()
    source_hash, ref_hash, mass_hash = sha(SOURCE), sha(REFERENCE), sha(MASSES)
    assert source_hash == '1bb3a617adb2f740889636cbbac19265f41a43974a10741f76b690b277ea9723'
    reference = json.loads(REFERENCE.read_text())
    assert reference['input_source_sha256'] == source_hash
    assert reference['parameter_status'] == 'manufactured'
    assert reference['joint_moments']['quadrature_order'] == 32
    mass_config = json.loads(MASSES.read_text())
    assert mass_config['mass_status'] == 'manufactured'
    study_path = args.packet_dir.parent / 'report.json'
    study = json.loads(study_path.read_text())
    assert study['schema'] == 'mhdlab-weighted-source-packet-verification-v1'
    assert study['parameter_status'] == 'manufactured'
    for key, path in [('source', SOURCE), ('finite_reference_report', REFERENCE),
                      ('mass_config', MASSES), ('verification_script', WORK / 'verify_weighted_source_packets.py')]:
        assert study['inputs'][key]['sha256'] == sha(path), key
    for name, digest in study['inputs']['public_code_sha256'].items():
        assert sha(REPO / name) == digest, name
    assert study['configuration']['seeds'] == SEEDS
    assert study['configuration']['packet_budgets'] == BUDGETS
    assert study['configuration']['interval_index'] == 6
    producer_cases = {Path(case['artifact']['path']).name: case for case in study['cases']}
    assert len(producer_cases) == 24
    history = load_temkin_planar_release_history(SOURCE)
    x_edges, z_edges = history.x_edges_m.astype(LD), history.z_edges_m.astype(LD)
    dx, dz = np.diff(x_edges), np.diff(z_edges)
    face_center = (x_edges[0] + x_edges[-1]) / 2
    records = []
    files = sorted(args.packet_dir.glob('n*_seed*.npz'))
    assert len(files) == 24, len(files)
    assert {path.name for path in files} == set(producer_cases)
    for path in files:
        with np.load(path, allow_pickle=False) as loaded:
            a = {name: loaded[name] for name in loaded.files}
        assert str(a['schema']) == 'mhdlab-weighted-source-packet-evidence-v1'
        n, interval = int(a['packet_budget']), int(a['interval_index'])
        producer_case = producer_cases[path.name]
        assert producer_case['artifact']['sha256'] == sha(path)
        assert n == producer_case['packet_budget'] and int(a['seed']) == producer_case['seed']
        assert interval == 6
        u = a['uniforms']
        assert u.shape == (n, 7) and np.all((u > 0) & (u < 1))
        assert len(a['particle_weight']) == n
        assert np.all(a['particle_weight'] > 0)
        pool, current, width = (a[name] for name in ('reservoir_index', 'source_current_index', 'source_width_index'))
        for indices, extent in [(pool, len(history.reservoirs)), (current, len(dz)), (width, len(dx))]:
            assert indices.dtype.kind in 'iu' and np.all((indices >= 0) & (indices < extent))
        theta = LD(KB) * history.temperature_k[interval, current, width].astype(LD)
        assert np.array_equal(a['temperature_k'], history.temperature_k[interval, current, width])
        states = np.asarray([history.reservoirs[int(p)].state_id for p in pool])
        assert np.array_equal(a['state_ids'], states)
        expected_masses = np.asarray([mass_config['state_masses_kg'][state] for state in states])
        assert np.array_equal(a['mass_kg'], expected_masses)
        assert np.array_equal(a['momentum_kg_m_s'], a['mass_kg'][:, None] * a['velocity_m_s'])
        resolved, uniform = a['resolved_position_m'], a['uniform_width_position_m']
        assert resolved.shape == uniform.shape == (n, 3)
        assert np.array_equal(resolved[:, 1:], uniform[:, 1:])
        assert np.all(resolved[:, 1] == a['face_normal_coordinate_m'])
        close(resolved[:, 0], x_edges[width] + dx[width] * u[:, 2], scale=float(dx.max()))
        close(uniform[:, 0], x_edges[0] + (x_edges[-1] - x_edges[0]) * u[:, 2], scale=float(dx.max()))
        close(resolved[:, 2], z_edges[current] + dz[current] * u[:, 6], scale=float(dz.max()))
        close(a['source_current_offset_m'], dz[current] * u[:, 6], scale=float(dz.max()))
        assert np.array_equal(a['time_s'], float(history.time_edges_s[interval]) + a['time_offset_s'])
        dt = float(history.time_edges_s[interval + 1] - history.time_edges_s[interval])
        assert np.all((a['time_offset_s'] >= 0) & (a['time_offset_s'] <= dt))
        velocity = a['velocity_m_s'].astype(LD)
        assert np.all(velocity[:, 1] * int(a['outward_normal_sign']) > 0)
        energy = a['mass_kg'].astype(LD) * np.sum(velocity * velocity, axis=1, dtype=LD) / 2
        energy_from_uniforms = theta * (-np.log1p(-u[:, 3].astype(LD)) - np.log(u[:, 4].astype(LD)))
        close(energy, energy_from_uniforms, rtol=3e-14)
        component_numbers, component_thetas, component_counts = [], [], []
        physical_weights = a['particle_weight'].astype(LD)
        actual_components = set(zip(a['component_reservoir_index'].tolist(), a['component_current_index'].tolist(), a['component_width_index'].tolist()))
        positive_components = set(zip(*(array.tolist() for array in np.nonzero(history.released_m2[interval] > 0))))
        assert actual_components == positive_components
        for ci, (p, j, k) in enumerate(zip(a['component_reservoir_index'], a['component_current_index'], a['component_width_index'])):
            selection = (pool == p) & (current == j) & (width == k)
            count = int(np.count_nonzero(selection))
            assert count == int(a['packet_counts'][ci]) and count > 0
            number = LD(history.released_m2[interval, p, j, k]) * dx[k] * dz[j]
            local_theta = LD(KB) * LD(history.temperature_k[interval, j, k])
            close(a['component_released_particles'][ci], number)
            close(np.sum(physical_weights[selection], dtype=LD), number)
            assert np.all(physical_weights[selection] == physical_weights[selection][0])
            close(physical_weights[selection], number / count)
            close(a['component_expected_translational_energy_j'][ci], number * 2 * local_theta)
            sampled = np.sum(physical_weights[selection] * energy[selection], dtype=LD)
            close(a['component_sampled_translational_energy_j'][ci], sampled)
            close(a['component_translational_energy_sampling_residual_j'][ci],
                  LD(a['component_sampled_translational_energy_j'][ci]) - LD(a['component_expected_translational_energy_j'][ci]),
                  scale=float(number * 2 * local_theta))
            component_numbers.append(number)
            component_thetas.append(local_theta)
            component_counts.append(count)
        numbers, component_theta = np.asarray(component_numbers, dtype=LD), np.asarray(component_thetas, dtype=LD)
        assert len(set(zip(a['component_reservoir_index'].tolist(), a['component_current_index'].tolist(), a['component_width_index'].tolist()))) == len(numbers)
        expected_positive = np.count_nonzero(history.released_m2[interval] > 0)
        assert len(numbers) == expected_positive
        assert sum(component_counts) == n
        total = np.sum(numbers, dtype=LD)
        probability = numbers / total
        normalized_weights = physical_weights / np.sum(physical_weights, dtype=LD)
        expected_mean = mean(2 * component_theta, probability)
        expected_conditional_mean_variance = mean((2 * component_theta - expected_mean) ** 2, probability)
        within_variance = mean(2 * component_theta ** 2, probability)
        expected_second = mean(6 * component_theta ** 2, probability)
        expected_variance = expected_conditional_mean_variance + within_variance
        close(expected_second - expected_mean ** 2, expected_variance)
        se2 = np.sum(probability ** 2 * 2 * component_theta ** 2 / np.asarray(component_counts), dtype=LD)
        second_se2 = np.sum(probability ** 2 * 84 * component_theta ** 4 / np.asarray(component_counts), dtype=LD)
        sampled_mean = mean(energy, normalized_weights)
        sampled_second = mean(energy * energy, normalized_weights)
        plugin_variance = centered_cov(energy, energy, normalized_weights)
        output = {
            'artifact': path.name, 'sha256': sha(path), 'packets': n, 'seed': int(a['seed']),
            'interval_index': interval, 'components': len(numbers), 'minimum_component_packets': min(component_counts),
            'particle_count': float(total), 'expected_mean_energy_j': float(expected_mean),
            'expected_raw_second_energy_j2': float(expected_second),
            'expected_conditional_mean_energy_variance_j2': float(expected_conditional_mean_variance),
            'expected_within_component_energy_variance_j2': float(within_variance),
            'expected_total_energy_variance_j2': float(expected_variance),
            'mean_energy_conditional_standard_error_j': float(np.sqrt(se2)),
            'raw_second_energy_conditional_standard_error_j2': float(np.sqrt(second_se2)),
            'sampled_mean_energy_j': float(sampled_mean), 'sampled_raw_second_energy_j2': float(sampled_second),
            'sampled_plugin_energy_variance_j2': float(plugin_variance),
            'sampled_corrected_energy_variance_j2': float(plugin_variance + se2),
            'mean_energy_conditional_z': float((sampled_mean - expected_mean) / np.sqrt(se2)),
            'raw_second_energy_conditional_z': float((sampled_second - expected_second) / np.sqrt(second_se2)),
            'unweighted_mean_energy_j': float(np.mean(energy, dtype=LD)),
            'paired_exact_shared_arrays': ['time_s', 'time_offset_s', 'state_ids', 'mass_kg', 'temperature_k',
                                          'velocity_m_s', 'momentum_kg_m_s', 'particle_weight', 'current_position_m'],
            'hypotheses': {},
        }
        for hypothesis, position in [('resolved', resolved), ('uniform_width', uniform)]:
            x = position[:, 0].astype(LD)
            square = (x - face_center) ** 2
            time = a['time_offset_s'].astype(LD)
            output['hypotheses'][hypothesis] = {
                'mean_time_s': float(LD(history.time_edges_s[interval]) + mean(time, normalized_weights)),
                'variance_time_s2': float(centered_cov(time, time, normalized_weights)),
                'mean_x_m': float(mean(x, normalized_weights)),
                'variance_x_m2': float(centered_cov(x, x, normalized_weights)),
                'mean_z_m': float(mean(position[:, 2], normalized_weights)),
                'mean_width_centered_square_m2': float(mean(square, normalized_weights)),
                'cov_time_width_centered_square_s_m2': float(centered_cov(time, square, normalized_weights)),
                'cov_kinetic_energy_width_centered_square_j_m2': float(centered_cov(energy, square, normalized_weights)),
                'cov_local_expected_energy_width_centered_square_j_m2': float(centered_cov(2 * theta, square, normalized_weights)),
                'cov_time_kinetic_energy_s_j': float(centered_cov(time, energy, normalized_weights)),
            }
        # The saved fixture has one reservoir; do not silently pool physical states.
        assert len(history.reservoirs) == 1
        deterministic = reference['joint_moments']['reservoirs'][0]['conditional_interval'][interval]
        close(expected_mean, deterministic['resolved']['mean_expected_translational_energy_j'])
        close(expected_conditional_mean_variance, deterministic['resolved']['variance_expected_translational_energy_j2'])
        close(total, deterministic['resolved']['released_number'])
        output['deterministic_conditional'] = deterministic
        records.append(output)
    assert {(item['packets'], item['seed']) for item in records} == {(budget, seed) for budget in BUDGETS for seed in SEEDS}
    assert len({item['interval_index'] for item in records}) == 1
    for seed in SEEDS:
        with np.load(args.packet_dir / f'n{max(BUDGETS):06d}_seed{seed:06d}.npz', allow_pickle=False) as largest:
            for budget in BUDGETS[:-1]:
                with np.load(args.packet_dir / f'n{budget:06d}_seed{seed:06d}.npz', allow_pickle=False) as smaller:
                    assert np.array_equal(smaller['uniforms'], largest['uniforms'][:budget])
    result = {
        'schema': 'mhdlab-weighted-packet-readback-v1', 'parameter_status': 'manufactured',
        'case_count': len(records), 'source_sha256': source_hash, 'reference_sha256': ref_hash,
        'mass_configuration_sha256': mass_hash, 'script_sha256': sha(__file__), 'producer_report_sha256': sha(study_path),
        'arithmetic': 'Independent long-double source/geometry reductions; sampled kinetic energy reconstructed from saved velocities and independently from open variates. No sampling repeated.',
        'qualifications': ['Independent-uniform statistical model is assumed, not established by open-variate API guards.',
                           'Eight seed streams are shared across budgets with verified common input prefixes. Cases across different budgets are correlated; no independent cross-budget uncertainty is inferred.',
                           'Finite seed errors and conditional-model z values are descriptive, not physical confidence intervals.',
                           'No trajectories, chemistry, spectra, moving wall, coupled host or actual FLASH run.'],
        'cases': records,
    }
    args.output.write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
    print(json.dumps({'case_count': len(records), 'output': str(args.output), 'sha256': sha(args.output),
                      'maximum_abs_mean_energy_z': max(abs(item['mean_energy_conditional_z']) for item in records)}, indent=2))


if __name__ == '__main__':
    main()
