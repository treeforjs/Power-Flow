# Next bounded upstream task: partial source-emission windows

Status: proposed interface and numerical requirements; not implemented or
numerically qualified in this packet.

The next queued task selects a local source-emission interval `[a,b]` inside
one original frozen-temperature release interval. It must retain the original
law, inventory reference, state, patch area and timing identity. Selection does
not restart physical inventory, add another reservoir or change temperature.

The existing conditional-time interface supports full original intervals. Its
public methods do not supply a qualified log-CDF or log-survival function for
conditioning on arbitrary late gates. In particular the depletion helper's
large-depletion sentinel serves its original whole-interval quantile domain;
it does not establish zero late-window release. Subtracting endpoint CDFs that
both round to one can erase a valid mathematical window. Mapping a new uniform
variate through that rounded CDF difference is also unsuitable.

A separate immutable source-window object should retain the parent law and
local start/end offsets. It should expose log fraction of the initial
inventory, log probability within the parent's released population, represented
areal and physical-patch counts, representation flags and local delay quantiles
and moments. Start and delay must remain separate so a narrow late window does
not lose its variance when its absolute times round together.

An equivalent law rebased to the population at `a` is a promising construction.
Derive the transformed rate and coverage parameter directly from the reviewed
law, then solve its local depletion over `b-a`. Compute the window's log amount
from starting survival and local release, without subtracting endpoint CDFs
or nearly equal depletion values. Retain mathematical log amounts separately
from representable conservative accounting budgets. Any supported domain must
bound log-mass error as well as time inversion error: a small relative time
error need not give a small survival error at large depletion.

New independent checks should cover constant-barrier closed forms, tiny-hazard
nearly uniform windows, nonlinear direct integration, endpoint CDFs both rounded
to one, narrow late windows, partition residuals and explicit unsupported-range
failures. Do not claim exact floating-point partition additivity or silently
replace unresolved positive source budgets with zero.

A source gate selects launch times. A recorded photon gate selects photon
times after transport, excitation and radiation; particles emitted before that
gate may contribute. The recovered timing-origin and shot-association limits
remain applicable. This upstream interface supplies no kinetic evolution or
collisional-radiative response.
