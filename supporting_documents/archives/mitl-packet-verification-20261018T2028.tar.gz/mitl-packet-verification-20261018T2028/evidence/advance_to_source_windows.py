"""Record completed packet evidence and advance the saved upstream queue."""
import datetime
import fcntl
import hashlib
import json
from pathlib import Path

work = Path(__file__).parent
status_path = Path('/workspace/research_work/mitl-upstream-status.json')
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
study = json.loads((work / 'packet-evidence/report.json').read_text())
readback = json.loads((work / 'packet_readback.json').read_text())
comparison = json.loads((work / 'packet_reduction_comparison.json').read_text())
assert study['verification']['case_count'] == readback['case_count'] == 24
assert comparison['scalar_comparisons'] == 576
now = datetime.datetime.now(datetime.timezone.utc).isoformat()
with Path('/workspace/research_work/mitl-upstream-status.lock').open('a') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX)
    status = json.loads(status_path.read_text())
    assert status['active_lease_owner'] == 'mitl-upstream-20261018T2028'
    assert datetime.datetime.fromisoformat(status['active_editing_lease_until_utc']) > datetime.datetime.now(datetime.timezone.utc)
    assert 'Compare deterministic joint' in status['next_work'][0]['task']
    completed = {
        'task': status['next_work'].pop(0)['task'], 'completed_utc': now,
        'study_report_sha256': sha(work / 'packet-evidence/report.json'),
        'readback_report_sha256': sha(work / 'packet_readback.json'),
        'comparison_report_sha256': sha(work / 'packet_reduction_comparison.json'),
        'cases': 24, 'packets': 172032, 'scalar_reduction_comparisons': 576,
        'sampling_repeated': False,
        'limits': 'One manufactured source interval; eight seed streams shared across budgets. No physical confidence or spectral inference.'}
    status['active_completed_subtasks'] = [completed]
    status['active_phase'] = 'Packet comparison completed; constant-barrier subwindow reference and late-tail qualification'
    status['last_update_utc'] = now
    for i, item in enumerate(status['next_work']):
        item['priority'] = i + 1
    temp = status_path.with_suffix('.tmp')
    temp.write_text(json.dumps(status, indent=2) + '\n')
    temp.replace(status_path)
    event = {'utc': now, 'event': 'subtask_completed_and_next_selected', 'pass_id': status['active_lease_owner'],
             'completed': completed, 'next_task': status['next_work'][0]['task'],
             'bounded_next_scope': 'Work-only manufactured constant-barrier high-precision source-window reference; nonlinear production interface remains unimplemented.'}
    with Path('/workspace/research_work/mitl-upstream-journal.jsonl').open('a') as stream:
        stream.write(json.dumps(event) + '\n')
print(json.dumps(event, indent=2))
