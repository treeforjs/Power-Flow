"""Manufactured weighted boundary-packet experiment; no transport or spectra.

The fixed seed/budget design is written before sampling and never selected by
its errors. Standard errors condition on actual component allocation and assume
externally independent uniform draws across packets and all seven columns.
Finite-seed errors and finite probability-quadrature references are diagnostics,
not certified convergence or physical uncertainty bounds.
"""

from __future__ import annotations

import argparse
from dataclasses import asdict
import hashlib
import json
import math
from pathlib import Path
import platform
import sys
import time

import numpy as np
import scipy

REPOSITORY = Path("/workspace/Power-Flow")
sys.path.insert(0, str(REPOSITORY))
from mhdlab.constants import KB
from mhdlab.emission_time_moments import conditional_time_moments, QUADRATURE_IDENTITY
from mhdlab.temkin_emission_time import FrozenTemkinEmission
from mhdlab.temkin_planar_boundary import sample_temkin_planar_emission_packets
from mhdlab.temkin_planar_io import load_temkin_planar_release_history

SCHEMA = "mhdlab-weighted-source-packet-verification-v1"
PACKET_SCHEMA = "mhdlab-weighted-source-packet-evidence-v1"
SOURCE = Path("/workspace/research_work/mitl-upstream-20261018T1947/joint-source-q8/source_input.h5")
REFERENCE = SOURCE.parent.parent / "joint-source-q32/report.json"
MASS_CONFIG = REPOSITORY / "configs/manufactured_boundary_masses.json"
SEEDS = [1729, 2718, 3141, 5772, 8111, 104729, 130363, 155921]
BUDGETS = [1024, 4096, 16384]
INTERVAL = 6
ORDER = 32
EPS = np.finfo(float).eps
LD = np.longdouble


def file_hash(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def array_hash(array):
    # Hash includes the actual dtype (including Unicode width), shape and bytes.
    value = np.asarray(array)
    digest = hashlib.sha256()
    digest.update(value.dtype.str.encode("ascii"))
    digest.update(json.dumps(list(value.shape), separators=(",", ":")).encode("ascii"))
    digest.update(np.ascontiguousarray(value).tobytes())
    return digest.hexdigest()


def dump(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


def check(condition, message):
    if not condition:
        raise AssertionError(message)


def close(actual, expected, *, scale=None, multiplier=256., message="mismatch"):
    actual, expected = np.asarray(actual, dtype=LD), np.asarray(expected, dtype=LD)
    if scale is None:
        scale = np.maximum(np.abs(actual), np.abs(expected))
    bound = multiplier * EPS * np.asarray(scale, dtype=LD)
    check(bool(np.all(np.abs(actual - expected) <= bound)),
          f"{message}: max absolute difference {float(np.max(np.abs(actual-expected)))}")


def weighted_mean(values, weights):
    values, weights = np.asarray(values, dtype=LD), np.asarray(weights, dtype=LD)
    return np.sum(weights * values, dtype=LD) / np.sum(weights, dtype=LD)


def covariance(a, b, weights):
    a, b, weights = np.asarray(a, dtype=LD), np.asarray(b, dtype=LD), np.asarray(weights, dtype=LD)
    return weighted_mean((a - weighted_mean(a, weights)) * (b - weighted_mean(b, weights)), weights)


def _float(value):
    result = float(value)
    check(math.isfinite(result), "nonfinite reduction")
    return result


def metrics(arrays, t0, face_center):
    weights = arrays["particle_weight"]
    velocity = np.asarray(arrays["velocity_m_s"], dtype=LD)
    energy = LD(.5) * np.asarray(arrays["mass_kg"], dtype=LD) * np.sum(velocity * velocity, axis=1, dtype=LD)
    expected = LD(2) * LD(KB) * np.asarray(arrays["temperature_k"], dtype=LD)
    offset = arrays["time_offset_s"]
    z = arrays["resolved_position_m"][:, 2]
    mean_k = weighted_mean(energy, weights)
    shared = {
        "released_number": _float(np.sum(weights, dtype=LD)),
        "mean_actual_kinetic_energy_j": _float(mean_k),
        "raw_second_actual_kinetic_energy_j2": _float(weighted_mean(energy * energy, weights)),
        "plugin_variance_actual_kinetic_energy_j2": _float(covariance(energy, energy, weights)),
        "mean_expected_translational_energy_j": _float(weighted_mean(expected, weights)),
        "variance_expected_translational_energy_j2": _float(covariance(expected, expected, weights)),
        "mean_time_offset_s": _float(weighted_mean(offset, weights)),
        "mean_time_s": _float(LD(t0) + weighted_mean(offset, weights)),
        "variance_time_s2": _float(covariance(offset, offset, weights)),
        "mean_z_m": _float(weighted_mean(z, weights)),
        "cov_time_z_s_m": _float(covariance(offset, z, weights)),
        "cov_time_actual_kinetic_energy_s_j": _float(covariance(offset, energy, weights)),
        "cov_time_expected_translational_energy_s_j": _float(covariance(offset, expected, weights)),
        "actual_total_translational_energy_j": _float(np.sum(np.asarray(weights, dtype=LD)*energy, dtype=LD)),
        "expected_total_translational_energy_j": _float(np.sum(np.asarray(weights, dtype=LD)*expected, dtype=LD)),
    }
    result = {"shared": shared}
    for name, key in (("resolved", "resolved_position_m"), ("uniform_width", "uniform_width_position_m")):
        x = np.asarray(arrays[key][:, 0], dtype=LD)
        square = (x - LD(face_center))**2
        result[name] = {
            "mean_x_m": _float(weighted_mean(x, weights)),
            "mean_width_centered_square_m2": _float(weighted_mean(square, weights)),
            "variance_width_centered_square_m4": _float(covariance(square, square, weights)),
            "cov_time_x_s_m": _float(covariance(offset, x, weights)),
            "cov_time_width_centered_square_s_m2": _float(covariance(offset, square, weights)),
            "cov_expected_translational_energy_width_centered_square_j_m2": _float(covariance(expected, square, weights)),
            "cov_actual_kinetic_energy_width_centered_square_j_m2": _float(covariance(energy, square, weights)),
        }
    return result, np.asarray(energy)


def source_reference(history, report):
    selected = report["joint_moments"]["reservoirs"]
    check(len(selected) == len(history.reservoirs) == 1, "this bounded experiment requires its one manufactured pool")
    pool = history.reservoirs[0]
    check(pool.state_id == "M:manufactured-ground", "unexpected source state")
    ref = selected[0]["conditional_interval"][INTERVAL]
    check(ref["interval_index"] == INTERVAL, "reference interval mismatch")
    t0, t1 = (float(v) for v in history.time_edges_s[INTERVAL:INTERVAL+2])
    close([t0, t1], [ref["time_start_s"], ref["time_stop_s"]], message="reference time edges")
    components = []
    for z in range(len(history.z_edges_m)-1):
        for x in range(len(history.x_edges_m)-1):
            density = float(history.released_m2[INTERVAL, 0, z, x])
            if density == 0:
                continue
            dx = float(history.x_edges_m[x+1]-history.x_edges_m[x])
            dz = float(history.z_edges_m[z+1]-history.z_edges_m[z])
            population = density * dx * dz
            temperature = float(history.temperature_k[INTERVAL, z, x])
            theta = KB * temperature
            emission = FrozenTemkinEmission(pool, float(history.coverage_m2[INTERVAL, 0, z, x]), temperature, t1-t0)
            moments = conditional_time_moments(emission, quadrature_order=ORDER)
            check(not any((moments.mean_underflowed, moments.second_raw_moment_underflowed, moments.variance_underflowed)),
                  "manufactured reference unexpectedly underflows timing")
            components.append({
                "reservoir_index": 0, "current_index": z, "width_index": x,
                "released_particles": population, "temperature_k": temperature,
                "theta_j": theta, "mean_expected_translational_energy_j": 2*theta,
                "variance_actual_kinetic_energy_j2": 2*theta**2,
                "raw_second_actual_kinetic_energy_j2": 6*theta**2,
                "variance_squared_actual_kinetic_energy_j4": 84*theta**4,
                "expected_translational_energy_j": float(history.translational_energy_j_m2[INTERVAL, 0, z, x])*dx*dz,
                "x_left_m": float(history.x_edges_m[x]), "x_right_m": float(history.x_edges_m[x+1]),
                "z_left_m": float(history.z_edges_m[z]), "z_right_m": float(history.z_edges_m[z+1]),
                "time_moments": asdict(moments),
            })
    populations = np.array([c["released_particles"] for c in components], dtype=LD)
    probabilities = populations / np.sum(populations, dtype=LD)
    expected = np.array([c["mean_expected_translational_energy_j"] for c in components], dtype=LD)
    time_mean = np.array([c["time_moments"]["mean_offset_s"] for c in components], dtype=LD)
    between = covariance(expected, expected, populations)
    within = weighted_mean([c["variance_actual_kinetic_energy_j2"] for c in components], populations)
    raw_second = weighted_mean([c["raw_second_actual_kinetic_energy_j2"] for c in components], populations)
    close(np.sum(populations, dtype=LD), ref["resolved"]["released_number"], message="source populations")
    close(weighted_mean(expected, populations), ref["resolved"]["mean_expected_translational_energy_j"], message="source 2kBT mean")
    close(between, ref["resolved"]["variance_expected_translational_energy_j2"], message="source between-component variance")
    close(LD(t0)+weighted_mean(time_mean, populations), ref["resolved"]["mean_time_s"], message="conditional time mean")
    close(covariance(time_mean, expected, populations), ref["resolved"]["cov_time_expected_translational_energy_s_j"], message="conditional time/energy covariance")
    for c, probability in zip(components, probabilities):
        c["probability"] = _float(probability)
        close(c["expected_translational_energy_j"], c["released_particles"]*c["mean_expected_translational_energy_j"], message="source expected-energy ledger")
    common = {
        "released_number": _float(np.sum(populations, dtype=LD)),
        "mean_actual_kinetic_energy_j": _float(weighted_mean(expected, populations)),
        "raw_second_actual_kinetic_energy_j2": _float(raw_second),
        "plugin_variance_actual_kinetic_energy_j2": _float(between+within),
        "corrected_variance_actual_kinetic_energy_j2": _float(between+within),
        "mean_expected_translational_energy_j": ref["resolved"]["mean_expected_translational_energy_j"],
        "variance_expected_translational_energy_j2": ref["resolved"]["variance_expected_translational_energy_j2"],
        "mean_time_offset_s": _float(weighted_mean(time_mean, populations)),
        "mean_time_s": ref["resolved"]["mean_time_s"],
        "variance_time_s2": ref["resolved"]["variance_time_s2"],
        "mean_z_m": ref["resolved"]["mean_z_m"],
        "cov_time_z_s_m": ref["resolved"]["cov_time_z_s_m"],
        "cov_time_actual_kinetic_energy_s_j": ref["resolved"]["cov_time_expected_translational_energy_s_j"],
        "cov_time_expected_translational_energy_s_j": ref["resolved"]["cov_time_expected_translational_energy_s_j"],
        "expected_total_translational_energy_j": _float(np.sum(populations*expected, dtype=LD)),
        "actual_total_translational_energy_j": _float(np.sum(populations*expected, dtype=LD)),
    }
    targets = {"shared": common}
    for hypothesis in ("resolved", "uniform_width"):
        targets[hypothesis] = {key: ref[hypothesis][key] for key in (
            "mean_x_m", "mean_width_centered_square_m2", "variance_width_centered_square_m4",
            "cov_time_x_s_m", "cov_time_width_centered_square_s_m2",
            "cov_expected_translational_energy_width_centered_square_j_m2")}
        targets[hypothesis]["cov_actual_kinetic_energy_width_centered_square_j_m2"] = ref[hypothesis]["cov_expected_translational_energy_width_centered_square_j_m2"]
    return components, targets, {
        "interval_index": INTERVAL, "time_start_s": t0, "time_stop_s": t1,
        "width_center_m": float((history.x_edges_m[0]+history.x_edges_m[-1])/2),
        "between_conditional_mean_energy_variance_j2": _float(between),
        "mean_within_component_kinetic_energy_variance_j2": _float(within),
        "total_kinetic_energy_variance_j2": _float(between+within),
        "raw_second_kinetic_energy_j2": _float(raw_second),
        "targets": targets,
        "finite_quadrature_order": ORDER, "quadrature_identity": QUADRATURE_IDENTITY,
        "reference_interpretation": "deterministic finite-order time quadrature; not a certified error bound",
        "all_positive_components": len(components),
        "temperature_min_k": min(c["temperature_k"] for c in components),
        "temperature_max_k": max(c["temperature_k"] for c in components),
    }


SAVE_FIELDS = (
    "particle_weight", "time_offset_s", "time_s", "source_current_offset_m",
    "resolved_position_m", "uniform_width_position_m", "temperature_k", "mass_kg",
    "velocity_m_s", "momentum_kg_m_s", "reservoir_index", "source_current_index", "source_width_index",
    "component_reservoir_index", "component_current_index", "component_width_index",
    "component_released_particles", "packet_counts", "component_expected_translational_energy_j",
    "component_sampled_translational_energy_j", "component_translational_energy_sampling_residual_j",
    "x_edges_m", "z_edges_m",
)


def inspect_case(arrays, components, targets, source_info, mass_map):
    ids = list(zip(arrays["component_reservoir_index"].tolist(), arrays["component_current_index"].tolist(), arrays["component_width_index"].tolist()))
    expected_ids = [(c["reservoir_index"], c["current_index"], c["width_index"]) for c in components]
    check(ids == expected_ids, "component ordering differs from source")
    lookup = {key: index for index, key in enumerate(ids)}
    indices = np.array([lookup[tuple(key)] for key in zip(arrays["reservoir_index"], arrays["source_current_index"], arrays["source_width_index"])], dtype=np.int64)
    check(np.array_equal(indices, arrays["component_index"]), "saved packet component mapping")
    counts = np.bincount(indices, minlength=len(components))
    check(np.array_equal(counts, arrays["packet_counts"]), "component packet allocation")
    check(bool(np.all(counts > 0)), "missing positive source component")
    populations = np.array([c["released_particles"] for c in components], dtype=LD)
    close(arrays["component_released_particles"], populations, message="component actual-area inventories")
    measured = np.array([np.sum(np.asarray(arrays["particle_weight"])[indices==c], dtype=LD) for c in range(len(components))], dtype=LD)
    close(measured, populations, message="component weighted populations")
    for c in range(len(components)):
        mask = indices == c
        close(arrays["particle_weight"][mask], populations[c]/counts[c], message="constant component packet weights")
        close(arrays["temperature_k"][mask], components[c]["temperature_k"], message="local temperature retained")
    check(np.array_equal(arrays["resolved_position_m"][:, 1:], arrays["uniform_width_position_m"][:, 1:]), "pairing modifies y/z")
    check(bool(np.all(arrays["resolved_position_m"][:, 1] == arrays["face_normal_coordinate_m"])), "face normal coordinate")
    check(bool(np.all(arrays["mass_kg"] == np.array([mass_map[str(state)] for state in arrays["state_ids"]]))), "exact-state masses")
    close(arrays["momentum_kg_m_s"], arrays["mass_kg"][:, None]*arrays["velocity_m_s"], message="momentum replay")
    check(bool(np.all(arrays["velocity_m_s"][:, 1]*int(arrays["outward_normal_sign"]) > 0)), "outward flux velocity")
    check(bool(np.all(arrays["time_offset_s"] > 0)) and bool(np.all(arrays["time_offset_s"] < source_info["time_stop_s"]-source_info["time_start_s"])), "conditional open event times")
    close(arrays["time_s"], arrays["time_offset_s"]+source_info["time_start_s"], message="absolute time reconstruction")
    draws = arrays["uniforms"]
    check(draws.shape == (int(arrays["packet_budget"]), 7) and bool(np.all((draws>0)&(draws<1))), "saved open uniforms")
    xedges, zedges = arrays["x_edges_m"], arrays["z_edges_m"]
    xindex, zindex = arrays["source_width_index"], arrays["source_current_index"]
    close(arrays["resolved_position_m"][:, 0], xedges[xindex]+np.diff(xedges)[xindex]*draws[:, 2], scale=xedges[-1]-xedges[0], message="resolved coordinate draw replay")
    close(arrays["uniform_width_position_m"][:, 0], xedges[0]+(xedges[-1]-xedges[0])*draws[:, 2], scale=xedges[-1]-xedges[0], message="matched width draw replay")
    close(arrays["source_current_offset_m"], np.diff(zedges)[zindex]*draws[:, 6], message="current-offset draw replay")
    close(arrays["resolved_position_m"][:, 2], zedges[zindex]+arrays["source_current_offset_m"], message="current-coordinate replay")
    # Different elementary-library implementations can differ by a few ulps.
    sigma = np.exp(.5*(math.log(KB)+np.log(arrays["temperature_k"])-np.log(arrays["mass_kg"])))
    radius = sigma*np.sqrt(-2*np.log(draws[:, 4]))
    angle = 2*math.pi*draws[:, 5]
    velocity = np.column_stack((radius*np.cos(angle), int(arrays["outward_normal_sign"])*sigma*np.sqrt(-2*np.log1p(-draws[:, 3])), radius*np.sin(angle)))
    close(arrays["velocity_m_s"], velocity, scale=np.max(np.abs(velocity)), message="velocity uniform-column replay")
    theta_packet = LD(KB)*np.asarray(arrays["temperature_k"], dtype=LD)
    normal_energy = LD(.5)*np.asarray(arrays["mass_kg"], dtype=LD)*np.asarray(arrays["velocity_m_s"][:, 1], dtype=LD)**2
    tangent_energy = LD(.5)*np.asarray(arrays["mass_kg"], dtype=LD)*np.sum(np.asarray(arrays["velocity_m_s"][:, (0, 2)], dtype=LD)**2, axis=1, dtype=LD)
    close(normal_energy/theta_packet, -np.log1p(-draws[:, 3]), message="normal exponential energy draw")
    close(tangent_energy/theta_packet, -np.log(draws[:, 4]), message="tangential exponential energy draw")
    result, energy = metrics(arrays, source_info["time_start_s"], source_info["width_center_m"])
    expected_ledger = np.array([c["expected_translational_energy_j"] for c in components], dtype=LD)
    measured_ledger = np.array([np.sum(np.asarray(arrays["particle_weight"], dtype=LD)[indices==c]*energy[indices==c], dtype=LD) for c in range(len(components))], dtype=LD)
    close(arrays["component_expected_translational_energy_j"], expected_ledger, message="component expected ledger")
    close(arrays["component_sampled_translational_energy_j"], measured_ledger, message="component actual ledger")
    close(arrays["component_translational_energy_sampling_residual_j"], measured_ledger-expected_ledger, scale=expected_ledger, message="sampled/expected residual ledger")
    probabilities = populations/np.sum(populations, dtype=LD)
    theta = np.array([c["theta_j"] for c in components], dtype=LD)
    mean_variance = np.sum(probabilities**2*2*theta**2/counts, dtype=LD)
    second_variance = np.sum(probabilities**2*84*theta**4/counts, dtype=LD)
    result["shared"]["conditional_model_plugin_variance_bias_correction_j2"] = _float(mean_variance)
    result["shared"]["corrected_variance_actual_kinetic_energy_j2"] = result["shared"]["plugin_variance_actual_kinetic_energy_j2"]+_float(mean_variance)
    standard_errors = {
        "shared.mean_actual_kinetic_energy_j": _float(np.sqrt(mean_variance)),
        "shared.raw_second_actual_kinetic_energy_j2": _float(np.sqrt(second_variance)),
        "shared.mean_time_offset_s": _float(np.sqrt(np.sum(probabilities**2*np.array([c["time_moments"]["variance_offset_s2"] for c in components], dtype=LD)/counts, dtype=LD))),
    }
    # Optional data-based grouped estimate: not an identity or an IID-N_eff rule.
    plugin_available = bool(np.all(counts > 1))
    empirical = None
    if plugin_available:
        sample_variance = np.array([np.var(energy[indices==c], ddof=1, dtype=LD) for c in range(len(components))], dtype=LD)
        empirical = _float(np.sqrt(np.sum(probabilities**2*sample_variance/counts, dtype=LD)))
    deterministic = ("released_number", "mean_expected_translational_energy_j", "variance_expected_translational_energy_j2", "expected_total_translational_energy_j")
    for key in deterministic:
        close(result["shared"][key], targets["shared"][key], message="deterministic mixture preservation: "+key)
    errors = {}
    for section in ("shared", "resolved", "uniform_width"):
        for key, target in targets[section].items():
            value = result[section][key]
            path = section+"."+key
            error = value-target
            entry = {"sample": value, "finite_reference": target, "error": error}
            if path in standard_errors:
                entry["conditional_model_standard_error"] = standard_errors[path]
                entry["error_over_conditional_model_standard_error"] = error/standard_errors[path]
            errors[path] = entry
    # The unweighted statistic answers an allocation-dependent question.
    unweighted_expected = _float(np.mean(2*LD(KB)*np.asarray(arrays["temperature_k"], dtype=LD), dtype=LD))
    allocation_expected = _float(np.sum(np.asarray(counts, dtype=LD)*2*theta, dtype=LD)/np.sum(counts))
    close(unweighted_expected, allocation_expected, message="unweighted allocation interpretation")
    unweighted_actual = _float(np.mean(energy, dtype=LD))
    unweighted_se = _float(np.sqrt(np.sum(np.asarray(counts, dtype=LD)*2*theta**2, dtype=LD))/np.sum(counts))
    return {
        "metrics": result, "target_errors": errors,
        "analytic_standard_errors": standard_errors,
        "grouped_empirical_mean_kinetic_energy_standard_error_j": empirical,
        "grouped_empirical_standard_error_available": plugin_available,
        "grouped_empirical_standard_error_qualification": "sum Pc^2 sc^2/nc with unbiased within-component variance; unavailable if any nc=1; data estimate, not fixed identity",
        "component_checks": {"positive_components": len(components), "minimum_packet_count": int(np.min(counts)), "maximum_packet_count": int(np.max(counts)), "max_population_relative_residual": _float(np.max(np.abs(measured-populations)/populations)), "all_component_inventories_match": True, "counts": counts.tolist()},
        "pairing_checks": {"y_and_z_exactly_equal": True, "time_state_mass_temperature_velocity_momentum_weight_shared_by_construction": True, "uniform_column_replay_passed": True, "only_x_position_changes": True},
        "energy_accounting": {"actual_total_j": result["shared"]["actual_total_translational_energy_j"], "expected_total_j": result["shared"]["expected_total_translational_energy_j"], "actual_minus_expected_j": result["shared"]["actual_total_translational_energy_j"]-result["shared"]["expected_total_translational_energy_j"], "actual_component_sum_matches_saved_ledger": True, "velocity_rescaled_to_expected_budget": False},
        "negative_control": {"unweighted_mean_expected_translational_energy_j": unweighted_expected, "allocation_conditional_target_j": allocation_expected, "physical_number_weighted_target_j": targets["shared"]["mean_actual_kinetic_energy_j"], "unweighted_minus_physical_target_j": unweighted_expected-targets["shared"]["mean_actual_kinetic_energy_j"], "unweighted_mean_actual_kinetic_energy_j": unweighted_actual, "unweighted_actual_conditional_model_standard_error_j": unweighted_se, "unweighted_actual_minus_allocation_target_j": unweighted_actual-allocation_expected, "interpretation": "unweighted packet mean represents allocation fractions nc/n, not emitted particle fractions Pc"},
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    output = args.output.resolve()
    check(not output.exists(), "output must be fresh; previous evidence is preserved")
    output.mkdir(parents=True)
    (output/"packets").mkdir()
    mass_config = json.loads(MASS_CONFIG.read_text())
    check(mass_config["mass_status"] == "manufactured", "mass input status")
    masses = mass_config["state_masses_kg"]
    check(masses == {"M:manufactured-ground": 3e-26}, "unexpected exact-state mass")
    configuration = {
        "schema": SCHEMA, "parameter_status": "manufactured",
        "interval_index": INTERVAL, "seeds": SEEDS, "packet_budgets": BUDGETS,
        "quadrature_order": ORDER, "state_masses_kg": masses,
        "mass_status": mass_config["mass_status"], "mass_provenance": mass_config["mass_provenance"],
        "face_normal_coordinate_m": 0., "outward_normal_sign": mass_config["outward_normal_sign"],
        "rng": {"generator": "numpy.random.Generator", "bit_generator": "PCG64", "numpy_version": np.__version__, "draw_method": "default_rng(seed).random((packet_budget,7))", "endpoint_policy": "fail if any variate is not strictly open; no redraw, clipping or favorable retries", "statistical_assumption": "independent uniform variates across all packets and columns including allocation; pseudorandom finite-seed diagnostics conditional on allocation"},
        "design_status": "fixed before sampling; no seed/budget chosen by outcome",
        "area_accounting": "dx*dz once from actual planar source; no 1D extrusion-length parameter",
    }
    dump(output/"configuration.json", configuration)
    started = time.monotonic()
    source_sha = file_hash(SOURCE)
    ref_report = json.loads(REFERENCE.read_text())
    check(ref_report["parameter_status"] == "manufactured", "source reference status")
    check(source_sha == ref_report["input_source_sha256"] == ref_report["output_sha256"]["source_input.h5"], "q32 reference must hash-associate with exact saved source")
    history = load_temkin_planar_release_history(SOURCE)
    check(history.surface_attributes["thermal_input_status"] == "manufactured", "source thermal status")
    check(bool(np.ptp(history.temperature_k[INTERVAL], axis=1).min() > 0), "selected interval must vary across width")
    components, targets, source_info = source_reference(history, ref_report)
    cases = []
    for budget in BUDGETS:
        for seed in SEEDS:
            tcase = time.monotonic()
            uniforms = np.random.default_rng(seed).random((budget, 7))
            check(bool(np.all((uniforms>0)&(uniforms<1))), "nonopen PRNG variate; do not redraw")
            packets = sample_temkin_planar_emission_packets(history, masses, INTERVAL, uniforms, face_normal_coordinate_m=0., outward_normal_sign=configuration["outward_normal_sign"])
            arrays = {key: np.asarray(getattr(packets, key)) for key in SAVE_FIELDS}
            arrays.update(schema=np.array(PACKET_SCHEMA), seed=np.array(seed, dtype=np.int64), packet_budget=np.array(budget, dtype=np.int64), interval_index=np.array(INTERVAL, dtype=np.int64), face_normal_coordinate_m=np.array(0.), outward_normal_sign=np.array(configuration["outward_normal_sign"], dtype=np.int64), uniforms=uniforms, state_ids=np.array(packets.state_ids, dtype="U64"))
            lookup = {key: index for index, key in enumerate(zip(arrays["component_reservoir_index"], arrays["component_current_index"], arrays["component_width_index"]))}
            arrays["component_index"] = np.array([lookup[key] for key in zip(arrays["reservoir_index"], arrays["source_current_index"], arrays["source_width_index"])], dtype=np.int64)
            filename = f"packets/n{budget:06d}_seed{seed:06d}.npz"
            path = output/filename
            np.savez_compressed(path, **arrays)
            hashes = {key: array_hash(value) for key, value in arrays.items()}
            # All statistics are evaluated from the reopened evidence, not hidden sampler state.
            with np.load(path, allow_pickle=False) as saved:
                restored = {key: np.array(saved[key]) for key in saved.files}
            check(restored.keys() == arrays.keys(), "NPZ inventory changed")
            check(all(array_hash(restored[key]) == digest for key, digest in hashes.items()), "NPZ roundtrip array hash")
            case = inspect_case(restored, components, targets, source_info, masses)
            case.update(packet_budget=budget, seed=seed, elapsed_s=time.monotonic()-tcase,
                        artifact={"path": filename, "sha256": file_hash(path), "bytes": path.stat().st_size, "array_sha256": hashes, "array_shape": {key: list(value.shape) for key, value in arrays.items()}, "array_dtype": {key: value.dtype.str for key, value in arrays.items()}})
            cases.append(case)
            dump(output/"cases.partial.json", cases)
            print(json.dumps({"packet_budget": budget, "seed": seed, "seconds": case["elapsed_s"], "kinetic_mean_error_over_conditional_se": case["target_errors"]["shared.mean_actual_kinetic_energy_j"]["error_over_conditional_model_standard_error"]}), flush=True)
    ensemble = []
    for budget in BUDGETS:
        selected = [c for c in cases if c["packet_budget"] == budget]
        reduced = {}
        for key in selected[0]["target_errors"]:
            errors = np.array([c["target_errors"][key]["error"] for c in selected], dtype=LD)
            item = {"bias": _float(np.mean(errors, dtype=LD)), "rmse": _float(np.sqrt(np.mean(errors**2, dtype=LD))), "maximum_absolute_error": _float(np.max(np.abs(errors))), "seeds": len(selected)}
            if key in selected[0]["analytic_standard_errors"]:
                normalized = np.array([c["target_errors"][key]["error_over_conditional_model_standard_error"] for c in selected], dtype=LD)
                item["normalized_error_rmse"] = _float(np.sqrt(np.mean(normalized**2, dtype=LD)))
                variances = np.array([c["analytic_standard_errors"][key] for c in selected], dtype=LD)**2
                item["root_mean_conditional_model_variance"] = _float(np.sqrt(np.mean(variances, dtype=LD)))
            reduced[key] = item
        ensemble.append({"packet_budget": budget, "metrics": reduced})
    code_paths = sorted(set(ref_report["source_sha256"]) | {"mhdlab/temkin_planar_boundary.py", "mhdlab/temkin_boundary.py", "mhdlab/planar_boundary.py", "mhdlab/thermal_boundary.py"})
    code_hashes = {name: file_hash(REPOSITORY/name) for name in code_paths}
    # Code supplying the saved time reference must still match its frozen report.
    check(all(code_hashes[name] == digest for name, digest in ref_report["source_sha256"].items()), "reference code changed since frozen q32 report")
    report = {
        "schema": SCHEMA, "parameter_status": "manufactured", "configuration": configuration,
        "inputs": {"source": {"path": str(SOURCE), "sha256": source_sha}, "finite_reference_report": {"path": str(REFERENCE), "sha256": file_hash(REFERENCE)}, "mass_config": {"path": str(MASS_CONFIG), "sha256": file_hash(MASS_CONFIG)}, "verification_script": {"path": str(Path(__file__).resolve()), "sha256": file_hash(__file__)}, "public_code_sha256": code_hashes},
        "environment": {"python": platform.python_version(), "numpy": np.__version__, "scipy": scipy.__version__, "platform": platform.platform()},
        "source_reference": source_info, "component_reference": components,
        "cases": cases, "ensemble": ensemble,
        "verification": {"case_count": len(cases), "total_packets": sum(c["packet_budget"] for c in cases), "all_artifacts_reopened_and_array_hash_verified": True, "all_component_population_checks_passed": True, "all_pairing_and_draw_replay_checks_passed": True, "source_counts_and_2kBT_mixture_checks_passed": True, "all_actual_component_energy_ledgers_passed": True, "source_hash_matches_finite_reference": True, "public_code_matches_frozen_reference": True, "elapsed_s": time.monotonic()-started},
        "statistical_qualifications": {"conditional_allocation": "Nc and nc define Pc=Nc/sumNc; weights Nc/nc. Analytic variances condition on actual allocation, assuming independent open uniforms across all columns and packets.", "kinetic_model": "flux-weighted Maxwell launch K|component is Gamma(shape2,scale kBT): mean2kBT,var2(kBT)^2,E[K^2]=6(kBT)^2,Var(K^2)=84(kBT)^4", "mean_uncertainty": "Var(weighted meanK|allocation)=sum Pc^2*2theta_c^2/nc; Var(weighted rawsecondK|allocation)=sum Pc^2*84theta_c^4/nc", "variance_correction": "plugin weighted population variance is biased down in conditional expectation by Var(weighted meanK|allocation); corrected value adds exact model-based amount. No assertion that a realized plugin error equals this bias.", "covariances": "actual K/time and K/widthsquare conditional covariances vanish from independent draw columns; mixture covariances target the deterministic conditional-mean-energy source statistics", "finite_ensemble": "eight fixed seeds per budget; RMSE, bias and normalized errors descriptive; no certified rates, confidence claims, monotonic-every-seed rule or favorable retries"},
        "limits": ["Manufactured source, independent pool and exact-state mass only; no measured water, foil calibration or state catalog.", "No gap transport, collisions, reactions, radiation, fields or spectral prediction.", "Expected local2kBT diagnostics differ from sampled packet energy and from binding/internal/total wall cost.", "Time moments are finite order32 probability quadrature; source interval is an emission gate, not a recorded photon gate.", "Only one saved width-varying interval studied; no source discretization or physical-model convergence claim.", "No production resources or private implementation used."],
    }
    dump(output/"report.json", report)
    (output/"cases.partial.json").unlink()
    manifest = {str(path.relative_to(output)): {"sha256": file_hash(path), "bytes": path.stat().st_size} for path in sorted(output.rglob("*")) if path.is_file()}
    dump(output/"manifest.json", manifest)
    print(json.dumps({"status": "passed", "report_sha256": file_hash(output/"report.json"), "manifest_sha256": file_hash(output/"manifest.json"), **report["verification"]}, indent=2), flush=True)


if __name__ == "__main__":
    main()
