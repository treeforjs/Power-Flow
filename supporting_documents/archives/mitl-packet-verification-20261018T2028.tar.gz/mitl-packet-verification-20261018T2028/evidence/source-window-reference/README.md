# Constant-barrier source-window reference

This work-only witness uses 180-digit Decimal arithmetic for eleven explicit,
manufactured first-order constant-barrier cases (`c=0`). It does not implement
nonlinear Temkin gating or modify a public source interface. `reference.json`
contains exact-decimal input references and separate references formed from the
exact binary values of projected float64 inputs. This separation makes changed
or merged gate endpoints visible.

For a gate `[a,b]` within the original interval `[0,dt]`, the source fraction is
`exp(-k*a)*(1-exp(-k*(b-a)))`. Its logarithm and parent-conditional probability
are evaluated without subtracting CDF values. The reference uses Decimal
series/log1p evaluation; the float witness uses log/expm1 evaluation, normalized
integral series for small local hazard and log delay quantiles. The unstable
small-hazard difference `1/k - L/expm1(k*L)` is not used in the float witness.

The cases cover ordinary release, tiny early hazard, an underflowed fraction
with a representable released number, late endpoint CDFs both rounded to one,
a narrow late gate, merged float endpoints, two underflowed-number situations,
coarsely quantized subnormal delays, lost late-origin spread and tiny parent
normalization. A separate five-window partition checks the high-precision sum.
Its observed residual is zero at 180 digits; that is an arithmetic result,
not a certified error bound.

All comparisons of the float log formulas to their projected-input references
passed the declared absolute log-difference criterion of `3e-12`. Ten inputs
define a float domain; the eleventh gate exists in the decimal specification
but its float endpoints merge and is explicitly rejected. Positive source
numbers below float range retain their finite logarithms and are not eligible
for a direct float count budget. The positive represented numbers in this
small witness are normal float64 values; this does not qualify arbitrary
positive subnormal budgets. Count representability is only a numerical
condition, not live-host thermodynamic or transaction acceptance.

Delay moments and log moments are the primary timing representation. The
artifact also records when adding the parent-relative start offset erases
quantile spread, when logs of those sums collapse, and when subtracting raw
parent-time moments loses the variance. Subnormal delay quantiles are marked
unqualified if their actual time quantization exceeds the stated log tolerance;
their log-delay estimates remain available.

The recorded invocation used `python -W error` and exited zero. Every asserted
case passed on the first execution; no earlier source integration or passing
suite was repeated. Exact command, times, exit and combined log hash are in the
parent work directory's `commands.jsonl`. The script refuses optimized Python
execution because its assertions are part of the witness.

These are source emission-time windows. A diagnostic photon gate instead
restricts detection times after transport and excitation; it does not authorize
discarding neutral launches before that gate. No molecular identities,
collisions, spectra, EOS, live host, Quark resource or production gate is tested.
