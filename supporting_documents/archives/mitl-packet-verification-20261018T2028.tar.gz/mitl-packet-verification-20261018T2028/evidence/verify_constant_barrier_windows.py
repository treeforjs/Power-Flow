"""Bounded manufactured constant-barrier source-window oracle; no Temkin gate.

Decimal source inputs and their separate float64 projections are explicit.
No source integration, particles, chemistry, EOS or host transaction is run.
"""

import argparse
from decimal import Decimal as D, localcontext
import hashlib
import json
import math
from pathlib import Path

PRECISION = 180
PROBABILITIES = ("0.1", "0.5", "0.9")
CASES = (
    ("ordinary", "2", ".1", ".7", "1", "1e18"),
    ("tiny_hazard_early", "1e-12", "0", "1e-9", "1", "1e18"),
    ("fraction_below_float_count_representable", "1e-200", "0", "1e-200", "1", "1e300"),
    ("late_both_float_cdfs_one", "1", "100", "101", "200", "1e18"),
    ("narrow_late", "1", "50", "50.00000000000001", "100", "1e18"),
    ("gate_endpoints_merge_in_float", "1e-12", "1e12", "1000000000000.000001", "1000000000001", "1e18"),
    ("released_number_below_float", "1", "1000", "1001", "2000", "1e18"),
    ("tiny_initial_number_late", "1", "100", "101", "200", "1e-300"),
    ("subnormal_delay_resolution", "1e308", "0", "1e-320", "1e-319", "1e18"),
    ("late_origin_erases_delay_spread", "1e-12", "1e12", "1000000000000.0003", "1000000000001", "1e18"),
    ("tiny_parent_normalization", "1e-200", "0", "1e-200", "1e-100", "1e300"),
)


def dlog1p(z):
    if abs(z) >= D('.1'):
        return (1 + z).ln()
    term, total, j = z, z, 1
    while term:
        j += 1
        term *= -z * D(j - 1) / D(j)
        total += term
        if abs(term) <= abs(total) * D(10) ** (-PRECISION - 3):
            return total
        if j > 2000:
            raise ArithmeticError('Decimal log1p series did not converge')
    return total


def integral_series(x, power):
    term, total, j = D(1), D(1) / D(power + 1), 0
    while True:
        j += 1
        term *= -x / D(j)
        addition = term / D(power + j + 1)
        total += addition
        if abs(addition) <= abs(total) * D(10) ** (-PRECISION - 3):
            return total
        if j > 2000:
            raise ArithmeticError('Decimal normalized integral series did not converge')


def dphi(x):
    return x * integral_series(x, 0) if x <= 1 else 1 - (-x).exp()


def dlogphi(x):
    return dphi(x).ln() if x <= 1 else dlog1p(-(-x).exp())


def oracle(k, a, b, duration, initial):
    assert k > 0 and initial > 0 and 0 <= a < b <= duration
    h, x = b - a, k * (b - a)
    log_fraction = -k * a + dlogphi(x)
    log_probability = log_fraction - dlogphi(k * duration)
    if x <= 1:
        i0, i1, i2 = (integral_series(x, n) for n in (0, 1, 2))
        mean, second = h * i1 / i0, h * h * i2 / i0
    else:
        ratio = (-x).exp() / dphi(x)
        mean = 1 / k - h * ratio
        second = 2 / k**2 - ratio * (h**2 + 2 * h / k)
    variance = second - mean**2
    assert 0 < mean < h and variance > 0 and log_probability <= 0
    q = dphi(x)
    delays = [-dlog1p(-D(u) * q) / k for u in PROBABILITIES]
    return dict(log_source_fraction=log_fraction, log_parent_conditional_probability=log_probability,
                log_released_number=initial.ln() + log_fraction,
                released_number=initial * log_fraction.exp(), mean_delay_s=mean,
                second_delay_moment_s2=second, variance_delay_s2=variance,
                log_mean_delay_s=mean.ln(), log_variance_delay_s2=variance.ln(),
                delay_quantiles_s=delays, log_delay_quantiles_s=[v.ln() for v in delays],
                original_offset_quantiles_s=[a + v for v in delays])


def fl_logphi(log_x):
    if log_x < -18:
        x = math.exp(log_x)
        return log_x + math.log1p(-x / 2 + x*x / 6 - x*x*x / 24)
    x = math.exp(log_x)
    return math.log(-math.expm1(-x))


def fl_integral(x, power):
    term, terms = 1., [1. / (power + 1)]
    for j in range(1, 100):
        term *= -x / j
        addition = term / (power + j + 1)
        terms.append(addition)
        if abs(addition) < 1e-18:
            return math.fsum(terms)
    raise ArithmeticError('float normalized integral did not converge')


def fl_delay_log(log_q, log_k, u):
    log_y = math.log(u) + log_q
    if log_y < -18:
        y = math.exp(log_y)
        return log_y + math.log1p(y / 2 + y*y / 3 + y*y*y / 4) - log_k
    return math.log(-math.log1p(-math.exp(log_y))) - log_k


def strings(value):
    if isinstance(value, D):
        return str(value)
    if isinstance(value, dict):
        return {key: strings(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [strings(item) for item in value]
    return value


def float_witness(inputs):
    k, a, b, duration, initial = map(float, inputs)
    if not (all(math.isfinite(v) for v in (k, a, b, duration, initial))
            and k > 0 and initial > 0 and 0 <= a < b <= duration):
        return dict(qualified=False, reason='projected float64 budget/domain endpoints do not define the requested positive window')
    # Compare the float formula against EXACT values of its projected inputs.
    reference = oracle(*(D.from_float(v) for v in (k, a, b, duration, initial)))
    h, log_k = b-a, math.log(k)
    log_x = log_k + math.log(h)
    log_q = fl_logphi(log_x)
    log_fraction = -k*a + log_q
    log_probability = log_fraction - fl_logphi(log_k + math.log(duration))
    log_number = math.log(initial) + log_fraction
    x = math.exp(log_x)
    if x <= 1:
        i0, i1, i2 = (fl_integral(x, n) for n in (0, 1, 2))
        mean_scaled, variance_scaled = i1/i0, i2/i0 - (i1/i0)**2
    else:
        q = -math.expm1(-x)
        ratio = math.exp(-x)/q
        mean_scaled, variance_scaled = 1/x-ratio, 1/x**2-math.exp(-x)/q**2
    log_mean = math.log(h) + math.log(mean_scaled)
    log_variance = 2*math.log(h) + math.log(variance_scaled)
    log_delays = [fl_delay_log(log_q, log_k, float(u)) for u in PROBABILITIES]
    estimates = dict(log_source_fraction=log_fraction, log_parent_conditional_probability=log_probability,
                     log_released_number=log_number, log_mean_delay_s=log_mean, log_variance_delay_s2=log_variance)
    errors = {key: abs(value-float(reference[key])) for key,value in estimates.items()}
    errors['log_delay_quantiles_s'] = max(abs(value-float(expected)) for value,expected in zip(log_delays,reference['log_delay_quantiles_s']))
    assert max(errors.values()) < 3e-12, errors
    delays = [math.exp(v) for v in log_delays]
    delay_errors = [abs(math.log(t)-log_t) if t > 0 else None for t,log_t in zip(delays,log_delays)]
    parent_times = [a+t for t in delays]
    parent_logs = [math.log(t) if t > 0 else None for t in parent_times]
    number, mean, variance = math.exp(log_number), math.exp(log_mean), math.exp(log_variance)
    cdfs = [-math.expm1(-k*t) for t in (a,b)]  # diagnostic only, never a mass calculation
    cdf_difference = cdfs[1]-cdfs[0]
    return dict(qualified=True, input_projection='reference uses exact Decimal.from_float of each float64 input',
                projected_inputs_hex=[v.hex() for v in (k,a,b,duration,initial)],
                float_estimates=estimates, absolute_log_errors=errors,
                released_number=number, positive_number_underflowed=number==0,
                budget_use_qualified=number>0 and math.isfinite(number),
                budget_use_limit='Positive representable count required for direct float64 packet budgets; log-only amounts remain diagnostic',
                fraction_underflowed=math.exp(log_fraction)==0,
                mean_delay_s=mean, variance_delay_s2=variance,
                variance_underflowed=variance==0, delay_quantiles_s=delays,
                log_delay_quantiles_s=log_delays, delay_quantization_log_errors=delay_errors,
                linear_delay_quantiles_qualified=all(error is not None and error<=1.6e-10 for error in delay_errors),
                original_offset_quantiles_s=parent_times,
                original_offset_quantiles_collapse=len(set(parent_times))<len(parent_times),
                original_log_offset_quantiles_collapse=len(set(parent_logs))<len(parent_logs),
                naive_raw_parent_variance=(a*a+2*a*mean+variance+mean*mean)-(a+mean)**2,
                endpoint_float_cdfs=cdfs, endpoint_float_cdfs_both_one=cdfs==[1.,1.],
                naive_cdf_difference_diagnostic=cdf_difference,
                high_precision_projected_input_reference=strings(reference))


def partition_reference():
    k, duration, initial = D('.5'), D(10), D('1e18')
    edges = list(map(D, ('0','1e-12','.5','5','9.999999999','10')))
    amounts = [oracle(k,a,b,duration,initial)['released_number'] for a,b in zip(edges,edges[1:])]
    full = initial*dphi(k*duration)
    residual = sum(amounts,D(0))-full
    relative = abs(residual)/full
    assert relative < D('1e-160')
    return strings(dict(rate_s_inv=k,duration_s=duration,initial_number=initial,edges_s=edges,
                        released_numbers=amounts,full_released_number=full,
                        sum_minus_full=residual,relative_partition_residual=relative,
                        interpretation='High-precision arithmetic residual; not a certified physical or numerical error bound'))


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir',required=True,type=Path)
    args=parser.parse_args()
    if not __debug__:
        raise RuntimeError('Run without -O: oracle assertions must be enabled')
    args.output_dir.mkdir(parents=False,exist_ok=False)
    with localcontext() as context:
        context.prec=PRECISION
        cases=[]
        for label,*values in CASES:
            inputs=list(map(D,values))
            cases.append(dict(label=label,parameter_status='manufactured',
                              source_law='constant barrier first order, c=0; k explicitly supplied',
                              input_columns=['rate_s_inv','start_s','stop_s','parent_duration_s','initial_number'],
                              decimal_inputs=values,decimal_reference=strings(oracle(*inputs)),
                              float_witness=float_witness(inputs)))
        by_label={case['label']:case for case in cases}
        assert by_label['late_both_float_cdfs_one']['float_witness']['endpoint_float_cdfs_both_one']
        assert by_label['released_number_below_float']['float_witness']['positive_number_underflowed']
        assert not by_label['gate_endpoints_merge_in_float']['float_witness']['qualified']
        assert not by_label['subnormal_delay_resolution']['float_witness']['linear_delay_quantiles_qualified']
        assert by_label['late_origin_erases_delay_spread']['float_witness']['original_log_offset_quantiles_collapse']
        partition=partition_reference()
    script=Path(__file__)
    result=dict(schema='constant-barrier-source-window-reference-v1',decimal_precision_digits=PRECISION,
                script_sha256=hashlib.sha256(script.read_bytes()).hexdigest(),
                methods=dict(log_source_fraction='-k*a + log(1-exp(-k*(b-a))) using Decimal series/log1p and float log/expm1 forms',
                             parent_probability='source-window fraction divided by original [0,parent_duration] released fraction in logarithms',
                             moments='Decimal normalized integral series at small kL; analytic truncated-exponential expressions otherwise',
                             quantiles='gate-local delay -log1p(-u*(1-exp(-kL)))/k, retaining log delay',
                             float_tiny_hazard='normalized integral series or bounded leading uniform limit when x underflows; no 1/k-minus-nearly-equal-quantity'),
                quantity='particle number, no state mass or molecular assignment',
                semantics='Source emission-time windows, not diagnostic photon gates; no earlier source population may be discarded solely by a later photon gate',
                unsupported=['nonlinear coverage-dependent Temkin gating','production source-window interface','EOS or live-host budget acceptance','transport, photon arrival times, collisions and chemistry'],
                comparison_qualification='Float formulas are compared to Decimal references of exactly projected binary inputs; projected endpoint failure is an explicit unsupported float domain',
                all_assertions_passed=True,cases=cases,partition=partition)
    out=args.output_dir/'reference.json'
    out.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    json.loads(out.read_text())
    print(json.dumps(dict(output=str(out),output_sha256=hashlib.sha256(out.read_bytes()).hexdigest(),
                         script_sha256=result['script_sha256'],cases=len(cases),
                         qualified_float_domains=sum(case['float_witness']['qualified'] for case in cases),
                         all_assertions_passed=True,partition_relative_residual=partition['relative_partition_residual']),indent=2))


if __name__=='__main__':
    main()
