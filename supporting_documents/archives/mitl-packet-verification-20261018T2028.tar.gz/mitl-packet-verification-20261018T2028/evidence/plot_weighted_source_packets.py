"""Plot already verified manufactured launch samples; do not resample."""
import argparse
import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).parent
EV_J = 1.602176634e-19
KB = 1.380649e-23
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--packet-dir', type=Path, required=True)
parser.add_argument('--readback', type=Path, default=ROOT / 'packet_readback.json')
parser.add_argument('--output-dir', type=Path, default=ROOT / 'packet-figures')
args = parser.parse_args()
assert not args.output_dir.exists()
readback = json.loads(args.readback.read_text())
assert readback['case_count'] == 24 and readback['parameter_status'] == 'manufactured'
cases = readback['cases']
budgets = sorted(set(case['packets'] for case in cases))
# Fixed display choice: largest budget and lowest seed, selected without errors.
display = min((case for case in cases if case['packets'] == max(budgets)), key=lambda case: case['seed'])
sample_path = args.packet_dir / display['artifact']
assert sha(sample_path) == display['sha256']
with np.load(sample_path, allow_pickle=False) as loaded:
    a = {name: loaded[name] for name in loaded.files}
kinetic_ev = a['mass_kg'] * np.einsum('ij,ij->i', a['velocity_m_s'], a['velocity_m_s']) / (2 * EV_J)
weights = a['particle_weight'] / np.sum(a['particle_weight'])
numbers = a['component_released_particles']
fractions = numbers / np.sum(numbers)
theta_ev = []
for p, j, k in zip(a['component_reservoir_index'], a['component_current_index'], a['component_width_index']):
    selection = (a['reservoir_index'] == p) & (a['source_current_index'] == j) & (a['source_width_index'] == k)
    theta_ev.append(KB * a['temperature_k'][selection][0] / EV_J)
theta_ev = np.asarray(theta_ev)
grid = np.linspace(0, 12 * max(theta_ev), 600)
pdf = np.sum(fractions[:, None] * grid[None, :] / theta_ev[:, None] ** 2 * np.exp(-grid[None, :] / theta_ev[:, None]), axis=0)
edges = np.linspace(0, grid[-1], 65)
hist, _ = np.histogram(kinetic_ev, bins=edges, weights=weights)
fig, axes = plt.subplots(2, 2, figsize=(11.5, 8), constrained_layout=True)
ax = axes[0, 0]
ax.stairs(hist / np.diff(edges), edges, label=f"Weighted sample ({display['packets']:,} packets)")
ax.plot(grid, pdf, label='Supplied thermal mixture', color='black', linewidth=1.4)
ax.set(xlabel='Outgoing translational energy [eV]', ylabel='Particle probability density [eV⁻¹]', title='One fixed realization; no gap evolution')
ax.legend(fontsize=8)
ax = axes[0, 1]
scale = display['expected_total_energy_variance_j2']
components = np.asarray([display['expected_conditional_mean_energy_variance_j2'],
                         display['expected_within_component_energy_variance_j2']]) / scale
ax.barh(['Variation of local means', 'Thermal spread within components'], components, color=['tab:blue', 'tab:orange'])
ax.set(xlabel='Fraction of total population kinetic variance', xlim=(0, 1.05), title='Both terms enter the kinetic variance')
for index, value in enumerate(components):
    if value > .5:
        ax.text(value - .025, index, f'{100 * value:.2f}%', va='center', ha='right', color='white', fontsize=9)
    else:
        ax.text(value + .015, index, f'{100 * value:.2f}%', va='center', fontsize=9)
ensemble = []
for budget in budgets:
    selected = [case for case in cases if case['packets'] == budget]
    assert len(selected) == 8
    record = {'packet_budget': budget, 'seeds': [case['seed'] for case in selected]}
    for prefix, measured, expected, se in [
        ('mean_energy', 'sampled_mean_energy_j', 'expected_mean_energy_j', 'mean_energy_conditional_standard_error_j'),
        ('raw_second_energy', 'sampled_raw_second_energy_j2', 'expected_raw_second_energy_j2', 'raw_second_energy_conditional_standard_error_j2'),
    ]:
        error = np.asarray([case[measured] - case[expected] for case in selected])
        standard_error = np.asarray([case[se] for case in selected])
        record[prefix + '_bias'] = float(np.mean(error))
        record[prefix + '_rmse'] = float(np.sqrt(np.mean(error ** 2)))
        record[prefix + '_root_mean_conditional_variance'] = float(np.sqrt(np.mean(standard_error ** 2)))
    ensemble.append(record)
for ax, prefix, unit, label in [
    (axes[1, 0], 'mean_energy', EV_J, 'Mean energy error [eV]'),
    (axes[1, 1], 'raw_second_energy', EV_J ** 2, 'Raw second energy moment error [eV²]'),
]:
    ax.loglog(budgets, [row[prefix + '_rmse'] / unit for row in ensemble], 'o-', label='Finite ensemble RMSE (8 seeds)')
    ax.loglog(budgets, [row[prefix + '_root_mean_conditional_variance'] / unit for row in ensemble], 's--', label='Root mean conditional sampling variance')
    ax.set(xlabel='Packets per original interval', ylabel=label)
    ax.grid(alpha=.25)
    ax.legend(fontsize=8)
fig.suptitle('Manufactured thermal-source packet verification', fontsize=15)
args.output_dir.mkdir()
figure = args.output_dir / 'weighted_source_packets.png'
fig.savefig(figure, dpi=170)
plt.close(fig)
result = {
    'schema': 'mhdlab-weighted-source-packet-figure-v1', 'parameter_status': 'manufactured',
    'source_readback_sha256': sha(args.readback), 'script_sha256': sha(__file__),
    'display_artifact': {'name': sample_path.name, 'sha256': sha(sample_path), 'choice': 'Largest budget, lowest fixed seed; no error-dependent selection.'},
    'probability_above_display_range': float(np.sum(weights[kinetic_ev > edges[-1]])),
    'variance_fractions': {'local_mean_mixture': float(components[0]), 'within_component_thermal': float(components[1])},
    'ensemble': ensemble,
    'output_sha256': {figure.name: sha(figure)},
    'limits': ['Finite ensemble RMSE is not a certified convergence rate or physical uncertainty.',
               'Analytic conditional sampling variance assumes supplied independent uniform variates.',
               'The displayed histogram uses physical weights without renormalizing to the display range.',
               'No experimental spectrum, actual foil material or calibrated water release is represented.'],
}
report_path = args.output_dir / 'report.json'
report_path.write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
print(json.dumps({'figure': str(figure), 'figure_sha256': sha(figure), 'report_sha256': sha(report_path), 'variance_fractions': result['variance_fractions']}, indent=2))
