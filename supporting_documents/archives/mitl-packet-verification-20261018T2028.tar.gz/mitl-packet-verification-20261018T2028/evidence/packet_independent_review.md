# Independent weighted-packet evidence review

The saved study contains 24 manufactured cases and 172,032 launches. The source
HDF5 was reused at SHA256
`1bb3a617adb2f740889636cbbac19265f41a43974a10741f76b690b277ea9723`;
the existing source was not reintegrated. Source interval 6 and the exact three
budgets/eight seeds are required by the independent readback, alongside the
producer's source/reference/configuration/code and artifact associations.

The readback independently derives positive component sets, areal-release times
physical patch-area counts, equal within-component particle weights, total
counts and expected thermal mixtures. It reconstructs actual kinetic energy
from saved velocities and separately from the supplied uniform transforms.
Every paired retained coordinate and every source state/mass assignment is
checked. No sampling was repeated.

`independent-packet-readback.log` records exit 0 and has SHA256
`1071f5968b02efb2cde175da62805744d805dd3e8ab6ef08a71a41ec4500f32e`.
Its report SHA256 is
`ddbe199d8f378ac57f2a9b7fcf6196fcd51ad1d2f32c3d2a8d3b94b98f7333e6`.
The independent reducer uses long-double centered reductions; it does not call
the producer's reduction helpers.

Comparison of the two saved reports passed 576 scalar comparisons over all
24 cases. The maximum difference divided by its declared physical coordinate/
energy scale is `3.822642839008572e-17`. The successful comparison log SHA256 is
`b1f2ec9cd237dc603ab42bedc99e1cca110ce2d99b636b289e934ed912398810`.
The first comparison attempt reached output serialization and failed while
calling a path helper on a string. Path normalization was corrected; the first
log is retained at SHA256
`78447d20007b448ce4b39fd3748eb4c4bf86f4c91421ac2b35996401271174b4`.
Only saved-report comparisons were repeated, with no sampling or NPZ reduction
repeated and no duplicate count of the comparisons.

Independent formula inspection confirms the outgoing Gamma(shape two) moments,
the total-variance decomposition, conditional component-allocation sampling
variances and population-variance bias correction. The review identified and
resolved four qualifications before the readback run:

- Statistical independence is a property assumed of caller-supplied variates,
  not guaranteed by the sampler's open-interval validation.
- The exact intended case set, input/code associations and artifact hashes must
  be verified, alongside source schema and component-index bounds.
- Equal within-component weights are checked individually, as required by the
  analytic conditional sampling formulas.
- Exact positive physical-component coverage is required, with packet counts
  summing to the declared budget.

The eight pseudorandom seed streams share verified input prefixes across
budgets. Cross-budget cases are correlated. Finite ensemble standardized errors
and RMSE describe those fixed outcomes, with no physical confidence intervals,
monotonic-outcome rule, seed selection or certified convergence rate. The
source-time target remains a finite order-32 quadrature result. Only one
manufactured original interval and one generic supplied exact-state mass are
studied. There is no measured spectrum, calibrated water-release input, live
host, kinetic-gap evolution or actual FLASH run.

The final figure was inspected after moving the long-bar annotation inside the
plot. Its SHA256 is
`7eee656032df01847129b8b7282124a8844e331d585685b1bb0f42ee7fd423b6`.
Only rendering changed; the data and statistics were preserved.
