"""Compare two saved reductions without reopening or regenerating samples."""
import hashlib
import json
from pathlib import Path

import numpy as np

work = Path(__file__).parent
producer_path = work / 'packet-evidence/report.json'
readback_path = work / 'packet_readback.json'
producer, readback = (json.loads(path.read_text()) for path in (producer_path, readback_path))
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
assert readback['producer_report_sha256'] == sha(producer_path)
original = {(item['packet_budget'], item['seed']): item for item in producer['cases']}
records = []
for case in readback['cases']:
    other = original[case['packets'], case['seed']]
    shared = other['metrics']['shared']
    e = case['expected_mean_energy_j']
    second = case['expected_raw_second_energy_j2']
    dt = case['deterministic_conditional']['time_stop_s'] - case['deterministic_conditional']['time_start_s']
    width = .005
    checks = [
        ('sampled_mean_energy_j', case['sampled_mean_energy_j'], shared['mean_actual_kinetic_energy_j'], e),
        ('sampled_raw_second_energy_j2', case['sampled_raw_second_energy_j2'], shared['raw_second_actual_kinetic_energy_j2'], second),
        ('sampled_plugin_energy_variance_j2', case['sampled_plugin_energy_variance_j2'], shared['plugin_variance_actual_kinetic_energy_j2'], second),
        ('sampled_corrected_energy_variance_j2', case['sampled_corrected_energy_variance_j2'], shared['corrected_variance_actual_kinetic_energy_j2'], second),
        ('mean_energy_conditional_standard_error_j', case['mean_energy_conditional_standard_error_j'], other['analytic_standard_errors']['shared.mean_actual_kinetic_energy_j'], e),
        ('raw_second_energy_conditional_standard_error_j2', case['raw_second_energy_conditional_standard_error_j2'], other['analytic_standard_errors']['shared.raw_second_actual_kinetic_energy_j2'], second),
    ]
    for hypothesis, value in case['hypotheses'].items():
        same = other['metrics'][hypothesis]
        for key, expected, scale in [
            ('mean_time_s', shared['mean_time_s'], 1.2e-7),
            ('variance_time_s2', shared['variance_time_s2'], dt ** 2),
            ('mean_x_m', same['mean_x_m'], width),
            ('mean_z_m', shared['mean_z_m'], .025),
            ('mean_width_centered_square_m2', same['mean_width_centered_square_m2'], width ** 2),
            ('cov_time_width_centered_square_s_m2', same['cov_time_width_centered_square_s_m2'], dt * width ** 2),
            ('cov_kinetic_energy_width_centered_square_j_m2', same['cov_actual_kinetic_energy_width_centered_square_j_m2'], e * width ** 2),
            ('cov_local_expected_energy_width_centered_square_j_m2', same['cov_expected_translational_energy_width_centered_square_j_m2'], e * width ** 2),
            ('cov_time_kinetic_energy_s_j', shared['cov_time_actual_kinetic_energy_s_j'], dt * e),
        ]:
            checks.append((hypothesis + '.' + key, value[key], expected, scale))
    relative = []
    for name, actual, expected, scale in checks:
        difference = abs(actual - expected)
        scaled = difference / scale
        assert scaled <= 128 * np.finfo(float).eps, (case['packets'], case['seed'], name, difference, scale)
        relative.append(scaled)
    records.append({'packets': case['packets'], 'seed': case['seed'], 'checks': len(checks),
                    'maximum_difference_over_physical_scale': max(relative)})
result = {
    'schema': 'mhdlab-weighted-source-reduction-comparison-v1', 'parameter_status': 'manufactured',
    'producer_report_sha256': sha(producer_path), 'readback_report_sha256': sha(readback_path),
    'script_sha256': sha(__file__), 'cases': records,
    'scalar_comparisons': sum(item['checks'] for item in records),
    'maximum_difference_over_physical_scale': max(item['maximum_difference_over_physical_scale'] for item in records),
    'tolerance': '128 float64 eps times the explicitly supplied physical coordinate/energy scale; centered covariance and symmetry-cancelled means are compared on those scales.',
    'sampling_repeated': False,
}
output = work / 'packet_reduction_comparison.json'
assert not output.exists()
output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'cases': len(records), 'scalar_comparisons': result['scalar_comparisons'],
                  'maximum_difference_over_physical_scale': result['maximum_difference_over_physical_scale'],
                  'output_sha256': sha(output)}, indent=2))
