import datetime, fcntl, hashlib, json, pathlib, shutil, subprocess, sys
status_path=pathlib.Path('/workspace/research_work/mitl-upstream-status.json')
work=pathlib.Path('/workspace/research_work/mitl-upstream-20261018T2028')
owner='mitl-upstream-20261018T2028'
now=datetime.datetime.now(datetime.timezone.utc)
with pathlib.Path('/workspace/research_work/mitl-upstream-status.lock').open('a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 status=json.loads(status_path.read_text())
 expiry=status.get('active_editing_lease_until_utc')
 assert not expiry or datetime.datetime.fromisoformat(expiry)<=now, 'Another editing lease is active'
 assert subprocess.check_output(['git','branch','--show-current'],cwd='/workspace/Power-Flow',text=True).strip()==status['branch']
 assert not subprocess.check_output(['git','status','--porcelain'],cwd='/workspace/Power-Flow',text=True).strip()
 assert status['last_complete_commit']==subprocess.check_output(['git','rev-parse','HEAD'],cwd='/workspace/Power-Flow',text=True).strip()
 work.mkdir()
 shutil.copy2('/workspace/research_work/mitl-upstream-20261018T1947/record_command.py',work/'record_command.py')
 (work/'claim_command.py').write_text(sys.argv[1])
 status.update(active_lease_owner=owner,active_editing_lease_until_utc=(now+datetime.timedelta(minutes=90)).isoformat(),last_update_utc=now.isoformat(),active_phase='Weighted paired-source launch verification with full kinetic scatter',reserved_paths=[str(work),'docs/weighted_source_packet_verification.md','/workspace/handoffs/mitl-packet-verification-20261018T2028','/workspace/power-flow-flash-foundation.patch'])
 temp=status_path.with_suffix('.tmp');temp.write_text(json.dumps(status,indent=2)+'\n');temp.replace(status_path)
 event={'utc':now.isoformat(),'event':'lease_claimed','pass_id':owner,'scope':status['reserved_paths'],'lease_until':status['active_editing_lease_until_utc'],'baseline':status['last_complete_commit'],'latest_handoff_read':status['handoff_document'],'next_task':status['next_work'][0]['task'],'command':['python','-c',sys.argv[1],sys.argv[1]],'command_exit':0}
 with pathlib.Path('/workspace/research_work/mitl-upstream-journal.jsonl').open('a') as stream:stream.write(json.dumps(event)+'\n')
 print(json.dumps(event,indent=2))
