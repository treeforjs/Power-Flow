from pathlib import Path
import ast,hashlib,importlib.util,json,sys
W=Path('/workspace/research_work/mitl-upstream-20261019T0810/producer');R=Path('/workspace/Power-Flow')
p=R/'tools/export_boundary_quadrature.py';old=W/'source-versions/parser_checked_cli.py'
spec=importlib.util.spec_from_file_location('export_raw',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
oldast=ast.parse(old.read_text());newast=ast.parse(p.read_text())
o={n.name:n for n in oldast.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))};n={n.name:n for n in newast.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
unchanged=['digest','sha','_constant','_decimal','_integer','_object','_text','_sha','_relative','_fraction','_read_relative','_source_float','_source_json','read_bound_source','_late_recheck']
for k in unchanged:assert ast.dump(o[k],include_attributes=False)==ast.dump(n[k],include_attributes=False),k
assert [ast.dump(v,include_attributes=False) for v in o['load_config'].body[1:]]==[ast.dump(v,include_attributes=False) for v in n['load_config'].body[2:]]
raw=(R/'configs/boundary_quadrature_manufactured.json').read_bytes();d=m.load_config(Path('/not/read'),raw_bytes=raw)
try:m.load_config(Path('/not/read'),raw_bytes=raw.replace(b'"decimal_precision": 80',b'"decimal_precision": 1e-1000'))
except ValueError as e:rejection=str(e)
else:raise RuntimeError('rawunderflow admitted')
assert not any(x.startswith('mhdlab') for x in sys.modules)
result={'schema':'mhdlab-boundary-quadrature-raw-config-binding-v1','status':'passed','initial_cli_sha256':hashlib.sha256(old.read_bytes()).hexdigest(),'checked_cli_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'config_sha256':hashlib.sha256(raw).hexdigest(),'unchanged_guard_function_ASTs':unchanged,'load_config_validation_suffix_AST_identical':True,'change':'Accept immutable already-read config bytes; validate with identical body, preserve and hash those same bytes, and reject late byte mutation. No numerical method or query change.','focused_checks':2,'accepted_immutable_raw_config':True,'rejected_raw_nonzero_underflow':rejection,'initial_19_controls_not_repeated':True,'scientific_modules_imported':False,'core_calls':0}
(W/'raw_config_binding.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
