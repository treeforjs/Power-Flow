"""New exporter parser/byte controls only; no scientific module imports."""
from pathlib import Path
import copy,hashlib,importlib.util,json,sys,tempfile
W=Path('/workspace/research_work/mitl-upstream-20261019T0810');R=Path('/workspace/Power-Flow')
script=R/'tools/export_boundary_quadrature.py';cfg=R/'configs/boundary_quadrature_manufactured.json'
spec=importlib.util.spec_from_file_location('boundary_export_cli',script);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
base=json.loads(cfg.read_bytes());results=[]
def test(name,change=None,raw=None):
 with tempfile.TemporaryDirectory() as tmp:
  p=Path(tmp)/'config.json';d=copy.deepcopy(base)
  if change:change(d)
  p.write_text(raw if raw is not None else json.dumps(d))
  try:m.load_config(p)
  except (ValueError,TypeError,OverflowError) as e:results.append({'name':name,'status':'rejected','error':str(e)});return
  raise RuntimeError('invalid config admitted: '+name)
config=m.load_config(cfg);results.append({'name':'declared_queries_method_and_binding','status':'accepted'})
test('decimal_precision_bool',lambda d:d['method'].__setitem__('decimal_precision',True))
test('wrong_number_of_nodes',lambda d:d['method'].__setitem__('nodes_per_positive_support',4))
test('weight_normalization_forbidden',lambda d:d['method'].__setitem__('weight_repair','renormalize'))
test('query_outside_declared_support',lambda d:d['queries'][0]['start_fraction'].__setitem__('numerator','4'))
test('duplicate_query_identity',lambda d:d['queries'][1].__setitem__('window_id','shifted_interior'))
test('noncanonical_rational',lambda d:d['queries'][0].__setitem__('start_fraction',{'numerator':'6','denominator':'64'}))
test('zero_width_query',lambda d:d['queries'][0].__setitem__('stop_fraction',d['queries'][0]['start_fraction']))
test('external_source_path',lambda d:d['source_binding']['files']['windows'].__setitem__('relative_path','../windows.json'))
test('missing_joint_moment',lambda d:d['quantity_contract']['joint_moments'].pop())
test('source_hash_alias_disagreement',lambda d:d['source_binding'].__setitem__('accepted_window_result_sha256','0'*64))
test('cache_count_bool',lambda d:d['declared_counts'].__setitem__('contrasts',True))
text=json.dumps(base)
test('raw_nonzero_underflow',raw=text.replace('"decimal_precision": 80','"decimal_precision": 1e-1000'))
test('raw_negative_integer_zero',raw=text.replace('"decimal_precision": 80','"decimal_precision": -0'))
test('duplicate_root_key',raw=text[:-1]+',"schema":"duplicate"}')
files=m.read_bound_source(config,Path('/workspace/research_work/mitl-upstream-20261019T0737'));results.append({'name':'actual_seven_accepted_source_bytes','status':'accepted','files':len(files)})
bad=copy.deepcopy(config);bad['source_binding']['files']['scientific_review']['sha256']='0'*64
try:m.read_bound_source(bad,Path('/workspace/research_work/mitl-upstream-20261019T0737'))
except ValueError as e:results.append({'name':'wrong_expected_source_byte_hash','status':'rejected','error':str(e)})
else:raise RuntimeError('wrong expected bytes admitted')
m._late_recheck(config,Path('/workspace/research_work/mitl-upstream-20261019T0737'));results.append({'name':'late_byte_identity','status':'accepted'})
real=m._read_relative
m._read_relative=lambda b,p: real(b,p)+b' ' if p.endswith('coupled_emission_windows.json') else real(b,p)
try:m._late_recheck(config,Path('/workspace/research_work/mitl-upstream-20261019T0737'))
except ValueError as e:results.append({'name':'late_byte_mutation','status':'rejected','error':str(e)})
else:raise RuntimeError('late byte mutation admitted')
finally:m._read_relative=real
assert not any(x.startswith('mhdlab') for x in sys.modules)
out={'schema':'mhdlab-boundary-quadrature-input-guards-v1','status':'passed','script_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),'config_sha256':hashlib.sha256(cfg.read_bytes()).hexdigest(),'check_script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'checks':results,'checks_count':len(results),'rejected_count':sum(r['status']=='rejected' for r in results),'scientific_modules_imported':False,'core_calls':0,'old_suites_or_numerical_cases_replayed':False}
(W/'producer/input_guard_checks.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
