"""Static import-boundary/unchanged-guard evidence; does not import any core."""
from pathlib import Path
import ast,hashlib,json,sys
P=Path(__file__).resolve().parent;R=Path('/workspace/Power-Flow');old=P/'source-versions/cli_before_direct_core_loader.py';new=R/'tools/export_boundary_quadrature.py';core=R/'mhdlab/boundary_quadrature.py'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def funcs(p):return {x.name:x for x in ast.parse(p.read_text()).body if isinstance(x,ast.FunctionDef)}
o,n=funcs(old),funcs(new)
unchanged=['digest','sha','_constant','_decimal','_integer','_object','_text','_sha','_relative','_fraction','load_config','_read_relative','_source_float','_source_json','read_bound_source','_late_recheck','_write_json','_flatten','_write_csv','_export_tables']
for k in unchanged:assert ast.dump(o[k],include_attributes=False)==ast.dump(n[k],include_attributes=False),k
imports=[]
for node in ast.walk(ast.parse(core.read_text())):
 if isinstance(node,ast.Import):imports.extend(x.name for x in node.names)
 if isinstance(node,ast.ImportFrom):
  assert node.level==0
  imports.append(node.module)
assert set(imports)<={'__future__','dataclasses','decimal','fractions','functools','hashlib','json','math','re','sys'},imports
loader=ast.get_source_segment(new.read_text(),n['_load_core'])
assert 'sys.modules[name]=module' in loader and loader.index('sys.modules[name]=module')<loader.index('spec.loader.exec_module(module)') and 'del sys.modules[name]' in loader
assert not any(k=='mhdlab' or k.startswith('mhdlab.') for k in sys.modules)
result={'schema':'mhdlab-boundary-quadrature-import-boundary-amendment-v1','status':'passed_static_AST_review_pending','initial_export_format_checked_cli_sha256':sha(old),'final_cli_sha256':sha(new),'current_core_sha256':sha(core),'change':'Dedicated direct file import, registering before exec for dataclasses and deleting on load failure; avoids eager legacy package initializer. No prior public file changes.','unchanged_function_ASTs':unchanged,'core_imports':sorted(set(imports)),'core_imports_are_stdlib_only':True,'dedicated_module_registered_before_execution':True,'load_failure_registration_cleanup':True,'new_package_module_rejection_check':True,'old_parser_and_format_controls_not_repeated':True,'core_imported_or_executed':False,'old_scientific_modules_imported':False}
(P/'import_boundary_amendment.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
