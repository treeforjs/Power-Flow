from pathlib import Path
import datetime,hashlib,json,subprocess
P=Path(__file__).resolve().parent;R=Path('/workspace/Power-Flow')
head=subprocess.run(['git','rev-parse','HEAD'],cwd=R,check=True,capture_output=True,text=True).stdout.strip()
commit_time=subprocess.run(['git','show','-s','--format=%cI',head],cwd=R,check=True,capture_output=True,text=True).stdout.strip()
report=json.loads((P/'reference-run/report.json').read_bytes());freeze=json.loads((P/'freeze.json').read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for f,h in report['code_sha256'].items():assert sha(R/f)==h
result={'schema':'mhdlab-boundary-quadrature-execution-source-lineage-v1','status':'saved_source_hashes_match_observed_git_context','observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'observed_git_HEAD_after_export':head,'observed_HEAD_commit_time':commit_time,'initial_lease_baseline':'ea82ae3094ae480cb9c370652fa1eb1c677d8de5','HEAD_not_assumed_equal_to_initial_lease_baseline':True,'executed_report_sha256':sha(P/'reference-run/report.json'),'executed_code_sha256':report['code_sha256'],'frozen_public_source_sha256':freeze['public_source_sha256'],'source_bytes_unchanged_after_export':True,'git_commands':[['git','rev-parse','HEAD'],['git','show','-s','--format=%cI',head]],'qualification':'Git context is observed after the single export. Exact executed file hashes and before-run snapshots, rather than an assumed lease HEAD, bind the numerical run. No exported report or source bytes were overwritten.','scientific_modules_imported_or_calls':0}
(P/'execution_lineage.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
