"""Freeze actual source/input/gate bytes before the single saved-data export."""
from pathlib import Path
import argparse,ast,datetime,hashlib,json
P=Path(__file__).resolve().parent;W=P.parent;R=Path('/workspace/Power-Flow')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
a=argparse.ArgumentParser();a.add_argument('--core-sha',required=True);a.add_argument('--static-sha',required=True);a.add_argument('--tests-completion',required=True);a.add_argument('--tests-sha',required=True);a.add_argument('--plan-review-sha',required=True);a.add_argument('--import-review-sha',required=True);args=a.parse_args()
paths={'core':R/'mhdlab/boundary_quadrature.py','static':W/'core-review/completion.json','tests':W/args.tests_completion,'plan_review':W/'oracle-review/plan_review.json','import_review':W/'core-review/import-boundary-review.json'}
expected={'core':args.core_sha,'static':args.static_sha,'tests':args.tests_sha,'plan_review':args.plan_review_sha,'import_review':args.import_review_sha}
for k,p in paths.items():
 if sha(p)!=expected[k]:raise ValueError('actual gate/source bytes differ: '+k)
config=R/'configs/boundary_quadrature_manufactured.json';cli=R/'tools/export_boundary_quadrature.py'
guards=json.loads((P/'input_guard_checks.json').read_bytes());raw=json.loads((P/'raw_config_binding.json').read_bytes())
if sha(config)!=guards['config_sha256'] or sha(config)!=raw['config_sha256']:raise ValueError('frozen scientific config changed')
fmt=json.loads((P/'export_format_checks.json').read_bytes())
amend=json.loads((P/'import_boundary_amendment.json').read_bytes())
if fmt['status']!='passed' or sha(cli)!=amend['final_cli_sha256'] or fmt['cli_sha256']!=amend['initial_export_format_checked_cli_sha256']:raise ValueError('CLI differs from reviewed export-format/import lineage')
format_old={x.name:x for x in ast.parse((P/'source-versions/cli_before_direct_core_loader.py').read_text()).body if isinstance(x,ast.FunctionDef)}
format_new={x.name:x for x in ast.parse(cli.read_text()).body if isinstance(x,ast.FunctionDef)}
for k in amend['unchanged_function_ASTs']:
 if ast.dump(format_old[k],include_attributes=False)!=ast.dump(format_new[k],include_attributes=False):raise ValueError('import-boundary-only AST relation changed: '+k)
old=P/'source-versions/parser_checked_cli.py'
o={x.name:x for x in ast.parse(old.read_text()).body if isinstance(x,ast.FunctionDef)};n={x.name:x for x in ast.parse(cli.read_text()).body if isinstance(x,ast.FunctionDef)}
for k in raw['unchanged_guard_function_ASTs']:
 if ast.dump(o[k],include_attributes=False)!=ast.dump(n[k],include_attributes=False):raise ValueError('guard AST changed: '+k)
if [ast.dump(v,include_attributes=False) for v in o['load_config'].body[1:]]!=[ast.dump(v,include_attributes=False) for v in n['load_config'].body[2:]]:raise ValueError('validation suffix changed')
source=json.loads(config.read_bytes());base=Path('/workspace/research_work/mitl-upstream-20261019T0737')
inputs={}
for k,v in source['source_binding']['files'].items():
 if sha(base/v['relative_path'])!=v['sha256']:raise ValueError('raw input changed: '+k)
 inputs[k]=v['sha256']
for rel in ['tools/export_boundary_quadrature.py','mhdlab/boundary_quadrature.py','configs/boundary_quadrature_manufactured.json']:
 q=P/'source-versions'/Path(rel).name;q.write_bytes((R/rel).read_bytes())
gates={k:{'path':str(p),'sha256':sha(p),'schema':json.loads(p.read_bytes()).get('schema'),'status':json.loads(p.read_bytes()).get('status')} for k,p in paths.items() if k!='core'}
result={'schema':'mhdlab-boundary-quadrature-producer-freeze-v1','status':'frozen_before_first_saved_data_quadrature_export','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'public_source_sha256':{str(p.relative_to(R)):sha(p) for p in [cli,paths['core'],config]},'actual_gate_bytes':gates,'input_alias_sha256':inputs,'input_guard_sha256':sha(P/'input_guard_checks.json'),'raw_config_binding_sha256':sha(P/'raw_config_binding.json'),'import_boundary_amendment_sha256':sha(P/'import_boundary_amendment.json'),'import_boundary_review_sha256':sha(W/'core-review/import-boundary-review.json'),'parser_AST_lineage_confirmed':True,'initial_19_controls_not_repeated':True,'queries':source['queries'],'method':source['method'],'declared_counts':source['declared_counts'],'previous_numerical_model_imports_or_calls':0,'positive_exports_before_this_freeze':0,'source_snapshots_sha256':{str(p.relative_to(W)):sha(p) for p in (P/'source-versions').iterdir() if p.is_file()}}
if (P/'freeze.json').exists():raise ValueError('freeze already exists')
(P/'freeze.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
