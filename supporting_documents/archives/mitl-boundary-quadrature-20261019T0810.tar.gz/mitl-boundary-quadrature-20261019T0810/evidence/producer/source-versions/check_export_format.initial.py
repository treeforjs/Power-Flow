from pathlib import Path
import csv,hashlib,importlib.util,json,sys,tempfile
R=Path('/workspace/Power-Flow');W=Path('/workspace/research_work/mitl-upstream-20261019T0810/producer');p=R/'tools/export_boundary_quadrature.py'
spec=importlib.util.spec_from_file_location('boundary_export_format',p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
record={'exact':{'numerator':'-1','denominator':'8'},'value':-.125,'projection':{'rounded':False,'exact_rounding_error':{'numerator':'0','denominator':'1'}}}
rows=[m._flatten({'node_id':'manufactured-format-only','time_s':1e-8,'number_weight':2.5,'signed_defect':record,'availability':{'available':False,'reason':'unavailable-format-only','record':None}}),m._flatten({'node_id':'second-format-row','time_s':2e-8,'number_weight':3.5,'other':True})]
with tempfile.TemporaryDirectory() as tmp:
 q=Path(tmp)/'format.csv';m._write_csv(q,rows)
 saved=list(csv.DictReader(q.open()))
 assert saved[0]['signed_defect__exact_numerator']=='-1' and saved[0]['signed_defect__exact_denominator']=='8'
 assert saved[0]['availability__record']=='null' and saved[0]['availability__available']=='false'
 assert saved[1]['signed_defect']=='null' and saved[1]['other']=='true'
 assert float(saved[0]['time_s'])==1e-8 and float(saved[0]['number_weight'])==2.5
 assert saved[0]['signed_defect__projection_json']==json.dumps(record['projection'],sort_keys=True,separators=(',',':'))
assert not any(x.startswith('mhdlab') for x in sys.modules)
d={'schema':'mhdlab-boundary-quadrature-export-format-check-v1','status':'passed','cli_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'synthetic_format_rows':2,'rational_and_signed_projection_fields_preserved':True,'explicit_null_and_availability_fields_preserved':True,'actual_float_csv_roundtrip_checked':True,'scientific_modules_imported':False,'core_calls':0}
(W/'export_format_checks.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d,indent=2))
