"""Read saved JSON/CSV bytes and binary-field arithmetic only; no model imports."""
from pathlib import Path
from fractions import Fraction as F
import csv,datetime,hashlib,json,math,sys
P=Path(__file__).resolve().parent;W=P.parent;R=Path('/workspace/Power-Flow');O=P/'reference-run'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def frac(r):return F(int(r['numerator']),int(r['denominator']))
def rec(r):return frac(r['exact'])
def flatten(v,p=''):
 if type(v) is dict and set(v)=={'exact','value','projection'}:
  return {p:v['value'],p+'__exact_numerator':v['exact']['numerator'],p+'__exact_denominator':v['exact']['denominator'],p+'__projection_json':json.dumps(v['projection'],sort_keys=True,separators=(',',':'),allow_nan=False)}
 if type(v) is dict:
  d={}
  for k,x in v.items():d.update(flatten(x,p+'__'+k if p else k))
  return d
 if type(v) is list:return {p:json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False)}
 return {p:'null' if v is None else v}
def cell(v):return format(v,'.17g') if type(v) is float else 'true' if v is True else 'false' if v is False else str(v)
report=json.loads((O/'report.json').read_bytes());d=json.loads((O/'boundary_quadrature.json').read_bytes());freeze=json.loads((P/'freeze.json').read_bytes())
assert report['schema']=='mhdlab-boundary-quadrature-export-run-v1' and report['status']=='manufactured_saved_source_boundary_quadrature_only'
assert sha(O/'boundary_quadrature.json')==report['result_sha256']
for rel,h in report['artifact_sha256'].items():assert sha(O/rel)==h,rel
for rel,h in report['copied_source_input_sha256'].items():assert sha(O/rel)==h,rel
for rel,h in freeze['public_source_sha256'].items():assert sha(R/rel)==h,rel
assert report['config_sha256']==freeze['public_source_sha256']['configs/boundary_quadrature_manufactured.json']
expected={'piece_cache':66,'node_cache':330,'source_queries':6,'patch_queries':12,'aggregate_queries':4,'contrasts':2}
rows={name:[flatten(x) for x in d[name]] for name in expected}
for name,typ in [('source_query_nodes','source_queries'),('patch_query_nodes','patch_queries')]:
 rows[name]=[]
 for parent,item in enumerate(d[typ]):
  identity={k:item[k] for k in ('source_history_id','query_id','state_id','hypothesis','patch_index') if k in item}
  for i,node in enumerate(item['summary']['nodes']):rows[name].append(flatten({'parent_query_index':parent,'node_reference_index':i,**identity,'node':node}))
expected.update({'source_query_nodes':570,'patch_query_nodes':1140})
for name,count in expected.items():
 assert len(rows[name])==count
 with (O/(name+'.csv')).open() as stream:saved=list(csv.DictReader(stream))
 assert len(saved)==count
 for got,wanted in zip(saved,rows[name]):
  assert set(wanted)<=set(got)
  for k in got:assert got[k]==cell(wanted[k]) if k in wanted else got[k]=='null',(name,k)
assert report['record_counts']==expected
kb=F('1.380649e-23');qe=F('1.602176634e-19')
config_path=next(O/x for x in report['copied_source_input_sha256'] if x.endswith('source-inputs/producer/reference-run/input_config.json'))
# The original width configuration has common_scalar_problem; the current window
# configuration also ends in input_config.json, so identify by schema explicitly.
configs=[json.loads((O/x).read_bytes()) for x in report['copied_source_input_sha256'] if x.endswith('input_config.json')]
width=next(x for x in configs if x.get('schema')=='mhdlab-thermal-width-power-manufactured-config-v1')
reservoir=width['common_scalar_problem']['reservoir'];D=F.from_float(reservoir['desorption_energy_ev'])*qe;I=F.from_float(reservoir['internal_energy_ev'])*qe
keys=('released_number','local_time_first_moment_s','local_time_second_moment_s2','temperature_first_moment_k','temperature_second_moment_k2','local_time_temperature_moment_k_s','binding_energy_j','internal_energy_j','translational_energy_j','gas_energy_j','total_wall_energy_debit_j')
checks={'summary_binary_field_moments':0,'exact_additive_defect_closures':0,'independent_energy_consistency_checks':0,'normalized_joint_statistic_checks':0}
for group in ('source_queries','patch_queries','aggregate_queries'):
 for item in d[group]:
  s=item['summary'];anchor=frac(s['local_time_anchor_exact_s']);sums={k:F(0) for k in keys}
  for node in s['nodes']:
   w=F.from_float(node['number_weight']);t=F.from_float(node['time_s'])-anchor;T=F.from_float(node['temperature_k']);E=F.from_float(node['expected_translational_energy_j']);B=F.from_float(node['desorption_energy_j']);J=F.from_float(node['internal_energy_j'])
   assert w>0 and T>0
   for k,v in zip(keys,(w,w*t,w*t*t,w*T,w*T*T,w*t*T,w*B,w*J,w*E,w*(E+J),w*(E+J+B))):sums[k]+=v
  for k in keys:
   assert sums[k]==rec(s['represented'][k]),(group,k)
   assert rec(s['finite_rule'][k])-rec(s['target'][k])==rec(s['rule_generation_defect'][k])
   assert rec(s['represented'][k])-rec(s['finite_rule'][k])==rec(s['export_projection_defect'][k])
   assert rec(s['total_defect'][k])==rec(s['rule_generation_defect'][k])+rec(s['export_projection_defect'][k])
   checks['summary_binary_field_moments']+=1;checks['exact_additive_defect_closures']+=3
  ec=s['energy_consistency'];fromT=2*kb*sums['temperature_first_moment_k']
  for k,v in {'represented_translation_from_temperature_j':fromT,'represented_translation_field_minus_temperature_energy_j':sums['translational_energy_j']-fromT,'represented_binding_field_minus_supplied_cost_j':sums['binding_energy_j']-D*sums['released_number'],'represented_internal_field_minus_supplied_cost_j':sums['internal_energy_j']-I*sums['released_number']}.items():
   assert rec(ec[k])==v,(group,k);checks['independent_energy_consistency_checks']+=1
  N=sums['released_number']
  if N:
   mt=sums['local_time_first_moment_s']/N;mT=sums['temperature_first_moment_k']/N;mtT=sums['local_time_temperature_moment_k_s']/N
   stats={'mean_local_time_s':mt,'variance_local_time_s2':sums['local_time_second_moment_s2']/N-mt*mt,'mean_temperature_k':mT,'variance_temperature_k2':sums['temperature_second_moment_k2']/N-mT*mT,'mean_local_time_temperature_k_s':mtT,'covariance_local_time_temperature_k_s':mtT-mt*mT}
   for k,v in stats.items():
    r=s['statistics']['represented'][k];assert r['available'] is True and rec(r['record'])==v,(group,k);checks['normalized_joint_statistic_checks']+=1
assert d['host_budget_accepted'] is False and d['owner_implementation_verified'] is False and d['new_query_IVP_error_qualified'] is False
assert not any(x.startswith('mhdlab') for x in sys.modules)
commands=[json.loads(x) for x in (W/'commands.jsonl').read_text().splitlines()]
positive=[x for x in commands if x['command'][0:4]==['.venv/bin/python','-W','error','tools/export_boundary_quadrature.py']]
assert len(positive)==1 and positive[0]['exit_code']==0
artifacts={str(p.relative_to(W)):sha(p) for p in P.rglob('*') if p.is_file() and p.name!='completion.json' and '__pycache__' not in p.parts}
result={'schema':'mhdlab-boundary-quadrature-producer-completion-v1','status':'passed_saved_data_export_and_binary_field_readback','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'report_path':'producer/reference-run/report.json','report_sha256':sha(O/'report.json'),'result_path':'producer/reference-run/boundary_quadrature.json','result_sha256':sha(O/'boundary_quadrature.json'),'public_source_sha256':freeze['public_source_sha256'],'config_sha256':report['config_sha256'],'positive_saved_data_export_batches':1,'batch':positive[0],'record_counts':expected,'cache':d['cache'],'copied_source_file_count':len(report['copied_source_input_sha256']),'copied_source_input_sha256':report['copied_source_input_sha256'],'source_binding':report['source_binding'],'accepted_prerequisites':freeze['actual_gate_bytes'],'input_controls':{'initial_19_report':'producer/input_guard_checks.json','initial_19_report_sha256':sha(P/'input_guard_checks.json'),'initial_19_CLI_sha256':json.loads((P/'input_guard_checks.json').read_bytes())['script_sha256'],'raw_config_binding_2_focused_checks':'producer/raw_config_binding.json','raw_config_binding_sha256':sha(P/'raw_config_binding.json'),'initial_guard_ASTs_and_validation_suffix_unchanged':True,'initial_19_not_repeated':True,'direct_import_boundary_amendment_sha256':sha(P/'import_boundary_amendment.json'),'direct_import_boundary_review_sha256':sha(W/'core-review/import-boundary-review.json'),'final_import_boundary_change_preserves_guard_export_ASTs':True,'synthetic_CSV_format_rows':2,'format_report_sha256':sha(P/'export_format_checks.json'),'format_control_execution_qualification':'Initial work-only reader emitted ResourceWarning after exit0; preserved, then only same two-row format control reran clean with context-managed reader. No CLI change.'},'saved_readback':{'all_CSV_JSON_records_exactly_matched':True,'all_output_and_copied_input_hashes_matched':True,**checks,'scientific_module_imports_or_calls':0},'inherited_source_and_IVP_errors_separate':True,'new_query_IVP_reference_computed_here':False,'source_evolution_RHS_assembly_window_export_reference_driver_calls':0,'host_budget_accepted':False,'owner_implementation_verified':False,'old_suites_or_numerical_cases_replayed':False,'open_substantive_findings':[],'artifact_path_base':'pass directory containing producer/','artifact_sha256':artifacts}
(P/'completion.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'completion':str(P/'completion.json'),'sha256':sha(P/'completion.json'),'counts':expected,'checks':checks},indent=2))
