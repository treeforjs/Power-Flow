"""Bind actual accepted saved records and the final guide, without numerical replay."""
import datetime
import hashlib
import json
from pathlib import Path

WORK = Path(__file__).resolve().parent
REPO = Path('/workspace/Power-Flow')
RUN = WORK / 'producer/reference-run'
ORACLE = WORK / 'independent-verification/quadrature-initial/report.json'
REVIEW = WORK / 'oracle-review/completion.json'
PUBLIC = (
    'mhdlab/boundary_quadrature.py',
    'tests/test_boundary_quadrature.py',
    'tools/export_boundary_quadrature.py',
    'configs/boundary_quadrature_manufactured.json',
    'docs/boundary_quadrature.md',
)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def pin(path):
    return {'path': str(path), 'sha256': sha(path)}


def load(path):
    return json.loads(path.read_text())


producer = load(RUN / 'report.json')
oracle = load(ORACLE)
review = load(REVIEW)
document = load(RUN / 'boundary_quadrature.json')
assert oracle['schema'] == 'mitl-independent-positive-boundary-quadrature-report-v1'
assert oracle['status'] == 'passed' and oracle['all_checks_passed'] is True
assert review['status'] == 'accepted'
assert review['actual_report_sha256'] == sha(ORACLE)
assert Path(review['actual_report_path']).resolve() == ORACLE.resolve()
assert oracle['producer_report_sha256'] == sha(RUN / 'report.json')
assert producer['result_sha256'] == sha(RUN / 'boundary_quadrature.json')
assert document['parameter_status'] == 'manufactured'
assert document['host_budget_accepted'] is False
assert document['owner_implementation_verified'] is False
assert document['new_query_IVP_error_qualified'] is False
cache = document['cache']
assert [cache[key] for key in ('source_evolution_calls', 'RHS_calls',
                              'assembly_calls', 'old_window_export_calls')] == [0, 0, 0, 0]
assert [cache[key] for key in ('unique_piece_supports', 'unique_nodes',
                              'source_queries', 'source_query_node_references',
                              'patch_queries', 'patch_node_references',
                              'aggregates', 'contrasts')] == [66, 330, 6, 570, 12, 1140, 4, 2]

record = {
    'schema': 'mitl-positive-boundary-quadrature-root-result-association-v1',
    'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'parameter_status': 'manufactured',
    'producer_report': pin(RUN / 'report.json'),
    'quadrature_document': pin(RUN / 'boundary_quadrature.json'),
    'oracle_report': pin(ORACLE),
    'oracle_review': pin(REVIEW),
    'public_source_sha256': {name: sha(REPO / name) for name in PUBLIC},
    'guide': pin(REPO / 'docs/boundary_quadrature.md'),
    'record_counts': producer['record_counts'],
    'cache': cache,
    'new_work_counts': oracle['new_work_counts'],
    'exact_check_counts': oracle['exact_check_counts'],
    'maximum_numerical_error_estimates': oracle['maxima'],
    'aggregate_queries': [
        {**{key: row[key] for key in ('hypothesis', 'query_id', 'state_id')},
         'summary': {key: value for key, value in row['summary'].items() if key != 'nodes'}}
        for row in document['aggregate_queries']
    ],
    'contrasts': document['contrasts'],
    'own_width_contrast_checks_reference': {
        **pin(ORACLE), 'key': 'own_width_contrast_checks',
        'maximum_checks': oracle['maxima']['own_contrast'],
    },
    'visual_review': {
        'performed': False,
        'reason': 'Data-only export; no new image generated or claimed inspected.',
    },
    'limits': [
        'New quadrature represents saved joint polynomial measures only.',
        'Finite-rule, actual exported-field and total defects remain separate.',
        'Prior source and IVP qualifications do not qualify new-query IVP error.',
        'No velocity, position, physical parameters, spectra or owner implementation supplied.',
        'This association calls no numerical producer, source, RHS or verification driver.',
    ],
}
out = WORK / 'root-result-association.json'
assert not out.exists()
out.write_text(json.dumps(record, indent=2, allow_nan=False) + '\n')
print(json.dumps({'result': pin(out), 'record_counts': record['record_counts'],
                  'maximum_numerical_error_estimates': record['maximum_numerical_error_estimates']},
                 indent=2))
