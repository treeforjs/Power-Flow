"""Static frozen-source review association, with no scientific imports."""
import datetime
import hashlib
import json
from pathlib import Path

WORK=Path('/workspace/research_work/mitl-upstream-20261019T0810')
OUT=WORK/'core-review'
SOURCE=Path('/workspace/Power-Flow/mhdlab/boundary_quadrature.py')
PIN='d396fa057e086af28dfe45af07a6efb613ba6ba595147ffb39b75be9ae2d551e'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def load(path):
    return json.loads(path.read_text())

assert sha(SOURCE)==PIN
freeze=load(WORK/'core/source-freeze.json')
assert freeze['source_sha256']==PIN and sha(Path(freeze['source_snapshot']))==PIN
assert sha(WORK/'core/boundary_quadrature.frozen.py')=='31cf8087c05ad700a6f6c8ebc618265ee8106ff666ead2063f54dc0cef37c276'
assert sha(WORK/'core/context-repair.diff')=='5cc800f748728daeabe261d719f0c79dd1e30adec8ebf10a1f8b7a3ed7ea8a25'
assert sha(WORK/'core/admission-repair.diff')=='1d3bbefeaefb1bb7b8fa8a0bdfe0e4cd1f0a4fb49dd28377dac006c50411cc5a'
for name in ('context-repair.json','admission-repair.json'):
    item=load(WORK/'core'/name)
    assert item['test_or_producer_runs_before_repair']==item['numerical_calls']==item['numerical_imports']==0
metadata=load(OUT/'admission-metadata.json')
assert metadata['status']=='passed'
assert metadata['all_seven_source_schema_literals_match'] is metadata['source_pin_vector_matches'] is True
assert metadata['reviewed_source_sha256']=='31cf8087c05ad700a6f6c8ebc618265ee8106ff666ead2063f54dc0cef37c276'
assert sha(WORK/'oracle-review/plan_review.json')=='999056c14d1e36ebbd865e4b6480565d43059085e48b5eec450c20680880b52c'
status=load(Path('/workspace/research_work/mitl-upstream-status.json'))
assert status['active_lease_owner']=='mitl-upstream-20261019T0810'
assert datetime.datetime.now(datetime.timezone.utc)<datetime.datetime.fromisoformat(status['active_editing_lease_until_utc'])

findings=[
 {'id':'fully-determined-decimal-context','status':'repaired_before_first_test_or_export',
  'origin':'Author self-review and independent static assessment.',
  'issue':'The initial Decimal80 localcontext inherited caller traps, permitting Inexact/Rounded traps to reject otherwise supported deterministic rule generation.',
  'correction':'A complete explicit Context pins precision, rounding, exponent limits, capitals, clamp, flags and selected exceptional traps.'},
 {'id':'outer-admission-qualification-replay','status':'repaired_before_first_test_or_export',
  'origin':'Author self-review and independent static assessment.',
  'issue':'A directly constructed admission dataclass could retain valid source bytes/documents but alter outer host/owner/declaration fields propagated into the export.',
  'correction':'Exact outer key set and canonical fixed declarations/provenance are replayed; document aliases and raw-byte tuple cardinality are strict before immutable byte association.'}
]
notes='''The complete initial source and both narrow pre-test repair diffs were read statically. The final module imports only the standard library; no old source, RHS, assembly, window export or IVP implementation is imported or called. Seven actual pinned source/acceptance files were compared as raw bytes and metadata against every new loader schema/status/hash/finding literal, including final review/report bindings. The initial metadata check remains associated with unchanged admission literals through the inspected narrow repairs; no old scientific audit was repeated.

The Decimal80 closed-form GL5 node/weight formulas are correctly mapped to [0,1]. They remain rational finite approximations, with untouched nonzero monomial defects and no normalization. A fully explicit Context now removes caller-trap dependence before first tests/export. Exact de Casteljau restriction carries the emitted measure scale; positive interior weights use dM/dv without a second duration. Exact-zero pieces skip with explicit source catalogue entries; nonzero unrepresentable fields, out-of-support node times/temperatures and collapsed binary clocks reject.

The exact polynomial target, finite-rule sum and actual binary-field sum are separate. All six required raw moments, including local-time*T, use a common exact query anchor. Per-phase normalized statistics retain full covariance and between-component variation through raw moment aggregation. Exact signed quantity defects telescope without altering weights. Both the binary expected-energy field and exact2*kB times binary temperature are retained and separately compared; removal/internal supplied costs are explicit and activation energy is not debited.

Unprojected areal node values are cached once by restricted source support. Patch number weights project true area times unprojected areal weight; source/patch summaries reuse time/T/energy fields and never multiply an already rounded source weight into a second physical launch. Source and patch binary moments use actual output fields. Full patch geometry ranges, states, source identities, complete controls and duplicate-view references remain explicit. Mean time/temperature are diagnostic, not substituted source distributions. Parent source/interpolation/IVP references remain inherited; new query IVP accuracy and host/owner acceptance stay false.

Both identified issues were repaired and frozen before any targeted test or export. No numerical result is established by this static gate; new tests, export and the independently frozen verifier own that evidence. This is manufactured deterministic quadrature of a saved polynomial source only, with no physical surface/water/ML, molecular-state/fragmentation data, velocities/positions, flight, gap transport, spectrum, Hall, FLASH or owner implementation claim.
'''
(OUT/'review.md').write_text(notes)
record={
 'schema':'mitl-positive-boundary-static-core-review-v1','status':'accepted',
 'reviewed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'reviewed_source':str(SOURCE),'reviewed_source_sha256':PIN,
 'initial_source_sha256':'31cf8087c05ad700a6f6c8ebc618265ee8106ff666ead2063f54dc0cef37c276',
 'source_freeze_sha256':sha(WORK/'core/source-freeze.json'),
 'output_contract_sha256':sha(WORK/'core/output-contract.json'),
 'admission_metadata_sha256':sha(OUT/'admission-metadata.json'),
 'prospective_plan_review_sha256':sha(WORK/'oracle-review/plan_review.json'),
 'source_input_sha256':metadata['source_file_sha256'],
 'findings':findings,'further_changes_requested':False,
 'all_source_admission_literals_compared_to_actual_metadata':True,
 'positive_rule_joint_moments_energy_area_and_cache_contracts_reviewed':True,
 'actual_independent_verification_result_pending':True,
 'scientific_module_imported':False,'numerical_models_or_tests_executed':False,
 'source_admission_or_quadrature_or_producer_executed':False,'old_source_or_IVP_driver_replayed':False,
 'physical_parameters_validated':False,'host_budget_accepted':False,
 'limits':['Static mathematical/interface/claims review and immutable metadata association only.',
           'No numerical node, polynomial, source, test, export or independent query is evaluated here.',
           'Two narrow pre-first-test/export repairs preserve initial frozen bytes and original equations/inputs/tolerances.',
           'Manufactured saved polynomial quadrature only; no physical/transport/owner/host qualification.'],
 'artifact_sha256':{name:sha(OUT/name) for name in ('freeze_review.py','review.md','check_admission_metadata.py',
   'check_admission_metadata.initial.py','admission-metadata.json','initial-read-provenance.json')},
 'pre_test_repair_sha256':{name:sha(WORK/'core'/name) for name in ('context-repair.json','context-repair.diff','admission-repair.json','admission-repair.diff')}
}
(OUT/'completion.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'path':str(OUT/'completion.json'),'sha256':sha(OUT/'completion.json'),'status':'accepted','source_sha256':PIN}))
