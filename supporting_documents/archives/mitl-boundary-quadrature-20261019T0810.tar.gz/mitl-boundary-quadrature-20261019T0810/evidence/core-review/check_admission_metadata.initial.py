"""Compare new loader literals with immutable acceptance metadata only."""
import ast
import hashlib
import json
from pathlib import Path

WORK = Path('/workspace/research_work/mitl-upstream-20261019T0810')
OLD = Path('/workspace/research_work/mitl-upstream-20261019T0737')
SOURCE = Path('/workspace/Power-Flow/mhdlab/boundary_quadrature.py')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def load(path):
    return json.loads(path.read_text())

tree = ast.parse(SOURCE.read_text())
assignments = {}
for node in tree.body:
    if isinstance(node,ast.Assign):
        for target in node.targets:
            if isinstance(target,ast.Name) and target.id in ('PINNED','ALIASES'):
                assignments[target.id] = ast.literal_eval(node.value)
admit = next(node for node in tree.body if isinstance(node,ast.FunctionDef) and node.name=='admit_boundary_source')
schemas = next(ast.literal_eval(node.value) for node in admit.body if isinstance(node,ast.Assign) and any(isinstance(target,ast.Name) and target.id=='schemas' for target in node.targets))
config = load(WORK/'independent-verification/input_config.json')
binding = config['source_binding']['files']
assert set(binding) == set(assignments['PINNED']) == set(schemas)
assert assignments['PINNED'] == {role:item['sha256'] for role,item in binding.items()}
paths = {role:OLD/item['relative_path'] for role,item in binding.items()}
for role,path in paths.items():
    assert sha(path) == assignments['PINNED'][role]
docs = {role:load(path) for role,path in paths.items()}
for role,schema in schemas.items():
    assert docs[role]['schema'] == schema, role
pin = assignments['PINNED']
checks = [
 ('report','result_sha256',pin['windows']),('report','config_sha256',pin['window_config']),
 ('windows','parameter_status','manufactured'),('windows','host_budget_accepted',False),
 ('windows','owner_implementation_verified',False),
 ('independent_completion','status','passed'),('independent_report','status','passed'),
 ('independent_completion','all_checks_passed',True),('independent_report','all_checks_passed',True),
 ('independent_completion','producer_report_sha256',pin['report']),
 ('independent_report','producer_report_sha256',pin['report']),
 ('independent_completion','report_sha256',pin['independent_report']),
 ('independent_completion','final_static_review_sha256',pin['scientific_review']),
 ('scientific_review','status','accepted'),
 ('scientific_review','actual_report_sha256',pin['independent_report']),
 ('scientific_review','owner_report_sha256',pin['independent_report']),
 ('scientific_review','window_document_sha256',pin['windows']),
 ('scientific_review','further_changes_requested',False)
]
for role,key,expected in checks:
    actual = docs[role][key]
    assert type(actual) is type(expected) and actual == expected, (role,key)
assert all(item['status']=='repaired_before_first_query' for item in docs['scientific_review']['findings'])
assert docs['report']['status']=='manufactured_saved_source_windows_only'
assert docs['report']['code_sha256']['mhdlab/coupled_emission_windows.py'] == '8a235ed92c0e40ccd43375fcd4d6c6beee05fd460b9fbf15102610c338eba786'
assert docs['scientific_review']['production_core_sha256'] == docs['report']['code_sha256']['mhdlab/coupled_emission_windows.py']
assert docs['scientific_review']['reviewed_source_sha256'] == 'a1c991808b9f7330f2b0dae54526464acae7a65429cc0cf0d45ed28dbad509a0'
result = {'schema':'mitl-boundary-admission-metadata-static-readback-v1','status':'passed',
 'reviewed_source_sha256':sha(SOURCE),'source_file_sha256':{role:sha(path) for role,path in paths.items()},
 'all_seven_source_schema_literals_match':True,'source_pin_vector_matches':True,
 'acceptance_field_and_type_checks':[{'role':role,'key':key,'expected':expected} for role,key,expected in checks],
 'finding_status':'repaired_before_first_query',
 'observed_parent_export_status':'manufactured_saved_source_windows_only',
 'source_acceptance_or_numerical_code_executed':False,
 'limits':'Static AST literal/read-only acceptance metadata comparison only. Source piece/value math is not recomputed.'}
path = WORK/'core-review/admission-metadata.json'
path.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'path':str(path),'sha256':sha(path),'status':'passed'}))
