"""Static direct-file import boundary association; does not import reviewed files."""
import ast
import datetime
import hashlib
import json
from pathlib import Path
import sys

WORK=Path('/workspace/research_work/mitl-upstream-20261019T0810')
REPO=Path('/workspace/Power-Flow')
OUT=WORK/'core-review'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def load(path):
    return json.loads(path.read_text())

cli=REPO/'tools/export_boundary_quadrature.py'
test=REPO/'tests/test_boundary_quadrature.py'
core=REPO/'mhdlab/boundary_quadrature.py'
initial=WORK/'producer/source-versions/cli_before_direct_core_loader.py'
assert sha(cli)=='cf293d5c7c41efd6cdb4de059fc1481323b796af127ed81414d59557ce51f9e1'
assert sha(test)=='0ac896e278b976f2539ed616d0d2167fee3b519ebf68bce8201d615f14b97177'
assert sha(core)=='d396fa057e086af28dfe45af07a6efb613ba6ba595147ffb39b75be9ae2d551e'
assert sha(initial)=='ee42bfdf438eb991b38967e38e33291993f8e29ed9cc6ca07c59ee17710e9d2e'
assert sha(WORK/'tests/plan.final52.json')=='8a609534668ffa37a34436efbf54a3ee4504dc61213821bc43f93310cad2cbc4'
assert sha(OUT/'completion.json')=='99d166a32e7fe905e9113f5ecdd1f629d4cfd346df2111105e58a4f4e02266a7'
amend=load(WORK/'producer/import_boundary_amendment.json')
oldtree,newtree=ast.parse(initial.read_text()),ast.parse(cli.read_text())
oldfunc={node.name:node for node in oldtree.body if isinstance(node,ast.FunctionDef)}
newfunc={node.name:node for node in newtree.body if isinstance(node,ast.FunctionDef)}
for name in amend['unchanged_function_ASTs']:
    assert ast.dump(oldfunc[name],include_attributes=False)==ast.dump(newfunc[name],include_attributes=False),name
assert len(amend['unchanged_function_ASTs'])==20
for path in (core,cli,test):
    for node in ast.walk(ast.parse(path.read_text())):
        if isinstance(node,ast.ImportFrom):
            assert node.module!='mhdlab' and not (node.module or '').startswith('mhdlab.')
        if isinstance(node,ast.Import):
            assert all(item.name!='mhdlab' and not item.name.startswith('mhdlab.') for item in node.names)
imports=[]
for node in ast.walk(ast.parse(core.read_text())):
    if isinstance(node,ast.ImportFrom):
        imports.append(node.module.split('.')[0])
    elif isinstance(node,ast.Import):
        imports.extend(item.name.split('.')[0] for item in node.names)
assert all(name in sys.stdlib_module_names for name in imports)
plan=load(WORK/'tests/plan.final52.json')
assert plan['planned_new_cases']==52 and plan['tests_executed_during_plan']==0
record={
 'schema':'mitl-positive-boundary-direct-import-static-review-v1','status':'accepted',
 'reviewed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'cli_sha256':sha(cli),'test_sha256':sha(test),'core_sha256':sha(core),
 'test_plan_sha256':sha(WORK/'tests/plan.final52.json'),
 'initial_cli_sha256':sha(initial),
 'import_boundary_amendment_sha256':sha(WORK/'producer/import_boundary_amendment.json'),
 'core_static_review_sha256':sha(OUT/'completion.json'),
 'unchanged_guard_export_function_ASTs':amend['unchanged_function_ASTs'],
 'review_checks':[
  'CLI loads the explicit new stdlib-only core path with spec_from_file_location under a dedicated nonpackage identity; no mhdlab initializer is traversed.',
  'The dedicated module is registered before execution for dataclass module identity, and its registration is removed on BaseException load failure. Reusing the dedicated identity rejects.',
  'Run integration changes only direct module qualification/import rejection and a truthful report declaration; the20 parser/source/late-recheck/CSV helpers retain identical ASTs.',
  'Final targeted tests direct-load the same new core file with a registered nonpackage identity; the autouse fixture records and requires an empty legacy-package module list.',
  'The fresh-process hostile-context case direct-loads the file before its first rule call, checks caller context preservation and empty legacy imports, and compares the resulting deterministic rule.',
  'The added forged-admission controls require specific outer declaration/provenance errors before intentionally unusable raw source data; no accepted-source numerical example is replayed.'
 ],
 'findings':[{'id':'legacy-package-import-boundary','status':'repaired_before_first_test_or_export',
   'issue':'Ordinary package import would traverse the existing eager scientific package initializer.',
   'correction':'CLI and targeted tests load only the fresh core file directly; initial CLI/test sources and static amendments are preserved.'}],
 'further_changes_requested':False,
 'actual_test_or_export_result_pending':True,
 'reviewed_module_imported_or_executed':False,'numerical_model_test_or_export_executed':False,
 'old_source_or_RHS_or_window_or_IVP_driver_replayed':False,
 'limits':['Static loader/run integration and source-byte/AST association only.',
           'Actual forbidden-import and hostile-context evidence belongs to the one planned targeted test run and subsequent sole export.',
           'No earlier parser controls, test suite, source evolution or numerical example is rerun by this review.'],
 'artifact_sha256':{'freeze_import_review.py':sha(Path(__file__))}
}
path=OUT/'import-boundary-review.json'
path.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'path':str(path),'sha256':sha(path),'status':'accepted'}))
