"""Freeze static rule/query/readback review without importing reviewed modules."""
import datetime
import hashlib
import json
from pathlib import Path

WORK=Path('/workspace/research_work/mitl-upstream-20261019T0810')
HERE=WORK/'independent-verification'
OUT=WORK/'oracle-review'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def load(path):
    return json.loads(path.read_text())

assert sha(HERE/'before_query_code_freeze.json')=='353ad66657a48d2d9600b270033612c944f33adfadaa984285128a6898cd633c'
assert sha(HERE/'effective_before_query_freeze.json')=='cf1a7f12679da45a66bbe9e9f8c443dfad9a49fc40c76cf3afdf73a06c7aea9e'
initial=load(HERE/'before_query_code_freeze.json')
effective=load(HERE/'effective_before_query_freeze.json')
assert effective['independent_numerical_calls_before_freeze']==effective['new_independent_query_calls_before_amendment']==0
for name,digest in initial['files_sha256'].items():
    assert sha(HERE/'source-versions/before-csv-field-cap'/name)==digest
for name,digest in effective['files_sha256'].items():
    assert sha(HERE/name)==digest
assert sha(OUT/'plan_review.json')=='999056c14d1e36ebbd865e4b6480565d43059085e48b5eec450c20680880b52c'
assert sha(WORK/'core-review/completion.json')=='99d166a32e7fe905e9113f5ecdd1f629d4cfd346df2111105e58a4f4e02266a7'
assert sha(WORK/'core-review/import-boundary-review.json')=='d6c127aa1bb0e5ba4fb0911384c0309e01ecc2cfc37949b24244c433c35d55d1'
assert not (HERE/'quadrature-initial').exists()
notes='''The full fresh independent reference, own-scale admission and saved JSON/CSV readback code has been read statically. Earlier draft mathematical bytes were compared by narrow diffs to their final freeze; the independent source is local and standard-library only, with no production or old source/window/IVP imports. Newton Legendre recurrence/derivative and mapped weights are distinct from production closed-form radicals. Explicit Decimal120/160 contexts and exact rational node evaluation leave finite monomial defects visible; nothing is normalized to the polynomial answer.

An independent ordinary power basis converts accepted cubic controls, restricts by exact affine substitution, differentiates M with respect to the restricted coordinate and directly integrates the six required products. There is no second duration factor. Exact attained restricted-endpoint temperatures supply the declared sampled excursion scale. Original control/domain/source/state/hash/support associations are independently checked. Zero measure has a separate honest algebra control; actual positive dataset skip catalogues are checked separately.

The saved production rule is consumed as finite data and its330 unique node fields are independently recomputed from the exact restricted polynomials. Two fresh Newton rules query those same66 supports independently for660 node evaluations. All990 new rational polynomial node operations are distinguished from zero source/RHS/window/old-grid/IVP calls; shared query and patch references do not trigger new state evaluation. Both Newton checkpoints are persisted before producer comparisons.

Actual binary weights, absolute times, temperature and independently projected expected-energy/cost fields are read as exact Fractions. Local time subtracts the exact query anchor. Patch number projects physical area times unprojected areal weight; its difference from area times rounded areal weight is retained separately. Expected energy versus2*kB times actual binary T is also retained separately. Exact target, finite-rule and represented phases, signed quantity/statistic defects, mixtures and width contrasts remain distinct and telescope without repairs.

All six planned admissions are enforced for source queries, patch views, gross aggregates and own raw/normalized width contrasts: finite rule versus exact target; represented versus finite; represented versus target; both independent rules versus exact target; and their finite reference change. Own temperature excursion/variance/covariance and width-contrast scales supplement gross budgets. Exact-zero unsupported differences reject without a dimensionful fallback. Future result claims remain confined to the accepted polynomial source; neither new window acquires continuous IVP accuracy or physical/transport acceptance.

The sole pre-first-query parser amendment raises the bounded CSV field cap to16MiB for complete nested node JSON cells and associates the effective source freeze. Initial files/freeze remain preserved. It changes no mathematical primitive, query, input, tolerance or producer output. No scientific module, quadrature, test, producer or verifier is executed by this review; actual saved result association remains pending.
'''
(OUT/'pre_run_review.md').write_text(notes)
record={
 'schema':'mitl-positive-boundary-static-query-code-review-v1','status':'accepted',
 'reviewed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'reviewed_source':str(HERE/'verify_boundary_quadrature.py'),
 'reviewed_source_sha256':sha(HERE/'verify_boundary_quadrature.py'),
 'original_code_freeze_sha256':sha(HERE/'before_query_code_freeze.json'),
 'effective_before_query_freeze_sha256':sha(HERE/'effective_before_query_freeze.json'),
 'reviewed_code_and_input_sha256':effective['files_sha256'],
 'prospective_plan_review_sha256':sha(OUT/'plan_review.json'),
 'core_static_review_sha256':sha(WORK/'core-review/completion.json'),
 'direct_import_boundary_review_sha256':sha(WORK/'core-review/import-boundary-review.json'),
 'producer_saved_report_sha256':sha(WORK/'producer/reference-run/report.json'),
 'actual_evaluation_budget':effective['actual_evaluation_budget'],
 'findings':[{'id':'bounded-complete-node-CSV-cells','status':'repaired_before_first_query',
  'origin':'Independent owner pre-query saved-format inspection.',
  'issue':'Complete nested node JSON cells exceed the Python CSV reader default field limit.',
  'correction':'A declared bounded16MiB field cap and effective byte manifest are frozen before the first numerical query, preserving original files; no equation/input/tolerance change.'}],
 'further_changes_requested':False,'new_query_output_existed_at_review':False,
 'scientific_module_imported':False,'numerical_models_or_tests_executed':False,
 'source_or_window_or_IVP_driver_replayed':False,'producer_or_verifier_executed':False,
 'actual_saved_result_review_pending':True,'host_budget_accepted':False,
 'read_only_filename_failure':{'log_sha256':'074abc0d3f9268fb6e7b238d19afe70398ee6b927336253655cd257f5172e16f',
  'reason':'Initial structure read named nonexistent saved_readback.py; corrected to the frozen saved_artifacts.py. No scientific call occurred.'},
 'limits':['Static mathematical/interface/claims and byte-association review only.',
  'Exact polynomial/rule/representation qualification is separate from inherited source/interpolation/IVP evidence.',
  'No physical species mass, velocity/position, flight, molecular-state, spectrum, Hall, FLASH, owner or host validation.'],
 'artifact_sha256':{name:sha(OUT/name) for name in ('freeze_code_review.py','pre_run_review.md',
   'freeze_plan_review.py','plan_review.json','mathematical-review-notes.md')}
}
path=OUT/'pre_run_code_review.json'
path.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'path':str(path),'sha256':sha(path),'status':'accepted'}))
