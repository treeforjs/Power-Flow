"""Bind actual saved numerical evidence by metadata/hash association only."""
import datetime
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

WORK=Path('/workspace/research_work/mitl-upstream-20261019T0810')
HERE=WORK/'independent-verification'
RESULTS=HERE/'quadrature-initial'
OUT=WORK/'oracle-review'
REPORT=RESULTS/'report.json'
PIN='6d03f54d412e98969978d8ca1daa81f0ea6317dbee352f561ae412f0e8cc4103'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def load(path):
    return json.loads(path.read_text())

assert sha(REPORT)==PIN
r=load(REPORT)
assert r['schema']=='mitl-independent-positive-boundary-quadrature-report-v1'
assert r['status']=='passed' and r['all_checks_passed'] is True
assert sha(HERE/'final_before_query_freeze.json')=='50dfcc061a9575edad75ef6988b42663d776987b8bf7617785b709dc1d59cc48'
final=load(HERE/'final_before_query_freeze.json')
assert r['source_sha256']==final['files_sha256']
for name,digest in r['source_sha256'].items():
    assert sha(HERE/name)==digest
for name,digest in r['artifact_sha256'].items():
    assert sha(RESULTS/name)==digest
assert len(r['checkpoint_sha256'])==2 and len(r['artifact_sha256'])==6
assert all(r['artifact_sha256'][name]==digest for name,digest in r['checkpoint_sha256'].items())
producer=WORK/'producer/reference-run'
assert sha(producer/'report.json')==r['producer_report_sha256']=='5fb0c7067016881296c853b5a702f362402e0fa620735c6bddb0e596406765f5'
assert sha(producer/'boundary_quadrature.json')==r['producer_result_sha256']=='da140ddd226ad746b5e6a94b06ddb71fdbd900705d5b13c4e0c7565a305dc8e3'
counts={'independent_Newton_precision_levels':2,'independent_Newton_node_evaluations':660,
 'provided_rule_node_field_recomputations':330,'total_new_rational_polynomial_node_evaluations':990,
 'independent_source_query_node_references_across_levels':1140,'producer_unique_supports':66,
 'producer_unique_nodes':330,'source_query_node_references':570,'patch_query_node_references':1140,
 'source_queries':6,'patch_queries':12,'aggregates':4,'contrasts':2,
 'old_source_evolution_RHS_window_export_reference_grid_IVP_calls':0}
assert r['new_work_counts']==counts
assert r['forbidden_model_or_numerical_package_imports']==[]
assert all(r[key] is False for key in ('new_query_IVP_error_qualified','host_budget_accepted','owner_implementation_verified'))
assert r['integer_codec']['decimal_digit_limit']==16384
assert r['integer_codec']['maximum_fraction_integer_digits_encoded']==4793
assert sha(WORK/'tests/completion.json')=='fc0e31a74ed0b7c8fee9592d66de9ab19430c103ef9867f3551719a3a7094c58'
assert sha(WORK/'tests/initial.xml')=='6ded07130dc38be74308c6b11b5105061945274e02fcc54e4aef34351ff27199'
tests=load(WORK/'tests/completion.json')
assert tests['status']=='passed' and tests['passing_test_cases']==52 and tests['failed_test_cases']==0 and tests['targeted_test_runs']==1
assert tests['legacy_modules_after_direct_core_import']==tests['hostile_context_subprocess_legacy_modules']==[]
assert tests['hostile_context_caller_restored'] is True and tests['forged_outer_declaration_rejections']==3
props={node.attrib['name']:node.attrib['value'] for node in ET.parse(WORK/'tests/initial.xml').getroot().findall('.//properties/property')}
assert props['legacy_modules_after_direct_core_import']==props['hostile_context_subprocess_legacy_modules']=='[]'
assert props['hostile_context_caller_restored']=='true' and props['forged_outer_declaration_rejections']=='3'
reviews={
 'core-review/completion.json':'99d166a32e7fe905e9113f5ecdd1f629d4cfd346df2111105e58a4f4e02266a7',
 'core-review/import-boundary-review.json':'d6c127aa1bb0e5ba4fb0911384c0309e01ecc2cfc37949b24244c433c35d55d1',
 'oracle-review/plan_review.json':'999056c14d1e36ebbd865e4b6480565d43059085e48b5eec450c20680880b52c',
 'oracle-review/pre_run_code_review.json':'c0d008cb84f5fd21ed5ff65f98e678775a2638516ca409df215d0138633190f1',
 'oracle-review/codec-review.json':'0b045299c7cefaaf04a2d8ec559920ef9f01650578b2f0f8fd3b234b5cd11b7f'}
for name,digest in reviews.items():
    assert sha(WORK/name)==digest
maxima={group:{phase:{key:value for key,value in record.items() if key!='exact_scaled_error'}
               for phase,record in phases.items()} for group,phases in r['maxima'].items()}
findings=[]
for path in ('core-review/completion.json','core-review/import-boundary-review.json',
             'oracle-review/pre_run_code_review.json','oracle-review/codec-review.json'):
    for item in load(WORK/path)['findings']:
        findings.append({**item,'origin_review':path})
notes='''The sole fresh independent saved-boundary pass declares all planned checks passed. The actual report, producer result/report, two Newton checkpoints and four exact/phase/statistic/projection diagnostic files are bound by immutable hashes. The earlier full code review and narrow integer-codec companion together identify the exact executed verifier bytes. No numerical comparison is repeated here.

The report declares66 unique supported pieces and330 production nodes, reused through570 source-query and1140 patch-node references. Its two independent Newton precision levels evaluate660 new polynomial nodes, while330 separate provided-rule field recomputations check the saved production fields:990 new rational polynomial node evaluations in total. All counts remain distinct from zero old source/RHS/window/IVP calls. Six source queries, twelve patch queries, four full aggregates and two signed width contrasts preserve all state, time, temperature, number, geometry and energy associations.

The report's largest own-contrast finite-rule discrepancy is about2.874e-81 against the prospectively frozen1e-60 budget. Its largest own-contrast binary/total discrepancy is about8.696e-14 against2e-10; the largest separately reported Newton ladder change across groups is about8.039e-120 against1e-100. These are observed finite-rule/representation comparisons with the exact polynomial source measure, not certified bounds, continuous-trajectory accuracy or physical uncertainty. Mean-temperature excursion, temperature variance/covariance and own width signals use their separately declared scales.

Actual binary expected-energy versus exact2*kB times binary temperature, and direct patch number projection versus area times rounded areal weight, remain explicit separate diagnostics. Exact quantity/statistic phase differences telescope without weight normalization. The actual encoder observed4793 Fraction integer digits, within the declared16384-digit standalone limit and beyond Python's original4300-digit default; no value was rounded or truncated to satisfy the codec.

The separately saved sole52-case target pass supplies actual empty legacy-package module lists in both its main process and fresh hostile-context subprocess. It records caller context restoration and three forged outer declaration rejections. Those results bind the previously static core and direct-import gates without rerunning tests. Two core guard issues, the package import boundary and the bounded CSV/integer codec issues were repaired before their first corresponding numerical evidence; initial frozen bytes and prior gate records remain preserved.

This final record is static mathematics/interface/claims review plus metadata and actual-result association only. No reviewed module, rule, polynomial query, test, producer or verifier is imported/executed by the reviewer. The scope is deterministic quadrature of accepted manufactured polynomial sources. New query IVP error remains unqualified; no physical water/material/ML, molecular-state/fragmentation data, mass/velocity/position sampling, flight, gap transport, spectrum, Hall, FLASH, owner or host acceptance is supplied.
'''
(OUT/'review.md').write_text(notes)
record={
 'schema':'mitl-positive-boundary-static-oracle-review-v1','status':'accepted',
 'reviewed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'reviewed_source':str(HERE/'verify_boundary_quadrature.py'),
 'reviewed_source_sha256':sha(HERE/'verify_boundary_quadrature.py'),
 'actual_report_path':str(REPORT),'actual_report_sha256':PIN,
 'owner_report_path':str(REPORT),'owner_report_sha256':PIN,
 'producer_report_sha256':r['producer_report_sha256'],'producer_result_sha256':r['producer_result_sha256'],
 'executed_reference_code_and_input_sha256':r['source_sha256'],
 'actual_reference_artifact_sha256':r['artifact_sha256'],
 'prior_static_review_sha256':reviews,
 'owner_report_observed_declarations':{key:r[key] for key in ('schema','status','all_checks_passed',
   'new_work_counts','exact_check_counts','integer_codec','new_query_IVP_error_qualified',
   'host_budget_accepted','owner_implementation_verified')},
 'owner_report_observed_maxima':maxima,
 'actual_target_tests':{'completion_sha256':sha(WORK/'tests/completion.json'),
   'JUnit_sha256':sha(WORK/'tests/initial.xml'),'passing_cases':52,'failed_cases':0,'target_runs':1,
   'legacy_module_lists':{'main':[],'hostile_context_subprocess':[]},
   'hostile_context_restored':True,'forged_outer_declaration_rejections':3},
 'actual_own_scale_phase_contrast_and_ladder_qualifications_read':True,
 'binary_energy_temperature_and_area_projection_diagnostics_preserved':True,
 'completed_report_bound_without_numerical_replay':True,
 'owner_report_numerics_recomputed_by_reviewer':False,
 'findings':findings,'further_changes_requested':False,
 'scientific_module_imported':False,'numerical_models_or_tests_executed':False,
 'source_or_window_or_IVP_driver_replayed':False,'producer_or_verifier_executed':False,
 'physical_parameters_validated':False,'host_budget_accepted':False,
 'qualification':r['qualification'],
 'artifact_sha256':{name:sha(OUT/name) for name in ('complete_review.py','review.md','freeze_plan_review.py',
   'plan_review.json','mathematical-review-notes.md','freeze_code_review.py','pre_run_code_review.json',
   'pre_run_review.md','freeze_codec_review.py','codec-review.json')}
}
path=OUT/'completion.json'
path.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'path':str(path),'sha256':sha(path),'status':'accepted','actual_report_sha256':PIN}))
