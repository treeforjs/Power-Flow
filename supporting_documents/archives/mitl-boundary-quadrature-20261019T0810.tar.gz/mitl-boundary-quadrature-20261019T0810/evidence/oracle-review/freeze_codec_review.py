"""Narrow static review of the standalone integer-string codec amendment."""
import datetime
import hashlib
import json
from pathlib import Path

WORK=Path('/workspace/research_work/mitl-upstream-20261019T0810')
HERE=WORK/'independent-verification'
OUT=WORK/'oracle-review'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def load(path):
    return json.loads(path.read_text())

assert sha(OUT/'pre_run_code_review.json')=='c0d008cb84f5fd21ed5ff65f98e678775a2638516ca409df215d0138633190f1'
assert sha(HERE/'final_before_query_freeze.json')=='50dfcc061a9575edad75ef6988b42663d776987b8bf7617785b709dc1d59cc48'
final=load(HERE/'final_before_query_freeze.json')
previous=load(HERE/'source-versions/before-integer-codec-cap/effective_before_query_freeze.json')
assert sha(HERE/'source-versions/before-integer-codec-cap/effective_before_query_freeze.json')=='cf1a7f12679da45a66bbe9e9f8c443dfad9a49fc40c76cf3afdf73a06c7aea9e'
assert sha(HERE/'source-versions/before-integer-codec-cap/verify_boundary_quadrature.py')=='4caba062e08110159018156ec428cf75c2c9fd25ba9ab72c1bd4024e2c46d1cc'
for name,digest in final['files_sha256'].items():
    assert sha(HERE/name)==digest
    if name!='verify_boundary_quadrature.py':
        assert digest==previous['files_sha256'][name]
assert final['new_query_calls_before_amendment']==0
assert final['mathematical_input_query_or_tolerance_change'] is False
assert not (HERE/'quadrature-initial').exists()
record={
 'schema':'mitl-positive-boundary-integer-codec-static-review-v1','status':'accepted',
 'reviewed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'original_full_code_review_sha256':sha(OUT/'pre_run_code_review.json'),
 'final_before_query_freeze_sha256':sha(HERE/'final_before_query_freeze.json'),
 'final_reviewed_source_sha256':sha(HERE/'verify_boundary_quadrature.py'),
 'final_code_and_input_sha256':final['files_sha256'],
 'review_checks':[
  'Only standalone integer-string cap, serialization-size reporting and final manifest filename changed; every mathematical/helper/input/tolerance byte remains identical to the accepted full review.',
  'The standalone main sets an explicit bounded16384-digit conversion limit before parsing/serializing reference values; the limit is not disabled or used to round/truncate exact values.',
  'Serialization records the largest Fraction integer representation seen by its encoder and the active cap. This is observed size evidence, not a certified worst-case bound.',
  'Prior full code review and initial/effective byte manifests remain immutable; the new query output directory is absent before this companion gate.'
 ],
 'findings':[{'id':'bounded-exact-Fraction-integer-serialization','status':'repaired_before_first_query',
  'issue':'High precision normalized contrast Fractions can exceed Python default4300-digit integer-string conversion support.',
  'correction':'Standalone cap16384 and actual encoder-size metadata are fixed before first numerical query, with prior accepted source bytes preserved.'}],
 'further_changes_requested':False,
 'reviewed_module_imported_or_executed':False,'numerical_query_test_or_producer_executed':False,
 'full_mathematical_review_repeated':False,'new_query_output_existed_at_review':False,
 'limits':['Narrow static codec/freeze diff review only; actual output size and numerical result remain pending.',
           'The serialization cap is a supported representation domain, not a mathematical accuracy or physical uncertainty claim.'],
 'artifact_sha256':{'freeze_codec_review.py':sha(Path(__file__))}
}
path=OUT/'codec-review.json'
path.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'path':str(path),'sha256':sha(path),'status':'accepted'}))
