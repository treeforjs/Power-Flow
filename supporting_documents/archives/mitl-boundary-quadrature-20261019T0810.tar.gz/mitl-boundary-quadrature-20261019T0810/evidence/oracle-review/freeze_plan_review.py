"""Raw-byte association of a prospective mathematical verification plan."""
import datetime
import hashlib
import json
from pathlib import Path
import sys

WORK = Path('/workspace/research_work/mitl-upstream-20261019T0810')
HERE = WORK/'independent-verification'
OUT = WORK/'oracle-review'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def load(path):
    return json.loads(path.read_text())

assert len(sys.argv) == 3, 'Supply the statically reviewed scale amendment path and expected SHA256.'
amendment = Path(sys.argv[1])
assert amendment.is_relative_to(HERE)
assert sha(amendment) == sys.argv[2]
assert sha(HERE/'oracle_plan.json') == '4e93481c8e2057318b4dbd294098c58379d0625864b2bc57f5ead0757bc7d7b3'
assert sha(HERE/'before_plan_freeze.json') == 'cfc88f549713d7873feedcc9f7a013aa52766675f69139b37b928cc220eb9cfb'
assert sha(HERE/'input_config.json') == '89d70d9f106dce164a749cd0789187cbf0023007624846f2229a2894f62f2691'
freeze = load(HERE/'before_plan_freeze.json')
assert freeze['new_boundary_or_independent_query_calls_before_freeze'] == 0
assert freeze['old_source_RHS_window_reference_driver_calls'] == 0
for name,digest in freeze['files_sha256'].items():
    assert sha(HERE/name) == digest
for role,item in freeze['accepted_source_inputs'].items():
    assert sha(Path(item['path'])) == item['sha256'], role
record = {
 'schema':'mitl-positive-boundary-oracle-plan-review-v1',
 'status':'plan_review_accepted_for_manufactured_verification',
 'reviewed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'plan_sha256':sha(HERE/'oracle_plan.json'),
 'before_plan_freeze_sha256':sha(HERE/'before_plan_freeze.json'),
 'input_config_sha256':sha(HERE/'input_config.json'),
 'scale_definition_amendment':str(amendment),'scale_definition_amendment_sha256':sha(amendment),
 'selected_proposal_sha256':sha(WORK/'selected-proposal.json'),
 'accepted_source_input_sha256':{role:item['sha256'] for role,item in freeze['accepted_source_inputs'].items()},
 'review_checks':[
  'Ideal GL5 degree-nine exactness covers all six required integrands, whose maximum degree is eight; finite Decimal rules are explicitly approximate.',
  'Production closed-form80 rule versus distinct Newton120/160 rule, exact ordinary-power antiderivatives and exact actual binary-field sums distinguish independent error layers.',
  'No second duration factor, no normalization or weight repair, exact total=finite-rule+projection signed defect closure.',
  'Query-start exact local-time anchor, direct joint t*T/covariance, exact area-once unprojected cache views and actual binary number weights are explicit.',
  'Actual weighted binary E_export and 2*kB times actual weighted binary T remain separate; D/I are explicit supplied costs, not residuals or activation-barrier debits.',
  'The exact attained restricted-piece endpoint temperature excursion is a declared sampled own scale, not a certified global cubic range. Unresolved zero excursion rejects without a floor.',
  'Own temperature variance/covariance and own width-contrast scales supplement gross checks; true-zero prediction and reference changes must vanish exactly.',
  'Finite-rule1e-60, independent ladder1e-100 and represented/total2e-10 thresholds, both new query bounds and reuse counts are prospective and fixed.',
  'Prior source/interpolation/old-query qualifications remain separate; no new IVP, physical, velocity, transport, spectra or owner/host claim.'
 ],
 'findings':[{'id':'temperature-excursion-scale-definition','status':'clarified_before_batch_and_queries',
  'issue':'The draft wording could imply the attained global range of a cubic with potentially irrational extrema.',
  'clarification':'Use exact attained values at every restricted-piece endpoint as a resolved sampled excursion; reject an unresolved zero span for nonconstant temperature.'}],
 'core_source_review_pending':True,'full_independent_code_review_pending':True,'actual_result_review_pending':True,
 'scientific_module_imported':False,'numerical_models_or_tests_executed':False,
 'old_source_or_window_or_IVP_driver_replayed':False,'new_boundary_or_reference_query_executed':False,
 'host_budget_accepted':False,
 'limits':['Static mathematical/method/fixture/threshold plan review and raw-byte association only.',
           'Finite-rule/projection qualification is against the accepted manufactured polynomial source measure.',
           'Source coefficients, state/geometry and full time/temperature mixture remain attached; no physical launch or host acceptance.'],
 'artifact_sha256':{'freeze_plan_review.py':sha(Path(__file__)),
   'mathematical-review-notes.md':sha(OUT/'mathematical-review-notes.md')}
}
(OUT/'plan_review.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'path':str(OUT/'plan_review.json'),'sha256':sha(OUT/'plan_review.json'),'status':record['status']}))
