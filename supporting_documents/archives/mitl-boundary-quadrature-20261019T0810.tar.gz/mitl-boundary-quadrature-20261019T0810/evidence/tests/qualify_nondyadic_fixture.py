"""Find a fixed synthetic projection-boundary control without importing a producer."""
from fractions import Fraction as F
import json
from pathlib import Path

# At v=1/2 the ideal GL5 weight is64/225 and dM/dv=15/4,
# giving areal weight16/15. Finite80-digit perturbations are far smaller
# than the binary-rounding margins checked here.
areal = F(16, 15)
found = []
for denominator in (3, 7, 10, 11, 13):
    for numerator in range(1, denominator):
        area = F(numerator, denominator)
        direct = float(area*areal)
        after_areal = float(area*F(float(areal)))
        if direct != after_areal:
            found.append({'area': str(area), 'direct': direct.hex(),
                          'after_projected_areal': after_areal.hex()})
assert found
record = {'schema': 'mitl-boundary-quadrature-nondyadic-fixture-qualification-v1',
          'ideal_center_areal_weight': str(areal), 'manufactured_algebra_only': True,
          'core_or_old_producer_imports': [], 'source_evolution_or_RHS_calls': 0,
          'candidate_differences': found}
out = Path(__file__).resolve().parent / 'nondyadic-fixture.json'
assert not out.exists()
out.write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
print(json.dumps(record, sort_keys=True))
