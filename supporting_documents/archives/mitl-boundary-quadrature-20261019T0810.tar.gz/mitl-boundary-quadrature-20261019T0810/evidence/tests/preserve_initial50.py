"""Preserve the unexecuted fifty-case plan before review/import amendments."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
TEST = Path('/workspace/Power-Flow/tests/test_boundary_quadrature.py')
assert hashlib.sha256(TEST.read_bytes()).hexdigest() == 'ba156e7261aa2a15a33173f295d06cbc95c6aec55d50f41b6ddc9ccdcabd3d0c'
versions = HERE / 'source-versions'
versions.mkdir(exist_ok=True)
pairs = [(versions / 'test_boundary_quadrature.initial50.py', TEST),
         (versions / 'plan.initial50.json', HERE / 'plan.json')]
for target, source in pairs:
    assert not target.exists()
    target.write_bytes(source.read_bytes())
record = {'schema': 'mitl-boundary-quadrature-unexecuted-plan-preservation-v1',
          'preserved_cases': 50, 'test_executions': 0,
          'amendments_pending': ['hostile caller Decimal context in fresh process',
                                 'forged outer admission declaration rejection',
                                 'direct-file loading and measured legacy-import boundaries'],
          'artifact_sha256': {str(target.relative_to(HERE)): hashlib.sha256(target.read_bytes()).hexdigest()
                              for target, _ in pairs}}
(HERE / 'preserved-initial50.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
print(json.dumps(record, sort_keys=True))
