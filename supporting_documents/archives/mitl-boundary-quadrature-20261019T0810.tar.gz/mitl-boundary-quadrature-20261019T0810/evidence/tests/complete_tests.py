"""Record successful new targeted-test evidence; never invoke numerical code."""
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

HERE = Path(__file__).resolve().parent
WORK = HERE.parent
REPO = Path('/workspace/Power-Flow')
gate = json.loads((HERE / 'run-gate.json').read_bytes())
source_paths = {
    'mhdlab/boundary_quadrature.py': REPO / 'mhdlab/boundary_quadrature.py',
    'tests/test_boundary_quadrature.py': REPO / 'tests/test_boundary_quadrature.py',
}
public_sha = {p: hashlib.sha256(f.read_bytes()).hexdigest() for p, f in source_paths.items()}
assert public_sha['mhdlab/boundary_quadrature.py'] == gate['core_sha256']
assert public_sha['tests/test_boundary_quadrature.py'] == gate['test_sha256']
entries = [json.loads(line) for line in (WORK / 'commands.jsonl').read_text().splitlines()]
runs = [r for r in entries if Path(r['log']).name == 'boundary-quadrature-tests-initial.log']
assert len(runs) == 1 and runs[0]['exit_code'] == 0
run = runs[0]
assert hashlib.sha256(Path(run['log']).read_bytes()).hexdigest() == run['log_sha256']
xml = ET.parse(HERE / 'initial.xml').getroot()
cases = list(xml.iter('testcase'))
assert len(cases) == 52
assert not list(xml.iter('failure')) and not list(xml.iter('error')) and not list(xml.iter('skipped'))
assert all('test_boundary_quadrature' in c.attrib.get('classname', '') for c in cases)
properties = {p.attrib['name']: p.attrib['value'] for p in xml.iter('property')}
assert json.loads(properties['legacy_modules_after_direct_core_import']) == []
assert json.loads(properties['hostile_context_subprocess_legacy_modules']) == []
assert properties['hostile_context_caller_restored'] == 'true'
assert properties['forged_outer_declaration_rejections'] == '3'
paths = [HERE / 'plan.json', HERE / 'plan.final52.json', HERE / 'preserved-initial50.json',
         HERE / 'run-gate.json', HERE / 'initial.xml',
         HERE / 'nondyadic-fixture.json', HERE / 'qualify_nondyadic_fixture.py',
         WORK / 'boundary-quadrature-tests-plan-freeze.log',
         WORK / 'boundary-quadrature-preserve-unexecuted50.log',
         WORK / 'boundary-quadrature-tests-preexecution-amendment.log',
         WORK / 'boundary-quadrature-nondyadic-fixture.log',
         WORK / 'boundary-quadrature-tests-run-gate.log', Path(run['log']),
         WORK / 'core-review/completion.json', WORK / 'core-review/import-boundary-review.json']
paths += sorted((HERE / 'source-versions').iterdir())
record = {
    'schema': 'mitl-boundary-quadrature-tests-v1', 'status': 'passed',
    'all_checks_passed': True, 'unique_new_test_cases': 52,
    'test_case_executions': 52, 'targeted_test_runs': 1,
    'passing_test_cases': 52, 'failed_test_cases': 0,
    'initial50_plan_executed': False, 'pre_execution_cases_added': 2,
    'old50_test_function_AST_unchanged_by_amendment': True,
    'legacy_modules_after_direct_core_import': [],
    'hostile_context_subprocess_legacy_modules': [],
    'hostile_context_caller_restored': True,
    'forged_outer_declaration_rejections': 3,
    'manufactured_polynomial_fixtures_only': True,
    'independent_rule_target_degrees': list(range(10)),
    'max_polynomial_integrand_degree': 8,
    'nondyadic_projection_boundary_control_passed': True,
    'canonical_E_and_actual_binary_T_relation_defect_retained': True,
    'total_defect_exactly_rule_plus_projection': True,
    'source_kinetic_truth_claimed': False,
    'actual_source_evolution_calls': 0, 'actual_source_RHS_calls': 0,
    'old_window_export_calls': 0, 'old_assembly_calls': 0,
    'old_test_suites_repeated': False, 'positive_old_source_admission_calls': 0,
    'physical_truth_verified': False, 'host_budget_accepted': False,
    'public_source_sha256': public_sha,
    'static_review_sha256': gate['static_review_sha256'],
    'import_boundary_review_sha256': gate['import_boundary_review_sha256'],
    'command': run['command'], 'cwd': run['cwd'], 'exit_code': 0,
    'log_sha256': run['log_sha256'], 'testcase_names': [c.attrib['name'] for c in cases],
    'artifact_sha256': {str(p.relative_to(WORK)): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths},
    'limits': [
        'Synthetic polynomial/rule targets test the new boundary algebra and projection semantics, not source kinetics.',
        'Actual accepted-source cache/geometry reuse is independently verified from the sole new export.',
        'No velocities, owner implementation, host-budget, fields, gap transport, physical material or spectra are supplied.',
    ],
}
target = HERE / 'completion.json'
assert not target.exists()
target.write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
print(json.dumps({'status': 'passed', 'unique_new_test_cases': 52,
                  'completion_sha256': hashlib.sha256(target.read_bytes()).hexdigest(),
                  'public_source_sha256': public_sha, 'log_sha256': run['log_sha256']}, sort_keys=True))
