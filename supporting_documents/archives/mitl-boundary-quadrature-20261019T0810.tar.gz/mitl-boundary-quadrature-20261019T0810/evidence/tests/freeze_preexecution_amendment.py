"""Bind new static-review guards and direct-file imports before first execution."""
import ast
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
TEST = Path('/workspace/Power-Flow/tests/test_boundary_quadrature.py')
INITIAL = HERE / 'source-versions/test_boundary_quadrature.initial50.py'
old_tree, tree = ast.parse(INITIAL.read_bytes()), ast.parse(TEST.read_bytes())
old_functions = {n.name: ast.dump(n, include_attributes=False) for n in old_tree.body if isinstance(n, ast.FunctionDef)}
functions = {n.name: ast.dump(n, include_attributes=False) for n in tree.body if isinstance(n, ast.FunctionDef)}
assert all(functions[name] == body for name, body in old_functions.items())
assert set(functions) - set(old_functions) == {
    '_record_import_boundary',
    'test_rule_ignores_hostile_caller_context_before_its_first_factory_call',
    'test_direct_source_outer_flags_and_provenance_reject_before_unusable_raw_data',
}
assert not any(isinstance(n, ast.ImportFrom) and n.module and n.module.startswith('mhdlab') for n in ast.walk(tree))
assert not any(isinstance(n, ast.Import) and any(a.name.startswith('mhdlab') for a in n.names) for n in ast.walk(tree))
hostile = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'test_rule_ignores_hostile_caller_context_before_its_first_factory_call')
script = next(ast.literal_eval(n.value) for n in hostile.body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'script' for t in n.targets))
child_tree = ast.parse(script)
assert not any(isinstance(n, ast.ImportFrom) and n.module and n.module.startswith('mhdlab') for n in ast.walk(child_tree))
assert 'spec_from_file_location' in script and 'forbidden_legacy_modules' in script
counts = {}
for node in tree.body:
    if not isinstance(node, ast.FunctionDef) or not node.name.startswith('test_'):
        continue
    count = 1
    for decorator in node.decorator_list:
        if isinstance(decorator, ast.Call) and isinstance(decorator.func, ast.Attribute) and decorator.func.attr == 'parametrize':
            values = decorator.args[1]
            count *= len(values.elts) if isinstance(values, (ast.List, ast.Tuple)) else len(range(*(ast.literal_eval(arg) for arg in values.args)))
    counts[node.name] = count
assert sum(counts.values()) == 52
record = json.loads((HERE / 'source-versions/plan.initial50.json').read_bytes())
record.update({
    'status': 'frozen_52_cases_pending_final_core_and_import_boundary_reviews',
    'test_sha256': hashlib.sha256(TEST.read_bytes()).hexdigest(),
    'planned_new_cases': 52, 'case_counts': counts,
    'pre_execution_amendment': {
        'new_cases': 2, 'old50_functions_AST_unchanged': True, 'prior_plan_executed': False,
        'initial50_test_sha256': hashlib.sha256(INITIAL.read_bytes()).hexdigest(),
        'initial50_plan_sha256': hashlib.sha256((HERE / 'source-versions/plan.initial50.json').read_bytes()).hexdigest(),
        'hostile_context': 'Fresh subprocess direct-loads the new core, then sets all Decimal traps, prec2/ROUND_UP/exponents[-2,2]/clamp1 before its first rule factory call. Context must remain unchanged and restore afterward.',
        'outer_declarations': 'Three invalid outer records: host true, owner true, blank provenance. Specific declaration errors must precede unrelated invalid raw-byte evidence.',
        'import_boundary': 'Target and child direct-load the sole new file with registered module identities. Actual forbidden legacy sys.modules lists must be empty and recorded in JUnit properties.',
        'production_or_test_calls_during_amendment': 0,
    },
    'first_run_gates': ['Final repaired core SHA', 'Actual saved static core acceptance',
                        'Actual saved direct-file import-boundary review matching test/core/CLI pins'],
})
out = HERE / 'plan.final52.json'
assert not out.exists()
out.write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
print(json.dumps({'planned_new_cases': 52, 'old50_functions_AST_unchanged': True,
                  'test_sha256': record['test_sha256'],
                  'plan_sha256': hashlib.sha256(out.read_bytes()).hexdigest(),
                  'core_or_test_executions': 0, 'legacy_package_imports_by_amendment': 0}, sort_keys=True))
