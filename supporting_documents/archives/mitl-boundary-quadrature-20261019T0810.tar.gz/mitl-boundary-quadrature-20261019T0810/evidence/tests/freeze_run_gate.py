"""Bind the new source, tests and actual saved review before first execution."""
import ast
import hashlib
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
REPO = Path('/workspace/Power-Flow')
core_sha, review_sha, import_review_sha = sys.argv[1:]
core = REPO / 'mhdlab/boundary_quadrature.py'
test = REPO / 'tests/test_boundary_quadrature.py'
review = HERE.parent / 'core-review/completion.json'
plan_path = HERE / 'plan.final52.json'
plan = json.loads(plan_path.read_bytes())
assert plan['planned_new_cases'] == 52
assert hashlib.sha256(test.read_bytes()).hexdigest() == plan['test_sha256']
assert hashlib.sha256(core.read_bytes()).hexdigest() == core_sha
assert hashlib.sha256(review.read_bytes()).hexdigest() == review_sha
review_record = json.loads(review.read_bytes())
assert core_sha in json.dumps(review_record)
import_review = HERE.parent / 'core-review/import-boundary-review.json'
assert hashlib.sha256(import_review.read_bytes()).hexdigest() == import_review_sha
import_record = json.loads(import_review.read_bytes())
assert core_sha in json.dumps(import_record) and plan['test_sha256'] in json.dumps(import_record)
ast.parse(core.read_bytes(), filename=str(core))
ast.parse(test.read_bytes(), filename=str(test))
target = HERE / 'run-gate.json'
assert not target.exists()
versions = HERE / 'source-versions'
versions.mkdir(exist_ok=True)
snapshots = {}
for name, source in (('boundary_quadrature.executed.py', core),
                     ('test_boundary_quadrature.executed.py', test)):
    saved = versions / name
    assert not saved.exists()
    saved.write_bytes(source.read_bytes())
    snapshots[str(saved.relative_to(HERE))] = hashlib.sha256(saved.read_bytes()).hexdigest()
record = {
    'schema': 'mitl-boundary-quadrature-test-run-gate-v1',
    'status': 'source_and_saved_static_review_byte_pins_bound',
    'core_sha256': core_sha, 'test_sha256': plan['test_sha256'],
    'static_review_sha256': review_sha, 'static_review_status': review_record['status'],
    'import_boundary_review_sha256': import_review_sha, 'import_boundary_review_status': import_record['status'],
    'plan_sha256': hashlib.sha256(plan_path.read_bytes()).hexdigest(),
    'snapshot_sha256': snapshots,
    'new_case_count': 52, 'tests_executed_by_gate': 0, 'core_imports_by_gate': 0,
}
target.write_text(json.dumps(record, sort_keys=True, indent=2) + '\n')
print(json.dumps(record, sort_keys=True))
