"""Freeze new algebra-only controls before any core or test execution."""
import ast
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = Path('/workspace/Power-Flow')
TEST = REPO / 'tests/test_boundary_quadrature.py'
API = HERE.parent / 'core/api-contract.json'
source = TEST.read_bytes()
tree = ast.parse(source, filename=str(TEST))
case_counts = {}
for node in tree.body:
    if not isinstance(node, ast.FunctionDef) or not node.name.startswith('test_'):
        continue
    count = 1
    for decorator in node.decorator_list:
        if isinstance(decorator, ast.Call) and isinstance(decorator.func, ast.Attribute) and decorator.func.attr == 'parametrize':
            values = decorator.args[1]
            if isinstance(values, (ast.List, ast.Tuple)):
                count *= len(values.elts)
            else:
                assert isinstance(values, ast.Call) and isinstance(values.func, ast.Name) and values.func.id == 'range'
                count *= len(range(*(ast.literal_eval(arg) for arg in values.args)))
    case_counts[node.name] = count
assert sum(case_counts.values()) == 50
assert [n.module for n in ast.walk(tree) if isinstance(n, ast.ImportFrom) and n.module.startswith('mhdlab')] == ['mhdlab.boundary_quadrature']
record = {
    'schema': 'mitl-boundary-quadrature-test-plan-v1',
    'status': 'frozen_pending_final_source_and_saved_static_review',
    'test_file': 'tests/test_boundary_quadrature.py',
    'test_sha256': hashlib.sha256(source).hexdigest(),
    'api_contract_sha256': hashlib.sha256(API.read_bytes()).hexdigest(),
    'planned_new_cases': 50, 'case_counts': case_counts,
    'fixtures': {
        'max_degree_eight': {
            'coordinate': 't=5+2u', 'cumulative_emission': '2+u+2u^2+u^3',
            'temperature': '10+u+u^2+u^3',
            'exact_raw_targets': {'number': '4', 'time_first': '31/6', 'time_second': '116/15',
                                  'temperature_first': '691/15', 'temperature_second': '224051/420',
                                  'time_temperature_joint': '12857/210'},
            'exact_covariance': '4337/10080',
            'exact_temperature_variance': '9199/12600',
            'target_derivation': 'Independent power-basis polynomial antiderivatives; no production polynomial/rule helper calls.',
        },
        'rule_targets': 'Independent ideal GL5 monomial targets integral0..1(v^k)=1/(k+1), degrees0..9.',
        'nondyadic_area': 'Area1/7; ideal center areal weight16/15. Direct0x1.3813813813814p-3 differs from rounded-areal-first0x1.3813813813813p-3.',
        'partial_support': 'u in[1/4,3/4], exact mass61/32, no additional duration multiplier.',
        'mixture': 'Second independent piece has globaltime+2 and temperature+4; summaries reanchor before moments and covariance.',
        'zero_mass': 'Flat cumulative controls; no nodes, reasoned skip catalogue, unavailable normalized statistics.',
        'source_rejection': 'Seven freshly constructed invalid in-memory documents with hash validation and parser-specific token rejections.',
    },
    'predeclared_budgets': {
        'rule_monomial_absolute_error': 'less than1e-70',
        'finite_rule_vs_polynomial_relative_raw_moment_error': 'less than1e-70',
        'represented_vs_polynomial_relative_raw_moment_error': 'less than1e-13',
        'exact_target_and_three_defect_layers': 'Exact Fraction equality; total=rule_generation+export_projection.',
        'actual_field_energy_consistency': 'E_export and2*kB*T_export are separate; exact weighted difference retained.',
    },
    'tests_executed_during_plan': 0, 'core_imports_during_plan': 0,
    'test_side_reference_production_helper_calls': 0,
    'actual_source_evolution_calls': 0, 'actual_source_RHS_calls': 0,
    'old_window_export_or_assembly_calls': 0, 'old_test_suites_repeated': False,
    'manufactured_polynomial_fixtures_only': True, 'source_kinetic_truth_claimed': False,
    'actual_export_cache_reuse_verification_owner': 'Separate sole saved-export and independent consumer evidence.',
    'first_run_gates': ['Final frozen new source SHA', 'Actual saved static review matching final source SHA'],
    'failure_policy': 'Preserve initial file/XML/logs; rerun only concretely changed failed checks, never unchanged passing cases.',
    'planned_command': [str(REPO / '.venv/bin/python'), '-W', 'error', '-m', 'pytest', '-q',
                        'tests/test_boundary_quadrature.py', '--junitxml=' + str(HERE / 'initial.xml')],
}
out = HERE / 'plan.json'
assert not out.exists()
out.write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
print(json.dumps({'case_count': 50, 'test_sha256': record['test_sha256'],
                  'plan_sha256': hashlib.sha256(out.read_bytes()).hexdigest(),
                  'core_imports': 0, 'test_executions': 0}, sort_keys=True))
