"""Freeze positive joint boundary-quadrature evidence without replaying source calculations."""
import datetime
import csv
import hashlib
import io
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tarfile
from xml.etree import ElementTree

from prepare_delivery import WORK, REPO, BASE, OUT, PUBLIC, WRAPPERS, clean_head, dependency_context, input_contract, command_snapshot_prefix, load, save, sha

TEXT_SUFFIXES = {'.py', '.json', '.jsonl', '.log', '.xml', '.md', '.txt', '.patch', '.sha256', '.yaml', '.csv'}
EVIDENCE_DIRS = ('core', 'core-review', 'producer', 'tests', 'independent-verification', 'oracle-review', 'next-upstream-selection', 'delivery-preparation', 'completion-preparation')
REPORT_PATHS = {
    'producer_run': 'producer/reference-run/report.json',
    'producer_completion': 'producer/completion.json',
    'input_guards': 'producer/input_guard_checks.json',
    'raw_config_binding': 'producer/raw_config_binding.json',
    'export_format_checks': 'producer/export_format_checks.json',
    'import_boundary_amendment': 'producer/import_boundary_amendment.json',
    'import_boundary_review': 'core-review/import-boundary-review.json',
    'producer_before_run': 'producer/freeze.json',
    'tests_completion': 'tests/completion.json',
    'core_freeze': 'core/source-freeze.json',
    'static_core_review': 'core-review/completion.json',
    'oracle_completion': 'independent-verification/completion.json',
    'oracle_report': 'independent-verification/quadrature-initial/report.json',
    'oracle_summary': 'independent-verification/summary.json',
    'oracle_review': 'oracle-review/completion.json',
    'root_result_association': 'root-result-association.json',
    'next_task_assessment': 'next-upstream-selection/assessment.json',
}

PROJECTIONS = (
    (bytes.fromhex('2f6f70742f636f6465782f72756e74696d65732f636f6465782d7072696d6172792d72756e74696d652f646570656e64656e636965732f707974686f6e'), b'[runtime Python directory]'),
    (bytes.fromhex('2f6574632f636f6465782f'), b'[runtime policy directory]/'),
)


def excluded(relative, allowed_figures=()):
    path = Path(relative)
    if 'delivery-preparation' in path.parts and 'payload' in path.parts:
        return True
    if any(part in {'__pycache__', '.pytest_cache', '.venv', 'source-local', 'fulltexts', 'raw-fulltexts',
                    'pytest-temp', 'pytest-tmp', 'test-fixtures', 'fixtures'}
           or part.startswith('.boundary-quadrature-') for part in path.parts):
        return True
    if path.suffix == '.pyc':
        return True
    if 'source-acquisition' in path.parts:
        return 'raw' in path.parts or path.suffix not in {'.json', '.jsonl', '.py', '.md', '.log', '.sha256'}
    if path.suffix.lower() in {'.png', '.pdf', '.jpg', '.jpeg', '.tif', '.tiff'}:
        return str(path) not in set(allowed_figures)
    return False


def verify_contracts(records, configured_inputs, *, work_sha=None, public_sha=None, work_bytes=None):
    """Check frozen metadata and byte identities without scientific imports."""
    h = work_sha or (lambda name: sha(WORK/name))
    p = public_sha or (lambda name: sha(REPO/name))
    b = work_bytes or (lambda name: (WORK/name).read_bytes())

    def artifacts(mapping, prefix=''):
        assert isinstance(mapping, dict) and mapping
        for name, digest in mapping.items():
            path = Path(name)
            assert not path.is_absolute() and '..' not in path.parts
            assert re.fullmatch('[0-9a-f]{64}', digest) and h(prefix+name) == digest

    def counts(record, expected):
        for key, value in expected.items():
            assert type(record[key]) is int and record[key] == value, key

    def reference(record):
        name = str(Path(record['path']).relative_to(WORK))
        assert h(name) == record['sha256']
        return name

    core_path = 'mhdlab/boundary_quadrature.py'
    test_path = 'tests/test_boundary_quadrature.py'
    cli_path = 'tools/export_boundary_quadrature.py'
    tests = records['tests_completion']
    assert tests['schema'] == 'mitl-boundary-quadrature-tests-v1'
    assert tests['status'] == 'passed' and tests['all_checks_passed'] is True
    counts(tests, {'unique_new_test_cases': 52, 'test_case_executions': 52, 'targeted_test_runs': 1,
        'passing_test_cases': 52, 'failed_test_cases': 0, 'pre_execution_cases_added': 2,
        'actual_source_evolution_calls': 0, 'actual_source_RHS_calls': 0,
        'old_assembly_calls': 0, 'old_window_export_calls': 0, 'positive_old_source_admission_calls': 0,
        'forged_outer_declaration_rejections': 3})
    assert tests['initial50_plan_executed'] is False and tests['old50_test_function_AST_unchanged_by_amendment'] is True
    assert tests['manufactured_polynomial_fixtures_only'] is True and tests['source_kinetic_truth_claimed'] is False
    assert tests['old_test_suites_repeated'] is False and tests['physical_truth_verified'] is False
    assert tests['legacy_modules_after_direct_core_import'] == tests['hostile_context_subprocess_legacy_modules'] == []
    assert tests['hostile_context_caller_restored'] is True and tests['host_budget_accepted'] is False
    assert tests['total_defect_exactly_rule_plus_projection'] is True
    assert tests['canonical_E_and_actual_binary_T_relation_defect_retained'] is True
    assert all(p(name) == digest for name, digest in tests['public_source_sha256'].items())
    artifacts(tests['artifact_sha256'])
    suites = list(ElementTree.fromstring(b('tests/initial.xml')).iter('testsuite'))
    assert sum(int(suite.attrib.get('tests', 0)) for suite in suites) == 52
    assert all(int(suite.attrib.get(key, 0)) == 0 for suite in suites for key in ('failures', 'errors', 'skipped'))
    core = records['core_freeze']
    assert core['schema'] == 'mhdlab-boundary-quadrature-source-freeze-v1'
    assert core['source_sha256'] == p(core_path) == core['source_snapshot_sha256']
    assert h(str(Path(core['source_snapshot']).relative_to(WORK))) == p(core_path)
    assert core['initial_source_sha256'] == h('core/boundary_quadrature.frozen.py')
    assert core['api_contract_sha256'] == h('core/api-contract.json')
    assert core['output_contract_sha256'] == h('core/output-contract.json')
    counts(core, {'author_numerical_evaluations': 0, 'author_numerical_imports': 0,
                  'old_source_RHS_assembly_window_or_IVP_calls': 0})
    static = records['static_core_review']
    assert static['schema'] == 'mitl-positive-boundary-static-core-review-v1' and static['status'] == 'accepted'
    assert static['reviewed_source_sha256'] == p(core_path)
    assert static['source_freeze_sha256'] == h(REPORT_PATHS['core_freeze'])
    assert static['source_input_sha256'] == {key: item['sha256'] for key, item in configured_inputs['accepted_source_binding']['files'].items()}
    assert len(static['findings']) == 2 and all(row['status'] == 'repaired_before_first_test_or_export' for row in static['findings'])
    for key in ('further_changes_requested', 'scientific_module_imported', 'numerical_models_or_tests_executed',
                'source_admission_or_quadrature_or_producer_executed', 'old_source_or_IVP_driver_replayed',
                'physical_parameters_validated', 'host_budget_accepted'):
        assert static[key] is False
    artifacts(static['artifact_sha256'], 'core-review/')
    artifacts(static['pre_test_repair_sha256'], 'core/')
    guards, raw_binding, formatting = records['input_guards'], records['raw_config_binding'], records['export_format_checks']
    assert guards['schema'] == 'mhdlab-boundary-quadrature-input-guards-v1' and guards['status'] == 'passed'
    assert guards['config_sha256'] == configured_inputs['config_sha256']
    assert guards['script_sha256'] == h('producer/source-versions/parser_checked_cli.py')
    counts(guards, {'checks_count': 19, 'rejected_count': 16, 'core_calls': 0})
    assert guards['scientific_modules_imported'] is False and guards['old_suites_or_numerical_cases_replayed'] is False
    assert raw_binding['schema'] == 'mhdlab-boundary-quadrature-raw-config-binding-v1' and raw_binding['status'] == 'passed'
    assert raw_binding['initial_cli_sha256'] == guards['script_sha256']
    assert raw_binding['checked_cli_sha256'] == h('producer/source-versions/raw_config_checked_cli.py')
    assert raw_binding['config_sha256'] == configured_inputs['config_sha256']
    counts(raw_binding, {'focused_checks': 2, 'core_calls': 0})
    assert raw_binding['load_config_validation_suffix_AST_identical'] is True
    assert raw_binding['initial_19_controls_not_repeated'] is True and raw_binding['scientific_modules_imported'] is False
    assert formatting['schema'] == 'mhdlab-boundary-quadrature-export-format-check-v1' and formatting['status'] == 'passed'
    assert formatting['cli_sha256'] == h('producer/source-versions/cli_before_direct_core_loader.py')
    counts(formatting, {'synthetic_format_rows': 2, 'core_calls': 0, 'initial_format_control_exit_code': 0})
    assert formatting['rational_and_signed_projection_fields_preserved'] is True
    assert formatting['explicit_null_and_availability_fields_preserved'] is True
    assert formatting['actual_float_csv_roundtrip_checked'] is True and formatting['scientific_modules_imported'] is False
    assert h('producer/'+formatting['initial_report_preserved']) != h(REPORT_PATHS['export_format_checks'])
    amendment, import_review = records['import_boundary_amendment'], records['import_boundary_review']
    assert amendment['schema'] == 'mhdlab-boundary-quadrature-import-boundary-amendment-v1'
    assert amendment['status'] == 'passed_static_AST_review_pending'
    assert amendment['initial_export_format_checked_cli_sha256'] == formatting['cli_sha256']
    assert amendment['final_cli_sha256'] == p(cli_path) and amendment['current_core_sha256'] == p(core_path)
    assert amendment['core_imports_are_stdlib_only'] is True and amendment['old_parser_and_format_controls_not_repeated'] is True
    assert amendment['core_imported_or_executed'] is False and amendment['old_scientific_modules_imported'] is False
    assert import_review['schema'] == 'mitl-positive-boundary-direct-import-static-review-v1' and import_review['status'] == 'accepted'
    assert import_review['cli_sha256'] == p(cli_path) and import_review['core_sha256'] == p(core_path)
    assert import_review['test_sha256'] == p(test_path)
    assert import_review['import_boundary_amendment_sha256'] == h(REPORT_PATHS['import_boundary_amendment'])
    assert import_review['further_changes_requested'] is False and import_review['reviewed_module_imported_or_executed'] is False
    assert import_review['old_source_or_RHS_or_window_or_IVP_driver_replayed'] is False
    artifacts(import_review['artifact_sha256'], 'core-review/')
    return verify_saved_export(records, configured_inputs, h, p, b, artifacts, counts, reference)


def csv_rows(data):
    """Read deliberately complete nested cells under the documented bounded cap."""
    previous = csv.field_size_limit()
    try:
        csv.field_size_limit(16*1024*1024)
        return list(csv.DictReader(io.StringIO(data.decode())))
    finally:
        csv.field_size_limit(previous)


def verify_saved_export(records, configured_inputs, h, p, b, artifacts, counts, reference):
    run, produced, before = records['producer_run'], records['producer_completion'], records['producer_before_run']
    assert run['schema'] == 'mhdlab-boundary-quadrature-export-run-v1'
    assert run['status'] == 'manufactured_saved_source_boundary_quadrature_only'
    assert run['config_sha256'] == configured_inputs['config_sha256']
    assert all(p(name) == digest for name, digest in run['code_sha256'].items())
    assert run['source_binding'] == configured_inputs['accepted_source_binding']
    for key in ('queries', 'method', 'quantity_contract', 'defect_contract'):
        assert run[key] == configured_inputs['configuration'][key]
    assert run['artifact_path_base'] == run['copied_source_path_base'] == 'directory containing report.json'
    prefix = 'producer/reference-run/'
    artifacts(run['artifact_sha256'], prefix)
    artifacts(run['copied_source_input_sha256'], prefix)
    expected_copies = {'source-inputs/'+item['relative_path']: item['sha256']
                       for item in configured_inputs['accepted_source_binding']['files'].values()}
    assert len(expected_copies) == 7 and run['copied_source_input_sha256'] == expected_copies
    assert load_json_bytes(b(prefix+'input_config.json')) == configured_inputs['configuration']
    expected_counts = {'piece_cache': 66, 'node_cache': 330, 'source_queries': 6, 'patch_queries': 12,
                       'aggregate_queries': 4, 'contrasts': 2, 'source_query_nodes': 570, 'patch_query_nodes': 1140}
    counts(run['record_counts'], expected_counts)
    result = load_json_bytes(b(prefix+run['result_file']))
    assert h(prefix+run['result_file']) == run['result_sha256']
    assert result['schema'] == 'mhdlab-boundary-quadrature-v1' and result['parameter_status'] == 'manufactured'
    assert result['host_budget_accepted'] is False and result['owner_implementation_verified'] is False
    assert result['new_query_IVP_error_qualified'] is False
    counts(result['cache'], {'unique_piece_supports': 66, 'unique_nodes': 330, 'source_queries': 6,
        'patch_queries': 12, 'aggregates': 4, 'contrasts': 2, 'source_query_node_references': 570,
        'patch_node_references': 1140, 'source_evolution_calls': 0, 'RHS_calls': 0, 'assembly_calls': 0,
        'old_window_export_calls': 0})
    assert result['cache'] == run['cache']
    total_rows = 0
    for section, number in expected_counts.items():
        rows = csv_rows(b(prefix+section+'.csv'))
        assert len(rows) == number and all(value != '' for row in rows for value in row.values())
        total_rows += len(rows)
        if section in result:
            assert len(result[section]) == number
    assert total_rows == 2130
    nodes = {node['node_id']: node for node in result['node_cache']}
    assert len(nodes) == 330 and all(node['binary']['number_weight_m2'] > 0 for node in nodes.values())
    assert all(node['binary']['temperature_k'] > 0 for node in nodes.values())
    assert all('translation_field_minus_temperature_energy_j' in node['energy_consistency'] for node in nodes.values())
    assert sum(len(row['summary']['nodes']) for row in result['source_queries']) == 570
    assert sum(len(row['summary']['nodes']) for row in result['patch_queries']) == 1140
    phases = {'target', 'finite_rule', 'represented', 'rule_generation_defect', 'export_projection_defect', 'total_defect'}
    for row in result['source_queries']:
        assert row['new_query_IVP_error_qualified'] is False
        assert row['local_time_anchor_exact_s'] == row['window_start_exact_s']
        assert phases <= set(row['summary'])
        assert 'local_time_temperature_moment_k_s' in row['summary']['represented']
        assert 'covariance_local_time_temperature_k_s' in row['summary']['statistics']['represented']
        assert all(node_id in nodes for node_id in row['node_ids'])
        assert row['parent_complete_source_window_key'].endswith('/complete_source_support')
    assert len(result['rule']['nodes']) == len(result['rule']['weights']) == 5 and result['rule']['precision'] == 80
    assert len(result['rule']['monomial_moment_defects']) == 10
    q = run['qualifications']
    counts(q, {'build_call_count': 1, 'old_source_evolution_RHS_assembly_window_export_reference_driver_calls': 0})
    assert q['forbidden_previous_math_or_source_modules_imported'] is False
    assert q['core_import_convention'] == 'dedicated_direct_file_module_bypasses_legacy_package_initializer'
    for key in ('source_input_hashes_rechecked_after_calculation', 'finite_Decimal_nodes_are_not_exact_algebraic_GL_nodes',
                'three_new_defect_layers_retained', 'inherited_source_and_IVP_errors_separate'):
        assert q[key] is True
    for key in ('weights_renormalized', 'new_query_IVP_reference_computed_here', 'position_or_velocity_sampling', 'actual_physical_or_spectral_claim'):
        assert q[key] is False
    assert produced['schema'] == 'mhdlab-boundary-quadrature-producer-completion-v1'
    assert produced['status'] == 'passed_saved_data_export_and_binary_field_readback'
    assert produced['report_path'] == REPORT_PATHS['producer_run'] and produced['report_sha256'] == h(produced['report_path'])
    assert produced['result_sha256'] == h(produced['result_path']) == run['result_sha256']
    assert produced['config_sha256'] == configured_inputs['config_sha256']
    assert all(p(name) == digest for name, digest in produced['public_source_sha256'].items())
    counts(produced, {'positive_saved_data_export_batches': 1, 'copied_source_file_count': 7,
                      'source_evolution_RHS_assembly_window_export_reference_driver_calls': 0})
    assert produced['record_counts'] == run['record_counts'] and produced['cache'] == result['cache']
    assert produced['copied_source_input_sha256'] == expected_copies
    assert produced['source_binding'] == configured_inputs['accepted_source_binding']
    assert produced['inherited_source_and_IVP_errors_separate'] is True
    for key in ('new_query_IVP_reference_computed_here', 'host_budget_accepted', 'owner_implementation_verified', 'old_suites_or_numerical_cases_replayed'):
        assert produced[key] is False
    assert produced['open_substantive_findings'] == [] and produced['artifact_path_base'] == 'pass directory containing producer/'
    artifacts(produced['artifact_sha256'])
    for gate in produced['accepted_prerequisites'].values():
        reference(gate)
    counts(produced['saved_readback'], {'summary_binary_field_moments': 242, 'exact_additive_defect_closures': 726,
        'independent_energy_consistency_checks': 88, 'normalized_joint_statistic_checks': 132,
        'scientific_module_imports_or_calls': 0})
    assert produced['saved_readback']['all_CSV_JSON_records_exactly_matched'] is True
    assert produced['saved_readback']['all_output_and_copied_input_hashes_matched'] is True
    assert produced['execution_lineage_sha256'] == h(produced['execution_lineage_path'])
    lineage = load_json_bytes(b(produced['execution_lineage_path']))
    assert lineage['executed_report_sha256'] == h(REPORT_PATHS['producer_run'])
    assert lineage['executed_code_sha256'] == run['code_sha256']
    assert lineage['initial_lease_baseline'] == BASE and lineage['HEAD_not_assumed_equal_to_initial_lease_baseline'] is True
    assert lineage['source_bytes_unchanged_after_export'] is True
    command = produced['batch']
    assert command['exit_code'] == 0 and h(str(Path(command['log']).relative_to(WORK))) == command['log_sha256']
    assert before['schema'] == 'mhdlab-boundary-quadrature-producer-freeze-v1'
    assert before['status'] == 'frozen_before_first_saved_data_quadrature_export'
    assert all(p(name) == digest for name, digest in before['public_source_sha256'].items())
    artifacts(before['source_snapshots_sha256'])
    for gate in before['actual_gate_bytes'].values():
        reference(gate)
    assert before['input_guard_sha256'] == h(REPORT_PATHS['input_guards'])
    assert before['raw_config_binding_sha256'] == h(REPORT_PATHS['raw_config_binding'])
    assert before['import_boundary_amendment_sha256'] == h(REPORT_PATHS['import_boundary_amendment'])
    assert before['import_boundary_review_sha256'] == h(REPORT_PATHS['import_boundary_review'])
    assert before['positive_exports_before_this_freeze'] == before['previous_numerical_model_imports_or_calls'] == 0
    return verify_independent_and_followup(records, configured_inputs, h, p, b, artifacts, counts, reference)


def verify_independent_and_followup(records, configured_inputs, h, p, b, artifacts, counts, reference):
    oracle, completion, summary = records['oracle_report'], records['oracle_completion'], records['oracle_summary']
    assert oracle['schema'] == 'mitl-independent-positive-boundary-quadrature-report-v1'
    assert completion['schema'] == 'mitl-independent-positive-boundary-quadrature-completion-v1'
    assert summary['schema'] == 'mitl-independent-positive-boundary-quadrature-summary-v1'
    assert all(row['status'] == 'passed' for row in (oracle, completion, summary))
    assert oracle['all_checks_passed'] is completion['all_checks_passed'] is True
    assert completion['report_sha256'] == summary['report_sha256'] == h(REPORT_PATHS['oracle_report'])
    assert completion['summary_sha256'] == h(REPORT_PATHS['oracle_summary'])
    assert oracle['producer_report_sha256'] == completion['producer_report_sha256'] == h(REPORT_PATHS['producer_run'])
    assert oracle['producer_result_sha256'] == records['producer_run']['result_sha256']
    expected_work = {'aggregates': 4, 'contrasts': 2, 'independent_Newton_node_evaluations': 660,
        'independent_Newton_precision_levels': 2, 'independent_source_query_node_references_across_levels': 1140,
        'old_source_evolution_RHS_window_export_reference_grid_IVP_calls': 0, 'patch_queries': 12,
        'patch_query_node_references': 1140, 'producer_unique_nodes': 330, 'producer_unique_supports': 66,
        'provided_rule_node_field_recomputations': 330, 'source_queries': 6,
        'source_query_node_references': 570, 'total_new_rational_polynomial_node_evaluations': 990}
    expected_checks = {'CSV': {'cells': 68864, 'rows': 2130, 'typed_float_projections': 18396},
        'actual_node_field_checks': 26220, 'contrast_exact_records': 176, 'patch_node_references': 1140,
        'primitive_cache_exact_field_checks': 5148, 'source_node_references': 570, 'summary_exact_records': 1936}
    for row in (oracle, completion, summary):
        assert row['new_work_counts'] == expected_work and row['exact_check_counts'] == expected_checks
        assert row['new_query_IVP_error_qualified'] is False
        assert row['integer_codec']['decimal_digit_limit'] == 16384
        assert row['integer_codec']['maximum_fraction_integer_digits_encoded'] == 4793
    counts(completion, {'completed_independent_runs': 1, 'independent_run_attempts': 1,
        'independent_checkpoints': 2, 'independent_polynomial_node_evaluations': 660,
        'provided_rule_field_recomputations': 330, 'total_new_rational_polynomial_node_evaluations': 990,
        'unique_production_nodes': 330, 'unique_supports': 66, 'distinct_source_queries': 6,
        'patch_queries': 12, 'aggregate_queries': 4, 'width_contrasts': 2,
        'source_node_references': 570, 'patch_node_references': 1140,
        'old_source_evolution_RHS_window_export_reference_grid_IVP_calls': 0})
    assert completion['independent_rule_precisions'] == [120, 160]
    for key in ('old_references_repeated', 'old_suites_repeated', 'host_budget_accepted',
                'owner_implementation_verified', 'physical_or_spectral_truth_validated'):
        assert completion[key] is False
    assert oracle['forbidden_model_or_numerical_package_imports'] == []
    assert oracle['host_budget_accepted'] is oracle['owner_implementation_verified'] is False
    artifacts(oracle['source_sha256'], 'independent-verification/')
    assert completion['source_sha256'] == oracle['source_sha256']
    artifacts(oracle['artifact_sha256'], 'independent-verification/quadrature-initial/')
    artifacts(oracle['checkpoint_sha256'], 'independent-verification/quadrature-initial/')
    assert len(oracle['checkpoint_sha256']) == 2
    artifacts(completion['artifact_sha256'])
    assert summary['maxima'] == oracle['maxima']
    query_run = completion['query_run']
    assert query_run['exit_code'] == 0 and h(str(Path(query_run['log']).relative_to(WORK))) == query_run['log_sha256']
    final_freeze = load_json_bytes(b('independent-verification/final_before_query_freeze.json'))
    artifacts(final_freeze['files_sha256'], 'independent-verification/')
    assert final_freeze['files_sha256'] == oracle['source_sha256']
    assert final_freeze['independent_numerical_calls_before_freeze'] == 0
    assert final_freeze['new_independent_query_calls_before_amendment'] == 0
    assert final_freeze['new_query_calls_before_amendment'] == 0
    assert final_freeze['mathematical_input_query_or_tolerance_change'] is False
    assert final_freeze['CSV_field_limit_bytes'] == 16*1024*1024
    assert final_freeze['integer_codec_amendment']['standalone_decimal_digit_limit'] == 16384
    review = records['oracle_review']
    assert review['schema'] == 'mitl-positive-boundary-static-oracle-review-v1' and review['status'] == 'accepted'
    assert reference({'path': review['actual_report_path'], 'sha256': review['actual_report_sha256']}) == REPORT_PATHS['oracle_report']
    assert completion['static_review_sha256'] == h(REPORT_PATHS['oracle_review'])
    assert review['producer_report_sha256'] == oracle['producer_report_sha256']
    assert review['producer_result_sha256'] == oracle['producer_result_sha256']
    assert review['executed_reference_code_and_input_sha256'] == oracle['source_sha256']
    assert review['actual_reference_artifact_sha256'] == oracle['artifact_sha256']
    artifacts(review['prior_static_review_sha256'])
    artifacts(review['artifact_sha256'], 'oracle-review/')
    assert review['actual_target_tests']['passing_cases'] == 52
    assert review['completed_report_bound_without_numerical_replay'] is True
    for key in ('further_changes_requested', 'scientific_module_imported', 'numerical_models_or_tests_executed',
                'source_or_window_or_IVP_driver_replayed', 'producer_or_verifier_executed',
                'physical_parameters_validated', 'host_budget_accepted', 'owner_report_numerics_recomputed_by_reviewer'):
        assert review[key] is False
    root = records['root_result_association']
    assert root['schema'] == 'mitl-positive-boundary-quadrature-root-result-association-v1'
    assert root['parameter_status'] == 'manufactured'
    assert set(root['public_source_sha256']) == set(PUBLIC)
    assert all(p(name) == digest for name, digest in root['public_source_sha256'].items())
    for key in ('producer_report', 'quadrature_document', 'oracle_report', 'oracle_review'):
        reference(root[key])
    assert root['guide']['sha256'] == p('docs/boundary_quadrature.md')
    assert root['record_counts'] == records['producer_run']['record_counts']
    assert root['cache'] == records['producer_run']['cache']
    assert root['new_work_counts'] == expected_work and root['exact_check_counts'] == expected_checks
    assert root['maximum_numerical_error_estimates'] == oracle['maxima']
    result = load_json_bytes(b('producer/reference-run/boundary_quadrature.json'))
    assert root['aggregate_queries'] == [
        {**{key: row[key] for key in ('hypothesis', 'query_id', 'state_id')},
         'summary': {key: value for key, value in row['summary'].items() if key != 'nodes'}}
        for row in result['aggregate_queries']]
    assert root['contrasts'] == result['contrasts']
    assert root['visual_review']['performed'] is False
    assessment = records['next_task_assessment']
    assert assessment['schema'] == 'mitl-next-upstream-task-assessment-v1' and assessment['status'] == 'assessment_complete'
    assert assessment['selected_task'] is None and assessment['followup_status'] == 'awaiting_receiver_contract_or_new_evidence'
    assert assessment['no_new_lease_claimed'] is True
    assert assessment['no_authorized_useful_unblocked_upstream_task_under_present_inputs'] is True
    assert assessment['preserved_queue_items_2_through_7'] == load_json_bytes(b('status-before-lease.json'))['next_work'][1:]
    for evidence in assessment['current_acceptance_evidence'].values():
        reference(evidence)
    request = assessment['record_references']['receiver_contract_request']
    assert reference(request) == 'next-upstream-selection/receiver-contract-request.md'
    assert assessment['assessment_source_sha256'] == h('next-upstream-selection/record_assessment.py')
    assert assessment['first_useful_interface_check']['external_request_sent'] is False
    assert assessment['new_source_acquisition_or_network_calls'] == assessment['source_or_test_or_oracle_or_owner_calls'] == 0
    assert assessment['public_files_changed'] == [] and assessment['live_status_changed'] is False
    relationships = {
        'core_pre_test_repairs': {'initial_source_sha256': records['core_freeze']['initial_source_sha256'],
            'final_source_sha256': p('mhdlab/boundary_quadrature.py'),
            'findings': records['static_core_review']['findings'], 'all_repairs_before_first_test_or_export': True},
        'tests': {'initial50_plan_executed': False, 'actual_final_source_cases': 52,
            'final_core_sha256': p('mhdlab/boundary_quadrature.py'), 'final_test_sha256': p('tests/test_boundary_quadrature.py')},
        'CLI_controls': {'initial_guard_CLI_sha256': records['input_guards']['script_sha256'],
            'raw_config_checked_CLI_sha256': records['raw_config_binding']['checked_cli_sha256'],
            'format_checked_CLI_sha256': records['export_format_checks']['cli_sha256'],
            'executed_final_CLI_sha256': p('tools/export_boundary_quadrature.py'),
            'initial_19_controls_not_repeated': True, 'import_review_sha256': h(REPORT_PATHS['import_boundary_review'])},
        'producer': {'readback_execution_qualification': records['producer_completion']['readback_execution_qualification'],
            'execution_lineage_sha256': records['producer_completion']['execution_lineage_sha256'],
            'observed_git_HEAD_after_export': records['producer_completion']['observed_git_HEAD_after_export'],
            'single_export_preserved': True, 'final_public_sources_equal_executed_sources': True},
        'independent': {'final_pre_query_freeze_sha256': h('independent-verification/final_before_query_freeze.json'),
            'original_pre_query_freeze_sha256': final_freeze['original_code_freeze_sha256'],
            'prior_effective_freeze_sha256': final_freeze['previous_effective_freeze_sha256'],
            'code_sha256': oracle['source_sha256'], 'reviewed_pre_query_repairs': review['findings'],
            'bounded_integer_codec': oracle['integer_codec'], 'single_new_quadrature_query_run': True,
            'old_source_or_IVP_replayed': False},
        'receiver': {'selected_task': None, 'followup_status': assessment['followup_status'],
            'existing_control_references': assessment['record_references'], 'no_new_lease': True},
    }
    results = {'new_tests_passed': 52, 'new_test_runs': 1, 'saved_export_batches': 1,
        'copied_source_inputs': 7, 'unique_supports': 66, 'unique_nodes': 330,
        'source_queries': 6, 'patch_queries': 12, 'aggregate_queries': 4, 'contrasts': 2,
        'source_node_references': 570, 'patch_node_references': 1140,
        'new_independent_runs': 1, 'independent_precision_levels': 2,
        'independent_checkpoints': 2, 'independent_Newton_node_evaluations': 660,
        'provided_rule_field_recomputations': 330, 'total_new_rational_polynomial_node_evaluations': 990,
        'CSV_rows_checked': 2130, 'CSV_cells_checked': 68864, 'typed_float_projections_checked': 18396,
        'summary_exact_records_checked': 1936, 'contrast_exact_records_checked': 176,
        'primitive_cache_exact_checks': 5148, 'actual_node_field_checks': 26220,
        'old_source_RHS_assembly_window_export_IVP_calls': 0, 'new_query_IVP_error_qualified': False,
        'host_budget_accepted': False, 'owner_implementation_verified': False, 'physical_truth_verified': False,
        'portable_execution_claimed': False, 'portable_executions_performed': False,
        'selected_task': None, 'new_lease_claimed': False}
    return {'results': results, 'source_version_relationships': relationships, 'allowed_figure_paths': []}


def load_json_bytes(data):
    from prepare_delivery import loads
    return loads(data)


def main():
    payload = WORK/'delivery-preparation/payload'
    preparation = load(payload/'preparation.json')
    head = clean_head(preparation['source_commit'])
    assert preparation['base_commit'] == BASE
    assert not OUT.exists() and not OUT.with_suffix('.tar.gz').exists()
    assert load(payload/'source_file_list.json') == {'byte_identical_public_files': list(PUBLIC), 'packaging_wrappers': list(WRAPPERS)}
    assert len(PUBLIC) == 5 and len(WRAPPERS) == 2
    assert {str(path.relative_to(payload/'source')) for path in (payload/'source').rglob('*') if path.is_file()} == set(PUBLIC)|set(WRAPPERS)
    assert not (payload/'source/mhdlab/__init__.py').exists()
    for name in PUBLIC:
        assert (payload/'source'/name).read_bytes() == (REPO/name).read_bytes()
    context = dependency_context()
    assert context == preparation['dependency_context'] == load(payload/'dependency_context.json')
    configured_inputs = input_contract()
    assert configured_inputs == preparation['input_contract']
    records = {key: load(WORK/name) for key, name in REPORT_PATHS.items()}
    contract = verify_contracts(records, configured_inputs)
    allowed_figures = contract['allowed_figure_paths']
    assessment = records['next_task_assessment']
    next_task = assessment['receiver_readback_need']
    assert isinstance(next_task, str) and next_task.strip()
    assert assessment['selected_task'] is None
    assert assessment['followup_status'] == 'awaiting_receiver_contract_or_new_evidence'
    shutil.copytree(payload, OUT)
    evidence = OUT/'evidence'
    evidence.mkdir()
    try:
        active_log = Path(os.readlink('/proc/self/fd/1')).resolve()
    except OSError:
        active_log = None
    copied_inputs, omitted, copied_root_files = [], [], []

    def copy(path, relative):
        assert not path.is_symlink()
        digest = sha(path)
        target = evidence/relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, target)
        assert sha(target) == digest
        copied_inputs.append({'source': str(path), 'archive': str(target.relative_to(OUT)), 'sha256': digest})

    for path in WORK.iterdir():
        if path.is_file() and path.suffix in TEXT_SUFFIXES and path.resolve() != active_log:
            copy(path, Path(path.name))
            copied_root_files.append(path.name)
    for folder in EVIDENCE_DIRS:
        for path in (WORK/folder).rglob('*'):
            assert not path.is_symlink()
            if not path.is_file():
                continue
            relative = path.relative_to(WORK)
            if excluded(relative, allowed_figures):
                omitted.append({'path': str(relative), 'sha256': sha(path), 'bytes': path.stat().st_size,
                    'reason': 'Cache, temporary fixture, failed staging data or unselected figure omitted from this new reference evidence.'})
            else:
                copy(path, relative)
    commands_raw = (evidence/'commands.jsonl').read_bytes()
    snapshot = command_snapshot_prefix(commands_raw, (WORK/'commands.jsonl').read_bytes())
    helper_pins = {name: sha(WORK/name) for name in ('prepare_delivery.py', 'freeze_delivery.py', 'verify_delivery.py', 'complete_pass.py')}
    projections = []
    for path in evidence.rglob('*'):
        if not path.is_file() or path.suffix not in TEXT_SUFFIXES:
            continue
        for prefix, replacement in PROJECTIONS:
            data = path.read_bytes()
            if prefix in data:
                assert replacement not in data
                path.write_bytes(data.replace(prefix, replacement))
                projections.append({'path': str(path.relative_to(OUT)), 'original_sha256': hashlib.sha256(data).hexdigest(),
                    'portable_sha256': sha(path), 'replacements': data.count(prefix), 'source_prefix_hex': prefix.hex(),
                    'replacement': replacement.decode(), 'scope': 'Archive-only machine-directory projection; local raw bytes unchanged.'})
    save(OUT/'portable_path_projections.json', projections)
    save(OUT/'excluded_evidence.json', omitted)
    with (OUT/'boundary-quadrature.patch').open('wb') as stream:
        subprocess.run(['git', 'diff', '--binary', BASE, head], cwd=REPO, stdout=stream, check=True)
    verification = {'schema': 'mitl-boundary-quadrature-verification-v1',
        'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'source_commit': head, 'base_commit': BASE, 'input_contract': configured_inputs,
        'dependency_context': context, 'package_kind': 'patch_over_exact_complete_baseline',
        'results': contract['results'], 'records': records, 'record_paths': REPORT_PATHS,
        'source_version_relationships': contract['source_version_relationships'],
        'record_sha256': {key: sha(WORK/name) for key, name in REPORT_PATHS.items()},
        'allowed_figure_paths': allowed_figures, 'copied_input_sha256': copied_inputs,
        'public_files_byte_identical': len(PUBLIC), 'packaging_wrappers': len(WRAPPERS),
        'commits': subprocess.check_output(['git', 'log', '--reverse', '--format=%H %s', BASE+'..'+head], cwd=REPO, text=True).splitlines(),
        'source_helper_sha256': helper_pins,
        'command_snapshot': {**snapshot, 'path': 'evidence/commands.jsonl',
            'copied_root_files': sorted(copied_root_files),
            'later_local_completion_repairs_may_exist': True,
            'historical_helper_policy': 'Archive helper bytes are immutable historical snapshots; later local repairs must explicitly bind them and preserve the initial failure.'},
        'next_task': next_task, 'selected_task': None,
        'followup_status': assessment['followup_status'],
        'limits': ['Manufactured saved-coefficient joint boundary quadrature for two new source-emission queries only.',
            'Exact polynomial targets, finite 80-digit quadrature-rule defects and actual exported defects in binary fields are separate.',
            'Inherited source and IVP/interpolation accuracy remains a distinct layer; no new IVP query accuracy is claimed.',
            'Positive joint time/temperature/state/number records do not constitute velocity or position sampling, physical molecular data or an owner solver.',
            'No old source, RHS, assembly, window export, old reference grid or IVP driver is replayed.',
            'Five-file patch requires the exact complete baseline. No standalone package, initializer workaround or portable execution is claimed.']}
    save(OUT/'verification.json', verification)
    save(OUT/'next_task.json', {'task': next_task, 'selected_task': None,
        'status': assessment['followup_status'], 'followup_status': assessment['followup_status'],
        'assessment_evidence': 'evidence/'+REPORT_PATHS['next_task_assessment']})
    (OUT/'systems-mitl-boundary-quadrature-10192026.md').write_text(f'''# Manufactured positive joint boundary quadrature

Five public files are byte-identical to `{head}`. Apply the patch over the
complete checkout at `{BASE}`. README/requirements are wrappers; no initializer
replacement, standalone package or portable execution is claimed.

The new handoff retains positive joint time, temperature, state and emitted
number records from accepted saved complete-support source coefficients.
Unique supports and nodes are distinct from source-query and patch references.
Exact polynomial targets, finite 80-digit rule defects and actual exported
defects in binary fields remain separate, with the inherited source accuracy layer
explicit. Independent higher-precision quadrature and power-basis checks concern
this finite data representation; no new IVP reference is claimed.

No source, RHS, assembly, window export, old reference grid or IVP driver is
replayed. No velocity or position samples, physical material/water/monolayer,
observed spectrum, gap, FLASH or host validation are supplied.

Commands form an immutable complete-record byte prefix; later verification and
completion commands may append. Archived helper hashes are historical snapshots;
any later local repair must preserve its initial failure and bind that archived
hash. Reversible machine-directory projections leave raw local evidence unchanged.
Assembly runs no scientific model, test suite or portable environment.

Awaiting input: {next_task}
No new task or lease is selected by this delivery.
''')
    manifest = {str(path.relative_to(OUT)): sha(path) for path in OUT.rglob('*') if path.is_file() and path.name != 'manifest.sha256.json'}
    save(OUT/'manifest.sha256.json', manifest)
    words = [bytes.fromhex(value).decode() for value in ('6f70656e6169', '63686174677074', '636c61756465', '636f646578')]
    prohibited = re.compile(r'\b(?:'+'|'.join(words)+r')\b', re.I)
    allowed_archive_figures = {'evidence/'+name for name in allowed_figures}
    for path in OUT.rglob('*'):
        assert not path.is_symlink()
        if path.is_file():
            assert not excluded(path.relative_to(OUT), allowed_archive_figures)
            if path.suffix in TEXT_SUFFIXES:
                assert not prohibited.search(path.read_text()), str(path)
    clean_head(head)
    assert all(sha(REPO/name) == preparation['public_source_sha256'][name] for name in PUBLIC)
    assert all(sha(Path(item['source'])) == item['sha256'] for item in copied_inputs
               if item['archive'] != 'evidence/commands.jsonl')
    assert all(sha(WORK/item['path']) == item['sha256'] for item in omitted)
    assert all(sha(WORK/name) == digest for name, digest in helper_pins.items())
    command_snapshot_prefix(commands_raw, (WORK/'commands.jsonl').read_bytes())
    archive = OUT.with_suffix('.tar.gz')
    with tarfile.open(archive, 'w:gz') as tar:
        tar.add(OUT, arcname=OUT.name)
    record = {'folder': str(OUT), 'archive': str(archive), 'sha256': sha(archive), 'bytes': archive.stat().st_size,
        'source_commit': head, 'base_commit': BASE, 'manifest_entries': len(manifest),
        'public_files_byte_identical': len(PUBLIC), 'packaging_wrappers': len(WRAPPERS),
        'manifest_sha256': sha(OUT/'manifest.sha256.json'), 'verification_sha256': sha(OUT/'verification.json')}
    save(WORK/'frozen_delivery.json', record)
    print(json.dumps(record, indent=2))


if __name__ == '__main__':
    main()
