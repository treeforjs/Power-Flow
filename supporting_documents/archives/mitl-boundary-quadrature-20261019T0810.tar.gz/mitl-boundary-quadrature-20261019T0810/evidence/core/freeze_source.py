"""Syntax-only freeze of the new boundary reference and declaration contract."""
from pathlib import Path
import ast
import hashlib
import json

ROOT = Path('/workspace/Power-Flow')
WORK = Path('/workspace/research_work/mitl-upstream-20261019T0810/core')
SOURCE = ROOT / 'mhdlab/boundary_quadrature.py'
raw = SOURCE.read_bytes()
compile(raw, str(SOURCE), 'exec')
tree = ast.parse(raw)
imports = sorted({node.module if isinstance(node, ast.ImportFrom) else alias.name
                  for node in ast.walk(tree) if isinstance(node, (ast.Import, ast.ImportFrom))
                  for alias in node.names})
assert not any(name.startswith(('mhdlab', 'numpy', 'scipy', 'h5py')) for name in imports)
assert not any(line.rstrip() != line for line in raw.decode().splitlines())
snapshot = WORK / 'boundary_quadrature.frozen.py'
assert not snapshot.exists()
snapshot.write_bytes(raw)
contract = {
    'schema': 'mhdlab-boundary-quadrature-output-contract-v1',
    'rule': {'nodes': 'five canonical rational records', 'weights': 'five canonical rational records',
             'monomial_moment_defects': 'ten exact/value/projection records, degree0 through9'},
    'piece_cache': ['piece_id','source_history_id','state_id','source_cell_index','start_exact_s','stop_exact_s',
                    'emitted_controls_m2','temperature_controls_k','source_start_exact_s','source_stop_exact_s',
                    'source_emitted_controls_m2','source_temperature_controls_k','node_ids','skip_reason'],
    'node_cache': {'keys': ['node_id','piece_id','node_index','coordinate_exact','unprojected','binary','energy_consistency'],
                   'unprojected': ['number_weight_m2','time_s','temperature_k','expected_translational_energy_j'],
                   'binary': ['number_weight_m2','time_s','temperature_k','expected_translational_energy_j','desorption_energy_j','internal_energy_j'],
                   'energy_consistency': ['translation_field_minus_temperature_energy_j']},
    'source_queries': ['source_history_id','query_id','state_id','window_start_exact_s','window_stop_exact_s',
                       'local_time_anchor_exact_s','piece_ids','node_ids','summary','canonical_history_sha256',
                       'raw_history_file_sha256','parent_complete_source_window_key','parent_source_RK_comparison',
                       'parent_independent_window_reference','new_query_IVP_error_qualified'],
    'patch_queries': ['hypothesis','patch_index','source_history_id','query_id','state_id','geometry','source_query_key','summary'],
    'geometry': ['width_start_exact_m','width_stop_exact_m','length_exact_m','area_exact_m2'],
    'aggregate_queries': ['hypothesis','query_id','state_id','patch_query_indices','summary'],
    'contrasts': {'keys': ['query_id','phase_difference_nonuniform_minus_uniform',
                            'statistics_difference_nonuniform_minus_uniform','energy_consistency_difference'],
                  'phase_difference_nonuniform_minus_uniform': 'six phases -> eleven quantity exact/value/projection records',
                  'statistics_difference_nonuniform_minus_uniform': 'target/finite_rule/represented -> six available/reason/record wrappers'},
    'summary': 'api-contract.json plus component_areas_exact_m2 on combined summaries; area_exact_m2 is assigned by explicit physical context',
    'node_view_context': 'source and patch summary node rows carry view_id/source_history_id/query_id; patch adds hypothesis/patch_index',
    'cost_input': 'Fraction of parsed original JSON binary64 D/I in eV, multiplied by exact SI elementary charge',
    'actual_local_time': 'Fraction(actual binary global time_s) minus exact query anchor; no second binary local-time input',
    'representation': 'All unprojected node fields and coordinates are canonical numerator/denominator records; binary fields are actual floats.',
    'new_query_IVP_error_qualified': False,
}
(WORK/'output-contract.json').write_text(json.dumps(contract,indent=2,sort_keys=True)+'\n')
record = {
    'schema': 'mhdlab-boundary-quadrature-source-freeze-v1',
    'status': 'source_frozen_before_tests_static_review_and_boundary_export',
    'source_path': str(SOURCE), 'source_sha256': hashlib.sha256(raw).hexdigest(),
    'source_snapshot': str(snapshot), 'source_snapshot_sha256': hashlib.sha256(snapshot.read_bytes()).hexdigest(),
    'api_contract_sha256': hashlib.sha256((WORK/'api-contract.json').read_bytes()).hexdigest(),
    'output_contract_sha256': hashlib.sha256((WORK/'output-contract.json').read_bytes()).hexdigest(),
    'imports': imports, 'syntax_compilation_passed': True,
    'author_numerical_imports': 0, 'author_numerical_evaluations': 0,
    'old_source_RHS_assembly_window_or_IVP_calls': 0,
    'supported_domain': ['manufactured monotone emitted cubic and positive temperature controls',
                         'finite positive represented node fields and strictly interior distinct binary node clocks',
                         'bounded Fraction arithmetic and strict finite canonical JSON',
                         'one explicitly hash-bound accepted saved-source bundle'],
}
(WORK/'source-freeze.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
print(json.dumps(record,sort_keys=True))
