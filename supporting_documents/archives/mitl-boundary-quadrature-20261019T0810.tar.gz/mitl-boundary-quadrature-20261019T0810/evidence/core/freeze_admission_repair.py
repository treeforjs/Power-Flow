"""Freeze the source-only outer admission guard after the context repair."""
from pathlib import Path
import ast
import difflib
import hashlib
import json

W=Path('/workspace/research_work/mitl-upstream-20261019T0810/core')
P=Path('/workspace/Power-Flow/mhdlab/boundary_quadrature.py')
previous=(W/'boundary_quadrature.frozen-context-repair.py').read_text()
final=P.read_text()
oldtree,newtree=ast.parse(previous),ast.parse(final)
def functions(tree):
    return {n.name:ast.dump(n,include_attributes=False) for n in tree.body
            if isinstance(n,(ast.FunctionDef,ast.ClassDef))}
old,new=functions(oldtree),functions(newtree)
changed={k for k in old if old[k]!=new[k]}
added=set(new)-set(old)
assert changed=={'admit_boundary_source','build_boundary_quadrature'}
assert added=={'_admission_metadata'}
assert set(old)-set(new)==set()
compile(final,str(P),'exec')
snapshot=W/'boundary_quadrature.frozen-admission-repair.py'
assert not snapshot.exists()
snapshot.write_text(final)
(W/'admission-repair.diff').write_text(''.join(difflib.unified_diff(previous.splitlines(True),final.splitlines(True),fromfile='context_fixed',tofile='admission_fixed')))
prior=(W/'source-freeze.json').read_bytes()
(W/'source-freeze.context-repair.json').write_bytes(prior)
record=json.loads(prior)
record.update(source_sha256=hashlib.sha256(P.read_bytes()).hexdigest(),source_snapshot=str(snapshot),
              source_snapshot_sha256=hashlib.sha256(snapshot.read_bytes()).hexdigest(),
              admission_repair='Canonical outer declaration replay with strict aliases; no polynomial, rule or projection algorithm changes.')
(W/'source-freeze.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
repair={'schema':'mhdlab-boundary-admission-declaration-repair-v1',
        'previous_source_sha256':hashlib.sha256(previous.encode()).hexdigest(),
        'final_source_sha256':record['source_sha256'],'changed_AST_functions':sorted(changed),'added_AST_functions':sorted(added),
        'syntax_and_AST_scope_checks_passed':True,'diff_sha256':hashlib.sha256((W/'admission-repair.diff').read_bytes()).hexdigest(),
        'numerical_calls':0,'numerical_imports':0,'test_or_producer_runs_before_repair':0}
(W/'admission-repair.json').write_text(json.dumps(repair,indent=2,sort_keys=True)+'\n')
print(json.dumps(repair,sort_keys=True))
