"""Preserve the initial source and freeze only the explicit Decimal context fix."""
from pathlib import Path
import ast
import difflib
import hashlib
import json

W = Path('/workspace/research_work/mitl-upstream-20261019T0810/core')
P = Path('/workspace/Power-Flow/mhdlab/boundary_quadrature.py')
initial = (W/'boundary_quadrature.frozen.py').read_text()
final = P.read_text()
expected = initial.replace('from decimal import Decimal, localcontext, ROUND_HALF_EVEN',
    'from decimal import Context, Decimal, DivisionByZero, InvalidOperation, Overflow, localcontext, ROUND_HALF_EVEN')
expected = expected.replace('    with localcontext() as context:\n        context.prec = 80\n        context.rounding = ROUND_HALF_EVEN\n        context.Emin, context.Emax = -10000, 10000\n',
    '    deterministic = Context(prec=80, rounding=ROUND_HALF_EVEN, Emin=-10000, Emax=10000,\n                            capitals=1, clamp=0, flags=[],\n                            traps=[InvalidOperation, DivisionByZero, Overflow])\n    with localcontext(deterministic):\n')
assert final == expected
compile(final, str(P), 'exec')
ast.parse(final)
snapshot = W/'boundary_quadrature.frozen-context-repair.py'
assert not snapshot.exists()
snapshot.write_text(final)
(W/'context-repair.diff').write_text(''.join(difflib.unified_diff(initial.splitlines(True),final.splitlines(True),fromfile='initial',tofile='final')))
oldfreeze = (W/'source-freeze.json').read_bytes()
(W/'source-freeze.initial.json').write_bytes(oldfreeze)
record = json.loads(oldfreeze)
record.update(source_sha256=hashlib.sha256(P.read_bytes()).hexdigest(),source_snapshot=str(snapshot),
              source_snapshot_sha256=hashlib.sha256(snapshot.read_bytes()).hexdigest(),
              initial_source_sha256=hashlib.sha256(initial.encode()).hexdigest(),
              context_repair='Only Decimal imports and deterministic explicit Context; no scientific invocation or algorithm/tolerance change.')
(W/'source-freeze.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
repair = {'schema':'mhdlab-boundary-decimal-context-repair-v1',
          'initial_source_sha256':hashlib.sha256(initial.encode()).hexdigest(),
          'final_source_sha256':record['source_sha256'],
          'exact_text_replacement_check':True,'syntax_and_AST_checks_passed':True,
          'diff_sha256':hashlib.sha256((W/'context-repair.diff').read_bytes()).hexdigest(),
          'numerical_imports':0,'numerical_calls':0,'test_or_producer_runs_before_repair':0}
(W/'context-repair.json').write_text(json.dumps(repair,indent=2,sort_keys=True)+'\n')
print(json.dumps(repair,sort_keys=True))
