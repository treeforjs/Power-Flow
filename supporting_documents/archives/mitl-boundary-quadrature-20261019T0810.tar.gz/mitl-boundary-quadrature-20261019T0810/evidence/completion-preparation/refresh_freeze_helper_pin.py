"""Refresh only the corrected pure-metadata freezer pin; preserve initial evidence."""
import ast
import hashlib
import json
from pathlib import Path

WORK=Path(__file__).resolve().parent.parent
HERE=WORK/'completion-preparation'
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

status=WORK.parent/'mitl-upstream-status.json';status_before=sha(status)
contract_path=HERE/'contract.json';old_raw=contract_path.read_bytes()
assert hashlib.sha256(old_raw).hexdigest()=='6e24c00a5f44ad261f858b99b42969f66b53dbb160f74d4a1663f6eb8f8ccd7d'
old=json.loads(old_raw)
correction_path=WORK/'delivery-preparation/compact-aggregate-correction.json'
assert sha(correction_path)=='fe2c2a2c21ad054d57b86a9dc773d174a9fc9151abeae170fcd95e7d1d97bdd6'
correction=json.loads(correction_path.read_bytes())
assert correction['status']=='passed_focused_metadata_check'
assert correction['only_two_assertions_changed_AST_proof'] is True
assert correction['scientific_model_or_core_or_test_or_oracle_calls']==0
assert correction['delivery_helpers_imported_or_executed'] is False
assert sha(WORK/correction['failed_log'])==correction['failed_log_sha256']
assert correction['failed_log_sha256']=='b813a9bcab78343b7a18557d8ab24220c705a80e8e8005c81605d5a882d11e0d'
assert sha(WORK/'delivery-preparation/freeze_delivery.before_compact_aggregate_fix.py')==correction['initial_freeze_helper_sha256']
assert old['metadata_helpers_sha256']['freeze_delivery.py']==correction['initial_freeze_helper_sha256']
assert sha(WORK/'freeze_delivery.py')==correction['corrected_freeze_helper_sha256']=='6ab6595ea0b2c26c0643381947fc21257b6968311b174d6cbc20c0cc6be075ed'
ast.parse((WORK/'freeze_delivery.py').read_bytes(),filename='freeze_delivery.py')
for name in ('prepare_delivery.py','verify_delivery.py'):
    assert sha(WORK/name)==old['metadata_helpers_sha256'][name]
assert sha(WORK/'complete_pass.py')=='c5ed24d505738ecc5fe23381832e7e662ebb707212071f1adc5cf1ff4c35a0dc'
historical_contract=HERE/'contract.before-compact-aggregate-fix.json'
historical_readiness=HERE/'AST-readiness.before-compact-aggregate-fix.json'
assert not historical_contract.exists() and not historical_readiness.exists()
historical_contract.write_bytes(old_raw)
historical_readiness.write_bytes((HERE/'AST-readiness.json').read_bytes())
updated=json.loads(old_raw)
updated['metadata_helpers_sha256']['freeze_delivery.py']=correction['corrected_freeze_helper_sha256']
for key in old:
    if key!='metadata_helpers_sha256':
        assert updated[key]==old[key]
assert {k:v for k,v in updated['metadata_helpers_sha256'].items() if k!='freeze_delivery.py'}=={
    k:v for k,v in old['metadata_helpers_sha256'].items() if k!='freeze_delivery.py'}
contract_path.write_text(json.dumps(updated,indent=2,allow_nan=False)+'\n')
assert sha(status)==status_before
result={
    'schema':'mitl-boundary-completion-freezer-pin-correction-v1',
    'status':'passed_focused_metadata_pin_refresh',
    'only_current_contract_change':'metadata_helpers_sha256.freeze_delivery.py',
    'initial_contract_sha256':hashlib.sha256(old_raw).hexdigest(),
    'corrected_contract_sha256':sha(contract_path),
    'initial_contract_path':str(historical_contract.relative_to(WORK)),
    'initial_AST_readiness_path':str(historical_readiness.relative_to(WORK)),
    'original_AST_readiness_unchanged':sha(historical_readiness)==sha(HERE/'AST-readiness.json'),
    'initial_AST_contract_reference_resolves_to_preserved_historical_contract':True,
    'initial_freeze_sha256':correction['initial_freeze_helper_sha256'],
    'corrected_freeze_sha256':correction['corrected_freeze_helper_sha256'],
    'correction_record_sha256':sha(correction_path),
    'failed_freeze_log_sha256':correction['failed_log_sha256'],
    'public_report_result_and_record_contract_fields_unchanged':True,
    'complete_pass_source_unchanged':True,'delivery_helpers_imported_or_executed':False,
    'scientific_core_test_or_oracle_calls':0,
    'status_before_sha256':status_before,'status_after_sha256':sha(status),
    'artifact_sha256':{str(p.relative_to(WORK)):sha(p) for p in
        (historical_contract,historical_readiness,contract_path,HERE/'refresh_freeze_helper_pin.py')},
}
out=HERE/'freeze-helper-pin-correction-readiness.json'
assert not out.exists()
out.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps(result,indent=2))
