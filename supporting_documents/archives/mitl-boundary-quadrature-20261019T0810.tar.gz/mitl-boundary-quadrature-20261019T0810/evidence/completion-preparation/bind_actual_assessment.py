"""Apply only actual assessment keys to the unexecuted completion draft."""
import hashlib
import json
from pathlib import Path

WORK=Path(__file__).resolve().parent.parent
helper=WORK/'complete_pass.py'
original=helper.read_bytes()
assert hashlib.sha256(original).hexdigest()=='0baa711ace278ece22ec535644822fbaec47a1d09ac8c882556ba495adbae09c'
assessment=WORK/'next-upstream-selection/assessment.json'
assert hashlib.sha256(assessment.read_bytes()).hexdigest()=='24e9cdc4dbfdbdffd85292cbcf3bfe0df361edbb415b19530a198379e875634a'
record=json.loads(assessment.read_bytes())
assert record['schema']=='mitl-next-upstream-task-assessment-v1'
assert record['status']=='assessment_complete' and record['selected_task'] is None
assert record['no_new_lease_claimed'] is True
saved=WORK/'completion-preparation/complete_pass.initial-draft.py'
assert not saved.exists()
saved.write_bytes(original)
source=original.decode()
old="""    need=verification['next_task'];next_record=load(OUT/'next_task.json')
    require(type(need) is str and need.strip() and next_record['task']==need,'receiver/readback dependency missing')
"""
new="""    require(assessment['schema']=='mitl-next-upstream-task-assessment-v1' and assessment['status']=='assessment_complete'
        and assessment['no_new_lease_claimed'] is True
        and assessment['no_authorized_useful_unblocked_upstream_task_under_present_inputs'] is True,'assessment authority changed')
    need=verification['next_task'];next_record=load(OUT/'next_task.json')
    require(type(need) is str and need.strip() and next_record['task']==need==assessment['receiver_readback_need'],'receiver/readback dependency missing')
"""
assert old in source
source=source.replace(old,new)
old="""        records=verify_metadata(contract,verification,archive_hashes)
        clean_head(contract);now=datetime.datetime.now(datetime.timezone.utc)
"""
new="""        records=verify_metadata(contract,verification,archive_hashes)
        require(records['next_task_assessment']['preserved_queue_items_2_through_7']==remaining,'assessment queue differs from saved pending work')
        clean_head(contract);now=datetime.datetime.now(datetime.timezone.utc)
"""
assert old in source
source=source.replace(old,new)
helper.write_text(source)
result={'schema':'mitl-boundary-completion-actual-assessment-binding-v1',
        'initial_unexecuted_draft_sha256':hashlib.sha256(original).hexdigest(),
        'final_helper_sha256':hashlib.sha256(helper.read_bytes()).hexdigest(),
        'actual_assessment_sha256':hashlib.sha256(assessment.read_bytes()).hexdigest(),
        'selected_task':None,'followup_status':record['followup_status'],
        'metadata_keys_only_changed':True,'helper_imported_or_executed':False,
        'source_science_tests_or_oracles_repeated':False,'status_or_lease_mutated':False}
(WORK/'completion-preparation/actual-assessment-binding.json').write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
print(json.dumps(result,sort_keys=True))
