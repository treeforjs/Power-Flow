"""Draft root-only metadata completion without executing any delivery helper."""
import hashlib
import json
from pathlib import Path

WORK=Path(__file__).resolve().parent.parent
PRIOR=WORK.parent/'mitl-upstream-20261019T0737/complete_pass.py'
source=PRIOR.read_text()
prefix=source.split('def main():',1)[0]
replacements={
    'Root-owned metadata completion of manufactured saved coupled-emission windows.': 'Root-owned metadata completion of positive joint boundary quadrature records.',
    'mitl-coupled-windows-20261019T0737': 'mitl-boundary-quadrature-20261019T0810',
    "BASE='df8eb7026b3a712bf641cbb4d136c497e8af50ba'": "BASE='ea82ae3094ae480cb9c370652fa1eb1c677d8de5'",
    'mhdlab/coupled_emission_windows.py': 'mhdlab/boundary_quadrature.py',
    'tests/test_coupled_emission_windows.py': 'tests/test_boundary_quadrature.py',
    'tools/export_coupled_emission_windows.py': 'tools/export_boundary_quadrature.py',
    'configs/coupled_emission_windows_manufactured.json': 'configs/boundary_quadrature_manufactured.json',
    'docs/coupled_emission_windows.md': 'docs/boundary_quadrature.md',
    'mitl-coupled-emission-windows-verification-v1': 'mitl-boundary-quadrature-verification-v1',
    'coupled-emission-windows.patch': 'boundary-quadrature.patch',
}
for old,new in replacements.items():
    assert old in prefix,old
    prefix=prefix.replace(old,new)
old_block='''    selection=records['selection']
    require(selection.get('selected') is True or str(selection.get('status','')).startswith('selected'),'next selection is only conditional')
    require(type(selection.get('selected_task')) is str and selection['selected_task'].strip(),'next task missing')
    require(load(OUT/'next_task.json')['task']==verification['next_task']==selection['selected_task'],'next task association changed')
'''
new_block='''    assessment=records['next_task_assessment']
    require('selected_task' in assessment and assessment['selected_task'] is None
        and assessment['followup_status']=='awaiting_receiver_contract_or_new_evidence','unsupported automatic follow-up selection')
    need=verification['next_task'];next_record=load(OUT/'next_task.json')
    require(type(need) is str and need.strip() and next_record['task']==need,'receiver/readback dependency missing')
    require('selected_task' in next_record and next_record['selected_task'] is None
        and next_record['followup_status']==assessment['followup_status'],'follow-up dependency qualification changed')
'''
assert old_block in prefix
prefix=prefix.replace(old_block,new_block)
body='''def main():
    contract_path=WORK/'completion-preparation/contract.json';contract=load(contract_path)
    require(contract['schema']=='mitl-boundary-quadrature-completion-contract-v1'
        and contract['ready_for_root_execution'] is True and contract['pending']==[],'completion contract is pending')
    require(set(contract['public_source_sha256'])==PUBLIC and set(contract['record_paths'])==set(contract['record_sha256']),'contract scope changed')
    for mapping in ['public_source_sha256','metadata_helpers_sha256','record_sha256']:
        require(all(type(value) is str and re.fullmatch('[0-9a-f]{64}',value) for value in contract[mapping].values()),'final byte pins are pending')
    status_path=WORK.parent/'mitl-upstream-status.json'
    with (WORK.parent/'mitl-upstream-status.lock').open('a+') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        before=status_path.read_bytes();status=json.loads(before);lease=load(WORK/'lease.json')
        now=datetime.datetime.now(datetime.timezone.utc)
        require(status['active_lease_owner']==lease['pass_id']==WORK.name
            and datetime.datetime.fromisoformat(status['active_editing_lease_until_utc'])>now,'lease changed or expired')
        require(status['last_complete_commit']==lease['baseline_commit']==BASE and status['handoff']==lease['prior_handoff']
            and not (WORK/'completion.json').exists(),'prior checkpoint changed or completion replay attempted')
        remaining=[json.loads(json.dumps(item)) for item in status['next_work'] if 2<=item['priority']<=7]
        require([item['priority'] for item in remaining]==[2,3,4,5,6,7],'prior queue priorities changed')
        changed={'last_complete_commit','last_completed_pass_id','last_update_utc','handoff','handoff_sha256','handoff_bytes','handoff_document',
            'active_lease_owner','active_editing_lease_until_utc','reserved_paths','active_completed_subtasks','active_phase',
            'last_verified_suite','next_work','verification_history','prior_handoffs','completed_milestones','manufactured_positive_boundary_quadrature'}
        preserved=json.loads(json.dumps({key:value for key,value in status.items() if key not in changed}))
        head=clean_head(contract);delivery,verification,archive_hashes,commands=verify_archive(contract)
        records=verify_metadata(contract,verification,archive_hashes)
        clean_head(contract);now=datetime.datetime.now(datetime.timezone.utc)
        require(datetime.datetime.fromisoformat(status['active_editing_lease_until_utc'])>now,'lease expired during verification')
        history=status.setdefault('verification_history',[]);prior=status.setdefault('prior_handoffs',[])
        if status['handoff'] not in prior:
            prior.append(status['handoff'])
        if not any(item['pass_id']==status['last_completed_pass_id'] for item in history):
            history.append({'pass_id':status['last_completed_pass_id'],'commit':status['last_complete_commit'],
                'handoff':status['handoff'],'handoff_sha256':status['handoff_sha256'],'verification':status['last_verified_suite']})
        assessment=records['next_task_assessment'];need=verification['next_task']
        status.update(last_complete_commit=head,last_completed_pass_id=WORK.name,last_update_utc=now.isoformat(),
            handoff=delivery['archive'],handoff_sha256=delivery['sha256'],handoff_bytes=delivery['bytes'],
            handoff_document=str(OUT/'systems-mitl-boundary-quadrature-10192026.md'),active_lease_owner=None,
            active_editing_lease_until_utc=None,reserved_paths=[],active_completed_subtasks=[],
            active_phase='Completed manufactured positive joint boundary records; awaiting receiver contract or new evidence')
        status['last_verified_suite']={**verification['results'],
            'scope':'New positive finite GL5 boundary quadrature of preserved joint coefficients;52 algebra/admission/import controls and independent exact/higher-precision record readback. No source/RHS/window/assembly/old-grid replay',
            'verification_record':str(OUT/'verification.json'),'delivery_manifest_entries':delivery['manifest_entries'],
            'public_files_byte_identical':5,'packaging_wrappers':2,'post_freeze_commands':str(WORK/'commands.jsonl'),
            'commands_snapshot_qualification':commands}
        status['manufactured_positive_boundary_quadrature']={'parameter_status':'manufactured',
            'interface':str(REPO/'mhdlab/boundary_quadrature.py'),
            'public_source_sha256':contract['public_source_sha256'],'results':verification['results'],
            'record_paths':{role:str(WORK/name) for role,name in contract['record_paths'].items()},'record_sha256':contract['record_sha256'],
            'full_joint_time_temperature_state_number_retained':True,'patch_geometry_retained':True,
            'exact_polynomial_finite_rule_and_binary_projection_defects_separate':True,
            'canonical_energy_and_represented_temperature_relation_defect_retained':True,
            'positive_weights_renormalized_or_repaired':False,'mean_temperature_substituted_for_mixture':False,
            'source_evolutions_by_interface':0,'source_RHS_calls_by_interface':0,
            'old_window_export_calls':0,'old_width_assembly_calls':0,
            'tests_use_manufactured_polynomial_fixtures_only':True,
            'legacy_import_boundary_measured_in_target_and_hostile_subprocess':True,
            'interval_certification_claimed':False,'new_query_IVP_error_qualified':False,
            'physical_parameters_adopted':0,'host_budget_accepted':False,'owner_implementation_verified':False,
            'actual_flash_run':False,'physical_water_material_or_surface_parameters_validated':False,
            'physical_spectra_calculated':False,'species_velocity_or_position_sampling_supplied':False,
            'limits':'Deterministic positive quadrature records of manufactured saved joint pieces only. Ideal GL5 polynomial capacity is distinct from finite Decimal80 approximations and independently projected binary fields. New-query IVP accuracy, physical materials/molecules, mass/velocity/flight, collection/response, fields, Hall/FLASH/Quark and host/owner acceptance remain unsupplied.'}
        status['next_work']=[{'priority':1,'task':need,'status':assessment['followup_status'],
            'selected_task':None,'assessment':str(WORK/contract['record_paths']['next_task_assessment']),
            'assessment_sha256':contract['record_sha256']['next_task_assessment'],
            'limits':'No new manufactured follow-up or lease is selected. Resume when the owner supplies an actual receiver/readback contract or new independent evidence; all physical surface, VUV, owner, FLASH and full-text gates remain in force.'}]+remaining
        require(status['next_work'][1:]==remaining and all(status[key]==value for key,value in preserved.items()),'earlier evidence,gates or queue changed')
        status['completed_milestones'].extend([
            'A new deterministic positive boundary interface preserves complete time/temperature/state/number and patch geometry, with exact polynomial targets, finite-rule discrepancies and actual binary-field projection defects. No weights, energies or source defects are normalized away.',
            'All52 new controls passed once. Original50test/plan bytes remain unexecuted before hostile-context and outer-declaration controls plus direct-file import measurements were added. Target and fresh subprocess recorded no forbidden legacy modules; no old source/RHS/window/assembly or suite was repeated.',
            f'Five public files through {head[:7]} and actual archive {delivery["sha256"]} require the complete ea82ae30 baseline. No new unblocked follow-up was selected; the receiver contract/new-evidence dependency and prior queue2-7 remain explicit.'
        ])
        history.append({'pass_id':WORK.name,'commit':head,'handoff':delivery['archive'],'handoff_sha256':delivery['sha256'],'verification':status['last_verified_suite']})
        encoded=(json.dumps(status,indent=2,allow_nan=False)+'\\n').encode()
        result={'utc':now.isoformat(),'event':'completed_with_upstream_dependencies_pending','pass_id':WORK.name,'commit':head,
            'archive':delivery['archive'],'archive_sha256':delivery['sha256'],'archive_bytes':delivery['bytes'],
            'actual_archive_reverified':True,'public_scope_sha256':contract['public_source_sha256'],
            'completion_contract_sha256':sha(contract_path),'record_sha256':contract['record_sha256'],
            'manufactured_positive_boundary_quadrature_qualified':True,'interval_certification_claimed':False,
            'physical_parameters_adopted':0,'host_budget_accepted':False,'owner_implementation_verified':False,'actual_flash_run':False,
            'source_recovery_or_scientific_checks_reexecuted':False,'portable_execution_performed':False,
            'command_snapshot_qualification':commands,'exact_commands':str(WORK/'commands.jsonl'),
            'status_before_sha256':hashlib.sha256(before).hexdigest(),'status_after_sha256':hashlib.sha256(encoded).hexdigest(),
            'lease_released':True,'reserved_paths':[],'next':need,'selected_task':None,
            'followup_status':assessment['followup_status'],'assessment_sha256':contract['record_sha256']['next_task_assessment']}
        require(not (WORK/'status-before-completion.json').exists(),'prior completion snapshot exists')
        (WORK/'status-before-completion.json').write_bytes(before)
        atomic_write(status_path,encoded)
        atomic_write(WORK/'completion.json',(json.dumps(result,indent=2,allow_nan=False)+'\\n').encode())
        with (WORK.parent/'mitl-upstream-journal.jsonl').open('a') as stream:
            stream.write(json.dumps(result,allow_nan=False)+'\\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':
    main()
'''
target=WORK/'complete_pass.py'
assert not target.exists()
target.write_text(prefix+body)
record={'schema':'mitl-boundary-quadrature-completion-draft-v1',
        'status':'unexecuted_pending_actual_records_approved_HEAD_and_delivery',
        'source_template_sha256':hashlib.sha256(PRIOR.read_bytes()).hexdigest(),
        'draft_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),
        'status_or_lease_mutated':False,'helper_imported_or_executed':False,
        'followup_status':'awaiting_receiver_contract_or_new_evidence','selected_task':None,
        'queue2_through7_preserved':True,
        'remaining_gates':['Final actual producer and independent readback records','Root documentation and dependency assessment',
                           'Approved clean final HEAD and final delivery helper/record pins','Single AST/data-pin readiness',
                           'Root-only actual archive freeze/verification before metadata completion']}
(WORK/'completion-preparation/draft-notes.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
print(json.dumps(record,sort_keys=True))
