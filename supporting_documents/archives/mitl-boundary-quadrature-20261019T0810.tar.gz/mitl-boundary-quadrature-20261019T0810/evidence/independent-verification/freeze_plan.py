"""Before-batch immutable input and positive-boundary method/threshold freeze."""
import datetime
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
WORK=HERE.parent
OLD=Path('/workspace/research_work/mitl-upstream-20261019T0737')
CONFIG=Path('/workspace/Power-Flow/configs/boundary_quadrature_manufactured.json')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    if (HERE/'before_plan_freeze.json').exists() or (WORK/'producer/reference-run/report.json').exists() or (HERE/'quadrature-initial').exists():
        raise RuntimeError('prospective freeze must precede the sole new producer and independent queries')
    if sha(CONFIG)!='89d70d9f106dce164a749cd0789187cbf0023007624846f2229a2894f62f2691':
        raise RuntimeError('actual config changed before prospective freeze')
    (HERE/'input_config.json').write_bytes(CONFIG.read_bytes())
    config=json.loads(CONFIG.read_text())
    inputs={}
    for alias,record in config['source_binding']['files'].items():
        path=OLD/record['relative_path']
        if sha(path)!=record['sha256']:
            raise RuntimeError('changed inherited accepted input '+alias)
        inputs[alias]={'path':str(path),'sha256':sha(path)}
    document={'schema':'mitl-positive-boundary-before-plan-freeze-v1',
        'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'files_sha256':{name:sha(HERE/name) for name in ('oracle_plan.json','input_config.json','freeze_plan.py')},
        'accepted_source_inputs':inputs,'new_boundary_or_independent_query_calls_before_freeze':0,
        'old_source_RHS_window_reference_driver_calls':0,
        'qualification':'Prospective finite-rule and exported-field qualification against accepted saved polynomial sources only. No fresh IVP assertion or numerical execution is made here.'}
    target=HERE/'before_plan_freeze.json'
    target.write_text(json.dumps(document,indent=2,sort_keys=True,allow_nan=False)+'\n')
    print(json.dumps({'freeze_sha256':sha(target),'files_sha256':document['files_sha256']},indent=2))


if __name__=='__main__':
    main()
