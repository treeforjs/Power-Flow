"""Bound exact-rational serialization before the sole independent query pass."""
import ast
import datetime
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    target=HERE/'final_before_query_freeze.json'
    if target.exists() or (HERE/'quadrature-initial').exists():
        raise RuntimeError('standalone codec amendment must precede all independent queries')
    parent=json.loads((HERE/'effective_before_query_freeze.json').read_text())
    old=HERE/'source-versions/before-integer-codec-cap'
    assert sha(old/'verify_boundary_quadrature.py')==parent['files_sha256']['verify_boundary_quadrature.py']
    assert sha(old/'effective_before_query_freeze.json')==sha(HERE/'effective_before_query_freeze.json')
    for name,digest in parent['files_sha256'].items():
        if name!='verify_boundary_quadrature.py':
            assert sha(HERE/name)==digest
        if name.endswith('.py'):
            ast.parse((HERE/name).read_text(),filename=name)
    document={**parent,'schema':'mitl-positive-boundary-final-before-query-freeze-v1',
        'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'previous_effective_freeze_sha256':sha(HERE/'effective_before_query_freeze.json'),
        'files_sha256':{name:sha(HERE/name) for name in parent['files_sha256']},
        'integer_codec_amendment':{
            'standalone_decimal_digit_limit':16384,
            'rationale':'Exact120/160-digit degree8 normalized-statistic contrasts combine distinct rational mass denominators, and their change ratios can exceed Python default4300 integer-string digits.16384 is an explicit supported serialization domain, not a certified worst-case integer-size bound; larger exact integers reject without clipping, rounding or truncation.',
            'actual_size_evidence':'The consumer records its maximum encoded Fraction integer length in the final report.',
            'scope':'Only standalone consumer codec setup, output-size metadata and final byte-manifest association changed.'},
        'mathematical_input_query_or_tolerance_change':False,'new_query_calls_before_amendment':0,
        'amendment_script_sha256':sha(HERE/'amend_integer_codec.py')}
    target.write_text(json.dumps(document,indent=2,sort_keys=True,allow_nan=False)+'\n')
    print(json.dumps({'final_freeze_sha256':sha(target),'main_sha256':document['files_sha256']['verify_boundary_quadrature.py']},indent=2))


if __name__=='__main__':
    main()
