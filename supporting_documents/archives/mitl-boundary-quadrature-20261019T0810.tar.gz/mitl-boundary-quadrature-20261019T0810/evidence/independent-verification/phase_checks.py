"""Exact phase closure and own-scale numerical qualification for new records."""
from fractions import Fraction as F
import math
import sys
from source_targets import RAW,STAT,KB,binary,ratio,packed,statistics

PUBLIC_KEYS=RAW+('binding_energy_j_m2','internal_energy_j_m2','translational_energy_j_m2',
    'gas_energy_j_m2','total_wall_energy_debit_j_m2')


def public_name(key):
    return 'released_number' if key=='released_m2' else key[:-3]


def check_record(actual,expected):
    if set(actual)!={'exact','value','projection'} or ratio(actual['exact'])!=expected:
        raise AssertionError('exact output record mismatch')
    try:
        value=float(expected)
    except OverflowError:
        value=None
    if value is not None and not math.isfinite(value):
        value=None
    if value is None:
        if actual['value'] is not None:
            raise AssertionError('overflow display mismatch')
    elif type(actual['value']) is not float or actual['value'].hex()!=value.hex():
        raise AssertionError('typed/signed float projection mismatch')
    flags={'exact_zero':expected==0,'positive':expected>0,'negative':expected<0,
        'finite':value is not None,'underflowed':expected!=0 and value==0,'overflowed':value is None,
        'rounded':value is None or binary(value)!=expected,
        'subnormal':value is not None and 0<abs(value)<sys.float_info.min,
        'exact_rounding_error':None if value is None else packed(binary(value)-expected)}
    if actual['projection']!=flags:
        raise AssertionError('projection flags or signed rounding defect changed')


def check_statistics(actual,expected):
    count=0
    if set(actual)!=set(STAT):
        raise AssertionError('six statistics required')
    for key,item in expected.items():
        declaration=actual[key]
        if item is None:
            if declaration!={'available':False,'reason':'exact_zero_emitted_mass','record':None}:
                raise AssertionError('empty-measure statistic availability changed')
        else:
            if declaration['available'] is not True or declaration['reason'] is not None:
                raise AssertionError('positive-measure statistic unavailable')
            check_record(declaration['record'],item)
            count+=1
    return count


def verify_summary(actual,target,finite,represented,removal,internal):
    phases={'target':target,'finite_rule':finite,'represented':represented}
    count=0
    for phase,reference in phases.items():
        if set(actual[phase])!={public_name(key) for key in PUBLIC_KEYS}:
            raise AssertionError('complete public phase quantities required')
        for key in PUBLIC_KEYS:
            check_record(actual[phase][public_name(key)],reference['moments'][key])
            count+=1
        count+=check_statistics(actual['statistics'][phase],reference['statistics'])
    for key in PUBLIC_KEYS:
        t,f,r=(phase['moments'][key] for phase in (target,finite,represented))
        defects={'rule_generation_defect':f-t,'export_projection_defect':r-f,'total_defect':r-t}
        if defects['total_defect']!=defects['rule_generation_defect']+defects['export_projection_defect']:
            raise AssertionError('exact defect identity failed')
        for phase,value in defects.items():
            check_record(actual[phase][public_name(key)],value)
            count+=1
    values=represented['moments']
    energy={
        'represented_translation_from_temperature_j':values['translation_from_temperature_j_m2'],
        'represented_translation_field_minus_temperature_energy_j':values['exported_minus_temperature_translation_j_m2'],
        'represented_binding_field_minus_supplied_cost_j':values['binding_energy_j_m2']-removal*values['released_m2'],
        'represented_internal_field_minus_supplied_cost_j':values['internal_energy_j_m2']-internal*values['released_m2']}
    if set(actual['energy_consistency'])!=set(energy):
        raise AssertionError('independent energy projection consistency map incomplete')
    for key,item in energy.items():
        check_record(actual['energy_consistency'][key],item)
        count+=1
    return count


def metrics(record,anchor_temperature):
    m=record['moments']
    s=record['statistics']
    result={key:m[key] for key in PUBLIC_KEYS if key not in (
        'temperature_first_moment_k_m2','temperature_second_moment_k2_m2','local_time_temperature_moment_k_s_m2')}
    result['translation_from_temperature_j_m2']=m['translation_from_temperature_j_m2']
    result.update({key:s[key] for key in STAT if key!='mean_local_time_temperature_k_s'})
    result['centered_joint_local_time_temperature_k_s']=(None if s['mean_local_time_s'] is None else
        s['mean_local_time_temperature_k_s']-anchor_temperature*s['mean_local_time_s'])
    return result


def shared_scales(records,anchor_temperature):
    maximum={}
    for record in records:
        for key,item in metrics(record,anchor_temperature).items():
            if item is not None:
                maximum[key]=max(maximum.get(key,F(0)),abs(item))
    return maximum


def admit_errors(actual,target,maximum,anchor_temperature,tolerance,baseline=None):
    a,t=metrics(actual,anchor_temperature),metrics(target,anchor_temperature)
    reference=metrics(target if baseline is None else baseline,anchor_temperature)
    output={}
    for key,expected in t.items():
        if expected is None:
            if a[key] is not None or reference[key] is not None:
                raise ArithmeticError('empty-measure normalized diagnostic became available')
            output[key]={'available':False,'reason':'exact_zero_emitted_mass'}
            continue
        if key=='mean_temperature_k':
            scale=target['temperature_excursion_scale_k']
        elif key in ('covariance_local_time_temperature_k_s','centered_joint_local_time_temperature_k_s'):
            scale=maximum[key]
        else:
            scale=abs(expected)
        difference=a[key]-reference[key]
        if scale==0:
            if difference!=0:
                raise ArithmeticError('unresolved structural zero: '+key)
            relative=F(0)
        else:
            relative=abs(difference)/scale
        if relative>tolerance:
            raise ArithmeticError('own-scale finite-rule/export qualification failed: '+key+' '+str(float(relative)))
        output[key]={'prediction':a[key],'comparison_reference':reference[key],'exact_polynomial_target':expected,
            'signed_error':difference,'scale':scale,'scaled_error':relative,'tolerance':tolerance,
            'remaining_margin':tolerance-relative}
    return output


def contrast_values(nonuniform,uniform,anchor_temperature):
    def all_values(record):
        values={key:record['moments'][key] for key in PUBLIC_KEYS}
        values['translation_from_temperature_j_m2']=record['moments']['translation_from_temperature_j_m2']
        values.update(record['statistics'])
        values['centered_joint_local_time_temperature_k_s']=metrics(record,anchor_temperature)['centered_joint_local_time_temperature_k_s']
        return values
    a,b=all_values(nonuniform),all_values(uniform)
    return {key:None if a[key] is None or b[key] is None else a[key]-b[key] for key in a}


def admit_contrasts(actual,target,anchor_temperature,tolerance,baseline=None):
    differences={key:contrast_values(pair['nonuniform'],pair['uniform'],anchor_temperature) for key,pair in target.items()}
    maximum={quantity:max((abs(values[quantity]) for values in differences.values() if values[quantity] is not None),default=F(0)) for quantity in next(iter(differences.values()))}
    output={}
    for key,pair in actual.items():
        values=contrast_values(pair['nonuniform'],pair['uniform'],anchor_temperature)
        reference=(differences[key] if baseline is None else contrast_values(baseline[key]['nonuniform'],baseline[key]['uniform'],anchor_temperature))
        output[key]={}
        for quantity,expected in differences[key].items():
            if expected is None:
                if values[quantity] is not None or reference[quantity] is not None:
                    raise ArithmeticError('unavailable normalized contrast became available')
                output[key][quantity]={'available':False,'reason':'exact_zero_emitted_mass'}
                continue
            scale=maximum[quantity]
            error=values[quantity]-reference[quantity]
            if scale==0:
                if error!=0:
                    raise ArithmeticError('zero own contrast has no relative scale: '+quantity)
                relative=F(0)
            else:
                relative=abs(error)/scale
            if relative>tolerance:
                raise ArithmeticError('own contrast quadrature/export qualification failed: '+quantity+' '+str(float(relative)))
            output[key][quantity]={'prediction':values[quantity],'exact_polynomial_target':expected,
                'comparison_reference':reference[quantity],
                'signed_error':error,'own_contrast_scale':scale,'scaled_error':relative,'tolerance':tolerance,
                'remaining_margin':tolerance-relative,
                'numerically_resolved_sign':abs(expected)>abs(error),
                'qualification':'Observed polynomial/finite-rule/export discrepancy, not physical or statistical confidence.'}
    return output
