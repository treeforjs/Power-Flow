"""Typed saved JSON/CSV/hash associations; no model or producer imports."""
import csv
import hashlib
import json
from pathlib import Path


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def strict_same(actual,expected):
    if type(actual) is not type(expected):
        raise AssertionError('saved declaration type mismatch')
    if type(expected) is float:
        if actual.hex()!=expected.hex():
            raise AssertionError('saved signed binary float mismatch')
    elif type(expected) is dict:
        if set(actual)!=set(expected):
            raise AssertionError('saved declaration key inventory mismatch')
        for key,item in expected.items():
            strict_same(actual[key],item)
    elif type(expected) is list:
        if len(actual)!=len(expected):
            raise AssertionError('saved declaration list inventory mismatch')
        for a,b in zip(actual,expected):
            strict_same(a,b)
    elif actual!=expected:
        raise AssertionError('saved declaration identity mismatch')


def cell_expectations(document):
    output={}
    def visit(item,path):
        if type(item) is dict and set(item)=={'exact','value','projection'}:
            output[path]=item['value']
            output[path+'__exact_numerator']=item['exact']['numerator']
            output[path+'__exact_denominator']=item['exact']['denominator']
            output[path+'__projection_json']=json.dumps(item['projection'],sort_keys=True,separators=(',',':'),allow_nan=False)
        elif type(item) is dict:
            for key,value in item.items():
                visit(value,path+'__'+key if path else key)
        elif type(item) is list:
            output[path]=json.dumps(item,sort_keys=True,separators=(',',':'),allow_nan=False)
        else:
            output[path]=item
    visit(document,'')
    return output


def verify_csvs(directory,document):
    csv.field_size_limit(16*1024*1024)
    tables={name:document[name] for name in ('piece_cache','node_cache','source_queries','patch_queries','aggregate_queries','contrasts')}
    expected_counts={'piece_cache':66,'node_cache':330,'source_queries':6,'patch_queries':12,'aggregate_queries':4,'contrasts':2,
        'source_query_nodes':570,'patch_query_nodes':1140}
    for source,destination in (('source_queries','source_query_nodes'),('patch_queries','patch_query_nodes')):
        tables[destination]=[]
        for parent_index,row in enumerate(document[source]):
            identity={key:row[key] for key in ('source_history_id','query_id','state_id','hypothesis','patch_index') if key in row}
            for index,node in enumerate(row['summary']['nodes']):
                tables[destination].append({'parent_query_index':parent_index,'node_reference_index':index,**identity,'node':node})
    counts={'rows':0,'cells':0,'typed_float_projections':0}
    for name,source_rows in tables.items():
        with (directory/(name+'.csv')).open(newline='') as stream:
            reader=csv.DictReader(stream)
            actual_rows=list(reader)
            headers=reader.fieldnames
        expected=[cell_expectations(row) for row in source_rows]
        if len(expected)!=expected_counts[name] or len(actual_rows)!=len(expected) or set(headers)!={key for row in expected for key in row}:
            raise AssertionError('saved CSV support or column inventory changed: '+name)
        for row,reference in zip(actual_rows,expected):
            counts['rows']+=1
            for key in headers:
                item=reference.get(key)
                if type(item) is float:
                    if float(row[key]).hex()!=item.hex():
                        raise AssertionError('saved CSV binary projection mismatch: '+name+'/'+key)
                    counts['typed_float_projections']+=1
                else:
                    text='null' if item is None else 'true' if item is True else 'false' if item is False else str(item)
                    if row[key]!=text:
                        raise AssertionError('saved CSV exact declaration mismatch: '+name+'/'+key)
                counts['cells']+=1
    return counts
