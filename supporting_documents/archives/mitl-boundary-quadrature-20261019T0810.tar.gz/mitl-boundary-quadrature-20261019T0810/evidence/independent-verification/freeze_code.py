"""Syntax/raw-byte freeze of the new polynomial consumer before any evaluation."""
import ast
import datetime
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
WORK=HERE.parent
NAMES=('independent_rule.py','source_targets.py','phase_checks.py','rule_queries.py','saved_artifacts.py',
    'verify_boundary_quadrature.py','oracle_plan.json','input_config.json','scale_definition_amendment.json','freeze_code.py')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    target=HERE/'before_query_code_freeze.json'
    if target.exists() or (HERE/'quadrature-initial').exists():
        raise RuntimeError('freeze must precede every new independent rule query')
    before=json.loads((HERE/'before_plan_freeze.json').read_text())
    for name,digest in before['files_sha256'].items():
        if sha(HERE/name)!=digest:
            raise RuntimeError('prospective plan/config changed '+name)
    for name in NAMES:
        if name.endswith('.py'):
            tree=ast.parse((HERE/name).read_text(),filename=name)
            for node in ast.walk(tree):
                if isinstance(node,ast.ImportFrom) and (node.module or '').split('.')[0] in ('mhdlab','numpy','scipy'):
                    raise RuntimeError('forbidden model/numerical import')
                if isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id=='reference_grid':
                    raise RuntimeError('old source reference driver prohibited')
    document={'schema':'mitl-positive-boundary-before-query-code-freeze-v1',
        'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'files_sha256':{name:sha(HERE/name) for name in NAMES},
        'before_plan_freeze_sha256':sha(HERE/'before_plan_freeze.json'),
        'accepted_plan_review_sha256':sha(WORK/'oracle-review/plan_review.json'),
        'output_contract_sha256':sha(WORK/'core/output-contract.json'),
        'producer_saved_report_already_exists':(WORK/'producer/reference-run/report.json').exists(),
        'independent_numerical_calls_before_freeze':0,
        'actual_evaluation_budget':{'Newton120_160_polynomial_nodes':660,'provided_Decimal80_rule_polynomial_field_recomputations':330,
            'total_new_rational_polynomial_node_evaluations':990,'new_IVP_RHS_or_source_calls':0},
        'qualification':'The independent rule explicitly uses caller-independent Decimal120/160 ROUND_HALF_EVEN contexts. Only rational polynomial queries are new; no source law, previous reference or IVP is replayed.'}
    target.write_text(json.dumps(document,indent=2,sort_keys=True,allow_nan=False)+'\n')
    print(json.dumps({'freeze_sha256':sha(target),'files_sha256':document['files_sha256']},indent=2))


if __name__=='__main__':
    main()
