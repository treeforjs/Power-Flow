"""Finalize saved polynomial-quadrature evidence without numerical replay."""
import datetime
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
WORK=HERE.parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    if (HERE/'completion.json').exists():
        raise RuntimeError('immutable saved completion already exists')
    report_path=HERE/'quadrature-initial/report.json'
    report=json.loads(report_path.read_text())
    assert report['schema']=='mitl-independent-positive-boundary-quadrature-report-v1'
    assert report['status']=='passed' and report['all_checks_passed'] is True
    assert report['new_query_IVP_error_qualified'] is False and report['forbidden_model_or_numerical_package_imports']==[]
    frozen=json.loads((HERE/'final_before_query_freeze.json').read_text())
    for name,digest in frozen['files_sha256'].items():
        assert sha(HERE/name)==digest
    for name,digest in report['checkpoint_sha256'].items():
        assert sha(HERE/'quadrature-initial'/name)==digest
    for name,digest in report['artifact_sha256'].items():
        assert sha(HERE/'quadrature-initial'/name)==digest
    review_path=WORK/'oracle-review/completion.json'
    review=json.loads(review_path.read_text())
    assert review['status']=='accepted' and sha(report_path) in json.dumps(review,sort_keys=True)
    commands=[json.loads(line) for line in (WORK/'commands.jsonl').read_text().splitlines()]
    expected_command=['.venv/bin/python','-W','error',str(HERE/'verify_boundary_quadrature.py')]
    runs=[entry for entry in commands if entry['command']==expected_command]
    assert len(runs)==1 and runs[0]['exit_code']==0 and sha(runs[0]['log'])==runs[0]['log_sha256']
    counts=report['new_work_counts']
    expected={'independent_Newton_precision_levels':2,'independent_Newton_node_evaluations':660,
        'provided_rule_node_field_recomputations':330,'total_new_rational_polynomial_node_evaluations':990,
        'independent_source_query_node_references_across_levels':1140,'producer_unique_supports':66,
        'producer_unique_nodes':330,'source_query_node_references':570,'patch_query_node_references':1140,
        'source_queries':6,'patch_queries':12,'aggregates':4,'contrasts':2,
        'old_source_evolution_RHS_window_export_reference_grid_IVP_calls':0}
    assert counts==expected
    codec=report['integer_codec']
    assert codec['decimal_digit_limit']==16384 and 0<codec['maximum_fraction_integer_digits_encoded']<=16384
    exact=report['exact_check_counts']
    assert exact['CSV']['rows']==2130 and exact['CSV']['cells']==68864 and exact['CSV']['typed_float_projections']==18396
    assert exact['summary_exact_records']==1936 and exact['contrast_exact_records']==176
    assert exact['primitive_cache_exact_field_checks']==5148 and exact['actual_node_field_checks']==26220
    assert exact['source_node_references']==570 and exact['patch_node_references']==1140
    producer_path=WORK/'producer/reference-run/report.json'
    assert sha(producer_path)==report['producer_report_sha256']
    maximum_summary={group:{phase:{'maximum_scaled_error':row['maximum_scaled_error'],
        'exact_scaled_error':row['exact_scaled_error'],'location':row['location'],'tolerance':row['tolerance'],
        'checked_quantities':row['checked_quantities']} for phase,row in phases.items()} for group,phases in report['maxima'].items()}
    summary={'schema':'mitl-independent-positive-boundary-quadrature-summary-v1','status':'passed',
        'report_sha256':sha(report_path),'maxima':maximum_summary,'new_work_counts':counts,
        'exact_check_counts':exact,'integer_codec':codec,'new_query_IVP_error_qualified':False,
        'qualification':report['qualification']}
    (HERE/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True,allow_nan=False)+'\n')
    evidence={str(path.relative_to(WORK)):sha(path) for path in HERE.rglob('*') if path.is_file() and '__pycache__' not in path.parts and path.name!='completion.json'}
    evidence['oracle-review/completion.json']=sha(review_path)
    completion={'schema':'mitl-independent-positive-boundary-quadrature-completion-v1','status':'passed','all_checks_passed':True,
        'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'distinct_source_queries':6,'patch_queries':12,'aggregate_queries':4,'width_contrasts':2,
        'unique_supports':66,'unique_production_nodes':330,'source_node_references':570,'patch_node_references':1140,
        'independent_rule_precisions':[120,160],'independent_checkpoints':2,
        'independent_polynomial_node_evaluations':660,'provided_rule_field_recomputations':330,
        'total_new_rational_polynomial_node_evaluations':990,
        'completed_independent_runs':1,'independent_run_attempts':1,
        'new_work_counts':counts,'exact_check_counts':exact,'integer_codec':codec,
        'old_source_evolution_RHS_window_export_reference_grid_IVP_calls':0,'old_suites_repeated':False,
        'old_references_repeated':False,'new_query_IVP_error_qualified':False,
        'host_budget_accepted':False,'owner_implementation_verified':False,'physical_or_spectral_truth_validated':False,
        'report_sha256':sha(report_path),'summary_sha256':sha(HERE/'summary.json'),
        'static_review_sha256':sha(review_path),'producer_report_sha256':sha(producer_path),
        'source_sha256':report['source_sha256'],'artifact_sha256':evidence,'query_run':runs[0],
        'qualification':report['qualification']}
    (HERE/'completion.json').write_text(json.dumps(completion,indent=2,sort_keys=True,allow_nan=False)+'\n')
    compact={group:{phase:row['maximum_scaled_error'] for phase,row in phases.items()} for group,phases in maximum_summary.items()}
    print(json.dumps({'completion_sha256':sha(HERE/'completion.json'),'summary_sha256':sha(HERE/'summary.json'),
        'maxima':compact,'counts':counts,'exact_counts':exact,'integer_codec':codec},indent=2))


if __name__=='__main__':
    main()
