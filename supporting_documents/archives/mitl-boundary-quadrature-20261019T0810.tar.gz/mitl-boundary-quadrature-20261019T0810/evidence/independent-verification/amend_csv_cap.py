"""Pre-query bounded CSV parser capacity correction, without numerical changes."""
import ast
import datetime
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    target=HERE/'effective_before_query_freeze.json'
    if target.exists() or (HERE/'quadrature-initial').exists():
        raise RuntimeError('CSV parser correction must precede all independent numerical queries')
    old=json.loads((HERE/'before_query_code_freeze.json').read_text())
    saved=HERE/'source-versions/before-csv-field-cap'
    for name,digest in old['files_sha256'].items():
        if sha(saved/name)!=digest:
            raise RuntimeError('original frozen bytes not preserved '+name)
        if name not in ('saved_artifacts.py','verify_boundary_quadrature.py') and sha(HERE/name)!=digest:
            raise RuntimeError('unexpected mathematical/input modification '+name)
        if name.endswith('.py'):
            ast.parse((HERE/name).read_text(),filename=name)
    document={**old,'schema':'mitl-positive-boundary-effective-pre-query-freeze-v1',
        'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'original_code_freeze_sha256':sha(HERE/'before_query_code_freeze.json'),
        'files_sha256':{name:sha(HERE/name) for name in old['files_sha256']},
        'amendment':'Bounded16MiB CSV field cap admits the already documented complete summary-node JSON cells. Main points to this effective source-byte manifest. Original frozen bytes remain preserved; no numerical/method/input/tolerance change.',
        'new_independent_query_calls_before_amendment':0,'CSV_field_limit_bytes':16*1024*1024,
        'amendment_script_sha256':sha(HERE/'amend_csv_cap.py')}
    target.write_text(json.dumps(document,indent=2,sort_keys=True,allow_nan=False)+'\n')
    print(json.dumps({'effective_freeze_sha256':sha(target),'files_sha256':document['files_sha256']},indent=2))


if __name__=='__main__':
    main()
