"""Exact ordinary-power-basis targets from accepted complete-support controls."""
from fractions import Fraction as F
import math

KB=F('1.380649e-23')
QE=F('1.602176634e-19')
RAW=('released_m2','local_time_first_moment_s_m2','local_time_second_moment_s2_m2',
    'temperature_first_moment_k_m2','temperature_second_moment_k2_m2','local_time_temperature_moment_k_s_m2')
STAT=('mean_local_time_s','variance_local_time_s2','mean_temperature_k','variance_temperature_k2',
    'mean_local_time_temperature_k_s','covariance_local_time_temperature_k_s')


def ratio(value):
    return F(int(value['numerator']),int(value['denominator']))


def binary(value):
    return F.from_float(float(value))


def packed(value):
    return {'numerator':str(value.numerator),'denominator':str(value.denominator)}


def power(controls):
    a,b,c,d=controls
    return [a,3*(b-a),3*(a-2*b+c),-a+3*b-3*c+d]


def substitute(coefficients,a,h):
    return [sum((coefficient*math.comb(j,k)*a**(j-k)*h**k
        for j,coefficient in enumerate(coefficients) if j>=k),F(0)) for k in range(len(coefficients))]


def multiply(a,b):
    result=[F(0)]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b):
            result[i+j]+=x*y
    return result


def evaluate(coefficients,x):
    value=F(0)
    for coefficient in reversed(coefficients):
        value=value*x+coefficient
    return value


def integrate(coefficients):
    return sum((coefficient/F(i+1) for i,coefficient in enumerate(coefficients)),F(0))


def statistics(values):
    mass=values['released_m2']
    if mass==0:
        return {key:None for key in STAT}
    t=values['local_time_first_moment_s_m2']/mass
    temperature=values['temperature_first_moment_k_m2']/mass
    joint=values['local_time_temperature_moment_k_s_m2']/mass
    return {'mean_local_time_s':t,'variance_local_time_s2':values['local_time_second_moment_s2_m2']/mass-t*t,
        'mean_temperature_k':temperature,'variance_temperature_k2':values['temperature_second_moment_k2_m2']/mass-temperature**2,
        'mean_local_time_temperature_k_s':joint,'covariance_local_time_temperature_k_s':joint-t*temperature}


def energies(values,removal,internal):
    result=dict(values)
    result['translational_energy_j_m2']=2*KB*values['temperature_first_moment_k_m2']
    result['translation_from_temperature_j_m2']=result['translational_energy_j_m2']
    result['binding_energy_j_m2']=removal*values['released_m2']
    result['internal_energy_j_m2']=internal*values['released_m2']
    result['gas_energy_j_m2']=result['internal_energy_j_m2']+result['translational_energy_j_m2']
    result['total_wall_energy_debit_j_m2']=result['binding_energy_j_m2']+result['gas_energy_j_m2']
    result['exported_minus_temperature_translation_j_m2']=F(0)
    return result


def support_identity(case,start,stop):
    return (case,start,stop)


def targets(windows,width_config,queries):
    complete={row['source_history_id']:row for row in windows['source_windows'] if row['query_id']=='complete_source_support'}
    if set(complete)!={'uniform_power','edge_power','middle_power'}:
        raise AssertionError('exactly three accepted complete-support sources required')
    p=width_config['common_scalar_problem']
    removal=binary(p['reservoir']['desorption_energy_ev'])*QE
    internal=binary(p['reservoir']['internal_energy_ev'])*QE
    supports={}
    outputs={}
    zero_catalog=[]
    for case,row in complete.items():
        outputs[case]={}
        for query_id,qa,qb in queries:
            values=dict.fromkeys(RAW,F(0))
            references=[]
            temperatures=[]
            for piece in row['pieces']:
                ta,tb=ratio(piece['start_exact_s']),ratio(piece['stop_exact_s'])
                a,b=max(qa,ta),min(qb,tb)
                if a>=b:
                    continue
                identity=support_identity(case,a,b)
                if identity not in supports:
                    u=(a-ta)/(tb-ta)
                    h=(b-a)/(tb-ta)
                    m=substitute(power([ratio(item) for item in piece['emitted_controls_m2']]),u,h)
                    temperature=substitute(power([ratio(item) for item in piece['temperature_controls_k']]),u,h)
                    derivative=[(i+1)*m[i+1] for i in range(3)]
                    mass=integrate(derivative)
                    if mass<0:
                        raise AssertionError('negative new support measure')
                    supports[identity]={'source_history_id':case,'start':a,'stop':b,
                        'source_cell_index':piece['source_cell_index'],'emitted':m,'temperature':temperature,
                        'derivative':derivative,'mass':mass,'state_id':row['state_id'],
                        'source_start':ta,'source_stop':tb,
                        'source_emitted_controls':[ratio(item) for item in piece['emitted_controls_m2']],
                        'source_temperature_controls':[ratio(item) for item in piece['temperature_controls_k']],
                        'temperature_min_k':binary(p['temperature_min_k']),
                        'temperature_max_k':binary(p['temperature_max_k'])}
                support=supports[identity]
                if support['mass']==0:
                    zero_catalog.append({'source_history_id':case,'query_id':query_id,
                        'start':a,'stop':b,'reason':'exact_zero_emitted_mass'})
                    continue
                tau=[a-qa,b-a]
                T=support['temperature']
                factors=([F(1)],tau,multiply(tau,tau),T,multiply(T,T),multiply(tau,T))
                for key,factor in zip(RAW,factors):
                    values[key]+=integrate(multiply(support['derivative'],factor))
                temperatures.extend((evaluate(T,F(0)),evaluate(T,F(1))))
                references.append(identity)
            enriched=energies(values,removal,internal)
            span=max(temperatures)-min(temperatures) if temperatures else F(0)
            if span==0 and any(any(item!=0 for item in supports[identity]['temperature'][1:]) for identity in references):
                raise ArithmeticError('zero attained endpoint excursion with a nonconstant source is unsupported')
            outputs[case][query_id]={'moments':enriched,'statistics':statistics(values),'support_references':references,
                'query_start':qa,'query_stop':qb,'temperature_excursion_scale_k':span,
                'attained_endpoint_temperatures_k':temperatures}
    return outputs,supports,zero_catalog


def node_values(support,node,weight,removal,internal):
    density=evaluate(support['derivative'],node)
    temperature=evaluate(support['temperature'],node)
    if not (0<node<1 and weight>0 and density>0 and support['temperature_min_k']<=temperature<=support['temperature_max_k']):
        raise ArithmeticError('new quadrature node must retain positive measure and temperature')
    return {'areal_weight_m2':weight*density,'time_s':support['start']+node*(support['stop']-support['start']),
        'temperature_k':temperature,'translational_energy_j':2*KB*temperature,
        'binding_energy_j':removal,'internal_energy_j':internal}


def node_moments(nodes,anchor,weight_key='areal_weight_m2'):
    result=dict.fromkeys(RAW,F(0))
    translation=binding=internal=F(0)
    for node in nodes:
        w=node[weight_key]
        tau=node['time_s']-anchor
        temperature=node['temperature_k']
        for key,factor in zip(RAW,(F(1),tau,tau*tau,temperature,temperature*temperature,tau*temperature)):
            result[key]+=w*factor
        translation+=w*node['translational_energy_j']
        binding+=w*node['binding_energy_j']
        internal+=w*node['internal_energy_j']
    result.update({'translational_energy_j_m2':translation,'translation_from_temperature_j_m2':2*KB*result['temperature_first_moment_k_m2'],
        'binding_energy_j_m2':binding,'internal_energy_j_m2':internal,'gas_energy_j_m2':internal+translation,
        'total_wall_energy_debit_j_m2':binding+internal+translation,
        'exported_minus_temperature_translation_j_m2':translation-2*KB*result['temperature_first_moment_k_m2']})
    return {'moments':result,'statistics':statistics(result)}


def weighted_mixture(records,areas):
    keys=records[0]['moments']
    values={key:sum((record['moments'][key]*area for record,area in zip(records,areas)),F(0)) for key in keys}
    temperatures=[t for record in records for t in record.get('attained_endpoint_temperatures_k',[])]
    result={'moments':values,'statistics':statistics(values)}
    if temperatures:
        result.update({'attained_endpoint_temperatures_k':temperatures,
            'temperature_excursion_scale_k':max(temperatures)-min(temperatures)})
    return result
