"""Distinct finite Gauss-Legendre rule from Decimal Newton iterations."""
from decimal import Decimal as D, Context, ROUND_HALF_EVEN, localcontext
from fractions import Fraction as F
import math


def legendre5(x):
    previous,current = D(1),x
    for n in range(2,6):
        previous,current = current,((2*n-1)*x*current-(n-1)*previous)/n
    derivative = 5*(x*current-previous)/(x*x-1)
    return current,derivative


def newton_rule(precision):
    """Binary cosines seed only; all refinement/weights use the stated context."""
    with localcontext(Context(prec=precision,rounding=ROUND_HALF_EVEN,Emin=-10000,Emax=10000)):
        tolerance = D(10)**(-precision+12)
        rule = [(D('0.5'),D(64)/D(225))]
        iterations = []
        for k in (1,2):
            root = D.from_float(math.cos(math.pi*(k-.25)/5.5))
            for count in range(1,101):
                polynomial,derivative = legendre5(root)
                change = polynomial/derivative
                root -= change
                if abs(change) <= tolerance:
                    break
            else:
                raise ArithmeticError('independent GL5 Newton iteration unresolved')
            polynomial,derivative = legendre5(root)
            weight = 1/((1-root*root)*derivative*derivative)
            if not (0 < root < 1 and weight > 0):
                raise ArithmeticError('independent GL5 positivity unresolved')
            rule.extend((((1-root)/2,weight),((1+root)/2,weight)))
            iterations.append(count)
        rule.sort()
        rational_rule = tuple((F(x),F(w)) for x,w in rule)
        if len(rational_rule)!=5 or any(not 0<x<1 or w<=0 for x,w in rational_rule):
            raise ArithmeticError('independent finite rule domain failed')
        defects = {str(k):sum((w*x**k for x,w in rational_rule),F(0))-F(1,k+1) for k in range(10)}
        return {'precision':precision,'rule':rational_rule,'Newton_iterations':iterations,
            'rounding':'ROUND_HALF_EVEN','Emin':-10000,'Emax':10000,
            'exact_rational_monomial_defects_through_degree9':defects,
            'normalization_repaired':False,
            'qualification':'Finite Decimal nodes and weights are rational approximations. Exact polynomial integration is a separate reference; order/precision changes are not certified error bounds.'}
