"""New saved-polynomial boundary verification; no source/IVP model is imported."""
import datetime
from fractions import Fraction as F
import json
import math
from pathlib import Path
import sys

from source_targets import (KB,QE,RAW,STAT,ratio,binary,packed,targets,node_moments,
    weighted_mixture,statistics,evaluate)
from phase_checks import (PUBLIC_KEYS,public_name,check_record,check_statistics,verify_summary,
    shared_scales,admit_errors,admit_contrasts)
from rule_queries import evaluate_supports,query_moments,independent_level,zero_measure_control
from saved_artifacts import sha,strict_same,verify_csvs

HERE=Path(__file__).resolve().parent
WORK=HERE.parent
OLD=Path('/workspace/research_work/mitl-upstream-20261019T0737')
OUT=HERE/'quadrature-initial'
MAX_ENCODED_INTEGER_DIGITS=0


def encode(value):
    if isinstance(value,F):
        global MAX_ENCODED_INTEGER_DIGITS
        result=packed(value)
        MAX_ENCODED_INTEGER_DIGITS=max(MAX_ENCODED_INTEGER_DIGITS,len(result['numerator'].lstrip('-')),len(result['denominator']))
        return result
    if isinstance(value,dict):
        if all(type(key) is str for key in value):
            return {key:encode(item) for key,item in value.items()}
        return [{'key':encode(key),'value':encode(item)} for key,item in value.items()]
    if isinstance(value,(tuple,list)):
        return [encode(item) for item in value]
    return value


def write(path,value):
    document=encode(value)
    if path.name=='report.json':
        document['integer_codec']={'decimal_digit_limit':sys.get_int_max_str_digits(),
            'maximum_fraction_integer_digits_encoded':MAX_ENCODED_INTEGER_DIGITS,
            'qualification':'A bounded standalone serialization domain, not a mathematical or physical precision limit; larger exact integers reject without truncation.'}
    path.write_text(json.dumps(document,indent=2,sort_keys=True,allow_nan=False)+'\n')


def inputs():
    config=json.loads((HERE/'input_config.json').read_text())
    freeze=json.loads((HERE/'before_plan_freeze.json').read_text())
    for name,digest in freeze['files_sha256'].items():
        if sha(HERE/name)!=digest:
            raise RuntimeError('changed prospective plan/input '+name)
    files={}
    for alias,record in config['source_binding']['files'].items():
        path=OLD/record['relative_path']
        if sha(path)!=record['sha256']:
            raise RuntimeError('changed inherited source input '+alias)
        files[alias]=json.loads(path.read_text())
    return config,files


def new_queries(config,width_config):
    duration=binary(width_config['duration_s'])
    return tuple((row['window_id'],duration*ratio(row['start_fraction']),duration*ratio(row['stop_fraction']))
        for row in config['queries'])


def bernstein(coefficients):
    n=len(coefficients)-1
    return [sum((coefficients[k]*F(math.comb(i,k),math.comb(n,k)) for k in range(i+1)),F(0)) for i in range(n+1)]


def provided_rule(document):
    rule=document['rule']
    if rule['precision']!=80 or rule['method']!='closed_form_GL5_Decimal80_then_exact_rational':
        raise AssertionError('provided finite rule declaration changed')
    pairs=tuple(zip((ratio(x) for x in rule['nodes']),(ratio(w) for w in rule['weights'])))
    if len(pairs)!=5 or any(not 0<x<1 or w<=0 for x,w in pairs) or any(a[0]>=b[0] for a,b in zip(pairs,pairs[1:])):
        raise AssertionError('provided finite rule positivity/order failed')
    if len(rule['monomial_moment_defects'])!=10:
        raise AssertionError('complete finite-rule monomial defects required')
    for k,record in enumerate(rule['monomial_moment_defects']):
        error=sum((w*x**k for x,w in pairs),F(0))-F(1,k+1)
        check_record(record,error)
        if abs(error)>F('1e-60'):
            raise ArithmeticError('provided finite rule monomial error unresolved')
    return pairs


def cache_readback(document,supports,finite_cache,removal,internal):
    if len(document['piece_cache'])!=66 or len(document['node_cache'])!=330:
        raise AssertionError('unique piece/node inventory differs')
    piece_ids={}
    identity_ids={}
    exact_checks=0
    for row in document['piece_cache']:
        identity=(row['source_history_id'],ratio(row['start_exact_s']),ratio(row['stop_exact_s']))
        if identity not in supports or identity in identity_ids or row['piece_id'] in piece_ids:
            raise AssertionError('piece identity missing or duplicated')
        expected=supports[identity]
        if row['state_id']!=expected['state_id'] or type(row['source_cell_index']) is not int or row['source_cell_index']!=expected['source_cell_index']:
            raise AssertionError('piece state/original-cell association changed')
        expected_arrays={'emitted_controls_m2':bernstein(expected['emitted']),
            'temperature_controls_k':bernstein(expected['temperature']),
            'source_emitted_controls_m2':expected['source_emitted_controls'],
            'source_temperature_controls_k':expected['source_temperature_controls']}
        for key,values in expected_arrays.items():
            strict_same(row[key],[packed(x) for x in values])
            exact_checks+=len(values)
        for key,item in (('source_start_exact_s',expected['source_start']),('source_stop_exact_s',expected['source_stop'])):
            strict_same(row[key],packed(item))
            exact_checks+=1
        reason='exact_zero_emitted_mass' if expected['mass']==0 else None
        if row['skip_reason']!=reason or len(row['node_ids'])!=(0 if reason else 5):
            raise AssertionError('zero/positive piece catalogue changed')
        piece_ids[row['piece_id']]=(identity,row)
        identity_ids[identity]=row['piece_id']
    node_ids={}
    node_binary={}
    for row in document['node_cache']:
        if row['node_id'] in node_ids or row['piece_id'] not in piece_ids or type(row['node_index']) is not int:
            raise AssertionError('node identity duplicate/missing/mistyped')
        identity,piece=piece_ids[row['piece_id']]
        index=row['node_index']
        if not 0<=index<5 or piece['node_ids'][index]!=row['node_id']:
            raise AssertionError('node index/piece reference mismatch')
        expected=finite_cache[identity][index]
        strict_same(row['coordinate_exact'],packed(expected['coordinate']))
        unprojected={'number_weight_m2':expected['areal_weight_m2'],'time_s':expected['time_s'],
            'temperature_k':expected['temperature_k'],'expected_translational_energy_j':expected['translational_energy_j']}
        strict_same(row['unprojected'],{key:packed(item) for key,item in unprojected.items()})
        expected_binary={key:float(item) for key,item in unprojected.items()}
        expected_binary.update({'desorption_energy_j':float(removal),'internal_energy_j':float(internal)})
        strict_same(row['binary'],expected_binary)
        if any(not math.isfinite(x) or x<=0 for x in expected_binary.values()):
            raise ArithmeticError('unsupported positive binary node projection')
        support=supports[identity]
        if not support['start']<binary(expected_binary['time_s'])<support['stop'] or not support['temperature_min_k']<=binary(expected_binary['temperature_k'])<=support['temperature_max_k']:
            raise ArithmeticError('represented node lies outside its admitted support/domain')
        check_record(row['energy_consistency']['translation_field_minus_temperature_energy_j'],
            binary(expected_binary['expected_translational_energy_j'])-2*KB*binary(expected_binary['temperature_k']))
        node_ids[row['node_id']]=(identity,index,expected)
        node_binary[row['node_id']]=expected_binary
        exact_checks+=12
    if len(node_ids)!=330 or len(identity_ids)!=66:
        raise AssertionError('finite support/node coverage incomplete')
    for identity,piece_id in identity_ids.items():
        row=piece_ids[piece_id][1]
        actual_times=[binary(node_binary[node_id]['time_s']) for node_id in row['node_ids']]
        if any(a>=b for a,b in zip(actual_times,actual_times[1:])):
            raise ArithmeticError('represented node time order collapsed')
    return {'piece_ids':piece_ids,'identity_ids':identity_ids,'node_ids':node_ids,'binary':node_binary},exact_checks


def summary_nodes(summary,target,lookup,area,context):
    expected_node_ids=[node_id for identity in target['support_references']
        for node_id in lookup['piece_ids'][lookup['identity_ids'][identity]][1]['node_ids']]
    if summary['node_count']!=len(expected_node_ids) or len(summary['nodes'])!=len(expected_node_ids):
        raise AssertionError('query node reference inventory differs')
    strict_same(summary['area_exact_m2'],packed(area))
    strict_same(summary['local_time_anchor_exact_s'],packed(target['query_start']))
    if summary['skipped_pieces']!=[]:
        raise AssertionError('saved positive source unexpectedly skipped a piece')
    nodes=[]
    area_projection_differences=[]
    checks=0
    for actual,node_id in zip(summary['nodes'],expected_node_ids):
        identity,index,unprojected=lookup['node_ids'][node_id]
        cached=lookup['binary'][node_id]
        expected_weight=float(area*unprojected['areal_weight_m2'])
        if not math.isfinite(expected_weight) or expected_weight<=0:
            raise ArithmeticError('physical patch number weight is unsupported')
        expected={'node_id':node_id,'node_index':index,'number_weight':expected_weight,
            **{key:cached[key] for key in ('time_s','temperature_k','expected_translational_energy_j','desorption_energy_j','internal_energy_j')}}
        for key,item in expected.items():
            strict_same(actual[key],item)
            checks+=1
        for key,item in context.items():
            strict_same(actual[key],item(node_id) if callable(item) else item)
            checks+=1
        local_time=binary(cached['time_s'])-target['query_start']
        strict_same(actual['local_time_exact_s'],packed(local_time))
        temperature_energy=2*KB*binary(cached['temperature_k'])
        check_record(actual['translation_from_represented_temperature_j'],temperature_energy)
        check_record(actual['translation_field_minus_temperature_energy_j'],binary(cached['expected_translational_energy_j'])-temperature_energy)
        area_projection_differences.append(binary(expected_weight)-area*binary(cached['number_weight_m2']))
        nodes.append({'areal_weight_m2':binary(expected_weight),'time_s':binary(cached['time_s']),
            'temperature_k':binary(cached['temperature_k']),'translational_energy_j':binary(cached['expected_translational_energy_j']),
            'binding_energy_j':binary(cached['desorption_energy_j']),'internal_energy_j':binary(cached['internal_energy_j'])})
        checks+=3
    return node_moments(nodes,target['query_start']),checks,area_projection_differences


def scale_record(record,area):
    result=weighted_mixture([record],[area])
    if 'temperature_excursion_scale_k' in record:
        result['temperature_excursion_scale_k']=record['temperature_excursion_scale_k']
    return result


def statistic_defects(target,finite,represented):
    result={}
    for key in STAT:
        a,b,c=(row['statistics'][key] for row in (target,finite,represented))
        if any(item is None for item in (a,b,c)):
            if not all(item is None for item in (a,b,c)):
                raise AssertionError('normalized phase availability changed')
            result[key]={'available':False,'reason':'exact_zero_emitted_mass'}
        else:
            rule,projection,total=b-a,c-b,c-a
            if total!=rule+projection:
                raise AssertionError('exact normalized statistic defect closure failed')
            result[key]={'rule_generation_defect':rule,'export_projection_defect':projection,'total_defect':total}
    return result


def query_readback(document,target_records,finite_records,lookup,width_config,old_windows,removal,internal):
    if len(document['source_queries'])!=6 or len(document['patch_queries'])!=12 or len(document['aggregate_queries'])!=4:
        raise AssertionError('source/patch/aggregate query inventory differs')
    complete={row['source_history_id']:row for row in old_windows['source_windows'] if row['query_id']=='complete_source_support'}
    phases={'target':target_records,'finite_rule':finite_records,'represented':{case:{} for case in target_records}}
    counts={'summary_exact_records':0,'actual_node_field_checks':0,'source_node_references':0,'patch_node_references':0}
    defects={'source':{},'patch':{},'aggregate':{}}
    projection_diagnostics={}
    source_rows={}
    for row in document['source_queries']:
        case,key=row['source_history_id'],row['query_id']
        if (case,key) in source_rows:
            raise AssertionError('duplicate source query identity')
        source_rows[case,key]=row
        target=target_records[case][key]
        finite=finite_records[case][key]
        for name,item in (('window_start_exact_s',target['query_start']),('window_stop_exact_s',target['query_stop']),('local_time_anchor_exact_s',target['query_start'])):
            strict_same(row[name],packed(item))
        expected_piece_ids=[lookup['identity_ids'][identity] for identity in target['support_references']]
        expected_node_ids=[node_id for piece_id in expected_piece_ids for node_id in lookup['piece_ids'][piece_id][1]['node_ids']]
        strict_same(row['piece_ids'],expected_piece_ids)
        strict_same(row['node_ids'],expected_node_ids)
        parent=complete[case]
        for name,parent_key in (('state_id','state_id'),('canonical_history_sha256','canonical_history_sha256'),
            ('raw_history_file_sha256','raw_history_file_sha256'),('parent_complete_source_window_key','source_window_key'),
            ('parent_source_RK_comparison','source_RK_comparison'),('parent_independent_window_reference','independent_window_reference')):
            strict_same(row[name],parent[parent_key])
        if row['new_query_IVP_error_qualified'] is not False:
            raise AssertionError('new boundary query cannot claim a fresh IVP reference')
        represented,checks,area_differences=summary_nodes(row['summary'],target,lookup,F(1),
            {'source_history_id':case,'query_id':key,'view_id':lambda node_id,case=case,key=key:case+'/'+key+'/'+node_id})
        strict_same(row['summary']['component_areas_exact_m2'],[packed(F(1)) for _ in target['support_references']])
        phases['represented'][case][key]=represented
        counts['summary_exact_records']+=verify_summary(row['summary'],target,finite,represented,removal,internal)
        counts['actual_node_field_checks']+=checks
        counts['source_node_references']+=len(row['summary']['nodes'])
        defects['source'][case+'/'+key]=statistic_defects(target,finite,represented)
        projection_diagnostics['source/'+case+'/'+key]=area_differences
    if len(source_rows)!=6:
        raise AssertionError('source query coverage incomplete')
    edges=[ratio(item) for item in width_config['geometry']['width_edges_m']]
    length=ratio(width_config['geometry']['common_length_m'])
    areas=[(b-a)*length for a,b in zip(edges,edges[1:])]
    patch_phases={phase:{} for phase in phases}
    patch_rows={}
    for row_index,row in enumerate(document['patch_queries']):
        hypothesis,index,key=row['hypothesis'],row['patch_index'],row['query_id']
        identity=(hypothesis,index,key)
        if identity in patch_rows or type(index) is not int or not 0<=index<3:
            raise AssertionError('duplicate/mistyped patch query')
        case=width_config['hypotheses'][hypothesis][index]
        if row['source_history_id']!=case or row['state_id']!=complete[case]['state_id'] or row['source_query_key']!=case+'/'+key:
            raise AssertionError('patch source/state association changed')
        strict_same(row['geometry'],{'width_start_exact_m':packed(edges[index]),'width_stop_exact_m':packed(edges[index+1]),
            'length_exact_m':packed(length),'area_exact_m2':packed(areas[index])})
        target=target_records[case][key]
        target_patch=scale_record(target,areas[index])
        finite_patch=scale_record(finite_records[case][key],areas[index])
        represented,checks,area_differences=summary_nodes(row['summary'],target,lookup,areas[index],
            {'hypothesis':hypothesis,'patch_index':index,'source_history_id':case,'query_id':key,
             'view_id':lambda node_id,hypothesis=hypothesis,index=index,key=key:hypothesis+'/'+str(index)+'/'+key+'/'+node_id})
        strict_same(row['summary']['component_areas_exact_m2'],[packed(areas[index]) for _ in target['support_references']])
        patch_phases['target'][identity]=target_patch
        patch_phases['finite_rule'][identity]=finite_patch
        patch_phases['represented'][identity]=represented
        counts['summary_exact_records']+=verify_summary(row['summary'],target_patch,finite_patch,represented,removal,internal)
        counts['actual_node_field_checks']+=checks
        counts['patch_node_references']+=len(row['summary']['nodes'])
        defects['patch'][identity]=statistic_defects(target_patch,finite_patch,represented)
        projection_diagnostics['patch/'+hypothesis+'/'+str(index)+'/'+key]=area_differences
        patch_rows[identity]=(row_index,row)
    aggregates={phase:{} for phase in phases}
    for row in document['aggregate_queries']:
        hypothesis,key=row['hypothesis'],row['query_id']
        if key not in aggregates['target']:
            for phase in aggregates:
                aggregates[phase][key]={}
        if hypothesis in aggregates['target'][key]:
            raise AssertionError('duplicate aggregate hypothesis/query')
        identities=[(hypothesis,index,key) for index in range(3)]
        parents=[patch_rows[identity] for identity in identities]
        strict_same(row['patch_query_indices'],[index for index,_ in parents])
        strict_same(row['summary']['nodes'],[node for _,parent in parents for node in parent['summary']['nodes']])
        strict_same(row['summary']['area_exact_m2'],packed(sum(areas,F(0))))
        strict_same(row['summary']['component_areas_exact_m2'],[packed(area) for area in areas])
        strict_same(row['summary']['local_time_anchor_exact_s'],parents[0][1]['summary']['local_time_anchor_exact_s'])
        if row['summary']['node_count']!=sum(parent['summary']['node_count'] for _,parent in parents) or row['summary']['skipped_pieces']!=[]:
            raise AssertionError('aggregate node/zero-piece inventory changed')
        for phase in phases:
            aggregates[phase][key][hypothesis]=weighted_mixture([patch_phases[phase][identity] for identity in identities],[F(1)]*3)
        counts['summary_exact_records']+=verify_summary(row['summary'],*(aggregates[phase][key][hypothesis] for phase in ('target','finite_rule','represented')),removal,internal)
        defects['aggregate'][hypothesis+'/'+key]=statistic_defects(*(aggregates[phase][key][hypothesis] for phase in ('target','finite_rule','represented')))
    if counts['source_node_references']!=570 or counts['patch_node_references']!=1140:
        raise AssertionError('new source/patch reference counts differ')
    return phases,patch_phases,aggregates,areas,counts,defects,projection_diagnostics


def check_contrast_records(document,aggregates,removal,internal):
    if len(document['contrasts'])!=2:
        raise AssertionError('exactly two width contrasts required')
    count=0
    for row in document['contrasts']:
        key=row['query_id']
        expected_phases={}
        for phase in ('target','finite_rule','represented'):
            pair=aggregates[phase][key]
            expected_phases[phase]={quantity:pair['nonuniform']['moments'][quantity]-pair['uniform']['moments'][quantity] for quantity in PUBLIC_KEYS}
            for quantity in STAT:
                declaration=row['statistics_difference_nonuniform_minus_uniform'][phase][quantity]
                if declaration['available'] is not True or declaration['reason'] is not None:
                    raise AssertionError('positive-measure width statistic contrast unavailable')
                check_record(declaration['record'],pair['nonuniform']['statistics'][quantity]-pair['uniform']['statistics'][quantity])
                count+=1
        expected_phases.update({'rule_generation_defect':{quantity:expected_phases['finite_rule'][quantity]-expected_phases['target'][quantity] for quantity in PUBLIC_KEYS},
            'export_projection_defect':{quantity:expected_phases['represented'][quantity]-expected_phases['finite_rule'][quantity] for quantity in PUBLIC_KEYS},
            'total_defect':{quantity:expected_phases['represented'][quantity]-expected_phases['target'][quantity] for quantity in PUBLIC_KEYS}})
        for phase,quantities in expected_phases.items():
            for quantity,item in quantities.items():
                check_record(row['phase_difference_nonuniform_minus_uniform'][phase][public_name(quantity)],item)
                count+=1
        pair=aggregates['represented'][key]
        consistency={}
        for hypothesis,record in pair.items():
            m=record['moments']
            consistency[hypothesis]={'represented_translation_from_temperature_j':m['translation_from_temperature_j_m2'],
                'represented_translation_field_minus_temperature_energy_j':m['exported_minus_temperature_translation_j_m2'],
                'represented_binding_field_minus_supplied_cost_j':m['binding_energy_j_m2']-removal*m['released_m2'],
                'represented_internal_field_minus_supplied_cost_j':m['internal_energy_j_m2']-internal*m['released_m2']}
        for quantity,item in consistency['nonuniform'].items():
            check_record(row['energy_consistency_difference'][quantity],item-consistency['uniform'][quantity])
            count+=1
    return count


def phase_admissions(targets_by_group,phases_by_group,newton_by_group,anchor_temperature):
    output={}
    for group,query_targets in targets_by_group.items():
        maximum=shared_scales(query_targets.values(),anchor_temperature)
        output[group]={}
        for key,target in query_targets.items():
            finite=phases_by_group['finite_rule'][group][key]
            actual=phases_by_group['represented'][group][key]
            low=newton_by_group[120][group][key]
            high=newton_by_group[160][group][key]
            output[group][key]={
                'finite_rule_vs_target':admit_errors(finite,target,maximum,anchor_temperature,F('1e-60')),
                'represented_vs_finite_rule':admit_errors(actual,target,maximum,anchor_temperature,F('2e-10'),baseline=finite),
                'represented_vs_target':admit_errors(actual,target,maximum,anchor_temperature,F('2e-10')),
                'Newton120_vs_target':admit_errors(low,target,maximum,anchor_temperature,F('1e-100')),
                'Newton160_vs_target':admit_errors(high,target,maximum,anchor_temperature,F('1e-100')),
                'Newton120_160_change':admit_errors(low,target,maximum,anchor_temperature,F('1e-100'),baseline=high)}
    return output


def reference_mixtures(reference,targets_by_case,width_config,areas):
    patches={}
    aggregates={}
    for hypothesis,cases in width_config['hypotheses'].items():
        for index,case in enumerate(cases):
            for key in targets_by_case[case]:
                patches[hypothesis,index,key]=scale_record(reference[case][key],areas[index])
        for key in targets_by_case[cases[0]]:
            aggregates.setdefault(key,{})[hypothesis]=weighted_mixture([reference[case][key] for case in cases],areas)
    return patches,aggregates


def group_patch_records(records):
    result={}
    for (hypothesis,index,key),record in records.items():
        result.setdefault(hypothesis+'/'+str(index),{})[key]=record
    return result


def group_aggregates(records):
    result={}
    for key,pair in records.items():
        for hypothesis,record in pair.items():
            result.setdefault(hypothesis,{})[key]=record
    return result


def contrast_admissions(aggregates,newton_aggregates,anchor_temperature):
    target=aggregates['target']
    finite=aggregates['finite_rule']
    actual=aggregates['represented']
    low,high=newton_aggregates[120],newton_aggregates[160]
    return {
        'finite_rule_vs_target':admit_contrasts(finite,target,anchor_temperature,F('1e-60')),
        'represented_vs_finite_rule':admit_contrasts(actual,target,anchor_temperature,F('2e-10'),baseline=finite),
        'represented_vs_target':admit_contrasts(actual,target,anchor_temperature,F('2e-10')),
        'Newton120_vs_target':admit_contrasts(low,target,anchor_temperature,F('1e-100')),
        'Newton160_vs_target':admit_contrasts(high,target,anchor_temperature,F('1e-100')),
        'Newton120_160_change':admit_contrasts(low,target,anchor_temperature,F('1e-100'),baseline=high)}


def maxima(source,patch,aggregate,contrast):
    result={}
    for category,tree in (('source',source),('patch',patch),('aggregate',aggregate),('own_contrast',contrast)):
        grouped={}
        def visit(item,path):
            if isinstance(item,dict):
                if 'scaled_error' in item:
                    phase=next(component for component in path if component.endswith('_vs_target') or component in ('represented_vs_finite_rule','Newton120_160_change'))
                    grouped.setdefault(phase,[]).append((item['scaled_error'],'/'.join(map(str,path)),item['tolerance']))
                for key,value in item.items():
                    visit(value,path+[key])
        visit(tree,[])
        result[category]={}
        for phase,rows in grouped.items():
            maximum,location,tolerance=max(rows,key=lambda row:row[0])
            result[category][phase]={'maximum_scaled_error':float(maximum),'exact_scaled_error':packed(maximum),
                'location':location,'tolerance':str(tolerance),'checked_quantities':len(rows)}
    return result


def declarations(document,config):
    if document['schema']!='mhdlab-boundary-quadrature-v1' or document['parameter_status']!='manufactured':
        raise AssertionError('manufactured pure-boundary schema required')
    for key in ('host_budget_accepted','owner_implementation_verified','new_query_IVP_error_qualified'):
        if document[key] is not False:
            raise AssertionError('new boundary output improperly claims '+key)
    strict_same(document['source_admission']['file_sha256'],{key:item['sha256'] for key,item in config['source_binding']['files'].items()})
    expected={'unique_piece_supports':66,'unique_nodes':330,'source_queries':6,'source_query_node_references':570,
        'patch_queries':12,'patch_node_references':1140,'aggregates':4,'contrasts':2,
        'source_evolution_calls':0,'RHS_calls':0,'assembly_calls':0,'old_window_export_calls':0}
    strict_same(document['cache'],expected)
    expected_queries=[{key:item for key,item in row.items() if key!='coordinate'} for row in config['queries']]
    strict_same(document['queries'],expected_queries)


def main():
    sys.set_int_max_str_digits(16384)
    config,files=inputs()
    final_freeze=json.loads((HERE/'final_before_query_freeze.json').read_text())
    for name,digest in final_freeze['files_sha256'].items():
        if sha(HERE/name)!=digest:
            raise RuntimeError('independent frozen query source changed '+name)
    forbidden=[name for name in sys.modules if name=='mhdlab' or name.startswith('mhdlab.') or name.split('.')[0] in ('numpy','scipy')]
    if forbidden:
        raise RuntimeError('independent boundary verifier imported model or numerical package '+str(forbidden))
    if OUT.exists():
        raise RuntimeError('fresh checkpoint directory required; no automatic numerical retries')
    OUT.mkdir()
    width=files['input_config']
    problem=width['common_scalar_problem']
    removal=binary(problem['reservoir']['desorption_energy_ev'])*QE
    internal=binary(problem['reservoir']['internal_energy_ev'])*QE
    anchor_temperature=binary(problem['initial_temperature_k'])
    queries=new_queries(config,width)
    exact,supports,zero_catalog=targets(files['windows'],width,queries)
    if len(supports)!=66 or zero_catalog!=[] or sum(len(record['support_references']) for row in exact.values() for record in row.values())!=114:
        raise AssertionError('new exact support/query catalogue differs from frozen scope')
    independent={}
    checkpoint_hashes={}
    for precision in (120,160):
        independent[precision]=independent_level(exact,supports,removal,internal,precision)
        if independent[precision]['counts']['node_evaluations']!=330 or independent[precision]['counts']['source_query_node_references']!=570:
            raise AssertionError('independent node reuse counters differ')
        checkpoint=OUT/('Newton'+str(precision)+'_checkpoint.json')
        write(checkpoint,{'schema':'mitl-independent-new-boundary-rule-checkpoint-v1','precision':precision,
            'input_config_sha256':sha(HERE/'input_config.json'),'accepted_source_inputs':config['source_binding']['files'],
            'result':independent[precision]})
        checkpoint_hashes[checkpoint.name]=sha(checkpoint)
        print(json.dumps({'checkpoint':checkpoint.name,'sha256':sha(checkpoint),'counts':independent[precision]['counts']}),flush=True)
    producer=WORK/'producer/reference-run'
    producer_report=json.loads((producer/'report.json').read_text())
    if producer_report['config_sha256']!=sha(HERE/'input_config.json') or producer_report['result_file']!='boundary_quadrature.json':
        raise RuntimeError('producer config/result association changed')
    for name,digest in producer_report['artifact_sha256'].items():
        if sha(producer/name)!=digest:
            raise RuntimeError('saved producer artifact changed '+name)
    document_path=producer/producer_report['result_file']
    if sha(document_path)!=producer_report['result_sha256']:
        raise RuntimeError('saved boundary result hash changed')
    document=json.loads(document_path.read_text())
    declarations(document,config)
    rule=provided_rule(document)
    finite_cache,finite_counts=evaluate_supports(supports,rule,removal,internal)
    finite_records,references=query_moments(exact,finite_cache)
    if finite_counts['node_evaluations']!=330 or references!=570:
        raise AssertionError('provided-rule independent field recomputation counts differ')
    lookup,cache_checks=cache_readback(document,supports,finite_cache,removal,internal)
    phases,patch_phases,aggregates,areas,counts,stat_defects,area_diagnostics=query_readback(
        document,exact,finite_records,lookup,width,files['windows'],removal,internal)
    counts['primitive_cache_exact_field_checks']=cache_checks
    counts['contrast_exact_records']=check_contrast_records(document,aggregates,removal,internal)
    counts['CSV']=verify_csvs(producer,document)
    newton_sources={precision:level['queries'] for precision,level in independent.items()}
    newton_patches={}
    newton_aggregates={}
    for precision,records in newton_sources.items():
        newton_patches[precision],newton_aggregates[precision]=reference_mixtures(records,exact,width,areas)
    source_checks=phase_admissions(exact,phases,newton_sources,anchor_temperature)
    patch_grouped={phase:group_patch_records(records) for phase,records in patch_phases.items()}
    newton_patch_grouped={precision:group_patch_records(records) for precision,records in newton_patches.items()}
    patch_checks=phase_admissions(patch_grouped['target'],patch_grouped,newton_patch_grouped,anchor_temperature)
    aggregate_grouped={phase:group_aggregates(records) for phase,records in aggregates.items()}
    newton_aggregate_grouped={precision:group_aggregates(records) for precision,records in newton_aggregates.items()}
    aggregate_checks=phase_admissions(aggregate_grouped['target'],aggregate_grouped,newton_aggregate_grouped,anchor_temperature)
    contrast_checks=contrast_admissions(aggregates,newton_aggregates,anchor_temperature)
    maximum_records=maxima(source_checks,patch_checks,aggregate_checks,contrast_checks)
    write(OUT/'exact_targets.json',{'sources':exact,'supports':supports,'zero_piece_catalog':zero_catalog})
    write(OUT/'statistic_defects.json',stat_defects)
    write(OUT/'patch_weight_projection_diagnostics.json',area_diagnostics)
    write(OUT/'phase_records.json',{'source':phases,'patch':patch_phases,'aggregate':aggregates})
    write(OUT/'report.json',{
        'schema':'mitl-independent-positive-boundary-quadrature-report-v1','status':'passed','all_checks_passed':True,
        'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'source_sha256':final_freeze['files_sha256'],'producer_report_sha256':sha(producer/'report.json'),
        'producer_result_sha256':sha(document_path),'checkpoint_sha256':checkpoint_hashes,
        'new_work_counts':{'independent_Newton_precision_levels':2,'independent_Newton_node_evaluations':660,
            'provided_rule_node_field_recomputations':330,'total_new_rational_polynomial_node_evaluations':990,
            'independent_source_query_node_references_across_levels':1140,
            'producer_unique_supports':66,'producer_unique_nodes':330,'source_query_node_references':570,
            'patch_query_node_references':1140,'source_queries':6,'patch_queries':12,'aggregates':4,'contrasts':2,
            'old_source_evolution_RHS_window_export_reference_grid_IVP_calls':0},
        'exact_check_counts':counts,'maxima':maximum_records,
        'source_phase_checks':source_checks,'patch_phase_checks':patch_checks,'aggregate_phase_checks':aggregate_checks,
        'own_width_contrast_checks':contrast_checks,'zero_measure_algebra_control':zero_measure_control(),
        'forbidden_model_or_numerical_package_imports':forbidden,
        'new_query_IVP_error_qualified':False,'host_budget_accepted':False,'owner_implementation_verified':False,
        'quantity_context':'Source summaries use unit reference area. Patch/aggregate/contrast moments are actual physical extensive sums; internal helper keys retain source suffixes, and the validated public records use parent-number/J quantity names.',
        'artifact_sha256':{path.name:sha(path) for path in OUT.iterdir() if path.is_file()},
        'qualification':[
            'Pure deterministic boundary quadrature of accepted saved polynomial sources; no new source evolution, RHS, window export, IVP or previous numerical case is replayed.',
            'Exact ordinary-power-basis target algebra, finite Decimal80 rule defects, and actual exported binary-field defects remain separate and telescope exactly.',
            'Distinct Decimal120/160 Newton-Legendre changes are finite numerical comparisons, not certified bounds or exact algebraic Gauss nodes.',
            'Actual Eexport versus2kB*Texport and actual patch weight versus area*rounded areal weight are explicit separate projection diagnostics; no identities are repaired.',
            'Covariance/temperature variation and width signals use their own resolved target scales; normalized statistics condition on each phase own positive mass rather than renormalizing source weights.',
            'Prior source/interpolation/IVP qualifications remain inherited and separate; neither new query acquires an IVP accuracy claim here.',
            'Manufactured source times are not photon gates or registered experimental clocks. No molecular mass, velocity, spatial sampling, water/material/state catalog, transport, spectra, FLASH, Hall, owner or host acceptance is supplied.'
        ]})
    print(json.dumps({'status':'passed','report_sha256':sha(OUT/'report.json'),'maxima':maximum_records},indent=2))


if __name__=='__main__':
    main()
