"""New pure polynomial node queries, reused across nested windows and patches."""
from fractions import Fraction as F
from independent_rule import newton_rule
from source_targets import RAW,STAT,node_values,node_moments,statistics,integrate,multiply


def evaluate_supports(supports,rule,removal,internal):
    cache={}
    evaluations=0
    skipped=[]
    for identity,support in supports.items():
        if support['mass']==0:
            cache[identity]=[]
            skipped.append({'identity':identity,'reason':'exact_zero_emitted_mass'})
            continue
        cache[identity]=[]
        for index,(coordinate,weight) in enumerate(rule):
            node=node_values(support,coordinate,weight,removal,internal)
            node.update({'node_index':index,'coordinate':coordinate,'rule_weight':weight})
            cache[identity].append(node)
            evaluations+=1
    return cache,{'distinct_supports':len(supports),'positive_supports':sum(bool(rows) for rows in cache.values()),
        'node_evaluations':evaluations,'skipped_supports':len(skipped),'skipped_catalog':skipped}


def query_moments(targets,cache):
    result={}
    references=0
    for case,queries in targets.items():
        result[case]={}
        for key,target in queries.items():
            nodes=[node for identity in target['support_references'] for node in cache[identity]]
            references+=len(nodes)
            record=node_moments(nodes,target['query_start'])
            record['temperature_excursion_scale_k']=target['temperature_excursion_scale_k']
            record['attained_endpoint_temperatures_k']=target['attained_endpoint_temperatures_k']
            result[case][key]=record
    return result,references


def independent_level(targets,supports,removal,internal,precision):
    rule=newton_rule(precision)
    if any(abs(error)>F('1e-100') for error in rule['exact_rational_monomial_defects_through_degree9'].values()):
        raise ArithmeticError('independent finite-rule monomial accuracy unresolved')
    cache,counts=evaluate_supports(supports,rule['rule'],removal,internal)
    queries,references=query_moments(targets,cache)
    counts['source_query_node_references']=references
    counts['new_IVP_or_RHS_or_source_calls']=0
    return {'rule':rule,'node_cache':cache,'queries':queries,'counts':counts}


def zero_measure_control():
    """Independent algebraic empty-measure oracle, without a producer call."""
    derivative=[F(0),F(0),F(0)]
    tau=[F(1,7),F(2,7)]
    temperature=[F(900),F(1),F(2),F(3)]
    factors=([F(1)],tau,multiply(tau,tau),temperature,multiply(temperature,temperature),multiply(tau,temperature))
    moments={key:integrate(multiply(derivative,factor)) for key,factor in zip(RAW,factors)}
    normalized=statistics(moments)
    if any(moments.values()) or any(value is not None for value in normalized.values()):
        raise AssertionError('independent exact-zero reference failed')
    return {'exact_zero_moments':moments,'normalized_statistics':normalized,'positive_node_evaluations':0,
        'qualification':'This independent empty-measure algebra control does not execute or stand in for the producer zero-piece branch; exported saved-source skip catalogs are checked separately.'}
