"""Clarify an attained polynomial excursion scale before new execution."""
import datetime
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    target=HERE/'scale_definition_amendment.json'
    if target.exists() or (HERE/'quadrature-initial').exists() or (HERE.parent/'producer/reference-run/report.json').exists():
        raise RuntimeError('scale clarification must precede new batch and queries')
    original=json.loads((HERE/'before_plan_freeze.json').read_text())
    for name,digest in original['files_sha256'].items():
        if sha(HERE/name)!=digest:
            raise RuntimeError('changed prospective plan/input')
    document={'schema':'mitl-positive-boundary-prospective-scale-definition-v1',
        'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'original_plan_sha256':sha(HERE/'oracle_plan.json'),
        'original_before_plan_freeze_sha256':sha(HERE/'before_plan_freeze.json'),
        'config_sha256':sha(HERE/'input_config.json'),
        'temperature_excursion_scale':'The exact rational maximum-minus-minimum of T evaluated at every restricted-piece endpoint, including new query bounds and all intervening original source knots. These attained values define a resolved sampled excursion; this is not a certified global cubic range or an unlabelled control-hull bound.',
        'aggregate_excursion_scale':'The exact maximum-minus-minimum over those attained target values across every patch in the declared hypothesis/query, with patch supports retained. Extensive thermal scales multiply the areal capacity by physical total area once if such diagnostics are checked.',
        'zero_excursion':'If the endpoint excursion is exactly zero but any retained temperature polynomial is nonconstant, normalized mean-temperature error qualification is unsupported and rejected. Truly constant polynomials retain exact-zero variance/covariance semantics. No fake floor.',
        'unchanged':'Exact polynomial moments, variance/covariance integrals, all source/query inputs and all frozen numerical tolerances remain unchanged.',
        'new_query_or_boundary_batch_calls_before_amendment':0}
    target.write_text(json.dumps(document,indent=2,sort_keys=True,allow_nan=False)+'\n')
    print(json.dumps({'amendment_sha256':sha(target),'original_plan_sha256':document['original_plan_sha256']},indent=2))


if __name__=='__main__':
    main()
