"""Record completed execution gates without changing the active lease."""
import datetime
import hashlib
import json
from pathlib import Path

work = Path(__file__).resolve().parent
records = {
    'tests': work / 'tests/completion.json',
    'producer': work / 'producer/completion.json',
    'core_review': work / 'core-review/completion.json',
    'import_boundary_review': work / 'core-review/import-boundary-review.json',
}
documents = {key: json.loads(path.read_text()) for key, path in records.items()}
assert documents['tests']['passing_test_cases'] == 52
assert documents['tests']['exit_code'] == 0
assert documents['producer']['status'] == 'passed_saved_data_export_and_binary_field_readback'
record = {
    'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'event': 'boundary_quadrature_execution_milestone',
    'pass_id': work.name,
    'records': {key: {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
                for key, path in records.items()},
    'new_tests_passed': 52,
    'sole_export_completed': True,
    'source_RHS_or_evolution_calls': 0,
    'independent_verification_accepted': False,
    'next': 'Review frozen independent consumer, execute its sole new verification, and inspect actual results.',
    'lease_changed': False,
}
out = work / 'execution-milestone.json'
assert not out.exists()
out.write_text(json.dumps(record, indent=2) + '\n')
with (work.parent / 'mitl-upstream-journal.jsonl').open('a') as stream:
    stream.write(json.dumps(record) + '\n')
print(json.dumps(record, indent=2))
