"""Prepare a five-file positive boundary-quadrature patch over an exact complete checkout."""
import argparse
import ast
from decimal import Decimal
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path
import re
import shutil
import subprocess

WORK = Path(__file__).resolve().parent
REPO = Path('/workspace/Power-Flow')
BASE = 'ea82ae3094ae480cb9c370652fa1eb1c677d8de5'
HEAD = '5019b86aabf0472037b0fa3262922c3d0dcd2e95'
OUT = Path('/workspace/handoffs/mitl-boundary-quadrature-20261019T0810')
PUBLIC = ('mhdlab/boundary_quadrature.py', 'tests/test_boundary_quadrature.py',
    'tools/export_boundary_quadrature.py', 'configs/boundary_quadrature_manufactured.json',
    'docs/boundary_quadrature.md')
WRAPPERS = ('README.md', 'requirements.txt')
BASELINE_CONTEXT = ('requirements.txt', 'pyproject.toml', 'mhdlab/__init__.py', 'mhdlab/coupled_emission_windows.py')


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024*1024), b''):
            digest.update(block)
    return digest.hexdigest()


def object_pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('duplicate JSON key')
        result[key] = value
    return result


def finite_float(value):
    result = float(value)
    if not math.isfinite(result):
        raise ValueError('nonfinite JSON number')
    if result == 0 and Decimal(value) != 0:
        raise ValueError('nonzero JSON number underflows its representation')
    return result


def loads(data):
    return json.loads(data, object_pairs_hook=object_pairs, parse_float=finite_float,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def load(path):
    return loads(Path(path).read_text())


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False)+'\n')


def baseline_bytes(name):
    return subprocess.check_output(['git', 'show', BASE+':'+name], cwd=REPO)


def clean_head(expected):
    assert HEAD is not None and re.fullmatch('[0-9a-f]{40}', expected) and expected == HEAD
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == expected
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=REPO, text=True).strip()
    subprocess.run(['git', 'merge-base', '--is-ancestor', BASE, expected], cwd=REPO, check=True)
    changed = subprocess.check_output(['git', 'diff', '--name-only', BASE, expected], cwd=REPO, text=True).splitlines()
    assert set(changed) == set(PUBLIC) and len(changed) == len(PUBLIC)
    return expected


def dependency_context():
    pins = {}
    for name in BASELINE_CONTEXT:
        content = baseline_bytes(name)
        digest = hashlib.sha256(content).hexdigest()
        assert sha(REPO/name) == digest
        pins[name] = digest
    imports = {}
    for name in PUBLIC:
        if not name.endswith('.py'):
            continue
        tree = ast.parse((REPO/name).read_text())
        imports[name] = sorted({node.module or '' for node in ast.walk(tree) if isinstance(node, ast.ImportFrom)}
            | {alias.name for node in ast.walk(tree) if isinstance(node, ast.Import) for alias in node.names})
    return {'required_complete_baseline_checkout': True, 'baseline_commit': BASE,
        'standalone_source_subset': False, 'empty_initializer_added': False,
        'unchanged_context_sha256': pins, 'declared_imports': imports,
        'accepted_saved_data_schema_context': ['mhdlab/coupled_emission_windows.py'],
        'dependency_qualification': 'Accepted saved coefficient and source-accuracy records are inputs; no source, RHS, assembly, window export or IVP driver is replayed.',
        'selected_core_import_style': 'CLI and targeted tests load the standard-library-only new core file directly; the unchanged baseline package initializer is not used on that path.',
        'standalone_execution_qualified': False,
        'requirements_wrapper_origin': 'Exact bytes of baseline requirements.txt; complete checkout setup remains required.'}


def input_contract():
    """Bind actual saved-source and query declarations without a numerical import."""
    name = 'configs/boundary_quadrature_manufactured.json'
    config = load(REPO/name)
    assert config['schema'] == 'mhdlab-boundary-quadrature-manufactured-config-v1'
    assert config['parameter_status'] == 'manufactured'
    assert all(isinstance(config[key], str) and config[key].strip() for key in ('provenance', 'scope'))
    binding = config['source_binding']
    assert binding['path_base'] == '--source-dir is the accepted0737 pass directory'
    assert set(binding['files']) == {'report', 'windows', 'input_config', 'window_config',
                                    'independent_completion', 'independent_report', 'scientific_review'}
    for record in binding['files'].values():
        path = Path(record['relative_path'])
        assert not path.is_absolute() and '..' not in path.parts
        assert re.fullmatch('[0-9a-f]{64}', record['sha256'])
    expected = {'report': '69907c8ba61545b31e67675a2c71bf8b9453006ea9f705b6f16d02e5b1a233ac',
        'windows': '64e0ce6b9cb271ad423109f3e52db02ab6017eb0d2591bbc8bdb30ca50aba731',
        'independent_completion': '7c0715cb1a89b7126c391886ef9a1ea2100f7d9be6f50bb0cd4d07aa64ecfb2a',
        'independent_report': '80f6577f67dacb29ad5d1f53c13a85b89aa10ab160cd79daf000dd43ca48d733',
        'scientific_review': '29f5b4e5291eba8e42e46f8f64f41524771f875c6c720898feb1482d7b388de0'}
    assert all(binding['files'][key]['sha256'] == digest for key, digest in expected.items())
    assert binding['accepted_source_report_sha256'] == binding['files']['report']['sha256']
    assert binding['accepted_window_result_sha256'] == binding['files']['windows']['sha256']
    assert binding['original_width_config_sha256'] == binding['files']['input_config']['sha256'] == '22f21dae395f31f9a13186821c5364033b50f051aa7296f93839896c2fae4b56'
    assert binding['original_window_config_sha256'] == binding['files']['window_config']['sha256'] == '2e8f1eb938a89957d2453f801321365ac6513fa8154b4dd3b925c1a67df1b18c'
    method = config['method']
    assert method['rule'] == 'positive_Gauss_Legendre_5_on_unit_interval'
    assert type(method['decimal_precision']) is int and method['decimal_precision'] == 80
    assert type(method['nodes_per_positive_support']) is int and method['nodes_per_positive_support'] == 5
    assert method['polynomial_evaluation'] == 'exact_rational_after_finite_decimal_node_generation'
    assert method['export_projection'] == 'binary64_fields_once_then_exact_fraction_defects'
    assert method['weight_repair'] == 'none'
    queries = config['queries']
    assert len(queries) == 2 and len({item['window_id'] for item in queries}) == 2
    for item in queries:
        assert isinstance(item['window_id'], str) and item['window_id'].strip()
        assert item['coordinate'] == 'canonical_duration_fraction' and item['parameter_provenance'].strip()
        values = []
        for key in ('start_fraction', 'stop_fraction'):
            pair = item[key]
            assert set(pair) == {'numerator', 'denominator'}
            assert all(isinstance(pair[part], str) and re.fullmatch('0|[1-9][0-9]*', pair[part])
                       for part in ('numerator', 'denominator'))
            value = Fraction(int(pair['numerator']), int(pair['denominator']))
            assert str(value.numerator) == pair['numerator'] and str(value.denominator) == pair['denominator']
            values.append(value)
        assert 0 <= values[0] < values[1] <= 1
    quantity = config['quantity_contract']
    assert quantity['local_time_anchor'] == 'exact_query_start'
    assert quantity['joint_moments'] == ['1', 'local_time', 'local_time_squared', 'temperature',
                                         'temperature_squared', 'local_time_temperature']
    assert quantity['new_query_IVP_error'] == 'unavailable_no_new_reference_driver'
    assert quantity['zero_mass_normalization'] == 'unavailable_with_explicit_reason'
    defect = config['defect_contract']
    assert defect['layers'] == ['approximate_rule_minus_exact_polynomial',
        'exported_binary_fields_minus_approximate_rule', 'exported_binary_fields_minus_exact_polynomial']
    assert defect['closure'] == 'total_equals_rule_plus_projection_exactly'
    assert defect['normalization'] == 'never_renormalize_weights'
    declared = config['declared_counts']
    assert all(type(value) is int for value in declared.values())
    assert declared == {'unique_piece_supports': 66, 'unique_node_evaluations': 330,
        'source_query_node_references': 570, 'patch_node_references': 1140,
        'source_queries': 6, 'aggregate_queries': 4, 'contrasts': 2,
        'source_evolution_RHS_assembly_window_export_reference_driver_calls': 0}
    return {'config_path': name, 'config_sha256': sha(REPO/name), 'configuration': config,
        'parameter_status': 'manufactured', 'declared_counts': declared,
        'accepted_source_binding': binding, 'source_and_accuracy_records_are_inputs': True,
        'exact_rule_and_binary_projection_defects_separate': True,
        'new_query_IVP_error_qualification_supplied': False,
        'source_RHS_assembly_window_or_reference_driver_reexecution_admitted': False,
        'physical_parameters_adopted': False, 'host_or_owner_implementation_installed': False}


def command_snapshot_prefix(snapshot, live):
    """Accept only an immutable newline-terminated prefix of complete JSONL records."""
    assert snapshot and snapshot.endswith(b'\n') and live.startswith(snapshot)
    assert all(isinstance(loads(line), dict) for line in snapshot.splitlines())
    return {'sha256': hashlib.sha256(snapshot).hexdigest(), 'bytes': len(snapshot),
        'complete_records': len(snapshot.splitlines()),
        'qualification': 'Exact complete-record byte prefix; later verification/completion records may append.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--expected-head', required=True)
    args = parser.parse_args()
    head = clean_head(args.expected_head)
    for name in PUBLIC:
        assert (REPO/name).is_file() and not (REPO/name).is_symlink()
    context = dependency_context()
    contract = input_contract()
    payload = WORK/'delivery-preparation/payload'
    assert not payload.exists() and not OUT.exists() and not OUT.with_suffix('.tar.gz').exists()
    source = payload/'source'
    source.mkdir(parents=True)
    for name in PUBLIC:
        target = source/name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(REPO/name, target)
    (source/'requirements.txt').write_bytes(baseline_bytes('requirements.txt'))
    (source/'README.md').write_text(f'''# Manufactured positive joint boundary-quadrature patch

Five new public files and a patch are pinned to the approved checkout. Apply the
patch to the complete baseline at `{BASE}` before importing, exporting or testing
this reference. This source/ review subset is not a standalone package. No
initializer replacement or portable execution is supplied. The requirements
wrapper copies baseline requirements.txt byte-for-byte; retain the complete
checkout setup and initializer.

The new CLI and targeted tests load the new standard-library-only core file
directly. No original package initializer is changed. The baseline requirements
wrapper provides checkout context; no minimum standalone environment or portable
execution is qualified by this packet.

The new data handoff uses positive deterministic joint time, temperature, state
and emitted-number records from accepted complete-support source coefficients.
Exact polynomial targets, the finite 80-digit quadrature rule and defects in the
actual exported binary fields remain separate. Unique supports and nodes stay
distinct from source-query and patch references. Full association remains; no
velocity or position samples are created.

Accepted source and prior accuracy records are inputs. New adapter tests,
input controls, a saved-data export and an independent higher-precision
quadrature/power-basis check retain their own counts and code versions. No old
source, RHS, assembly, window export, reference grid or IVP driver is rerun.
No new IVP accuracy, physical material/water/monolayer, spectra, transport,
field, FLASH or host implementation is claimed.
''')
    save(payload/'source_file_list.json', {'byte_identical_public_files': list(PUBLIC), 'packaging_wrappers': list(WRAPPERS)})
    (payload/'source-files.sha256').write_text(''.join(f'{sha(source/name)}  {name}\n' for name in PUBLIC))
    (payload/'wrapper-files.sha256').write_text(''.join(f'{sha(source/name)}  {name}\n' for name in WRAPPERS))
    save(payload/'dependency_context.json', context)
    save(payload/'preparation.json', {'source_commit': head, 'base_commit': BASE,
        'input_contract': contract, 'dependency_context': context,
        'portable_execution_performed': False, 'physical_truth_validated': False,
        'public_source_sha256': {name: sha(REPO/name) for name in PUBLIC}})
    print(json.dumps({'payload': str(payload), 'source_commit': head, 'public_files': len(PUBLIC),
        'packaging_wrappers': len(WRAPPERS), 'complete_baseline_checkout_required': True}, indent=2))


if __name__ == '__main__':
    main()
