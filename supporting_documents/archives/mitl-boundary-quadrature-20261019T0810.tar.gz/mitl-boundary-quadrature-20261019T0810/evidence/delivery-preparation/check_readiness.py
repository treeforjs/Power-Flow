"""Read source text, AST literals and frozen pins without importing delivery helpers."""
import ast
import hashlib
import json
from pathlib import Path
import subprocess

WORK = Path(__file__).resolve().parents[1]
REPO = Path('/workspace/Power-Flow')
EXPECTED_HEAD = '5019b86aabf0472037b0fa3262922c3d0dcd2e95'
EXPECTED_BASE = 'ea82ae3094ae480cb9c370652fa1eb1c677d8de5'
EXPECTED_RECORDS = {'producer_run': '5fb0c7067016881296c853b5a702f362402e0fa620735c6bddb0e596406765f5', 'producer_completion': '06b3499af814c35a468690dec098457a954b8150a1918c69156deb1d4de5e03c', 'input_guards': 'db1d4b62b4403d0e6e82d9e37e12d4424af0f4cadb1859613a86199e28a42378', 'raw_config_binding': '2bcb4fd5b9e35bd90c7eb1718be4ecb471505e4784fd4724250a43d652566eaf', 'export_format_checks': '8e0dbb954221c477d57903404e8306d904129752972a6aa2b77ab9d1ec1eef65', 'import_boundary_amendment': 'ef7a7984d38335bd985bebf7285177c87cc4f7752dccd5ced76cd9fd0c6e79bc', 'import_boundary_review': 'd6c127aa1bb0e5ba4fb0911384c0309e01ecc2cfc37949b24244c433c35d55d1', 'producer_before_run': 'ba5fdabee8c7175f0c41a4d2257d4678f5082480a3f9e399d50afad4288130da', 'tests_completion': 'fc0e31a74ed0b7c8fee9592d66de9ab19430c103ef9867f3551719a3a7094c58', 'core_freeze': 'aa7235c9298ab19e021b646bee5c64a5ba101000ba936cd76cc964c2dbdc66a5', 'static_core_review': '99d166a32e7fe905e9113f5ecdd1f629d4cfd346df2111105e58a4f4e02266a7', 'oracle_completion': '356f3d1a3647272e440adccc79679368d2193530f9bcea05f4c39dad573b822a', 'oracle_report': '6d03f54d412e98969978d8ca1daa81f0ea6317dbee352f561ae412f0e8cc4103', 'oracle_summary': '65fc3e34f50667435142a7f607365b85434935ef3b8527ffc8c9f9c8cdcb2eb8', 'oracle_review': 'fcaf71505fae26aedfb564488beb56a64d9910bf5b4279b85acf701c2ae9f9dc', 'root_result_association': 'decb0b57869f1b714cd93d8376ef86a322709a6c478d062120b69b3d2df3bb2a', 'next_task_assessment': '24e9cdc4dbfdbdffd85292cbcf3bfe0df361edbb415b19530a198379e875634a'}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def literal(tree, key):
    found = [node.value for node in ast.walk(tree) if isinstance(node, ast.Assign)
             and any(isinstance(target, ast.Name) and target.id == key for target in node.targets)]
    assert len(found) == 1, key
    return ast.literal_eval(found[0])


def main():
    helper_names = ('prepare_delivery.py', 'freeze_delivery.py', 'verify_delivery.py')
    trees = {}
    for name in helper_names:
        text = (WORK/name).read_text()
        compile(text, str(WORK/name), 'exec')
        trees[name] = ast.parse(text)
        assert 'raise RuntimeError(' not in text
    prepare, freeze = trees['prepare_delivery.py'], trees['freeze_delivery.py']
    assert literal(prepare, 'HEAD') == EXPECTED_HEAD and literal(prepare, 'BASE') == EXPECTED_BASE
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == EXPECTED_HEAD
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=REPO, text=True).strip()
    public = literal(prepare, 'PUBLIC')
    assert len(public) == 5 and len(literal(prepare, 'WRAPPERS')) == 2
    assert set(subprocess.check_output(['git', 'diff', '--name-only', EXPECTED_BASE, EXPECTED_HEAD], cwd=REPO, text=True).splitlines()) == set(public)
    roles = literal(freeze, 'REPORT_PATHS')
    assert set(roles) == set(EXPECTED_RECORDS) and len(roles) == 17
    actual = {key: sha(WORK/name) for key, name in roles.items()}
    assert actual == EXPECTED_RECORDS
    results = literal(freeze, 'results')
    assert results['new_tests_passed'] == 52 and results['unique_nodes'] == 330
    assert results['unique_supports'] == 66 and results['total_new_rational_polynomial_node_evaluations'] == 990
    assert results['CSV_cells_checked'] == 68864 and results['typed_float_projections_checked'] == 18396
    assert results['old_source_RHS_assembly_window_export_IVP_calls'] == 0
    assert results['selected_task'] is None and results['new_lease_claimed'] is False
    assert results['portable_executions_performed'] is False
    assert json.loads((WORK/roles['next_task_assessment']).read_text())['followup_status'] == 'awaiting_receiver_contract_or_new_evidence'
    record = {'schema': 'mitl-boundary-quadrature-delivery-helper-readiness-v1', 'status': 'ready_for_root_execution',
        'source_commit': EXPECTED_HEAD, 'base_commit': EXPECTED_BASE,
        'helper_sha256': {name: sha(WORK/name) for name in helper_names},
        'record_paths': roles, 'record_sha256': actual, 'public_source_sha256': {name: sha(REPO/name) for name in public},
        'results': results, 'assessment_key': 'selected_task', 'followup_status': 'awaiting_receiver_contract_or_new_evidence',
        'validation_scope': 'Source text compilation, AST literal and frozen data-pin reads only; delivery helpers not imported or executed.',
        'scientific_model_test_or_oracle_calls': 0, 'assembly_freeze_or_verification_helpers_executed': False,
        'portable_execution_claimed': False}
    (WORK/'delivery-preparation/helper-readiness.json').write_text(json.dumps(record, indent=2, allow_nan=False)+'\n')
    print(json.dumps(record, indent=2))


if __name__ == '__main__':
    main()
