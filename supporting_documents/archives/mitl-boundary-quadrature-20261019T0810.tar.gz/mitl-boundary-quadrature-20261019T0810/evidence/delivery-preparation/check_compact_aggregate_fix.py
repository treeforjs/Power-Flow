"""Check the sole metadata repair against the published compact projection."""
import ast
import hashlib
import json
from pathlib import Path

WORK = Path(__file__).resolve().parents[1]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    old = WORK/'delivery-preparation/freeze_delivery.before_compact_aggregate_fix.py'
    current = WORK/'freeze_delivery.py'
    assert sha(old) == '7aa4dfc2cdefb289779b08529f606d0d13b5c16726c20f80df0b2ade5adb822c'
    before, after = ast.parse(old.read_text()), ast.parse(current.read_text())
    before_function = next(n for n in before.body if isinstance(n, ast.FunctionDef) and n.name == 'verify_independent_and_followup')
    after_function = next(n for n in after.body if isinstance(n, ast.FunctionDef) and n.name == 'verify_independent_and_followup')
    # The one old aggregate/contrast assertion becomes compact aggregate plus unchanged contrast assertions.
    old_assert = next(n for n in before_function.body if isinstance(n, ast.Assert)
                      and "root['aggregate_queries']" in ast.unparse(n))
    new_asserts = [n for n in after_function.body if isinstance(n, ast.Assert)
                   and ("root['aggregate_queries']" in ast.unparse(n) or "root['contrasts']" in ast.unparse(n))]
    assert len(new_asserts) == 2
    before_function.body.remove(old_assert)
    for node in new_asserts:
        after_function.body.remove(node)
    assert ast.dump(before, include_attributes=False) == ast.dump(after, include_attributes=False)
    compile(current.read_text(), str(current), 'exec')
    result = json.loads((WORK/'producer/reference-run/boundary_quadrature.json').read_text())
    root = json.loads((WORK/'root-result-association.json').read_text())
    expected = [{**{key: row[key] for key in ('hypothesis', 'query_id', 'state_id')},
                 'summary': {key: value for key, value in row['summary'].items() if key != 'nodes'}}
                for row in result['aggregate_queries']]
    assert root['aggregate_queries'] == expected
    assert root['contrasts'] == result['contrasts']
    out = Path('/workspace/handoffs/mitl-boundary-quadrature-20261019T0810')
    assert not out.exists() and not out.with_suffix('.tar.gz').exists()
    record = {'schema': 'mitl-delivery-compact-aggregate-metadata-correction-v1',
        'status': 'passed_focused_metadata_check', 'initial_freeze_helper_sha256': sha(old),
        'corrected_freeze_helper_sha256': sha(current),
        'failed_log': 'freeze-delivery.log',
        'failed_log_sha256': sha(WORK/'freeze-delivery.log'),
        'failure': 'Full aggregate equality incorrectly required repeated summary nodes deliberately omitted by the hash-bound root association.',
        'correction': 'Compare hypothesis/query/state plus every summary field except nodes; retain full contrast equality.',
        'only_two_assertions_changed_AST_proof': True,
        'compact_aggregates_checked': len(expected), 'full_contrasts_checked': len(result['contrasts']),
        'source_document_sha256': sha(WORK/'producer/reference-run/boundary_quadrature.json'),
        'root_association_sha256': sha(WORK/'root-result-association.json'),
        'partial_output_directory_exists': False, 'partial_archive_exists': False,
        'scientific_model_or_core_or_test_or_oracle_calls': 0,
        'delivery_helpers_imported_or_executed': False}
    target = WORK/'delivery-preparation/compact-aggregate-correction.json'
    assert not target.exists()
    target.write_text(json.dumps(record, indent=2)+'\n')
    print(json.dumps(record, indent=2))


if __name__ == '__main__':
    main()
