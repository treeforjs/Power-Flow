"""Journal the bounded positive joint boundary quadrature allocation."""
import datetime,fcntl,hashlib,json
from pathlib import Path
w=Path(__file__).resolve().parent
prior=w.parent/'mitl-upstream-20261019T0737'
def pin(p):return {'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
with (w.parent/'mitl-upstream-status.lock').open('a+') as lock:
    fcntl.flock(lock,fcntl.LOCK_EX)
    s=json.loads((w.parent/'mitl-upstream-status.json').read_text());l=json.loads((w/'lease.json').read_text())
    assert s['active_lease_owner']==w.name and s['reserved_paths']==l['reserved_paths']
    assert datetime.datetime.fromisoformat(s['active_editing_lease_until_utc'])>datetime.datetime.now(datetime.timezone.utc)
    r={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'event':'bounded_work_allocation','pass_id':w.name,
       'lease':pin(w/'lease.json'),'claim_command_log':pin(prior/'claim-boundary-quadrature-lease.log'),
       'initial_checks':{'workspace_available':True,'correct_branch':True,'clean_baseline':l['baseline_commit'],
          'saved_status_sha256':l['status_before_sha256'],'latest_local_handoff_read_before_selection':True,
          'other_unexpired_lease':False,'prior_reservations_empty':True,'prior_handoff_hash_verified':True},
       'selected_task':l['task'],'selected_proposal':pin(w/'selected-proposal.json'),
       'allocation':{'core':'stdlib-only accepted-byte admission, positive finite-rule quadrature and exported-field defect ledgers',
          'tests':'fresh analytic polynomial/rule/representation/admission controls only',
          'producer':'one two-query boundary export with full input/acceptance identity and cache/reference counts',
          'independent_verification':'new exact power-basis targets, distinct Newton-Legendre high-precision rule and actual binary-field moment checks',
          'review':'prospective frozen plan, source/code and actual saved result; no numerical calls',
          'delivery':'metadata-only compact patch/evidence helpers; root execution',
          'root':'guide, actual results, commits, delivery/status and useful next selection'},
       'prospective_counts':{'source_queries':6,'distinct_piece_supports':66,'unique_node_evaluations':330,
          'source_query_node_references':570,'patch_node_references':1140,'aggregates':4,'contrasts':2},
       'preproduction_budgets':{'finite_rule_digits':80,'independent_rule_digits':[120,160],
          'independent_ladder':'1e-100','finite_rule_target':'1e-60','represented_fields_and_own_contrasts':'2e-10'},
       'limits':'No normalization, physical velocity/position sampling, source/RHS/old assembly/window export or IVP replay; no new-query IVP accuracy claim. Prior source and interpolation qualifications remain separate.'}
    p=w/'allocation.json';assert not p.exists();p.write_text(json.dumps(r,indent=2)+'\n')
    with (w.parent/'mitl-upstream-journal.jsonl').open('a') as f:f.write(json.dumps(r)+'\n')
print(json.dumps({'allocation':pin(p),'reserved_paths':l['reserved_paths']},indent=2))
