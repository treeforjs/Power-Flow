# Receiver contract needed after quadrature acceptance

This is a local handoff request, conditional on acceptance of the current
quadrature export. It has not been sent externally. The offered interface is
seven hash-bound accepted input files and, if the frozen export confirms the
planned counts, 330 positive weighted nodes with explicit source-query and patch
references. These are deterministic quadrature records, not velocity or position
samples. Numerical handoff readiness does not establish physical transport or
host acceptance.

The receiver owner should identify one concrete reader/API and supply:

- The accepted schema, implementation version and units. Prefer the actual
  patch views, whose number weights already include area; never multiply those
  weights by area again. The cache has areal weights with no area applied, and
  its projected float is diagnostic. An equivalent patch weight must use true
  area times the **unprojected exact areal reference**, then project once; do not
  multiply the rounded areal float by area.
- The retained `node_id`, source history, `state_id`, query, hypothesis and patch
  identity, plus exact patch range, length and area. Reused references across
  overlapping queries are not independent emission events.
- The binary `time_s` and exact query-start anchor convention. Local time is the
  exact represented global time minus that anchor; its rational diagnostic is
  not a second binary time input. This source clock is not a registered photon
  observation clock.
- The actual binary temperature and number-weight fields, the separately
  projected expected translation, supplied desorption and internal energies,
  and their unit conventions. Preserve the time–temperature–state association.
  The expected translation field and `2*kB*T` evaluated from the received
  temperature have a retained rounding difference; neither silently replaces
  the other. No molecular mass, velocity distribution or physical state map is
  supplied by this handoff.
- The receiver precision, explicit conversion rules, unsupported-input policy
  and numerical acceptance thresholds. Weight renormalization, clipped weights,
  inferred unavailable channels and silent state aliases are not acceptable.

One useful owner-produced readback is a JSON record bound to the original export
report/result hashes and the receiver version. It should report admitted input
hashes; node/reference counts; and, for each source query and patch/hypothesis
view, sums of `w`, `w*tau`, `w*tau^2`, `w*T`, `w*T^2`, `w*tau*T`, supplied energy
channels and received expected translation. Compute these from the actual
received binary fields. Report the resulting means, variances and mandatory
`Cov(tau,T)`, availability flags and energy-field consistency differences.
Compare them with the export's **represented** records, retaining any precision
or unit-conversion differences. Do not compare only with exact polynomial
targets or discard the finite-rule and projection defect layers. A wrong-input
hash rejection can accompany that same admission record; no source or IVP
recalculation is required.

This would enable a concrete receiver admission check. The existing fixed linear
full-width control can then be evaluated with the owner's actual response
functional using a width-only redistribution of the **same** joint source.
Equal prescribed power in the uniform and nonuniform heating examples does not
make their emitted source mixtures equal, so that pair is not an equality null.
Physical fields, losses/collection, kinetics/response and host transactions stay
with their owners. This delivery does not wait for an owner response.
