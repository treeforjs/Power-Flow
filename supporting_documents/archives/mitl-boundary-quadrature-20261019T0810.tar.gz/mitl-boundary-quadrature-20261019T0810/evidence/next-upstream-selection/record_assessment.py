"""Record saved dependency evidence without source or numerical execution."""
import hashlib
import json
from pathlib import Path

WORK = Path(__file__).resolve().parents[1]
STATUS = WORK/'status-before-lease.json'
FOLLOWUP = 'awaiting_receiver_contract_or_new_evidence'
NEED = ('Obtain a concrete receiver reader/unit/precision contract and one hash-bound readback '
        'of the accepted joint node and patch fields; then test actual receiver admission and '
        'the existing fixed linear full-width control with a width-only redistribution of the same source.')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    saved = json.loads(STATUS.read_text())
    queue = saved['next_work']
    assert [item['priority'] for item in queue[1:]] == list(range(2,8))
    controls = saved['owner_response_controls']
    descriptor = Path(controls['source_ledger_owner_handoff'])
    handoff = json.loads(descriptor.read_text())
    assert handoff['host_budget_accepted'] is False and handoff['owner_implementation_verified'] is False
    contexts = handoff['required_owner_context']
    assert len(contexts) == 6 and all(value == 'pending_owner_supplied' for value in contexts.values())
    refs = {
        'saved_status': STATUS,
        'lease': WORK/'lease.json',
        'existing_owner_controls': Path(controls['handoff']),
        'existing_windowed_packet_readback': Path(controls['windowed_packet_readback']),
        'existing_fixed_allocation_qualification': Path(controls['fixed_allocation_qualification']),
        'existing_owner_handoff': descriptor,
        'receiver_contract_request': WORK/'next-upstream-selection/receiver-contract-request.md',
    }
    expected = {
        'existing_owner_controls': controls['sha256'],
        'existing_windowed_packet_readback': controls['windowed_packet_readback_sha256'],
        'existing_fixed_allocation_qualification': controls['fixed_allocation_qualification_sha256'],
    }
    assert all(sha(refs[key]) == digest for key, digest in expected.items())
    current_paths = {
        'producer_completion': 'producer/completion.json',
        'independent_completion': 'independent-verification/completion.json',
        'static_oracle_review': 'oracle-review/completion.json',
        'root_result_association': 'root-result-association.json',
    }
    assert all((WORK/name).is_file() for name in current_paths.values())
    current = {key: {'path': str(WORK/name), 'sha256': sha(WORK/name)} for key,name in current_paths.items()}
    record = {
        'schema': 'mitl-next-upstream-task-assessment-v1',
        'status': 'assessment_complete', 'followup_status': FOLLOWUP, 'selected_task': None,
        'receiver_readback_need': NEED, 'no_new_lease_claimed': True,
        'current_bounded_work_is_being_completed': True,
        'conditional_on_current_acceptance': True,
        'current_acceptance_evidence': current,
        'no_authorized_useful_unblocked_upstream_task_under_present_inputs': True,
        'reason': ('Numerical joint-source representation, finite-width source comparison, full-width '
                   'functional controls and pure source-ledger admission are already available. '
                   'The missing useful next interface check is admission by a concrete receiver; '
                   'a new generic mock kernel or format-only exercise would not establish that.'),
        'existing_control_evidence': {
            'exact_full_width_functional_controls': controls['exact_full_width_functional_controls'],
            'manufactured_apertures': controls['manufactured_apertures'],
            'physical_spectra_calculated': controls['physical_spectra_calculated'],
            'owner_implementation_verified': controls['owner_implementation_verified'],
            'windowed_packet_exact_full_width_controls': controls['windowed_packet_exact_full_width_controls'],
            'fixed_allocation_qualified_mean_observables': controls['sampling_qualified_mean_observables'],
            'fixed_allocation_qualified_cross_covariances': controls['sampling_qualified_independent_cross_covariances'],
            'source_ledger_admission_available': controls['source_ledger_admission_available'],
        },
        'first_useful_interface_check': {
            'task': NEED, 'status': 'blocked_on_concrete_receiver_contract_or_owner_readback',
            'minimal_missing_input': ('One named receiver/API and its time/state/weight/unit/precision '
                                      'conventions, or one owner-produced hash-bound readback using the '
                                      'actual received binary fields. Physical kinetics are not required '
                                      'for this initial numerical admission check.'),
            'local_request': str(refs['receiver_contract_request']),
            'external_request_sent': False,
            'not_an_equality_null': 'Matched prescribed input across distinct heating histories does not preserve their emitted mixtures.',
            'equality_null': 'Use a width-only redistribution of the same complete joint source and a fixed linear full-width response.',
        },
        'pending_physical_owner_context': contexts,
        'other_missing_inputs': {
            'VUV_observation_mapping': 'Actual reduction/instrument response, same-quantity forward mapping, shot/gate/bin/background definitions and justified covariance/calibration.',
            'physical_inventory': 'Explicit parent monolayer convention, pool allocation and qualified kinetics/energy inputs for the actual surface.',
            'actual_foil_properties': 'New actual-foil phase/thermodynamic/geometry evidence; no extrapolated or invented defaults.',
            'FLASH': 'Installed licensed source and configured workstation plus actual field/unit/material/Hall interfaces.',
            'full_text': 'New legitimate full-text location or owner-supplied copy; recorded blocked routes are not retried.',
        },
        'new_evidence_lead_identified': False,
        'cached_lead_qualification': ('The cached 1986 DOI already has a verified Fe2O3(001) title in '
                                     'the saved metadata record and no acquired full text. Its stale '
                                     'unverified citation entry is not a new physical 304 lead.'),
        'preserved_queue_items_2_through_7': queue[1:],
        'record_references': {key: {'path': str(path), 'sha256': sha(path)} for key,path in refs.items()},
        'assessment_source_sha256': sha(Path(__file__)),
        'new_source_acquisition_or_network_calls': 0,
        'source_or_test_or_oracle_or_owner_calls': 0,
        'old_scientific_audits_or_cases_replayed': False,
        'public_files_changed': [], 'live_status_changed': False,
        'host_budget_accepted': False, 'owner_implementation_verified': False,
        'physical_truth_verified': False,
    }
    target = WORK/'next-upstream-selection/assessment.json'
    assert not target.exists()
    target.write_text(json.dumps(record,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'assessment': str(target), 'sha256': sha(target),
                      'followup_status': FOLLOWUP, 'selected_task': None},indent=2))


if __name__ == '__main__':
    main()
