# Manufactured positive joint boundary-quadrature patch

Five new public files and a patch are pinned to the approved checkout. Apply the
patch to the complete baseline at `ea82ae3094ae480cb9c370652fa1eb1c677d8de5` before importing, exporting or testing
this reference. This source/ review subset is not a standalone package. No
initializer replacement or portable execution is supplied. The requirements
wrapper copies baseline requirements.txt byte-for-byte; retain the complete
checkout setup and initializer.

The new CLI and targeted tests load the new standard-library-only core file
directly. No original package initializer is changed. The baseline requirements
wrapper provides checkout context; no minimum standalone environment or portable
execution is qualified by this packet.

The new data handoff uses positive deterministic joint time, temperature, state
and emitted-number records from accepted complete-support source coefficients.
Exact polynomial targets, the finite 80-digit quadrature rule and defects in the
actual exported binary fields remain separate. Unique supports and nodes stay
distinct from source-query and patch references. Full association remains; no
velocity or position samples are created.

Accepted source and prior accuracy records are inputs. New adapter tests,
input controls, a saved-data export and an independent higher-precision
quadrature/power-basis check retain their own counts and code versions. No old
source, RHS, assembly, window export, reference grid or IVP driver is rerun.
No new IVP accuracy, physical material/water/monolayer, spectra, transport,
field, FLASH or host implementation is claimed.
