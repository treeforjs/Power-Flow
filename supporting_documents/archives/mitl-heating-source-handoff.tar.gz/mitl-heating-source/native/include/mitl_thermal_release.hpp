#pragma once

#include <cmath>
#include <cstddef>
#include <initializer_list>
#include <limits>
#include <set>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

namespace quark::physics::surface {

using Matrix = std::vector<std::vector<double>>;

// Exact SI constants. These are unit definitions, not material properties.
inline constexpr double boltzmann_j_k = 1.380649e-23;
inline constexpr double electron_volt_j = 1.602176634e-19;

namespace detail {

inline void nonnegative(double value, const char* name) {
    if (!std::isfinite(value) || value < 0.0) {
        throw std::invalid_argument(std::string(name) + " must be finite and nonnegative");
    }
}

inline void positive(double value, const char* name) {
    nonnegative(value, name);
    if (value == 0.0) {
        throw std::invalid_argument(std::string(name) + " must be positive");
    }
}

inline bool whitespace(char value) {
    return value == ' ' || value == '\t' || value == '\n' || value == '\r'
        || value == '\f' || value == '\v';
}

inline void label(const std::string& value, const char* name) {
    if (value.empty() || whitespace(value.front()) || whitespace(value.back())) {
        throw std::invalid_argument(std::string(name) + " must be nonempty without surrounding whitespace");
    }
}

inline std::size_t matrix_width(const Matrix& values, const char* name) {
    if (values.empty() || values.front().empty()) {
        throw std::invalid_argument(std::string(name) + " must be a nonempty rectangular matrix");
    }
    const auto width = values.front().size();
    for (const auto& row : values) {
        if (row.size() != width) {
            throw std::invalid_argument(std::string(name) + " must be rectangular");
        }
        for (double value : row) {
            nonnegative(value, name);
        }
    }
    return width;
}

// Neumaier accumulation retains small inventory residuals after cancellation.
inline double compensated_sum(std::initializer_list<double> values) {
    double sum = 0.0;
    double correction = 0.0;
    for (double value : values) {
        const double next = sum + value;
        if (!std::isfinite(next)) {
            throw std::overflow_error("thermal release sum exceeds finite double range");
        }
        correction += std::abs(sum) >= std::abs(value)
            ? (sum - next) + value : (value - next) + sum;
        sum = next;
    }
    const double result = sum + correction;
    if (!std::isfinite(result)) {
        throw std::overflow_error("thermal release sum exceeds finite double range");
    }
    return result;
}

// Multiplication is scaled so a partial product cannot under/overflow while
// the final nonnegative result remains representable.
inline double product(std::initializer_list<double> factors) {
    double mantissa = 1.0;
    int exponent = 0;
    for (double factor : factors) {
        if (factor == 0.0) {
            return 0.0;
        }
        int power = 0;
        mantissa *= std::frexp(factor, &power);
        exponent += power;
    }
    const double result = std::ldexp(mantissa, exponent);
    if (!std::isfinite(result)) {
        throw std::overflow_error("thermal release product exceeds finite double range");
    }
    return result;
}

inline double ratio(double numerator, double denominator) {
    if (numerator == 0.0) {
        return 0.0;
    }
    int numerator_power = 0;
    int denominator_power = 0;
    const double numerator_fraction = std::frexp(numerator, &numerator_power);
    const double denominator_fraction = std::frexp(denominator, &denominator_power);
    const double result = std::ldexp(numerator_fraction / denominator_fraction,
                                   numerator_power - denominator_power);
    if (!std::isfinite(result)) {
        throw std::overflow_error("average release flux exceeds finite double range");
    }
    return result;
}

inline Matrix zeros(std::size_t rows, std::size_t columns) {
    return Matrix(rows, std::vector<double>(columns, 0.0));
}

}  // namespace detail

struct BindingReservoir {
    std::string name;
    std::string state_id;
    double attempt_frequency_s;
    double activation_energy_ev;
    double desorption_energy_ev;
    double internal_energy_ev;

    // Every material/state parameter is explicit, including zero internal energy.
    BindingReservoir(std::string pool_name, std::string gas_state_id,
                     double frequency_s, double activation_ev,
                     double desorption_ev, double internal_ev)
        : name(std::move(pool_name)), state_id(std::move(gas_state_id)),
          attempt_frequency_s(frequency_s), activation_energy_ev(activation_ev),
          desorption_energy_ev(desorption_ev), internal_energy_ev(internal_ev) {
        validate();
    }

    void validate() const {
        detail::label(name, "reservoir name");
        detail::label(state_id, "state_id");
        detail::positive(attempt_frequency_s, "attempt_frequency_s");
        detail::nonnegative(activation_energy_ev, "activation_energy_ev");
        detail::nonnegative(desorption_energy_ev, "desorption_energy_ev");
        detail::nonnegative(internal_energy_ev, "internal_energy_ev");
    }
};

struct SurfaceInventory {
    // Coverage [m^-2]: rows are binding pools; columns are surface width bins.
    Matrix coverage_m2;

    explicit SurfaceInventory(Matrix coverage) : coverage_m2(std::move(coverage)) {
        static_cast<void>(detail::matrix_width(coverage_m2, "coverage_m2"));
    }
};

struct EnergyBudgets {
    Matrix translational_energy_j_m2;
    Matrix internal_energy_j_m2;
    Matrix binding_energy_j_m2;
    Matrix total_wall_energy_debit_j_m2;
};

struct ThermalReleaseTrial {
    SurfaceInventory trial_inventory;
    std::vector<std::string> reservoir_names;
    std::vector<std::string> state_ids;
    std::vector<double> temperature_k;
    double dt_s;
    Matrix released_m2;
    Matrix average_flux_m2_s;
    Matrix translational_energy_j_m2;
    Matrix internal_energy_j_m2;
    Matrix binding_energy_j_m2;
    Matrix total_wall_energy_debit_j_m2;
    Matrix inventory_balance_residual_m2;
};

namespace detail {

inline void validate_pools(const std::vector<BindingReservoir>& pools) {
    if (pools.empty()) {
        throw std::invalid_argument("reservoirs must be nonempty");
    }
    std::set<std::string> names;
    for (const auto& pool : pools) {
        pool.validate();
        if (!names.insert(pool.name).second) {
            throw std::invalid_argument("reservoir names must be unique");
        }
    }
    // Different named pools may emit the same gas state.
}

inline void validate_shape(const Matrix& values, const std::vector<BindingReservoir>& pools,
                           const std::vector<double>& temperatures, const char* name) {
    validate_pools(pools);
    const auto width = matrix_width(values, name);
    if (values.size() != pools.size() || temperatures.size() != width) {
        throw std::invalid_argument("matrix shape must match reservoir count and temperature width bins");
    }
    for (double temperature : temperatures) {
        positive(temperature, "temperature_k");
    }
}

inline double log_hazard(const BindingReservoir& pool, double temperature, double dt) {
    double barrier = 0.0;
    if (pool.activation_energy_ev > 0.0) {
        int energy_power = 0;
        int constant_power = 0;
        int temperature_power = 0;
        const double energy_fraction = std::frexp(pool.activation_energy_ev, &energy_power);
        const double constant_fraction = std::frexp(boltzmann_j_k / electron_volt_j, &constant_power);
        const double temperature_fraction = std::frexp(temperature, &temperature_power);
        barrier = std::ldexp(energy_fraction / (constant_fraction * temperature_fraction),
                            energy_power - constant_power - temperature_power);
        if (!std::isfinite(barrier)) {
            return -std::numeric_limits<double>::infinity();
        }
    }
    return compensated_sum({std::log(pool.attempt_frequency_s), std::log(dt), -barrier});
}

inline std::pair<double, double> deplete(double coverage, double logarithmic_hazard) {
    if (coverage == 0.0) {
        return {0.0, 0.0};
    }
    const double log_coverage = std::log(coverage);
    if (logarithmic_hazard < std::log(std::numeric_limits<double>::epsilon())) {
        // In this regime the release fraction equals h to double relative
        // precision. Combine before exponentiation to retain N*h for h below
        // the smallest representable double; there is no physical rate floor.
        const double log_released = std::isinf(logarithmic_hazard)
            ? logarithmic_hazard : compensated_sum({log_coverage, logarithmic_hazard});
        const double released = std::exp(log_released);
        return {coverage - released, released};
    }
    if (logarithmic_hazard > std::log(std::numeric_limits<double>::max())) {
        return {0.0, coverage};
    }
    const double hazard = std::exp(logarithmic_hazard);
    const double released = coverage * (-std::expm1(-hazard));
    const double remaining = -hazard < std::log(std::numeric_limits<double>::min())
        ? std::exp(log_coverage - hazard) : coverage * std::exp(-hazard);
    return {remaining, released};
}

inline EnergyBudgets make_energy_budgets(const Matrix& released,
                                        const std::vector<BindingReservoir>& pools,
                                        const std::vector<double>& temperatures) {
    const auto width = temperatures.size();
    EnergyBudgets result{zeros(pools.size(), width), zeros(pools.size(), width),
                         zeros(pools.size(), width), zeros(pools.size(), width)};
    for (std::size_t row = 0; row < pools.size(); ++row) {
        for (std::size_t column = 0; column < width; ++column) {
            const auto& pool = pools[row];
            const double amount = released[row][column];
            const double translation = product({2.0, boltzmann_j_k, temperatures[column], amount});
            const double internal = product({pool.internal_energy_ev, electron_volt_j, amount});
            const double binding = product({pool.desorption_energy_ev, electron_volt_j, amount});
            result.translational_energy_j_m2[row][column] = translation;
            result.internal_energy_j_m2[row][column] = internal;
            result.binding_energy_j_m2[row][column] = binding;
            result.total_wall_energy_debit_j_m2[row][column] = compensated_sum({translation, internal, binding});
        }
    }
    return result;
}

}  // namespace detail

// These budgets do not infer a source rate or alter inventory. Desorption cost
// is referenced to the specified gas state with zero internal excitation;
// specified internal excitation is added once. The activation barrier controls
// the rate and is never debited again. Translation uses mean outgoing 2*kB*T
// for a thermally accommodating flux-weighted Maxwellian boundary.
inline EnergyBudgets energy_budgets(const Matrix& released_m2,
                                    const std::vector<BindingReservoir>& reservoirs,
                                    const std::vector<double>& temperature_k) {
    detail::validate_shape(released_m2, reservoirs, temperature_k, "released_m2");
    return detail::make_energy_budgets(released_m2, reservoirs, temperature_k);
}

// Exact first-order depletion for a temperature held fixed over this timestep.
// The input is never modified. The caller decides whether/when to commit the
// returned inventory, and separately applies particle injection and wall debit.
// No coupled temperature solve, emission velocity draw, molecular population
// model, spatial interpolation, or physical parameter inference is performed.
inline ThermalReleaseTrial release_step(const SurfaceInventory& inventory,
                                        const std::vector<BindingReservoir>& reservoirs,
                                        const std::vector<double>& temperature_k,
                                        double dt_s) {
    detail::validate_shape(inventory.coverage_m2, reservoirs, temperature_k, "coverage_m2");
    detail::positive(dt_s, "dt_s");
    const auto rows = reservoirs.size();
    const auto width = temperature_k.size();
    Matrix remaining = detail::zeros(rows, width);
    Matrix released = detail::zeros(rows, width);
    Matrix flux = detail::zeros(rows, width);
    Matrix residual = detail::zeros(rows, width);
    std::vector<std::string> names;
    std::vector<std::string> states;
    names.reserve(rows);
    states.reserve(rows);
    for (std::size_t row = 0; row < rows; ++row) {
        names.push_back(reservoirs[row].name);
        states.push_back(reservoirs[row].state_id);
        for (std::size_t column = 0; column < width; ++column) {
            const double original = inventory.coverage_m2[row][column];
            const auto [after, amount] = detail::deplete(original,
                detail::log_hazard(reservoirs[row], temperature_k[column], dt_s));
            remaining[row][column] = after;
            released[row][column] = amount;
            flux[row][column] = detail::ratio(amount, dt_s);
            // Subtract the original first to avoid an intermediate overflow
            // when coverage is close to the largest representable double.
            residual[row][column] = detail::compensated_sum({after, -original, amount});
        }
    }
    auto energy = detail::make_energy_budgets(released, reservoirs, temperature_k);
    return ThermalReleaseTrial{
        SurfaceInventory(std::move(remaining)), std::move(names), std::move(states), temperature_k,
        dt_s, std::move(released), std::move(flux),
        std::move(energy.translational_energy_j_m2), std::move(energy.internal_energy_j_m2),
        std::move(energy.binding_energy_j_m2), std::move(energy.total_wall_energy_debit_j_m2),
        std::move(residual)};
}

}  // namespace quark::physics::surface
