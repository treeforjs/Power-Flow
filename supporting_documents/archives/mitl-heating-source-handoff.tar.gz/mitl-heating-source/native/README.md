# Native finite-inventory release candidate

This header-only C++20 reference implements the same frozen-temperature
first-order source and explicit energy convention as the Python upstream core.
No Quark target, registration, runner or source tree is included.

```bash
make check BUILD_DIR=/tmp/mitl-surface-reference
```

Alternatively:

```bash
cmake -S . -B /tmp/mitl-surface-cmake -DCMAKE_BUILD_TYPE=Release
cmake --build /tmp/mitl-surface-cmake
ctest --test-dir /tmp/mitl-surface-cmake --output-on-failure
```

All reservoir parameters are mandatory. The activation barrier controls the
rate, while desorption energy, assigned internal energy and `2 kB T` translation
form the diagnostic wall debit. The routine returns a proposed inventory and
does not change accepted state or apply wall cooling.

The 11 runtime verification groups cover analytic depletion, independent pools,
finite exhaustion, constant-temperature subdivision, Arrhenius ratios, energy
ownership, tiny releases/survivors, scaled products, extreme finite inputs,
malformed values and nonmutating trials. Checks remain active under `NDEBUG`.
Native host integration and physical water parameter qualification are separate.
