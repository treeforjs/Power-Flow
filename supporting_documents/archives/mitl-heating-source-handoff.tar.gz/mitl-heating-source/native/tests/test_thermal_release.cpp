#include "mitl_thermal_release.hpp"

#include <algorithm>
#include <cmath>
#include <functional>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>
#include <vector>

namespace {

using quark::physics::surface::BindingReservoir;
using quark::physics::surface::Matrix;
using quark::physics::surface::SurfaceInventory;
using quark::physics::surface::boltzmann_j_k;
using quark::physics::surface::electron_volt_j;
using quark::physics::surface::energy_budgets;
using quark::physics::surface::release_step;

void require(bool condition, const std::string& message) {
    if (!condition) {
        throw std::runtime_error(message);
    }
}

void near(double actual, double expected, double relative, const std::string& message) {
    require(std::isfinite(actual) && std::isfinite(expected), message + ": nonfinite comparison");
    require(std::abs(actual - expected) <= relative * std::max(std::abs(actual), std::abs(expected)),
            message + ": values differ");
}

void rejects(const std::function<void()>& action, const std::string& message) {
    bool rejected = false;
    try {
        action();
    } catch (const std::invalid_argument&) {
        rejected = true;
    } catch (const std::overflow_error&) {
        rejected = true;
    }
    require(rejected, message);
}

void analytic_decay_and_flux() {
    const std::vector<BindingReservoir> pools{{"sample", "gas:state0", 1.0e12, 0.42, 0.3, 0.07}};
    const SurfaceInventory inventory({{3.0e19, 9.0e18}});
    const std::vector<double> temperatures{700.0, 900.0};
    const double dt = 2.0e-9;
    const auto result = release_step(inventory, pools, temperatures, dt);
    for (std::size_t index = 0; index < temperatures.size(); ++index) {
        const double hazard = pools[0].attempt_frequency_s * dt
            * std::exp(-pools[0].activation_energy_ev * electron_volt_j
                       / (boltzmann_j_k * temperatures[index]));
        const double expected = inventory.coverage_m2[0][index] * (-std::expm1(-hazard));
        near(result.released_m2[0][index], expected, 2.0e-14, "analytic release");
        near(result.trial_inventory.coverage_m2[0][index],
             inventory.coverage_m2[0][index] * std::exp(-hazard), 3.0e-14, "analytic survivor");
        near(result.average_flux_m2_s[0][index], expected / dt, 2.0e-14, "average flux");
    }
    require(result.reservoir_names == std::vector<std::string>{"sample"}, "reservoir identity");
    require(result.state_ids == std::vector<std::string>{"gas:state0"}, "state identity");
    require(result.temperature_k == temperatures && result.dt_s == dt, "temperature/time metadata");
}

void depletion_exhaustion_and_empty_inventory() {
    const std::vector<BindingReservoir> pools{{"fast", "gas:state0", 1.0e300, 0.0, 0.0, 0.0}};
    const auto result = release_step(SurfaceInventory({{2.5e19, 0.0}}), pools, {300.0, 300.0}, 1.0e10);
    require(result.released_m2 == Matrix{{2.5e19, 0.0}}, "exhaustion cannot emit beyond finite inventory");
    require(result.trial_inventory.coverage_m2 == Matrix{{0.0, 0.0}}, "inventory exhaustion");
    require(result.inventory_balance_residual_m2 == Matrix{{0.0, 0.0}}, "exhaustion exact balance");
    const auto repeated = release_step(result.trial_inventory, pools, {300.0, 300.0}, 1.0e10);
    require(repeated.released_m2 == Matrix{{0.0, 0.0}}, "exhausted reservoir stays exhausted");
}

void frozen_temperature_subdivision() {
    const std::vector<BindingReservoir> pools{{"pool", "gas:state0", 8.0e10, 0.3, 0.2, 0.0}};
    SurfaceInventory divided({{1.0e20}});
    const double dt = 1.0e-8;
    const auto whole = release_step(divided, pools, {500.0}, dt);
    double release_sum = 0.0;
    for (int step = 0; step < 20; ++step) {
        const auto trial = release_step(divided, pools, {500.0}, dt / 20.0);
        release_sum += trial.released_m2[0][0];
        divided = trial.trial_inventory;
    }
    near(divided.coverage_m2[0][0], whole.trial_inventory.coverage_m2[0][0], 1.0e-13,
         "constant-temperature subdivision survivor");
    near(release_sum, whole.released_m2[0][0], 1.0e-13, "constant-temperature subdivision release");
}

void arrhenius_ratio() {
    const double activation_ev = 0.45;
    const std::vector<BindingReservoir> pools{{"pool", "gas:state0", 1.0e5, activation_ev, 0.2, 0.0}};
    const auto result = release_step(SurfaceInventory({{1.0e18, 1.0e18}}), pools, {400.0, 600.0}, 1.0e-20);
    const double expected_ratio = std::exp(activation_ev * electron_volt_j / boltzmann_j_k
                                          * (1.0 / 400.0 - 1.0 / 600.0));
    near(result.average_flux_m2_s[0][1] / result.average_flux_m2_s[0][0], expected_ratio,
         4.0e-14, "Arrhenius temperature ratio");
}

void energy_ledger() {
    const std::vector<BindingReservoir> pools{
        {"site0", "gas:v0", 2.0e4, 4.0, 0.5, 0.08},
        {"site1", "gas:v0", 3.0e4, 8.0, 0.5, 0.08}};
    const Matrix amount{{4.0e18}, {4.0e18}};
    const auto energy = energy_budgets(amount, pools, {700.0});
    const double translation = amount[0][0] * 2.0 * boltzmann_j_k * 700.0;
    const double internal = amount[0][0] * 0.08 * electron_volt_j;
    const double binding = amount[0][0] * 0.5 * electron_volt_j;
    near(energy.translational_energy_j_m2[0][0], translation, 5.0e-16, "outgoing translation is 2kBT");
    near(energy.internal_energy_j_m2[0][0], internal, 5.0e-16, "state internal energy");
    near(energy.binding_energy_j_m2[0][0], binding, 5.0e-16, "binding energy");
    near(energy.total_wall_energy_debit_j_m2[0][0], translation + internal + binding,
         5.0e-16, "complete wall debit");
    require(energy.total_wall_energy_debit_j_m2[0][0] == energy.total_wall_energy_debit_j_m2[1][0],
            "activation barrier must not be charged as energy");
}

void tiny_hazard_and_compensated_balance() {
    const std::vector<BindingReservoir> pools{{"slow", "gas:state0", 1.0e-200, 0.0, 0.0, 0.0}};
    const auto result = release_step(SurfaceInventory({{1.0e300}}), pools, {300.0}, 1.0e-200);
    require(result.released_m2[0][0] > 0.0, "representable N*h survives unrepresentable hazard");
    near(result.released_m2[0][0], 1.0e-100, 3.0e-13, "tiny hazard scaled release");
    near(result.average_flux_m2_s[0][0], 1.0e100, 3.0e-13, "tiny hazard scaled flux");
    require(result.trial_inventory.coverage_m2[0][0] == 1.0e300, "sub-spacing release does not invent depletion");
    require(result.inventory_balance_residual_m2[0][0] == result.released_m2[0][0],
            "compensated residual reports sub-spacing release");
    const std::vector<BindingReservoir> immobile{{"immobile", "gas:state0", 1.0, 1.0e300, 0.0, 0.0}};
    const auto frozen = release_step(SurfaceInventory({{1.0e19}}), immobile,
                                     {std::numeric_limits<double>::denorm_min()}, 1.0);
    require(frozen.released_m2[0][0] == 0.0, "unrepresentably small release becomes zero without a rate floor");
}

void survivor_below_exponential_range() {
    const std::vector<BindingReservoir> pools{{"strong", "gas:state0", 800.0, 0.0, 0.0, 0.0}};
    const auto result = release_step(SurfaceInventory({{1.0e300}}), pools, {300.0}, 1.0);
    require(std::exp(-800.0) == 0.0, "fixture must underflow unscaled survival factor");
    require(result.trial_inventory.coverage_m2[0][0] > 0.0, "scaled survivor remains representable");
    near(result.trial_inventory.coverage_m2[0][0], std::exp(std::log(1.0e300) - 800.0),
         3.0e-12, "large-coverage survivor");
}

void scaled_energy_products() {
    const double denormal = std::numeric_limits<double>::denorm_min();
    const std::vector<BindingReservoir> pools{{"scaled", "gas:state0", 1.0, 0.0, denormal, denormal}};
    const auto tiny = energy_budgets({{1.0e300}}, pools, {1.0e-300});
    require(tiny.binding_energy_j_m2[0][0] > 0.0, "small eV*J product retained after multiplying coverage");
    const long double expected_binding = static_cast<long double>(denormal)
        * static_cast<long double>(electron_volt_j) * 1.0e300L;
    near(tiny.binding_energy_j_m2[0][0], static_cast<double>(expected_binding), 1.0e-15,
         "scaled binding energy");
    near(tiny.translational_energy_j_m2[0][0], 2.0 * boltzmann_j_k, 1.0e-15,
         "scaled translation retains product");
    const auto large = energy_budgets({{1.0e-300}}, pools, {1.0e300});
    near(large.translational_energy_j_m2[0][0], 2.0 * boltzmann_j_k, 1.0e-15,
         "large-temperature product stays finite");
    const std::vector<BindingReservoir> high_energy{
        {"high-energy", "gas:state0", 1.0, 0.0, std::numeric_limits<double>::max(),
         std::numeric_limits<double>::max()}};
    const auto finite = energy_budgets({{1.0e-300}}, high_energy, {1.0e300});
    const long double expected_large = static_cast<long double>(std::numeric_limits<double>::max())
        * static_cast<long double>(electron_volt_j) * 1.0e-300L;
    near(finite.binding_energy_j_m2[0][0], static_cast<double>(expected_large), 1.0e-15,
         "large energy scaled by tiny coverage");
}

void extreme_finite_inputs() {
    const double denormal = std::numeric_limits<double>::denorm_min();
    const double cold_temperature = denormal * 10000.0;
    const std::vector<BindingReservoir> cold{{"cold", "gas:state0", 1.0, denormal, 0.0, 0.0}};
    const auto cold_result = release_step(SurfaceInventory({{1.0e20}}), cold, {cold_temperature}, 1.0);
    const long double barrier = static_cast<long double>(denormal)
        / ((static_cast<long double>(boltzmann_j_k) / static_cast<long double>(electron_volt_j))
           * static_cast<long double>(cold_temperature));
    const long double cold_expected = 1.0e20L * (-std::expm1(-std::exp(-barrier)));
    near(cold_result.released_m2[0][0], static_cast<double>(cold_expected), 1.0e-15,
         "scaled barrier with a subnormal denominator");
    const double maximum = std::numeric_limits<double>::max();
    const std::vector<BindingReservoir> finite{{"large", "gas:state0", std::log(2.0), 0.0, 0.0, 0.0}};
    const auto maximum_result = release_step(SurfaceInventory({{maximum}}), finite, {300.0}, 1.0);
    require(std::isfinite(maximum_result.inventory_balance_residual_m2[0][0]),
            "inventory residual avoids intermediate overflow near maximum coverage");
    near(maximum_result.released_m2[0][0], maximum / 2.0, 1.0e-15, "maximum finite coverage release");
}

void malformed_input_guards() {
    const double nan = std::numeric_limits<double>::quiet_NaN();
    const double inf = std::numeric_limits<double>::infinity();
    const std::vector<BindingReservoir> pools{{"valid", "gas:state0", 1.0, 0.0, 0.0, 0.0}};
    rejects([] { BindingReservoir("", "s", 1.0, 0.0, 0.0, 0.0); }, "empty reservoir label");
    rejects([] { BindingReservoir("a", " s", 1.0, 0.0, 0.0, 0.0); }, "state whitespace");
    rejects([] { BindingReservoir("a", "s", 0.0, 0.0, 0.0, 0.0); }, "zero attempt frequency");
    rejects([nan] { BindingReservoir("a", "s", 1.0, nan, 0.0, 0.0); }, "NaN energy");
    rejects([inf] { BindingReservoir("a", "s", inf, 0.0, 0.0, 0.0); }, "infinite frequency");
    rejects([] { BindingReservoir("a", "s", 1.0, 0.0, -1.0, 0.0); }, "negative binding cost");
    rejects([] { SurfaceInventory({}); }, "empty matrix");
    rejects([] { SurfaceInventory({{1.0}, {2.0, 3.0}}); }, "ragged matrix");
    rejects([] { SurfaceInventory({{-1.0}}); }, "negative inventory");
    rejects([nan] { SurfaceInventory({{nan}}); }, "NaN inventory");
    rejects([&pools] { release_step(SurfaceInventory({{1.0}}), pools, {0.0}, 1.0); }, "zero temperature");
    rejects([&pools] { release_step(SurfaceInventory({{1.0}}), pools, {300.0}, -1.0); }, "negative dt");
    rejects([&pools] { release_step(SurfaceInventory({{1.0}}), pools, {300.0, 400.0}, 1.0); }, "width mismatch");
    rejects([&pools] { release_step(SurfaceInventory({{1.0}, {1.0}}), pools, {300.0}, 1.0); }, "pool mismatch");
    rejects([&pools] { release_step(SurfaceInventory({{1.0}}), {}, {300.0}, 1.0); }, "empty reservoirs");
    rejects([&pools] { release_step(SurfaceInventory({{1.0}, {1.0}}), {pools[0], pools[0]}, {300.0}, 1.0); },
            "duplicate reservoir identities");
    rejects([&pools, inf] { energy_budgets({{inf}}, pools, {300.0}); }, "nonfinite release budget");
    rejects([&pools] { energy_budgets({{1.0e308}}, pools, {1.0e308}); }, "energy overflow");
    const std::vector<BindingReservoir> fast{{"fast", "gas:state0", 1.0e308, 0.0, 0.0, 0.0}};
    rejects([&fast] { release_step(SurfaceInventory({{1.0e308}}), fast, {300.0}, 1.0e-100); }, "flux overflow");
}

void immutable_inputs_and_named_pools() {
    const SurfaceInventory inventory({{1.0e20, 2.0e20}, {3.0e20, 4.0e20}});
    const Matrix saved = inventory.coverage_m2;
    const std::vector<BindingReservoir> pools{
        {"siteA", "gas:same-state", 1.0e5, 0.2, 0.3, 0.04},
        {"siteB", "gas:same-state", 2.0e5, 0.3, 0.4, 0.04}};
    const std::vector<double> temperature{400.0, 800.0};
    auto result = release_step(inventory, pools, temperature, 1.0e-5);
    require(inventory.coverage_m2 == saved, "release trial must not mutate input coverage");
    result.trial_inventory.coverage_m2[0][0] = 0.0;
    require(inventory.coverage_m2 == saved, "returned inventory must not alias input");
    require(pools[0].name == "siteA" && temperature == std::vector<double>({400.0, 800.0}),
            "metadata inputs are unchanged");
    rejects([&inventory, &pools] { release_step(inventory, pools, {400.0, 0.0}, 1.0); }, "invalid trial rejects");
    require(inventory.coverage_m2 == saved, "invalid trial cannot mutate inventory");
}

}  // namespace

int main() {
    const std::vector<std::pair<std::string, std::function<void()>>> tests{
        {"analytic decay and flux", analytic_decay_and_flux},
        {"depletion exhaustion", depletion_exhaustion_and_empty_inventory},
        {"frozen-temperature subdivision", frozen_temperature_subdivision},
        {"Arrhenius ratio", arrhenius_ratio},
        {"energy ledger", energy_ledger},
        {"tiny hazard and compensated balance", tiny_hazard_and_compensated_balance},
        {"scaled survivor", survivor_below_exponential_range},
        {"scaled energy products", scaled_energy_products},
        {"extreme finite inputs", extreme_finite_inputs},
        {"malformed input guards", malformed_input_guards},
        {"nonmutating named-pool trials", immutable_inputs_and_named_pools}};
    for (const auto& [name, test] : tests) {
        try {
            test();
            std::cout << "PASS " << name << '\n';
        } catch (const std::exception& error) {
            std::cerr << "FAIL " << name << ": " << error.what() << '\n';
            return 1;
        }
    }
    std::cout << tests.size() << " surface-release verification groups passed\n";
    return 0;
}
