"""Independent heating, evidence and boundary-source reference components."""
