# Heating and boundary-source reference

This standalone package contains the upstream FLASH extraction, thermal-release,
source-comparison and reconstruction components. It imports no legacy runner and
does not implement Boltzmann or collisional-radiative evolution.

```bash
python -m pip install -r requirements.txt
python -m pytest -q
python tools/export_flash_surface.py --demo
python tools/run_surface_release.py --demo --plot
python tools/run_planar_release.py --demo --plot
python tools/run_heating_benchmark.py --plot
python tools/sample_surface_boundary.py \
  --source runs/surface_release_reference/surface_release.h5 \
  --masses configs/manufactured_boundary_masses.json \
  --interval 80 --packets 4096 --seed 42
```

For resolved three-dimensional launches from the planar demonstration:

```bash
python examples/paired_planar_packets.py \
  --source runs/planar_release_reference/planar_release.h5 \
  --masses configs/manufactured_boundary_masses.json \
  --face-normal-coordinate-m 0 --normal-sign 1
```

Every demonstration uses manufactured inputs. External material-plane samples
cannot silently serve as desorption boundary temperatures. Follow
[the source workflow](docs/surface_release_pipeline.md),
[the extraction contract](docs/flash_surface_contract.md), and
[the drive-input guide](docs/flash_drive_inputs.md) for physical inputs and limits.
The [heating verification guide](docs/flash_heating_verification.md) describes
the analytic comparison assumptions and separate energy reservoirs.

[Recovered published evidence](docs/dissertation_recovery.md) retains original
figure coordinates, hashes and digitization bounds. Reproduction tools require
the exact dissertation PDF supplied separately with `--pdf`.

The source manifests identify packaged file bytes. The package initializer and
this guide are extraction-specific wrappers; numerical components are copied
from the pinned public project implementation. Quark integration is handled
through the accompanying owner handoff.
