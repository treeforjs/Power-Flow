"""Sample the paired planar boundary contract without running gap transport."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from mhdlab.planar_boundary import sample_planar_emission_packets
from mhdlab.planar_release_io import load_planar_release_history, plain_metadata
from tools.sample_surface_boundary import load_mass_config


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--masses", type=Path, required=True)
    parser.add_argument("--face-normal-coordinate-m", type=float, required=True)
    parser.add_argument("--normal-sign", type=int, choices=(-1, 1), required=True)
    parser.add_argument("--interval", type=int, default=24)
    parser.add_argument("--packets", type=int, default=4096)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--output-dir", type=Path, default=Path("runs/paired_planar_packets"))
    args = parser.parse_args()
    if args.packets < 1 or args.seed < 0:
        parser.error("packets must be positive and seed nonnegative")
    mass_config = load_mass_config(args.masses)
    history = load_planar_release_history(args.source)
    if not math.isclose(mass_config["current_direction_length_m"], float(history.z_edges_m[-1] - history.z_edges_m[0]),
                        rel_tol=64 * np.finfo(float).eps, abs_tol=0):
        parser.error("the declared current length must match the resolved planar extent")
    rng = np.random.default_rng(args.seed)
    draws = rng.random((args.packets, 7))
    while np.any(draws == 0):
        mask = draws == 0
        draws[mask] = rng.random(int(np.sum(mask)))
    packets = sample_planar_emission_packets(
        history, mass_config["state_masses_kg"], args.interval, draws,
        face_normal_coordinate_m=args.face_normal_coordinate_m, outward_normal_sign=args.normal_sign,
    )
    if not np.array_equal(packets.resolved_position_m[:, 1:], packets.uniform_width_position_m[:, 1:]):
        raise RuntimeError("paired width control changed the boundary/current coordinates")
    component_residual = []
    for pool, current, width, expected in zip(
        packets.component_reservoir_index, packets.component_current_index,
        packets.component_width_index, packets.component_released_particles,
    ):
        selected = ((packets.reservoir_index == pool) & (packets.source_current_index == current)
                    & (packets.source_width_index == width))
        actual = math.fsum(float(value) for value in packets.particle_weight[selected])
        component_residual.append(math.fsum((actual, -float(expected))))
    output = args.output_dir
    output.mkdir(parents=True, exist_ok=True)
    archive = output / "paired_planar_packets.npz"
    np.savez_compressed(
        archive, resolved_position_m=packets.resolved_position_m,
        uniform_width_position_m=packets.uniform_width_position_m,
        velocity_m_s=packets.velocity_m_s, momentum_kg_m_s=packets.momentum_kg_m_s,
        particle_weight=packets.particle_weight, time_s=packets.time_s,
        time_offset_s=packets.time_offset_s, state_ids=np.asarray(packets.state_ids, dtype=str),
        reservoir_index=packets.reservoir_index, source_current_index=packets.source_current_index,
        source_width_index=packets.source_width_index,
    )
    summary = {
        "schema": packets.schema, "scope": "paired upstream boundary samples; no gap solver",
        "source_attributes": plain_metadata(packets.surface_attributes),
        "mass_status": mass_config["mass_status"], "mass_provenance": mass_config["mass_provenance"],
        "source_sha256": hashlib.sha256(args.source.read_bytes()).hexdigest(),
        "masses_sha256": hashlib.sha256(args.masses.read_bytes()).hexdigest(),
        "packet_sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
        "interval_index": args.interval, "packets": args.packets, "seed": args.seed,
        "required_minimum_n": packets.required_minimum_n,
        "total_released_particles": packets.total_released_particles,
        "total_packet_particles": math.fsum(float(value) for value in packets.particle_weight),
        "maximum_component_particle_residual": max(abs(value) for value in component_residual),
        "unequal_macro_weights": packets.unequal_macro_weights,
        "face_normal_coordinate_m": packets.face_normal_coordinate_m,
        "outward_normal_sign": packets.outward_normal_sign,
        "expected_translational_energy_j": packets.expected_translational_energy_j,
        "sampled_translational_energy_j": packets.sampled_translational_energy_j,
        "thermal_energy_sampling_residual_j": packets.translational_energy_sampling_residual_j,
        "comparison": "Only width position differs; current position, boundary coordinate, times, states, momenta and weights are shared",
        "source_code_sha256": {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in
                               ["mhdlab/planar_boundary.py", "mhdlab/thermal_boundary.py", "mhdlab/planar_release.py",
                                "mhdlab/thermal_release.py", "examples/paired_planar_packets.py"]},
        "limits": ["thermal packet energy is a sampled estimator of the expected source moment",
                   "component-specific unequal weights require downstream support"],
    }
    (output / "summary.json").write_text(json.dumps(summary, indent=2, allow_nan=False) + "\n")
    print(json.dumps({"packets": args.packets, "components": packets.required_minimum_n,
                      "maximum_component_particle_residual": summary["maximum_component_particle_residual"]}))


if __name__ == "__main__":
    main()
