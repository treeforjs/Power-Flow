"""Portable upstream fixed-source-window verification subset."""
