# Fixed-source-window verification subset

Named public files are byte-identical to the recorded commit. Four named
packaging wrappers isolate imports from unrelated downstream solvers.

```sh
python -W error -m pytest tests/test_source_window_plan.py tests/test_windowed_source_resolution_cli.py
```

Inputs are manufactured. Global source windows condition original local
intervals and remain separate from photon recording gates. Endpoint rounding
is explicit; geometric qualification is not a kinetic mass error bound.
Source comparisons at fixed quadrature orders remain separate from quadrature
changes. No source evolution or gap/chemistry/radiation solver is performed.
Read `docs/source_window_resolution.md`.
