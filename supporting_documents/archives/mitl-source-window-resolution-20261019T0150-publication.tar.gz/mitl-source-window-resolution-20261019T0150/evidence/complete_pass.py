"""Record the verified source-window milestone and release its bounded lease."""
import datetime
import fcntl
import hashlib
import json
from pathlib import Path
import subprocess

work=Path(__file__).resolve().parent
repo=Path('/workspace/Power-Flow')
out=Path('/workspace/handoffs/mitl-source-window-resolution-20261019T0150')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_text())
delivery=load(work/'delivery_verification.json')
verification=load(out/'verification.json')
study=load(work/'snapshot-window-study/report.json')
profile=load(work/'profile-reduction/artifacts/report.json')
next_task=load(out/'next_task.json')['task']
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert commit==delivery['source_commit']==verification['source_commit']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip()
assert sha(delivery['archive'])==delivery['sha256'] and delivery['status']=='passed'
assert verification['results']['portable_unique_passed']==105
now=datetime.datetime.now(datetime.timezone.utc)
status_path=work.parent/'mitl-upstream-status.json'
with (work.parent/'mitl-upstream-status.lock').open('a+') as lock:
    fcntl.flock(lock,fcntl.LOCK_EX)
    old=status_path.read_bytes();status=json.loads(old)
    assert status['active_lease_owner']==work.name
    assert datetime.datetime.fromisoformat(status['active_editing_lease_until_utc'])>now
    if status['handoff'] not in status.setdefault('prior_handoffs',[]):status['prior_handoffs'].append(status['handoff'])
    history=status.setdefault('verification_history',[])
    if not any(item['pass_id']==status['last_completed_pass_id'] for item in history):
        history.append({'pass_id':status['last_completed_pass_id'],'commit':status['last_complete_commit'],
                        'handoff':status['handoff'],'handoff_sha256':status['handoff_sha256'],'verification':status['last_verified_suite']})
    status.update(last_complete_commit=commit,last_completed_pass_id=work.name,last_update_utc=now.isoformat(),
        handoff=delivery['archive'],handoff_sha256=delivery['sha256'],handoff_bytes=delivery['bytes'],
        handoff_document=str(out/'systems-mitl-source-window-resolution-10192026.md'),
        active_lease_owner=None,active_editing_lease_until_utc=None,reserved_paths=[],active_completed_subtasks=[],
        active_phase='Completed fixed SOURCE-window plans, preserved canonical-array recovery, snapshot comparisons and width profiles; conservative public window ledgers selected next')
    status['last_verified_suite']={**verification['results'],'scope':'New global coordinate planning, saved canonical source conditioning/comparison and manufactured profile reduction; no unchanged project suites or saved source evolution repeated',
        'verification_record':str(out/'verification.json'),'delivery_manifest_entries':delivery['manifest_entries'],
        'physical_spectra_calculated':False,'host_budget_accepted':False,'previous_full_project_passed':721,'previous_full_project_skipped':2,
        'post_freeze_commands':str(work/'commands.jsonl')}
    status['source_window_resolution']={'planner':str(repo/'mhdlab/source_window_plan.py'),
        'comparison_command':str(repo/'tools/compare_windowed_source_resolution.py'),'guide':str(repo/'docs/source_window_resolution.md'),
        'inventory':str(work/'inventory/inventory.json'),'inventory_sha256':sha(work/'inventory/inventory.json'),
        'preserved_histories':6,'source_evolution_repeated':False,'canonical_frozen_law_validation_replayed':True,
        'study':str(work/'snapshot-window-study/report.json'),'study_sha256':sha(work/'snapshot-window-study/report.json'),
        'snapshot_levels':[8,16,32,64],'common_source_intervals':512,'orders':[8,16,32],
        'windows':study['windows'],'profile_report':str(work/'profile-reduction/artifacts/report.json'),
        'profile_report_sha256':sha(work/'profile-reduction/artifacts/report.json'),
        'figure':str(work/'profile-reduction/artifacts/source_width_profiles.pdf'),
        'physical_parameter_status':'manufactured','missing_refinement_families':['width','current','integration'],
        'limitation':'Only snapshot family has complete preserved source arrays; older spatial/integration histories retain hashes alone. Coordinate projection, source discretization and finite moment quadrature changes remain distinct; no physical water coverage or spectra inferred.'}
    status['next_work']=[{'priority':1,'task':next_task}]+[dict(item) for item in status['next_work'] if item['priority']>1]
    status['completed_milestones'].extend([
        'Qualified global SOURCE windows intersect original intervals through exact represented-Fraction arithmetic, explicit local/global rounding and positive-support rejection;65 new planner checks and13 independent probes passed.',
        'Recovered six fully preserved canonical source arrays without replacement evolution; constructor/HDF hash replay retains all14 source arrays and exact metadata. Four snapshot levels8/16/32/64 share512 source intervals; older width/current/integration families lack required array payloads.',
        'Two fixed SOURCE windows at49.1–49.7ns and80.2–80.8ns compare preserved snapshot histories at orders8/16/32, separating fixed-order source differences from quadrature changes and anchoring time before subtraction. Manufactured number/translation width profiles retain signed area and source closures.',
        f'Two local commits through{commit[:7]};105 new targeted checks passed and105 unique portable checks completed. Initial portable104pass/1missing dynamic dependency corrected with only affected guard rerun; failures and original records retained. Actual archive{delivery["sha256"]} verifies{delivery["manifest_entries"]}manifest entries and28 byte-identical public files plus4 wrappers.'
    ])
    temp=status_path.with_suffix('.json.new');temp.write_text(json.dumps(status,indent=2,allow_nan=False)+'\n');temp.replace(status_path)
    result={'utc':now.isoformat(),'event':'completed_and_next_selected','pass_id':work.name,'commit':commit,
        'archive':delivery['archive'],'archive_sha256':delivery['sha256'],'archive_bytes':delivery['bytes'],
        'new_targeted_unique_passed':105,'portable_unique_passed':105,'canonical_histories_recovered':6,
        'snapshot_histories_compared':4,'source_windows':2,'quadrature_orders':[8,16,32],
        'exact_commands':str(work/'commands.jsonl'),'status_before_sha256':hashlib.sha256(old).hexdigest(),'status_after_sha256':sha(status_path),
        'lease_released':True,'reserved_paths':[],'next':next_task,
        'limits':'Manufactured source evidence; no physical spectra/calibration or host transaction. Missing older spatial/integration array payloads prevent their partial-window comparisons. Installed licensed FLASH/configured workstation remain unavailable.'}
    (work/'completion.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    with (work.parent/'mitl-upstream-journal.jsonl').open('a') as f:f.write(json.dumps(result,allow_nan=False)+'\n')
print(json.dumps(result,indent=2))
