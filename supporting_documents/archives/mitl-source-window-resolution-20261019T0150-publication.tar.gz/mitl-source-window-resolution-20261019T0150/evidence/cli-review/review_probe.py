"""Focused, read-only contract review of the fixed-window comparison command."""
from __future__ import annotations

import ast
from fractions import Fraction
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

ROOT = Path('/workspace/Power-Flow')
OUT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))
path = ROOT/'tools/compare_windowed_source_resolution.py'
spec = importlib.util.spec_from_file_location('window_resolution_review_subject', path)
subject = importlib.util.module_from_spec(spec)
spec.loader.exec_module(subject)

def pin(relative):
    return hashlib.sha256((ROOT/relative).read_bytes()).hexdigest()

code = subject.CODE_PATHS
seen = set()
imports = []
missing = {'mhdlab/__init__.py'} - set(code)
todo = list(code) + ['mhdlab/__init__.py']
while todo:
    current = todo.pop()
    if current in seen:
        continue
    seen.add(current)
    tree = ast.parse((ROOT/current).read_text())
    for node in ast.walk(tree):
        if not isinstance(node, ast.ImportFrom):
            continue
        if not (node.level or (node.module or '').startswith('mhdlab.')):
            continue
        module = 'mhdlab.'+(node.module or '') if node.level else node.module
        target = module.replace('.', '/')+'.py'
        if (ROOT/target).is_file():
            imports.append([current, target])
            todo.append(target)
            if target not in code:
                missing.add(target)

def result(origin, start, local, *, count=3.):
    anchor = {'interval_origin_s': origin, 'window_start_offset_s': start,
              'mean_time_offset_s': local}
    values = {'released_number': count, 'mean_time_s': float(Fraction(origin)+Fraction(start)+Fraction(local)),
              'mean_time_offset_s': local}
    return {'units': {'released_number': 'parent', 'mean_time_s': 's', 'mean_time_offset_s': 's'},
            'resolved': dict(values), 'matched_uniform_width': dict(values),
            'mean_time_anchor': dict(anchor), 'matched_uniform_width_mean_time_anchor': dict(anchor)}

rounded_a = result(1.0e16, 0., .25)
rounded_b = result(1.0e16, 0., .5)
assert rounded_a['resolved']['mean_time_s'] == rounded_b['resolved']['mean_time_s']
small_difference = subject.changes(rounded_a, rounded_b)
for hypothesis in ('resolved', 'matched_uniform_width'):
    row = small_difference[hypothesis]['mean_time_s']
    assert row['signed_change']['value'] == -.25
    assert 'mean_time_offset_s' not in small_difference[hypothesis]

equivalent_a = result(1024., 0., .75)
equivalent_b = result(1024.5, 0., .25)
equivalent_difference = subject.changes(equivalent_a, equivalent_b)
assert equivalent_difference['resolved']['mean_time_s']['signed_change']['value'] == 0.

empty_a = result(0., 0., 0., count=0.)
for hypothesis in ('resolved', 'matched_uniform_width'):
    empty_a[hypothesis]['mean_time_s'] = None
    empty_a[hypothesis]['mean_time_offset_s'] = None
empty_a['mean_time_anchor'] = None
empty_a['matched_uniform_width_mean_time_anchor'] = None
empty_comparison = subject.changes(empty_a, empty_a)
assert empty_comparison['resolved']['released_number']['available']
assert empty_comparison['resolved']['released_number']['relative_to_reference'] is None
assert not empty_comparison['resolved']['mean_time_s']['available']

config_path = OUT.parent/'snapshot-window-config.json'
raw, config, windows = subject.configuration(config_path)
total_counts = [case['resolution']['snapshot_intervals'] * case['resolution']['subdivisions_per_interval']
                for case in config['cases']]
assert total_counts == [512]*4
assert len(config['comparisons']) == 3

report = {
    'review': 'read-only focused CLI contract review; no source evolution, public mutation, or prior suite replay',
    'code_sha256': {relative: pin(relative) for relative in code},
    'documentation_sha256': {'docs/source_window_resolution.md': pin('docs/source_window_resolution.md')},
    'static_import_closure_not_in_code_paths': sorted(missing),
    'static_import_edges': imports,
    'rounded_absolute_time_difference_retained': small_difference,
    'different_anchor_equal_time_comparison': equivalent_difference,
    'empty_source_comparison': empty_comparison,
    'declared_common_source_intervals': total_counts,
    'snapshot_window_configuration_sha256': hashlib.sha256(raw).hexdigest(),
    'source_windows': [window.manifest() for window in windows],
}
(OUT/'review_probe.json').write_text(json.dumps(report, indent=2, allow_nan=False)+'\n')
print(json.dumps({'code_sha256': pin('tools/compare_windowed_source_resolution.py'),
                  'source_window_plan_sha256': pin('mhdlab/source_window_plan.py'),
                  'unhashed_imports': sorted(missing),
                  'focused_anchor_and_empty_population_probes': 'passed',
                  'common512_config': 'passed', 'report': str(OUT/'review_probe.json')}, indent=2))
