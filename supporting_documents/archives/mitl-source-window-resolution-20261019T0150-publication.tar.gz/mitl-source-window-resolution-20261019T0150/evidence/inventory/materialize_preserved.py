"""Inventory and serialize saved canonical source arrays without evolution."""
from dataclasses import asdict, fields
import hashlib
import json
from pathlib import Path
import sys
import traceback

import h5py
import numpy as np

ROOT = Path('/workspace/Power-Flow')
sys.path.insert(0, str(ROOT))
from mhdlab.planar_release_io import plain_metadata
from mhdlab.temkin_release import TemkinReservoir
from mhdlab.temkin_planar import TemkinPlanarReleaseHistory
from mhdlab.temkin_planar_io import write_temkin_planar_release_history

OUT = Path(__file__).resolve().parent
ORIGINAL = Path('/workspace/research_work/mitl-upstream-20261018T1858')
FOLLOWUP = ORIGINAL/'source-refinement-followup'
REPORT = FOLLOWUP/'report.json'
INITIAL_REPORT = ORIGINAL/'manufactured-convergence/report.json'
CONFIG = ROOT/'configs/temkin_convergence_manufactured.json'
FOLLOWUP_SCRIPT = ORIGINAL/'refine_source_uncertainties.py'
HANDOFF = Path('/workspace/handoffs/mitl-convergence-heating-20261018T1858/evidence/followup_refinement')

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()

def array_record(value):
    array = np.asarray(value)
    dtype = '<f8' if array.dtype.kind == 'f' else ('<' if array.dtype.itemsize > 1 else '|')+array.dtype.kind+str(array.dtype.itemsize)
    array = np.asarray(array, dtype=dtype, order='C')
    header = {'shape': list(array.shape), 'dtype': dtype, 'order': 'C'}
    return {**header, 'sha256': hashlib.sha256(canonical(header)+b'\n'+array.tobytes()).hexdigest()}

def save(path, record):
    with path.open('x') as handle:
        handle.write(json.dumps(record, indent=2, allow_nan=False)+'\n')

def main():
    report = json.loads(REPORT.read_text())
    initial_report = json.loads(INITIAL_REPORT.read_text())
    assert sha(INITIAL_REPORT) == report['initial_report_sha256']
    assert sha(CONFIG) == report['input_config_sha256']
    config = json.loads(CONFIG.read_text())
    assert config == report['config']
    pools = tuple(TemkinReservoir(**{key:value for key,value in record.items() if key != 'initial_coverage_m2'})
                  for record in config['reservoirs'])
    canonical_dir = OUT/'canonical'
    canonical_dir.mkdir(exist_ok=False)
    code_paths = [ROOT/'mhdlab/temkin_planar.py', ROOT/'mhdlab/temkin_history.py',
                  ROOT/'mhdlab/temkin_release.py', ROOT/'mhdlab/temkin_planar_io.py', Path(__file__)]
    materializer_code_hashes = {str(path):sha(path) for path in code_paths}
    results, failures = [], []
    for case_id in report['new_case_ids']:
        record_path = FOLLOWUP/'cases'/(case_id+'.json')
        record = json.loads(record_path.read_text())
        npz_path = record_path.with_suffix('.npz')
        association_path = canonical_dir/(case_id+'.json')
        history_path = canonical_dir/(case_id+'.h5')
        try:
            assert sha(record_path) == report['new_case_artifacts'][record_path.name]
            assert sha(npz_path) == record['npz_sha256'] == report['new_case_artifacts'][npz_path.name]
            assert record['config_sha256'] == sha(CONFIG)
            assert record == report['cases'][case_id]
            with np.load(npz_path, allow_pickle=False) as archive:
                arrays = {name:archive[name] for name in archive.files}
            assert set(arrays) == set(record['array_records'])
            for name,value in arrays.items():
                assert array_record(value) == record['array_records'][name], name
            values = {name.removeprefix('source__'): value for name,value in arrays.items() if name.startswith('source__')}
            # Constructor validation checks the stored local law, energy and
            # diagnostics. It never integrates a new source history.
            history = TemkinPlanarReleaseHistory(**values, reservoirs=pools,
                surface_attributes=record['input_surface_attributes'],
                parameter_provenance=config['parameter_provenance'])
            assert plain_metadata(history.surface_attributes) == record['input_surface_attributes']
            for name,value in values.items():
                assert array_record(getattr(history,name)) == record['array_records']['source__'+name], name
            write_temkin_planar_release_history(history_path, history)
            reopened = {}
            with h5py.File(history_path,'r') as handle:
                for name,value in values.items():
                    reopened[name] = array_record(handle[name][()])
                    assert reopened[name] == record['array_records']['source__'+name], name
                assert json.loads(handle.attrs['surface_attributes_json']) == record['input_surface_attributes']
                assert json.loads(handle.attrs['reservoirs_json']) == [asdict(pool) for pool in pools]
                assert handle.attrs['parameter_provenance'] == config['parameter_provenance']
            families = []
            for family,study in report['studies'].items():
                if case_id in study['case_ids']:
                    families.append({'family':family, 'varied':study['varied'],
                        'level':record['resolution'][study['varied']], 'reference_level':study['reference'],
                        'reference_case_id':study['case_ids'][-1],
                        'is_finite_reference':case_id == study['case_ids'][-1],
                        'complete_saved_family':all((FOLLOWUP/'cases'/(name+'.npz')).exists() for name in study['case_ids'])})
            original_times = arrays['original__time_s']
            time_edges = values['time_edges_s']
            duplicate_npz = HANDOFF/'cases'/npz_path.name
            duplicate_record = HANDOFF/'cases'/record_path.name
            preserved = {str(path):sha(path) for path in (npz_path,record_path,REPORT,INITIAL_REPORT,CONFIG,FOLLOWUP_SCRIPT)}
            association = {
                'schema':'mhdlab-preserved-source-association-v1',
                'parameter_status':'manufactured', 'parameter_provenance':history.parameter_provenance,
                'source_sha256':sha(history_path), 'source_file':str(history_path), 'case_id':case_id,
                'resolution':record['resolution'], 'preserved_inputs_sha256':preserved,
                'source_evolution_repeated':False,
                'materialization':'Serialized from the complete preserved canonical source arrays; no source evolution regenerated.',
                'completeness':{'all_npz_arrays_verified_against_original_array_records':True,
                    'canonical_source_array_count':len(values), 'all_source_arrays_byte_identical_after_constructor_and_hdf':True,
                    'canonical_constructor_validation_passed':True, 'input_surface_attributes_exact':True,
                    'reservoirs_and_parameter_provenance_exact':True,
                    'initial_report_hash_association_verified':True,'input_config_hash_association_verified':True},
                'dimensions':{'reservoirs':len(pools),'width_bins':len(values['x_edges_m'])-1,
                    'current_bins':len(values['z_edges_m'])-1,'source_intervals':len(time_edges)-1,
                    'original_snapshot_intervals':len(original_times)-1,
                    'actual_integrator_input_intervals':len(arrays['input__time_s'])-1,
                    'source_coverage_shape':list(values['coverage_m2'].shape),
                    'source_interval_population_shape':list(values['released_m2'].shape)},
                'time_support_s':[float(time_edges[0]),float(time_edges[-1])],
                'families':families, 'original_plan':record['plan'],
                'source_array_records':reopened,
                'original_integration_source_sha256':record['source_sha256'],
                'original_followup_script_sha256_at_integration':record['followup_script_sha256_at_integration'],
                'materialization_source_sha256':materializer_code_hashes,
                'archive_duplicates':{'npz_path':str(duplicate_npz), 'npz_sha256':sha(duplicate_npz),
                    'npz_matches_original':sha(duplicate_npz)==sha(npz_path),
                    'record_path':str(duplicate_record),'record_sha256':sha(duplicate_record),
                    'record_matches_original':sha(duplicate_record)==sha(record_path)},
                'limits':['All rates, energies, masses, coverage and temperatures are manufactured.',
                    'Canonical validation is numerical record validation, not physical water/foil validation.',
                    'Original local midpoint history errors remain unchanged.',
                    'Common512 interpolation does not add analytic thermal snapshots.',
                    'Only the complete stored snapshot family supports a within-family resolution comparison; width/current stored cases are isolated finest references.'],
            }
            save(association_path,association)
            results.append({'case_id':case_id,'source_file':str(history_path),'source_sha256':sha(history_path),
                'evidence_file':str(association_path),'evidence_sha256':sha(association_path),
                'npz_file':str(npz_path),'npz_sha256':sha(npz_path), 'dimensions':association['dimensions'],
                'resolution':record['resolution'],'families':families})
            print('materialized '+case_id,flush=True)
        except Exception as error:
            failure={'case_id':case_id,'type':type(error).__name__,'message':str(error),'traceback':traceback.format_exc()}
            failures.append(failure)
            save(canonical_dir/(case_id+'.failure.json'),failure)
            print('FAILED '+case_id+': '+str(error),flush=True)
    result={'schema':'mitl-preserved-source-inventory-v1', 'source_evolution_repeated':False,
        'original_initial_report':str(INITIAL_REPORT),'original_initial_report_sha256':sha(INITIAL_REPORT),
        'original_followup_report':str(REPORT),'original_followup_report_sha256':sha(REPORT),
        'input_config_file':str(CONFIG),'input_config_sha256':sha(CONFIG),
        'followup_script_file':str(FOLLOWUP_SCRIPT),'followup_script_sha256':sha(FOLLOWUP_SCRIPT),
        'inventory_script_sha256':sha(__file__), 'cases':results,'failures':failures,
        'historical_initial_cases_without_array_payloads':list(initial_report['cases']),
        'limitations':['Initial convergence report preserved hashes and observables only; those thirteen histories cannot be reconstructed from hashes.',
            'The six fully preserved records include one complete four-level snapshot refinement and two isolated spatial reference cases.',
            'Width/current and subdivision refinement families lack the historical arrays required for a new partial-window comparison; no evolution was repeated or invented.']}
    save(OUT/'inventory.json',result)
    print(json.dumps({'materialized':len(results),'failed':len(failures),'inventory_file':str(OUT/'inventory.json'),
                      'inventory_sha256':sha(OUT/'inventory.json')},indent=2))
    if failures:
        raise SystemExit(1)

if __name__ == '__main__':
    main()
