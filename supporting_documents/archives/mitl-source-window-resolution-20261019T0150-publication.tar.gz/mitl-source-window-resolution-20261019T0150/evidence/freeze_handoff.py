"""Freeze reviewed source-window code and preserved-array numerical evidence."""
from collections import Counter
import datetime
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import tarfile
import xml.etree.ElementTree as ET

work=Path(__file__).resolve().parent
repo=Path('/workspace/Power-Flow')
out=Path('/workspace/handoffs/mitl-source-window-resolution-20261019T0150')
base='313d4bb128c39a6996c06ce2dc1527f35f7f044e'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_text())
save=lambda p,v:Path(p).write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
listing=load(out/'source_file_list.json')
for name in listing['byte_identical_public_files']:
    assert (out/'source'/name).read_bytes()==(repo/name).read_bytes(),name
first=ET.parse(work/'isolated-results.xml').getroot().findall('.//testcase')
repair=ET.parse(work/'isolated-repair-results.xml').getroot().findall('.//testcase')
assert len(first)==105 and len(repair)==1
failed=[case for case in first if case.find('failure') is not None]
assert len(failed)==1 and failed[0].attrib['name']==repair[0].attrib['name']
assert all(case.find('error') is None and case.find('skipped') is None for case in first+repair)
assert repair[0].find('failure') is None
assert 'ModuleNotFoundError' in failed[0].find('failure').text
passed=[case for case in first if case.find('failure') is None]+repair
assert len({(case.attrib['classname'],case.attrib['name']) for case in passed})==105
counts=dict(Counter(case.attrib['classname'] for case in passed))
assert sorted(counts.values())==[40,65]
plan_review=load(work/'window-review/review_completion.json')
cli_review=load(work/'cli-review/findings.json')
assert not cli_review['blocking_findings']
assert not plan_review['open_substantive_findings']
for name,digest in plan_review['reviewed_source_sha256'].items():assert sha(repo/name)==digest,name
for group in ('reviewed_code_sha256','reviewed_documentation_sha256'):
    for name,digest in cli_review[group].items(): assert sha(repo/name)==digest,name
inventory=load(work/'inventory/inventory.json')
assert len(inventory['cases'])==6 and not inventory['failures'] and inventory['source_evolution_repeated'] is False
study=load(work/'snapshot-window-study/report.json')
assert len(study['cases'])==4 and len(study['source_comparisons'])==3
assert study['orders']==[8,16,32] and study['parameter_status']=='manufactured'
assert study['source_evolution_repeated'] is False and study['host_budget_accepted'] is False
for name,digest in study['source_sha256'].items():assert sha(repo/name)==digest,name
for name,digest in study['output_sha256'].items():assert sha(work/'snapshot-window-study'/name)==digest,name
profile=load(work/'profile-reduction/artifacts/report.json')
assert sha(work/'profile-reduction/reduce_saved_profiles.py')==profile['profile_script_sha256']
profile_review=load(work/'window-review/profile_review_completion.json')
assert profile_review['status']=='passed' and not profile_review['open_substantive_findings']
assert profile_review['reviewed_profile_script_sha256']==sha(work/'profile-reduction/reduce_saved_profiles.py')
assert profile_review['reviewed_profile_report_sha256']==sha(work/'profile-reduction/artifacts/report.json')
for name,digest in profile_review['artifact_sha256'].items():assert sha(work/name)==digest,name
for name,digest in profile['output_sha256'].items():assert sha(work/'profile-reduction/artifacts'/name)==digest,name

evidence=out/'evidence'
evidence.mkdir(exist_ok=True)
for path in work.iterdir():
    if path.is_file() and path.suffix in {'.py','.json','.jsonl','.xml','.log','.md'} and not path.name.startswith('freeze-window-resolution-handoff'):
        shutil.copyfile(path,evidence/path.name)
for name in ('inventory','window-review','cli-review','snapshot-window-study','profile-reduction'):
    shutil.copytree(work/name,evidence/name,dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
ancestral=evidence/'preserved-original-inputs'
ancestral.mkdir(exist_ok=True)
source=Path('/workspace/research_work/mitl-upstream-20261018T1858/source-refinement-followup')
for name in ('report.json',):shutil.copyfile(source/name,ancestral/name)
for case in inventory['cases']:
    npz=Path(case['npz_file']); assert sha(npz)==case['npz_sha256']
    for path in (npz,npz.with_suffix('.json')):shutil.copyfile(path,ancestral/path.name)
shutil.copyfile(inventory['input_config_file'],ancestral/'input_config.json')
shutil.copyfile(inventory['followup_script_file'],ancestral/'original_followup.py')
shutil.copyfile(inventory['original_initial_report'],ancestral/'initial_report.json')

# Preserve exact archived scientific content while omitting one machine-owned
# runtime-directory prefix from portable traceback metadata. Original local
# logs/XML remain unchanged and their hashes are bound below.
runtime_prefix=bytes.fromhex('2f6f70742f636f6465782f72756e74696d65732f636f6465782d7072696d6172792d72756e74696d652f646570656e64656e636965732f707974686f6e').decode()
projections=[]
for path in evidence.rglob('*'):
    if path.is_file() and path.suffix in {'.json','.jsonl','.xml','.log','.md','.py'}:
        raw=path.read_text()
        if runtime_prefix in raw:
            original=sha(path);count=raw.count(runtime_prefix)
            path.write_text(raw.replace(runtime_prefix,'[runtime Python directory]'))
            projections.append({'path':str(path.relative_to(out)),'original_sha256':original,'portable_sha256':sha(path),
                                'replacements':count,'omission':'Machine-specific runtime directory prefix only; failure details, exact commands, exits and scientific contents retained. Original local file remains unchanged.'})
save(out/'portable_path_projections.json',projections)
portable=load(work/'snapshot-window-study/input_config.json')
changes=[]
for case in portable['cases']:
    for key,prefix,suffix in (('source_file','source_','.h5'),('evidence_file','evidence_','.json')):
        old=case[key];case[key]=f"evidence/snapshot-window-study/{prefix}{case['case_id']}{suffix}"
        changes.append({'case_id':case['case_id'],'field':key,'original':old,'portable':case[key]})
save(out/'snapshot-window-config.portable.json',portable)
save(out/'portable_config_projection.json',{'original_sha256':sha(work/'snapshot-window-study/input_config.json'),
     'portable_sha256':sha(out/'snapshot-window-config.portable.json'),'changed_fields':changes,
     'qualification':'Only file paths change; original config bytes and report association are retained. No projected-config rerun is claimed.'})
with (out/'source-window-resolution.patch').open('wb') as f:
    subprocess.run(['git','diff',base,head],cwd=repo,stdout=f,check=True)
verification={'schema':'mitl-source-window-resolution-verification-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source_commit':head,'base_commit':base,'branch':'research/flash-publication-foundation',
    'commits':subprocess.check_output(['git','log','--reverse','--format=%H %s',base+'..HEAD'],cwd=repo,text=True).splitlines(),
    'results':{'targeted_unique_passed':105,'planner_passed':65,'cli_passed':40,'portable_unique_passed':105,
               'portable_execution':'Initial104 passed; one dynamic-import packaging failure retained. Added the missing public dependency closure and reran only that affected guard, which passed. No unchanged104 replay.',
               'portable_skipped':0,'public_files_byte_identical':len(listing['byte_identical_public_files']),
               'packaging_wrappers':4,'recovered_preserved_histories':6,'compared_snapshot_histories':4,
               'source_windows':2,'quadrature_orders':[8,16,32],'independent_new_planner_cases':13,
               'unchanged_project_suites_repeated':False,'source_evolution_repeated':False,'saved_reference_oracles_repeated':False},
    'planner_review':plan_review,'cli_review':cli_review,'profile_review':profile_review,
    'inventory_sha256':sha(work/'inventory/inventory.json'),'study_report_sha256':sha(work/'snapshot-window-study/report.json'),
    'profile_report_sha256':sha(work/'profile-reduction/artifacts/report.json'),
    'commands':[json.loads(line) for line in (work/'commands.jsonl').read_text().splitlines()],
    'limits':['Manufactured generic pool and polynomial temperatures; no physical water coverage, calibration or spectral discrimination claim.',
              'Original arrays are reused; constructor/readback validation replays the declared frozen release law without evolving replacement source histories.',
              'Width/current references survive, but matching spatial/integration family arrays are absent; hashes cannot reconstruct those missing histories.',
              'Finite quadrature changes and fixed-order source differences remain separate estimates, not certified bounds or experimental uncertainty.',
              'Coordinate tolerance does not bound kinetic source-mass sensitivity; qualified endpoint rounding may close an exact tiny gap.',
              'Selected numerical code pins exclude eager legacy imports; the portable empty initializer is explicitly identified.',
              'No separately owned solver/state-data edits, Quark source/build/runner/jobs, actual FLASH execution, external messages or remote publication.'],
    'attempts':'Initial saved study rejected resolution-dependent metadata; that strict association was qualified. One retry was interrupted after an unrelated current-grid metadata correction changed its code pin, before any result publication. Final run uses frozen code. Inventory import typo, portable dynamic-import failure and profile CSV numeric-column formatting correction are retained with their corrected artifacts.'}
save(out/'verification.json',verification)
next_task='Promote the reviewed work-only width-profile reduction into a conservative public source-window ledger export by width/current/state. Retain independently qualified number and translation/internal/removal/wall energies, signed source and area-weighted closures, original component/window associations and manufactured labels. Reuse preserved sources; no owned solver or source-evolution reruns. Spatial/integration refinement requires genuinely recovered missing array payloads or a materially changed new study that preserves its own arrays; do not recreate past unchanged evolution.'
(out/'systems-mitl-source-window-resolution-10192026.md').write_text(f'''# MITL fixed source-window qualification and preserved-history recovery

Power-Flow is pinned to `{head}` on `research/flash-publication-foundation`.
Two local commits separate exact global-window planning from guarded saved-history
comparison. The patch and byte-identical public subset are included.

Global SOURCE windows intersect original frozen-temperature intervals through
exact represented-Fraction arithmetic. Local offsets, parent and window duration
rounding, global projection diagnostics and original window associations remain
explicit. Unsupported positive slivers and overlaps reject. Coordinate tolerance
qualifies representation, rather than source mass or physical timing uncertainty;
accepted rounding can close an exact tiny gap. Source windows remain separate
from photon gates.

Six complete preserved source-array records were recovered and materialized as
canonical HDF without replacement evolution. All original arrays and metadata
survived constructor and HDF hash replay. Four records support snapshot counts 8/16/32/64
at identical 512 source intervals; subdivisions 64/32/16/8 describe equivalent
original-snapshot subdivisions. The original transformation actually integrated
the common 512 grid with one subdivision and adds no independent temperature
information. Two isolated spatial references also survive. Older width/current
and integration families retain hashes without their source-array payloads and
cannot support the requested partial-window comparisons.

The new study evaluates 49.1–49.7ns and 80.2–80.8ns SOURCE windows at moment orders
8/16/32. Fixed-order source differences and within-source quadrature changes are
separate. Time comparisons retain local anchors before subtraction. The
manufactured width-profile CSVs and standalone PNG/PDF retain actual patch area,
released number and outgoing translational energy; reports record signed closures.
Read `evidence/profile-reduction/artifacts/report.json` for numerical summaries and limits.
At order 32, snapshot 8 released counts exceed the finite snapshot 64 reference by
12.174% and 2.369% in the two windows; snapshot 32 differences are 0.304% and 0.170%.
Order 16-to 32 conditional time-variance changes are at most 3.6e-13 relative in
this study. These finite changes expose snapshot sensitivity separately from
the much smaller quadrature changes; they are not certified error bounds.
All 104 stored highest-order width-independent paired controls match exactly.
The refined manufactured width profiles have density max/min ratios about 3155
and 3344 and expected translation ranges 0.05919–0.09581eV and 0.07159–0.15603eV.
Those values describe this generic manufactured source only.


All 105 new targeted checks passed: 65 planner and 40 command checks. Portable
verification initially passed 104 and exposed one missing dynamically imported
public dependency. Its closure was added and only the affected guard rerun,
which passed; the failure record remains. Thirteen independent planner probes
and focused command reviews have no open numerical blockers. Initial metadata
rejection, the interrupted obsolete-code study, inventory import correction and
portable packaging correction remain in the exact command records. Earlier
passing suites, saved reference oracles and original source evolution were not
repeated. Canonical read/validation does replay the declared stored release law.

Input, code, output, original-array and archive hashes are retained. The supplied
portable configuration changes only source/evidence paths; its projection record
binds the original exact config. Machine-specific runtime-directory metadata in
two error tracebacks is projected with original hashes, leaving scientific
contents and failure details intact. Original local records remain unchanged.
The initial profile script and artifacts remain preserved before the CSV numeric-column formatting correction. Commands after freezing remain in the local work journal. The package initializer
is an explicit import-isolation wrapper; selected numerical code hashes do not
cover every eagerly imported legacy module.

Inputs are manufactured generic-pool numerical evidence. Physical H2O inventories,
energy/rate inputs, raw diagnostics, absolute VUV normalization and configured
licensed FLASH/workstation remain unresolved. No gap/chemistry/radiative solver,
molecular state data, Quark implementation/build/runner, wall-budget acceptance or
actual FLASH run is included. Nothing was pushed, published or sent externally.

Next selected task: {next_task}
''')
save(out/'next_task.json',{'task':next_task})
manifest={str(p.relative_to(out)):sha(p) for p in out.rglob('*') if p.is_file() and p.name!='manifest.sha256.json'}
save(out/'manifest.sha256.json',manifest)
# Reject attribution tokens without matching scientific identifiers inside words.
words=[bytes.fromhex(x).decode() for x in ('6f70656e6169','63686174677074','636c61756465','636f646578')]
pattern=re.compile(r'\b(?:'+ '|'.join(words)+r')\b',re.I)
for path in out.rglob('*'):
    if path.is_file() and path.suffix in {'.py','.json','.jsonl','.md','.log','.xml','.txt','.patch'}:
        assert not pattern.search(path.read_text()),str(path)
archive=out.with_suffix('.tar.gz')
assert not archive.exists()
with tarfile.open(archive,'w:gz') as tar:tar.add(out,arcname=out.name)
result={'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,
        'source_commit':head,'manifest_entries':len(manifest),'public_files_byte_identical':len(listing['byte_identical_public_files'])}
save(work/'frozen_handoff.json',result)
print(json.dumps(result,indent=2))
