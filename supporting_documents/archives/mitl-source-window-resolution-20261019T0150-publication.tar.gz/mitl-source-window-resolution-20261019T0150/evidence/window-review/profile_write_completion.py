"""Record final profile review pins without rerunning any reduction."""
import hashlib
import json
from pathlib import Path

work=Path(__file__).resolve().parent
parent=work.parent
folder=parent/'profile-reduction/artifacts'
initial=parent/'profile-reduction/artifacts-initial'
script=parent/'profile-reduction/reduce_saved_profiles.py'
initial_script=parent/'profile-reduction/reduce_saved_profiles.initial.py'
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
readback=json.loads((work/'profile_readback.json').read_text())
report=json.loads((folder/'report.json').read_text())
old=json.loads((initial/'report.json').read_text())
if sha(script)!=readback['reducer_sha256'] or sha(folder/'report.json')!=readback['profile_report_sha256']:
    raise SystemExit('Final reviewed profile bytes changed')
if sha(initial_script)!=old['profile_script_sha256']:
    raise SystemExit('Initial reducer/report pin mismatch')
artifacts={
    'profile-reduction/artifacts/report.json':sha(folder/'report.json'),
    'profile-reduction/reduce_saved_profiles.py':sha(script),
    'profile-reduction/artifacts-initial/report.json':sha(initial/'report.json'),
    'profile-reduction/reduce_saved_profiles.initial.py':sha(initial_script),
}
for directory,prefix,data in ((folder,'profile-reduction/artifacts/',report),
                              (initial,'profile-reduction/artifacts-initial/',old)):
    for name,digest in data['output_sha256'].items():
        if sha(directory/name)!=digest:
            raise SystemExit('Profile artifact changed: '+prefix+name)
        artifacts[prefix+name]=digest
unchanged=('width_profiles.csv','paired_width_controls.csv','source_width_profiles.png','source_width_profiles.pdf')
for name in unchanged:
    if report['output_sha256'][name]!=old['output_sha256'][name]:
        raise SystemExit('Unexpected profile arithmetic/figure change: '+name)
for name in ('profile_readback.py','profile_readback.json','profile_review_notes.md','profile_write_completion.py'):
    artifacts['window-review/'+name]=sha(work/name)
log=parent/'profile_independent_readback.log'
artifacts[log.name]=sha(log)
commands=[json.loads(line) for line in (parent/'commands.jsonl').read_text().splitlines()]
record=[entry for entry in commands if Path(entry['log']).name==log.name]
if len(record)!=1 or record[0]['exit_code']!=0 or record[0]['log_sha256']!=sha(log):
    raise SystemExit('Recorded readback command mismatch')
completion={
    'schema':'mhdlab-source-profile-independent-review-completion-v1',
    'status':'passed',
    'reviewed_profile_script_sha256':sha(script),
    'reviewed_profile_report_sha256':sha(folder/'report.json'),
    'artifact_sha256':artifacts,
    'artifact_path_root':str(parent),
    'checking_counts':{
        key:readback[key] for key in (
            'checked_case_windows','checked_width_rows','checked_original_components','checked_paired_controls',
            'paired_invariants','paired_width_descriptors','change_csv_rows','exact_or_projected_equalities_passed')
    },
    'readback_command':record[0],
    'closed_substantive_findings':[
        {'id':'owner_identified_nested_change_csv_serialization',
         'finding':'Initial resolution/quadrature CSVs contained dictionary strings for nested numerical projections.',
         'resolution':'Numeric projections and explicit flags/reasons now occupy CSV cells; exact records remain JSON. Initial bytes are preserved. Width profiles, paired controls and figures are unchanged.',
         'reviewer_executed_reducer':False}
    ],
    'open_substantive_findings':[],
    'review_conclusions':[
        'Represented individually qualified parent counts and translational energies are reduced as extensive amounts, then divided once by exact actual dx times full original current length.',
        'Declared original float scalar patch area is distinct from exact endpoint geometry; signed declared-minus-geometry and extensive-minus-density-times-declared-area residuals are retained.',
        'Matched uniform-width profiles are the linear marginal of redistributing each original conditioned component count and source translation by dx/fullwidth, preserving the other mixture coordinates.',
        'Conditional expected translation is summed qualified source translation divided by summed represented count, with its source2kBT rounding residual retained.',
        'Displayed density integral residuals match the represented extensive targets; matched count and translation sums close exactly without repair.',
        'All highest-order stored paired controls match the original JSON; non-width invariants are exact and width descriptors are numerical source controls only.',
        'Source-resolution changes, moment quadrature changes, and CSV display projections remain distinct evidence families.',
    ],
    'ledger_scope':'Released parent count and expected translational source energy only. Internal-state/removal/full-wall ledgers remain in the conditioned source manifests and are not reduced or claimed as full profile closure.',
    'superseded_initial_artifacts':'Formatting-only first export is retained under artifacts-initial; use artifacts for final numeric CSVs.',
    'old_cases_or_oracles_rerun':False,
    'reduction_executed_by_reviewer':False,
    'source_law_or_history_or_sampler_or_moment_called':False,
    'public_files_edited':False,
    'host_budget_accepted':False,
    'limits':[
        'Saved manufactured source artifact arithmetic/readback, not a new physical source or solver run.',
        'No spectral, transport, chemistry, trajectory, statistical significance, material calibration or experimental claim follows from the profile differences.',
        'Expected translation is neither a velocity realization nor an internal rovibrational energy partition.',
        'Figures are hashed in this review; visual inspection belongs to root.',
        'Completion applies to exact reviewed code/artifact hashes.',
    ],
}
path=work/'profile_review_completion.json'
path.write_text(json.dumps(completion,indent=2,allow_nan=False)+'\n')
print(json.dumps({'completion':str(path),'sha256':sha(path),
                  'reviewed_profile_script_sha256':sha(script),'reviewed_profile_report_sha256':sha(folder/'report.json'),
                  'status':'passed','open_substantive_findings':[]},indent=2))
