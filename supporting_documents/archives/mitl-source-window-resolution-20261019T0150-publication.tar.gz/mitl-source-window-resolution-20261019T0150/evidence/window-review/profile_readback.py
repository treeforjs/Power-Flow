"""Independent saved JSON/CSV arithmetic readback; imports no source code."""
import csv
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path

work=Path(__file__).resolve().parent
parent=work.parent
folder=parent/'profile-reduction/artifacts'
report_path=folder/'report.json'
report=json.loads(report_path.read_text())
study=Path(report['input_study_report']).parent
ZERO=F(0)
KB=F(1.380649e-23)
QE=F(1.602176634e-19)
checks=0
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def equal(a,b,label):
    global checks
    if a!=b:
        raise AssertionError((label,a,b))
    checks+=1
def rational(record):
    return F(int(record['numerator']),int(record['denominator']))
def csv_expected(row,key,value):
    if value is None:
        equal(row[key],'',key)
    else:
        equal(float(row[key]),float(value),key)
def stored_closure(summary,name,value):
    equal(rational(summary['closure'][name]),value,name)

script=parent/'profile-reduction/reduce_saved_profiles.py'
equal(sha(script),report['profile_script_sha256'],'reducer pin')
for name,digest in report['output_sha256'].items():
    equal(sha(folder/name),digest,'output pin '+name)
with (folder/'width_profiles.csv').open(newline='') as stream:
    width_rows=list(csv.DictReader(stream))
with (folder/'paired_width_controls.csv').open(newline='') as stream:
    paired_rows=list(csv.DictReader(stream))
width_by_key={(row['case_id'],int(row['window_index']),int(row['width_index'])):row for row in width_rows}
paired_by_key={(row['case_id'],int(row['window_index']),row['observable']):row for row in paired_rows}
equal(len(width_by_key),len(width_rows),'unique width rows')
equal(len(paired_by_key),len(paired_rows),'unique paired rows')
summaries={(item['case_id'],item['window_index']):item for item in report['profiles']}
case_pins={}
windows_checked=components_checked=paired_invariants=paired_descriptors=0
for case in report['cases']:
    case_id=case['case_id']
    path=study/('case_'+case_id+'.json')
    equal(sha(path),report['input_files_sha256'][str(path.resolve())],'original case pin')
    case_pins[str(path)]=sha(path)
    case_data=json.loads(path.read_text())
    for window in case_data['windows']:
        wi=window['window_index']
        summary=summaries[(case_id,wi)]
        source=window['conditioned_source']
        x=tuple(F(value) for value in source['x_edges_m'])
        z=tuple(F(value) for value in source['z_edges_m'])
        W=x[-1]-x[0];L=z[-1]-z[0]
        N=[ZERO for _ in x[:-1]];E=[ZERO for _ in x[:-1]]
        component_counts=[0 for _ in x[:-1]]
        area_residual=N_density_residual=E_density_residual=thermal_residual=ZERO
        for index,component in enumerate(source['components']):
            xi=component['width_index'];zi=component['current_index']
            scalar=component['source_window'];q=scalar['quantities']
            equal(q['released_number']['qualified'],True,'qualified count')
            equal(q['translational_energy_j']['qualified'],True,'qualified translation')
            n=F(q['released_number']['value']);e=F(q['translational_energy_j']['value'])
            N[xi]+=n;E[xi]+=e;component_counts[xi]+=1
            actual_area=(x[xi+1]-x[xi])*(z[zi+1]-z[zi])
            declared_area=F(scalar['patch_area_m2'])
            reduced=summary['components'][index]
            equal(rational(reduced['released_number']),n,'component represented count')
            equal(rational(reduced['translational_energy_j']),e,'component represented energy')
            equal(rational(reduced['actual_geometry_area_m2']),actual_area,'component actual area')
            equal(rational(reduced['area_rounding_residual_m2']),declared_area-actual_area,'signed area residual')
            area_residual+=declared_area-actual_area
            thermal_residual+=e-n*2*KB*F(scalar['temperature_k'])
            if q['released_m2']['qualified'] and q['released_m2']['value'] is not None:
                N_density_residual+=n-F(q['released_m2']['value'])*declared_area
            if q['translational_energy_j_m2']['qualified'] and q['translational_energy_j_m2']['value'] is not None:
                E_density_residual+=e-F(q['translational_energy_j_m2']['value'])*declared_area
            components_checked+=1
        total_n=sum(N,ZERO);total_e=sum(E,ZERO)
        equal(summary['released_number'],float(total_n),'summary count')
        equal(summary['translational_energy_j'],float(total_e),'summary translation')
        residuals=[ZERO,ZERO,ZERO,ZERO]
        for i,(n,e) in enumerate(zip(N,E)):
            row=width_by_key[(case_id,wi,i)]
            dx=x[i+1]-x[i];A=dx*L
            un=total_n*dx/W;ue=total_e*dx/W
            equal(int(row['retained_components']),component_counts[i],'retained component count')
            for key,value in (
                ('actual_width_bin_area_m2',A),
                ('resolved_released_number',n),('matched_uniform_width_released_number',un),
                ('resolved_translational_energy_j',e),('matched_uniform_width_translational_energy_j',ue),
                ('resolved_released_areal_density_m2',n/A),('matched_uniform_width_released_areal_density_m2',un/A),
                ('resolved_translational_energy_areal_density_j_m2',e/A),('matched_uniform_width_translational_energy_areal_density_j_m2',ue/A),
                ('resolved_expected_translational_energy_per_parent_j',e/n if n else None),
                ('matched_uniform_width_expected_translational_energy_per_parent_j',total_e/total_n if total_n else None),
                ('resolved_expected_translational_energy_per_parent_ev',e/n/QE if n else None),
                ('matched_uniform_width_expected_translational_energy_per_parent_ev',total_e/total_n/QE if total_n else None),
            ):
                csv_expected(row,key,value)
            residuals[0]+=F(float(row['resolved_released_areal_density_m2']))*A-n
            residuals[1]+=F(float(row['resolved_translational_energy_areal_density_j_m2']))*A-e
            residuals[2]+=F(float(row['matched_uniform_width_released_areal_density_m2']))*A-un
            residuals[3]+=F(float(row['matched_uniform_width_translational_energy_areal_density_j_m2']))*A-ue
        for name,value in zip((
            'resolved_displayed_areal_density_integral_minus_count',
            'resolved_displayed_energy_density_integral_minus_energy_j',
            'uniform_displayed_areal_density_integral_minus_count',
            'uniform_displayed_energy_density_integral_minus_energy_j'),residuals):
            stored_closure(summary,name,value)
        stored_closure(summary,'matched_uniform_width_minus_resolved_number',ZERO)
        stored_closure(summary,'matched_uniform_width_minus_resolved_energy_j',ZERO)
        stored_closure(summary,'qualified_scalar_extensive_minus_areal_times_declared_area_number',N_density_residual)
        stored_closure(summary,'qualified_scalar_extensive_minus_areal_times_declared_area_energy_j',E_density_residual)
        stored_closure(summary,'source_energy_minus_represented_count_times_2kbT_j',thermal_residual)
        estimate=max(window['estimates'],key=lambda item:item['quadrature_order'])
        for key,row in paired_by_key.items():
            if key[:2]!=(case_id,wi):
                continue
            name=row['observable']
            if name=='mean_time_s':
                a=estimate['mean_time_anchor'];b=estimate['matched_uniform_width_mean_time_anchor']
                a=sum((F(a[name]) for name in ('interval_origin_s','window_start_offset_s','mean_time_offset_s')),ZERO)
                b=sum((F(b[name]) for name in ('interval_origin_s','window_start_offset_s','mean_time_offset_s')),ZERO)
            else:
                a=estimate['resolved'][name];b=estimate['matched_uniform_width'][name]
                a=F(a) if a is not None else None;b=F(b) if b is not None else None
            available=a is not None and b is not None
            equal(row['available'],str(available),'paired availability')
            csv_expected(row,'resolved_value',a);csv_expected(row,'matched_uniform_width_value',b)
            csv_expected(row,'resolved_minus_matched_uniform_width',a-b if available else None)
            equal(int(row['quadrature_order']),estimate['quadrature_order'],'highest stored order')
            equal(row['unit'],estimate['units'][name],'paired unit')
            if row['category']=='width_independent_invariant':
                equal(a,b,'matched non-width invariant')
                paired_invariants+=1
            else:
                equal(row['category'],'width_sensitive_descriptor','width category')
                paired_descriptors+=1
        windows_checked+=1
    del case_data
# The long-form changes are copied diagnostics. Their cells must be usable CSV
# projections, rather than Python dictionary representations of nested records.
change_row_counts={}
for name in ('source_resolution_differences.csv','quadrature_changes.csv'):
    with (folder/name).open(newline='') as stream:
        records=list(csv.DictReader(stream))
    for row in records:
        for value in row.values():
            if value is not None and value.lstrip().startswith('{'):
                raise AssertionError(('unflattened change record',name,value))
    change_row_counts[name]=len(records)
equal(len(width_rows),128,'declared profile rows')
equal(windows_checked,8,'declared case windows')
result={
    'schema':'mhdlab-saved-source-profile-independent-readback-v1',
    'reducer_sha256':sha(script),'profile_report_sha256':sha(report_path),
    'output_sha256':report['output_sha256'],'original_case_sha256':case_pins,
    'checked_case_windows':windows_checked,'checked_width_rows':len(width_rows),
    'checked_original_components':components_checked,'checked_paired_controls':len(paired_rows),
    'paired_invariants':paired_invariants,'paired_width_descriptors':paired_descriptors,
    'change_csv_rows':change_row_counts,'exact_or_projected_equalities_passed':checks,
    'open_substantive_findings':[],
    'scope':'Saved original JSON and final CSV/report arithmetic only; reducer, source laws, moments, history, sampler, solver and old test suites are not called.',
    'ledger_scope':'Released parent count and expected translational source energy; no internal/removal/full-wall-ledger reduction is claimed.'
}
path=work/'profile_readback.json'
path.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps(result,indent=2,allow_nan=False))
