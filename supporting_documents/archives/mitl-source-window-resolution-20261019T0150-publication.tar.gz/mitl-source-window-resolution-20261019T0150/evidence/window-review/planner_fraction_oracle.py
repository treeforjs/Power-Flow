"""Independent exact-intersection planner oracle for new endpoint cases."""
from fractions import Fraction as F
import hashlib
import json
import math
from pathlib import Path
import sys

REPO=Path('/workspace/Power-Flow')
sys.path.insert(0,str(REPO))
from mhdlab.source_window_plan import SourceTimeWindow,plan_source_windows

TOLERANCE=1e-7
minimum=float.fromhex('0x0.0000000000001p-1022')
def oracle(edges,windows):
    """All fixture endpoints are supported/disjoint; qualify only projections."""
    result=[]
    for w,(left,right) in enumerate(windows):
        for i,(lo,hi) in enumerate(zip(edges[:-1],edges[1:])):
            a=max(F(left),F(lo));b=min(F(right),F(hi))
            if a>=b:
                continue
            span=b-a
            exact_start=a-F(lo);exact_stop=b-F(lo)
            projected_start=float(exact_start);projected_stop=float(exact_stop)
            exact_parent=F(hi)-F(lo);parent=float(exact_parent)
            projected_duration=float(F(projected_stop)-F(projected_start))
            errors={
                'start':abs(F(projected_start)-exact_start)/span,
                'stop':abs(F(projected_stop)-exact_stop)/span,
                'duration':abs(F(projected_duration)-span)/span,
            }
            if b==F(hi):
                errors['applicable_parent_duration']=abs(F(parent)-exact_parent)/span
            valid=(0<=projected_start<projected_stop<=parent
                   and all(error<=F(TOLERANCE) for error in errors.values()))
            result.append({'window':w,'interval':i,'start':projected_start,'stop':projected_stop,
                           'exact_span':str(span),'projection_errors':{k:str(v) for k,v in errors.items()},
                           'qualifies':valid})
    return result

cases=[
    ('unrelated_parent_rounding_must_not_reject_tiny_early_window',(minimum,1.),((minimum,2*minimum),)),
    ('positive_relative_error_below_float_range',(0.,1e-300,1e300),((0.,1e300),)),
    ('ordinary_input_order_and_interval_tiling',(0.,1.,2.,4.),((2.,4.),(0.,1.),(1.,2.))),
]
for exponent in (54,56,60):
    right=float(2**exponent)
    below=math.nextafter(right,-math.inf)
    ulp=right-below
    cases.append((f'collapsed_or_shifted_late_ulp_k{exponent}',(3.,right),((below,right),)))
    wide_left=right-ulp*(2**20)
    cases.append((f'wide_enough_late_window_k{exponent}',(3.,right),((wide_left,right),)))
    midpoint=right/2
    cases.append((f'adjacent_shared_cut_reversed_input_k{exponent}',(3.,right),((midpoint,right),(3.,midpoint))))

rows=[]
accepted=rejected=0
for name,edges,windows in cases:
    expected=oracle(edges,windows)
    expected_accept=all(part['qualifies'] for part in expected)
    try:
        result=plan_source_windows(edges,tuple(SourceTimeWindow(a,b) for a,b in windows),
                                   relative_time_tolerance=TOLERANCE)
    except ValueError as error:
        if expected_accept:
            raise AssertionError((name,'unexpected rejection',str(error),expected)) from error
        rejected+=1
        outcome={'accepted':False,'reason':str(error)}
    else:
        if not expected_accept:
            raise AssertionError((name,'unexpected acceptance',expected))
        actual=[(int(w),selection.interval_index,selection.start_s,selection.stop_s)
                for w,selection in zip(result.window_indices,result.selections)]
        mapped=[(p['window'],p['interval'],p['start'],p['stop']) for p in expected]
        if actual!=mapped:
            raise AssertionError((name,actual,mapped))
        # Two adjacent global windows share one exact cut. Their corresponding
        # local projections must agree even when the input order is reversed.
        if name.startswith('adjacent_shared_cut'):
            if result.selections[0].start_s!=result.selections[1].stop_s:
                raise AssertionError('Shared cut does not tile')
        accepted+=1
        outcome={'accepted':True,'mapped':actual}
    rows.append({'name':name,'edges_s':edges,'windows_s':windows,
                 'oracle_parts':expected,'outcome':outcome})
report={
    'schema':'mhdlab-new-source-window-plan-fraction-oracle-v1',
    'planner_sha256':hashlib.sha256((REPO/'mhdlab/source_window_plan.py').read_bytes()).hexdigest(),
    'relative_time_tolerance':TOLERANCE,'cases':rows,
    'accepted_cases':accepted,'explicitly_rejected_cases':rejected,
    'all_oracle_comparisons_passed':True,
    'scope':'New exact Fraction endpoint/intersection tests only; no prior suite, saved oracle, canonical source history, release law, sampler, transport or spectra.'
}
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps(report,indent=2,allow_nan=False))
