"""Pin final coordinate review after the planner owner's freeze notice."""
import datetime
import hashlib
import json
from pathlib import Path

work=Path(__file__).resolve().parent
parent=work.parent
repo=Path('/workspace/Power-Flow')
source=repo/'mhdlab/source_window_plan.py'
expected='fa9169160a87de666a9add85f991935af59d8ffd2c56c35ca5a18a166e181688'
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
if sha(source)!=expected:
    raise SystemExit('Final source differs from owner freeze notice')
oracle=json.loads((work/'planner_fraction_oracle.json').read_text())
gap=json.loads((work/'planner_gap_projection_probe.json').read_text())
commands=[json.loads(line) for line in (parent/'commands.jsonl').read_text().splitlines()]
own=[record for record in commands if Path(record['log']).name in {'planner_fraction_oracle.log','planner_gap_projection_probe.log'}]
if len(own)!=2 or any(record['exit_code']!=0 or sha(record['log'])!=record['log_sha256'] for record in own):
    raise SystemExit('Coordinate probe evidence mismatch')
artifacts={
    name:sha(work/name) for name in (
        'review_notes.md','planner_fraction_oracle.py','planner_fraction_oracle.json',
        'planner_gap_projection_probe.py','planner_gap_projection_probe.json')
}
artifacts.update({str(Path(record['log']).relative_to(parent)):record['log_sha256'] for record in own})
report={
    'schema':'mhdlab-source-window-plan-independent-review-v1',
    'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'reviewed_source_sha256':{'mhdlab/source_window_plan.py':expected},
    'artifact_sha256':artifacts,'focused_commands':own,
    'new_fraction_oracle':{
        'cases':len(oracle['cases']),'accepted':oracle['accepted_cases'],
        'explicit_rejections':oracle['explicitly_rejected_cases'],
        'all_comparisons_passed':oracle['all_oracle_comparisons_passed'],
        'executed_source_sha256':oracle['planner_sha256'],
    },
    'new_gap_semantics_probe':{
        'cases':1,'exact_requested_gap_s':gap['exact_requested_gap_s'],
        'projected_local_gap_s':gap['projected_local_gap_s'],
        'executed_source_sha256':gap['planner_sha256'],
    },
    'closed_substantive_findings':[
        {'id':'qualified_endpoint_motion_and_tiny_gap_semantics',
         'finding':'Nearest local endpoint projections may expand a cut and close a smaller positive exact gap while passing selected-span-relative tolerance. Earlier never-expanded wording did not describe the projected support correctly.',
         'resolution':'Module description and manifest now explicitly disclose endpoint movement/tiny-gap closure, prohibit projected overlap and manual repair, and distinguish geometric tolerance from a source-mass or physical-timing bound.',
         'algorithm_changed':False,
         'verification':'One new coordinate probe and read-only final wording inspection; author added a focused regression. The twelve already-passing oracle cases were not rerun for a doc/metadata change.'}
    ],
    'open_substantive_findings':[],
    'review_conclusions':[
        'Exact rational intersections cover every positive part of supported disjoint source windows without truncation or dropping.',
        'Output preserves caller window identity/order and chronological original interval association within each window.',
        'Local endpoint/duration errors are relative to positive intersection support, not a large absolute epoch or parent duration.',
        'Rounded canonical parent-duration error is always reported and qualified against the selected span only when its boundary is selected.',
        'Shared exact cuts within one original interval project consistently; collapsed or unsupported positive spans reject without repair.',
        'Exact rational and underflow diagnostics retain nonzero errors smaller than float64 projections.',
        'Accepted geometric projection may erase a tiny gap; it is not exact support preservation or a release-law mass qualification.',
    ],
    'old_suites_or_oracles_repeated':False,
    'source_evolution_or_law_or_sampler_called':False,
    'public_files_edited':False,
    'host_budget_accepted':False,
    'limits':[
        'Coordinate-only independent review and thirteen new bounded cases; no physical source, gap, collision, radiation, spectra or experimental validation.',
        'Global inputs denote supplied binary64 endpoints; no unrecoverable higher-precision experimental timestamp is inferred.',
        'Source-emission restrictions are distinct from photon observation gates.',
        'The exact reviewed code pin is authoritative; any later code change needs a scoped review update.',
    ],
}
path=work/'review_completion.json'
path.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps({'completion':str(path),'sha256':sha(path),'reviewed_source_sha256':report['reviewed_source_sha256'],
                  'new_cases':13,'open_substantive_findings':[]},indent=2))
