"""New documentary probe of a tiny positive gap after local projection."""
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path
import sys

repo=Path('/workspace/Power-Flow')
sys.path.insert(0,str(repo))
from mhdlab.source_window_plan import SourceTimeWindow,plan_source_windows

cut=float(2**54)
edges=(3.,float(2**55))
windows=(SourceTimeWindow(3.,cut-2.),SourceTimeWindow(cut,float(2**55)))
plan=plan_source_windows(edges,windows,relative_time_tolerance=1e-7)
manifest=plan.manifest()
left,right=plan.selections
exact_gap=F(windows[1].start_s)-F(windows[0].stop_s)
projected_gap=F(right.start_s)-F(left.stop_s)
if exact_gap!=2 or projected_gap!=0:
    raise AssertionError((exact_gap,projected_gap))
records=manifest['selection_records']
def rational(record):
    return F(int(record['numerator']),int(record['denominator']))
if rational(records[0]['local_stop_projection_error']['exact_s'])!=1:
    raise AssertionError(records[0])
if rational(records[1]['local_start_projection_error']['exact_s'])!=-1:
    raise AssertionError(records[1])
report={
    'schema':'mhdlab-new-planner-tiny-gap-projection-probe-v1',
    'planner_sha256':hashlib.sha256((repo/'mhdlab/source_window_plan.py').read_bytes()).hexdigest(),
    'exact_requested_gap_s':str(exact_gap),'projected_local_gap_s':str(projected_gap),
    'windows':[window.manifest() for window in windows],
    'mapped_selections':[selection.manifest() for selection in plan.selections],
    'left_stop_projection_error_s':1.,'right_start_projection_error_s':-1.,
    'qualified_span_relative_errors':[
        records[0]['local_stop_projection_error']['relative_to_intersection'],
        records[1]['local_start_projection_error']['relative_to_intersection']],
    'interpretation':'Accepted span-relative projection may expand one endpoint and erase a smaller positive gap. This does not create overlap, clipping, manual repair, a physical timing uncertainty, or a bound on emitted source number.',
    'scope':'One new coordinate-only case; no prior suite, source evolution, law inversion, sampler, transport or spectra.'
}
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps(report,indent=2,allow_nan=False))
