"""Verify the actual compressed handoff, public bytes and evidence bindings."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess
import tarfile

work=Path(__file__).resolve().parent
repo=Path('/workspace/Power-Flow')
out=Path('/workspace/handoffs/mitl-source-window-resolution-20261019T0150')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_text())
frozen=load(work/'frozen_handoff.json')
archive=Path(frozen['archive']); assert sha(archive)==frozen['sha256']
with tarfile.open(archive,'r:gz') as tar:
    files={}
    for member in tar.getmembers():
        path=PurePosixPath(member.name)
        assert not path.is_absolute() and '..' not in path.parts and path.parts[0]==out.name
        assert not member.issym() and not member.islnk()
        if member.isdir():continue
        assert member.isfile()
        name=str(PurePosixPath(*path.parts[1:])); assert name not in files
        files[name]=tar.extractfile(member).read()
manifest=json.loads(files['manifest.sha256.json'])
assert set(files)==set(manifest)|{'manifest.sha256.json'}
for name,digest in manifest.items():assert hashlib.sha256(files[name]).hexdigest()==digest,name
listing=json.loads(files['source_file_list.json'])
for name in listing['byte_identical_public_files']:
    assert files['source/'+name]==(repo/name).read_bytes(),name
verification=json.loads(files['verification.json'])
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert head==frozen['source_commit']==verification['source_commit']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip()
study=json.loads(files['evidence/snapshot-window-study/report.json'])
for name,digest in study['output_sha256'].items():
    assert hashlib.sha256(files['evidence/snapshot-window-study/'+name]).hexdigest()==digest,name
for name,digest in study['source_sha256'].items():assert sha(repo/name)==digest,name
profile=json.loads(files['evidence/profile-reduction/artifacts/report.json'])
for name,digest in profile['output_sha256'].items():
    assert hashlib.sha256(files['evidence/profile-reduction/artifacts/'+name]).hexdigest()==digest,name
assert verification['results']['portable_unique_passed']==105
result={**frozen,'status':'passed','actual_archive_regular_files':len(files),'manifest_entries':len(manifest),
        'public_files_byte_identical':len(listing['byte_identical_public_files']),
        'packaging_wrappers':len(listing['packaging_wrappers']),'unsafe_or_duplicate_members':0,
        'input_code_output_bindings_verified':True,'repository_clean':True}
(work/'delivery_verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
