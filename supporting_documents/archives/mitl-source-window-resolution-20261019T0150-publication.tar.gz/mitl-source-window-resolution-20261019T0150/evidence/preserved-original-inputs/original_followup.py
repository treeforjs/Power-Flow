#!/usr/bin/env python3
"""Work-only manufactured follow-up; finite changes are not uncertainties.

Historical source-array bytes were not saved by the initial CLI. Their hashes
remain historical records, never independently revalidated array digests here.
New cases persist all numeric inputs/source arrays for actual hash verification.
"""

from __future__ import annotations

import argparse
import datetime
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import platform
import sys
import tempfile

import numpy as np
import scipy


ROOT = Path('/workspace/Power-Flow')
WORK = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from mhdlab.planar_release import PlanarSurfaceHistory
from mhdlab.source_convergence import (
    manufactured_planar_surface, source_observables, compare_observables,
    observed_self_order,
)
from mhdlab.temkin_planar import evolve_temkin_planar_release


spec = importlib.util.spec_from_file_location('recorded_convergence_cli', ROOT/'tools/verify_temkin_planar_convergence.py')
cli = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cli)

SOURCE_ARRAYS = (
    'time_edges_s', 'x_edges_m', 'z_edges_m', 'temperature_k', 'coverage_m2',
    'released_m2', 'translational_energy_j_m2', 'internal_energy_j_m2',
    'binding_energy_j_m2', 'total_wall_energy_debit_j_m2',
    'inventory_balance_residual_m2', 'inversion_iterations',
    'inversion_log_time_residual', 'inversion_regime',
)
INPUT_ARRAYS = ('time_s', 'x_edges_m', 'z_edges_m', 'temperature_k')
LIMITS = [
    'All rates, energies, masses and temperatures are manufactured numerical inputs, not physical water/foil calibration.',
    'Every reference is a finite numerical solution; no continuum solution or experimental uncertainty is inferred.',
    'Historical source-array hashes are retained from the pinned initial report; absent historical array bytes prevent independent recomputation.',
    'Historical reuse verifies report/artifact/config and code digests plus regenerated original input-array hashes; no old source integration is repeated.',
    'Snapshot study changes original knot count and equivalent subdivisions together, exposing the same original piecewise-linear interpolant on one exact common512-edge grid.',
    'Resampling adds no recovered information or temporal smoothing. It is a representation of each original piecewise-linear interpolant.',
    'Fixed512 integration leaves finite midpoint-integration error; spatial resolutions remain finite in every family.',
    'Follow-up runtime versions are recorded at this run, not retroactively certified for the historical run.',
]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def canonical_json(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()


def object_sha(value):
    return hashlib.sha256(canonical_json(value)).hexdigest()


def array_record(value):
    array = np.asarray(value)
    if array.dtype.kind == 'f':
        dtype = '<f8'
    elif array.dtype.kind in 'iu':
        dtype = ('<' if array.dtype.itemsize > 1 else '|') + array.dtype.kind + str(array.dtype.itemsize)
    else:
        raise ValueError('only real numeric source arrays are supported')
    array = np.asarray(array, dtype=dtype, order='C')
    if not np.all(np.isfinite(array)):
        raise ValueError('source arrays must be finite')
    header = {'shape': list(array.shape), 'dtype': dtype, 'order': 'C'}
    digest = hashlib.sha256(canonical_json(header)+b'\n'+array.tobytes()).hexdigest()
    return dict(header, sha256=digest)


def atomic_json(path, value):
    payload = json.dumps(value, indent=2, allow_nan=False)+'\n'
    with tempfile.NamedTemporaryFile(mode='w', dir=path.parent, prefix='.'+path.name, delete=False) as stream:
        staged = Path(stream.name)
        stream.write(payload)
    try:
        os.replace(staged, path)
    finally:
        staged.unlink(missing_ok=True)


def strict_pairs(pairs):
    output = {}
    for key, value in pairs:
        if key in output:
            raise ValueError('duplicate JSON key: '+key)
        output[key] = value
    return output


def load_json(path):
    def reject(value):
        raise ValueError('nonfinite JSON constant: '+value)
    return json.loads(Path(path).read_bytes(), object_pairs_hook=strict_pairs, parse_constant=reject)


def version_record():
    return {'python': sys.version, 'python_implementation': platform.python_implementation(),
            'numpy': np.__version__, 'scipy': scipy.__version__, 'platform': platform.platform(),
            'machine': platform.machine(), 'float64_dtype': np.dtype('<f8').str,
            'float64_epsilon': float(np.finfo(float).eps)}


def work_path(value):
    path = Path(value).resolve()
    if not path.is_relative_to(WORK) or path == WORK:
        raise ValueError('outputs must remain below the current work directory')
    return path


def plans(base):
    studies = {
        'width_refined': {'varied': 'width_bins', 'levels': [16, 32, 64], 'reference': 128},
        'current_refined': {'varied': 'current_bins', 'levels': [4, 8, 16], 'reference': 32},
        'snapshot_fixed512': {'varied': 'snapshot_intervals', 'levels': [8, 16, 32], 'reference': 64},
    }
    unique = {}
    for family, study in studies.items():
        case_ids = []
        for level in study['levels']+[study['reference']]:
            resolution = dict(base, **{study['varied']: level})
            common = family == 'snapshot_fixed512'
            if common:
                resolution['subdivisions_per_interval'] = 512//level
            case_id = 'x%d-z%d-s%d-i%d' % tuple(resolution[key] for key in cli.FAMILIES.values())
            if common:
                case_id += '-common512'
            unique[case_id] = {'resolution': resolution, 'fixed_common_grid': common}
            case_ids.append(case_id)
        study['case_ids'] = case_ids
        study['fixed_resolution'] = {key: value for key, value in base.items() if key != study['varied']}
        if family == 'snapshot_fixed512':
            study['fixed_resolution'].pop('subdivisions_per_interval')
            study['fixed_actual_frozen_midpoint_intervals'] = 512
            study['changed_resolution_knobs'] = ['snapshot_intervals', 'subdivisions_per_interval']
            study['actual_integrator_representation'] = 'resampled_original_piecewise_linear_interpolant_512_intervals_subdivisions1'
    return unique, studies


def input_surface(config, plan):
    resolution = plan['resolution']
    original = manufactured_planar_surface(
        **{key: resolution[key] for key in ('width_bins', 'current_bins', 'snapshot_intervals')},
        **{key: config[key] for key in ('duration_s', 'width_m', 'current_length_m')})
    if not plan['fixed_common_grid']:
        return original, original, resolution['subdivisions_per_interval']
    common = np.linspace(0., config['duration_s'], 513)
    stride = resolution['subdivisions_per_interval']
    if 512 % resolution['snapshot_intervals'] or not np.array_equal(original.time_s, common[::stride]):
        raise ValueError('original analytic knots must be exact subsets of the common512 grid')
    indices = np.minimum(np.searchsorted(original.time_s, common, side='right')-1, len(original.time_s)-2)
    fraction = (common-original.time_s[indices])/(original.time_s[indices+1]-original.time_s[indices])
    temperature = ((1-fraction[:, None, None])*original.temperature_k[indices]
                   +fraction[:, None, None]*original.temperature_k[indices+1])
    attrs = original.attributes
    attrs['manufactured_snapshot_interpolation'] = 'original piecewise-linear analytic snapshots exposed on exact common512 grid; resampled values are not additional analytic snapshots'
    attrs['followup_common_grid_resampling'] = {
        'original_snapshot_intervals': resolution['snapshot_intervals'],
        'equivalent_subdivisions_per_original_interval': stride,
        'actual_integrator_snapshot_intervals': 512, 'actual_integrator_subdivisions': 1,
        'additional_recovered_information': False, 'temporal_smoothing': False,
        'original_snapshot_attributes': original.attributes,
    }
    surface = PlanarSurfaceHistory(common, original.x_edges_m, original.z_edges_m, temperature, attrs)
    return original, surface, 1


def validate_initial(path, expected_digest, config_path, config, code_hashes):
    if sha(path) != expected_digest:
        raise ValueError('initial report digest does not match explicit expected value')
    report = load_json(path)
    if report.get('schema') != 'mhdlab-temkin-planar-convergence-report-v1':
        raise ValueError('unexpected initial report schema')
    if report['input_config_sha256'] != sha(config_path) or report['config'] != config:
        raise ValueError('initial config bytes or parsed config do not match current supplied input')
    if report['source_sha256'] != code_hashes:
        raise ValueError('initial source/core code digests do not match current implementation')
    for filename, digest in report['output_sha256'].items():
        artifact = path.parent/filename
        if artifact.parent != path.parent or sha(artifact) != digest:
            raise ValueError('initial artifact digest mismatch: '+filename)
    return report


def validate_historical(case, original):
    regenerated = {name: array_record(getattr(original, name)) for name in INPUT_ARRAYS}
    if regenerated != case['input_arrays']:
        raise ValueError('historical regenerated input-array hashes disagree')
    for record in case['source_arrays'].values():
        if (record.get('dtype') != '<f8' or record.get('order') != 'C'
                or not isinstance(record.get('shape'), list)
                or not isinstance(record.get('sha256'), str) or len(record['sha256']) != 64):
            raise ValueError('invalid historical source-array hash record')
    return {
        'kind': 'historical_source_reused_without_integration',
        'regenerated_input_array_hashes_match': True,
        'historical_source_array_bytes_available': False,
        'historical_source_array_hashes_independently_recomputed': False,
        'source_array_evidence': 'retained digest records in explicitly pinned initial report',
    }


def verify_cache(record_path, config_digest, code_hashes, original, surface, coverage):
    record = load_json(record_path)
    if record['config_sha256'] != config_digest or record['source_sha256'] != code_hashes:
        raise ValueError('new-case cache configuration/code mismatch; refusing reintegration')
    npz_path = record_path.parent/record['npz_filename']
    if npz_path.parent != record_path.parent or sha(npz_path) != record['npz_sha256']:
        raise ValueError('new-case compressed-array cache digest mismatch')
    with np.load(npz_path, allow_pickle=False) as arrays:
        if set(arrays.files) != set(record['array_records']):
            raise ValueError('new-case array cache names disagree')
        for name, expected in record['array_records'].items():
            if array_record(arrays[name]) != expected:
                raise ValueError('new-case canonical array digest mismatch: '+name)
    for prefix, source in (('original', original), ('input', surface)):
        for name in INPUT_ARRAYS:
            if array_record(getattr(source, name)) != record['array_records'][prefix+'__'+name]:
                raise ValueError('new-case regenerated input digest mismatch')
    if array_record(coverage) != record['array_records']['input__initial_coverage_m2']:
        raise ValueError('new-case initial coverage digest mismatch')
    if object_sha(record['observables']) != record['observables_sha256']:
        raise ValueError('new-case cached observable record digest mismatch')
    return record


def new_case(case_id, plan, config, pools, initial, output, code_hashes, config_digest, versions):
    original, surface, subdivisions = input_surface(config, plan)
    resolution = plan['resolution']
    coverage = np.broadcast_to(np.asarray(initial)[:, None, None],
                               (len(pools), resolution['current_bins'], resolution['width_bins']))
    record_path = output/'cases'/(case_id+'.json')
    if record_path.exists():
        record = verify_cache(record_path, config_digest, code_hashes, original, surface, coverage)
        record['reuse'] = 'verified_new_case_cache_reused_without_integration'
        print('verified cached new case '+case_id, flush=True)
        return record, False
    print('integrating NEW case '+case_id, flush=True)
    history = evolve_temkin_planar_release(surface, coverage, pools,
                                          parameter_provenance=config['parameter_provenance'],
                                          subdivisions_per_interval=subdivisions)
    if plan['fixed_common_grid'] and not np.array_equal(history.time_edges_s, surface.time_s):
        raise ValueError('actual integration grid is not the declared exact common grid')
    observables = source_observables(history, state_masses_kg=config['state_masses_kg'],
                                     include_time_moments=config['include_time_moments'],
                                     time_quadrature_order=config['time_quadrature_order'])
    arrays = {prefix+'__'+name: getattr(source, name)
              for prefix, source in (('original', original), ('input', surface)) for name in INPUT_ARRAYS}
    arrays['input__initial_coverage_m2'] = coverage
    arrays.update({'source__'+name: getattr(history, name) for name in SOURCE_ARRAYS})
    npz_path = record_path.with_suffix('.npz')
    with tempfile.NamedTemporaryFile(dir=npz_path.parent, prefix='.'+npz_path.name, delete=False) as stream:
        staged = Path(stream.name)
        np.savez_compressed(stream, **arrays)
    os.replace(staged, npz_path)
    record = {
        'schema': 'mitl-work-followup-source-case-v1', 'case_id': case_id,
        'resolution': resolution, 'plan': plan, 'config_sha256': config_digest,
        'source_sha256': code_hashes, 'runtime_versions_at_integration': versions,
        'followup_script_sha256_at_integration': sha(__file__),
        'npz_filename': npz_path.name, 'npz_sha256': sha(npz_path),
        'array_records': {name: array_record(value) for name, value in arrays.items()},
        'input_surface_attributes': surface.attributes,
        'observables': observables, 'observables_sha256': object_sha(observables),
        'max_abs_inversion_log_time_residual': float(np.max(np.abs(history.inversion_log_time_residual))),
        'reuse': 'newly_integrated_once',
    }
    atomic_json(record_path, record)
    # Reopen persisted bytes: a successful in-memory integration alone does not
    # establish that a future process can verify the cached numeric artifacts.
    verified = verify_cache(record_path, config_digest, code_hashes, original, surface, coverage)
    print('saved and hash-verified '+case_id, flush=True)
    return verified, True


def selected(observables, names):
    return {'metrics': {name: observables['metrics'][name] for name in names},
            'units': {name: observables['units'][name] for name in names}}


def plot(report, path):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig, axes = plt.subplots(1, 3, figsize=(15, 4.5), constrained_layout=True)
    for ax, (family, study) in zip(axes, report['studies'].items()):
        for name in report['selected_metrics']:
            pairs = [(level, study['comparisons'][case_id]['metrics'][name]['relative_l2'])
                     for level, case_id in zip(study['levels'], study['case_ids'][:-1])]
            valid = [(level, value) for level, value in pairs if value is not None and value > 0]
            if valid:
                ax.loglog(*zip(*valid), marker='o', label=name)
        ax.set(title=family, xlabel=study['varied'], ylabel='relative difference to finite finest reference')
        ax.grid(True, which='both', alpha=.25)
        ax.legend(fontsize=6)
    fig.suptitle('Manufactured follow-up; finite references, no continuum/error-bound claim')
    fig.savefig(path, dpi=160)
    plt.close(fig)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--initial-report', type=Path, default=WORK/'manufactured-convergence/report.json')
    parser.add_argument('--initial-report-sha256', required=True)
    parser.add_argument('--config', type=Path, default=ROOT/'configs/temkin_convergence_manufactured.json')
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--plan-only', action='store_true')
    parser.add_argument('--plot', action='store_true')
    args = parser.parse_args()
    output = work_path(args.output_dir)
    config, pools, initial = cli.load_config(args.config)
    config_digest = sha(args.config)
    code_hashes = {name: sha(ROOT/name) for name in cli.CODE_PATHS}
    original_report = validate_initial(args.initial_report, args.initial_report_sha256, args.config, config, code_hashes)
    cases_plan, studies = plans(config['base_resolution'])
    reused, new_ids = [], []
    for case_id, plan in cases_plan.items():
        original, surface, _ = input_surface(config, plan)
        if case_id in original_report['cases']:
            validate_historical(original_report['cases'][case_id], original)
            reused.append(case_id)
        else:
            new_ids.append(case_id)
    versions = version_record()
    print(json.dumps({'historical_reused_cases': reused, 'new_cases': new_ids,
                      'runtime_versions_at_followup': versions}, indent=2), flush=True)
    if len(reused) != 5 or len(new_ids) != 6:
        raise ValueError('unexpected plan; refusing any additional integration')
    if args.plan_only:
        return
    output.mkdir(parents=True, exist_ok=True)
    (output/'cases').mkdir(exist_ok=True)
    records, newly_integrated = {}, 0
    for case_id, plan in cases_plan.items():
        if case_id in original_report['cases']:
            original, _, _ = input_surface(config, plan)
            evidence = validate_historical(original_report['cases'][case_id], original)
            records[case_id] = dict(original_report['cases'][case_id], reuse=evidence)
            print('reused historical source case '+case_id, flush=True)
        else:
            record, computed = new_case(case_id, plan, config, pools, initial, output, code_hashes, config_digest, versions)
            records[case_id] = record
            newly_integrated += int(computed)
    common_records = [records[case_id]['array_records']['source__time_edges_s']
                      for case_id, plan in cases_plan.items() if plan['fixed_common_grid']]
    if not all(record == common_records[0] for record in common_records):
        raise ValueError('fixed-grid snapshot cases do not share the identical actual time-edge digest')
    for family, study in studies.items():
        selected_cases = [selected(records[case_id]['observables'], config['selected_metrics']) for case_id in study['case_ids']]
        study['comparisons'] = {case_id: compare_observables(value, selected_cases[-1])
                                for case_id, value in zip(study['case_ids'][:-1], selected_cases[:-1])}
        all_levels = study['levels']+[study['reference']]
        study['self_orders'] = []
        for index in range(len(all_levels)-2):
            estimates = {}
            for name in config['selected_metrics']:
                values = [selected_cases[j]['metrics'][name] for j in range(index, index+3)]
                if any(any(value is None for value in level) for level in values):
                    estimates[name] = {'observed_order': None, 'warnings': ['undefined normalized observable']}
                else:
                    estimates[name] = observed_self_order(*values, refinement_ratio=all_levels[index+1]/all_levels[index])
            study['self_orders'].append({'case_ids': study['case_ids'][index:index+3],
                                         'resolutions': all_levels[index:index+3],
                                         'includes_finite_reference_as_third_numerical_level': index+2 == len(all_levels)-1,
                                         'metrics': estimates})
    if sha(args.config) != config_digest or any(sha(ROOT/name) != digest for name, digest in code_hashes.items()):
        raise ValueError('configuration or implementation changed during follow-up')
    report = {
        'schema': 'mitl-work-source-refinement-followup-v1', 'parameter_status': 'manufactured',
        'generated_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'runtime_versions_at_followup': versions, 'initial_report_sha256': args.initial_report_sha256,
        'input_config_sha256': config_digest, 'source_sha256': code_hashes,
        'followup_script_sha256': sha(__file__), 'config': config,
        'reference_kind': 'finite_finest_resolution_reference', 'selected_metrics': config['selected_metrics'],
        'unique_cases': len(records), 'historical_reused_cases': reused,
        'new_case_ids': new_ids, 'new_integrations_this_run': newly_integrated,
        'verified_new_cache_reuses_this_run': len(new_ids)-newly_integrated,
        'common512_time_edges_record': common_records[0],
        'array_hash_scheme': 'sha256(sorted compact JSON {shape,dtype,order}+newline+little-endian C-order numeric bytes); float arrays f8, integer diagnostics retain itemsize',
        'cases': records, 'studies': studies, 'limitations': LIMITS,
        'new_case_artifacts': {path.name: sha(path) for path in sorted((output/'cases').iterdir()) if path.is_file()},
    }
    if args.plot:
        plot(report, output/'refinement.png')
        report['figure_sha256'] = sha(output/'refinement.png')
    atomic_json(output/'report.json', report)
    print(json.dumps({'output': str(output), 'historical_reused': len(reused),
                      'new_integrations': newly_integrated, 'verified_cache_reuses': len(new_ids)-newly_integrated}), flush=True)


if __name__ == '__main__':
    main()
