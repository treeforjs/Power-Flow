"""Width profiles from preserved conditioned-source manifests, without evolution.

The input study must have completed atomically. Every supplied output hash is
checked before reading its conditioned components. Exact rational reductions use
the represented extensive source ledgers; no history, source law, sampler or
moment routine is imported or called.
"""
from __future__ import annotations

import argparse
import csv
from fractions import Fraction
import hashlib
import importlib.metadata
import json
import math
import os
from pathlib import Path
import sys
import tempfile


HERE = Path(__file__).resolve().parent
DEFAULT_STUDY = HERE.parent/'snapshot-window-study'
QE = 1.602176634e-19
KB = 1.380649e-23
ZERO = Fraction(0)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read_json(path):
    def pairs(values):
        result = {}
        for key,value in values:
            if key in result:
                raise ValueError('duplicate JSON key: '+key)
            result[key] = value
        return result
    def reject(value):
        raise ValueError('nonfinite JSON constant: '+value)
    return json.loads(Path(path).read_bytes(), object_pairs_hook=pairs, parse_constant=reject)


def represented(value, name):
    try:
        number = float(value)
    except OverflowError as error:
        raise ValueError(name+' exceeds finite output range') from error
    if not math.isfinite(number) or (value != 0 and number == 0.):
        raise ValueError(name+' is nonzero outside finite represented output range')
    return number


def exact_record(value):
    try:
        projected = float(value)
        overflow = not math.isfinite(projected)
    except OverflowError:
        projected,overflow = None,True
    if overflow:
        projected = None
    return {'value':projected, 'numerator':str(value.numerator), 'denominator':str(value.denominator),
            'nonzero_underflowed':bool(value and projected == 0.), 'overflowed':overflow}


def number(value,name,*,positive=False):
    if type(value) not in (float,int) or not math.isfinite(float(value)) or (positive and value <= 0):
        raise ValueError(name+' must be an explicitly finite real number'+(' >0' if positive else ''))
    return Fraction(value)


def extensive(window,name):
    quantity = window['quantities'][name]
    if type(quantity['qualified']) is not bool or not quantity['qualified']:
        raise ValueError('individual extensive '+name+' is not qualified')
    value = number(quantity['value'],name)
    if name == 'released_number' and (value <= 0 or quantity['exact_zero']):
        raise ValueError('a retained positive source component lacks positive extensive release')
    if name == 'translational_energy_j' and (value <= 0 or quantity['exact_zero']):
        raise ValueError('a retained positive thermal component lacks positive extensive translation')
    return value


def write_csv(path,rows,fields):
    with path.open('w',newline='') as handle:
        writer=csv.DictWriter(handle,fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def paired_width_controls(case_id,window_record):
    """Read highest-order deterministic controls; never rerun moment kernels."""
    estimate=max(window_record['estimates'],key=lambda item:item['quadrature_order'])
    resolved=estimate['resolved']
    uniform=estimate['matched_uniform_width']
    invariants=('released_number','mean_time_s','variance_time_s2','mean_z_m','variance_z_m2',
        'mean_expected_translational_energy_j','variance_expected_translational_energy_j2',
        'mean_conditional_kinetic_energy_variance_j2','variance_kinetic_energy_j2',
        'second_raw_kinetic_energy_j2','cov_time_z_s_m',
        'cov_time_expected_translational_energy_s_j','cov_expected_translational_energy_z_j_m')
    width_observables=('mean_x_m','variance_x_m2','mean_width_centered_square_m2',
        'variance_width_centered_square_m4','cov_time_x_s_m','cov_expected_translational_energy_x_j_m',
        'cov_time_width_centered_square_s_m2',
        'cov_expected_translational_energy_width_centered_square_j_m2')
    def anchored_time(hypothesis):
        key='mean_time_anchor' if hypothesis=='resolved' else 'matched_uniform_width_mean_time_anchor'
        anchor=estimate[key]
        if anchor is None:
            return None
        return sum((number(anchor[name],'retained time anchor')
                    for name in ('interval_origin_s','window_start_offset_s','mean_time_offset_s')),ZERO)
    rows=[]
    for category,names in (('width_independent_invariant',invariants),('width_sensitive_descriptor',width_observables)):
        for name in names:
            if name=='mean_time_s':
                a,b=anchored_time('resolved'),anchored_time('matched_uniform_width')
            else:
                a=number(resolved[name],name) if resolved[name] is not None else None
                b=number(uniform[name],name) if uniform[name] is not None else None
            available=a is not None and b is not None
            rows.append({'case_id':case_id,'window_index':window_record['window_index'],
                'quadrature_order':estimate['quadrature_order'],'category':category,'observable':name,
                'unit':estimate['units'][name],'available':available,
                'resolved_minus_matched_uniform_width':exact_record(a-b) if available else None,
                'resolved_value':exact_record(a) if a is not None else None,
                'matched_uniform_width_value':exact_record(b) if b is not None else None,
                'time_comparison':'retained interval origin + window start + local mean before subtraction' if name=='mean_time_s' else None})
    return rows


def reduce_window(case_id,resolution,window_record,*,parameter_status):
    source=window_record['conditioned_source']
    if source['schema'] != 'mhdlab-temkin-planar-source-windows-v1' or source['status'] != parameter_status:
        raise ValueError('conditioned-source schema/status association failed')
    if source['host_budget_accepted'] is not False:
        raise ValueError('unexpected accepted host budget')
    xedges=[number(value,'x edge') for value in source['x_edges_m']]
    zedges=[number(value,'z edge') for value in source['z_edges_m']]
    if any(b<=a for a,b in zip(xedges,xedges[1:])) or any(b<=a for a,b in zip(zedges,zedges[1:])):
        raise ValueError('source edges must remain ordered')
    width=xedges[-1]-xedges[0]
    length=zedges[-1]-zedges[0]
    if len(xedges)-1 != resolution['width_bins'] or len(zedges)-1 != resolution['current_bins']:
        raise ValueError('declared resolution changes source geometry')
    bins=[{'number':ZERO,'energy':ZERO,'components':0} for _ in xedges[:-1]]
    total=ZERO
    energy_total=ZERO
    ledger_density_number_residual=ZERO
    ledger_density_energy_residual=ZERO
    ledger_density_unavailable=[]
    temperature_energy_residual=ZERO
    exact_components=[]
    seen=set()
    for component_index,component in enumerate(source['components']):
        key=tuple(component[name] for name in ('selection_index','reservoir_index','current_index','width_index'))
        if key in seen:
            raise ValueError('duplicate retained component association')
        seen.add(key)
        xi,zi=component['width_index'],component['current_index']
        if component['x_bounds_m'] != source['x_edges_m'][xi:xi+2] or component['z_bounds_m'] != source['z_edges_m'][zi:zi+2]:
            raise ValueError('component geometry differs from original source patch')
        scalar=component['source_window']
        if scalar['status'] != source['status'] or scalar['provenance'] != source['provenance']:
            raise ValueError('component source labels differ from conditioned-source declaration')
        actual_area=(xedges[xi+1]-xedges[xi])*(zedges[zi+1]-zedges[zi])
        # Scalar areas are the original float64 product, retained separately
        # from exact geometry reductions and never applied twice to a count.
        declared_area=number(scalar['patch_area_m2'],'declared patch area',positive=True)
        expected_float_area=Fraction(float((float(xedges[xi+1])-float(xedges[xi]))*(float(zedges[zi+1])-float(zedges[zi]))))
        if declared_area != expected_float_area:
            raise ValueError('scalar patch area differs from original geometry product')
        count=extensive(scalar,'released_number')
        energy=extensive(scalar,'translational_energy_j')
        bins[xi]['number']+=count
        bins[xi]['energy']+=energy
        bins[xi]['components']+=1
        total+=count
        energy_total+=energy
        temperature=number(scalar['temperature_k'],'component temperature',positive=True)
        temperature_energy_residual+=energy-count*2*Fraction(KB)*temperature
        for quantity_name,extensive_value,target in (('released_m2',count,'number'),('translational_energy_j_m2',energy,'energy')):
            quantity=scalar['quantities'][quantity_name]
            if quantity['qualified'] and quantity['value'] is not None:
                residual=extensive_value-number(quantity['value'],quantity_name)*declared_area
                if target=='number': ledger_density_number_residual+=residual
                else: ledger_density_energy_residual+=residual
            else:
                ledger_density_unavailable.append({'component_index':component_index,'quantity':quantity_name,
                    'reason':quantity['reason'],'log_value':quantity['log_value']})
        exact_components.append({'component_index':component_index,'selection_index':component['selection_index'],
            'interval_index':component['interval_index'],'reservoir_index':component['reservoir_index'],
            'current_index':zi,'width_index':xi,'reservoir_name':scalar['reservoir']['name'],
            'state_id':scalar['reservoir']['state_id'],'released_number':exact_record(count),
            'translational_energy_j':exact_record(energy),'actual_geometry_area_m2':exact_record(actual_area),
            'declared_scalar_area_m2':float(declared_area),
            'area_rounding_residual_m2':exact_record(declared_area-actual_area)})
    rows=[]
    uniform_number_total=ZERO
    uniform_energy_total=ZERO
    resolved_count_density_rounding=ZERO
    resolved_energy_density_rounding=ZERO
    uniform_count_density_rounding=ZERO
    uniform_energy_density_rounding=ZERO
    resolved_density_values=[]
    resolved_energy_means=[]
    for index,bin_record in enumerate(bins):
        dx=xedges[index+1]-xedges[index]
        area=dx*length
        fraction=dx/width
        uniform_n=total*fraction
        uniform_e=energy_total*fraction
        uniform_number_total+=uniform_n
        uniform_energy_total+=uniform_e
        resolved_n=bin_record['number']
        resolved_e=bin_record['energy']
        densities=(resolved_n/area,resolved_e/area,uniform_n/area,uniform_e/area)
        n_density,e_density,un_density,ue_density=[represented(v,'width profile density') for v in densities]
        resolved_count_density_rounding+=Fraction(n_density)*area-resolved_n
        resolved_energy_density_rounding+=Fraction(e_density)*area-resolved_e
        uniform_count_density_rounding+=Fraction(un_density)*area-uniform_n
        uniform_energy_density_rounding+=Fraction(ue_density)*area-uniform_e
        resolved_mean=resolved_e/resolved_n if resolved_n else None
        uniform_mean=uniform_e/uniform_n if uniform_n else None
        row={'case_id':case_id,'snapshot_intervals':resolution['snapshot_intervals'],
            'window_index':window_record['window_index'],
            'window_start_s':window_record['window']['start_s'],'window_stop_s':window_record['window']['stop_s'],
            'width_index':index,'x_left_m':float(xedges[index]),'x_right_m':float(xedges[index+1]),
            'x_center_mm':represented(1000*(xedges[index]+xedges[index+1])/2,'x center'),
            'actual_width_bin_area_m2':represented(area,'bin area'),
            'retained_components':bin_record['components'],
            'resolved_released_number':represented(resolved_n,'resolved width count'),
            'matched_uniform_width_released_number':represented(uniform_n,'matched width count'),
            'resolved_released_areal_density_m2':n_density,
            'matched_uniform_width_released_areal_density_m2':un_density,
            'resolved_translational_energy_j':represented(resolved_e,'resolved width energy'),
            'matched_uniform_width_translational_energy_j':represented(uniform_e,'matched width energy'),
            'resolved_translational_energy_areal_density_j_m2':e_density,
            'matched_uniform_width_translational_energy_areal_density_j_m2':ue_density,
            'resolved_expected_translational_energy_per_parent_j':represented(resolved_mean,'resolved energy per parent') if resolved_mean is not None else None,
            'matched_uniform_width_expected_translational_energy_per_parent_j':represented(uniform_mean,'matched energy per parent') if uniform_mean is not None else None,
            'resolved_expected_translational_energy_per_parent_ev':represented(resolved_mean/Fraction(QE),'resolved energy eV') if resolved_mean is not None else None,
            'matched_uniform_width_expected_translational_energy_per_parent_ev':represented(uniform_mean/Fraction(QE),'matched energy eV') if uniform_mean is not None else None,
        }
        rows.append(row)
        resolved_density_values.append(resolved_n/area)
        if resolved_mean is not None: resolved_energy_means.append(resolved_mean)
    weighted_mean_density=total/(width*length)
    normalized_l1=sum((abs(bin_record['number']-total*(xedges[i+1]-xedges[i])/width)
                      for i,bin_record in enumerate(bins)),ZERO)/total if total else None
    density_ratio=max(resolved_density_values)/min(resolved_density_values) if resolved_density_values and min(resolved_density_values)>0 else None
    order_count_residuals=[]
    for estimate in window_record['estimates']:
        order_count_residuals.append({'quadrature_order':estimate['quadrature_order'],
            'component_sum_minus_joint_released_number':exact_record(total-number(estimate['resolved']['released_number'],'joint number')),
            'joint_resolved_minus_uniform_released_number':exact_record(number(estimate['resolved']['released_number'],'joint resolved number')-number(estimate['matched_uniform_width']['released_number'],'joint uniform number'))})
    summary={'case_id':case_id,'snapshot_intervals':resolution['snapshot_intervals'],
        'window_index':window_record['window_index'],'window':window_record['window'],
        'retained_components':len(exact_components),'released_number':represented(total,'total count'),
        'translational_energy_j':represented(energy_total,'total energy'),
        'mean_released_areal_density_m2':represented(weighted_mean_density,'mean source density'),
        'resolved_min_released_areal_density_m2':represented(min(resolved_density_values),'minimum density'),
        'resolved_max_released_areal_density_m2':represented(max(resolved_density_values),'maximum density'),
        'resolved_max_to_min_density_ratio':represented(density_ratio,'density ratio') if density_ratio is not None else None,
        'resolved_vs_uniform_count_l1_fraction':represented(normalized_l1,'profile L1') if normalized_l1 is not None else None,
        'resolved_min_expected_translation_ev':represented(min(resolved_energy_means)/Fraction(QE),'minimum energy') if resolved_energy_means else None,
        'resolved_max_expected_translation_ev':represented(max(resolved_energy_means)/Fraction(QE),'maximum energy') if resolved_energy_means else None,
        'matched_uniform_width_expected_translation_ev':represented(energy_total/total/Fraction(QE),'uniform expected energy') if total else None,
        'closure':{
            'matched_uniform_width_minus_resolved_number':exact_record(uniform_number_total-total),
            'matched_uniform_width_minus_resolved_energy_j':exact_record(uniform_energy_total-energy_total),
            'resolved_displayed_areal_density_integral_minus_count':exact_record(resolved_count_density_rounding),
            'resolved_displayed_energy_density_integral_minus_energy_j':exact_record(resolved_energy_density_rounding),
            'uniform_displayed_areal_density_integral_minus_count':exact_record(uniform_count_density_rounding),
            'uniform_displayed_energy_density_integral_minus_energy_j':exact_record(uniform_energy_density_rounding),
            'qualified_scalar_extensive_minus_areal_times_declared_area_number':exact_record(ledger_density_number_residual),
            'qualified_scalar_extensive_minus_areal_times_declared_area_energy_j':exact_record(ledger_density_energy_residual),
            'scalar_density_unavailable_components':ledger_density_unavailable,
            'source_energy_minus_represented_count_times_2kbT_j':exact_record(temperature_energy_residual),
            'moment_order_count_associations':order_count_residuals,
        },'components':exact_components}
    return rows,summary


def make_figure(rows,case_records,path):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    import numpy as np
    windows=sorted({row['window_index'] for row in rows})
    figure,axes=plt.subplots(2,len(windows),figsize=(max(6.2,4.8*len(windows)),6.7),squeeze=False)
    cases=sorted(case_records,key=lambda item:item['resolution']['snapshot_intervals'])
    colors=plt.get_cmap('viridis')(np.linspace(.08,.85,len(cases)))
    handles=[]
    for col,window_index in enumerate(windows):
        for color,case in zip(colors,cases):
            selected=[row for row in rows if row['case_id']==case['case_id'] and row['window_index']==window_index]
            selected.sort(key=lambda row:row['width_index'])
            centers=[row['x_center_mm'] for row in selected]
            label=str(case['resolution']['snapshot_intervals'])+' snapshot intervals'
            line,=axes[0,col].plot(centers,[row['resolved_released_areal_density_m2'] for row in selected],color=color,lw=1.8,label=label)
            axes[0,col].plot(centers,[row['matched_uniform_width_released_areal_density_m2'] for row in selected],color=color,lw=1.1,ls=':')
            axes[1,col].plot(centers,[row['resolved_expected_translational_energy_per_parent_ev'] for row in selected],color=color,lw=1.8)
            axes[1,col].plot(centers,[row['matched_uniform_width_expected_translational_energy_per_parent_ev'] for row in selected],color=color,lw=1.1,ls=':')
            if col==0: handles.append(line)
        first=next(row for row in rows if row['window_index']==window_index)
        interval=f"{first['window_start_s']*1e9:g}–{first['window_stop_s']*1e9:g} ns"
        axes[0,col].set_title('Manufactured source release\n'+interval,fontsize=10)
        axes[1,col].set_title('Manufactured outgoing translation\n'+interval,fontsize=10)
        for axis in axes[:,col]:
            axis.set_xlabel('Foil width position (mm)')
            axis.grid(alpha=.22)
        axes[0,col].set_ylabel('Released areal density (parent m$^{-2}$)')
        axes[0,col].ticklabel_format(axis='y',style='sci',scilimits=(0,0))
        axes[1,col].set_ylabel('Expected translation per parent (eV)')
    figure.suptitle('Manufactured conditional source profiles',fontsize=14,y=.99)
    figure.text(.5,.935,'Solid: original width distribution   ···   Dotted: matched uniform width',ha='center',fontsize=10)
    figure.legend(handles=handles,loc='lower center',ncol=min(4,len(handles)),frameon=False,bbox_to_anchor=(.5,.005))
    figure.subplots_adjust(top=.83,bottom=.17,hspace=.52,wspace=.35)
    figure.savefig(path/'source_width_profiles.png',dpi=180,metadata={'Software':''})
    figure.savefig(path/'source_width_profiles.pdf',metadata={'Creator':'','Producer':'','CreationDate':None,'ModDate':None})
    plt.close(figure)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--study',type=Path,default=DEFAULT_STUDY)
    parser.add_argument('--output-dir',type=Path,default=HERE/'artifacts')
    args=parser.parse_args()
    output=args.output_dir.resolve()
    if not output.is_relative_to(HERE) or output==HERE or args.output_dir.exists() or args.output_dir.is_symlink():
        parser.error('output must be a new directory below profile-reduction')
    report_path=args.study/'report.json'
    report=read_json(report_path)
    if report['schema']!='mhdlab-windowed-source-resolution-report-v1' or report['parameter_status']!='manufactured':
        parser.error('only the completed manufactured resolution-study report is supported')
    if report['source_evolution_repeated'] is not False:
        parser.error('study did not retain the preserved-evolution association')
    input_hashes={str(report_path.resolve()):sha(report_path)}
    for name,digest in report['output_sha256'].items():
        if Path(name).name!=name:
            raise ValueError('study output key is not a plain filename')
        path=args.study/name
        if path.is_symlink() or not path.is_file() or sha(path)!=digest:
            raise ValueError('study output hash association failed: '+name)
        input_hashes[str(path.resolve())]=digest
    if sha(args.study/'input_config.json')!=report['input_config_sha256']:
        raise ValueError('study config association failed')
    rows=[]
    summaries=[]
    width_controls=[]
    case_records=[]
    for case in report['cases']:
        case_path=args.study/('case_'+case['case_id']+'.json')
        if case_path.name not in report['output_sha256']:
            raise ValueError('case file lacks a study output association')
        stored=read_json(case_path)
        evidence=read_json(args.study/('evidence_'+case['case_id']+'.json'))
        resolution=evidence['resolution']
        if (sha(args.study/('source_'+case['case_id']+'.h5')) != case['source_sha256']
                or sha(args.study/('evidence_'+case['case_id']+'.json')) != case['evidence_sha256']):
            raise ValueError('copied source/evidence differs from declared original case input')
        if evidence['source_sha256']!=case['source_sha256'] or evidence['parameter_status']!='manufactured':
            raise ValueError('preserved case evidence association failed')
        if evidence['source_evolution_repeated'] is not False:
            raise ValueError('source evidence does not retain the no-evolution declaration')
        case_records.append({'case_id':case['case_id'],'resolution':resolution,'source_sha256':case['source_sha256'],
                             'evidence_sha256':case['evidence_sha256']})
        for window in stored['windows']:
            if window['conditioned_source']['parameter_provenance'] != evidence['parameter_provenance']:
                raise ValueError('conditioned source changes original parameter provenance')
            r,s=reduce_window(case['case_id'],resolution,window,parameter_status=report['parameter_status'])
            rows.extend(r)
            summaries.append(s)
            width_controls.extend(paired_width_controls(case['case_id'],window))
    source_changes=[]
    for comparison in report['source_comparisons']:
        for difference in comparison['differences']:
            for hypothesis,metrics in difference['estimate_minus_reference'].items():
                for name,value in metrics.items():
                    source_changes.append({'estimate_case_id':comparison['estimate_case_id'],
                        'reference_case_id':comparison['reference_case_id'],'family':comparison['family'],
                        'window_index':difference['window_index'],'quadrature_order':difference['quadrature_order'],
                        'hypothesis':hypothesis,'observable':name,**value})
    quadrature_changes=[]
    for case in report['cases']:
        stored=read_json(args.study/('case_'+case['case_id']+'.json'))
        for window in stored['windows']:
            for change in window['quadrature_changes']:
                for hypothesis,metrics in change['refined_minus_coarse'].items():
                    for name,value in metrics.items():
                        quadrature_changes.append({'case_id':case['case_id'],'window_index':window['window_index'],
                            'coarse_order':change['coarse_order'],'refined_order':change['refined_order'],
                            'hypothesis':hypothesis,'observable':name,**value})
    case_levels={case['case_id']:case['resolution']['snapshot_intervals'] for case in case_records}
    release_refinement_summary=[{**change,
        'estimate_snapshot_intervals':case_levels[change['estimate_case_id']],
        'reference_snapshot_intervals':case_levels[change['reference_case_id']]}
        for change in source_changes if change['observable']=='released_number'
        and change['hypothesis']=='resolved' and change['quadrature_order']==max(report['orders'])]
    reduction={'schema':'mitl-manufactured-window-source-profiles-v1','parameter_status':'manufactured',
        'input_study_report':str(report_path.resolve()),'input_files_sha256':input_hashes,
        'input_study_source_sha256':report['source_sha256'],'profile_script_sha256':sha(__file__),
        'runtime':{'python':sys.version,**{name:importlib.metadata.version(name) for name in ('matplotlib','numpy')}},
        'source_evolution_repeated':False,'source_or_moment_routines_called':False,
        'orders':report['orders'],'windows':report['windows'],'cases':case_records,'profiles':summaries,
        'release_refinement_summary':release_refinement_summary,
        'highest_order_paired_width_controls':width_controls,
        'source_resolution_differences':source_changes,'quadrature_changes':quadrature_changes,
        'definitions':{'release_density':'window-integrated represented extensive count divided once by physical width-bin area dx times full original current length',
            'conditional_expected_translation':'sum of individually qualified extensive translational source energies divided by sum of represented released parent counts',
            'matched_uniform_width':'each original time/current/reservoir/state/temperature component contributes its exact count and source energy multiplied by dx/full_width; no other mixture coordinate changes',
            'signed_residual':'displayed value minus its declared comparison target; no forced closure repair',
            'source_vs_quadrature':'width profiles use conditioned extensive source manifests without quadrature; stored moment refinement changes are copied as a separate evidence family'},
        'limits':['All thermal, kinetic, inventory and energy inputs are manufactured; these are source controls, not a physical water or foil calibration.',
            'Source-emission windows are distinct from photon observation gates.',
            'No spectra, chemistry, molecular daughters, transport, trajectories or host-budget acceptance are calculated.',
            'The outgoing energy is a conditional expectation, not a species velocity realization or an internal/rotational/vibrational energy allocation.',
            'Counts and expected source energies are summed exactly as represented; the original source calculation and its numerical errors are preserved.',
            'Resolution and quadrature differences are finite numerical changes, not certified error bars or experimental uncertainty.']}
    reduction['definitions']['paired_width_controls']='highest stored moment order; exact represented resolved-minus-uniform differences. Symmetric heating can suppress mean-x and time-x covariance while leaving face-centered x-squared signatures. Width-sensitive descriptors are numerical source effects, not spectral or statistical distinguishability claims.'
    args.output_dir.parent.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='.profile-reduction-',dir=args.output_dir.parent) as temporary:
        stage=Path(temporary)/'result'
        stage.mkdir()
        write_csv(stage/'width_profiles.csv',rows,list(rows[0]))
        width_control_csv=[{key:(value['value'] if isinstance(value,dict) and 'value' in value else value)
            for key,value in record.items()} for record in width_controls]
        write_csv(stage/'paired_width_controls.csv',width_control_csv,list(width_control_csv[0]))
        # Long-form metric tables retain availability/reason information and
        # never replace a missing normalized moment with zero.
        for filename,data in (('source_resolution_differences.csv',source_changes),('quadrature_changes.csv',quadrature_changes)):
            fields=[]
            for row in data:
                for key in row:
                    if key not in fields: fields.append(key)
            write_csv(stage/filename,data,fields)
        make_figure(rows,case_records,stage)
        if any(sha(Path(path))!=digest for path,digest in input_hashes.items()):
            raise ValueError('study input changed during profile reduction')
        reduction['output_sha256']={p.name:sha(p) for p in stage.iterdir() if p.is_file()}
        (stage/'report.json').write_text(json.dumps(reduction,indent=2,allow_nan=False)+'\n')
        if args.output_dir.exists() or args.output_dir.is_symlink():
            raise ValueError('output appeared during profile reduction')
        os.rename(stage,args.output_dir)
    print(json.dumps({'output_dir':str(args.output_dir),'rows':len(rows),'case_windows':len(summaries),
        'report_sha256':sha(args.output_dir/'report.json'),'source_evolution_repeated':False},indent=2))

if __name__=='__main__':
    main()
