# Calibration evidence and coverage regression subset

Use Python3.11 or newer and install requirements. Public files are byte-identical
to the pinned commit. This README, minimal initializer, requirements and pytest
settings are extraction wrappers.

```sh
python -m pytest -q -W error
python tools/fit_surface_coverage.py --config configs/coverage_regression_manufactured.json --output-dir /tmp/coverage-fit --plot
```

The example uses arbitrary supplied count templates, covariance, calibration
constraint and monolayer convention. It infers no physical water coverage.
Externally supplied forward predictions replace the fixture; no transport,
chemistry or emission solver is included.

The recovered calibration figures retain their literal ambiguous units and
correlated display geometry. They are not an installed response or raw detector
counts. PDF recovery needs optional PyMuPDF and the exact external dissertation
identified by hash. Source-pixel QA and original source documents are excluded.
Without that cache the exact-source integration check skips. The current
workspace source-integrity integration was checked separately before extraction.

Work-only example/oracle scripts in ../evidence retain their recorded workspace
paths. Read the main handoff and guides for calibration, covariance and monolayer
qualifications. No actual FLASH or production host is run.
