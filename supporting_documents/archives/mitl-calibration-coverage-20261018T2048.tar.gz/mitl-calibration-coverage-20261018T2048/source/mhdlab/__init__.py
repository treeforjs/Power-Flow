"""Independent calibration and supplied-grid coverage interfaces."""
