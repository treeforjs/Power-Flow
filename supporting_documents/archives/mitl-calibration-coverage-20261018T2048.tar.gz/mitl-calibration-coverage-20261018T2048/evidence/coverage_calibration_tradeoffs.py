"""Manufactured coverage/calibration tradeoffs using supplied numerical grids."""
from dataclasses import fields
import hashlib
import json
from pathlib import Path
import sys

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

REPO = Path('/workspace/Power-Flow')
sys.path.insert(0, str(REPO))
from mhdlab.coverage_regression import BinnedObservation, CalibrationScale, CoveragePredictionGrid, fit_surface_coverage

WORK = Path(__file__).parent
CONFIG = REPO / 'configs/coverage_regression_manufactured.json'
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
out = WORK / 'coverage-calibration-tradeoffs'
assert not out.exists()
config = json.loads(CONFIG.read_text())
grid = CoveragePredictionGrid(**config['grid'])
observation = BinnedObservation(**config['observation'])
truth = config['manufactured_truth']
cases = {}
for name, calibration in [
    ('shape_grid_declared_calibration', CalibrationScale(**config['calibration'])),
    ('shape_grid_wrong_fixed_scale', CalibrationScale('fixed', fixed_scale=1., provenance='Manufactured deliberately offset reference scale.')),
    ('shape_grid_free_scale', CalibrationScale('free', provenance='Manufactured unconstrained scale.')),
]:
    cases[name] = fit_surface_coverage(grid, observation, calibration)
args = {field.name: getattr(grid, field.name) for field in fields(grid)}
coverage = np.asarray([.25, .5, 1., 2., 4.])
template = np.asarray([10., 16., 13., 4.])
args.update(coverage_ml=coverage, predictions=coverage[:, None] * template[None, :],
            provenance='Manufactured amplitude-only count templates; no physical spectrum or source calculation.')
amplitude_grid = CoveragePredictionGrid(**args)
args = {field.name: getattr(observation, field.name) for field in fields(observation) if field.init}
args.update(values=truth['coverage_ml'] * truth['calibration_scale'] * template + observation.known_background,
            provenance='Manufactured amplitude-only observation with fixed product coverage times calibration scale.')
amplitude_observation = BinnedObservation(**args)
for name, calibration in [
    ('amplitude_grid_free_scale', CalibrationScale('free', provenance='Manufactured unconstrained scale.')),
    ('amplitude_grid_declared_calibration', CalibrationScale(**config['calibration'])),
    ('amplitude_grid_wrong_fixed_scale', CalibrationScale('fixed', fixed_scale=1., provenance='Manufactured deliberately offset reference scale.')),
]:
    cases[name] = fit_surface_coverage(amplitude_grid, amplitude_observation, calibration)
assert cases['amplitude_grid_free_scale']['diagnostics']['coverage_amplitude_degeneracy']
assert cases['amplitude_grid_free_scale']['diagnostics']['coverage_unconstrained']
assert abs(cases['amplitude_grid_wrong_fixed_scale']['best_fit']['coverage_ml'] - 1.568) < 2e-13
assert abs(cases['shape_grid_declared_calibration']['best_fit']['coverage_ml'] - 1.4) < 2e-13
assert abs(cases['shape_grid_free_scale']['best_fit']['coverage_ml'] - 1.4) < 2e-13
fig, axes = plt.subplots(1, 2, figsize=(11, 4.6), constrained_layout=True)
for name, label in [
    ('shape_grid_declared_calibration', 'Supplied calibration constraint'),
    ('shape_grid_wrong_fixed_scale', 'Deliberately offset fixed scale'),
    ('shape_grid_free_scale', 'Free scale, supplied shape changes'),
]:
    fit = cases[name]['best_fit']
    axes[0].plot(.5 * (grid.bin_edges[:-1] + grid.bin_edges[1:]), fit['prediction_with_background'], 'o-', label=f'{label}: {fit["coverage_ml"]:.4g} ML')
axes[0].plot(.5 * (grid.bin_edges[:-1] + grid.bin_edges[1:]), observation.values, 'k+', markersize=10, label='Manufactured observations')
axes[0].set(xlabel='Manufactured detector-bin coordinate [nm]', ylabel='ADU per detector bin', title='Calibration choice changes inferred coverage')
axes[0].legend(fontsize=7)
theta = np.linspace(.25, 4., 220)
scale = np.linspace(.35, 3., 210)
factor = np.linalg.solve(np.linalg.cholesky(observation.covariance), template)
delta = theta[None, :] * scale[:, None] - truth['coverage_ml'] * truth['calibration_scale']
cost = delta ** 2 * np.dot(factor, factor)
image = axes[1].pcolormesh(theta, scale, np.log10(1 + cost), shading='auto', cmap='viridis')
axes[1].plot(theta, truth['coverage_ml'] * truth['calibration_scale'] / theta, 'w--', linewidth=1.3, label='Same amplitude product')
axes[1].plot([truth['coverage_ml']], [truth['calibration_scale']], 'r*', markersize=10, label='Manufactured truth')
axes[1].set(xlim=(theta[0], theta[-1]), ylim=(scale[0], scale[-1]), xlabel='Coverage [manufactured ML]', ylabel='Absolute scale', title='Amplitude-only data retain a coverage/scale ridge')
axes[1].legend(fontsize=7)
fig.colorbar(image, ax=axes[1], label='log₁₀(1 + data objective)')
fig.suptitle('Numerical coverage regression controls; no physical water-coverage inference')
out.mkdir()
figure = out / 'coverage_calibration_tradeoffs.png'
fig.savefig(figure, dpi=165)
plt.close(fig)
result = {
    'schema': 'mhdlab-manufactured-coverage-calibration-tradeoffs-v1', 'parameter_status': 'manufactured',
    'config_sha256': sha(CONFIG), 'script_sha256': sha(__file__),
    'source_sha256': {'mhdlab/coverage_regression.py': sha(REPO / 'mhdlab/coverage_regression.py')},
    'truth_not_supplied_to_optimizer': truth,
    'amplitude_grid': {'coverage_ml': coverage.tolist(), 'predictions': amplitude_grid.predictions.tolist(),
                       'observations': amplitude_observation.values.tolist()},
    'cases': cases,
    'wrong_fixed_scale_amplitude_coverage_relative_error': cases['amplitude_grid_wrong_fixed_scale']['best_fit']['coverage_ml'] / truth['coverage_ml'] - 1,
    'output_sha256': {figure.name: sha(figure)},
    'limits': ['Arbitrary supplied numerical detector-bin grids and a manufactured monolayer convention only.',
               'A calibration constraint contributes independent information; it does not make amplitude-only data identify both coverage and scale.',
               'The deliberate scale error is illustrative, not an estimated dissertation correction.',
               'No molecular states, reaction model, transport, radiation or physical spectra are calculated.'],
}
report = out / 'report.json'
report.write_text(json.dumps(result, indent=2, allow_nan=False) + '\n')
print(json.dumps({'output': str(out), 'report_sha256': sha(report),
                  'best_fits': {name: {'coverage_ml': value['best_fit']['coverage_ml'], 'scale': value['best_fit']['calibration_scale'],
                                      'coverage_unconstrained': value['diagnostics']['coverage_unconstrained']} for name, value in cases.items()}}, indent=2))
