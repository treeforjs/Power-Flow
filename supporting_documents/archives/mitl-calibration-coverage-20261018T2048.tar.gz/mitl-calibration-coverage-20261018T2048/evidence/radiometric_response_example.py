"""Exercise explicit manufactured measurement units without source calibration."""
import hashlib
import json
from pathlib import Path
import sys

import numpy as np

repo = Path('/workspace/Power-Flow')
sys.path.insert(0, str(repo))
from mhdlab.radiometric_response import RadiometricResponse

work = Path(__file__).parent
out = work / 'radiometric-response-example'
assert not out.exists()
condition = 'manufactured-camera-gain-and-effective-gate-condition'
response = RadiometricResponse(
    [120., 121., 123.], 2e-8, 3e-9, [2., 4.],
    reference_plane='Manufactured radiance-reference plane before the supplied response product',
    included_factors=('manufactured_optical_efficiency_times_camera_gain_at_matching_gate_condition',),
    status='manufactured', provenance='Numerical unit/covariance example; no instrument calibration.',
    measurement_conditions_id=condition, response_includes_exposure=False,
    response_includes_etendue=False, response_includes_bin_width=False)
covariance = np.asarray([[100., 40.], [40., 200.]])
background = np.asarray([10., 20.])
records = {}
for kind, values in [('photon_spectral_radiance', [1e20, 2e20]),
                     ('energy_spectral_radiance', [100., 200.])]:
    counts = response.counts_from_radiance(values, radiance_kind=kind, measurement_conditions_id=condition)
    raw_counts = counts + background
    restored = response.calibrate_counts(raw_counts - background, covariance, radiance_kind=kind,
                                        measurement_conditions_id=condition)
    assert np.allclose(restored.radiance, values, rtol=3e-15, atol=0)
    factors = response.conversion_factors(kind)
    expected_covariance = covariance / factors[:, None] / factors[None, :]
    assert np.allclose(restored.covariance, expected_covariance, rtol=3e-15, atol=0)
    records[kind] = {'supplied_constant_bin_mean_radiance': values,
                     'conversion_factors_counts_per_radiance': factors.tolist(),
                     'signal_counts': counts.tolist(), 'raw_counts_with_known_background': raw_counts.tolist(),
                     'calibrated_radiance': restored.radiance.tolist(),
                     'calibrated_covariance': restored.covariance.tolist(), 'metadata': restored.metadata}
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
out.mkdir()
record = {'schema': 'mhdlab-manufactured-radiometric-response-example-v1', 'parameter_status': 'manufactured',
          'script_sha256': sha(__file__), 'source_sha256': {'mhdlab/radiometric_response.py': sha(repo / 'mhdlab/radiometric_response.py')},
          'count_covariance_adu2': covariance.tolist(), 'known_background_adu': background.tolist(), 'cases': records,
          'limits': ['The two radiance kinds are separate manufactured constant-bin models, not simultaneous spectral descriptions of one physical source.',
                     'Response, reference plane, exposure, etendue and conditions are illustrative inputs; no dissertation calibration factor is inferred.',
                     'Supplied covariance includes no inferred Poisson, response or calibration uncertainty.',
                     'No emission, molecular population, transport or radiative solver is called.']}
path = out / 'report.json'
path.write_text(json.dumps(record, indent=2, allow_nan=False) + '\n')
print(json.dumps({'output': str(path), 'sha256': sha(path), 'cases': len(records)}, indent=2))
