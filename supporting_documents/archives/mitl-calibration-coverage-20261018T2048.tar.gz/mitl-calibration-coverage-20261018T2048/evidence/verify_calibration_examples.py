"""Associate completed calibration/inference examples with frozen public bytes."""
import hashlib
import json
from pathlib import Path

repo = Path('/workspace/Power-Flow')
work = Path(__file__).parent
sha = lambda path: hashlib.sha256(Path(path).read_bytes()).hexdigest()
records = {}
for directory, filename in [('coverage-fit-example', 'fit_report.json'),
                            ('coverage-calibration-tradeoffs', 'report.json'),
                            ('radiometric-response-example', 'report.json')]:
    path = work / directory
    record = json.loads((path / filename).read_text())
    for name, digest in record['source_sha256'].items():
        assert sha(repo / name) == digest, (directory, name)
    for name, digest in record.get('output_sha256', {}).items():
        assert sha(path / name) == digest, (directory, name)
    if 'script_sha256' in record:
        script = {'coverage-calibration-tradeoffs': 'coverage_calibration_tradeoffs.py',
                  'radiometric-response-example': 'radiometric_response_example.py'}[directory]
        assert sha(work / script) == record['script_sha256']
    records[directory] = {'report': str(path / filename), 'sha256': sha(path / filename)}
completion = json.loads((work / 'calibration-recovery/completion.json').read_text())
for item in completion['frozen_repository_artifacts']:
    assert sha(item['path']) == item['sha256'], item['path']
fit = json.loads((work / 'coverage-fit-example/fit_report.json').read_text())
assert fit['fit']['best_fit']['coverage_ml'] == 1.4
assert fit['fit']['best_fit']['calibration_scale'] == 1.12
assert fit['input_labels']['prediction_status'] == fit['input_labels']['observation_status'] == 'manufactured'
assert fit['input_config_sha256'] == sha(repo / 'configs/coverage_regression_manufactured.json')
for name in ('figure_4_18_calibration', 'figure_4_19_gain'):
    sidecar = json.loads((repo / 'data/dissertation' / (name + '.json')).read_text())
    assert sidecar['output']['csv_sha256'] == sha(repo / 'data/dissertation' / (name + '.csv'))
    assert sidecar['observable']['literal_ordinate_unit'] == 'µW/(sr·nm·mm)'
    assert not sidecar['observable']['absolute_factor_resolved']
    assert not sidecar['observable']['SI_radiance_conversion_applied']
result = {'schema': 'mitl-calibration-examples-association-v1', 'script_sha256': sha(__file__),
          'examples': records, 'calibration_completion_sha256': sha(work / 'calibration-recovery/completion.json'),
          'absolute_factor_resolved': False, 'sampling_or_fitting_repeated': False,
          'source_pixel_QA_not_for_delivery': completion['source_pixel_QA']}
output = work / 'example_associations.json'
assert not output.exists()
output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'output': str(output), 'sha256': sha(output), 'examples': len(records)}, indent=2))
