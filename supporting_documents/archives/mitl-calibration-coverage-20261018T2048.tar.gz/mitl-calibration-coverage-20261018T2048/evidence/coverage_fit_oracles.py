"""Independent analytic and joint-optimization coverage-fit comparisons."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import platform
import sys

import numpy as np
import scipy
from scipy.optimize import least_squares

REPO = Path('/workspace/Power-Flow')
sys.path.insert(0, str(REPO))
from mhdlab.coverage_regression import (
    BinnedObservation, CalibrationScale, CoveragePredictionGrid, fit_surface_coverage,
)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    work = Path(__file__).resolve().parent
    output = work / 'coverage_fit_oracles.json'
    if output.exists():
        raise ValueError('Refusing to overwrite independent oracle evidence')
    coverage = np.array([.2, .8, 1.7, 3.2, 5.])
    predictions = np.column_stack((1. + .4 * coverage, .5 + coverage**2 / 3.,
                                   2. + 1.5 / (1. + coverage)))
    background = np.array([.4, .8, .1])
    response = lambda c: np.array([np.interp(c, coverage, column) for column in predictions.T])
    values = 1.1 * response(2.1) + np.array([.3, -.4, .2]) + background
    covariance = np.array([[.36, .12, -.06], [.12, .25, .05], [-.06, .05, .49]])
    shared = dict(signal_units='manufactured_signal', bin_edges=[0., 1., 2., 3.],
                  bin_axis_units='manufactured_bin_coordinate', bin_support='fixed manufactured bins',
                  status='manufactured', provenance='Explicit manufactured external-response oracle')
    table = CoveragePredictionGrid(coverage, predictions, monolayer_areal_density_m2=2.75e18,
                                   monolayer_definition='Explicit manufactured 2.75e18 particles/m2 convention',
                                   monolayer_provenance='Manufactured convention, no kinetic Nref conversion', **shared)
    data = BinnedObservation(values, covariance, background, **shared)
    scale = CalibrationScale('gaussian_prior', prior_mean=.9, prior_sigma=.2,
                             provenance='Explicit manufactured Gaussian calibration nuisance prior')
    chol = np.linalg.cholesky(covariance)
    target = values - background

    def residual(parameters):
        c, a = parameters
        return np.r_[np.linalg.solve(chol, target - a * response(c)), (a - .9) / .2]

    candidates = []
    for left, right in zip(coverage[:-1], coverage[1:]):
        for initial_scale in (.05, 1., 3.):
            fitted = least_squares(residual, [(left + right) / 2., initial_scale],
                                   bounds=([left, 0.], [right, np.inf]),
                                   ftol=1e-13, xtol=1e-13, gtol=1e-13, max_nfev=1000)
            if not fitted.success:
                raise ValueError(f'Independent optimizer failed: {fitted.message}')
            candidates.append({'segment': [float(left), float(right)], 'initial_scale': initial_scale,
                               'coverage_ml': float(fitted.x[0]), 'calibration_scale': float(fitted.x[1]),
                               'chi2': float(fitted.fun @ fitted.fun), 'optimality': float(fitted.optimality)})
    oracle = min(candidates, key=lambda record: record['chi2'])
    result = fit_surface_coverage(table, data, scale)
    best = result['best_fit']
    for name, tolerance in [('coverage_ml', 3e-7), ('calibration_scale', 3e-7), ('chi2', 3e-12)]:
        if not np.isclose(best[name], oracle[name], rtol=tolerance, atol=0.):
            raise ValueError(f'{name} disagrees: {best[name]} vs {oracle[name]}')
    analytic_profile = []
    for c, model in zip(coverage, predictions):
        wm = np.linalg.solve(covariance, model)
        a = max(0., (wm @ target + .9 / .2**2) / (model @ wm + 1. / .2**2))
        error = target - a * model
        analytic_profile.append({'coverage_ml': float(c), 'calibration_scale': float(a),
                                 'chi2': float(error @ np.linalg.solve(covariance, error) + ((a-.9)/.2)**2)})
    for index, point in enumerate(analytic_profile):
        for name in ('calibration_scale', 'chi2'):
            if not np.isclose(result['grid_profile'][name][index], point[name], rtol=3e-13, atol=0.):
                raise ValueError(f'Analytic knot profile mismatch: {name}')
    record = {
        'schema': 'mhdlab-coverage-fit-independent-oracles-v1', 'parameter_status': 'manufactured',
        'inputs': {'coverage_ml': coverage.tolist(), 'predictions': predictions.tolist(), 'values': values.tolist(),
                   'known_background': background.tolist(), 'covariance': covariance.tolist(),
                   'prior_mean': .9, 'prior_sigma': .2, 'monolayer_areal_density_m2': 2.75e18},
        'independent_joint_optimizer': {'method': 'scipy.optimize.least_squares with Cholesky-whitened residuals; every supplied coverage segment and three starts',
                                        'best': oracle, 'candidates': candidates},
        'independent_analytic_knot_profile': analytic_profile, 'implementation_best_fit': best,
        'hashes': {'script_sha256': sha(__file__), 'core_sha256': sha(REPO/'mhdlab/coverage_regression.py'),
                   'tests_sha256': sha(REPO/'tests/test_coverage_regression.py')},
        'runtime': {'python': platform.python_version(), 'numpy': np.__version__, 'scipy': scipy.__version__},
        'qualifications': ['Manufactured external responses only; no spectral generation or physical water parameters.',
                           'Gaussian nuisance prior is manufactured; no dissertation calibration uncertainty inferred.',
                           'Numerical optimization checks the finite piecewise-linear response grid, not unprovided coverage physics.'],
    }
    output.write_text(json.dumps(record, indent=2, allow_nan=False) + '\n')
    print(json.dumps({'output': str(output), 'sha256': sha(output), 'oracle': oracle,
                      'implementation_best_fit': best}, indent=2, allow_nan=False))


if __name__ == '__main__':
    main()
