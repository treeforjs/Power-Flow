# Upstream release and Hall reference subset

This extraction is pinned to the public project commit in the parent handoff.
Its initializer intentionally imports no legacy runner. The source modules,
configuration, tests, data manifests and reference documents are byte-identical
to that commit; the initializer, this guide and packaging files are extraction
wrappers. No native host registration is included.

With Python 3.11 or newer, install requirements in a local environment and run:

```sh
python -m pytest -q -W error
python tools/run_temkin_release.py --demo --constant-barrier-control --plot --output-dir runs/temkin_demo
python tools/run_hall_induction_benchmark.py --plot --output-dir runs/hall_reference
```

Both demonstrations use manufactured inputs. The Temkin file cannot feed the
ordinary first-order packet sampler; a law-specific temporal adapter remains
future work. The Hall case prescribes stationary ions and qualifies its
induction subsystem only. The material-source files are evidence manifests,
not adopted material tables. Refer to docs/coverage_dependent_release.md,
docs/hall_induction_verification.md and docs/ss304_property_sources.md for scope.
The historical audit also references files in the complete public repository.
