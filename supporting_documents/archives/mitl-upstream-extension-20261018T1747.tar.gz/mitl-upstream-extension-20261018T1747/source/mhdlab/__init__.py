"""Independent heating and boundary-source reference modules."""
