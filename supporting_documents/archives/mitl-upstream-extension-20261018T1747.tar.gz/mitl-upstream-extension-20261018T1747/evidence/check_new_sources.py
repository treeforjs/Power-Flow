import hashlib,json,pathlib,re
import fitz
root=pathlib.Path('/workspace/Power-Flow')
p=root/'data/materials/ss304_source_manifest.json'
manifest=json.loads(p.read_text()); checks=[]
def visit(v):
 if isinstance(v,dict):
  if 'cache_path' in v and 'sha256' in v:
   path=pathlib.Path(v['cache_path']);data=path.read_bytes()
   assert hashlib.sha256(data).hexdigest()==v['sha256'],path
   if 'bytes' in v:assert len(data)==v['bytes'],path
   entry={'path':str(path),'sha256':v['sha256'],'bytes':len(data)}
   if v.get('kind')=='pdf':
    assert data[:5]==b'%PDF-',path
    with fitz.open(path) as doc:
     entry['pdf_pages']=len(doc)
     if 'pdf_pages' in v: assert len(doc)==v['pdf_pages'],path
   checks.append(entry)
  for x in v.values():visit(x)
 elif isinstance(v,list):
  for x in v:visit(x)
visit(manifest)
assert len(manifest['sources'])==8
assert len(checks)==10
for name in ['docs/coverage_dependent_release.md','docs/hall_induction_verification.md','docs/ss304_property_sources.md']:
 path=root/name
 for target in re.findall(r'\]\(([^)]+)\)',path.read_text()):
  if target.startswith(('https:','http:','#')):continue
  assert (path.parent/target.split('#')[0]).resolve().exists(),(path,target)
print(json.dumps({'sources':len(manifest['sources']),'artifact_checks':checks,'relative_document_links':'passed'},indent=2))
