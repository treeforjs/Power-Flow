import hashlib,json,pathlib,sys
sys.path.insert(0,"/workspace/Power-Flow")
from mhdlab.temkin_io import load_temkin_history
repo=pathlib.Path('/workspace/Power-Flow');out=pathlib.Path('/workspace/handoffs/mitl-upstream-extension-20261018T1747')
checks={}
for name in ['temkin_manufactured','hall_reference']:
 p=out/'evidence'/name;s=json.loads((p/'summary.json').read_text())
 for key,digest in s['source_sha256'].items():
  assert hashlib.sha256((repo/key).read_bytes()).hexdigest()==digest,(name,key)
  assert hashlib.sha256((out/'source'/key).read_bytes()).hexdigest()==digest,(name,key)
 for key,digest in s['output_sha256'].items():assert hashlib.sha256((p/key).read_bytes()).hexdigest()==digest,(name,key)
 checks[name]={'source_hashes':'passed','output_hashes':'passed'}
h=load_temkin_history(out/'evidence/temkin_manufactured/temkin_release.h5')
checks['temkin_metrics']={'intervals':len(h.time_edges_s)-1,'width_bins':len(h.x_edges_m)-1,'max_abs_inversion_log_time_residual':float(abs(h.inversion_log_time_residual).max()),'max_abs_inventory_balance_residual_m2':float(abs(h.inventory_balance_residual_m2).max())}
listing=json.loads((out/'source_file_list.json').read_text())
for name in listing['byte_identical_public_files']:assert (repo/name).read_bytes()==(out/'source'/name).read_bytes(),name
checks['byte_identical_public_files']=len(listing['byte_identical_public_files'])
print(json.dumps(checks,indent=2))
