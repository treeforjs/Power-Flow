"""Record independent dimensionless ramp-energy integrals; no suite rerun."""

import datetime
import hashlib
import json
import math
from pathlib import Path
import time

from scipy.integrate import quad


work = Path(__file__).resolve().parent
repo = Path('/workspace/Power-Flow')
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
clock_start = time.perf_counter()

# These formulas are evaluated independently; the benchmark is not imported.
def b(u):
    return (1 + 2*u*u)*math.erfc(u) - 2*u*math.exp(-u*u)/math.sqrt(math.pi)


def g(u):
    return math.exp(-u*u)/math.sqrt(math.pi) - u*math.erfc(u)


ib, ib_error = quad(lambda u: b(u)**2, 0., math.inf, epsabs=1e-13, epsrel=1e-12)
ig, ig_error = quad(lambda u: g(u)**2, 0., math.inf, epsabs=1e-13, epsrel=1e-12)
closed_b = (28 - 16*math.sqrt(2))/(15*math.sqrt(math.pi))
closed_g = (math.sqrt(2)-1)/(3*math.sqrt(math.pi))
closed_q = 16*(math.sqrt(2)-1)/(15*math.sqrt(math.pi))
closed_input = 4/(5*math.sqrt(math.pi))
numeric_q = 16/5*ig
closure = math.fsum((ib, numeric_q, -closed_input))
assert abs(ib-closed_b) < 1e-11
assert abs(ig-closed_g) < 1e-11
assert abs(closure) < 1e-11

calculation = {
    'schema': 'mhdlab-independent-smooth-ramp-coefficients-v1',
    'record_kind': 'fresh_independent_coefficient_calculation',
    'started_utc': started,
    'ended_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'elapsed_s': time.perf_counter()-clock_start,
    'benchmark_module_imported': False,
    'full_test_suite_rerun': False,
    'method': 'scipy.integrate.quad of independent math.erfc closed dimensionless profiles on [0,infinity)',
    'quadrature': {'epsabs': 1e-13, 'epsrel': 1e-12},
    'common_energy_scale': '(Bdot^2/mu)*sqrt(D)*t^(5/2), D=1/(mu*sigma)',
    'profiles': {
        'b': '(1+2*u^2)*erfc(u)-2*u*exp(-u^2)/sqrt(pi)',
        'g': 'exp(-u^2)/sqrt(pi)-u*erfc(u)',
        'identity': 'db/du=-4*g',
    },
    'integrals': {
        'int_b_squared': {'numeric': ib, 'quad_error_estimate': ib_error, 'closed': closed_b,
                          'formula': '(28-16*sqrt(2))/(15*sqrt(pi))'},
        'int_g_squared': {'numeric': ig, 'quad_error_estimate': ig_error, 'closed': closed_g,
                          'formula': '(sqrt(2)-1)/(3*sqrt(pi))'},
    },
    'energy_coefficients': {
        'magnetic': closed_b,
        'joule_cumulative': closed_q,
        'joule_cumulative_independent_numeric': numeric_q,
        'poynting_input_cumulative': closed_input,
        'numeric_balance_residual': closure,
        'surface_power_coefficient': 2/math.sqrt(math.pi),
    },
    'derivation': [
        'U/A=(R^2/mu)*sqrt(D)*t^(5/2)*integral_0^infinity b(u)^2 du',
        'Instantaneous Joule/A=8*(R^2/mu)*sqrt(D)*t^(3/2)*integral_0^infinity g(u)^2 du',
        'Time integration contributes 2/5, giving Joule coefficient (16/5)*integral g^2',
        'Surface Poynting power=2*(R^2/mu)*sqrt(D/pi)*t^(3/2)',
        'Its time integral coefficient is 4/(5*sqrt(pi))',
    ],
    'independent_review': {
        'reviewer': '/root/cr_transport',
        'kind': 'independent algebra and subsequent read-only implementation review',
        'reported_outcome': 'same coefficients and no actionable implementation issue',
        'review_timestamp_utc': None,
        'timestamp_status': 'not captured in collaboration message',
    },
    'exit_code': 0,
}
(work/'smooth_heating_global_coefficients.json').write_text(json.dumps(calculation, indent=2)+'\n')

report_log = work/'smooth_heating_unit_reported_run.log'
report_log.write_text(
    'REPORTED RUN RECORD: no original process log file was captured.\n'
    'This note records a tool-reported outcome; it is not original pytest stdout/stderr.\n'
    'Working directory: /workspace/Power-Flow\n'
    'Command: .venv/bin/python -W error -m pytest -q tests/test_smooth_heating_benchmark.py\n'
    'Tool-reported exit code: 0\n'
    'Pytest-reported outcome: 58 passed in 1.65s\n'
    'Tool exec session: 96369; final result chunk: c7887d\n'
    'Original run UTC timestamps and full wall duration were not captured.\n'
    'No unchanged passing suite was rerun to create this record.\n'
)
report = {
    'schema': 'mhdlab-reported-test-run-v1',
    'record_kind': 'reported_run_no_original_captured_log',
    'record_created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'command': ['.venv/bin/python', '-W', 'error', '-m', 'pytest', '-q',
                'tests/test_smooth_heating_benchmark.py'],
    'cwd': str(repo),
    'reported_exit_code': 0,
    'reported_passed': 58,
    'pytest_reported_duration_s': 1.65,
    'original_start_utc': None,
    'original_end_utc': None,
    'original_wall_duration_s': None,
    'original_captured_log': None,
    'original_captured_log_sha256': None,
    'reported_tool_session_id': 96369,
    'reported_final_tool_chunk_id': 'c7887d',
    'reported_outcome_excerpt': '58 passed in 1.65s',
    'report_note_path': str(report_log),
    'report_note_sha256': hashlib.sha256(report_log.read_bytes()).hexdigest(),
    'report_note_is_original_process_output': False,
    'unchanged_suite_rerun_for_capture': False,
    'source_hashes_captured_at_record_creation_not_claimed_as_original_run_snapshot': {
        str(path.relative_to(repo)): hashlib.sha256(path.read_bytes()).hexdigest()
        for path in (repo/'mhdlab/smooth_heating_benchmark.py', repo/'tests/test_smooth_heating_benchmark.py')
    },
}
(work/'smooth_heating_unit_reported_run.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps({'coefficient_calculation': calculation, 'reported_test_run': report}, indent=2))
