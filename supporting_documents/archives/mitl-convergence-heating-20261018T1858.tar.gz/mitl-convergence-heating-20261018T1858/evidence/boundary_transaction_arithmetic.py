"""Exact rational accounting for the manufactured boundary handoff example."""

from decimal import Decimal, localcontext
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path


def decimal(value):
    with localcontext() as context:
        context.prec = 50
        return str(Decimal(value.numerator) / Decimal(value.denominator))


def dot(a, b):
    return sum((x * y for x, y in zip(a, b)), F(0))


weights = (2, 3)
masses = (F("2e-26"), F("4e-26"))
velocities = ((1000, 2000, 0), (-500, 1000, 500))
wall_velocity = (400, -200, 100)
temperatures = (300, 600)
desorption_ev = (F("0.2"), F("0.4"))
internal_ev = (F("0.1"), F("0.05"))
elementary_charge = F("1.602176634e-19")
boltzmann = F("1.380649e-23")
initial_counts = (10, 8)
remaining_counts = tuple(before - released for before, released in zip(initial_counts, weights))
area = F("1e-12")

mass = sum((n * m for n, m in zip(weights, masses)), F(0))
momentum_rest = tuple(sum((n * m * c[k] for n, m, c in zip(weights, masses, velocities)), F(0)) for k in range(3))
kinetic_rest = sum((F(1, 2) * n * m * dot(c, c) for n, m, c in zip(weights, masses, velocities)), F(0))
velocities_lab = tuple(tuple(c[k] + wall_velocity[k] for k in range(3)) for c in velocities)
momentum_lab = tuple(sum((n * m * c[k] for n, m, c in zip(weights, masses, velocities_lab)), F(0)) for k in range(3))
kinetic_lab = sum((F(1, 2) * n * m * dot(c, c) for n, m, c in zip(weights, masses, velocities_lab)), F(0))
cross_work = dot(wall_velocity, momentum_rest)
advected_kinetic = F(1, 2) * mass * dot(wall_velocity, wall_velocity)
assert momentum_lab == tuple(momentum_rest[k] + mass * wall_velocity[k] for k in range(3))
assert kinetic_lab == kinetic_rest + cross_work + advected_kinetic

adsorption_change = sum((n * energy * elementary_charge for n, energy in zip(weights, desorption_ev)), F(0))
internal = sum((n * energy * elementary_charge for n, energy in zip(weights, internal_ev)), F(0))
expected_kinetic = 2 * boltzmann * sum(n * temperature for n, temperature in zip(weights, temperatures))
thermal_debit = kinetic_rest + adsorption_change + internal
expected_thermal_debit = expected_kinetic + adsorption_change + internal
thermal_before = F("2e-18")
thermal_after = thermal_before - thermal_debit
assert thermal_after > 0
adsorption_before = -sum((n * energy * elementary_charge for n, energy in zip(initial_counts, desorption_ev)), F(0))
adsorption_after = -sum((n * energy * elementary_charge for n, energy in zip(remaining_counts, desorption_ev)), F(0))
assert adsorption_after - adsorption_before == adsorption_change

wall_stationary_change = -thermal_debit + adsorption_change
gas_stationary_change = kinetic_rest + internal
wall_moving_change = wall_stationary_change - advected_kinetic
gas_moving_change = kinetic_lab + internal
assert wall_stationary_change + gas_stationary_change == 0
assert wall_moving_change + gas_moving_change == cross_work
assert mass == sum(((before - after) * m for before, after, m in zip(initial_counts, remaining_counts, masses)), F(0))
assert all(c[1] > 0 for c in velocities)

report = {
    "case": "manufactured_two_packet_boundary_accounting_v1",
    "arithmetic": "exact rational; decimal values are printed to 50 significant digits",
    "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "weights": weights,
    "initial_counts": initial_counts,
    "remaining_counts": remaining_counts,
    "initial_coverage_m2": [decimal(F(n) / area) for n in initial_counts],
    "remaining_coverage_m2": [decimal(F(n) / area) for n in remaining_counts],
    "released_mass_kg": decimal(mass),
    "momentum_rest_kg_m_s": [decimal(x) for x in momentum_rest],
    "momentum_lab_kg_m_s": [decimal(x) for x in momentum_lab],
    "kinetic_rest_j": decimal(kinetic_rest),
    "kinetic_lab_j": decimal(kinetic_lab),
    "wall_velocity_dot_rest_momentum_j": decimal(cross_work),
    "removed_advected_kinetic_j": decimal(advected_kinetic),
    "adsorption_reference_energy_change_j": decimal(adsorption_change),
    "gas_internal_energy_j": decimal(internal),
    "expected_kinetic_rest_j": decimal(expected_kinetic),
    "actual_minus_expected_kinetic_j": decimal(kinetic_rest - expected_kinetic),
    "actual_thermal_debit_j": decimal(thermal_debit),
    "expected_thermal_debit_j": decimal(expected_thermal_debit),
    "thermal_energy_before_j": decimal(thermal_before),
    "thermal_energy_after_j": decimal(thermal_after),
    "stationary_wall_total_energy_change_j": decimal(wall_stationary_change),
    "stationary_gas_total_energy_change_j": decimal(gas_stationary_change),
    "stationary_total_energy_residual_j": decimal(wall_stationary_change + gas_stationary_change),
    "prescribed_velocity_wall_total_energy_change_j": decimal(wall_moving_change),
    "prescribed_velocity_gas_total_energy_change_j": decimal(gas_moving_change),
    "prescribed_velocity_support_work_j": decimal(cross_work),
    "prescribed_velocity_energy_balance_residual_j": decimal(wall_moving_change + gas_moving_change - cross_work),
    "rejection_case_available_thermal_energy_j": decimal(thermal_debit / 2),
    "rejection_case_thermal_shortfall_j": decimal(thermal_debit / 2),
}
print(json.dumps(report, indent=2))
