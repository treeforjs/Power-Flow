# Source convergence and heating reference subset

The public source files are byte-identical to the commit recorded in the parent
handoff. This README, minimal initializer, requirements and pytest settings are
packaging wrappers. Python 3.11 or newer is required.

```sh
python -m pytest -q -W error
python tools/verify_temkin_planar_convergence.py --output-dir /tmp/source-refinement --plot
python tools/run_smooth_heating_benchmark.py --output-dir /tmp/ramp-reference --plot
```

Every output path must be new. The numerical examples are manufactured. They
neither calibrate water desorption nor reproduce a measured shot or run FLASH.
Read `docs/temkin_convergence.md` and `docs/smooth_drive_verification.md` for
finite-reference, physical and numerical limits. No transport evolution,
collisions, radiation or production host is included.

The ten Wilkes points are a partial reconstructed plot dataset, not raw data,
a fitted continuous curve or an automatic property input. Source PDFs and
source-pixel overlays are not redistributed. Optional PDF recovery needs
PyMuPDF and the hash-identified official file; the data and other tests work
without it. The historical source assessment is retained for context and may
refer to files available in earlier source packets or the complete repository.
