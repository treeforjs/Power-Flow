"""Independent thermal-source and heating verification references."""
