"""Prepare a public fixed-source-window subset for independent import verification."""
import ast
import hashlib
import json
from pathlib import Path
import shutil

repo = Path('/workspace/Power-Flow')
out = Path('/workspace/handoffs/mitl-window-source-ledgers-20261019T0250')
assert out.exists()
source = out/'source'
source.mkdir(parents=True,exist_ok=True)
names = {'mhdlab/window_source_ledger.py','tests/test_window_source_ledger.py',
         'tools/export_window_source_ledger.py','tests/test_window_source_ledger_cli.py',
         'tools/export_packet_source_ledger.py','tests/test_packet_source_ledger_cli.py',
         'docs/window_source_ledgers.md'}
pending = list(names)
while pending:
    name = pending.pop()
    if not name.endswith('.py'):
        continue
    tree = ast.parse((repo/name).read_text())
    needed = []
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom) and node.module:
            if node.level:
                needed.append('mhdlab/'+node.module.replace('.', '/')+'.py')
            elif node.module.startswith(('mhdlab.', 'tools.')):
                needed.append(node.module.replace('.', '/')+'.py')
    for node in ast.walk(tree):
        if (isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
                and node.func.attr == 'import_module' and node.args
                and isinstance(node.args[0], ast.Constant) and isinstance(node.args[0].value,str)
                and node.args[0].value.startswith(('mhdlab.','tools.'))):
            needed.append(node.args[0].value.replace('.','/')+'.py')
    for node in ast.walk(tree):
        if (isinstance(node,ast.Constant) and isinstance(node.value,str)
                and node.value.startswith(('mhdlab.','tools.'))):
            needed.append(node.value.replace('.','/')+'.py')
    for node in tree.body:
        if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'CODE_PATHS' for t in node.targets):
            needed.extend(ast.literal_eval(node.value))
    for item in needed:
        if (repo/item).is_file() and item not in names:
            names.add(item)
            pending.append(item)
assert not names.intersection({'mhdlab/runner.py','mhdlab/chemistry.py','mhdlab/kinetic_gap.py','mhdlab/cr_data.py','mhdlab/bolsig.py'})
for name in sorted(names):
    target = source/name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(repo/name, target)
wrappers = {
    'mhdlab/__init__.py':'"""Portable upstream source-window ledger verification subset."""\n',
    'pytest.ini':'[pytest]\npythonpath = .\n',
    'requirements.txt':'numpy\nscipy\nh5py\nmatplotlib\npytest\n',
    'README.md':'''# Conservative source-window ledger verification subset

Named public files are byte-identical to the recorded commit. Four named
packaging wrappers isolate imports from unrelated downstream solvers.

```sh
python -W error -m pytest tests/test_window_source_ledger.py tests/test_window_source_ledger_cli.py tests/test_packet_source_ledger_cli.py
```

Inputs are manufactured. Five source extensive channels retain independent
qualification. Exact rational aggregation and signed area/energy residuals
remain separate from SI projection flags and host acceptance. New study and
packet-source exports reuse original histories and moments; no saved evolution
or sampling is repeated. Read `docs/window_source_ledgers.md`.
''',
}
for name, body in wrappers.items():
    (source/name).write_text(body)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
listing = {'byte_identical_public_files':sorted(names), 'packaging_wrappers':sorted(wrappers)}
(out/'source_file_list.json').write_text(json.dumps(listing, indent=2)+'\n')
(out/'source-files.sha256').write_text(''.join(f'{sha(source/name)}  {name}\n' for name in sorted(names)))
print(json.dumps({'public_files':len(names), 'packaging_wrappers':len(wrappers), 'output':str(out)}, indent=2))
