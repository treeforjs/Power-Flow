"""Plot five-channel expected budgets from a verified manufactured source ledger."""
import csv
from fractions import Fraction
import hashlib
import importlib.metadata
import json
from pathlib import Path
import sys

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np

work=Path(__file__).resolve().parent
source=work/'saved-packet-ledger'
output=work/'energy-pathways'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_text())
Q_E=Fraction(1.602176634e-19)
channels=('translational_energy_j','internal_energy_j','binding_energy_j','total_wall_energy_debit_j')

def exact(record):
    assert record['available']
    return Fraction(int(record['exact_sum']['numerator']),int(record['exact_sum']['denominator']))

report=load(source/'report.json')
assert report['parameter_status']=='manufactured' and report['host_budget_accepted'] is False
assert sha(source/'ledger.json')==report['output_sha256']['ledger.json']
ledger=load(source/'ledger.json')
input_hashes={str(source/'report.json'):sha(source/'report.json'),str(source/'ledger.json'):sha(source/'ledger.json')}
rows=[]
for group in ledger['resolved']['by_reservoir']+[ledger['resolved']['total']]:
    key=group['key'];q=group['quantities'];number=exact(q['released_number'])
    assert number>0
    means={name:exact(q[name])/number/Q_E for name in channels}
    residual=means['total_wall_energy_debit_j']-sum((means[name] for name in channels[:-1]),Fraction(0))
    rows.append({'reservoir_name':key.get('reservoir_name','Full source'),'state_id':key.get('state_id','all supplied states'),
                 'released_number':float(number),**{name.removesuffix('_j')+'_ev_per_parent':float(value) for name,value in means.items()},
                 'wall_minus_parts_ev_per_parent':float(residual),
                 'exact_wall_minus_parts_ev_per_parent':{'numerator':str(residual.numerator),'denominator':str(residual.denominator)}})
assert not output.exists()
output.mkdir()
fields=[key for key in rows[0] if not key.startswith('exact_')]
with (output/'energy_pathways.csv').open('w',newline='') as stream:
    writer=csv.DictWriter(stream,fieldnames=fields)
    writer.writeheader();writer.writerows({key:row[key] for key in fields} for row in rows)
figure,axis=plt.subplots(figsize=(9.0,5.8))
x=np.arange(len(rows))
bottom=np.zeros(len(rows))
for name,label,color in (
    ('translational_energy','Outgoing translation (mean 2kBT)','#2B6F9C'),
    ('internal_energy','Supplied internal excitation','#DDAA44'),
    ('binding_energy','Supplied removal cost','#91A3AE')):
    values=np.asarray([row[name+'_ev_per_parent'] for row in rows])
    axis.bar(x,values,bottom=bottom,label=label,color=color,width=.58)
    bottom+=values
axis.scatter(x,[row['total_wall_energy_debit_ev_per_parent'] for row in rows],
             marker='D',s=55,facecolors='white',edgecolors='black',linewidths=1.2,zorder=4,label='Declared wall total')
axis.set_xticks(x,[row['reservoir_name']+'\n'+row['state_id'] for row in rows])
axis.set_ylabel('Expected source energy (eV / released parent)')
axis.set_title('Manufactured source energy pathways',pad=14)
axis.set_ylim(0,max(bottom)*1.13)
axis.grid(axis='y',alpha=.2)
axis.set_axisbelow(True)
axis.legend(loc='upper center',bbox_to_anchor=(.5,-.15),ncol=2,frameon=False,fontsize=9)
figure.text(.5,.025,'Composite source selections; supplied energy references; no accepted wall transaction.',ha='center',fontsize=9)
figure.subplots_adjust(left=.11,right=.97,top=.88,bottom=.31)
figure.savefig(output/'source_energy_pathways.png',dpi=180,metadata={'Software':''})
figure.savefig(output/'source_energy_pathways.pdf',metadata={'Creator':'','Producer':'','CreationDate':None,'ModDate':None})
plt.close(figure)
assert all(sha(Path(path))==digest for path,digest in input_hashes.items())
result={'schema':'mitl-manufactured-source-energy-pathways-v1','parameter_status':'manufactured',
        'input_sha256':input_hashes,'script_sha256':sha(__file__),'rows':rows,
        'source_evolution_or_moments_or_packets_repeated':False,'host_budget_accepted':False,
        'runtime':{'python':sys.version,**{name:importlib.metadata.version(name) for name in ('numpy','matplotlib')}},
        'limits':['Expected source parent budgets with supplied independent energy references; no physical water calibration or inferred state branching.',
                  'Kinetic activation barriers are separate from the supplied removal energy and are not added to the wall total.',
                  'Source translation means are distinct from realized particle energies and their conditional thermal scatter.',
                  'Signed wall-minus-parts residuals are retained; stacked height and marker are floating-point display projections.'],
        'output_sha256':{path.name:sha(path) for path in output.iterdir() if path.is_file()}}
(output/'report.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps({'output_dir':str(output),'rows':len(rows),'report_sha256':sha(output/'report.json')},indent=2))
