"""Verify actual compressed ledger handoff bytes and original associations."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess
import tarfile

work=Path(__file__).resolve().parent
repo=Path('/workspace/Power-Flow')
out=Path('/workspace/handoffs/mitl-window-source-ledgers-20261019T0250')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_text())
frozen=load(work/'frozen_handoff.json');archive=Path(frozen['archive'])
assert sha(archive)==frozen['sha256']
files={}
with tarfile.open(archive,'r:gz') as tar:
    for item in tar.getmembers():
        path=PurePosixPath(item.name)
        assert not path.is_absolute() and '..' not in path.parts and path.parts[0]==out.name
        assert not item.issym() and not item.islnk()
        if item.isdir():continue
        assert item.isfile()
        name=str(PurePosixPath(*path.parts[1:]));assert name not in files
        files[name]=tar.extractfile(item).read()
manifest=json.loads(files['manifest.sha256.json'])
assert set(files)==set(manifest)|{'manifest.sha256.json'}
for name,digest in manifest.items():assert hashlib.sha256(files[name]).hexdigest()==digest,name
listing=json.loads(files['source_file_list.json'])
assert {name[7:] for name in files if name.startswith('source/')}==set(listing['byte_identical_public_files'])|set(listing['packaging_wrappers'])
for name in listing['byte_identical_public_files']:assert files['source/'+name]==(repo/name).read_bytes(),name
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
verification=json.loads(files['verification.json'])
assert head==frozen['source_commit']==verification['source_commit']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip()
for folder in ('saved-study-ledgers','saved-packet-ledger','saved-packet-ledger-initial','energy-pathways'):
    report=json.loads(files[f'evidence/{folder}/report.json'])
    for name,digest in report['output_sha256'].items():
        assert hashlib.sha256(files[f'evidence/{folder}/{name}']).hexdigest()==digest,name
    if folder in ('saved-study-ledgers','saved-packet-ledger'):
        for name,digest in report['source_sha256'].items():assert sha(repo/name)==digest,name
study=json.loads(files['evidence/saved-study-ledgers/study/report.json'])
for name,digest in study['output_sha256'].items():
    assert hashlib.sha256(files['evidence/saved-study-ledgers/study/'+name]).hexdigest()==digest,name
packet=json.loads(files['evidence/saved-packet-ledger/packet_export/report.json'])
for name,digest in packet['output_sha256'].items():
    assert hashlib.sha256(files['evidence/saved-packet-ledger/packet_export/'+name]).hexdigest()==digest,name
assert files['evidence/saved-packet-ledger-initial/ledger.json']==files['evidence/saved-packet-ledger/ledger.json']
assert verification['results']['portable_unique_passed']==68
result={**frozen,'status':'passed','actual_archive_regular_files':len(files),'manifest_entries':len(manifest),
        'public_files_byte_identical':len(listing['byte_identical_public_files']),'packaging_wrappers':len(listing['packaging_wrappers']),
        'unsafe_or_duplicate_members':0,'input_code_output_bindings_verified':True,'repository_clean':True}
(work/'delivery_verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
