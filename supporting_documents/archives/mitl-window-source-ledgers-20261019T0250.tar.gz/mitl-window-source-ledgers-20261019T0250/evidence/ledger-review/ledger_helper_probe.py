"""New exact-enumeration checks of trusted ledger arithmetic helpers only."""
from fractions import Fraction as F
import hashlib
import json
import math
from pathlib import Path
import sys

work=Path(__file__).resolve().parent
repo=Path('/workspace/Power-Flow')
sys.path.insert(0,str(repo))
from mhdlab import window_source_ledger as ledger
from mhdlab.constants import KB
from fraction_reference import CHANNELS,X,Z,STATES,ZERO,fixture,enumerate_reference

checks=groups=0
def equal(a,b,label):
    global checks
    if a!=b:
        raise AssertionError((label,a,b))
    checks+=1
def fraction(record):
    return F(int(record['numerator']),int(record['denominator']))
def amount(record,expected,area):
    equal(record['available'],expected['available'],'availability')
    equal(fraction(record['qualified_subtotal']['exact_sum']),expected['subtotal'],'qualified subtotal')
    equal(record['unqualified']['count'],len(expected['missing']),'missing contributor count')
    if expected['available']:
        total=expected['total']
        equal(fraction(record['exact_sum']),total,'complete amount')
        projected=float(total)
        equal(record['value'],projected,'display amount')
        equal(record['projection']['exact_zero'],total==0,'structural zero')
        equal(record['projection']['underflowed'],bool(total and projected==0),'positive-underflow flag')
        equal(fraction(record['projection']['exact_rounding_error']),F(projected)-total,'signed output rounding')
        equal(record['per_area']['available'],True,'density availability')
        equal(fraction(record['per_area']['exact_sum']),total/area,'single area division')
    else:
        equal(record['exact_sum'],None,'incomplete exact amount')
        equal(record['value'],None,'incomplete display amount')
        equal(record['projection'],None,'incomplete projection')
        equal(record['per_area']['available'],False,'incomplete density')
        equal(record['per_area']['value'],None,'incomplete density value')

def applies(category,key,source):
    return (category=='total'
        or category=='by_width' and key==(source['x'],)
        or category=='by_current' and key==(source['z'],)
        or category=='by_state' and key==(STATES[source['pool']],)
        or category=='by_reservoir' and key==(source['pool'],)
        or category=='by_selection' and key==(source['selection'],)
        or category=='by_patch_state' and key==(source['z'],source['x'],STATES[source['pool']]))

def accumulator(records,condition):
    acc=ledger._Accumulator()
    chosen=[]
    for source in records:
        if not condition(source):
            continue
        values={name:record['value'] if record['available'] else None for name,record in source['amounts'].items()}
        missing={name:source['index']*10+i for i,name in enumerate(CHANNELS) if values[name] is None}
        T=float(100*(source['index']+1))
        acc.add(values,missing,T)
        chosen.append((source,T))
    return acc,chosen

samples={}
for scenario,options in (
    ('complete',{}),('missing_positive_internal',{'missing':True}),
    ('missing_positive_count',{'missing_count':True}),('tiny_positive',{'tiny':True}),
):
    records=fixture(**options)
    for matched in (False,True):
        reference=enumerate_reference(matched=matched,**options)
        for category,entries in reference.items():
            for key,expected in entries.items():
                scale=F(1);source_ref=None
                if matched and category=='by_width':
                    acc,chosen=accumulator(records,lambda source:True)
                    scale=(X[key[0]+1]-X[key[0]])/(X[-1]-X[0]);source_ref='resolved/total'
                elif matched and category=='by_patch_state':
                    j,x,state=key
                    acc,chosen=accumulator(records,lambda source:source['z']==j and STATES[source['pool']]==state)
                    scale=(X[x+1]-X[x])/(X[-1]-X[0]);source_ref='independent-current-state-base'
                else:
                    acc,chosen=accumulator(records,lambda source:applies(category,key,source))
                area=expected['area']
                actual=ledger._group(acc,{'test_key':str(key)},area,area,'independent unique patch union',
                                     scale=scale,source_ref=source_ref)
                equal(fraction(actual['area']['exact_m2']),area,'unique geometry area')
                equal(fraction(actual['area']['canonical_minus_exact_residual_m2']['exact_sum']),ZERO,'exact geometry fixture')
                equal(actual['host_budget_accepted'],False,'no host acceptance')
                for name in CHANNELS:
                    amount(actual['quantities'][name],expected['amounts'][name],area)
                missing_energy=any(not expected['amounts'][name]['available'] for name in CHANNELS[1:])
                equal(actual['residuals']['wall_minus_parts_j']['available'],not missing_energy,'complete wall residual')
                if not missing_energy:
                    residual=expected['amounts'][CHANNELS[-1]]['total']-sum((expected['amounts'][name]['total'] for name in CHANNELS[1:-1]),ZERO)
                    equal(fraction(actual['residuals']['wall_minus_parts_j']['exact_sum']),residual,'signed wall residual')
                missing_thermal=not expected['amounts']['released_number']['available'] or not expected['amounts']['translational_energy_j']['available']
                equal(actual['residuals']['translation_minus_count_2kbt_j']['available'],not missing_thermal,'complete thermal residual')
                if not missing_thermal:
                    count_energy=scale*sum((source['amounts']['released_number']['value']*2*F(KB)*F(T) for source,T in chosen),ZERO)
                    residual=expected['amounts']['translational_energy_j']['total']-count_energy
                    equal(fraction(actual['residuals']['translation_minus_count_2kbt_j']['exact_sum']),residual,'signed thermal residual without repair')
                if scenario=='tiny_positive' and matched and category=='by_width':
                    samples['tiny_width_'+str(key[0])]=actual['quantities']['released_number']
                if scenario=='complete' and not matched and category=='by_patch_state' and key==(0,1,'B'):
                    samples['complete_zero_patch_state']=actual['quantities']['released_number']
                if scenario=='missing_positive_internal' and matched and category=='by_width':
                    samples['incomplete_internal_width_'+str(key[0])]=actual['quantities']['internal_energy_j']
                groups+=1

# A signed canonical-area residual and aggregate overflow are diagnostics, not
# silently repaired or reclassified as missing source values.
area=ledger._area(F(1),F(math.nextafter(1.,math.inf)),'area rounding probe')
equal(fraction(area['canonical_minus_exact_residual_m2']['exact_sum']),F(1,2**52),'signed area rounding')
overflow=ledger._number(F(float.fromhex('0x1.fffffffffffffp+1023'))*2)
equal(overflow['value'],None,'aggregate display overflow')
equal(overflow['projection']['overflowed'],True,'aggregate overflow flag')
equal(overflow['projection']['exact_zero'],False,'overflow is not zero')

report={
    'schema':'mhdlab-new-window-ledger-helper-fraction-probe-v1',
    'ledger_sha256':hashlib.sha256((repo/'mhdlab/window_source_ledger.py').read_bytes()).hexdigest(),
    'scenarios':4,'resolved_and_matched_groups_checked':groups,'exact_checks_passed':checks,
    'source_fixture_totals':dict(zip(CHANNELS,(41,127,23,64,214))),
    'samples':samples,'signed_area_residual':area,'aggregate_overflow':overflow,
    'open_substantive_findings':[],
    'scope':'New trusted arithmetic helper inputs compared with independent naive component-by-width Fraction enumeration; no public source admission, canonical history, source law, sampler, prior suite/oracle or owned solver is called.'
}
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps({key:value for key,value in report.items() if key!='samples'},indent=2,allow_nan=False))
