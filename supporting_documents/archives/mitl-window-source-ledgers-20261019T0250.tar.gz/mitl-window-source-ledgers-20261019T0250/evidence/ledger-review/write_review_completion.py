"""Pin the frozen ledger review; does not execute source or probe routines."""
import datetime
import hashlib
import json
from pathlib import Path

work=Path(__file__).resolve().parent
parent=work.parent
repo=Path('/workspace/Power-Flow')
source=repo/'mhdlab/window_source_ledger.py'
expected='6b99ce628b8ca1f6a31e868debf89395be3236e4b59777ab442d792feea1ed67'
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
if sha(source)!=expected:
    raise SystemExit('Frozen ledger differs from final owner notice')
probe=json.loads((work/'ledger_helper_probe.json').read_text())
if probe['ledger_sha256']!=expected or probe['open_substantive_findings']:
    raise SystemExit('Probe source/finding association mismatch')
commands=[json.loads(line) for line in (parent/'commands.jsonl').read_text().splitlines()]
records=[record for record in commands if Path(record['log']).name=='ledger_helper_fraction_probe.log']
if len(records)!=1 or records[0]['exit_code']!=0 or sha(records[0]['log'])!=records[0]['log_sha256']:
    raise SystemExit('Recorded new probe evidence mismatch')
artifacts={
    'ledger-review/'+name:sha(work/name) for name in (
        'fraction_reference.py','ledger_helper_probe.py','ledger_helper_probe.json',
        'review_notes.md','write_review_completion.py')
}
artifacts['ledger_helper_fraction_probe.log']=records[0]['log_sha256']
report={
    'schema':'mhdlab-window-source-ledger-independent-review-v1',
    'status':'passed','completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'reviewed_source_sha256':{'mhdlab/window_source_ledger.py':expected},
    'artifact_path_root':str(parent),'artifact_sha256':artifacts,
    'new_focused_probe':{
        'scenarios':probe['scenarios'],
        'resolved_and_matched_groups_checked':probe['resolved_and_matched_groups_checked'],
        'exact_checks_passed':probe['exact_checks_passed'],
        'command':records[0],
        'method':'Naive explicit component-by-destination-width Fraction enumeration compared with factored trusted arithmetic helpers.'
    },
    'closed_substantive_findings':[],
    'open_substantive_findings':[],
    'review_conclusions':[
        'Every consumed extensive source quantity has independent qualification. An unqualified positive field makes its complete affected total/density unavailable rather than zero; qualified subtotals remain separately labeled.',
        'Group areas count declared physical geometry once, including zero-initial slots. Width/current/fullface/patchstate conventions agree with their explicit output definitions.',
        'Represented extensive quantities already include the original canonical float patch area and are not multiplied by area again; exact geometric density areas retain separate signed canonical-area residuals.',
        'Matched width applies exact geometric width fractions to each original quantity mixture. Non-width groups remain unchanged; patch-state reductions preserve their current/state base without a component-by-width materialization.',
        'Available source sums and float projections are distinct: positive exact subnormal fractions, coarse display rounding and aggregate overflow retain rational values and signed projection errors.',
        'Structural zero groups remain complete zeros over a positive declared area and cannot be confused with missing positive contributors.',
        'Full-wall-minus-parts and translation-minus-count-times2kBT residuals have independent required-field availability and retain signed differences without balancing repair.',
        'Rate activation energy is not added to the supplied source energy debit; gas internal energy, removal cost and translation remain distinct declared energy pathways.',
        'Canonical source and cached scalar field validation are replayed by the public implementation before grouping; this reviewer inspected that route without calling it.',
    ],
    'scope_clarifications':[
        'include_components=False returns a budget summary; full conditional time/temperature sampling requires the original conditioned source or included component manifests.',
        'The unqualified contributor catalog covers the five consumed extensive quantities. Other source quantities remain in included component manifests or the original source.',
        'The ledger does not expose a conditional-energy-per-parent ratio; any downstream ratio is undefined at zero count.',
    ],
    'public_files_edited':False,
    'old_suites_or_oracles_repeated':False,
    'saved_source_evolved':False,
    'public_source_admission_or_history_or_law_or_sampler_called_by_reviewer':False,
    'host_budget_accepted':False,
    'limits':[
        'Read-only scientific/numerical code review plus one new trusted-helper probe; not an end-to-end public source validation test.',
        'The implementation owner independently tests fresh canonical source fixtures; reviewer did not rerun those tests.',
        'The numerical fixtures are manufactured and do not represent water material/chemical parameters or an experimental source.',
        'No host transaction, wall feedback, transport, collision, radiation, photon gate, FLASH/Quark run or physical spectrum is performed.',
        'Completion applies to the exact reviewed code hash; later changes need a scoped review update.',
    ],
}
path=work/'review_completion.json'
path.write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps({'completion':str(path),'sha256':sha(path),'reviewed_source_sha256':report['reviewed_source_sha256'],
                  'status':'passed','groups':160,'exact_checks':9028,'open_substantive_findings':[]},indent=2))
