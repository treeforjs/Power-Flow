"""Independent tiny enumeration; no source/history/sampler routines."""
from fractions import Fraction as F

CHANNELS=('released_number','translational_energy_j','internal_energy_j','binding_energy_j','total_wall_energy_debit_j')
X=(F(0),F(1),F(4));Z=(F(0),F(2),F(7))
STATES=('A','A','B')
FIXTURE=(
    (0,0,0,0,(2,6,2,4,12)),
    (0,1,0,0,(3,12,3,6,21)),
    (0,2,1,1,(5,10,0,5,15)),
    (1,0,0,0,(7,14,7,14,35)),
    (1,1,1,0,(11,33,11,22,66)),
    (1,2,1,1,(13,52,0,13,65)),
)
ZERO=F(0)
def keys(selection,pool,z,x):
    return {
        'total':(),'by_width':(x,),'by_current':(z,),
        'by_state':(STATES[pool],),'by_reservoir':(pool,),
        'by_selection':(selection,),'by_patch_state':(z,x,STATES[pool]),
    }

def fixture(*,missing=False,missing_count=False,tiny=False):
    records=[]
    chosen=FIXTURE if not tiny else ((0,0,0,0,(float.fromhex('0x0.0000000000001p-1022'),)*2+(0,0,float.fromhex('0x0.0000000000001p-1022'))),)
    for index,(s,p,z,x,values) in enumerate(chosen):
        amounts={name:{'available':not((missing and index==5 and name=='internal_energy_j')
                                      or (missing_count and index==0 and name=='released_number')),
                       'value':F(value)} for name,value in zip(CHANNELS,values)}
        records.append({'index':index,'selection':s,'pool':p,'z':z,'x':x,'amounts':amounts})
    return records

def enumerate_reference(*,matched,missing=False,missing_count=False,tiny=False):
    """Seed geometry first, then enumerate every tiny destination explicitly."""
    result={name:{} for name in keys(0,0,0,0)}
    for s in range(2):
        for p in range(3):
            for z in range(2):
                for x in range(2):
                    for category,key in keys(s,p,z,x).items():
                        record=result[category].setdefault(key,{'patches':set(),'amounts':{
                            name:{'subtotal':ZERO,'missing':set()} for name in CHANNELS}})
                        record['patches'].add((z,x))
    for source in fixture(missing=missing,missing_count=missing_count,tiny=tiny):
        destinations=range(2) if matched else (source['x'],)
        for x in destinations:
            scale=(X[x+1]-X[x])/(X[-1]-X[0]) if matched else F(1)
            for category,key in keys(source['selection'],source['pool'],source['z'],x).items():
                group=result[category][key]
                for name,amount in source['amounts'].items():
                    if amount['available']:
                        group['amounts'][name]['subtotal']+=amount['value']*scale
                    else:
                        group['amounts'][name]['missing'].add(source['index'])
    for groups in result.values():
        for group in groups.values():
            group['area']=sum(((X[x+1]-X[x])*(Z[z+1]-Z[z]) for z,x in group['patches']),ZERO)
            for amount in group['amounts'].values():
                amount['available']=not amount['missing']
                amount['total']=amount['subtotal'] if amount['available'] else None
    return result
