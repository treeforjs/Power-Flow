"""Freeze conservative source ledgers and independently qualified saved evidence."""
from collections import Counter
import datetime
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import tarfile
import xml.etree.ElementTree as ET

work=Path(__file__).resolve().parent
repo=Path('/workspace/Power-Flow')
out=Path('/workspace/handoffs/mitl-window-source-ledgers-20261019T0250')
base='4b083dea073c01c833f8da6844e048dda4be6990'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_text())
save=lambda p,v:Path(p).write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
listing=load(out/'source_file_list.json')
for name in listing['byte_identical_public_files']:assert (out/'source'/name).read_bytes()==(repo/name).read_bytes(),name
for path in sorted((out/'source').rglob('*'),key=lambda p:len(p.parts),reverse=True):
    if path.is_dir() and path.name in {'__pycache__','.pytest_cache'}:shutil.rmtree(path)
assert {str(p.relative_to(out/'source')) for p in (out/'source').rglob('*') if p.is_file()}==set(listing['byte_identical_public_files'])|set(listing['packaging_wrappers'])
initial=ET.parse(work/'isolated-results.xml').getroot().findall('.//testcase')
repair=ET.parse(work/'isolated-repair-results.xml').getroot().findall('.//testcase')
assert len(initial)==68 and len(repair)==24
errors=[case for case in initial if case.find('error') is not None]
assert len(errors)==24 and all('ModuleNotFoundError' in case.find('error').text for case in errors)
assert {(c.attrib['classname'],c.attrib['name']) for c in errors}=={(c.attrib['classname'],c.attrib['name']) for c in repair}
assert all(c.find('failure') is None and c.find('error') is None and c.find('skipped') is None for c in repair)
passed=[c for c in initial if c.find('error') is None]+repair
assert len(passed)==68 and all(c.find('failure') is None and c.find('skipped') is None for c in passed)
counts=dict(Counter(c.attrib['classname'] for c in passed));assert sorted(counts.values())==[13,24,31]
core_review=load(work/'ledger-review/review_completion.json')
wrapper_review=load(work/'packet-review/findings.json')
study_review=load(work/'saved-ledger-verification/completion.json')
packet_review=load(work/'packet-ledger-review/completion.json')
assert core_review['status']=='passed' and not core_review['open_substantive_findings']
assert packet_review['status']=='passed' and not packet_review['open_substantive_findings']
assert not wrapper_review['open']
for review in (core_review,packet_review):
    for name,digest in review['reviewed_source_sha256'].items():assert sha(repo/name)==digest,name
    for name,digest in review['artifact_sha256'].items():assert sha(work/name)==digest,name
for mapping in ('code_sha256','test_sha256','documentation_sha256'):
    for name,digest in wrapper_review[mapping].items():assert sha(repo/name)==digest,name
for name,digest in study_review['export_implementation_sha256'].items():assert sha(repo/name)==digest,name
for name,digest in study_review['evidence_sha256'].items():assert sha(name)==digest,name
for path in ('saved-study-ledgers','saved-packet-ledger','saved-packet-ledger-initial'):
    report=load(work/path/'report.json')
    assert report['host_budget_accepted'] is False and report['source_evolution_repeated'] is False
    for name,digest in report['output_sha256'].items():assert sha(work/path/name)==digest,name
for path in ('saved-study-ledgers','saved-packet-ledger'):
    for name,digest in load(work/path/'report.json')['source_sha256'].items():assert sha(repo/name)==digest,name
assert sha(work/'packet_wrapper_initial.py')==load(work/'saved-packet-ledger-initial/report.json')['source_sha256']['tools/export_packet_source_ledger.py']
assert sha(work/'saved-packet-ledger-initial/ledger.json')==sha(work/'saved-packet-ledger/ledger.json')
assert sha(work/'saved-packet-ledger-initial/ledger.csv')==sha(work/'saved-packet-ledger/ledger.csv')
figure=load(work/'energy-pathways/report.json')
assert figure['parameter_status']=='manufactured' and figure['host_budget_accepted'] is False
assert sha(work/'plot_source_energy_pathways.py')==figure['script_sha256']
for name,digest in figure['input_sha256'].items():assert sha(name)==digest,name
for name,digest in figure['output_sha256'].items():assert sha(work/'energy-pathways'/name)==digest,name

evidence=out/'evidence';evidence.mkdir(exist_ok=True)
for path in work.iterdir():
    if path.is_file() and path.suffix in {'.py','.json','.jsonl','.log','.xml','.md'} and not path.name.startswith('freeze-ledger-handoff'):
        shutil.copyfile(path,evidence/path.name)
for name in ('ledger-review','packet-review','saved-ledger-verification','packet-ledger-review',
             'saved-study-ledgers','saved-packet-ledger','saved-packet-ledger-initial','energy-pathways'):
    shutil.copytree(work/name,evidence/name,dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))
runtime_prefix=bytes.fromhex('2f6f70742f636f6465782f72756e74696d65732f636f6465782d7072696d6172792d72756e74696d652f646570656e64656e636965732f707974686f6e').decode()
projections=[]
for path in evidence.rglob('*'):
    if path.is_file() and path.suffix in {'.json','.jsonl','.xml','.log','.md','.py'}:
        text=path.read_text()
        if runtime_prefix in text:
            old=sha(path);n=text.count(runtime_prefix);path.write_text(text.replace(runtime_prefix,'[runtime Python directory]'))
            projections.append({'path':str(path.relative_to(out)),'original_sha256':old,'portable_sha256':sha(path),'replacements':n,
                'omission':'Machine-specific runtime path prefix only. Exact commands, failures, exits and scientific content are retained. Original local records are unchanged.'})
save(out/'portable_path_projections.json',projections)
with (out/'source-ledgers.patch').open('wb') as stream:subprocess.run(['git','diff',base,head],cwd=repo,stdout=stream,check=True)
next_task=('Implement strict read-only admission and an owner handoff descriptor for the exported source ledgers. '
           'Validate exact group partitions, declared area support, typed quantity availability/projection records, '
           'unqualified-catalog references, duplicate/missing state bins, original component time/state/temperature '
           'associations and bound source/evidence hashes. Use existing exported artifacts without source, moment '
           'or packet regeneration. This upstream validator must not accept a host transaction or alter owned '
           'transport, collision/radiative data or Quark code. Actual host response and field/loss/collection '
           'definitions remain owner-supplied.')
record={'schema':'mitl-window-source-ledger-verification-v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source_commit':head,'base_commit':base,'branch':'research/flash-publication-foundation',
    'commits':subprocess.check_output(['git','log','--reverse','--format=%H %s',base+'..HEAD'],cwd=repo,text=True).splitlines(),
    'results':{'targeted_unique_passed':68,'core_passed':31,'study_cli_passed':24,'packet_cli_passed':13,
        'portable_unique_passed':68,'portable_skipped':0,'portable_execution':'Initial44 passed and24 setup errors exposed two missing dynamically imported public guard dependencies. Added their byte-identical closure and reran only the affected24; all passed. Unchanged44 were not repeated.',
        'public_files_byte_identical':len(listing['byte_identical_public_files']),'packaging_wrappers':4,
        'new_exact_helper_scenarios':4,'new_exact_helper_groups':160,'new_exact_helper_checks':9028,
        'saved_study_windows':8,'saved_study_components':1792,'saved_study_group_rows':1448,'saved_study_channel_aggregates':7240,
        'saved_study_partition_area_closures':480,'saved_packet_components':48,'saved_packet_group_rows':78,
        'saved_packet_channel_rows':390,'source_evolution_repeated':False,'saved_moments_recomputed':False,
        'saved_packet_sampling_repeated':False,'unchanged_old_suites_or_saved_oracles_repeated':False},
    'core_review':core_review,'packet_wrapper_review':wrapper_review,'saved_study_review':study_review,'saved_packet_review':packet_review,
    'energy_figure':figure,'commands':[json.loads(line) for line in (work/'commands.jsonl').read_text().splitlines()],
    'attempts':'Fresh new tests passed. Strict JSON type replay was strengthened after review, with only new regressions and affected normal checks repeated. The initial packet wrapper/artifacts remain preserved, with final ledger/CSV bytes unchanged. Initial reference CSV ResourceWarning was corrected without repeating the passing numeric check. Portable dependency failure and repaired affected scope are retained.',
    'limits':['Manufactured source inputs; no physical water coverage, source rates/energies, calibration or spectral discrimination inferred.',
              'Canonical source admission replays the stored release law; it does not evolve replacement histories or repeat original saved moment/sampling drivers.',
              'Quantity completeness, exact algebra and SI projection are separate; unqualified positive channels are unavailable, never structural zeros.',
              'Component-free marginals do not reconstruct the original joint time/state/temperature source. Retain original source/component associations for transport.',
              'No host budget is accepted, no source weight/temperature/energy repair or wall cooling occurs, and no owned solver/state-data or Quark source/build/runner/job is touched.',
              'Selected numerical source pins exclude eager legacy imports; the portable empty initializer is an explicit wrapper.',
              'Physical inventory/calibration evidence and installed licensed FLASH/configured workstation remain unresolved.'],
    'next_task':next_task}
save(out/'verification.json',record)
(out/'systems-mitl-window-source-ledgers-10192026.md').write_text(f'''# MITL conservative source-window counts and energy pathways

Power-Flow is pinned to `{head}` on `research/flash-publication-foundation`.
Three local commits separate the ledger core, preserved-study exporter and
preserved-packet source exporter. The patch and public source subset are included.

Five extensive channels keep independent source qualification: parent number,
outgoing translation, supplied internal excitation, supplied removal cost and
declared wall debit. Exact represented-Fraction totals, signed energy/area
residuals, complete-versus-subtotal status and independent SI projection flags
prevent an unavailable positive channel from becoming zero. The kinetic
activation barrier is separate from the supplied removal energy. Expected
outgoing flux translation is 2*kB*T. No wall transaction is accepted or repaired.

Resolved and matched-width ledgers include total, width/current/state/reservoir/
selection marginals and current/state/width patches. Full declared geometry,
including zero-release slots, is divided once for each areal density. Width
redistribution preserves all other source associations through exact factored
mixtures. Optional full components retain source windows; component-free summaries
must not replace the joint time/state/temperature distribution in transport.

All 68 new targeted checks passed: 31 core, 24 study command and 13 packet command.
Independent helper review checked four scenarios, 160 groups and 9,028 exact
equalities including unavailable channels, zero support and extreme projections.
Strict JSON type replay covers the new study exporter and packet report/NPZ
metadata. Only new type regressions and affected normal tests were repeated.
Portable verification initially passed 44 and exposed 24 setup errors from two
missing dynamically imported public guard dependencies. Their closure was added
and only those 24 rerun, all passing. Original records and failures are retained.

The new study export reuses four preserved histories and eight source windows:
1,792 component associations, 1,448 resolved/matched group rows, 7,240 channel
aggregates and 480 partition/area closures were independently checked. Its zero
internal costs remain exact zeros. Prior width-profile quantities and totals
match without rerunning that reduction, source evolution or moment calculation.
The additional saved packet association supplies 48 components and two distinct
parent states with nonzero internal cost in the second pool. All five channels,
78 groups, four factored bases and 390 CSV rows were independently checked.
Final ledger JSON/CSV bytes equal the preserved initial admission-version output.
Both original wrappers/artifacts and the strengthened type checks are retained.

`evidence/packet-ledger-review/energy_channels.csv` and its exact JSON preserve
separate reservoir/state budgets. Manufactured per-parent outgoing translation
is about 0.11913eV and 0.12150eV; supplied internal costs are 0 and 0.05eV and
removal costs 0.6 and 0.7eV. These are generic reference inputs, not physical
water measurements. `evidence/energy-pathways/` contains a standalone PNG/PDF
and table separating these costs from the declared wall total. Signed rounding
residuals remain in the reports. The figure does not depict realized particle
energy, molecular daughter branching or wall feedback.

Commands, exits, exact input/code/output hashes and independent review pins are
retained. Original input files remain under each export's `study/` or
`packet_export/` directory. Only machine-specific runtime-directory metadata in
portable error records is projected, with original hashes and unchanged local
files. Source files are byte-identical to the commit, with four explicit import/
verification wrappers. Commands after archive freezing remain in the local work
journal. No prior unchanged suite, saved oracle, moment calculation, source
evolution or packet realization was repeated. Canonical validation does replay
the declared stored release law.

Physical H2O inventories and rate/energy/state inputs, raw diagnostics, absolute
VUV normalization and configured licensed FLASH/workstation remain unresolved.
No owned gap/collision/radiative solver, molecular data, Quark implementation/
build/runner, external messages or remote publication is included.

Next selected task: {next_task}
''')
save(out/'next_task.json',{'task':next_task})
manifest={str(path.relative_to(out)):sha(path) for path in out.rglob('*') if path.is_file() and path.name!='manifest.sha256.json'}
save(out/'manifest.sha256.json',manifest)
words=[bytes.fromhex(x).decode() for x in ('6f70656e6169','63686174677074','636c61756465','636f646578')]
pattern=re.compile(r'\b(?:'+'|'.join(words)+r')\b',re.I)
for path in out.rglob('*'):
    if path.is_file() and path.suffix in {'.py','.json','.jsonl','.log','.xml','.md','.txt','.patch'}:assert not pattern.search(path.read_text()),str(path)
archive=out.with_suffix('.tar.gz');assert not archive.exists()
with tarfile.open(archive,'w:gz') as tar:tar.add(out,arcname=out.name)
result={'archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'source_commit':head,
        'manifest_entries':len(manifest),'public_files_byte_identical':len(listing['byte_identical_public_files'])}
save(work/'frozen_handoff.json',result)
print(json.dumps(result,indent=2))
