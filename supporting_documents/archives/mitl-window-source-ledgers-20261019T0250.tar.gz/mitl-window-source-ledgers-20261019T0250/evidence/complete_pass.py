"""Record the verified ledger milestone, queue the next task and release its lease."""
import datetime
import fcntl
import hashlib
import json
from pathlib import Path
import subprocess

work=Path(__file__).resolve().parent
repo=Path('/workspace/Power-Flow')
out=Path('/workspace/handoffs/mitl-window-source-ledgers-20261019T0250')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
load=lambda p:json.loads(Path(p).read_text())
delivery=load(work/'delivery_verification.json');verification=load(out/'verification.json')
next_task=load(out/'next_task.json')['task']
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert commit==delivery['source_commit']==verification['source_commit']
assert delivery['status']=='passed' and sha(delivery['archive'])==delivery['sha256']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip()
assert verification['results']['portable_unique_passed']==68
now=datetime.datetime.now(datetime.timezone.utc)
status_path=work.parent/'mitl-upstream-status.json'
with (work.parent/'mitl-upstream-status.lock').open('a+') as lock:
    fcntl.flock(lock,fcntl.LOCK_EX)
    old=status_path.read_bytes();s=json.loads(old)
    assert s['active_lease_owner']==work.name
    assert datetime.datetime.fromisoformat(s['active_editing_lease_until_utc'])>now
    if s['handoff'] not in s.setdefault('prior_handoffs',[]):s['prior_handoffs'].append(s['handoff'])
    history=s.setdefault('verification_history',[])
    if not any(item['pass_id']==s['last_completed_pass_id'] for item in history):
        history.append({'pass_id':s['last_completed_pass_id'],'commit':s['last_complete_commit'],
            'handoff':s['handoff'],'handoff_sha256':s['handoff_sha256'],'verification':s['last_verified_suite']})
    s.update(last_complete_commit=commit,last_completed_pass_id=work.name,last_update_utc=now.isoformat(),
        handoff=delivery['archive'],handoff_sha256=delivery['sha256'],handoff_bytes=delivery['bytes'],
        handoff_document=str(out/'systems-mitl-window-source-ledgers-10192026.md'),
        active_lease_owner=None,active_editing_lease_until_utc=None,reserved_paths=[],active_completed_subtasks=[],
        active_phase='Completed conservative source ledgers and saved two-parent energy-pathway qualification; strict exported-ledger admission/owner handoff selected next')
    s['last_verified_suite']={**verification['results'],
        'scope':'New count/translation/internal/removal/wall source ledger, strict saved-study and packet-source exporters, independently read saved five-channel groups and one manufactured energy-pathway figure',
        'verification_record':str(out/'verification.json'),'delivery_manifest_entries':delivery['manifest_entries'],
        'physical_spectra_calculated':False,'host_budget_accepted':False,
        'previous_full_project_passed':721,'previous_full_project_skipped':2,'post_freeze_commands':str(work/'commands.jsonl')}
    s['source_window_ledgers']={'implementation':str(repo/'mhdlab/window_source_ledger.py'),
        'study_exporter':str(repo/'tools/export_window_source_ledger.py'),'packet_exporter':str(repo/'tools/export_packet_source_ledger.py'),
        'guide':str(repo/'docs/window_source_ledgers.md'),'quantities':['released_number','translational_energy_j','internal_energy_j','binding_energy_j','total_wall_energy_debit_j'],
        'saved_study_export':str(work/'saved-study-ledgers/report.json'),'saved_study_export_sha256':sha(work/'saved-study-ledgers/report.json'),
        'saved_study_readback':str(work/'saved-ledger-verification/completion.json'),
        'saved_packet_export':str(work/'saved-packet-ledger/report.json'),'saved_packet_export_sha256':sha(work/'saved-packet-ledger/report.json'),
        'saved_packet_readback':str(work/'packet-ledger-review/completion.json'),
        'energy_table':str(work/'packet-ledger-review/energy_channels.csv'),
        'energy_figure':str(work/'energy-pathways/source_energy_pathways.pdf'),
        'exact_aggregation':True,'independent_quantity_qualification':True,'si_projection_separate_from_availability':True,
        'host_budget_accepted':False,'parameter_status':'manufactured','source_evolution_repeated':False,
        'saved_moments_or_packet_sampling_repeated':False,
        'limits':'Ledger summaries do not replace original joint component source distributions; unqualified channels remain unavailable. No physical water parameters, monolayer inference, calibration or accepted host transaction.'}
    s.setdefault('owner_response_controls',{}).update(source_ledger_available=True,
        source_ledger_export=str(work/'saved-packet-ledger/report.json'),source_ledger_host_budget_accepted=False,
        owner_implementation_verified=False,physical_spectra_calculated=False)
    s['next_work']=[{'priority':1,'task':next_task}]+[dict(item) for item in s['next_work'] if item['priority']>1]
    s['completed_milestones'].extend([
        'Conservative exact represented-Fraction source ledgers preserve independent number/translation/internal/removal/wall availability, qualified subtotals, signed energy/area residuals and distinct SI projections. Width/current/state/reservoir/selection/patch-state support includes exact zeros; no host acceptance or source repair.31 new core checks passed.',
        'Strict saved-study and boundary-packet source exporters preserve input bytes/source associations and numeric CSV qualification flags. JSON type replay rejects bool/int aliases in study associations, packet source reports and NPZ metadata.24 study and13 packet checks passed; changed metadata guards reran only affected checks.',
        'Independent new helper reference passed4scenarios160groups9028checks. Saved study qualification passed8windows1792components1448group rows7240five-channel aggregates480partition/area closures. The48component two-state savedpacket qualification passed78groups390CSVrows40106checks including nonzero supplied internal energy; expected/source/sample references remain distinct.',
        f'Three local commits through{commit[:7]};68 new targeted and68 unique portable checks completed. Portable first44passed/24missing-guard-dependency setup errors corrected by added public closure and rerunning only affected24. {delivery["public_files_byte_identical"]} public files plus4wrappers and{delivery["manifest_entries"]}manifest entries verify in actual archive{delivery["sha256"]}. Manufactured PNG/PDF/table separate outgoing flux translation, internal excitation and removal costs; no saved source/moment/packet regeneration.'
    ])
    q=status_path.with_suffix('.json.new');q.write_text(json.dumps(s,indent=2,allow_nan=False)+'\n');q.replace(status_path)
    result={'utc':now.isoformat(),'event':'completed_and_next_selected','pass_id':work.name,'commit':commit,
        'archive':delivery['archive'],'archive_sha256':delivery['sha256'],'archive_bytes':delivery['bytes'],
        'new_targeted_unique_passed':68,'portable_unique_passed':68,'saved_study_windows':8,'saved_packet_components':48,
        'exact_commands':str(work/'commands.jsonl'),'status_before_sha256':hashlib.sha256(old).hexdigest(),'status_after_sha256':sha(status_path),
        'lease_released':True,'reserved_paths':[],'next':next_task,
        'limits':'Manufactured source/energy references; physical inventories, molecular energy/rate data, raw diagnostics, absolute VUV calibration and installed licensed FLASH/configured workstation remain unresolved. No host transaction or owned solver changes.'}
    (work/'completion.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    with (work.parent/'mitl-upstream-journal.jsonl').open('a') as f:f.write(json.dumps(result,allow_nan=False)+'\n')
print(json.dumps(result,indent=2))
