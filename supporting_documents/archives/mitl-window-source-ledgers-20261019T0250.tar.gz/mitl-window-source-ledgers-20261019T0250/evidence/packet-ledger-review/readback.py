"""Independent saved two-state ledger readback using only standard-library data."""
import csv
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path

work=Path(__file__).resolve().parent
parent=work.parent
repo=Path('/workspace/Power-Flow')
folder=parent/'saved-packet-ledger'
initial=parent/'saved-packet-ledger-initial'
original=Path('/workspace/research_work/mitl-upstream-20261018T2348/windowed-packet-example/report.json')
Q=('released_number','translational_energy_j','internal_energy_j','binding_energy_j','total_wall_energy_debit_j')
KB=F(1.380649e-23);QE=F(1.602176634e-19);ZERO=F(0)
checks=0
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def equal(a,b,label):
    global checks
    if a!=b:
        raise AssertionError((label,a,b))
    checks+=1
def rational(value):
    return F(int(value['numerator']),int(value['denominator']))
def typed_json(value):
    return json.dumps(value,sort_keys=True,allow_nan=False)
def number(value):
    projected=float(value)
    return {'exact_sum':{'numerator':str(value.numerator),'denominator':str(value.denominator)},'value':projected,
            'signed_projection_error':{'numerator':str((F(projected)-value).numerator),
                                       'denominator':str((F(projected)-value).denominator)}}
def check_number(record,value,label):
    equal(rational(record['exact_sum']),value,label+' exact')
    projected=float(value)
    equal(record['value'],projected,label+' float')
    projection=record['projection']
    for key,expected in (
        ('exact_zero',value==0),('positive',value>0),('negative',value<0),('finite',True),
        ('underflowed',bool(value and projected==0.)),('overflowed',False),
        ('rounded',F(projected)!=value),('subnormal',0<abs(projected)<float.fromhex('0x1.0000000000000p-1022'))):
        equal(projection[key],expected,label+' '+key)
    equal(rational(projection['exact_rounding_error']),F(projected)-value,label+' projection residual')

report=json.loads((folder/'report.json').read_text())
old_report=json.loads((initial/'report.json').read_text())
ledger=json.loads((folder/'ledger.json').read_text())
source_report=json.loads(original.read_text())
source=source_report['conditioned_source']
equal(report['parameter_status'],'manufactured','status')
equal(report['host_budget_accepted'],False,'report host acceptance')
for name,digest in report['output_sha256'].items():
    equal(sha(folder/name),digest,'final output pin '+name)
equal(sha(original),report['input_export_sha256']['report.json'],'original source report pin')
equal(sha(folder/'ledger.json'),sha(initial/'ledger.json'),'ledger unchanged after admission guard')
equal(sha(folder/'ledger.csv'),sha(initial/'ledger.csv'),'ledger CSV unchanged after admission guard')
equal(sha(initial/'ledger.json'),old_report['output_sha256']['ledger.json'],'initial ledger association')
equal(sha(parent/'packet_wrapper_initial.py'),old_report['source_sha256']['tools/export_packet_source_ledger.py'],'initial wrapper association')
for name in ('mhdlab/window_source_ledger.py','tools/export_packet_source_ledger.py','tools/export_window_source_ledger.py'):
    equal(sha(repo/name),report['source_sha256'][name],'final numerical/export code pin')
equal(ledger['component_count'],48,'declared original components')
equal(ledger['host_budget_accepted'],False,'ledger host acceptance')
equal(typed_json(ledger['skipped_zero_initials']),typed_json(source['skipped_zero_initials']),'zero-initial association')
pools=source['source_reservoirs']
states=tuple(dict.fromkeys(pool['state_id'] for pool in pools))
equal(len(pools),2,'parent pools');equal(len(states),2,'parent states')
x=tuple(F(value) for value in source['x_edges_m']);z=tuple(F(value) for value in source['z_edges_m'])
dx=tuple(b-a for a,b in zip(x[:-1],x[1:]));dz=tuple(b-a for a,b in zip(z[:-1],z[1:]))
W=x[-1]-x[0];L=z[-1]-z[0]
records=[];canonical={};catalog={};next_catalog=0
for index,component in enumerate(source['components']):
    scalar=component['source_window'];pool=scalar['reservoir'];i=component['width_index'];j=component['current_index']
    included=ledger['components'][index]
    equal(typed_json(included['source_window']),typed_json(scalar),'all original component flags/logs retained')
    for name in ('selection_index','interval_index','reservoir_index','current_index','width_index','interval_origin_s'):
        equal(included[name],component[name],'component '+name)
    equal(included['reservoir_name'],pool['name'],'component reservoir name')
    equal(included['state_id'],pool['state_id'],'component state')
    actual=dx[i]*dz[j];declared=F(scalar['patch_area_m2'])
    check_number(included['geometric_patch_area_m2'],actual,'component exact area')
    check_number(included['canonical_minus_geometric_patch_area_m2'],declared-actual,'component signed area residual')
    if (j,i) in canonical:
        equal(canonical[j,i],declared,'same patch once across time/pools')
    canonical[j,i]=declared
    values={};missing={}
    for name in Q:
        q=scalar['quantities'][name]
        equal(type(q['qualified']),bool,'typed qualification')
        equal(type(q['exact_zero']),bool,'typed structural zero')
        if q['qualified']:
            values[name]=F(q['value'])
        else:
            values[name]=None;missing[name]=next_catalog
            catalog[next_catalog]=(index,name,q);next_catalog+=1
    records.append({'index':index,'x':i,'z':j,'pool':component['reservoir_index'],
                    'selection':component['selection_index'],'state':pool['state_id'],
                    'T':F(scalar['temperature_k']),'values':values,'missing':missing})
equal(len(ledger['unqualified_contributors']),next_catalog,'complete consumed-field missing catalog')
for item in ledger['unqualified_contributors']:
    index,name,q=catalog[item['catalog_index']]
    equal(item['component_index'],index,'unqualified source component')
    equal(item['quantity_name'],name,'unqualified source channel')
    equal(typed_json(item['representation']),typed_json(q),'unqualified flags/reason/log retained')

def member(group_type,key,record,destination):
    if group_type=='total':return True
    if group_type=='by_width':return key['width_index']==destination
    if group_type=='by_current':return key['current_index']==record['z']
    if group_type=='by_state':return key['state_id']==record['state']
    if group_type=='by_reservoir':return key['reservoir_index']==record['pool']
    if group_type=='by_selection':return key['selection_index']==record['selection']
    if group_type in ('patch_state','uniform_width_bases'):
        return key['current_index']==record['z'] and key['state_id']==record['state'] and (group_type=='uniform_width_bases' or key['width_index']==destination)
    raise AssertionError(group_type)
def patches(group_type,key):
    return tuple((j,i) for j in range(len(dz)) for i in range(len(dx))
                 if (group_type not in ('by_current','patch_state','uniform_width_bases') or j==key['current_index'])
                 and (group_type not in ('by_width','patch_state') or i==key['width_index']))
group_checks=0;empty_complete_internal=positive_internal=0
group_objects={}
for hypothesis in ('resolved','matched_uniform_width'):
    for category,container in ledger[hypothesis].items():
        items=[container] if category=='total' else container
        for group_index,group in enumerate(items):
            key=group['key'];p=patches(category,key)
            area=sum((dx[i]*dz[j] for j,i in p),ZERO)
            canon=sum((canonical[j,i] for j,i in p),ZERO)
            equal(rational(group['area']['exact_m2']),area,'unique declared geometric group area')
            check_number(group['area']['canonical_patch_area_sum'],canon,'canonical unique area')
            check_number(group['area']['canonical_minus_exact_residual_m2'],canon-area,'canonical-minus-geometry group area')
            subtotal={name:ZERO for name in Q};missing={name:set() for name in Q};contributing=set();expected_thermal=ZERO
            for record in records:
                destinations=range(len(dx)) if hypothesis=='matched_uniform_width' else (record['x'],)
                for destination in destinations:
                    if not member(category,key,record,destination):continue
                    scale=dx[destination]/W if hypothesis=='matched_uniform_width' else F(1)
                    contributing.add(record['index'])
                    for name in Q:
                        if record['values'][name] is None:missing[name].add(record['missing'][name])
                        else:subtotal[name]+=record['values'][name]*scale
                    if record['values']['released_number'] is not None:
                        expected_thermal+=record['values']['released_number']*2*KB*record['T']*scale
            equal(group['component_count'],len(contributing),'unique contributing component count')
            equal(group['host_budget_accepted'],False,'group host acceptance')
            for name in Q:
                amount=group['quantities'][name];available=not missing[name]
                equal(amount['available'],available,'per-channel availability')
                equal(amount['unqualified']['count'],len(missing[name]),'per-channel unavailable count')
                check_number(amount['qualified_subtotal'],subtotal[name],'qualified subtotal')
                check_number(amount['per_area']['qualified_subtotal'],subtotal[name]/area,'density qualified subtotal')
                if available:
                    check_number(amount,subtotal[name],'complete amount')
                    equal(amount['per_area']['available'],True,'complete density')
                    check_number(amount['per_area'],subtotal[name]/area,'complete density once')
                else:
                    equal(amount['exact_sum'],None,'incomplete exact amount')
                    equal(amount['value'],None,'incomplete amount')
                    equal(amount['per_area']['available'],False,'incomplete density')
                if name=='internal_energy_j' and available:
                    if subtotal[name]==0:empty_complete_internal+=1
                    else:positive_internal+=1
            energy_available=not any(missing[name] for name in Q[1:])
            residual=group['residuals']['wall_minus_parts_j']
            equal(residual['available'],energy_available,'wall closure availability')
            if energy_available:check_number(residual,subtotal[Q[-1]]-sum((subtotal[name] for name in Q[1:-1]),ZERO),'signed wall-minus-parts')
            thermal_available=not missing[Q[0]] and not missing[Q[1]]
            residual=group['residuals']['translation_minus_count_2kbt_j']
            equal(residual['available'],thermal_available,'thermal residual availability')
            if thermal_available:check_number(residual,subtotal[Q[1]]-expected_thermal,'signed translation-minus-count2kBT')
            if not missing[Q[0]]:check_number(group['residuals']['count_times_2kbt_j'],expected_thermal,'source count2kBT')
            group_objects[hypothesis,category,group_index]=group
            group_checks+=1
# The four current/state mixture bases retain the same extensive channels.
for group in ledger['uniform_width_bases']:
    key=group['key']
    selected=[record for record in records if record['z']==key['current_index'] and record['state']==key['state_id']]
    area=W*dz[key['current_index']]
    equal(rational(group['area']['exact_m2']),area,'base unique area')
    for name in Q:
        equal(group['quantities'][name]['available'],all(record['values'][name] is not None for record in selected),'base availability')
        if group['quantities'][name]['available']:
            check_number(group['quantities'][name],sum((record['values'][name] for record in selected),ZERO),'factored base amount')
with (folder/'ledger.csv').open(newline='') as stream:
    csv_rows=list(csv.DictReader(stream))
for row in csv_rows:
    group=group_objects[row['hypothesis'],row['group_type'],int(row['group_index'])]
    amount=group['quantities'][row['quantity']]
    equal(int(row['available']),int(amount['available']),'CSV availability')
    equal(float(row['area_m2']),group['area']['value_m2'],'CSV area')
    equal(float(row['value']) if row['value'] else None,amount['value'],'CSV amount')
    equal(float(row['qualified_subtotal_value']),amount['qualified_subtotal']['value'],'CSV subtotal')
    equal(float(row['per_area_value']) if row['per_area_value'] else None,amount['per_area']['value'],'CSV density')
    equal(int(row['unqualified_count']),amount['unqualified']['count'],'CSV missing count')
    for prefix,projection in (('',amount['projection']),('qualified_subtotal_',amount['qualified_subtotal']['projection']),
                              ('per_area_',amount['per_area']['projection']),('per_area_qualified_subtotal_',amount['per_area']['qualified_subtotal']['projection'])):
        for flag in ('exact_zero','positive','negative','finite','underflowed','overflowed','rounded','subnormal'):
            equal(int(row[prefix+flag]),int(projection[flag]),'CSV projection flag')

table=[];exact_table=[]
for category in ('by_reservoir','by_state'):
    for index,group in enumerate(ledger['resolved'][category]):
        matching=ledger['matched_uniform_width'][category][index]
        equal(typed_json(group),typed_json(matching),'non-width group unchanged exactly')
        values={name:rational(group['quantities'][name]['exact_sum']) for name in Q}
        n=values['released_number']
        row={'group_type':category,**group['key'],'declared_source_parents':float(n),
             'translation_j':float(values[Q[1]]),'internal_j':float(values[Q[2]]),'removal_j':float(values[Q[3]]),
             'total_wall_debit_j':float(values[Q[4]]),
             'wall_minus_parts_j':group['residuals']['wall_minus_parts_j']['value'],
             'translation_minus_count_2kbT_j':group['residuals']['translation_minus_count_2kbt_j']['value']}
        for label,name in zip(('translation','internal','removal','total_wall'),Q[1:]):
            row['mean_'+label+'_ev_per_declared_source_parent']=float(values[name]/n/QE) if n else None
        row['all_channels_available']=all(group['quantities'][name]['available'] for name in Q)
        row['matched_width_group_exactly_equal']=True
        table.append(row)
        exact_table.append({'key':group['key'],'group_type':category,
            'channels':{name:{'available':group['quantities'][name]['available'],**number(values[name]),
                              'projection':group['quantities'][name]['projection']} for name in Q},
            'signed_wall_minus_parts_j':group['residuals']['wall_minus_parts_j'],
            'signed_translation_minus_count2kbT_j':group['residuals']['translation_minus_count_2kbt_j']})
csv_path=work/'energy_channels.csv'
fields=[]
for row in table:
    for name in row:
        if name not in fields:fields.append(name)
with csv_path.open('w',newline='') as stream:
    writer=csv.DictWriter(stream,fieldnames=fields,lineterminator='\n');writer.writeheader();writer.writerows(table)
summary={
    'schema':'mhdlab-saved-two-state-parent-energy-channel-readback-v1','parameter_status':'manufactured',
    'original_source_report_sha256':sha(original),'final_wrapper_report_sha256':sha(folder/'report.json'),
    'ledger_json_sha256':sha(folder/'ledger.json'),'ledger_csv_sha256':sha(folder/'ledger.csv'),
    'initial_ledger_json_sha256':sha(initial/'ledger.json'),'initial_ledger_report_sha256':sha(initial/'report.json'),
    'reviewed_source_sha256':{name:report['source_sha256'][name] for name in ('mhdlab/window_source_ledger.py','tools/export_packet_source_ledger.py','tools/export_window_source_ledger.py')},
    'checked_original_components':len(records),'checked_resolved_matched_groups':group_checks,
    'checked_uniform_width_bases':len(ledger['uniform_width_bases']),'checked_ledger_csv_rows':len(csv_rows),
    'complete_zero_internal_groups':empty_complete_internal,'positive_internal_groups':positive_internal,
    'exact_or_projected_checks_passed':checks,'unqualified_contributors':next_catalog,
    'ledger_unchanged_after_admission_guard':True,'energy_channels':exact_table,
    'energy_channel_csv_sha256':sha(csv_path),'open_substantive_findings':[],
    'normalization':'Any eV ratio is total declared deterministic source energy divided by the declared released source-parent count and the SI eV conversion; not a photon, electron, daughter-species, rovibrational or experimental yield normalization.',
    'limits':['All parent states, reservoirs, thermal inputs and removal/internal costs are manufactured declarations.',
              'Source count, expected translation, internal cost, removal and full wall debit remain distinct; signed source rounding residuals are retained without repair.',
              'Exact counts/energies are represented-source sums; their physical model and numerical qualification are not re-derived here.',
              'No ledger/reducer/source/model modules are imported, and no source, law, moment, packet or old oracle/suite is rerun.',
              'No host acceptance, physical water, material calibration, transport or spectrum is computed.']
}
(work/'energy_channels.json').write_text(json.dumps(summary,indent=2,allow_nan=False)+'\n')
print(json.dumps({key:value for key,value in summary.items() if key!='energy_channels'},indent=2,allow_nan=False))
