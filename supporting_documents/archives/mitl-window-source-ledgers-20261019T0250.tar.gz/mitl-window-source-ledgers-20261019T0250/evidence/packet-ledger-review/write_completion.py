"""Pin the new saved-packet ledger readback without executing any models."""
import hashlib
import json
from pathlib import Path

work=Path(__file__).resolve().parent
parent=work.parent
repo=Path('/workspace/Power-Flow')
folder=parent/'saved-packet-ledger'
initial=parent/'saved-packet-ledger-initial'
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
readback=json.loads((work/'energy_channels.json').read_text())
report=json.loads((folder/'report.json').read_text())
old=json.loads((initial/'report.json').read_text())
for name,digest in readback['reviewed_source_sha256'].items():
    if sha(repo/name)!=digest:
        raise SystemExit('Reviewed code changed: '+name)
if sha(folder/'report.json')!=readback['final_wrapper_report_sha256']:
    raise SystemExit('Reviewed export report changed')
if sha(folder/'ledger.json')!=sha(initial/'ledger.json') or sha(folder/'ledger.csv')!=sha(initial/'ledger.csv'):
    raise SystemExit('Admission-only change altered a saved ledger')
artifacts={
    'packet-ledger-review/'+name:sha(work/name) for name in (
        'readback.py','energy_channels.csv','energy_channels.json','write_completion.py')
}
for directory,prefix,data in ((folder,'saved-packet-ledger/',report),(initial,'saved-packet-ledger-initial/',old)):
    artifacts[prefix+'report.json']=sha(directory/'report.json')
    for name,digest in data['output_sha256'].items():
        if sha(directory/name)!=digest:
            raise SystemExit('Exported input/output changed: '+prefix+name)
        artifacts[prefix+name]=digest
artifacts['packet_wrapper_initial.py']=sha(parent/'packet_wrapper_initial.py')
log=parent/'saved_packet_ledger_readback.log'
artifacts[log.name]=sha(log)
records=[json.loads(line) for line in (parent/'commands.jsonl').read_text().splitlines()]
records=[record for record in records if Path(record['log']).name==log.name]
if len(records)!=1 or records[0]['exit_code']!=0 or records[0]['log_sha256']!=sha(log):
    raise SystemExit('Readback command evidence mismatch')
completion={
    'schema':'mhdlab-saved-two-state-packet-ledger-independent-review-v1',
    'status':'passed','open_substantive_findings':[],'closed_substantive_findings':[],
    'reviewed_source_sha256':readback['reviewed_source_sha256'],
    'reviewed_export_report_sha256':sha(folder/'report.json'),
    'reviewed_ledger_json_sha256':sha(folder/'ledger.json'),
    'reviewed_ledger_csv_sha256':sha(folder/'ledger.csv'),
    'artifact_path_root':str(parent),'artifact_sha256':artifacts,
    'original_conditioned_source_report_sha256':readback['original_source_report_sha256'],
    'initial_ledger_json_sha256':sha(initial/'ledger.json'),
    'ledger_json_and_csv_byteidentical_after_admission_only_change':True,
    'checks':{name:readback[name] for name in (
        'checked_original_components','checked_resolved_matched_groups','checked_uniform_width_bases',
        'checked_ledger_csv_rows','complete_zero_internal_groups','positive_internal_groups',
        'exact_or_projected_checks_passed','unqualified_contributors')},
    'energy_channel_table':{
        'csv':'packet-ledger-review/energy_channels.csv',
        'csv_sha256':sha(work/'energy_channels.csv'),
        'json':'packet-ledger-review/energy_channels.json',
        'json_sha256':sha(work/'energy_channels.json'),
        'rows':4,'groupings':['by_reservoir','by_state'],
        'quantities':['declared_source_parents','translation_j','internal_j','removal_j','total_wall_debit_j'],
        'normalization':readback['normalization'],
    },
    'review_conclusions':[
        'All consumed source qualification/structural-zero flags, logarithms and component associations are retained through typed JSON comparison with the preserved original conditioned source.',
        'All five extensive channels match independent sums in total, width, current, exact state, reservoir, original selection and patch-state groups.',
        'Group densities use their unique full declared geometry once; canonical-minus-geometric signed area residuals remain separate.',
        'Naive component-to-destination-width enumeration matches the factored matched-width groups and current/state bases, including non-width invariance.',
        'Signed full-wall-minus-translation-minus-internal-minus-removal and translation-minus-count-times2kBT residuals match the original represented component fields without repair.',
        'The original state-A zero internal cost remains complete structural zero, while state-B positive internal cost remains a positive complete quantity.',
        'All exported CSV amounts, density values, availability and projection flags match authoritative ledger JSON.',
        'Final ledger JSON and CSV are byte-identical to the initial export; typed admission changes affect validation and code/report pins, not ledger values.',
    ],
    'readback_command':records[0],
    'parameter_status':'manufactured','host_budget_accepted':False,
    'ledger_or_reducer_or_model_modules_imported':False,
    'source_law_or_moment_or_packet_or_history_rerun':False,
    'old_oracles_or_verification_suites_repeated':False,
    'public_files_edited':False,
    'limits':[
        'This is a new saved two-pool/two-state positive-internal-energy qualification, complementary to the separate one-pool zero-internal-cost study.',
        'Only standard-library JSON/CSV/Fraction arithmetic and byte hashing are used; no ledger/source/reducer/owned solver calls occur.',
        'Budgets and any eV-per-parent ratios refer to manufactured declared source parents. They do not establish molecular level assignment, photon normalization, daughter yields or experimental spectra.',
        'Expected source translation remains separate from the saved packet realization and its sampling uncertainty.',
        'No host transaction, physical water/material parameter, wall feedback, transport or radiation claim is made.',
        'The completion is tied to exact code/artifact hashes.',
    ],
}
path=work/'completion.json'
path.write_text(json.dumps(completion,indent=2,allow_nan=False)+'\n')
print(json.dumps({'completion':str(path),'sha256':sha(path),'status':'passed',
                  'energy_channels_csv_sha256':sha(work/'energy_channels.csv'),
                  'energy_channels_json_sha256':sha(work/'energy_channels.json'),
                  'open_substantive_findings':[]},indent=2))
