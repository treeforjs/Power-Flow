"""Associate new exact ledger references with the prior saved source profiles."""
import csv
from fractions import Fraction
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
PROFILE=Path('/workspace/research_work/mitl-upstream-20261019T0150/profile-reduction/artifacts')

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def fraction(record): return Fraction(int(record['numerator']),int(record['denominator']))

def main():
    reference=json.loads((HERE/'reference.json').read_text())
    profiles=json.loads((PROFILE/'report.json').read_text())
    csv_path=PROFILE/'width_profiles.csv'
    if sha(csv_path)!=profiles['output_sha256']['width_profiles.csv']:
        raise ValueError('prior width-profile CSV hash association failed')
    by_id={(case['case_id'],case['window_index']):case for case in reference['case_windows']}
    with csv_path.open(newline='') as handle:
        rows=list(csv.DictReader(handle))
    checks=[]
    for row in rows:
        case=by_id[(row['case_id'],int(row['window_index']))]
        for hypothesis,prefix in (('resolved','resolved'),('matched_uniform_width','matched_uniform_width')):
            group=next(group for group in case[hypothesis]['by_width'] if group['key']['width_index']==int(row['width_index']))
            n=group['channels']['released_number']
            e=group['channels']['translational_energy_j']
            assert n['complete'] and e['complete']
            quantity_checks={
                prefix+'_released_number':fraction(n['exact_total']),
                prefix+'_translational_energy_j':fraction(e['exact_total']),
                prefix+'_released_areal_density_m2':fraction(n['areal_density']),
                prefix+'_translational_energy_areal_density_j_m2':fraction(e['areal_density']),
                prefix+'_expected_translational_energy_per_parent_j':fraction(group['energy_per_released_parent']['translational_energy_j']),
            }
            for name,expected in quantity_checks.items():
                actual=float(row[name])
                if actual!=float(expected):
                    raise AssertionError((row['case_id'],row['window_index'],row['width_index'],name,actual,float(expected)))
                checks.append({'case_id':row['case_id'],'window_index':int(row['window_index']),
                    'width_index':int(row['width_index']),'observable':name,'represented_projection_identical':True})
    total_checks=[]
    for prior in profiles['profiles']:
        case=by_id[(prior['case_id'],prior['window_index'])]
        total=case['resolved']['total'][0]
        for channel in ('released_number','translational_energy_j'):
            expected=fraction(total['channels'][channel]['exact_total'])
            assert float(expected)==prior[channel]
            total_checks.append({'case_id':prior['case_id'],'window_index':prior['window_index'],
                'channel':channel,'represented_projection_identical':True})
    result={'schema':'mitl-saved-ledger-prior-profile-comparison-v1',
        'input_files_sha256':{str(HERE/'reference.json'):sha(HERE/'reference.json'),
            str(PROFILE/'report.json'):sha(PROFILE/'report.json'),str(csv_path):sha(csv_path)},
        'script_sha256':sha(__file__),'source_model_or_ledger_routines_called':False,
        'width_profile_rows':len(rows),'width_quantity_projection_checks':len(checks),'total_projection_checks':len(total_checks),
        'all_comparisons_passed':True,'checks':checks,'total_checks':total_checks,
        'limits':['Agreement concerns identical quantities from the preserved manufactured source manifests.',
            'Internal, binding and total wall channels are new ledger analysis; the previous profile did not report them.',
            'No source evolution, moment quadrature or physical validation was repeated.']}
    target=HERE/'prior-profile-comparison.json'
    with target.open('x') as handle: handle.write(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'output':str(target),'sha256':sha(target),'width_quantity_projection_checks':len(checks),
        'total_projection_checks':len(total_checks),'all_comparisons_passed':True},indent=2))

if __name__=='__main__': main()
