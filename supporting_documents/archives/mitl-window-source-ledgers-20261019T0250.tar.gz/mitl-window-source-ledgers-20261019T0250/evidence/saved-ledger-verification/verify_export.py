"""Read back saved ledger exports against the independent manifest reference.

An explicit bindings file identifies each exported JSON ledger's original
case/window. The bindings have schema mitl-ledger-readback-bindings-v1 and a
ledgers list of {case_id, window_index, ledger_file, ledger_sha256}. No public
source, moment or ledger implementation is imported.
"""
import argparse
import csv
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path
import sys


HERE=Path(__file__).resolve().parent
CHANNELS=('released_number','translational_energy_j','internal_energy_j','binding_energy_j','total_wall_energy_debit_j')
GROUP_KEYS={'total':(), 'by_width':('width_index',),'by_current':('current_index',),
    'by_state':('state_id',),'by_reservoir':('reservoir_index',),'by_selection':('selection_index',),
    'patch_state':('current_index','state_id','width_index')}


def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path): return json.loads(Path(path).read_bytes())
def fraction(record): return Fraction(int(record['numerator']),int(record['denominator']))
def scalar(value):
    try: result=float(value)
    except OverflowError: return None
    return result if math.isfinite(result) else None


def compare_ledger(ledger,reference,source):
    if ledger['schema']!='mhdlab-window-source-ledger-v1': raise ValueError('unsupported ledger schema')
    checked=0
    rows_checked=0
    partitions_checked=0
    projection_checks=0
    def check_number(record,value):
        nonlocal projection_checks
        represented=scalar(value)
        assert fraction(record['exact_sum'])==value
        assert record['value']==represented
        error=None if represented is None else Fraction(represented)-value
        flags={'exact_zero':value==0,'positive':value>0,'negative':value<0,'finite':represented is not None,
            'underflowed':bool(value and represented==0.),'overflowed':represented is None,
            'rounded':error is None or error!=0,
            'subnormal':represented is not None and 0<abs(represented)<sys.float_info.min}
        for name,expected in flags.items():
            assert type(record['projection'][name]) is bool and record['projection'][name]==expected,(name,value)
        if error is None: assert record['projection']['exact_rounding_error'] is None
        else: assert fraction(record['projection']['exact_rounding_error'])==error
        projection_checks+=1
    x=list(map(Fraction,source['x_edges_m']))
    z=list(map(Fraction,source['z_edges_m']))
    canonical={(j,i):Fraction((source['x_edges_m'][i+1]-source['x_edges_m'][i])*(source['z_edges_m'][j+1]-source['z_edges_m'][j]))
        for j in range(len(z)-1) for i in range(len(x)-1)}
    def canonical_area(kind,key):
        return sum((area for (j,i),area in canonical.items()
            if (kind not in ('by_width','patch_state') or i==key['width_index'])
            and (kind not in ('by_current','patch_state') or j==key['current_index'])),Fraction())
    assert ledger['component_count']==len(source['components'])==len(reference['components'])
    assert ledger['quantity_units']=={name:'parent' if name=='released_number' else 'J' for name in CHANNELS}
    assert ledger['density_units']=={name:'parent m^-2' if name=='released_number' else 'J m^-2' for name in CHANNELS}
    assert ledger['components_included'] is True and ledger['host_budget_accepted'] is False
    assert len(ledger['components'])==len(reference['components'])
    for actual,expected,original in zip(ledger['components'],reference['components'],source['components']):
        for name in ('component_index','selection_index','interval_index','reservoir_index','current_index','width_index',
                     'interval_origin_s','x_bounds_m','z_bounds_m','state_id','reservoir_name'):
            assert actual[name]==expected[name],('component association',name)
        assert actual['source_window']==original['source_window']
        area=fraction(expected['actual_geometry_area_m2'])
        check_number(actual['geometric_patch_area_m2'],area)
        check_number(actual['canonical_minus_geometric_patch_area_m2'],Fraction(expected['source_patch_area_m2'])-area)
    assert ledger['skipped_zero_initials']==source['skipped_zero_initials']
    assert ledger['geometry']['x_edges_m']==source['x_edges_m'] and ledger['geometry']['z_edges_m']==source['z_edges_m']
    assert ledger['geometry']['time_edges_s']==source['time_edges_s']
    assert ledger['source_association']=={name:source[name] for name in ('status','provenance','parameter_provenance',
        'log_mass_tolerance','surface_attributes','source_reservoirs','selections')}
    unavailable=[]
    for index,original in enumerate(source['components']):
        for name in CHANNELS:
            quantity=original['source_window']['quantities'][name]
            if not quantity['qualified']: unavailable.append((index,name,quantity))
    assert len(ledger['unqualified_contributors'])==len(unavailable)
    for index,(actual,(component_index,name,quantity)) in enumerate(zip(ledger['unqualified_contributors'],unavailable)):
        assert actual['catalog_index']==index and actual['component_index']==component_index
        assert actual['quantity_name']==name and actual['representation']==quantity
        assert actual['positive']==(not quantity['exact_zero'])
    bases={}
    for index,base in enumerate(ledger['uniform_width_bases']):
        identity=(base['key']['current_index'],base['key']['state_id'])
        assert identity not in bases
        bases[identity]=(index,base)
        original=[entry for entry in reference['resolved']['patch_state']
            if entry['key']['current_index']==identity[0] and entry['key']['state_id']==identity[1]]
        area=(x[-1]-x[0])*(z[identity[0]+1]-z[identity[0]])
        assert fraction(base['area']['exact_m2'])==area
        assert base['component_count']==len(set(ci for entry in original for ci in entry['component_indices']))
        for name in CHANNELS:
            parts=[entry['channels'][name] for entry in original]
            assert base['quantities'][name]['available']==all(entry['complete'] for entry in parts)
            if all(entry['complete'] for entry in parts):
                amount=sum((fraction(entry['exact_total']) for entry in parts),Fraction())
                check_number(base['quantities'][name],amount)
                check_number(base['quantities'][name]['per_area'],amount/area)
    assert set(bases)=={(j,state) for j in range(len(z)-1) for state in {pool['state_id'] for pool in source['source_reservoirs']}}
    residuals=[]
    for hypothesis in ('resolved','matched_uniform_width'):
        for kind,keys in GROUP_KEYS.items():
            actual_rows=ledger[hypothesis][kind]
            if isinstance(actual_rows,dict): actual_rows=[actual_rows]
            expected_rows=reference[hypothesis][kind]
            def identity(row): return tuple(row['key'][key] for key in keys)
            actual_by_key={identity(row):row for row in actual_rows}
            expected_by_key={identity(row):row for row in expected_rows}
            if len(actual_by_key)!=len(actual_rows) or set(actual_by_key)!=set(expected_by_key):
                raise AssertionError((hypothesis,kind,'group key support changed'))
            for key,expected in expected_by_key.items():
                actual=actual_by_key[key]
                expected_area=fraction(expected['area_m2'])
                assert fraction(actual['area']['exact_m2'])==expected_area,(hypothesis,kind,key,'area')
                area_record={'exact_sum':actual['area']['exact_m2'],'value':actual['area']['value_m2'],'projection':actual['area']['projection']}
                check_number(area_record,expected_area)
                declared=canonical_area(kind,actual['key'])
                check_number(actual['area']['canonical_patch_area_sum'],declared)
                check_number(actual['area']['canonical_minus_exact_residual_m2'],declared-expected_area)
                assert actual['component_count']==len(expected['component_indices'])
                assert actual['host_budget_accepted'] is False
                if hypothesis=='matched_uniform_width' and kind in ('by_width','patch_state'):
                    xi=actual['key']['width_index']
                    factor=(x[xi+1]-x[xi])/(x[-1]-x[0])
                    assert fraction(actual['redistribution']['fraction'])==factor
                    if kind=='by_width': expected_ref='resolved/total'
                    else:
                        base_index,_=bases[(actual['key']['current_index'],actual['key']['state_id'])]
                        expected_ref='uniform_width_bases/'+str(base_index)
                    assert actual['redistribution']['source_group_ref']==expected_ref
                rows_checked+=1
                for name in CHANNELS:
                    supplied=actual['quantities'][name]
                    target=expected['channels'][name]
                    assert supplied['available']==target['complete'],(hypothesis,kind,key,name,'availability')
                    assert type(supplied['available']) is bool
                    subtotal=fraction(target['qualified_subtotal'])
                    check_number(supplied['qualified_subtotal'],subtotal)
                    check_number(supplied['per_area']['qualified_subtotal'],subtotal/expected_area)
                    assert supplied['per_area']['available']==target['complete']
                    assert supplied['unqualified']['count']==len(target['unqualified_components'])
                    if target['complete']:
                        value=fraction(target['exact_total'])
                        check_number(supplied,value)
                        check_number(supplied['per_area'],value/expected_area)
                    else:
                        assert supplied['exact_sum'] is None and supplied['value'] is None and supplied['projection'] is None
                        assert supplied['per_area']['exact_sum'] is None and supplied['per_area']['value'] is None and supplied['per_area']['projection'] is None
                    checked+=1
                # Compare the signed supplied wall-energy residual rather
                # than requiring rounded independent source channels to close.
                if expected['wall_minus_translation_internal_binding_j'] is not None:
                    q=actual['quantities']
                    residual=fraction(q['total_wall_energy_debit_j']['exact_sum'])-sum((fraction(q[name]['exact_sum']) for name in CHANNELS[1:4]),Fraction())
                    assert residual==fraction(expected['wall_minus_translation_internal_binding_j'])
                    assert actual['residuals']['wall_minus_parts_j']['available'] is True
                    check_number(actual['residuals']['wall_minus_parts_j'],residual)
                    residuals.append({'hypothesis':hypothesis,'group':kind,'key':actual['key'],
                        'signed_wall_minus_components_j':scalar(residual),
                        'exact_sum':{'numerator':str(residual.numerator),'denominator':str(residual.denominator)}})
        total=ledger[hypothesis]['total']
        if isinstance(total,list): total=total[0]
        for kind in GROUP_KEYS:
            if kind=='total': continue
            rows=ledger[hypothesis][kind]
            for name in CHANNELS:
                quantities=[row['quantities'][name] for row in rows]
                if all(quantity['available'] for quantity in quantities) and total['quantities'][name]['available']:
                    amount=sum((fraction(quantity['exact_sum']) for quantity in quantities),Fraction())
                    assert amount==fraction(total['quantities'][name]['exact_sum']),(hypothesis,kind,name,'partition')
                    area_integral=sum((fraction(row['quantities'][name]['per_area']['exact_sum'])*fraction(row['area']['exact_m2']) for row in rows),Fraction())
                    assert area_integral==amount,(hypothesis,kind,name,'area-weighted closure')
                    partitions_checked+=1
    for kind in ('total','by_current','by_state','by_reservoir','by_selection'):
        for name in CHANNELS:
            a=ledger['resolved'][kind]
            b=ledger['matched_uniform_width'][kind]
            if isinstance(a,dict): a,b=[a],[b]
            def key(row): return tuple(row['key'][field] for field in GROUP_KEYS[kind])
            original={key(row):row['quantities'][name] for row in a}
            redistributed={key(row):row['quantities'][name] for row in b}
            for group_key in original:
                qa,qb=original[group_key],redistributed[group_key]
                assert qa['available']==qb['available']
                if qa['available']: assert fraction(qa['exact_sum'])==fraction(qb['exact_sum'])
    return {'group_rows_checked':rows_checked,'channel_groups_checked':checked,
        'component_associations_checked':len(reference['components']),'unqualified_extensive_contributors':len(unavailable),
        'exact_numbers_and_projection_flags_checked':projection_checks,
        'partitions_and_area_integrals_checked':partitions_checked,'signed_wall_energy_residuals':residuals}


def compare_csv(path,ledgers):
    flags=('exact_zero','positive','negative','finite','underflowed','overflowed','rounded','subnormal')
    checks=0
    seen=set()
    def numeric_cell(row,name,value):
        nonlocal checks
        if value is None: assert row[name]=='',(name,row[name],value)
        else: assert float(row[name])==value,(name,row[name],value)
        checks+=1
    def projection_cells(row,prefix,projection):
        nonlocal checks
        for flag in flags:
            expected='' if projection is None else str(int(projection[flag]))
            assert row[prefix+flag]==expected,(prefix+flag,row[prefix+flag],expected)
            checks+=1
    with path.open(newline='') as handle:
        rows=list(csv.DictReader(handle))
    for row in rows:
        case_id,window_index=row['case_id'],int(row['window_index'])
        hypothesis,kind,name=row['hypothesis'],row['group_type'],row['quantity']
        group_index=int(row['group_index'])
        identity=(case_id,window_index,hypothesis,kind,group_index,name)
        assert identity not in seen
        seen.add(identity)
        ledger=ledgers[(case_id,window_index)]
        groups=ledger[hypothesis][kind]
        group=groups if kind=='total' else groups[group_index]
        if kind=='total': assert group_index==0
        for key in ('width_index','current_index','state_id','reservoir_index','reservoir_name','selection_index'):
            assert row[key]==str(group['key'].get(key,'')),(identity,key)
        quantity=group['quantities'][name]
        numeric_cell(row,'area_m2',group['area']['value_m2'])
        projection_cells(row,'area_',group['area']['projection'])
        assert row['unit']==('parent' if name=='released_number' else 'J')
        assert row['per_area_unit']==row['unit']+' m^-2'
        for prefix,q in (('',quantity),('per_area_',quantity['per_area'])):
            assert row[prefix+'available']==str(int(q['available']))
            assert row[prefix+'availability_reason']==('complete_qualified_aggregation' if q['available'] else 'unqualified_contributors')
            numeric_cell(row,prefix+'value',q['value'])
            projection=q['projection']
            reason=('not_available' if projection is None else 'si_projection_overflow' if projection['overflowed']
                    else 'si_projection_underflow' if projection['underflowed'] else 'represented')
            assert row[prefix+'projection_reason']==reason
            projection_cells(row,prefix,projection)
            numeric_cell(row,prefix+'qualified_subtotal_value',q['qualified_subtotal']['value'])
            projection_cells(row,prefix+'qualified_subtotal_',q['qualified_subtotal']['projection'])
        assert row['unqualified_count']==str(quantity['unqualified']['count'])
        assert row['unqualified_source_group_ref']==quantity['unqualified'].get('source_group_ref','')
    expected_rows=sum(sum((1 if kind=='total' else len(groups))*len(CHANNELS) for kind,groups in ledger[hyp].items())
        for ledger in ledgers.values() for hyp in ('resolved','matched_uniform_width'))
    assert len(rows)==expected_rows
    return {'csv_rows_checked':len(rows),'csv_numeric_and_flag_cells_checked':checks}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    mode=parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--bindings',type=Path)
    mode.add_argument('--export-dir',type=Path)
    parser.add_argument('--output',type=Path,default=HERE/'verification.json')
    args=parser.parse_args()
    if args.output.exists(): raise ValueError('verification output already exists')
    references=read(HERE/'reference.json')
    by_key={(record['case_id'],record['window_index']):record for record in references['case_windows']}
    inputs={str(HERE/'reference.json'):sha(HERE/'reference.json')}
    if args.export_dir is not None:
        export_report_path=args.export_dir/'report.json'
        export_report=read(export_report_path)
        assert export_report['schema']=='mhdlab-window-source-ledger-export-v1'
        assert export_report['parameter_status']=='manufactured'
        for name in ('source_evolution_repeated','source_moment_quadrature_repeated','packet_sampling_performed','host_budget_accepted'):
            assert export_report[name] is False
        inputs[str(export_report_path)]=sha(export_report_path)
        for name,digest in export_report['output_sha256'].items():
            path=args.export_dir/name
            if not path.resolve().is_relative_to(args.export_dir.resolve()) or path.is_symlink() or sha(path)!=digest:
                raise ValueError('export output hash mismatch: '+name)
            inputs[str(path)]=digest
        original=Path('/workspace/research_work/mitl-upstream-20261019T0150/snapshot-window-study')
        assert export_report['study_report_sha256']==references['input_files_sha256'][str(original/'report.json')]
        for name,digest in export_report['input_study_sha256'].items():
            assert digest==references['input_files_sha256'][str(original/name)]
        bindings={'schema':'mitl-ledger-readback-bindings-v1','export_report_sha256':sha(export_report_path),'ledgers':[]}
        for case_id,filename in export_report['case_ledger_files'].items():
            path=args.export_dir/filename
            case=read(path)
            assert case['schema']=='mhdlab-window-source-ledger-case-v1' and case['case_id']==case_id
            for window in case['windows']:
                bindings['ledgers'].append({'case_id':case_id,'window_index':window['window_index'],
                    'ledger_file':str(path.resolve()),'ledger_sha256':sha(path)})
        binding_path=HERE/'bindings.json'
        with binding_path.open('x') as handle: handle.write(json.dumps(bindings,indent=2,allow_nan=False)+'\n')
        args.bindings=binding_path
    else:
        bindings=read(args.bindings)
    if bindings['schema']!='mitl-ledger-readback-bindings-v1': raise ValueError('unsupported bindings schema')
    inputs[str(args.bindings)]=sha(args.bindings)
    results=[]
    ledgers={}
    seen=set()
    for binding in bindings['ledgers']:
        key=(binding['case_id'],binding['window_index'])
        if key in seen: raise ValueError('duplicate bound ledger')
        seen.add(key)
        path=Path(binding['ledger_file'])
        if not path.is_absolute(): path=args.bindings.parent/path
        if path.is_symlink() or sha(path)!=binding['ledger_sha256']: raise ValueError('bound ledger hash mismatch')
        inputs[str(path.resolve())]=sha(path)
        payload=read(path)
        if payload.get('schema')=='mhdlab-window-source-ledger-case-v1':
            assert payload['case_id']==key[0]
            selected=next(window for window in payload['windows'] if window['window_index']==key[1])
            assert selected['window']==by_key[key]['window']
            payload=selected['ledger']
        original_case_path=Path('/workspace/research_work/mitl-upstream-20261019T0150/snapshot-window-study')/('case_'+key[0]+'.json')
        assert sha(original_case_path)==references['input_files_sha256'][str(original_case_path)]
        inputs[str(original_case_path)]=sha(original_case_path)
        original_case=read(original_case_path)
        source=next(window['conditioned_source'] for window in original_case['windows'] if window['window_index']==key[1])
        results.append({'case_id':key[0],'window_index':key[1],**compare_ledger(payload,by_key[key],source)})
        ledgers[key]=payload
    if set(by_key)!=seen: raise ValueError('not every original case/window was independently checked')
    result={'schema':'mitl-independent-saved-window-ledger-readback-v1','input_files_sha256':inputs,
        'script_sha256':sha(__file__),'all_comparisons_passed':True,'case_windows_checked':len(results),
        'source_moment_or_ledger_implementation_called':False,'results':results,
        'group_rows_checked':sum(r['group_rows_checked'] for r in results),
        'channel_groups_checked':sum(r['channel_groups_checked'] for r in results),
        'component_associations_checked':sum(r['component_associations_checked'] for r in results),
        'unqualified_extensive_contributors':sum(r['unqualified_extensive_contributors'] for r in results),
        'exact_numbers_and_projection_flags_checked':sum(r['exact_numbers_and_projection_flags_checked'] for r in results),
        'partitions_and_area_integrals_checked':sum(r['partitions_and_area_integrals_checked'] for r in results),
        'limits':['These are numerical readback controls for preserved manufactured sources, not physical calibration.',
            'Each original qualification is handled independently; this preserved study has no unqualified extensive contributors, so unavailable-contributor edge cases remain separate implementation evidence.',
            'Signed energy residuals are checked and retained without forcing closure or accepting a host budget.']}
    if args.export_dir is not None:
        result.update(compare_csv(args.export_dir/'ledger.csv',ledgers))
    if any(sha(Path(path))!=digest for path,digest in inputs.items()): raise ValueError('verification input changed')
    with args.output.open('x') as handle: handle.write(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'output':str(args.output),'sha256':sha(args.output),
        **{name:result[name] for name in ('case_windows_checked','group_rows_checked','channel_groups_checked','partitions_and_area_integrals_checked')}},indent=2))

if __name__=='__main__': main()
