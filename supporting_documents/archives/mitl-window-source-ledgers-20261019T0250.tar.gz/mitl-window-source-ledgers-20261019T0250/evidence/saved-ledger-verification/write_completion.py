"""Freeze exact evidence associations for the saved source-ledger readback."""
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
WORK=HERE.parent
EXPORT=WORK/'saved-study-ledgers'

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path): return json.loads(Path(path).read_bytes())

verification=read(HERE/'verification.json')
reference=read(HERE/'reference.json')
prior=read(HERE/'prior-profile-comparison.json')
export=read(EXPORT/'report.json')
assert verification['all_comparisons_passed'] is True
assert prior['all_comparisons_passed'] is True
assert sha(HERE/'compare_prior_profile.initial.py')==prior['script_sha256']
assert sha(HERE/'prepare_reference.py')==reference['script_sha256']
assert sha(HERE/'verify_export.py')==verification['script_sha256']
commands=[json.loads(line) for line in (WORK/'commands.jsonl').read_text().splitlines() if line]
labels={'saved-ledger-independent-reference','saved-ledger-prior-profile-reference',
    'saved-ledger-csv-lifetime-check','saved-ledger-export-independent-readback'}
evidence=[record for record in commands if Path(record['log']).stem in labels]
assert len(evidence)==len(labels)
assert all(record['exit_code']==0 and sha(record['log'])==record['log_sha256'] for record in evidence)
paths=[HERE/'reference.json',HERE/'prior-profile-comparison.json',HERE/'bindings.json',HERE/'verification.json',
    HERE/'prepare_reference.py',HERE/'compare_prior_profile.initial.py',HERE/'compare_prior_profile.py',HERE/'verify_export.py']
exact_zero_internal=sum(component['quantities']['internal_energy_j']['exact_zero']
    for case in reference['case_windows'] for component in case['components'])
result={'schema':'mitl-saved-source-ledger-verification-completion-v1',
    'parameter_status':'manufactured','input_export_report':str(EXPORT/'report.json'),
    'input_export_report_sha256':sha(EXPORT/'report.json'),
    'export_implementation_sha256':export['source_sha256'],
    'evidence_sha256':{str(path):sha(path) for path in paths},'completion_script_sha256':sha(__file__),
    'source_evolution_repeated':False,'moment_quadrature_repeated':False,'packet_generation_repeated':False,
    'public_ledger_implementation_imported_by_verifier':False,
    'case_windows_checked':verification['case_windows_checked'],
    'component_associations_checked':verification['component_associations_checked'],
    'group_rows_checked':verification['group_rows_checked'],
    'channel_groups_checked':verification['channel_groups_checked'],
    'exact_numbers_and_projection_flags_checked':verification['exact_numbers_and_projection_flags_checked'],
    'partitions_and_area_integrals_checked':verification['partitions_and_area_integrals_checked'],
    'csv_rows_checked':verification['csv_rows_checked'],
    'csv_numeric_and_flag_cells_checked':verification['csv_numeric_and_flag_cells_checked'],
    'prior_width_profile_rows':prior['width_profile_rows'],
    'prior_width_quantity_projection_checks':prior['width_quantity_projection_checks'],
    'prior_total_projection_checks':prior['total_projection_checks'],
    'unqualified_extensive_contributors':verification['unqualified_extensive_contributors'],
    'exact_zero_internal_energy_components':exact_zero_internal,
    'channels':['released_number','translational_energy_j','internal_energy_j','binding_energy_j','total_wall_energy_debit_j'],
    'groupings':['total','by_width','by_current','by_state','by_reservoir','by_selection','patch_state'],
    'matched_width_controls':'independent direct per-component exact dx/full_width redistribution agrees with factored current/state bases and every reported group; original time/state/temperature/cost components remain associated',
    'closure_controls':'exact extensive and area-weighted partition sums agree; supplied wall-minus-translation/internal/binding residuals retain their signs and values without repair',
    'command_evidence':evidence,
    'limitations':['Every input is preserved manufactured generic-pool source evidence; no physical water calibration, transport, spectra or host budget acceptance is established.',
        'The saved study has no unqualified extensive contributors. Preservation of unavailable contributors is checked structurally here; separate implementation evidence covers unsupported representation ranges.',
        'Internal, binding/removal and full-wall channels are new analysis of already saved source quantities; prior profiles only provided number and translation comparisons.',
        'The first independent prior-profile comparison exited zero with all1296 numerical checks passed and an unclosed-CSV ResourceWarning. Its exact script and log remain preserved; I/O alone was corrected and a new closed-file lifetime check passed, without repeating the unchanged numerical checks.']}
target=HERE/'completion.json'
with target.open('x') as handle: handle.write(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps({'completion':str(target),'sha256':sha(target),
    **{name:result[name] for name in ('case_windows_checked','component_associations_checked','group_rows_checked',
        'channel_groups_checked','exact_numbers_and_projection_flags_checked','partitions_and_area_integrals_checked',
        'csv_rows_checked','csv_numeric_and_flag_cells_checked')}},indent=2))
