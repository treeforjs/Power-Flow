"""Independent exact ledger reference from already saved source manifests.

No history loader, source law, evolution, moment kernel or ledger implementation
is imported. Each extensive channel keeps its individual qualification and
original reasons. Geometric support includes every declared patch and state.
"""
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path


HERE=Path(__file__).resolve().parent
STUDY=Path('/workspace/research_work/mitl-upstream-20261019T0150/snapshot-window-study')
PROFILE=Path('/workspace/research_work/mitl-upstream-20261019T0150/profile-reduction/artifacts')
CHANNELS=('released_number','translational_energy_j','internal_energy_j','binding_energy_j','total_wall_energy_debit_j')
ZERO=Fraction(0)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    def pairs(values):
        result={}
        for key,value in values:
            if key in result: raise ValueError('duplicate JSON key: '+key)
            result[key]=value
        return result
    return json.loads(Path(path).read_bytes(),object_pairs_hook=pairs,
        parse_constant=lambda value:(_ for _ in ()).throw(ValueError('nonfinite JSON: '+value)))


def exact(value):
    try:
        projection=float(value)
        overflowed=not math.isfinite(projection)
    except OverflowError:
        projection,overflowed=None,True
    if overflowed: projection=None
    return {'value':projection,'numerator':str(value.numerator),'denominator':str(value.denominator),
        'nonzero_underflowed':bool(value and projection==0.),'overflowed':overflowed}


def number(value):
    if type(value) not in (float,int) or not math.isfinite(float(value)):
        raise ValueError('unrepresented numeric input')
    return Fraction(value)


def buckets(source):
    x=list(map(number,source['x_edges_m']))
    z=list(map(number,source['z_edges_m']))
    width,length=x[-1]-x[0],z[-1]-z[0]
    states=sorted({pool['state_id'] for pool in source['source_reservoirs']})
    output={}
    def add(kind,key,area):
        output[(kind,tuple(sorted(key.items()))) ]={
            'kind':kind,'key':key,'area':area,'channels':{name:ZERO for name in CHANNELS},
            'unqualified':{name:[] for name in CHANNELS},'component_indices':set()}
    add('total',{},width*length)
    for xi in range(len(x)-1): add('by_width',{'width_index':xi},(x[xi+1]-x[xi])*length)
    for zi in range(len(z)-1): add('by_current',{'current_index':zi},width*(z[zi+1]-z[zi]))
    for state in states: add('by_state',{'state_id':state},width*length)
    for ri in range(len(source['source_reservoirs'])): add('by_reservoir',{'reservoir_index':ri},width*length)
    for si in range(len(source['selections'])): add('by_selection',{'selection_index':si},width*length)
    for zi in range(len(z)-1):
        for state in states:
            for xi in range(len(x)-1):
                add('patch_state',{'current_index':zi,'state_id':state,'width_index':xi},(x[xi+1]-x[xi])*(z[zi+1]-z[zi]))
    return output,x,z


def reference_for(source,matched):
    groups,x,z=buckets(source)
    width=x[-1]-x[0]
    original_components=[]
    def get(kind,key): return groups[(kind,tuple(sorted(key.items())))]
    for ci,component in enumerate(source['components']):
        scalar=component['source_window']
        state=scalar['reservoir']['state_id']
        base=[get('total',{}),get('by_current',{'current_index':component['current_index']}),
            get('by_state',{'state_id':state}),get('by_reservoir',{'reservoir_index':component['reservoir_index']}),
            get('by_selection',{'selection_index':component['selection_index']})]
        destinations=[(group,Fraction(1)) for group in base]
        target_widths=range(len(x)-1) if matched else (component['width_index'],)
        for xi in target_widths:
            factor=(x[xi+1]-x[xi])/width if matched else Fraction(1)
            destinations.extend([(get('by_width',{'width_index':xi}),factor),
                (get('patch_state',{'current_index':component['current_index'],'state_id':state,'width_index':xi}),factor)])
        for group,factor in destinations:
            group['component_indices'].add(ci)
            for name in CHANNELS:
                quantity=scalar['quantities'][name]
                if type(quantity['qualified']) is not bool: raise ValueError('missing explicit qualification')
                if quantity['qualified']:
                    value=number(quantity['value'])
                    if value<0 or (name=='released_number' and value<=0): raise ValueError('invalid qualified extensive value')
                    if value==0 and quantity['exact_zero'] is not True: raise ValueError('positive underflow cannot be a qualified zero')
                    group['channels'][name]+=value*factor
                else:
                    group['unqualified'][name].append({'component_index':ci,'factor':exact(factor),
                        'source_quantity':quantity})
        if not matched:
            original_components.append({'component_index':ci,
                **{name:component[name] for name in ('selection_index','interval_index','reservoir_index','current_index','width_index','interval_origin_s','x_bounds_m','z_bounds_m')},
                'state_id':state,'reservoir_name':scalar['reservoir']['name'],
                'window_start_offset_s':scalar['start_s'],'window_stop_offset_s':scalar['stop_s'],
                'source_patch_area_m2':scalar['patch_area_m2'],
                'actual_geometry_area_m2':exact((x[component['width_index']+1]-x[component['width_index']])*(z[component['current_index']+1]-z[component['current_index']])),
                'quantities':{name:scalar['quantities'][name] for name in CHANNELS}})
    result={kind:[] for kind in ('total','by_width','by_current','by_state','by_reservoir','by_selection','patch_state')}
    for group in groups.values():
        channels={}
        for name in CHANNELS:
            missing=group['unqualified'][name]
            subtotal=group['channels'][name]
            channels[name]={'complete':not missing,'exact_total':exact(subtotal) if not missing else None,
                'qualified_subtotal':exact(subtotal),'unqualified_components':missing,
                'areal_density':exact(subtotal/group['area']) if not missing else None}
        count=channels['released_number']
        norms={}
        for name in CHANNELS[1:]:
            if count['complete'] and channels[name]['complete'] and group['channels']['released_number']>0:
                norms[name]=exact(group['channels'][name]/group['channels']['released_number'])
            else: norms[name]=None
        energy_complete=all(channels[name]['complete'] for name in CHANNELS[1:])
        energy_residual=group['channels']['total_wall_energy_debit_j']-sum((group['channels'][name] for name in CHANNELS[1:4]),ZERO)
        entry={'key':group['key'],'area_m2':exact(group['area']),'channels':channels,
            'energy_per_released_parent':norms,'component_indices':sorted(group['component_indices']),
            'wall_minus_translation_internal_binding_j':exact(energy_residual) if energy_complete else None}
        result[group['kind']].append(entry)
    return result,original_components


def main():
    output=HERE/'reference.json'
    if output.exists(): raise ValueError('reference output already exists')
    report=read(STUDY/'report.json')
    profile=read(PROFILE/'report.json')
    if report['parameter_status']!='manufactured' or report['source_evolution_repeated'] is not False:
        raise ValueError('preserved manufactured study required')
    inputs={str(STUDY/'report.json'):sha(STUDY/'report.json'),str(PROFILE/'report.json'):sha(PROFILE/'report.json')}
    for folder,record in ((STUDY,report),(PROFILE,profile)):
        for name,digest in record['output_sha256'].items():
            path=folder/name
            if Path(name).name!=name or path.is_symlink() or sha(path)!=digest:
                raise ValueError('saved input hash association failed: '+str(path))
            inputs[str(path)]=digest
    cases=[]
    for case in report['cases']:
        path=STUDY/('case_'+case['case_id']+'.json')
        stored=read(path)
        for window in stored['windows']:
            source=window['conditioned_source']
            resolved,components=reference_for(source,False)
            uniform,_=reference_for(source,True)
            cases.append({'case_id':case['case_id'],'window_index':window['window_index'],
                'window':window['window'],'conditioned_source_sha256':hashlib.sha256(json.dumps(source,sort_keys=True,separators=(',',':'),allow_nan=False).encode()).hexdigest(),
                'resolved':resolved,'matched_uniform_width':uniform,'components':components,
                'skipped_zero_initials':source['skipped_zero_initials']})
    result={'schema':'mitl-independent-saved-window-ledger-reference-v1','parameter_status':'manufactured',
        'input_files_sha256':inputs,'script_sha256':sha(__file__), 'source_evolution_repeated':False,
        'source_moment_or_ledger_routines_called':False,'channels':list(CHANNELS),'case_windows':cases,
        'area_definition':'full declared geometric support including zeros; physical patch/strip/face area once, independent of number of selections, intervals, pools and emitting components',
        'uniform_width_definition':'each original component retains selection/current/state/reservoir/time/temperature/costs; targetwidth factor dx/full_width is applied before grouping',
        'qualification_definition':'all represented extensive channels handled independently; incomplete totals remain null with exact qualified subtotal and original unqualified component records',
        'limits':['All inputs remain manufactured generic-pool source evidence.',
            'No missing extensive channel is replaced by zero; an exact supplied zero remains distinct from positive unrepresented output.',
            'Reference arithmetic is independent of the new ledger implementation and uses stored conditioned manifests only.',
            'No spectra, transport, chemistry, source evolution or host budget acceptance is evaluated.']}
    if any(sha(Path(path))!=digest for path,digest in inputs.items()): raise ValueError('saved input changed during reference preparation')
    output.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'output':str(output),'sha256':sha(output),'case_windows':len(cases),
        'retained_components':sum(len(case['components']) for case in cases),
        'groups_per_hypothesis':sum(sum(len(group) for group in case['resolved'].values()) for case in cases)},indent=2))

if __name__=='__main__': main()
