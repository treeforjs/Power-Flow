# Conservative source-window ledger verification subset

Named public files are byte-identical to the recorded commit. Four named
packaging wrappers isolate imports from unrelated downstream solvers.

```sh
python -W error -m pytest tests/test_window_source_ledger.py tests/test_window_source_ledger_cli.py tests/test_packet_source_ledger_cli.py
```

Inputs are manufactured. Five source extensive channels retain independent
qualification. Exact rational aggregation and signed area/energy residuals
remain separate from SI projection flags and host acceptance. New study and
packet-source exports reuse original histories and moments; no saved evolution
or sampling is repeated. Read `docs/window_source_ledgers.md`.
