"""Portable upstream source-window ledger verification subset."""
