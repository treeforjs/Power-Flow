# Source-ledger admission verification subset

The listed public files are byte-identical to commit079bddf9f81021ee4f3d79c42011185511d53747.
Four packaging wrappers isolate this upstream subset from unrelated solver imports.

```sh
python -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -W error -m pytest tests/test_window_source_ledger_validation.py tests/test_source_ledger_admission_cli.py
```

Only the two new admission suites are selected by this verification. Their
small manufactured source and packet fixtures are generated once during setup;
admission afterward uses JSON, CSV, hashes and exact algebra. Physical source,
law, HDF/array loading, moment, sampler and ledger-producer execution is guarded.
Older modules and tests are retained to satisfy imports and literal code pins,
and are not selected as test suites.

The admission command itself supports system Python with-S and the empty
package initializer. This excludes scientific packages and eager solver imports.
It consumes an externally approved report hash, preserves full component/joint
source references, and does not verify an owner implementation or accept a host
transaction. Read docs/source_ledger_admission.md for the trust boundary.

The managed verification environment reuses installed third-party distributions
in a separate venv; its method and exact versions are recorded outside source/.
Pinned requirements support a fresh installation elsewhere. No local project
or editable import hook is included in that dependency reuse.
