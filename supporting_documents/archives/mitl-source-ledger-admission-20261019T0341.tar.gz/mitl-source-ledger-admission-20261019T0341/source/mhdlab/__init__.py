"""Portable source-ledger admission verification subset."""
