"""Freeze completed admission evidence after final commits and independent checks."""
from collections import Counter
import datetime
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tarfile
import xml.etree.ElementTree as ET

from prepare_delivery import WORK, REPO, BASE, HEAD, OUT, clean_head, load, save, sha

TRUSTED = {'study': '7c3b3ea50b84992926b33e9da589153379ed168252a0ee54da47b576cebfe179',
           'packet': '23be0f8ebe86113ef8433ae48bc9e7ca7a554315ff31d9d00d99bcb23009577f'}
TEXT_SUFFIXES = {'.py', '.json', '.jsonl', '.log', '.xml', '.md', '.txt', '.patch', '.sha256'}
EVIDENCE_DIRS = ('admission-review', 'next-upstream-selection', 'saved-admission-verification',
                 'admitted-study', 'admitted-packet', 'stdlib-packet-admission', 'C19-preview')
PORTABLE_FILES = ('source_file_list.json', 'source-files.sha256', 'wrapper-files.sha256',
                  'environment.json', 'verification.json', 'new0341-results.xml', 'stdlib-imports.json', 'stdlib-comparison.json')


def check_admission(path, trusted):
    record = load(path/'admission.json')
    handoff = load(path/'owner_handoff.json')
    assert record['expected_report_sha256'] == handoff['expected_report_sha256'] == trusted
    assert sha(path/'export/report.json') == trusted
    for document in (record, handoff):
        for name in ('host_budget_accepted', 'owner_implementation_verified', 'physical_truth_verified',
                     'source_quantity_qualification_recomputed'):
            assert document[name] is False
    for name, digest in record['output_sha256'].items():
        assert sha(path/name) == digest, name
    for name, digest in record['input_export_sha256'].items():
        assert sha(path/'export'/name) == digest, name
    for name, digest in record['source_sha256'].items():
        assert sha(REPO/name) == digest, name
    return record


def main():
    clean_head()
    payload = WORK/'delivery-preparation/payload'
    assert payload.is_dir() and not OUT.exists() and not OUT.with_suffix('.tar.gz').exists()
    listing = load(payload/'source_file_list.json')
    for name in listing['byte_identical_public_files']:
        assert (payload/'source'/name).read_bytes() == (REPO/name).read_bytes(), name
    allowed = set(listing['byte_identical_public_files']) | set(listing['packaging_wrappers'])
    assert {str(p.relative_to(payload/'source')) for p in (payload/'source').rglob('*') if p.is_file()} == allowed
    assert load(payload/'preparation.json')['source_commit'] == HEAD
    cases = ET.parse(WORK/'portable/new0341-results.xml').getroot().findall('.//testcase')
    assert len(cases) == 145 and all(c.find(tag) is None for c in cases for tag in ('failure', 'error', 'skipped'))
    classes = dict(Counter(c.attrib['classname'] for c in cases))
    assert sorted(classes.values()) == [71, 74]
    review = load(WORK/'admission-review/review_completion.json')
    assert review['status'] == 'passed' and not review['open_substantive_findings']
    assert review['new_case_count'] == 33
    for name, digest in review['reviewed_source_sha256'].items():
        assert sha(REPO/name) == digest
    consumer = load(WORK/'saved-admission-verification/completion.json')
    independent = load(WORK/'saved-admission-verification/verification.json')
    assert consumer['all_checks_passed'] is True and independent['all_checks_passed'] is True
    trusted = load(WORK/'saved-admission-verification/trusted_inputs.json')
    assert {e['kind']: e['expected_report_sha256'] for e in trusted['exports']} == TRUSTED
    selection = load(WORK/'next-upstream-selection/selection.json')
    assert selection['status'] == 'selected' and selection['source_recovery_performed'] is False
    admissions = {kind: check_admission(WORK/('admitted-'+kind), digest) for kind, digest in TRUSTED.items()}
    check_admission(WORK/'stdlib-packet-admission', TRUSTED['packet'])
    core_notes = load(WORK/'ledger-admission-core-notes.json')
    assert core_notes['verification']['unique_new_core_checks_passed'] == 71
    assert any(run['exit_code'] != 0 for run in core_notes['verification']['runs'])
    assert sha(WORK/'admit-saved-study.log') == core_notes['verification']['saved_study_integration_failure_preserved']['log_sha256']
    assert core_notes['verification']['saved_study_integration_failure_preserved']['exit_code'] == 2
    for filename in PORTABLE_FILES:
        assert (WORK/'portable'/filename).is_file(), filename
    stdlib = load(WORK/'portable/stdlib-imports.json')
    comparison = load(WORK/'portable/stdlib-comparison.json')
    assert stdlib['no_site'] is True and not stdlib['numerical_package_imports'] and not stdlib['forbidden_module_imports']
    assert comparison['owner_handoff_identical'] is True and comparison['owner_handoff_bytes_identical'] is True
    assert sha(WORK/'admitted-packet/owner_handoff.json') == sha(WORK/'stdlib-packet-admission/owner_handoff.json')

    shutil.copytree(payload, OUT)
    evidence = OUT/'evidence'
    evidence.mkdir()
    try:
        active_log = Path(os.readlink('/proc/self/fd/1')).resolve()
    except OSError:
        active_log = None
    copied_root = []
    for path in WORK.iterdir():
        if path.is_file() and path.suffix in TEXT_SUFFIXES and path.resolve() != active_log:
            shutil.copyfile(path, evidence/path.name)
            copied_root.append(path.name)
    for name in EVIDENCE_DIRS:
        shutil.copytree(WORK/name, evidence/name, ignore=shutil.ignore_patterns('__pycache__', '*.pyc', '.pytest_cache'))
    (evidence/'portable').mkdir()
    for filename in PORTABLE_FILES:
        shutil.copyfile(WORK/'portable'/filename, evidence/'portable'/filename)
    prefix = bytes.fromhex('2f6f70742f636f6465782f72756e74696d65732f636f6465782d7072696d6172792d72756e74696d652f646570656e64656e636965732f707974686f6e')
    replacement = b'[runtime Python directory]'
    projections = []
    for path in evidence.rglob('*'):
        if path.is_file() and path.suffix in TEXT_SUFFIXES:
            data = path.read_bytes()
            if prefix in data:
                assert replacement not in data
                projected = data.replace(prefix, replacement)
                path.write_bytes(projected)
                projections.append({'path': str(path.relative_to(OUT)), 'original_sha256': __import__('hashlib').sha256(data).hexdigest(),
                    'portable_sha256': sha(path), 'replacements': data.count(prefix), 'source_prefix_hex': prefix.hex(),
                    'replacement': replacement.decode(), 'scope': 'Machine runtime directory prefix only; local raw records are unchanged.'})
    save(OUT/'portable_path_projections.json', projections)
    with (OUT/'source-ledger-admission.patch').open('wb') as stream:
        subprocess.run(['git', 'diff', '--binary', BASE, HEAD], cwd=REPO, stdout=stream, check=True)
    commands = [json.loads(line) for line in (evidence/'commands.jsonl').read_text().splitlines()]
    next_task = selection['selected_task']
    results = {'targeted_unique_passed': 145, 'core_passed': 71, 'cli_passed': 74,
        'portable_unique_passed': 145, 'portable_skipped': 0, 'independent_review_new_cases': 33,
        'saved_sources_checked': 9, 'saved_joint_components_checked': 1840, 'saved_group_rows_bound': 1526,
        'saved_datafile_references_checked': 48, 'independent_tamper_rejections': 6,
        'source_evolution_repeated': False, 'saved_moments_recomputed': False, 'saved_packet_sampling_repeated': False,
        'old_suites_or_saved_oracles_repeated': False, 'stdlib_packet_admission_verified': True}
    record = {'schema': 'mitl-source-ledger-admission-delivery-verification-v1',
        'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'source_commit': HEAD, 'base_commit': BASE,
        'branch': 'research/flash-publication-foundation',
        'commits': subprocess.check_output(['git', 'log', '--reverse', '--format=%H %s', BASE+'..'+HEAD], cwd=REPO, text=True).splitlines(),
        'results': results, 'portable_test_classes': classes, 'portable_verification': load(WORK/'portable/verification.json'),
        'stdlib_import_proof': {'evidence_path': 'evidence/portable/stdlib-imports.json',
            'original_sha256': sha(WORK/'portable/stdlib-imports.json'), 'no_site': True,
            'numerical_package_imports': [], 'forbidden_module_imports': [],
            'owner_handoff_bytes_identical': True}, 'core_review': review,
        'saved_admission_consumer_completion': consumer, 'trusted_original_report_sha256': TRUSTED,
        'admission_report_sha256': {kind: sha(WORK/('admitted-'+kind)/'admission.json') for kind in TRUSTED},
        'selection_sha256': sha(WORK/'next-upstream-selection/selection.json'),
        'runtime_dependency_scope': {'algorithm_and_validator': 'standard_library_only',
            'full_repository_initializer_can_require_numerical_packages': True,
            'stdlib_minus_s_proof_requires_explicit_portable_empty_initializer': True},
        'command_snapshot': {'entries': len(commands), 'copied_root_files': sorted(copied_root),
            'scope': 'All completed work-pass records before archive freezing; freeze, verification and completion commands remain in the local journal.'},
        'attempts': 'Initial overflow fixture failure, focused fixture repair, first saved-study coupling-cache rejection, exact one-ULP producer-roundtrip correction and affected checks are retained. Unchanged passing scopes were not repeated.',
        'limits': ['Algebra, original-source association and opaque-file integrity relative to independently approved report pins only.',
            'Source quantity qualification, physical truth, owner kernels, host transactions and response/collection remain unverified.',
            'Full joint component references remain necessary; marginal budgets do not define an emission distribution.',
            'No source/model/HDF/NPZ realization recomputation or owned solver/private integration is performed by admission.',
            'Runtime dependency flag describes the algorithm; normal repository package initialization can require numerical packages.'],
        'next_task': next_task}
    save(OUT/'verification.json', record)
    save(OUT/'next_task.json', {'task': next_task, 'selection_evidence': 'evidence/next-upstream-selection/selection.json',
                              'source_recovery_performed': False})
    (OUT/'systems-mitl-source-ledger-admission-10192026.md').write_text(f'''# MITL source-ledger admission and owner handoff

The public subset is pinned to `{HEAD}`; the patch starts at `{BASE}`.
Named public files are byte-identical. Four explicit packaging wrappers isolate
the subset from unrelated repository initialization.

All 145 new targeted checks passed: 71 core and 74 command checks. The portable
subset passes the same 145 checks. A separate system Python `-S` admission reads
the approved preserved packet export without numerical packages. The runtime
dependency flag describes the admission algorithm and validator only: normal
repository package initialization can require numerical packages. The `-S`
proof uses the disclosed empty initializer wrapper.

Original externally approved report pins bind the saved study and packet exports.
The new admissions and independent consumer preserve 9 source selections and 1840
joint component associations, 1526 resolved/matched groups and 48 data-file references.
Six independent pointer, hash and acceptance-escalation controls reject. These
checks do not regenerate histories, laws, moments, packets or physical responses.

Exact represented counts and all five energy channels, unique geometric areas,
unqualified-contributor evidence and independent SI projection flags are retained.
Availability means source completeness; it does not qualify a displayed number
or accept a host transaction. Full component state, pool, temperature, current
and separated timing references remain necessary for an emission kernel.

The initial overflow fixture failure and its focused correction are preserved.
The first saved-study admission exposed a one-ULP upward cached coupling after
the producer's scalar log/exp round trip. The narrow exact declaration guard and
five new checks are retained; no tolerance envelope or source-law replay was added.
Original raw local logs remain unchanged. Archive-only machine-directory prefix
projections are reversible and retain original and portable hashes.

Owner implementation, physical truth, fields, Hall feedback, state kinetics,
loss/collection definitions and numerical acceptance policy remain pending.
No host budget or physical dissertation/spectral result is asserted. Source and
mass labels retain their supplied provenance.

Next selected task: {next_task}
No waveform recovery has been performed in this pass. A pinned page preview
provides visual context for that next task without extracting a waveform.
''')
    manifest = {str(p.relative_to(OUT)): sha(p) for p in OUT.rglob('*') if p.is_file() and p.name != 'manifest.sha256.json'}
    save(OUT/'manifest.sha256.json', manifest)
    words = [bytes.fromhex(x).decode() for x in ('6f70656e6169', '63686174677074', '636c61756465', '636f646578')]
    prohibited = re.compile(r'\b(?:'+'|'.join(words)+r')\b', re.I)
    for path in OUT.rglob('*'):
        assert not path.is_symlink()
        if path.is_file() and path.suffix in TEXT_SUFFIXES:
            assert not prohibited.search(path.read_text()), str(path)
    archive = OUT.with_suffix('.tar.gz')
    with tarfile.open(archive, 'w:gz') as tar:
        tar.add(OUT, arcname=OUT.name)
    result = {'folder': str(OUT), 'archive': str(archive), 'sha256': sha(archive), 'bytes': archive.stat().st_size,
        'source_commit': HEAD, 'base_commit': BASE, 'manifest_entries': len(manifest),
        'public_files_byte_identical': len(listing['byte_identical_public_files']), 'packaging_wrappers': len(listing['packaging_wrappers']),
        'manifest_sha256': sha(OUT/'manifest.sha256.json'), 'verification_sha256': sha(OUT/'verification.json')}
    save(WORK/'frozen_delivery.json', result)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
