"""New expected-input binding probe; stdlib JSON only, no source-law imports."""
import copy,hashlib,importlib.util,json,sys
from pathlib import Path
p=Path('/workspace/Power-Flow/mhdlab/window_source_ledger_validation.py')
spec=importlib.util.spec_from_file_location('expected_input_binding_review',p)
m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
w=Path(__file__).resolve().parent
ledger=json.loads(Path('/workspace/research_work/mitl-upstream-20261019T0250/saved-packet-ledger/ledger.json').read_text())
expected=json.loads(Path('/workspace/research_work/mitl-upstream-20261018T2348/windowed-packet-example/report.json').read_text())['conditioned_source']
rows=[]
for key,replacement in [('time_coordinate','incorrect global photon timestamp convention'),('limits',['incorrect host-accepted claim'])]:
    changed=copy.deepcopy(expected);changed[key]=replacement
    try:
        result=m.validate_window_source_ledger(ledger,expected_source=changed)
    except (ValueError,TypeError) as error:
        rows.append({'field':key,'rejected':True,'error':str(error)})
    else:
        rows.append({'field':key,'rejected':False,'source_association_bound':result['source_association_bound']})
report={'schema':'mhdlab-new-expected-source-top-field-review-v1','validator_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'cases':rows,'scope':'Only new expected-input declaration mutations; no source physics or old suites.'}
out='expected_top_fields_closed.json' if all(row['rejected'] for row in rows) else 'expected_top_fields_prefixed.json'
(w/out).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
