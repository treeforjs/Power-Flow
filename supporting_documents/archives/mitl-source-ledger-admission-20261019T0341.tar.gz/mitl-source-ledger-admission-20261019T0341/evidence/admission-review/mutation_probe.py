"""New strict-admission mutations; loads only the new stdlib validator file."""
import copy
from fractions import Fraction as F
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import sys

work=Path(__file__).resolve().parent
parent=work.parent
path=Path('/workspace/Power-Flow/mhdlab/window_source_ledger_validation.py')
spec=importlib.util.spec_from_file_location('new_json_ledger_admission_review',path)
module=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=module
spec.loader.exec_module(module)
validate=module.validate_window_source_ledger
ledger_path=Path('/workspace/research_work/mitl-upstream-20261019T0250/saved-packet-ledger/ledger.json')
source_path=Path('/workspace/research_work/mitl-upstream-20261018T2348/windowed-packet-example/report.json')
baseline=json.loads(ledger_path.read_text())
expected=json.loads(source_path.read_text())['conditioned_source']
Q=('released_number','translational_energy_j','internal_energy_j','binding_energy_j','total_wall_energy_debit_j')
rows=[]
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def rational(value):return F(int(value['numerator']),int(value['denominator']))
def record(value):
    try:v=float(value)
    except OverflowError:v=None
    if v is not None and not math.isfinite(v):v=None
    error=None if v is None else F(v)-value
    r=lambda x:{'numerator':str(x.numerator),'denominator':str(x.denominator)}
    return {'exact_sum':r(value),'value':v,'projection':{
        'exact_zero':value==0,'positive':value>0,'negative':value<0,'finite':v is not None,
        'underflowed':bool(value and v==0.),'overflowed':v is None,'rounded':error is None or error!=0,
        'subnormal':v is not None and 0<abs(v)<float.fromhex('0x1.0000000000000p-1022'),
        'exact_rounding_error':None if error is None else r(error)}}
def outcome(name,document,*,bind=True,reject=True):
    try:
        result=validate(document,expected_source=expected if bind else None)
    except (ValueError,TypeError) as error:
        if not reject:raise
        rows.append({'name':name,'expected_source_bound':bind,'rejected':True,'reason':str(error)})
        return None
    if reject:raise AssertionError((name,'mutation admitted',result))
    rows.append({'name':name,'expected_source_bound':bind,'rejected':False,'summary':result})
    return result

unbound=outcome('original algebra without external binding',baseline,bind=False,reject=False)
bound=outcome('original bound to preserved expected source',baseline,bind=True,reject=False)

def mutate(name,fn):
    document=copy.deepcopy(baseline);fn(document);outcome(name,document)
def nrecord(d):return d['resolved']['total']['quantities']['released_number']
def alias_fraction(d):
    target=nrecord(d)['exact_sum'];target['numerator']=str(int(target['numerator'])*2);target['denominator']=str(int(target['denominator'])*2)
mutate('non-reduced equivalent exact fraction',alias_fraction)
mutate('leading-zero integer alias',lambda d:nrecord(d)['exact_sum'].__setitem__('numerator','0'+nrecord(d)['exact_sum']['numerator']))
mutate('over-limit rational digit string',lambda d:nrecord(d)['exact_sum'].__setitem__('numerator','1'*4097))
mutate('boolean flag replaced by equal integer',lambda d:nrecord(d)['projection'].__setitem__('positive',1))
mutate('wrong count2kBT source group reference',lambda d:d['matched_uniform_width']['by_width'][0]['residuals']['count_times_2kbt_j']['unqualified'].__setitem__('source_group_ref','resolved/total/quantities/released_number'))
mutate('noncanonical source group index alias',lambda d:d['matched_uniform_width']['patch_state'][0]['redistribution'].__setitem__('source_group_ref','uniform_width_bases/00'))
mutate('component interval origin changed',lambda d:d['components'][0].__setitem__('interval_origin_s',math.nextafter(d['components'][0]['interval_origin_s'],math.inf)))
mutate('boolean selection index alias',lambda d:d['components'][0].__setitem__('selection_index',False))
def negative_zero(d):
    for group in d['resolved']['by_state']:
        q=group['quantities']['internal_energy_j']
        if q['projection']['exact_zero']:
            q['value']=-0.;return
    raise AssertionError('No structural zero fixture')
mutate('negative zero alias for canonical zero projection',negative_zero)

def replace_number(target,value):
    for key in ('exact_sum','value','projection'):target[key]=record(value)[key]
def false_area(d):
    group=d['resolved']['by_state'][0]
    area=group['area'];a=rational(area['exact_m2'])*2;c=rational(area['canonical_patch_area_sum']['exact_sum'])*2
    r=record(a);area.update(exact_m2=r['exact_sum'],value_m2=r['value'],projection=r['projection'])
    area['canonical_patch_area_sum']=record(c);area['canonical_minus_exact_residual_m2']=record(c-a)
    for amount in tuple(group['quantities'].values())+(group['residuals']['count_times_2kbt_j'],):
        if amount['available']:replace_number(amount['per_area'],rational(amount['exact_sum'])/a)
        amount['per_area']['qualified_subtotal']=record(rational(amount['qualified_subtotal']['exact_sum'])/a)
mutate('self-consistent doubled state area and all densities',false_area)

def renamed(value,old,new):
    if isinstance(value,dict):return {key:renamed(item,old,new) for key,item in value.items()}
    if isinstance(value,list):return [renamed(item,old,new) for item in value]
    return new if type(value) is str and value==old else value
old_state=baseline['source_association']['source_reservoirs'][0]['state_id']
changed=renamed(baseline,old_state,'M:review-new-source-identity')
outcome('coherent state rename remains algebraically self-consistent',changed,bind=False,reject=False)
outcome('coherent state rename fails original expected-source binding',changed,bind=True,reject=True)

# Rescale every declared parent population, reference/max coverage and source
# amount by two; update every ledger amount/density/residual consistently.
# This is a new declared input, not evidence of the original source. It tests
# whether a self-consistent outer hash can substitute for external binding.
scaled=copy.deepcopy(baseline)
for pool in scaled['source_association']['source_reservoirs']:
    for key in ('reference_coverage_m2','max_coverage_m2'):pool[key]*=2
for component in scaled['components']:
    window=component['source_window'];window['initial_coverage_m2']*=2
    for key in ('reference_coverage_m2','max_coverage_m2'):window['reservoir'][key]*=2
    for q in window['quantities'].values():
        if q['value'] is not None:q['value']*=2
        if q['log_value'] is not None:
            q['log_value']+=math.log(2.)
            if q['value']:
                q['log_rounding_error']=abs(math.log(q['value'])-q['log_value'])
    for key in ('inventory_balance_residual_m2','inventory_balance_residual_number','energy_balance_residual_j_m2','energy_balance_residual_j'):
        if window[key] is not None:window[key]*=2
def scale_amount(amount):
    if amount['available']:replace_number(amount,2*rational(amount['exact_sum']))
    amount['qualified_subtotal']=record(2*rational(amount['qualified_subtotal']['exact_sum']))
    if amount['per_area']['available']:replace_number(amount['per_area'],2*rational(amount['per_area']['exact_sum']))
    amount['per_area']['qualified_subtotal']=record(2*rational(amount['per_area']['qualified_subtotal']['exact_sum']))
for hypothesis in ('resolved','matched_uniform_width'):
    for category,container in scaled[hypothesis].items():
        for group in ([container] if category=='total' else container):
            for amount in group['quantities'].values():scale_amount(amount)
            scale_amount(group['residuals']['count_times_2kbt_j'])
            for key in ('wall_minus_parts_j','translation_minus_count_2kbt_j'):
                residual=group['residuals'][key]
                if residual['available']:replace_number(residual,2*rational(residual['exact_sum']))
for group in scaled['uniform_width_bases']:
    for amount in group['quantities'].values():scale_amount(amount)
    scale_amount(group['residuals']['count_times_2kbt_j'])
    for key in ('wall_minus_parts_j','translation_minus_count_2kbt_j'):
        residual=group['residuals'][key]
        if residual['available']:replace_number(residual,2*rational(residual['exact_sum']))
outcome('coherent twofold amount/reference rescaling unbound',scaled,bind=False,reject=False)
outcome('coherent twofold amount rescaling fails original expected-source binding',scaled,bind=True,reject=True)
envelope_sha=hashlib.sha256(json.dumps(scaled,sort_keys=True,allow_nan=False).encode()).hexdigest()

report={'schema':'mhdlab-new-strict-ledger-admission-mutation-probe-v1',
    'validator_sha256':sha(path),'input_ledger_sha256':sha(ledger_path),'input_source_report_sha256':sha(source_path),
    'cases':rows,'case_count':len(rows),'all_expectations_passed':True,
    'new_outer_hash_of_coherent_changed_amounts':envelope_sha,
    'origin_scope':'A self-consistent new content hash and algebra do not establish original input identity; binding is to the caller-supplied preserved expected source, not independent physical truth.',
    'open_substantive_findings':[],
    'scope':'New JSON mutations and Fraction constructions only. Loads new validator file directly without importing the mhdlab package or source/ledger helpers, histories, laws, samplers, old suites/oracles or solvers.'}
(work/'mutation_probe.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps({key:value for key,value in report.items() if key!='cases'},indent=2,allow_nan=False))
