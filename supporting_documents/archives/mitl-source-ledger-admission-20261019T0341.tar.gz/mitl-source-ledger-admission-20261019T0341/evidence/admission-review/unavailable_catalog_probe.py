"""New declared-unavailability fixture using only JSON and independent Fraction algebra.

The changed representation is an artificial admission-boundary input, not a
new source-law calculation or a physically evaluated underflow experiment.
"""
import copy,hashlib,importlib.util,json,math,sys
from fractions import Fraction as F
from pathlib import Path
w=Path(__file__).resolve().parent
p=Path('/workspace/Power-Flow/mhdlab/window_source_ledger_validation.py')
spec=importlib.util.spec_from_file_location('unavailable_catalog_admission_review',p)
m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
validate=m.validate_window_source_ledger
ledger_path=Path('/workspace/research_work/mitl-upstream-20261019T0250/saved-packet-ledger/ledger.json')
source_path=Path('/workspace/research_work/mitl-upstream-20261018T2348/windowed-packet-example/report.json')
doc=json.loads(ledger_path.read_text());expected=json.loads(source_path.read_text())['conditioned_source']
Q=('released_number','translational_energy_j','internal_energy_j','binding_energy_j','total_wall_energy_debit_j')
def r(x):return {'numerator':str(x.numerator),'denominator':str(x.denominator)}
def f(x):return F(int(x['numerator']),int(x['denominator']))
def number(x):
    try:value=float(x)
    except OverflowError:value=None
    if value is not None and not math.isfinite(value):value=None
    error=None if value is None else F(value)-x
    return {'exact_sum':r(x),'value':value,'projection':{'exact_zero':x==0,'positive':x>0,'negative':x<0,'finite':value is not None,'underflowed':x!=0 and value==0.,'overflowed':value is None,'rounded':error is None or error!=0,'subnormal':value is not None and 0<abs(value)<sys.float_info.min,'exact_rounding_error':None if error is None else r(error)}}
component=doc['components'][0];window=component['source_window']
N=F(window['quantities']['released_number']['value']);thermal=N*2*F(1.380649e-23)*F(window['temperature_k'])
window['quantities']['released_number']={'value':0.,'log_value':-1000.,'exact_zero':False,'qualified':False,'reason':'positive_amount_underflow','log_rounding_error':None,'log_rounding_allowance':0.}
window['all_budget_values_qualified']=False
window['inventory_balance_residual_number']=math.fsum((window['quantities']['remaining_stop_number']['value'],-window['quantities']['remaining_start_number']['value'],0.))
expected['components'][0]['source_window']=copy.deepcopy(window)
association_fields=('component_index','selection_index','interval_index','reservoir_index','reservoir_name','state_id','current_index','width_index','interval_origin_s','x_bounds_m','z_bounds_m')
doc['unqualified_contributors']=[{'catalog_index':0,**{key:component[key] for key in association_fields},'quantity_name':'released_number','positive':True,'representation':copy.deepcopy(window['quantities']['released_number'])}]
empty={'exact_sum':None,'value':None,'projection':None}
def unavailable(amount,removed,area,reference):
    subtotal=f(amount['qualified_subtotal']['exact_sum'])-removed
    amount.update(available=False,**empty)
    amount['qualified_subtotal']=number(subtotal)
    amount['per_area']={'available':False,**empty,'qualified_subtotal':number(subtotal/area)}
    amount['unqualified']={'count':1,**({'catalog_indices':[0]} if reference is None else {'source_group_ref':reference})}
def change(group,factor,reference=None):
    area=f(group['area']['exact_m2'])
    unavailable(group['quantities']['released_number'],N*factor,area,None if reference is None else reference+'/quantities/released_number')
    unavailable(group['residuals']['count_times_2kbt_j'],thermal*factor,area,None if reference is None else reference+'/residuals/count_times_2kbt_j')
    group['residuals']['translation_minus_count_2kbt_j']={'available':False,**empty,'unavailable_quantities':['released_number']}
def member(family,key):
    if family=='total':return True
    keys={'by_width':('width_index',),'by_current':('current_index',),'by_state':('state_id',),'by_reservoir':('reservoir_index',),'by_selection':('selection_index',),'patch_state':('current_index','state_id','width_index')}
    return all(key[name]==component[name] for name in keys[family])
xe=doc['geometry']['x_edges_m'];width=F(xe[-1])-F(xe[0]);states=list(dict.fromkeys(pool['state_id'] for pool in doc['source_association']['source_reservoirs']))
for hypothesis in ('resolved','matched_uniform_width'):
    for family,container in doc[hypothesis].items():
        for group in ([container] if family=='total' else container):
            key=group['key'];factor=F(1);reference=None;affected=member(family,key)
            if hypothesis=='matched_uniform_width' and family=='by_width':
                i=key['width_index'];factor=(F(xe[i+1])-F(xe[i]))/width;reference='resolved/total';affected=True
            elif hypothesis=='matched_uniform_width' and family=='patch_state':
                i=key['width_index'];factor=(F(xe[i+1])-F(xe[i]))/width
                reference='uniform_width_bases/'+str(key['current_index']*len(states)+states.index(key['state_id']))
                affected=key['current_index']==component['current_index'] and key['state_id']==component['state_id']
            if affected:change(group,factor,reference)
for group in doc['uniform_width_bases']:
    if all(group['key'][name]==component[name] for name in ('current_index','state_id')):change(group,F(1))
rows=[]
def outcome(name,d,*,reject):
    try:result=validate(d,expected_source=expected)
    except (ValueError,TypeError) as error:
        if not reject:raise
        rows.append({'name':name,'rejected':True,'error':str(error)})
    else:
        if reject:raise AssertionError((name,'unexpected admission'))
        assert result['unqualified_contributor_count']==1
        assert result['total_quantity_availability']=={key:key!='released_number' for key in Q}
        rows.append({'name':name,'rejected':False,'summary':result})
outcome('artificial declared-unavailable count retains qualified subtotals and explicit catalog',doc,reject=False)
def mutate(name,fn):
    changed=copy.deepcopy(doc);fn(changed);outcome(name,changed,reject=True)
mutate('unqualified catalog association changed',lambda d:d['unqualified_contributors'][0].__setitem__('width_index',1))
mutate('unqualified catalog quantity substituted',lambda d:d['unqualified_contributors'][0].__setitem__('quantity_name','translational_energy_j'))
mutate('unqualified catalog representation relabeled exact zero',lambda d:d['unqualified_contributors'][0]['representation'].__setitem__('exact_zero',True))
mutate('missing contributor hidden behind zero count',lambda d:d['resolved']['total']['quantities']['released_number']['unqualified'].__setitem__('count',0))
mutate('missing contributor redirected to nonexistent catalog index',lambda d:d['resolved']['total']['quantities']['released_number']['unqualified'].__setitem__('catalog_indices',[1]))
mutate('thermal unavailable count reference redirected to count quantity',lambda d:d['matched_uniform_width']['by_width'][0]['residuals']['count_times_2kbt_j']['unqualified'].__setitem__('source_group_ref','resolved/total/quantities/released_number'))
mutate('thermal residual incorrectly declared available',lambda d:d['resolved']['total']['residuals']['translation_minus_count_2kbt_j'].__setitem__('available',True))
mutate('qualified subtotal silently includes unavailable amount',lambda d:d['resolved']['total']['quantities']['released_number'].__setitem__('qualified_subtotal',number(f(d['resolved']['total']['quantities']['released_number']['qualified_subtotal']['exact_sum'])+N)))
mutate('unavailable complete total replaced with qualified subtotal',lambda d:d['resolved']['total']['quantities']['released_number'].update(available=True,**d['resolved']['total']['quantities']['released_number']['qualified_subtotal']))
report={'schema':'mhdlab-new-unavailable-catalog-admission-review-v1','validator_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'input_ledger_sha256':hashlib.sha256(ledger_path.read_bytes()).hexdigest(),'input_source_report_sha256':hashlib.sha256(source_path.read_bytes()).hexdigest(),'cases':rows,'case_count':len(rows),'all_expectations_passed':True,'scope':'Artificial input declaration + exact Fraction adjustments to saved JSON, not new physical underflow/source calculations; only new stdlib validator loaded, no ledger/source helpers, old tests or physics.'}
(w/'unavailable_catalog_probe.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='cases'},indent=2))
