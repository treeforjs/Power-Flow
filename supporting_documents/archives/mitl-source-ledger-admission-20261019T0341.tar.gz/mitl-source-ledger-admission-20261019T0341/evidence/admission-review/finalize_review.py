"""Freeze new independent admission review evidence; performs no validation runs."""
from pathlib import Path
import datetime,hashlib,json
work=Path(__file__).resolve().parent;root=work.parent
source=Path('/workspace/Power-Flow/mhdlab/window_source_ledger_validation.py')
final='876f01e75a2bfb35df3addf1284313882821a442fff35a835fbb177a512cdae1'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(source)==final
probes=[json.loads((work/name).read_text()) for name in ('mutation_probe.json','expected_top_fields_closed.json','unavailable_catalog_probe.json','domain_bounds_probe.json')]
assert sum(len(p['cases']) for p in probes)==33
assert all(p.get('all_expectations_passed',True) for p in probes)
notes=work/'review_notes.md'
notes.write_text(notes.read_text()+'''\n\nFinal review: 33 new cases met their explicit expectations (five accepted declarations and 28 rejected mutations). Coherently renamed or rescaled declarations remain admissible without external binding and reject against the preserved original source. A separately constructed unavailable-count declaration retains the catalog, unavailable complete totals, qualified subtotals, and unavailable count-times-2kBT residual; nine mutations to those associations or availability states reject. This artificial boundary fixture is not a new evaluated source or physical-underflow experiment.\n\nThe concrete finding was that two required expected-source fields, `time_coordinate` and `limits`, were initially ignored by `_bind`. The owner added exact canonical checks before the focused execution; both altered declarations then rejected. The first 16 cases ran on source `74f9aa0b9f90b16ba4bba117c98fab80ec6f85a1f217620671ce3b8eb6759d70`; the following 17 ran on `cb2fadc6b4a5e56e3c723e39dac29419216da10b4a01004a4055bc2ff0471fb3`. The final source adds only a positive reduced-tolerance guard, read-reviewed without repeating those unchanged cases. The owner's single focused tolerance regression is separately recorded.\n\nNo remaining substantive finding was identified. Admission establishes represented algebra and optional exact association with caller-supplied declarations. It does not independently solve source kinetics, verify physical qualifications/logs, authenticate experimental origin, qualify rounded SI projections, or accept host energy transactions. The caller must preserve a trusted expected input and its provenance; a self-consistent new outer content hash supplies no such trust. No CLI outer-wrapper reexecution was part of these probes.\n''')
files=[p for p in work.iterdir() if p.is_file() and p.name!='review_completion.json']
logs=['admission-new-json-mutations.log','admission-expected-top-fields.log','admission-unavailable-catalog.log','admission-domain-bounds.log','ledger-admission-positive-half-tolerance.log']
artifacts={str(p.relative_to(root)):sha(p) for p in files}
artifacts.update({name:sha(root/name) for name in logs})
report={'schema':'mhdlab-independent-strict-ledger-admission-review-completion-v1','status':'passed','completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
'reviewed_source_sha256':{'mhdlab/window_source_ledger_validation.py':final},'artifact_sha256':artifacts,
'new_case_count':33,'accepted_declared_inputs':5,'rejected_mutations':28,
'probe_source_sha256':{name:probe['validator_sha256'] for name,probe in zip(('mutation_probe.json','expected_top_fields_closed.json','unavailable_catalog_probe.json','domain_bounds_probe.json'),probes)},
'closed_substantive_findings':[{'finding':'Expected source time_coordinate and limits were required keys but initially not validated or bound.','resolution':'Owner added exact canonical expected-source checks before focused execution. Both new altered-field cases reject.','evidence':'admission-review/expected_top_fields_closed.json','pre_fix_execution_performed':False}],
'last_guard_review':{'change':'Require strictly positive reduced log_mass_tolerance; physical minsubnormal tolerance divided by two cannot silently establish a zero reduced tolerance.','read_reviewed':True,'prior_33_cases_repeated':False,'owner_focused_regression_log':'ledger-admission-positive-half-tolerance.log','owner_focused_regression_exit_code':0,'owner_focused_regression_passed':1},
'open_substantive_findings':[],
'scientific_scope':['Exact represented arithmetic and associations only; source log and qualification declarations remain input evidence.','External expected-source provenance remains the caller responsibility; a recomputed self-consistent hash is not authentication.','No host budget or kinetic/thermal/experimental truth is established.','Five-channel unqualified contributor catalog is distinct from separate source representation fields.'],
'old_suites_or_source_evolution_repeated':False,'public_files_edited':False,'source_model_imports':False,'owned_solver_accessed':False}
(work/'review_completion.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps({'completion':str(work/'review_completion.json'),'completion_sha256':sha(work/'review_completion.json'),'final_source_sha256':final,'new_cases':33,'open_substantive_findings':[]},indent=2))
