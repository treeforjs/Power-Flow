"""Record read-only final coupling-cache guard review; repeats no probes."""
from pathlib import Path
import datetime,hashlib,json,shutil
work=Path(__file__).resolve().parent;root=work.parent
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
p=Path('/workspace/Power-Flow/mhdlab/window_source_ledger_validation.py');final='458d743ca5353ce5bacfe506379d360f777863c9e194e775a5d94d5acd7de8e4'
assert sha(p)==final
completion=work/'review_completion.json';old=work/'review_completion.before_coupling_roundtrip.json'
assert not old.exists();shutil.copyfile(completion,old)
d=json.loads(completion.read_text());assert d['reviewed_source_sha256']['mhdlab/window_source_ledger_validation.py']=='876f01e75a2bfb35df3addf1284313882821a442fff35a835fbb177a512cdae1'
d['reviewed_source_sha256']['mhdlab/window_source_ledger_validation.py']=final
d['review_updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
d['prior_review_completion_sha256']=sha(old)
d['subsequent_narrow_cache_guard_review']={'change':'When retained local_coupling exceeds retained original coupling, allow only exact binary64 cache identities log_ca=math.log(c)-start_depletion and ca=math.exp(log_ca). Keep original0<=c<=512 and all other structural checks.','review':'Read-only: nonnegative depletion bounds log_ca before the exponential, exact typed hex comparisons reject altered logs or upward values, no broad tolerance or source-law inversion is introduced. Platform-specific libm cache differences can still reject externally generated records; declaration/association scope remains explicit.','read_reviewed':True,'new_probe_execution':False,'prior_33_cases_repeated':False,'owner_focused_test_log':'ledger-admission-coupling-roundtrip.log','owner_focused_test_log_sha256':sha(root/'ledger-admission-coupling-roundtrip.log')}
notes=work/'review_notes.md';notes.write_text(notes.read_text()+'''\n\nSubsequent final-pin update: the actual saved-study admission exposed a one-ULP upward `exp(log(c)-s_a)` cache at zero start depletion. Final source `458d743ca5353ce5bacfe506379d360f777863c9e194e775a5d94d5acd7de8e4` permits this only when the declared log and exponential reproduce those exact float identities. The original coupling limit `0 <= c <= 512`, nonnegative depletion, finite scalars, and strict typed comparisons remain. This is cache-declaration compatibility, not a source-law solve or arbitrary closeness envelope. The narrow branch was read-reviewed; the owner's five new focused cases are separately logged. None of the 33 prior independent cases was repeated. Prior completion is preserved byte-for-byte. No new substantive finding remains.\n''')
d['artifact_sha256']['admission-review/review_notes.md']=sha(notes)
d['artifact_sha256']['admission-review/review_completion.before_coupling_roundtrip.json']=sha(old)
d['artifact_sha256']['admission-review/update_final_pin.py']=sha(Path(__file__))
d['artifact_sha256']['ledger-admission-coupling-roundtrip.log']=sha(root/'ledger-admission-coupling-roundtrip.log')
completion.write_text(json.dumps(d,indent=2,allow_nan=False)+'\n')
print(json.dumps({'completion':str(completion),'completion_sha256':sha(completion),'reviewed_source_sha256':final,'old_completion_sha256':sha(old),'probe_reruns':0,'open_substantive_findings':[]},indent=2))
