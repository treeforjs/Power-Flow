"""New bounded parsing/type cases for the standalone admission validator."""
import copy,hashlib,importlib.util,json,sys
from pathlib import Path
w=Path(__file__).resolve().parent;p=Path('/workspace/Power-Flow/mhdlab/window_source_ledger_validation.py')
spec=importlib.util.spec_from_file_location('admission_domain_limits_review',p)
m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
base=json.loads(Path('/workspace/research_work/mitl-upstream-20261019T0250/saved-packet-ledger/ledger.json').read_text())
rows=[]
def reject(name,change):
    d=copy.deepcopy(base);change(d)
    try:m.validate_window_source_ledger(d)
    except m.LedgerAdmissionError as e:rows.append({'name':name,'rejected':True,'error':str(e)})
    else:raise AssertionError(name)
def nested(d):
    v=0
    for _ in range(70):v=[v]
    d['source_association']['surface_attributes']['review']=v
def cyclic(d):
    v=[];v.append(v);d['source_association']['surface_attributes']['review']=v
reject('depth above64',nested)
reject('integer bitlength above4096',lambda d:d['source_association']['surface_attributes'].__setitem__('review',1<<4096))
reject('individual string above1000000',lambda d:d['source_association']['surface_attributes'].__setitem__('review','a'*1000001))
reject('cyclic Python container cannot masquerade as JSON',cyclic)
reject('unhashable status declaration fails typed admission',lambda d:d['source_association'].__setitem__('status',{}))
report={'schema':'mhdlab-new-admission-domain-bounds-review-v1','validator_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'case_count':len(rows),'cases':rows,'all_expectations_passed':True,'scope':'New bounded malformed declarations only; no original helper/model/suite imports.'}
(w/'domain_bounds_probe.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
