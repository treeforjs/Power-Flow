"""Inspect actual compressed delivery bytes without rerunning admission math."""
import csv
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import tarfile

from prepare_delivery import WORK, REPO, BASE, HEAD, OUT, clean_head, load, save, sha
from freeze_delivery import TRUSTED


def pointer(document, value):
    assert value == '' or value.startswith('/')
    for item in value.split('/')[1:]:
        item = item.replace('~1', '/').replace('~0', '~')
        document = document[int(item)] if isinstance(document, list) else document[item]
    return document


def main():
    clean_head()
    frozen = load(WORK/'frozen_delivery.json')
    archive = Path(frozen['archive'])
    assert frozen['source_commit'] == HEAD and frozen['base_commit'] == BASE
    assert sha(archive) == frozen['sha256'] and archive.stat().st_size == frozen['bytes']
    digests, members = {}, {}
    with tarfile.open(archive, 'r:gz') as tar:
        all_names = set()
        for item in tar.getmembers():
            path = PurePosixPath(item.name)
            assert not path.is_absolute() and '..' not in path.parts and path.parts[0] == OUT.name
            assert item.name not in all_names and not item.issym() and not item.islnk()
            all_names.add(item.name)
            if item.isdir():
                continue
            assert item.isfile()
            name = PurePosixPath(*path.parts[1:]).as_posix()
            assert name not in members and name != '.'
            digest = hashlib.sha256()
            stream = tar.extractfile(item)
            for block in iter(lambda: stream.read(1024*1024), b''):
                digest.update(block)
            digests[name] = digest.hexdigest()
            members[name] = item

        def raw(name):
            data = tar.extractfile(members[name]).read()
            assert hashlib.sha256(data).hexdigest() == digests[name]
            return data

        def document(name):
            assert members[name].size <= 64*1024*1024
            return json.loads(raw(name))

        manifest = document('manifest.sha256.json')
        assert set(digests) == set(manifest) | {'manifest.sha256.json'}
        assert all(digests[name] == value for name, value in manifest.items())
        assert digests['manifest.sha256.json'] == frozen['manifest_sha256']
        assert digests['verification.json'] == frozen['verification_sha256']
        assert {str(p.relative_to(OUT)) for p in OUT.rglob('*') if p.is_file()} == set(digests)
        assert all(sha(OUT/name) == value for name, value in digests.items())
        listing = document('source_file_list.json')
        public, wrappers = listing['byte_identical_public_files'], listing['packaging_wrappers']
        assert {n[7:] for n in digests if n.startswith('source/')} == set(public) | set(wrappers)
        for name in public:
            assert digests['source/'+name] == sha(REPO/name), name
        for line in raw('source-files.sha256').decode().splitlines():
            value, name = line.split('  ', 1)
            assert value == digests['source/'+name] == sha(REPO/name)
        verification = document('verification.json')
        assert verification['source_commit'] == HEAD and verification['base_commit'] == BASE
        for key, value in {'targeted_unique_passed': 145, 'core_passed': 71, 'cli_passed': 74,
                           'portable_unique_passed': 145, 'portable_skipped': 0}.items():
            assert verification['results'][key] == value
        projections = document('portable_path_projections.json')
        original_digests = dict(digests)
        for projection in projections:
            name = projection['path']
            data = raw(name)
            replacement = projection['replacement'].encode()
            assert hashlib.sha256(data).hexdigest() == projection['portable_sha256']
            assert data.count(replacement) == projection['replacements']
            restored = data.replace(replacement, bytes.fromhex(projection['source_prefix_hex']))
            assert hashlib.sha256(restored).hexdigest() == projection['original_sha256']
            original_digests[name] = projection['original_sha256']
        trusted = document('evidence/saved-admission-verification/trusted_inputs.json')
        assert {entry['kind']: entry['expected_report_sha256'] for entry in trusted['exports']} == TRUSTED
        assert document('evidence/saved-admission-verification/verification.json')['all_checks_passed'] is True
        assert document('evidence/saved-admission-verification/completion.json')['all_checks_passed'] is True
        total_sources = total_components = 0
        for kind in ('study', 'packet'):
            prefix = 'evidence/admitted-'+kind+'/'
            admission, handoff = document(prefix+'admission.json'), document(prefix+'owner_handoff.json')
            assert admission['expected_report_sha256'] == handoff['expected_report_sha256'] == TRUSTED[kind]
            assert original_digests[prefix+'export/report.json'] == TRUSTED[kind]
            for value in (admission, handoff):
                for flag in ('host_budget_accepted', 'owner_implementation_verified', 'physical_truth_verified',
                             'source_quantity_qualification_recomputed'):
                    assert value[flag] is False
            for name, digest in admission['output_sha256'].items():
                assert original_digests[prefix+name] == digest
            for name, digest in admission['input_export_sha256'].items():
                assert original_digests[prefix+'export/'+name] == digest
            for name, digest in admission['source_sha256'].items():
                assert sha(REPO/name) == digest
            outer = document(prefix+'export/report.json')
            for name, digest in outer['output_sha256'].items():
                assert original_digests[prefix+'export/'+name] == digest
            csv_path = prefix+'export/ledger.csv'
            csv_count = sum(1 for _ in csv.DictReader(io.StringIO(raw(csv_path).decode())))
            assert csv_count == admission['csv_scalar_rows_verified']
            for source in handoff['sources']:
                for field in ('ledger', 'original_conditioned_source', 'original_source', 'original_report',
                              'original_evidence', 'unqualified_contributors_reference'):
                    reference = source[field]
                    if reference is not None:
                        assert original_digests[prefix+reference['path']] == reference['sha256']
                ledger_ref, original_ref = source['ledger'], source['original_conditioned_source']
                ledger = pointer(document(prefix+ledger_ref['path']), ledger_ref['json_pointer'])
                expected = pointer(document(prefix+original_ref['path']), original_ref['json_pointer'])
                joint = source['component_joint_source']
                assert joint['ledger_components_pointer'] == ledger_ref['json_pointer']+'/components'
                assert joint['source_components_pointer'] == original_ref['json_pointer']+'/components'
                assert len(ledger['components']) == len(expected['components']) == joint['component_count']
                assert source['resolved_total'] == ledger['resolved']['total']
                assert source['matched_uniform_width_total'] == ledger['matched_uniform_width']['total']
                assert source['source_association'] == ledger['source_association'] and source['geometry'] == ledger['geometry']
                assert source['validation_summary']['source_association_bound'] is True
                assert source['validation_summary']['algebraically_consistent'] is True
                assert all(value == 'pending_owner_supplied' for value in source['required_owner_context'].values())
                total_sources += 1
                total_components += joint['component_count']
        assert (total_sources, total_components) == (9, 1840)
        for folder in ('admitted-study/export/study', 'admitted-packet/export/packet_export'):
            prefix = 'evidence/'+folder+'/'
            nested = document(prefix+'report.json')
            for name, digest in nested['output_sha256'].items():
                assert original_digests[prefix+name] == digest
        stdlib_prefix = 'evidence/stdlib-packet-admission/'
        stdlib = document(stdlib_prefix+'admission.json')
        assert stdlib['expected_report_sha256'] == TRUSTED['packet']
        for name, digest in stdlib['output_sha256'].items():
            assert original_digests[stdlib_prefix+name] == digest
        for name, digest in stdlib['source_sha256'].items():
            assert sha(REPO/name) == digest
        assert document('evidence/portable/stdlib-imports.json')
        result = {**frozen, 'status': 'passed', 'actual_archive_regular_files': len(digests),
            'unsafe_or_duplicate_members': 0, 'input_code_output_bindings_verified': True, 'repository_clean': True,
            'actual_source_descriptors': total_sources, 'actual_joint_component_references': total_components,
            'independent_consumer_evidence_bound': True, 'archive_math_or_admission_repeated': False}
    save(WORK/'delivery_verification.json', result)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
