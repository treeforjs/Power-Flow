"""Freeze trusted-input and independent owner-descriptor readback evidence."""
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
WORK=HERE.parent
ROOT=Path('/workspace/Power-Flow')

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path): return json.loads(Path(path).read_bytes())

verification=read(HERE/'verification.json')
trusted=read(HERE/'trusted_inputs.json')
assert verification['all_checks_passed'] is True
assert verification['trusted_inputs_sha256']==sha(HERE/'trusted_inputs.json')
assert sha(HERE/'inventory.py')==trusted['script_sha256']
assert sha(HERE/'verify_admissions.py')==verification['script_sha256']
assert all(sha(Path(path))==digest for path,digest in verification['input_files_sha256'].items())
exports=[]
for record in verification['exports']:
    directory=Path(record['admission'])
    admission=read(directory/'admission.json')
    handoff=read(directory/'owner_handoff.json')
    assert admission['host_budget_accepted'] is False and admission['owner_implementation_verified'] is False
    assert admission['physical_truth_verified'] is False
    assert all(sha(ROOT/name)==digest for name,digest in admission['source_sha256'].items())
    exports.append({'kind':record['kind'],'admission_directory':str(directory),
        'admission_sha256':sha(directory/'admission.json'),'owner_handoff_sha256':sha(directory/'owner_handoff.json'),
        'trusted_original_export_report_sha256':admission['expected_report_sha256'],
        'admission_source_sha256':admission['source_sha256'],
        'owner_required_context':handoff['required_owner_context'],
        'source_count':record['sources_checked'],'component_count':record['component_associations_checked'],
        'full_and_width_group_rows_bound':record['full_and_width_group_rows_bound'],
        'datafile_references_checked':record['datafile_references_checked'],
        'host_budget_accepted':False,'owner_implementation_verified':False,'physical_truth_verified':False,
        'tamper_controls':record['tamper_controls']})
commands=[json.loads(line) for line in (WORK/'commands.jsonl').read_text().splitlines() if line]
wanted={'009c10de76eadee84edc98ed828399e6078665188be3ff8123d20bf99726b8f8',
    '3c48f4729b180381f95a19103070320c0ccd2c12812ae0bd179684f0a1077441',
    'a40a7dcd27d65bc7789b7d9f229dcdfce53d4d624a05964be51104592738f955',
    'f0a5042333618138a738b1f68093bbaf0714dbdd112b41f2df3a2a574e6de9f8'}
evidence=[record for record in commands if record['log_sha256'] in wanted]
assert len(evidence)==len(wanted)
assert all(record['exit_code']==0 and sha(record['log'])==record['log_sha256'] for record in evidence)
artifacts={str(path.relative_to(HERE)):sha(path) for path in HERE.iterdir()
    if path.is_file() and path.name!='completion.json'}
result={'schema':'mitl-saved-admission-verification-completion-v1','all_checks_passed':True,
    'parameter_status':'manufactured','trusted_inputs_sha256':sha(HERE/'trusted_inputs.json'),
    'verification_sha256':sha(HERE/'verification.json'),'script_sha256':sha(__file__),
    'artifact_sha256':artifacts,'exports':exports,'command_evidence':evidence,
    'source_count':sum(record['source_count'] for record in exports),
    'component_count':sum(record['component_count'] for record in exports),
    'full_and_width_group_rows_bound':sum(record['full_and_width_group_rows_bound'] for record in exports),
    'datafile_references_checked':sum(record['datafile_references_checked'] for record in exports),
    'unique_tamper_families':3,'rejected_tamper_outcomes':sum(len(record['tamper_controls']) for record in exports),
    'no_source_moment_sampler_producer_admission_or_owner_solver_calls_by_consumer':True,
    'no_original_input_files_modified':True,'host_budget_accepted':False,
    'owner_implementation_verified':False,'physical_truth_verified':False,
    'qualification_scope':['Externally saved prior status and frozen-handoff report digests matched actual original report bytes before admission consumption.',
        'Exact raw datafile pins and canonical parsed-ledger hashes remain distinct; full original component/window/state/temperature/quantity qualification types stay bound.',
        'The descriptor retains full declared geometry, exact original totals, width group support and original unavailable-contributor catalog references.',
        'Packet supplied masses/normal geometry/array references remain manufactured original context; study packet context remains explicitly absent.',
        'All physical emission, fields, Hall feedback, loss/collection, state response and precision/acceptance policy context remains pending owner supply.',
        'Three tamper families were applied independently to both descriptors as new work-only copies, producing six expected rejections.'],
    'limits':['Read-only upstream admission does not accept a host transaction or verify owner implementation or physical truth.',
        'Manufactured generic-pool evidence is not physical water calibration, spectral distinguishability, charged transport or molecular kinetics.',
        'Original model evolution, moment estimates, packet realizations, producer exports and old passing suites were not repeated by this consumer.']}
target=HERE/'completion.json'
with target.open('x') as handle: handle.write(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps({'completion':str(target),'sha256':sha(target),
    **{name:result[name] for name in ('source_count','component_count','full_and_width_group_rows_bound',
        'datafile_references_checked','unique_tamper_families','rejected_tamper_outcomes')}},indent=2))
