"""Bind prior reviewed report digests to existing owner-admission inputs."""
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
STATUS=Path('/workspace/research_work/mitl-upstream-status.json')
OLD=Path('/workspace/research_work/mitl-upstream-20261019T0250')
HANDOFF=Path('/workspace/handoffs/mitl-window-source-ledgers-20261019T0250')

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path): return json.loads(Path(path).read_bytes())
def save(path,value):
    with path.open('x') as handle: handle.write(json.dumps(value,indent=2,allow_nan=False)+'\n')
def pointer(document,path):
    for key in path.strip('/').split('/') if path else ():
        document=document[int(key)] if isinstance(document,list) else document[key.replace('~1','/').replace('~0','~')]
    return document

def main():
    raw=STATUS.read_bytes()
    status=json.loads(raw)
    manifest=read(HANDOFF/'manifest.sha256.json')
    trusted=status['source_window_ledgers']
    records=[]
    for kind,name,key in (('study','saved-study-ledgers','saved_study_export_sha256'),
                         ('packet','saved-packet-ledger','saved_packet_export_sha256')):
        directory=OLD/name
        report_path=directory/'report.json'
        expected=trusted[key]
        assert sha(report_path)==expected
        archived='evidence/'+name+'/report.json'
        assert manifest[archived]==expected and sha(HANDOFF/archived)==expected
        report=read(report_path)
        assert report['parameter_status']=='manufactured' and report['host_budget_accepted'] is False
        sources=[]
        def source_record(case_id,window_index,window,ledger_file,ledger_pointer,original_file,source_pointer,source_file):
            for filename in {ledger_file,original_file,source_file}:
                assert sha(directory/filename)==report['output_sha256'][filename]
            ledger=pointer(read(directory/ledger_file),ledger_pointer)
            original=pointer(read(directory/original_file),source_pointer)
            assert ledger['components_included'] is True
            assert len(ledger['components'])==len(original['components'])==ledger['component_count']
            for index,(a,b) in enumerate(zip(ledger['components'],original['components'])):
                assert a['component_index']==index and a['source_window']==b['source_window']
                for field in ('selection_index','interval_index','reservoir_index','current_index','width_index',
                              'interval_origin_s','x_bounds_m','z_bounds_m'):
                    assert a[field]==b[field]
            return {'original_case_id':case_id,'window_index':window_index,'window':window,
                'ledger':{'path':ledger_file,'sha256':report['output_sha256'][ledger_file],'json_pointer':ledger_pointer},
                'original_conditioned_source':{'path':original_file,'sha256':report['output_sha256'][original_file],'json_pointer':source_pointer},
                'original_source':{'path':source_file,'sha256':report['output_sha256'][source_file]},
                'component_count':ledger['component_count'],'parameter_status':original['status'],
                'source_parameter_provenance':original['parameter_provenance'],'conditioning_provenance':original['provenance'],
                'ledger_group_counts':{hyp:{group:1 if group=='total' else len(rows) for group,rows in ledger[hyp].items()}
                    for hyp in ('resolved','matched_uniform_width')},
                'unqualified_contributors':len(ledger['unqualified_contributors']),
                'host_budget_accepted':False,'owner_implementation_accepted':False,
                'owner_response_kernel_supplied':False}
        if kind=='study':
            for case in report['cases']:
                filename=report['case_ledger_files'][case['case_id']]
                stored=read(directory/filename)
                for ordinal,item in enumerate(stored['windows']):
                    sources.append(source_record(case['case_id'],item['window_index'],item['window'],filename,
                        '/windows/'+str(ordinal)+'/ledger','study/case_'+case['case_id']+'.json',
                        '/windows/'+str(ordinal)+'/conditioned_source','study/source_'+case['case_id']+'.h5'))
        else:
            sources.append(source_record(None,None,None,'ledger.json','','packet_export/report.json',
                '/conditioned_source','packet_export/source_input.h5'))
        records.append({'kind':kind,'directory':str(directory),'report_file':str(report_path),
            'expected_report_sha256':expected,'trust_source':{'status_json_pointer':'/source_window_ledgers/'+key,
                'status_sha256_at_capture':hashlib.sha256(raw).hexdigest(),
                'prior_handoff_manifest':str(HANDOFF/'manifest.sha256.json'),
                'prior_handoff_manifest_sha256':sha(HANDOFF/'manifest.sha256.json'),
                'prior_handoff_report_path':archived,'prior_handoff_report_sha256':expected},
            'export_schema':report['schema'],'parameter_status':report['parameter_status'],
            'original_export_output_sha256':report['output_sha256'],'original_export_source_sha256':report['source_sha256'],
            'sources':sources,'component_count':sum(source['component_count'] for source in sources)})
    assert {record['kind']:record['component_count'] for record in records}=={'study':1792,'packet':48}
    snapshot=HERE/'status_snapshot.json'
    with snapshot.open('xb') as handle: handle.write(raw)
    result={'schema':'mitl-trusted-saved-ledger-admission-inputs-v1',
        'trust_basis':'Expected report digests come from prior reviewed status fields and the frozen prior handoff manifest; actual file hashes are checked against those saved digests, not treated as approval by themselves.',
        'status_snapshot':str(snapshot),'status_snapshot_sha256':sha(snapshot),'script_sha256':sha(__file__),
        'exports':records,'no_source_moment_sampler_producer_or_admission_calls':True,
        'limits':['Manufactured provenance is retained; record validation cannot establish physical H2O parameters or an owner response kernel.',
            'No host transaction, owner implementation, physical response or production run is accepted.',
            'The original packet export has no case/window label; any admission role label must remain explicitly synthetic context.']}
    save(HERE/'trusted_inputs.json',result)
    print(json.dumps({'trusted_inputs':str(HERE/'trusted_inputs.json'),'sha256':sha(HERE/'trusted_inputs.json'),
        'reports':[{'kind':record['kind'],'expected_report_sha256':record['expected_report_sha256'],
            'sources':len(record['sources']),'components':record['component_count']} for record in records]},indent=2))

if __name__=='__main__': main()
