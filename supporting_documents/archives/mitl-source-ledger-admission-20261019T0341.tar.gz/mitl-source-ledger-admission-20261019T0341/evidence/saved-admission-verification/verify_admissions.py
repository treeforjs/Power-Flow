"""Independent owner-descriptor consumption against previously trusted exports.

Only JSON and bound file bytes are read. This script imports no source,
admission, ledger producer, moment, particle, chemistry or transport routine.
"""
import argparse
import copy
import hashlib
import json
from pathlib import Path


HERE=Path(__file__).resolve().parent


def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def canonical(value): return json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
def same(a,b): return canonical(a)==canonical(b)
def require(condition,reason):
    if not condition: raise ValueError(reason)
def read(path):
    def pairs(items):
        result={}
        for key,value in items:
            require(key not in result,'duplicate JSON key: '+key)
            result[key]=value
        return result
    def reject(value): raise ValueError('nonfinite JSON value: '+value)
    return json.loads(Path(path).read_bytes(),object_pairs_hook=pairs,parse_constant=reject)
def pointer(document,path):
    require(path=='' or (isinstance(path,str) and path.startswith('/')),'invalid absolute JSON pointer')
    for key in path.strip('/').split('/') if path else ():
        document=document[int(key)] if isinstance(document,list) else document[key.replace('~1','/').replace('~0','~')]
    return document
def safe(base,name):
    require(isinstance(name,str),'reference path is not explicit')
    path=base/name
    require(not Path(name).is_absolute() and path.resolve().is_relative_to(base.resolve()),'reference path escapes admission')
    require(path.is_file() and not path.is_symlink(),'reference does not name a local regular file')
    return path


def check_handoff(handoff,admission_dir,expected):
    require(handoff['schema']=='mhdlab-source-ledger-owner-handoff-v1','wrong owner descriptor schema')
    require(handoff['host_budget_accepted'] is False,'owner descriptor escalates host budget acceptance')
    require(handoff['owner_implementation_verified'] is False,'owner descriptor escalates implementation verification')
    require(handoff['physical_truth_verified'] is False,'owner descriptor escalates physical truth verification')
    pending={name:'pending_owner_supplied' for name in ('physical_emission_kernel','electromagnetic_fields','hall_feedback',
        'loss_and_boundary_collection','state_kinetics_and_response','owner_precision_and_acceptance_policy')}
    require(same(handoff['required_owner_context'],pending),'physical, response or acceptance context is no longer explicitly pending')
    require(len(handoff['sources'])==len(expected['sources']),'source count changed')
    by_ledger={(item['ledger']['path'],item['ledger']['json_pointer']):item for item in expected['sources']}
    seen=set()
    checked_components=0
    checked_groups=0
    checked_references=0
    contexts=[]
    for item in handoff['sources']:
        require(item['host_budget_accepted'] is False and item['owner_implementation_verified'] is False
            and item['physical_truth_verified'] is False,'source descriptor escalates host, owner or physical verification')
        require(item['source_quantity_qualification_recomputed'] is False,'source descriptor promotes original qualification to a new physical calculation')
        require(same(item['required_owner_context'],pending),'source owner requirements are no longer pending')
        ledger_ref=item['ledger']
        key=(ledger_ref['path'].removeprefix('export/'),ledger_ref['json_pointer'])
        require(key in by_ledger and key not in seen,'owner source ledger reference is missing, duplicated or unexpected')
        seen.add(key)
        original=by_ledger[key]
        if expected['kind']=='study':
            require(item['case_id']==original['original_case_id'] and same(item['window_index'],original['window_index'])
                and same(item['window'],original['window']),'preserved study case/window identity changed')
            require(item['label_origin']=='preserved_study_case_and_global_window','study label origin is not retained')
        else:
            require(item['case_id']=='packet_source' and item['window_index'] is None and item['window'] is None,
                'packet role label invents an original global window')
            require(item['label_origin']=='ledger_export_context','packet introduced label context is missing')
        documents={}
        objects={}
        for kind in ('ledger','original_conditioned_source','original_source'):
            supplied=item[kind]
            target=original[kind]
            require(supplied['path']=='export/'+target['path'],'owner '+kind+' file association changed')
            require(supplied['sha256']==target['sha256'],'owner '+kind+' datafile pin changed')
            path=safe(admission_dir,supplied['path'])
            require(sha(path)==target['sha256'],'owner '+kind+' file bytes differ from trusted export')
            checked_references+=1
            if kind!='original_source':
                require(supplied['json_pointer']==target['json_pointer'],'owner '+kind+' JSON pointer changed')
                documents[kind]=read(path)
                objects[kind]=pointer(documents[kind],supplied['json_pointer'])
        ledger,source=objects['ledger'],objects['original_conditioned_source']
        aux_names={'original_report':'study/report.json' if expected['kind']=='study' else 'packet_export/report.json',
            'original_evidence':('study/evidence_'+original['original_case_id']+'.json') if expected['kind']=='study'
                else ('packet_export/source_run_summary.json' if 'packet_export/source_run_summary.json' in expected['original_export_output_sha256'] else None)}
        for name,filename in aux_names.items():
            ref=item[name]
            if filename is None:
                require(ref is None,'absent original evidence was invented')
            else:
                digest=expected['original_export_output_sha256'][filename]
                require(ref['path']=='export/'+filename and ref['sha256']==digest
                    ==sha(safe(admission_dir,ref['path'])),'original report/evidence file pin changed')
                checked_references+=1
        packet_context=item['packet_context']
        if expected['kind']=='study':
            require(same(packet_context,{'available':False,'reason':'no_packet_mass_or_normal_geometry_in_study_export',
                'owner_supplied_required':True}),'study descriptor invents packet mass or face-normal geometry')
        else:
            require(packet_context['available'] is True and packet_context['realization_recomputed'] is False,
                'packet descriptor realization/status changed')
            require(packet_context['array_contents_parsed'] is False and packet_context['normal_geometry_is_supplied_context'] is True,
                'packet descriptor claims newly parsed arrays or reconstructed normal geometry')
            original_packet_report=documents['original_conditioned_source']
            config_path=safe(admission_dir,'export/packet_export/input_config.json')
            config=read(config_path)
            reference=packet_context['config_reference']
            require(reference['path']=='export/packet_export/input_config.json'
                and reference['sha256']==expected['original_export_output_sha256']['packet_export/input_config.json']
                ==sha(config_path),'packet config reference pin changed')
            require(packet_context['mass_status']==original_packet_report['mass_status']
                and packet_context['mass_provenance']==original_packet_report['mass_provenance'],
                'packet mass status/provenance changed')
            for field in ('state_masses_kg','face_normal_coordinate_m','outward_normal_sign'):
                require(same(packet_context[field],config[field]),'packet original '+field+' or type changed')
            arrays=packet_context['arrays']
            require({entry['path'] for entry in arrays}=={'export/packet_export/boundary_packets.npz','export/packet_export/uniforms.npy'},
                'packet array associations changed')
            for entry in arrays:
                original_name=entry['path'].removeprefix('export/')
                require(entry['sha256']==expected['original_export_output_sha256'][original_name]
                    ==sha(safe(admission_dir,entry['path'])),'packet array datafile pin changed')
                checked_references+=1
            checked_references+=1
        require(ledger['components_included'] is True and ledger['host_budget_accepted'] is False,'joint ledger components or host flag changed')
        require(source['host_budget_accepted'] is False and source['status']==original['parameter_status'],'source status or host acceptance changed')
        joint=item['component_joint_source']
        expected_ledger_pointer=ledger_ref['json_pointer']+'/components'
        expected_source_pointer=item['original_conditioned_source']['json_pointer']+'/components'
        require(joint['ledger_components_pointer']==expected_ledger_pointer,'owner ledger component pointer no longer names full joint components')
        require(joint['source_components_pointer']==expected_source_pointer,'owner source component pointer no longer names full joint components')
        require(joint['component_records_preserved'] is True and joint['state_temperature_timing_are_joint'] is True,
            'joint component preservation/interpretation flags changed')
        ledger_components=pointer(documents['ledger'],joint['ledger_components_pointer'])
        source_components=pointer(documents['original_conditioned_source'],joint['source_components_pointer'])
        require(type(joint['component_count']) is int and joint['component_count']==original['component_count']
            ==len(ledger_components)==len(source_components),'owner component count changed')
        for index,(a,b) in enumerate(zip(ledger_components,source_components)):
            require(type(a['component_index']) is int and a['component_index']==index,'component index or type changed')
            for field in ('selection_index','interval_index','reservoir_index','current_index','width_index','interval_origin_s','x_bounds_m','z_bounds_m'):
                require(same(a[field],b[field]),'joint component original '+field+' association or type changed')
            require(same(a['source_window'],b['source_window']),'source-window quantities, qualification or types changed')
            checked_components+=1
        require(same(item['source_association'],ledger['source_association']),'owner source provenance/qualification association changed')
        require(same(item['geometry'],ledger['geometry']),'owner geometry association changed')
        require(same(item['resolved_total'],ledger['resolved']['total']),'owner resolved total is not the exact source group')
        require(same(item['matched_uniform_width_total'],ledger['matched_uniform_width']['total']),'owner matched-width total is not the exact source group')
        unavailable_ref=item['unqualified_contributors_reference']
        require(unavailable_ref['path']==ledger_ref['path'] and unavailable_ref['sha256']==ledger_ref['sha256']
            and unavailable_ref['json_pointer']==ledger_ref['json_pointer']+'/unqualified_contributors',
            'owner unavailable-contributor catalog reference changed')
        require(same(pointer(documents['ledger'],unavailable_ref['json_pointer']),ledger['unqualified_contributors']),
            'owner unavailable-contributor reasons or types changed')
        for hypothesis in ('resolved','matched_uniform_width'):
            require({group:1 if group=='total' else len(rows) for group,rows in ledger[hypothesis].items()}
                ==original['ledger_group_counts'][hypothesis],'owner source full/width group support changed')
            checked_groups+=sum(original['ledger_group_counts'][hypothesis].values())
        summary=item['validation_summary']
        require(summary['algebraically_consistent'] is True and summary['source_association_bound'] is True,'source is not bound by admission summary')
        require(summary['host_budget_accepted'] is False,'source summary accepts a host transaction')
        require(summary['ledger_sha256']==hashlib.sha256(canonical(ledger)).hexdigest(),
            'source summary canonical parsed-JSON ledger hash changed or confused with raw file hash')
        require(type(summary['component_count']) is int and summary['component_count']==original['component_count'],'source summary component count/type changed')
        expected_group_count=sum(sum(groups.values()) for groups in original['ledger_group_counts'].values())
        expected_group_count+=(len(source['z_edges_m'])-1)*len({pool['state_id'] for pool in source['source_reservoirs']})
        require(type(summary['group_count']) is int and summary['group_count']==expected_group_count,
            'source summary group count or type changed')
        require(type(summary['skipped_zero_initial_count']) is int and summary['skipped_zero_initial_count']==len(source['skipped_zero_initials']),
            'source summary skipped-zero count or type changed')
        require(same(summary['total_quantity_availability'],{name:quantity['available'] for name,quantity in ledger['resolved']['total']['quantities'].items()}),
            'source summary changes independent quantity availability/types')
        require(summary['unqualified_contributor_count']==len(ledger['unqualified_contributors']),'source summary unavailable catalog count changed')
        contexts.append({'case_id':item['case_id'],'window_index':item['window_index'],'label_origin':item['label_origin'],
            'component_count':joint['component_count'],'status':source['status'],'parameter_provenance':source['parameter_provenance'],
            'source_provenance':source['provenance']})
    require(seen==set(by_ledger),'some trusted source was omitted')
    return {'sources_checked':len(seen),'component_associations_checked':checked_components,
        'full_and_width_group_rows_bound':checked_groups,'datafile_references_checked':checked_references,'contexts':contexts}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--study-admission',type=Path,required=True)
    parser.add_argument('--packet-admission',type=Path,required=True)
    args=parser.parse_args()
    trusted=read(HERE/'trusted_inputs.json')
    inputs={str(HERE/'trusted_inputs.json'):sha(HERE/'trusted_inputs.json')}
    results=[]
    for expected in trusted['exports']:
        directory=getattr(args,expected['kind']+'_admission')
        admission_path=directory/'admission.json'
        owner_path=directory/'owner_handoff.json'
        admission=read(admission_path)
        require(admission['schema']=='mhdlab-source-ledger-export-admission-v1','wrong admission schema')
        require(admission['expected_report_sha256']==expected['expected_report_sha256'],'admission uses an untrusted report digest')
        require(admission['input_export_schema']==expected['export_schema'],'original export schema changed')
        require(admission['host_budget_accepted'] is False and admission['owner_implementation_verified'] is False
            and admission['physical_truth_verified'] is False,'admission escalates host, owner or physical verification')
        expected_files={'report.json':expected['expected_report_sha256'],**expected['original_export_output_sha256']}
        require(same(admission['input_export_sha256'],expected_files),'admission original export file pins changed')
        for name,digest in admission['output_sha256'].items():
            path=safe(directory,name)
            require(sha(path)==digest,'admission output hash changed: '+name)
            inputs[str(path.resolve())]=digest
        inputs[str(admission_path.resolve())]=sha(admission_path)
        owner=read(owner_path)
        checked=check_handoff(owner,directory,expected)
        tamper_results=[]
        for label,mutate in (
            ('joint_source_pointer_to_single_component',lambda value:value['sources'][0]['component_joint_source'].__setitem__('source_components_pointer',value['sources'][0]['component_joint_source']['source_components_pointer']+'/0')),
            ('original_source_datafile_pin_corrupted',lambda value:value['sources'][0]['original_source'].__setitem__('sha256','0'*64)),
            ('host_budget_acceptance_escalation',lambda value:value.__setitem__('host_budget_accepted',True)),
        ):
            changed=copy.deepcopy(owner)
            mutate(changed)
            try:
                check_handoff(changed,directory,expected)
            except (ValueError,KeyError,TypeError,IndexError) as error:
                outcome={'tamper':label,'rejected':True,'reason':str(error)}
            else:
                raise AssertionError('bounded owner-consumption tamper was accepted: '+label)
            target=HERE/(expected['kind']+'-'+label+'.json')
            with target.open('x') as handle: handle.write(json.dumps(changed,indent=2,allow_nan=False)+'\n')
            outcome['artifact_sha256']=sha(target)
            tamper_results.append(outcome)
        results.append({'kind':expected['kind'],'admission':str(directory),'admission_sha256':sha(admission_path),
            'owner_handoff_sha256':sha(owner_path),**checked,'tamper_controls':tamper_results})
    require(all(sha(Path(path))==digest for path,digest in inputs.items()),'admission input changed during readback')
    result={'schema':'mitl-independent-saved-admission-verification-v1','trusted_inputs_sha256':sha(HERE/'trusted_inputs.json'),
        'input_files_sha256':inputs,'script_sha256':sha(__file__),'all_checks_passed':True,'exports':results,
        'no_source_moment_sampler_producer_admission_or_owner_solver_calls':True,
        'limitations':['These checks qualify descriptor consumption of the preserved manufactured source exports only.',
            'No host transaction, owner implementation, physical response kernel, water calibration or spectral prediction is accepted.',
            'Tampered owner descriptors are new work-only copies. Original exports and their admission copies remain unchanged.']}
    target=HERE/'verification.json'
    with target.open('x') as handle: handle.write(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'verification':str(target),'sha256':sha(target),
        'sources_checked':sum(record['sources_checked'] for record in results),
        'components_checked':sum(record['component_associations_checked'] for record in results),
        'tamper_controls_rejected':sum(len(record['tamper_controls']) for record in results)},indent=2))

if __name__=='__main__': main()
