"""Prepare and inspect an isolated public source-ledger admission subset."""
from __future__ import annotations

import argparse
import ast
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import runpy
import shutil
import subprocess
import sys
import sysconfig
import venv
import xml.etree.ElementTree as ET

WORK = Path(__file__).resolve().parent
REPO = Path('/workspace/Power-Flow')
PORTABLE = WORK/'portable'
SOURCE = PORTABLE/'source'
PRIOR = Path('/workspace/handoffs/mitl-window-source-ledgers-20261019T0250/source_file_list.json')
PUBLIC_COMMIT = '079bddf9f81021ee4f3d79c42011185511d53747'
NEW = {
    'mhdlab/window_source_ledger_validation.py',
    'tests/test_window_source_ledger_validation.py',
    'tools/admit_source_ledger_export.py',
    'tests/test_source_ledger_admission_cli.py',
    'docs/source_ledger_admission.md',
}
FORBIDDEN = {
    'mhdlab/runner.py', 'mhdlab/chemistry.py', 'mhdlab/bolsig.py', 'mhdlab/cr_data.py',
    'mhdlab/kinetic_gap.py', 'mhdlab/state_kinetics.py', 'mhdlab/reaction_kinematics.py',
    'mhdlab/mhd.py', 'mhdlab/neutrals.py', 'mhdlab/spectra.py', 'mhdlab/diagnostics.py',
}
DEPENDENCIES = ('numpy', 'scipy', 'h5py', 'matplotlib', 'pytest')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False)+'\n')


def closure():
    prior = json.loads(PRIOR.read_text())
    names = set(prior['byte_identical_public_files']) | NEW
    pending = list(names)
    while pending:
        name = pending.pop()
        if not name.endswith('.py'):
            continue
        tree = ast.parse((REPO/name).read_text())
        needed = set()
        for node in ast.walk(tree):
            if isinstance(node, ast.ImportFrom) and node.module:
                if node.level:
                    needed.add('mhdlab/'+node.module.replace('.', '/')+'.py')
                elif node.module.startswith(('mhdlab.', 'tools.')):
                    needed.add(node.module.replace('.', '/')+'.py')
            elif isinstance(node, ast.Import):
                for alias in node.names:
                    if alias.name.startswith(('mhdlab.', 'tools.')):
                        needed.add(alias.name.replace('.', '/')+'.py')
            if (isinstance(node, ast.Constant) and isinstance(node.value, str)
                    and node.value.startswith(('mhdlab.', 'tools.'))):
                needed.add(node.value.replace('.', '/')+'.py')
        for node in tree.body:
            if (isinstance(node, ast.Assign)
                    and any(isinstance(target, ast.Name) and target.id.endswith('CODE_PATHS')
                            for target in node.targets)):
                try:
                    literal = ast.literal_eval(node.value)
                except (ValueError, TypeError):
                    continue
                if isinstance(literal, (tuple, list)):
                    needed.update(item for item in literal if isinstance(item, str))
        for item in needed:
            if (REPO/item).is_file() and item not in names:
                names.add(item)
                pending.append(item)
    assert not names.intersection(FORBIDDEN), names.intersection(FORBIDDEN)
    assert 'mhdlab/__init__.py' not in names
    return names, prior


def prepare():
    names, prior = closure()
    SOURCE.mkdir(parents=True, exist_ok=True)
    versions = {name: importlib.metadata.version(name) for name in DEPENDENCIES}
    wrappers = {
        'mhdlab/__init__.py': '"""Portable source-ledger admission verification subset."""\n',
        'pytest.ini': '[pytest]\npythonpath = .\n',
        'requirements.txt': ''.join(f'{name}=={version}\n' for name, version in versions.items()),
        'README.md': '''# Source-ledger admission verification subset

The listed public files are byte-identical to commit079bddf9f81021ee4f3d79c42011185511d53747.
Four packaging wrappers isolate this upstream subset from unrelated solver imports.

```sh
python -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python -W error -m pytest tests/test_window_source_ledger_validation.py tests/test_source_ledger_admission_cli.py
```

Only the two new admission suites are selected by this verification. Their
small manufactured source and packet fixtures are generated once during setup;
admission afterward uses JSON, CSV, hashes and exact algebra. Physical source,
law, HDF/array loading, moment, sampler and ledger-producer execution is guarded.
Older modules and tests are retained to satisfy imports and literal code pins,
and are not selected as test suites.

The admission command itself supports system Python with-S and the empty
package initializer. This excludes scientific packages and eager solver imports.
It consumes an externally approved report hash, preserves full component/joint
source references, and does not verify an owner implementation or accept a host
transaction. Read docs/source_ledger_admission.md for the trust boundary.

The managed verification environment reuses installed third-party distributions
in a separate venv; its method and exact versions are recorded outside source/.
Pinned requirements support a fresh installation elsewhere. No local project
or editable import hook is included in that dependency reuse.
''',
    }
    for name in sorted(names):
        target = SOURCE/name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(REPO/name, target)
    for name, text in wrappers.items():
        (SOURCE/name).write_text(text)
    listing = {
        'byte_identical_public_files': sorted(names), 'packaging_wrappers': sorted(wrappers),
        'declared_public_commit': PUBLIC_COMMIT,
        'prior_public_files': len(prior['byte_identical_public_files']),
        'new_admission_files': sorted(NEW),
        'closure_method': 'AST public imports, literal CODE_PATHS and dynamic mhdlab/tools module strings',
        'forbidden_modules_absent': sorted(FORBIDDEN),
    }
    write_json(PORTABLE/'source_file_list.json', listing)
    (PORTABLE/'source-files.sha256').write_text(''.join(f'{sha(SOURCE/name)}  {name}\n' for name in sorted(names)))
    (PORTABLE/'wrapper-files.sha256').write_text(''.join(f'{sha(SOURCE/name)}  {name}\n' for name in sorted(wrappers)))
    print(json.dumps({'public_files': len(names), 'wrappers': len(wrappers), 'new_files': len(NEW),
                      'source': str(SOURCE), 'source_list_sha256': sha(PORTABLE/'source_file_list.json')}, indent=2))


def environment():
    """Use a new venv and unchanged installed third-party files without downloads."""
    target = PORTABLE/'.venv'
    if target.exists():
        raise ValueError('portable venv already exists; refusing to replace it')
    origin = Path(sysconfig.get_path('purelib'))
    assert str(origin).startswith('/workspace/Power-Flow/.venv/')
    hooks = {path.name: path.read_text() for path in origin.glob('*.pth')}
    assert not list(origin.glob('*.egg-link'))
    assert not (origin/'mhdlab').exists()
    assert all('/workspace' not in text and 'Power-Flow' not in text for text in hooks.values())
    venv.create(target, with_pip=False, system_site_packages=False)
    executable = target/'bin/python'
    destination = Path(subprocess.check_output([str(executable), '-c',
        "import sysconfig; print(sysconfig.get_path('purelib'))"], text=True).strip())
    shutil.copytree(origin, destination, dirs_exist_ok=True, symlinks=True, copy_function=os.link,
                    ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
    details = json.loads(subprocess.check_output([str(executable), '-c',
        "import sys,sysconfig,importlib.metadata,json; print(json.dumps({'executable':sys.executable,"
        "'prefix':sys.prefix,'purelib':sysconfig.get_path('purelib'),'versions':"
        "{name:importlib.metadata.version(name) for name in ('numpy','scipy','h5py','matplotlib','pytest')}}))"],
        text=True))
    record = {'method': 'new venv; hardlinked unchanged installed third-party site-packages; no network install',
              'origin_site_packages': str(origin), 'origin_pth_hooks': hooks,
              'project_package_or_editable_hook_reused': False, **details}
    write_json(PORTABLE/'environment.json', record)
    print(json.dumps(record, indent=2))


def stdlib_packet():
    """Run only the pure admission entry point against an independently pinned export."""
    if not sys.flags.no_site:
        raise ValueError('stdlib admission proof must be invoked with Python-S')
    trusted = WORK/'saved-admission-verification/trusted_inputs.json'
    trust = json.loads(trusted.read_text())
    matches = [item for item in trust['exports'] if item['kind'] == 'packet']
    if len(matches) != 1:
        raise ValueError('trusted input map must have exactly one packet export')
    item = matches[0]
    export = Path(item['directory'])
    pin = item['expected_report_sha256']
    output = WORK/'stdlib-packet-admission'
    blocked_roots = {'numpy', 'scipy', 'h5py', 'matplotlib', 'pytest'}
    blocked_modules = {name.removesuffix('.py').replace('/', '.') for name in FORBIDDEN}
    before = set(sys.modules)
    sys.argv = [str(SOURCE/'tools/admit_source_ledger_export.py'), '--export', str(export),
                '--expected-report-sha256', pin, '--output-dir', str(output)]
    runpy.run_path(str(SOURCE/'tools/admit_source_ledger_export.py'), run_name='__main__')
    assert not ({name.split('.')[0] for name in sys.modules} & blocked_roots)
    assert not (set(sys.modules) & blocked_modules)
    local = {name: str(Path(module.__file__).resolve()) for name, module in sys.modules.items()
             if name.startswith(('mhdlab', 'tools')) and getattr(module, '__file__', None)}
    assert all(Path(path).is_relative_to(SOURCE) for path in local.values())
    record = {'system_python': sys.executable, 'python_version': sys.version, 'no_site': bool(sys.flags.no_site),
              'trusted_input_file': str(trusted), 'trusted_input_sha256': sha(trusted),
              'export_directory': str(export), 'approved_report_sha256': pin,
              'output': str(output), 'numerical_package_imports': [], 'forbidden_module_imports': [],
              'local_module_paths': local, 'newly_imported_modules': sorted(set(sys.modules)-before),
              'admission_sha256': sha(output/'admission.json'),
              'owner_handoff_sha256': sha(output/'owner_handoff.json')}
    write_json(PORTABLE/'stdlib-imports.json', record)
    print(json.dumps({'proof': str(PORTABLE/'stdlib-imports.json'), 'local_modules': local,
                      'no_site': True, 'numerical_package_imports': [], 'output': str(output)}, indent=2))


def verify():
    listing = json.loads((PORTABLE/'source_file_list.json').read_text())
    public = listing['byte_identical_public_files']
    assert all(sha(SOURCE/name) == sha(REPO/name) for name in public)
    names = set(public) | set(listing['packaging_wrappers'])
    actual = {path.relative_to(SOURCE).as_posix() for path in SOURCE.rglob('*') if path.is_file()
              and '__pycache__' not in path.parts and '.pytest_cache' not in path.parts}
    assert names == actual, sorted(actual-names)
    assert not set(public).intersection(FORBIDDEN)
    assert (SOURCE/'mhdlab/__init__.py').read_text() == '"""Portable source-ledger admission verification subset."""\n'
    print(json.dumps({'byte_identical_public_files': len(public), 'packaging_wrappers': len(names)-len(public),
                      'forbidden_modules_present': [], 'source_list_sha256': sha(PORTABLE/'source_file_list.json')}, indent=2))


def clean():
    for path in sorted(SOURCE.rglob('__pycache__'), key=lambda p: len(p.parts), reverse=True):
        shutil.rmtree(path)
    for path in sorted(SOURCE.rglob('.pytest_cache'), key=lambda p: len(p.parts), reverse=True):
        shutil.rmtree(path)
    print(json.dumps({'source_caches_remaining': [str(p) for p in SOURCE.rglob('*')
          if p.is_dir() and p.name in {'__pycache__', '.pytest_cache'}]}))


def same_json(left, right):
    if type(left) is not type(right):
        return False
    if isinstance(left, dict):
        return set(left) == set(right) and all(same_json(left[key], right[key]) for key in left)
    if isinstance(left, list):
        return len(left) == len(right) and all(same_json(a, b) for a, b in zip(left, right))
    if isinstance(left, float):
        return left.hex() == right.hex()
    return left == right


def compare():
    root = WORK/'admitted-packet'
    isolated = WORK/'stdlib-packet-admission'
    root_owner = json.loads((root/'owner_handoff.json').read_text())
    isolated_owner = json.loads((isolated/'owner_handoff.json').read_text())
    root_admission = json.loads((root/'admission.json').read_text())
    isolated_admission = json.loads((isolated/'admission.json').read_text())
    fields = ('expected_report_sha256', 'input_export_schema', 'input_export_sha256',
              'source_sha256', 'sources', 'host_budget_accepted', 'owner_implementation_verified')
    comparisons = {name: name in root_admission and name in isolated_admission
                   and same_json(root_admission[name], isolated_admission[name]) for name in fields}
    source_bound = [source['validation_summary']['source_association_bound'] is True
                    for source in isolated_owner['sources']]
    original_report = json.loads((root/'export/report.json').read_text())
    isolated_report = json.loads((isolated/'export/report.json').read_text())
    record = {
        'comparison': 'type-sensitive JSON equality, including binary64 signed-zero representation',
        'owner_handoff_identical': same_json(root_owner, isolated_owner),
        'owner_handoff_bytes_identical': sha(root/'owner_handoff.json') == sha(isolated/'owner_handoff.json'),
        'root_owner_handoff_sha256': sha(root/'owner_handoff.json'),
        'stdlib_owner_handoff_sha256': sha(isolated/'owner_handoff.json'),
        'admission_shared_fields': comparisons,
        'all_source_summaries_bound': bool(source_bound) and all(source_bound),
        'source_count': len(source_bound),
        'producer_pins_unchanged': same_json(original_report['source_sha256'], isolated_report['source_sha256']),
        'original_report_bytes_identical': sha(root/'export/report.json') == sha(isolated/'export/report.json'),
        'approved_report_sha256': isolated_admission['expected_report_sha256'],
        'no_validator_or_producer_repeated': True,
    }
    write_json(PORTABLE/'stdlib-comparison.json', record)
    assert record['owner_handoff_identical'] and record['owner_handoff_bytes_identical']
    assert all(comparisons.values()), comparisons
    assert record['all_source_summaries_bound']
    assert record['producer_pins_unchanged'] and record['original_report_bytes_identical']
    print(json.dumps(record, indent=2))


def summarize():
    listing = json.loads((PORTABLE/'source_file_list.json').read_text())
    xml = ET.parse(PORTABLE/'new0341-results.xml').getroot()
    cases = xml.findall('.//testcase')
    assert len(cases) == 145
    assert not xml.findall('.//failure') and not xml.findall('.//error') and not xml.findall('.//skipped')
    by_class = {}
    for case in cases:
        name = case.attrib['classname']
        by_class[name] = by_class.get(name, 0)+1
    assert sorted(by_class.values()) == [71, 74], by_class
    caches = [str(path.relative_to(SOURCE)) for path in SOURCE.rglob('*') if path.is_dir()
              and path.name in {'__pycache__', '.pytest_cache'}]
    assert not caches
    stdlib = json.loads((PORTABLE/'stdlib-imports.json').read_text())
    comparison = json.loads((PORTABLE/'stdlib-comparison.json').read_text())
    assert stdlib['no_site'] is True and stdlib['numerical_package_imports'] == []
    assert stdlib['forbidden_module_imports'] == []
    assert comparison['owner_handoff_identical'] is True
    for name in listing['byte_identical_public_files']:
        assert sha(SOURCE/name) == sha(REPO/name)
    record = {
        'schema': 'mitl-source-ledger-portable-verification-v1',
        'declared_public_commit': PUBLIC_COMMIT,
        'byte_identical_public_files': len(listing['byte_identical_public_files']),
        'packaging_wrappers': len(listing['packaging_wrappers']),
        'source_sha256': {name: sha(SOURCE/name) for name in listing['byte_identical_public_files']},
        'wrapper_sha256': {name: sha(SOURCE/name) for name in listing['packaging_wrappers']},
        'source_file_list_sha256': sha(PORTABLE/'source_file_list.json'),
        'preparation_script_sha256': sha(Path(__file__)),
        'tests': {'total': len(cases), 'per_class': by_class, 'failed': 0, 'errors': 0, 'skipped': 0,
                  'warnings_as_errors': True, 'only_new_admission_suites_selected': True,
                  'junit': str(PORTABLE/'new0341-results.xml'),
                  'junit_sha256': sha(PORTABLE/'new0341-results.xml'),
                  'log': str(WORK/'portable-new0341-tests.log'),
                  'log_sha256': sha(WORK/'portable-new0341-tests.log'),
                  'portable_failures_or_repairs': []},
        'environment': json.loads((PORTABLE/'environment.json').read_text()),
        'stdlib_proof': str(PORTABLE/'stdlib-imports.json'),
        'stdlib_proof_sha256': sha(PORTABLE/'stdlib-imports.json'),
        'stdlib_comparison': str(PORTABLE/'stdlib-comparison.json'),
        'stdlib_comparison_sha256': sha(PORTABLE/'stdlib-comparison.json'),
        'stdlib_packet_output': str(WORK/'stdlib-packet-admission'),
        'source_caches_remaining': caches,
        'forbidden_modules_present': [],
        'old_test_suites_run': False,
        'saved_source_moments_packets_or_ledgers_regenerated': False,
        'public_source_modified': False,
        'status_commit_or_archive_actions_performed': False,
        'limits': ['Manufactured fresh test fixtures are setup evidence, not physical water or recorded spectra.',
                   'The new venv reuses installed third-party distributions; this is a new import/packaging boundary rather than an independent dependency installation.',
                   'System Python-S admission uses the externally approved prior packet report; source association and algebra do not accept a host transaction or owner implementation.'],
    }
    write_json(PORTABLE/'verification.json', record)
    print(json.dumps({'verification': str(PORTABLE/'verification.json'),
                      'verification_sha256': sha(PORTABLE/'verification.json'),
                      'tests': record['tests'], 'source_caches_remaining': caches,
                      'public_files': record['byte_identical_public_files'],
                      'wrappers': record['packaging_wrappers']}, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('prepare', 'environment', 'stdlib', 'verify', 'clean', 'compare', 'summarize'))
    arguments = parser.parse_args()
    {'prepare': prepare, 'environment': environment, 'stdlib': stdlib_packet,
     'verify': verify, 'clean': clean, 'compare': compare, 'summarize': summarize}[arguments.action]()
