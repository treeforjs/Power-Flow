"""Guard completed ledger admission, retain history and release the pass lease.

Prepared for an explicit final run after delivery verification. Importing this
draft performs no status mutation. Completion rechecks actual compressed bytes,
committed source pins, new portable cases and the standard-library proof while
holding the project status lock. It never invokes a scientific producer.
"""
from collections import Counter
import datetime
import fcntl
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import subprocess
import tarfile
import xml.etree.ElementTree as ET


WORK = Path(__file__).resolve().parent
REPO = Path('/workspace/Power-Flow')
OUT = Path('/workspace/handoffs/mitl-source-ledger-admission-20261019T0341')
EXPECTED_HEAD = '079bddf9f81021ee4f3d79c42011185511d53747'
BASE = '96ba472e21d1f587cd20495ce033fb5eed3e52f3'
SCOPE = ('mhdlab/window_source_ledger_validation.py', 'tests/test_window_source_ledger_validation.py',
         'tools/admit_source_ledger_export.py', 'tests/test_source_ledger_admission_cli.py', 'docs/source_ledger_admission.md')
FALSE_FLAGS = ('host_budget_accepted', 'owner_implementation_verified', 'physical_truth_verified', 'source_quantity_qualification_recomputed')


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(path):
    result = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024*1024), b''):
            result.update(block)
    return result.hexdigest()


def no_duplicates(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'duplicate object key in completion evidence')
        result[key] = value
    return result


def load(path):
    return json.loads(Path(path).read_text(), object_pairs_hook=no_duplicates,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError('nonfinite completion evidence')))


def clean_head():
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
    require(head == EXPECTED_HEAD, 'source HEAD changed from approved completed pass')
    require(not subprocess.check_output(['git', 'status', '--porcelain'], cwd=REPO, text=True).strip(), 'repository is not clean')
    require(subprocess.check_output(['git', 'branch', '--show-current'], cwd=REPO, text=True).strip() == 'research/flash-publication-foundation', 'unexpected branch')
    return head


def relative_path(value):
    path = PurePosixPath(value)
    require(not path.is_absolute() and value and str(path) == value and '..' not in path.parts, 'unsafe evidence path')
    return path


def verify_archive(delivery, frozen, verification):
    archive = Path(delivery['archive'])
    require(archive == OUT.with_suffix('.tar.gz'), 'unexpected delivery archive destination')
    require(delivery['status'] == 'passed' and delivery['repository_clean'] is True
            and delivery['input_code_output_bindings_verified'] is True and delivery['unsafe_or_duplicate_members'] == 0,
            'delivery verification has not passed')
    for key in ('archive', 'sha256', 'bytes', 'source_commit', 'base_commit', 'manifest_sha256', 'verification_sha256'):
        require(delivery[key] == frozen[key], 'frozen/delivery identity mismatch: '+key)
    require(delivery['source_commit'] == verification['source_commit'] == EXPECTED_HEAD, 'delivery source commit mismatch')
    require(delivery['base_commit'] == verification['base_commit'] == BASE, 'delivery base mismatch')
    require(archive.stat().st_size == delivery['bytes'] and sha(archive) == delivery['sha256'], 'actual archive bytes changed')
    hashes, seen = {}, set()
    with tarfile.open(archive, 'r:gz') as stream:
        for member in stream:
            path = PurePosixPath(member.name)
            require(not path.is_absolute() and '..' not in path.parts and path.parts and path.parts[0] == OUT.name,
                    'unsafe archive path')
            require(member.name not in seen, 'duplicate archive member')
            seen.add(member.name)
            require(not member.issym() and not member.islnk(), 'linked archive payload is unsupported')
            if member.isdir():
                continue
            require(member.isfile() and len(path.parts) > 1, 'nonregular archive payload')
            name = str(PurePosixPath(*path.parts[1:]))
            relative_path(name)
            digest = hashlib.sha256()
            with stream.extractfile(member) as payload:
                for block in iter(lambda: payload.read(1024*1024), b''):
                    digest.update(block)
            hashes[name] = digest.hexdigest()
            require((OUT/name).is_file() and not (OUT/name).is_symlink() and sha(OUT/name) == hashes[name],
                    'archive bytes differ from frozen directory: '+name)
    manifest = load(OUT/'manifest.sha256.json')
    require(set(hashes) == set(manifest)|{'manifest.sha256.json'}, 'archive member set differs from actual manifest')
    require(sha(OUT/'manifest.sha256.json') == delivery['manifest_sha256'], 'manifest pin changed')
    for name, digest in manifest.items():
        relative_path(name)
        require(type(digest) is str and re.fullmatch('[0-9a-f]{64}', digest) is not None and hashes[name] == digest,
                'actual archive manifest hash mismatch: '+name)
    require(len(manifest) == delivery['manifest_entries'] and len(hashes) == delivery['actual_archive_regular_files'], 'delivery archive counts mismatch')
    require(sha(OUT/'verification.json') == delivery['verification_sha256'], 'frozen verification pin changed')
    listing = load(OUT/'source_file_list.json')
    public, wrappers = listing['byte_identical_public_files'], listing['packaging_wrappers']
    require(len(set(public)) == len(public) and len(set(wrappers)) == len(wrappers) and not set(public)&set(wrappers), 'source listing duplicates')
    require({name[7:] for name in hashes if name.startswith('source/')} == set(public)|set(wrappers), 'source payload/listing mismatch')
    require(set(SCOPE) <= set(public), 'completed public scope absent from delivery')
    scope_pins = {}
    for name in public:
        relative_path(name)
        committed = subprocess.check_output(['git', 'show', EXPECTED_HEAD+':'+name], cwd=REPO)
        digest = hashlib.sha256(committed).hexdigest()
        require(hashes['source/'+name] == sha(REPO/name) == digest, 'source bytes differ from approved commit: '+name)
        if name in SCOPE:
            scope_pins[name] = digest
    declared = {}
    for line in (OUT/'source-files.sha256').read_text().splitlines():
        digest, name = line.split('  ', 1)
        require(name not in declared, 'duplicate source-file hash entry')
        declared[name] = digest
    require(set(declared) == set(public), 'public hash inventory mismatch')
    for name, digest in declared.items():
        require(hashes['source/'+name] == digest, 'public source hash inventory mismatch')
    require(len(public) == delivery['public_files_byte_identical'] and len(wrappers) == delivery['packaging_wrappers'], 'public/wrapper count mismatch')
    return scope_pins


def verify_portable():
    portable = WORK/'portable'
    cases = ET.parse(portable/'new0341-results.xml').getroot().findall('.//testcase')
    require(len(cases) == 145 and len({(case.get('classname'), case.get('name')) for case in cases}) == 145,
            'portable case inventory is incomplete or duplicated')
    require(all(case.find('failure') is None and case.find('error') is None and case.find('skipped') is None for case in cases),
            'portable new-scope test failure, error or skip remains')
    counts = Counter(case.get('classname') for case in cases)
    require(sum(count for name, count in counts.items() if name.endswith('test_window_source_ledger_validation')) == 71, 'portable core count mismatch')
    require(sum(count for name, count in counts.items() if name.endswith('test_source_ledger_admission_cli')) == 74, 'portable command count mismatch')
    proof = load(portable/'stdlib-imports.json')
    require(proof['no_site'] is True and proof['numerical_package_imports'] == [] and proof['forbidden_module_imports'] == [],
            'standard-library-only packet proof failed')
    require(proof['approved_report_sha256'] == '23be0f8ebe86113ef8433ae48bc9e7ca7a554315ff31d9d00d99bcb23009577f', 'stdlib packet trust pin mismatch')
    require(proof['trusted_input_sha256'] == sha(WORK/'saved-admission-verification/trusted_inputs.json'), 'stdlib trusted inventory pin mismatch')
    require(set(proof['local_module_paths']) == {'mhdlab', 'mhdlab.window_source_ledger_validation'}, 'unexpected local modules imported by stdlib proof')
    for name, filename in proof['local_module_paths'].items():
        path = Path(filename)
        require(path.is_file() and path.resolve().is_relative_to((portable/'source').resolve()), 'stdlib proof loaded an external local module')
        if name == 'mhdlab.window_source_ledger_validation':
            require(sha(path) == sha(REPO/'mhdlab/window_source_ledger_validation.py'), 'stdlib validator bytes differ')
    stdlib = WORK/'stdlib-packet-admission'
    require(proof['admission_sha256'] == sha(stdlib/'admission.json') and proof['owner_handoff_sha256'] == sha(stdlib/'owner_handoff.json'),
            'stdlib actual output bytes differ from proof')
    admission = load(stdlib/'admission.json')
    require(admission['algebraically_consistent'] is True and all(source['validation_summary']['source_association_bound'] is True for source in admission['sources']),
            'stdlib packet lacks source-bound algebraic admission')
    require(all(admission[name] is False for name in FALSE_FLAGS), 'stdlib packet escalates acceptance')
    load(portable/'verification.json')
    return {'new_unique_passed': 145, 'core_passed': 71, 'cli_passed': 74, 'skipped': 0,
            'junit_sha256': sha(portable/'new0341-results.xml'), 'stdlib_proof_sha256': sha(portable/'stdlib-imports.json'),
            'portable_verification_sha256': sha(portable/'verification.json')}


def verify_admissions():
    trust_path = WORK/'saved-admission-verification/trusted_inputs.json'
    completion_path = WORK/'saved-admission-verification/completion.json'
    completion, trusted = load(completion_path), load(trust_path)
    require(completion['all_checks_passed'] is True and completion['source_count'] == 9 and completion['component_count'] == 1840,
            'saved admission independent review incomplete')
    require(completion['full_and_width_group_rows_bound'] == 1526 and completion['datafile_references_checked'] == 48
            and completion['rejected_tamper_outcomes'] == 6, 'independent admission inventory mismatch')
    require(completion['no_source_moment_sampler_producer_admission_or_owner_solver_calls_by_consumer'] is True
            and completion['no_original_input_files_modified'] is True, 'independent consumer scope mismatch')
    require(completion['trusted_inputs_sha256'] == sha(trust_path), 'trusted inventory bytes changed')
    require(completion['verification_sha256'] == sha(WORK/'saved-admission-verification/verification.json'), 'independent verification bytes changed')
    for filename, digest in completion['artifact_sha256'].items():
        relative_path(filename)
        require(sha(WORK/'saved-admission-verification'/filename) == digest, 'independent consumer evidence changed: '+filename)
    approvals = {item['kind']: item['expected_report_sha256'] for item in trusted['exports']}
    reviewed = {item['kind']: item for item in completion['exports']}
    require(set(reviewed) == {'study', 'packet'}, 'independent review source kinds differ')
    records, counts = {}, {'source_count': 0, 'component_count': 0, 'groups_including_bases': 0}
    for kind in ('study', 'packet'):
        folder = WORK/('admitted-'+kind)
        admission, owner = load(folder/'admission.json'), load(folder/'owner_handoff.json')
        require(sha(folder/'admission.json') == reviewed[kind]['admission_sha256']
                and sha(folder/'owner_handoff.json') == reviewed[kind]['owner_handoff_sha256'], 'actual admission/owner bytes differ from independent consumption')
        require(reviewed[kind]['trusted_original_export_report_sha256'] == approvals[kind], 'independent original report approval changed')
        require(admission['source_sha256'] == reviewed[kind]['admission_source_sha256'], 'independently consumed source pins changed')
        require(admission['expected_report_sha256'] == owner['expected_report_sha256'] == approvals[kind], 'original approved report pin changed')
        require(admission['algebraically_consistent'] is True and all(admission[name] is False and owner[name] is False for name in FALSE_FLAGS),
                'admission/owner acceptance escalation')
        for filename, digest in admission['output_sha256'].items():
            relative_path(filename)
            require(sha(folder/filename) == digest, 'saved admission output bytes changed: '+filename)
        for filename, digest in admission['source_sha256'].items():
            relative_path(filename)
            require(sha(REPO/filename) == digest, 'saved admission source pin changed: '+filename)
        for source in admission['sources']:
            summary = source['validation_summary']
            require(summary['algebraically_consistent'] is True and summary['source_association_bound'] is True
                    and summary['host_budget_accepted'] is False, 'source admission is unbound or escalated')
            counts['source_count'] += 1
            counts['component_count'] += summary['component_count']
            counts['groups_including_bases'] += summary['group_count']
        require(set(owner['required_owner_context']) == {'physical_emission_kernel', 'electromagnetic_fields', 'hall_feedback',
                'loss_and_boundary_collection', 'state_kinetics_and_response', 'owner_precision_and_acceptance_policy'}
                and all(value == 'pending_owner_supplied' for value in owner['required_owner_context'].values()), 'owner context has been promoted or omitted')
        records[kind] = {'admission': str(folder/'admission.json'), 'admission_sha256': sha(folder/'admission.json'),
                         'owner_handoff': str(folder/'owner_handoff.json'), 'owner_handoff_sha256': sha(folder/'owner_handoff.json'),
                         'approved_original_report_sha256': approvals[kind], 'source_count': len(admission['sources']),
                         'component_count': sum(item['validation_summary']['component_count'] for item in admission['sources']),
                         'required_owner_context': owner['required_owner_context']}
    require(counts['source_count'] == 9 and counts['component_count'] == 1840, 'actual admission source/component inventory mismatch')
    return records, counts


def main():
    status_path = WORK.parent/'mitl-upstream-status.json'
    with (WORK.parent/'mitl-upstream-status.lock').open('a+') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        before = status_path.read_bytes()
        status = json.loads(before)
        now = datetime.datetime.now(datetime.timezone.utc)
        require(status['active_lease_owner'] == WORK.name, 'another lease owner is active')
        require(datetime.datetime.fromisoformat(status['active_editing_lease_until_utc']) > now, 'completion lease expired')
        require(status['last_complete_commit'] == BASE, 'previous completed checkpoint changed')
        require(not (WORK/'completion.json').exists(), 'completion already recorded; no replay')
        clean_head()
        delivery, frozen, verification = load(WORK/'delivery_verification.json'), load(WORK/'frozen_delivery.json'), load(OUT/'verification.json')
        results = verification['results']
        require(results['targeted_unique_passed'] == results['portable_unique_passed'] == 145
                and results['core_passed'] == 71 and results['cli_passed'] == 74 and results['portable_skipped'] == 0,
                'completed new-scope count mismatch')
        scope_pins = verify_archive(delivery, frozen, verification)
        portable = verify_portable()
        admissions, admission_counts = verify_admissions()
        selection_path = WORK/'next-upstream-selection/selection.json'
        selection = load(selection_path)
        require(selection['status'] == 'selected' and selection['source_recovery_performed'] is False, 'next task evidence not in selected-only state')
        next_task = selection['selected_task']
        require(load(OUT/'next_task.json')['task'] == next_task, 'handoff next task differs from selected source evidence')
        require(selection['primary_source']['figure'] == 'C.19' and selection['primary_source']['shot'] == 17133, 'unexpected selected physical drive task')
        require(sha(selection['primary_source']['path']) == selection['primary_source']['sha256'], 'selected primary dissertation bytes changed')
        remaining = [dict(item) for item in status['next_work'] if 2 <= item['priority'] <= 6]
        require([item['priority'] for item in remaining] == [2, 3, 4, 5, 6], 'existing pending queue changed')
        # Check the lease and source a second time after all bounded evidence IO.
        now = datetime.datetime.now(datetime.timezone.utc)
        require(datetime.datetime.fromisoformat(status['active_editing_lease_until_utc']) > now, 'lease expired while verifying delivery')
        clean_head()
        history = status.setdefault('verification_history', [])
        old_id = status['last_completed_pass_id']
        if not any(item['pass_id'] == old_id for item in history):
            history.append({'pass_id': old_id, 'commit': status['last_complete_commit'], 'handoff': status['handoff'],
                            'handoff_sha256': status['handoff_sha256'], 'verification': status['last_verified_suite']})
        prior = status.setdefault('prior_handoffs', [])
        if status['handoff'] not in prior:
            prior.append(status['handoff'])
        status.update(last_complete_commit=EXPECTED_HEAD, last_completed_pass_id=WORK.name, last_update_utc=now.isoformat(),
                      handoff=delivery['archive'], handoff_sha256=delivery['sha256'], handoff_bytes=delivery['bytes'],
                      handoff_document=str(OUT/'systems-mitl-source-ledger-admission-10192026.md'), active_lease_owner=None,
                      active_editing_lease_until_utc=None, reserved_paths=[], active_completed_subtasks=[],
                      active_phase='Completed source-bound algebraic ledger admission and owner handoffs; published shot17133 Fig.C.19 drive recovery selected next')
        status['last_verified_suite'] = {**results, 'scope': 'New strict full-component source-ledger algebra admission and trusted-export owner handoffs; no source law/history/moment/sampler/producer replay',
            'verification_record': str(OUT/'verification.json'), 'delivery_manifest_entries': delivery['manifest_entries'],
            'standard_library_packet_admission': True, 'source_producer_replay_performed': False,
            'physical_spectra_calculated': False, 'host_budget_accepted': False,
            'previous_full_project_passed': 721, 'previous_full_project_skipped': 2, 'post_freeze_commands': str(WORK/'commands.jsonl')}
        status['source_ledger_admission'] = {'implementation': str(REPO/SCOPE[0]), 'command': str(REPO/SCOPE[2]), 'guide': str(REPO/SCOPE[4]),
            'full_components_required': True, 'strict_typed_json_fraction_algebra': True, 'source_association_bound': True,
            'trusted_input_inventory': str(WORK/'saved-admission-verification/trusted_inputs.json'),
            'trusted_input_inventory_sha256': sha(WORK/'saved-admission-verification/trusted_inputs.json'),
            'study': admissions['study'], 'packet': admissions['packet'],
            'independent_consumer_completion': str(WORK/'saved-admission-verification/completion.json'),
            'independent_consumer_completion_sha256': sha(WORK/'saved-admission-verification/completion.json'),
            **admission_counts, 'raw_file_hashes_distinct_from_canonical_parsed_json_hashes': True,
            'standard_library_packet_admission': True, 'standard_library_proof': str(WORK/'portable/stdlib-imports.json'),
            'standard_library_proof_sha256': portable['stdlib_proof_sha256'],
            'source_quantity_qualification_recomputed': False, 'source_producer_replay_performed': False,
            'source_evolution_repeated': False, 'saved_moments_or_packet_sampling_repeated': False,
            'owner_implementation_verified': False, 'physical_truth_verified': False, 'host_budget_accepted': False,
            'limits': 'Algebra and declared original source identities only. Qualifications/logs are input evidence, source kernels/fields/Hall/loss/response/precision policy remain owner supplied, physical truth and host acceptance are not verified.'}
        status.setdefault('owner_response_controls', {}).update(source_ledger_admission_available=True,
            source_ledger_admission=str(WORK/'admitted-packet/admission.json'), source_ledger_owner_handoff=str(WORK/'admitted-packet/owner_handoff.json'),
            source_ledger_host_budget_accepted=False, owner_implementation_verified=False, physical_spectra_calculated=False)
        status['next_work'] = [{'priority': 1, 'task': next_task, 'selection': str(selection_path), 'selection_sha256': sha(selection_path)}]+remaining
        status['completed_milestones'].extend([
            'Strict standard-library-only full-component source-ledger admission recomputes exact represented-Fraction groups, independent field availability/subtotals, zero support, typed projection/catalog/area records and original component associations.71 new core checks pass; source qualifications and host acceptance remain unverified declarations.',
            'Pinned export admission and owner descriptors preserve original joint component pointers and raw versus canonical JSON hashes without scientific imports or producer replay.74 new command checks pass with duplicate/nonfinite/type/source-pointer guards; all physical and owner contexts remain pending.',
            'Nine preserved source manifests and1840 components from eight study windows and one packet source are bound independently through trusted prior-report pins.1526 group rows,48 datafile references and six tampered owner descriptors checked;33 independent JSON/Fraction review cases plus narrow five-regression cached-coupling fix retain failures and exact evidence.',
            f'Two local commits through{EXPECTED_HEAD[:7]};145 new targeted and145 portable checks pass with no skips, and a python-S packet admission imports only the package wrapper and standard-library validator. {delivery["public_files_byte_identical"]} public files plus{delivery["packaging_wrappers"]} wrappers and{delivery["manifest_entries"]} manifest entries are verified against actual archive{delivery["sha256"]}. New upstream source lead selects dissertation Fig.C.19 shot17133 published average-current vector recovery; no waveform recovered in this pass.'
        ])
        history.append({'pass_id': WORK.name, 'commit': EXPECTED_HEAD, 'handoff': delivery['archive'],
                        'handoff_sha256': delivery['sha256'], 'verification': status['last_verified_suite']})
        encoded = (json.dumps(status, indent=2, allow_nan=False)+'\n').encode('utf-8')
        result = {'utc': now.isoformat(), 'event': 'completed_and_next_selected', 'pass_id': WORK.name, 'commit': EXPECTED_HEAD,
                  'archive': delivery['archive'], 'archive_sha256': delivery['sha256'], 'archive_bytes': delivery['bytes'],
                  'actual_archive_reverified': True, 'scope_sha256': scope_pins, 'new_targeted_unique_passed': 145,
                  'portable_unique_passed': 145, 'stdlib_packet_admission_verified': True, **admission_counts,
                  'exact_commands': str(WORK/'commands.jsonl'), 'status_before_sha256': hashlib.sha256(before).hexdigest(),
                  'status_after_sha256': hashlib.sha256(encoded).hexdigest(), 'lease_released': True, 'reserved_paths': [],
                  'next': next_task, 'next_selection_sha256': sha(selection_path),
                  'limits': 'Algebraic/source-declaration admission only; physical kernels, fields/Hall/loss/state response, host policy, raw diagnostics, absolute calibration and configured licensed FLASH remain unresolved. No source producer, owner solver, Quark runner or external publication.'}
        (WORK/'status-before-completion.json').write_bytes(before)
        temporary = status_path.with_suffix('.json.new')
        temporary.write_bytes(encoded)
        temporary.replace(status_path)
        (WORK/'completion.json').write_text(json.dumps(result, indent=2, allow_nan=False)+'\n')
        with (WORK.parent/'mitl-upstream-journal.jsonl').open('a') as stream:
            stream.write(json.dumps(result, allow_nan=False)+'\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
