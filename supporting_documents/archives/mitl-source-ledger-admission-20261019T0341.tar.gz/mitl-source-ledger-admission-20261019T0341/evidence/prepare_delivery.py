"""Prepare the final byte-identical public subset without freezing an archive."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import shutil
import subprocess

WORK = Path(__file__).resolve().parent
REPO = Path('/workspace/Power-Flow')
BASE = '96ba472e21d1f587cd20495ce033fb5eed3e52f3'
HEAD = '079bddf9f81021ee4f3d79c42011185511d53747'
OUT = Path('/workspace/handoffs/mitl-source-ledger-admission-20261019T0341')


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024*1024), b''):
            digest.update(block)
    return digest.hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False)+'\n')


def clean_head():
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == HEAD
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=REPO, text=True).strip()
    subprocess.run(['git', 'merge-base', '--is-ancestor', BASE, HEAD], cwd=REPO, check=True)
    return HEAD


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--portable', type=Path, default=WORK/'portable')
    parser.add_argument('--payload', type=Path, default=WORK/'delivery-preparation/payload')
    args = parser.parse_args()
    clean_head()
    assert not args.payload.exists()
    listing = load(args.portable/'source_file_list.json')
    assert set(listing) == {'byte_identical_public_files', 'packaging_wrappers', 'declared_public_commit',
                            'prior_public_files', 'new_admission_files', 'closure_method', 'forbidden_modules_absent'}
    assert listing['declared_public_commit'] == HEAD
    public, wrappers = listing['byte_identical_public_files'], listing['packaging_wrappers']
    assert isinstance(public, list) and isinstance(wrappers, list)
    assert len(public) == len(set(public)) and not set(public) & set(wrappers)
    assert set(wrappers) == {'README.md', 'mhdlab/__init__.py', 'pytest.ini', 'requirements.txt'}
    assert set(listing['new_admission_files']) == {'docs/source_ledger_admission.md', 'mhdlab/window_source_ledger_validation.py',
        'tests/test_source_ledger_admission_cli.py', 'tests/test_window_source_ledger_validation.py', 'tools/admit_source_ledger_export.py'}
    assert set(listing['new_admission_files']) <= set(public)
    assert type(listing['prior_public_files']) is int and listing['prior_public_files'] == 36
    assert listing['prior_public_files']+len(listing['new_admission_files']) == len(public)
    assert isinstance(listing['closure_method'], str) and listing['closure_method'].strip()
    assert isinstance(listing['forbidden_modules_absent'], list) and not set(listing['forbidden_modules_absent']) & set(public)
    for name in public+wrappers:
        path = PurePosixPath(name)
        assert isinstance(name, str) and not path.is_absolute() and path.as_posix() == name and '..' not in path.parts
        if name in public:
            assert path.parts[0] in {'docs', 'mhdlab', 'tests', 'tools'} and path.suffix in {'.py', '.md'}
    for name in public:
        assert (args.portable/'source'/name).read_bytes() == (REPO/name).read_bytes(), name
    args.payload.mkdir(parents=True)
    for name in public+wrappers:
        origin = args.portable/'source'/name
        assert origin.is_file() and not origin.is_symlink()
        target = args.payload/'source'/name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(origin, target)
    save(args.payload/'source_file_list.json', listing)
    (args.payload/'source-files.sha256').write_text(''.join(f'{sha(REPO/name)}  {name}\n' for name in sorted(public)))
    (args.payload/'wrapper-files.sha256').write_text(''.join(f'{sha(args.payload/"source"/name)}  {name}\n' for name in sorted(wrappers)))
    save(args.payload/'preparation.json', {'source_commit': HEAD, 'base_commit': BASE,
         'portable_source': str(args.portable/'source'), 'public_files': len(public), 'packaging_wrappers': len(wrappers),
         'source_file_sha256': {name: sha(args.payload/'source'/name) for name in public+wrappers}})
    print(json.dumps({'payload': str(args.payload), 'source_commit': HEAD, 'public_files': len(public), 'packaging_wrappers': len(wrappers)}, indent=2))


if __name__ == '__main__':
    main()
