"""Render the newly selected published drive figure without digitizing it."""
import hashlib
import json
from pathlib import Path
import pymupdf

root = Path(__file__).resolve().parent
source = Path('/workspace/research_sources/smtrevor_1.pdf')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(source) == '1d7b1f9c191a37e94f1cc3634587750f1af35b07eb13e0b94c60f3da47495ed7'
out = root / 'C19-preview'
out.mkdir(exist_ok=False)
with pymupdf.open(source) as document:
    page = document[189]
    assert hashlib.sha256(page.read_contents()).hexdigest() == '0a6619c5541d64d19d1534e738268c6d7868eca658152967a2f8c8dfe9c57edb'
    page.get_pixmap(matrix=pymupdf.Matrix(2, 2), alpha=False).save(out / 'page190.png')
    result = {'source_sha256': sha(source), 'figure': 'C.19', 'printed_page': 165,
        'pdf_page': 190, 'page_text': page.get_text(), 'render_sha256': sha(out / 'page190.png'),
        'render_scale': 2, 'source_recovery_performed': False,
        'limits': 'Published display preview only; no axis fitting, waveform extraction or physical timing inference.'}
(out / 'preview.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
