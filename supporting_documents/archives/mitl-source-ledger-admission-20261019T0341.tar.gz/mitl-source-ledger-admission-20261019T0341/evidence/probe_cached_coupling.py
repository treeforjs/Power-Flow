"""Read-only evidence for a separately rounded reduced-coupling cache."""
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path

work = Path(__file__).resolve().parent
saved = Path("/workspace/research_work/mitl-upstream-20261019T0250/saved-study-ledgers/case_x16-z4-s8-i64-common512.json")
producer = Path("/workspace/Power-Flow/mhdlab/temkin_emission_window.py")
text = producer.read_text()
expressions = ["log_c = math.log(self.coupling)-sa if self.coupling else -math.inf",
               "ca = math.exp(log_c) if self.coupling else 0."]
assert all(expression in text for expression in expressions)
case = json.loads(saved.read_text())
value = case["windows"][0]["ledger"]["components"][112]["source_window"]["time_window"]
c, ca, sa, log_ca = (value[name] for name in ("coupling", "local_coupling", "start_depletion", "log_local_coupling"))
assert ca > c and ca == math.nextafter(c, math.inf)
assert log_ca.hex() == (math.log(c)-sa).hex()
assert ca.hex() == math.exp(log_ca).hex()
delta = Fraction(ca)-Fraction(c)
record = {
    "schema": "mhdlab-declared-coupling-cache-investigation-v1",
    "saved_case_file": str(saved), "saved_case_sha256": hashlib.sha256(saved.read_bytes()).hexdigest(),
    "saved_pointer": "/windows/0/ledger/components/112/source_window/time_window",
    "producer_file": str(producer), "producer_sha256": hashlib.sha256(producer.read_bytes()).hexdigest(),
    "verified_producer_expressions": expressions,
    "coupling": c, "local_coupling": ca, "start_depletion": sa, "log_local_coupling": log_ca,
    "coupling_hex": c.hex(), "local_coupling_hex": ca.hex(),
    "signed_local_minus_original": {"numerator": str(delta.numerator), "denominator": str(delta.denominator)},
    "difference_in_original_ulps": float(delta/Fraction(math.ulp(c))),
    "exact_declared_log_transform_matches": True, "exact_declared_exp_transform_matches": True,
    "interpretation": "Mathematical local coupling does not exceed original coupling; separately rounded binary64 caches need not satisfy that exact inequality. Admission checks this specific producer log/exp transform when ordering reverses, without a closeness envelope.",
    "platform_limit": "Exact scalar transform comparison uses the current platform math library; an externally produced different rounded cache may be rejected and requires explicit qualification.",
    "source_law_imported": False, "source_history_or_quantities_generated": False,
}
target = work/"cached-coupling-investigation.json"
target.write_text(json.dumps(record, indent=2, allow_nan=False)+"\n")
print(json.dumps({"artifact": str(target), "sha256": hashlib.sha256(target.read_bytes()).hexdigest(),
                  "producer_expression_checks": len(expressions), "saved_literal_roundtrip": True}, indent=2))
