# Joint source, solid enthalpy and conductive heating subset

Public files are byte-identical to the commit in the parent handoff. This
README, minimal initializer, pytest settings and requirements are packaging
wrappers. Use Python3.11 or newer and install requirements, then run:

```sh
python -m pytest -q -W error
python tools/inspect_joint_source_moments.py --demo --output-dir /tmp/joint-source --plot
python tools/inspect_solid_enthalpy.py --output-dir /tmp/enthalpy-inspection --plot
python tools/run_conductive_heating_benchmark.py --output-dir /tmp/conductive-reference --plot
```

Output paths must be new. The source/heating examples are manufactured; the
enthalpy example inspects an explicitly selected source-evaluated solid branch
at illustrative temperatures. It supplies neither actual foil qualification nor
Cv/EOS internal energy, density or a melt law. The source model uses independent
surface pools and expected local2kBT means, not a chemistry/transport solver.
Read the corresponding guides under docs/ for physical/numerical limits.

No actual FLASH or production host is run. Independent finite-volume and
one-shot accounting examples under ../evidence preserve their recorded workspace
paths. Those verification prototypes are owner handoffs, not production host or
gap evolution code. Source papers, scanned pixels and private implementation are
not redistributed.
