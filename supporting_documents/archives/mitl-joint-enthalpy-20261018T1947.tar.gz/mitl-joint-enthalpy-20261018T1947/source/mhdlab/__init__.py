"""Independent upstream source and material verification interfaces."""
