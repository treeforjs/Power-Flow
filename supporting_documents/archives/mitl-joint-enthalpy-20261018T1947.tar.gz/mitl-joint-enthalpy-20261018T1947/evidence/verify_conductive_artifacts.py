"""Reopen numerical evidence, verify bytes and recompute reported comparisons."""
import hashlib
import json
from pathlib import Path

import numpy as np

WORK = Path(__file__).resolve().parent
ROOT = WORK / "conductive_fd_evidence"
report_path = ROOT / "report.json"
report = json.loads(report_path.read_text())
artifact_count = 0
for case in report["cases"]:
    for result in case["results"]:
        path = ROOT / result["artifact"]
        assert hashlib.sha256(path.read_bytes()).hexdigest() == result["artifact_sha256"]
        with np.load(path, allow_pickle=False) as arrays:
            assert all(np.all(np.isfinite(arrays[name])) for name in arrays.files)
            cells = result["cells"]
            field = arrays["numerical_state"][:cells]
            temperature = arrays["numerical_state"][cells:]
            parameters = report["parameters"]
            energy = (np.mean(field**2, axis=0) / (2 * parameters["permeability_h_m"])
                      + parameters["volumetric_heat_capacity_j_m3_k"] * np.mean(temperature, axis=0))
            np.testing.assert_array_equal(energy, arrays["discrete_total_energy_j_m3"])
            # Match the separately evaluated one-dimensional initial storage;
            # its sum can differ from the column reduction by one rounding bit.
            initial_energy = np.mean(field[:, 0]**2) / (2 * parameters["permeability_h_m"])
            residual = energy - initial_energy
            np.testing.assert_array_equal(residual, arrays["discrete_energy_residual_j_m3"])
            np.testing.assert_allclose(np.max(np.abs(residual)) / initial_energy,
                                       result["maximum_relative_discrete_energy_residual"], rtol=2e-15)
            for name, actual, reference in (
                ("magnetic_cell_mean", field[:, -1], arrays["exact_magnetic_cell_mean_t"]),
                ("temperature_cell_mean", temperature[:, -1], arrays["exact_temperature_cell_mean_k"]),
                ("joule_cell_mean", arrays["numerical_joule_cell_mean_w_m3"], arrays["exact_joule_cell_mean_w_m3"]),
            ):
                difference = np.linalg.norm(actual - reference) / np.linalg.norm(reference)
                assert difference == result["relative_l2_errors"][name]
        artifact_count += 1
result = {"schema": "mhdlab-conductive-evidence-integrity-v1", "artifacts_reopened": artifact_count,
          "report_sha256": hashlib.sha256(report_path.read_bytes()).hexdigest(),
          "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          "checks": ["NPZ byte hashes", "allow_pickle=False", "finite arrays", "saved total-energy identity",
                     "saved energy residuals", "saved relative energy residual", "saved cell-mean reference-error norms"]}
destination = WORK / "conductive_fd_integrity.json"
destination.write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
