import hashlib,json,math
from pathlib import Path
w=Path(__file__).parent
reports={n:json.loads((w/f'joint-source-q{n}/report.json').read_text()) for n in [8,16,32]}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source_hash=sha(w/'joint-source-q8/source_input.h5')
for n in [16,32]:
 assert reports[n]['input_source_sha256']==source_hash
 assert sha(w/f'joint-source-q{n}/source_input.h5')==source_hash
 assert reports[n]['parameter_status']=='manufactured'
rows=[]
for a,b in [(8,16),(16,32)]:
 for p,q in zip(reports[a]['joint_moments']['reservoirs'],reports[b]['joint_moments']['reservoirs']):
  assert p['name']==q['name']
  for key in ['released_number','mean_expected_translational_energy_j','cov_expected_translational_energy_width_centered_square_j_m2']:
   assert p['resolved'][key]==q['resolved'][key]
  for key in ['released_number','mean_time_s','variance_time_s2','mean_z_m','variance_z_m2','mean_expected_translational_energy_j','cov_time_expected_translational_energy_s_j']:
   assert p['resolved'][key]==p['uniform_width'][key]
   assert q['resolved'][key]==q['uniform_width'][key]
  assert p['uniform_width']['cov_time_width_centered_square_s_m2']==q['uniform_width']['cov_time_width_centered_square_s_m2']==0
  metrics={}
  for key in ['mean_time_s','variance_time_s2','cov_time_width_centered_square_s_m2','cov_time_expected_translational_energy_s_j']:
   left,right=p['resolved'][key],q['resolved'][key]
   change=math.fsum((right,-left))
   metrics[key]={'signed_refined_minus_coarse':change,'absolute_change':abs(change),
                 'relative_change_to_finite_refined':abs(change/right) if right else None}
  rows.append({'coarse_order':a,'finite_refined_order':b,'reservoir':p['name'],'metrics':metrics})
record={'schema':'mitl-joint-time-quadrature-changes-v1','parameter_status':'manufactured',
        'same_source_sha256':source_hash,'new_source_integrations':1,
        'additional_orders_reuse_exact_source':True,
        'report_sha256':{str(n):sha(w/f'joint-source-q{n}/report.json') for n in reports},
        'comparisons':rows,'qualification':'Finite quadrature changes only, not certified error bounds, physical uncertainty or source-grid convergence.'}
(w/'joint_quadrature_comparison.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
