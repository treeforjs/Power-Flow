"""Exact manufactured arithmetic for the fixed linear width-invariance limit.

The component index is abstract retained-variable phase space. All measures,
source densities, kernel entries and nonlinear examples are dimensionless toy
quantities. No spectrum, physical state catalog or reaction model is supplied.
"""

from __future__ import annotations

import argparse
from fractions import Fraction
import hashlib
import json
from pathlib import Path


F = Fraction
ZERO = F(0)
SCHEMA = "mhdlab-source-identifiability-arithmetic-v1"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def encoded(value):
    if isinstance(value, Fraction):
        return {"numerator": value.numerator, "denominator": value.denominator, "decimal": float(value)}
    if isinstance(value, list):
        return [encoded(item) for item in value]
    if isinstance(value, dict):
        return {key: encoded(item) for key, item in value.items()}
    return value


def marginal(source, areas):
    return [sum((area * row[j] for area, row in zip(areas, source)), ZERO) for j in range(len(source[0]))]


def channel(source, areas, kernel, width_weight=None):
    width_weight = [F(1)] * len(areas) if width_weight is None else width_weight
    return sum((area * weight * sum((density * coefficient for density, coefficient in zip(row, kernel)), ZERO)
                for area, weight, row in zip(areas, width_weight, source)), ZERO)


def local_quadratic(source, areas):
    return sum((area * sum(row, ZERO) ** 2 for area, row in zip(areas, source)), ZERO)


def verification():
    areas = [F(1, 2), F(3, 2), F(1)]
    resolved = [[F(6), F(0), F(1, 3), F(2)],
                [F(1, 2), F(3), F(2, 3), F(0)],
                [F(4), F(1), F(0), F(5, 2)]]
    require(all(area > 0 for area in areas), "manufactured patch measures must be positive")
    require(len({len(row) for row in resolved}) == 1, "component matrix must be rectangular")
    require(len(areas) == len(resolved), "one area is required per width patch")
    require(all(value >= 0 for row in resolved for value in row), "source must be nonnegative")
    total_area = sum(areas, ZERO)
    target = marginal(resolved, areas)
    uniform = [[value / total_area for value in target] for _ in areas]
    recovered = marginal(uniform, areas)
    checks = []
    for j, (original, redistributed) in enumerate(zip(target, recovered)):
        require(original == redistributed, f"retained-component marginal changed at index {j}")
        checks.append({"name": f"retained_component_{j}_marginal", "passed": True,
                       "resolved": original, "uniform_width": redistributed})
    kernels = {
        "total_measure": [F(1)] * 4,
        "component_selective": [F(0), F(1), F(0), F(1)],
        "generic_nonnegative_channel_a": [F(1, 3), F(7, 5), F(0), F(11, 6)],
        "generic_nonnegative_channel_b": [F(9, 4), F(2, 7), F(5, 8), F(1, 9)],
        "zero_response": [ZERO] * 4,
    }
    responses = {}
    for name, kernel in kernels.items():
        direct = channel(resolved, areas, kernel)
        redistributed = channel(uniform, areas, kernel)
        factored = sum((coefficient * value for coefficient, value in zip(kernel, target)), ZERO)
        require(direct == redistributed == factored, f"fixed linear channel changed: {name}")
        responses[name] = {"kernel": kernel, "resolved": direct, "uniform_width": redistributed,
                           "marginal_factorization": factored, "difference": direct - redistributed}
        checks.append({"name": f"fixed_linear_{name}_invariance", "passed": True})
    width_weights = [F(1, 4), F(2), F(3, 2)]
    weighted_kernel = kernels["generic_nonnegative_channel_b"]
    weighted_resolved = channel(resolved, areas, weighted_kernel, width_weights)
    weighted_uniform = channel(uniform, areas, weighted_kernel, width_weights)
    require(weighted_resolved != weighted_uniform, "nonuniform-width counterexample must differ")
    checks.append({"name": "nonuniform_width_response_breaks_x_independence", "passed": True})
    local_resolved, local_uniform = local_quadratic(resolved, areas), local_quadratic(uniform, areas)
    require(local_resolved > local_uniform, "local convex-response counterexample must be strict")
    checks.append({"name": "local_quadratic_response_can_break_invariance", "passed": True})
    global_resolved, global_uniform = sum(target, ZERO) ** 2, sum(recovered, ZERO) ** 2
    require(global_resolved == global_uniform, "global marginal-only nonlinear response must agree")
    checks.append({"name": "nonlinear_marginal_only_response_still_invariant", "passed": True})
    return {
        "schema": SCHEMA, "parameter_status": "manufactured", "units": "dimensionless toy measures and responses",
        "source_matrix_interpretation": "row=width patch; column=abstract complete retained-variable component",
        "patch_areas": areas, "total_area": total_area, "source_density_resolved": resolved,
        "source_density_uniform_width": uniform, "retained_component_marginal": target,
        "fixed_linear_channels": responses,
        "counterexamples": {
            "nonuniform_width_response": {"width_weights": width_weights, "kernel": weighted_kernel,
                                          "resolved": weighted_resolved, "uniform_width": weighted_uniform,
                                          "difference": weighted_resolved - weighted_uniform,
                                          "interpretation": "manufactured fixed linear kernel now depends on launch width"},
            "local_quadratic_response": {"formula": "sum_i area_i*(sum_j S_ij)^2", "resolved": local_resolved,
                                         "uniform_width": local_uniform, "difference": local_resolved - local_uniform,
                                         "interpretation": "nonphysical functional local in width, summing abstract components before squaring; no chemical reaction or emission law"},
        },
        "additional_invariant": {"global_marginal_quadratic": {"formula": "(sum_j M_j)^2", "resolved": global_resolved,
                                                               "uniform_width": global_uniform, "difference": global_resolved - global_uniform}},
        "checks": checks, "passed_checks": len(checks),
        "qualifications": ["Fixed linear x-independent complete response and compatible collection/boundaries are assumptions of the equality.",
                           "Matching total number and mean energy alone does not preserve every retained-variable marginal.",
                           "Nonuniform width sensitivity and local nonlinear response are manufactured counterexamples, not physical spectra.",
                           "No conclusion that width-integrated spectra can never discriminate is implied.",
                           "No gap, Boltzmann, collisional-radiative or physical reaction calculation is performed."],
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--document", type=Path, default=Path('/workspace/Power-Flow/docs/source_identifiability_controls.md'))
    args = parser.parse_args()
    report = verification()
    report["script_sha256"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    report["document_path"] = str(args.document)
    report["document_sha256"] = hashlib.sha256(args.document.read_bytes()).hexdigest()
    payload = json.dumps(encoded(report), indent=2, sort_keys=True, allow_nan=False) + "\n"
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("x") as stream:
        stream.write(payload)
    print(json.dumps({"output": str(args.output), "sha256": hashlib.sha256(args.output.read_bytes()).hexdigest(),
                      "passed_checks": report["passed_checks"], "arithmetic": "exact Fraction", "parameter_status": "manufactured"}, sort_keys=True))


if __name__ == "__main__":
    main()
