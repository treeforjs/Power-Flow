"""Manufactured one-shot accounting/acceptance examples; no live host or EOS.

Inputs reuse the independently specified two-packet fixture in
docs/boundary_transaction_requirements.md. Generic A/B state and pool labels
carry symbolic counts only. They supply no molecular nuclei/charge catalog.
The candidate packets are supplied records, not sampled or propagated particles.
Replay cursor tokens are metadata, not a physical random-number sampler.
"""

from __future__ import annotations

import argparse
import copy
from dataclasses import asdict, dataclass, replace
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path


EV = F("1.602176634e-19")
KB = F("1.380649e-23")
ZERO = (F(0), F(0), F(0))
AREA = F("1e-12")
NORMAL = (F(0), F(1), F(0))
SOURCE = "manufactured-two-packet-source-v1"
GEOMETRY = "manufactured-one-patch-positive-y-v1"
TOKENS = ("fixture-token-5", "fixture-token-6", "fixture-token-7", "fixture-token-8")
STATES = {
    "generic_A": {"pool": "pool_A", "mass": F("2e-26"), "D": F("0.2") * EV,
                  "I": F("0.1") * EV, "temperature": F(300)},
    "generic_B": {"pool": "pool_B", "mass": F("4e-26"), "D": F("0.4") * EV,
                  "I": F("0.05") * EV, "temperature": F(600)},
}
POOL_STATES = {item["pool"]: label for label, item in STATES.items()}


def add(a, b):
    return tuple(x + y for x, y in zip(a, b, strict=True))


def scale(a, factor):
    return tuple(x * factor for x in a)


def dot(a, b):
    return sum((x * y for x, y in zip(a, b, strict=True)), F(0))


def encode(value):
    if isinstance(value, F):
        return {"$fraction": [value.numerator, value.denominator]}
    if isinstance(value, dict):
        return {key: encode(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [encode(item) for item in value]
    if isinstance(value, frozenset):
        return {"$frozenset": [encode(item) for item in sorted(value)]}
    if value is None or isinstance(value, (str, int, bool)):
        return value
    raise TypeError(f"unsupported checkpoint type: {type(value).__name__}")


def decode(value):
    if isinstance(value, dict):
        if set(value) == {"$fraction"}:
            return F(*value["$fraction"])
        if set(value) == {"$frozenset"}:
            return frozenset(decode(item) for item in value["$frozenset"])
        return {key: decode(item) for key, item in value.items()}
    if isinstance(value, list):
        return [decode(item) for item in value]
    return value


def canonical(value):
    return json.dumps(encode(value), sort_keys=True, separators=(",", ":")).encode("utf-8")


def digest(value):
    return hashlib.sha256(canonical(value)).hexdigest()


@dataclass(frozen=True)
class Packet:
    state: str
    pool: str
    weight: F
    mass: F
    velocity_rest: tuple[F, F, F]
    temperature: F
    binding_cost: F
    internal: F


@dataclass(frozen=True)
class Candidate:
    transaction_id: str
    version: int
    committed_step: int
    cursor: int
    supplied_tokens: tuple[str, ...]
    source: str
    geometry: str
    area: F
    normal: tuple[F, F, F]
    packets: tuple[Packet, ...]


def candidate_record(candidate):
    return asdict(candidate)


def candidate_from_record(record):
    values = dict(record)
    values["supplied_tokens"] = tuple(values["supplied_tokens"])
    values["normal"] = tuple(values["normal"])
    values["packets"] = tuple(Packet(**{**packet, "velocity_rest": tuple(packet["velocity_rest"])})
                              for packet in values["packets"])
    return Candidate(**values)


def initial_state(velocity=ZERO, thermal=F("2e-18"), inventory=None):
    inventory = dict(inventory or {"pool_A": F(10), "pool_B": F(8)})
    wall_mass = F("1e-22")
    return {
        "version": 7, "committed_step": 17, "cursor": 5,
        "source": SOURCE, "geometry": GEOMETRY, "area": AREA, "normal": NORMAL,
        "velocity_prescribed": tuple(velocity), "inventory": inventory,
        "wall_mass": wall_mass, "wall_thermal": thermal,
        "wall_bound_reference": -sum((count * STATES[POOL_STATES[pool]]["D"]
                                      for pool, count in inventory.items()), F(0)),
        "wall_advected_momentum": scale(velocity, wall_mass),
        "wall_advected_kinetic": wall_mass * dot(velocity, velocity) / 2,
        "gas_packets": [], "gas_state_counts": {label: F(0) for label in STATES},
        "gas_mass": F(0), "gas_momentum": ZERO, "gas_kinetic": F(0), "gas_internal": F(0),
        "support_impulse_supplied": ZERO, "support_work_supplied": F(0),
        "external_momentum": ZERO, "external_energy": F(0), "accepted_ids": frozenset(),
        "mass_ownership": "adsorbed mass included in wall_mass; remove once",
        "reference_convention": "negative bound reference; gas ground zero; independent positive D and I",
        "phase_or_EOS_admissibility": "not implemented or tested",
    }


def make_candidate(state, transaction_id="manufactured-tx-1"):
    records = []
    for label, weight, velocity in (
        ("generic_A", F(2), (F(1000), F(2000), F(0))),
        ("generic_B", F(3), (F(-500), F(1000), F(500))),
    ):
        item = STATES[label]
        records.append(Packet(label, item["pool"], weight, item["mass"], velocity,
                              item["temperature"], item["D"], item["I"]))
    return Candidate(transaction_id, state["version"], state["committed_step"], state["cursor"],
                     TOKENS, state["source"], state["geometry"], state["area"],
                     tuple(state["normal"]), tuple(records))


def ledger(candidate, velocity):
    counts = {pool: F(0) for pool in POOL_STATES}
    state_counts = {label: F(0) for label in STATES}
    mass, kinetic_rest, kinetic_lab, D, I, expected = (F(0) for _ in range(6))
    momentum_rest, momentum_lab = ZERO, ZERO
    for packet in candidate.packets:
        counts[packet.pool] += packet.weight
        state_counts[packet.state] += packet.weight
        weighted_mass = packet.weight * packet.mass
        lab = add(packet.velocity_rest, velocity)
        mass += weighted_mass
        momentum_rest = add(momentum_rest, scale(packet.velocity_rest, weighted_mass))
        momentum_lab = add(momentum_lab, scale(lab, weighted_mass))
        kinetic_rest += weighted_mass * dot(packet.velocity_rest, packet.velocity_rest) / 2
        kinetic_lab += weighted_mass * dot(lab, lab) / 2
        D += packet.weight * packet.binding_cost
        I += packet.weight * packet.internal
        expected += 2 * KB * packet.weight * packet.temperature
    advected_momentum = scale(velocity, mass)
    advected_kinetic = mass * dot(velocity, velocity) / 2
    work = dot(velocity, momentum_rest)
    assert momentum_lab == add(momentum_rest, advected_momentum)
    assert kinetic_lab == kinetic_rest + work + advected_kinetic
    return {"pool_counts": counts, "state_counts": state_counts, "mass": mass,
            "momentum_rest": momentum_rest, "momentum_lab": momentum_lab,
            "kinetic_rest_actual": kinetic_rest, "kinetic_lab_actual": kinetic_lab,
            "translation_expected_2kBT": expected,
            "translation_actual_minus_expected": kinetic_rest - expected,
            "bound_reference_increase_D": D, "gas_internal_above_ground_I": I,
            "thermal_debit": kinetic_rest + D + I,
            "advected_mass_momentum_removed": advected_momentum,
            "advected_mass_kinetic_removed": advected_kinetic,
            "wall_reaction_impulse": scale(momentum_rest, -1),
            "support_impulse_supplied": momentum_rest, "support_work_supplied": work}


def total_energy(state):
    return sum((state[name] for name in ("wall_thermal", "wall_bound_reference",
                "wall_advected_kinetic", "gas_kinetic", "gas_internal", "external_energy")), F(0))


def total_momentum(state):
    return add(add(state["wall_advected_momentum"], state["gas_momentum"]), state["external_momentum"])


def validate_candidate(state, candidate):
    if candidate.transaction_id in state["accepted_ids"]:
        return "duplicate_accepted_transaction"
    if candidate.version != state["version"] or candidate.committed_step != state["committed_step"]:
        return "stale_committed_version_or_step"
    if candidate.cursor != state["cursor"] or candidate.supplied_tokens != TOKENS:
        return "stale_or_invalid_replay_cursor"
    if (candidate.source != state["source"] or candidate.geometry != state["geometry"]
            or candidate.area != state["area"] or tuple(candidate.normal) != tuple(state["normal"])):
        return "invalid_source_or_geometry_association"
    if state["wall_thermal"] < 0:
        return "negative_initial_available_thermal"
    for packet in candidate.packets:
        item = STATES.get(packet.state)
        if (item is None or packet.pool != item["pool"] or packet.mass != item["mass"]
                or packet.binding_cost != item["D"] or packet.internal != item["I"]
                or packet.temperature != item["temperature"]):
            return "invalid_generic_state_membership_or_reference"
        if packet.weight <= 0 or dot(packet.velocity_rest, candidate.normal) <= 0:
            return "invalid_weight_or_outward_geometry"
    return None


def attempt(state, candidate, *, corrupt_provisional_gas_energy=False):
    """Build a private copy, then publish it only after every fixture check.

    This functional demonstration is not a concurrent or crash-durable host
    transaction. Nothing writes the input state. Rejection returns that state.
    """
    before = canonical(state)
    audit = {"candidate_sha256": digest(candidate_record(candidate)),
             "provisional_gas_inserted": False, "live_host_tested": False}
    reason = validate_candidate(state, candidate)
    if reason:
        assert canonical(state) == before
        return state, False, reason, audit
    proposed = ledger(candidate, state["velocity_prescribed"])
    audit["ledger"] = proposed
    if any(proposed["pool_counts"][pool] > count for pool, count in state["inventory"].items()):
        return state, False, "insufficient_live_coverage", audit
    trial = copy.deepcopy(state)
    for packet in candidate.packets:
        trial["gas_packets"].append({"transaction_id": candidate.transaction_id, **asdict(packet),
                                     "velocity_lab": add(packet.velocity_rest, state["velocity_prescribed"])})
    for label, count in proposed["state_counts"].items():
        trial["gas_state_counts"][label] += count
    trial["gas_mass"] += proposed["mass"]
    trial["gas_momentum"] = add(trial["gas_momentum"], proposed["momentum_lab"])
    trial["gas_kinetic"] += proposed["kinetic_lab_actual"]
    trial["gas_internal"] += proposed["gas_internal_above_ground_I"]
    audit["provisional_gas_inserted"] = True
    audit["provisional_gas_records"] = len(trial["gas_packets"])
    if corrupt_provisional_gas_energy:
        trial["gas_kinetic"] += F("1e-22")
        audit["injected_accounting_fault_J"] = F("1e-22")
    for pool, count in proposed["pool_counts"].items():
        trial["inventory"][pool] -= count
    trial["wall_mass"] -= proposed["mass"]
    trial["wall_thermal"] -= proposed["thermal_debit"]
    trial["wall_bound_reference"] += proposed["bound_reference_increase_D"]
    trial["wall_advected_momentum"] = add(trial["wall_advected_momentum"],
                                            scale(proposed["advected_mass_momentum_removed"], -1))
    trial["wall_advected_kinetic"] -= proposed["advected_mass_kinetic_removed"]
    trial["support_impulse_supplied"] = add(trial["support_impulse_supplied"], proposed["support_impulse_supplied"])
    trial["support_work_supplied"] += proposed["support_work_supplied"]
    trial["external_momentum"] = add(trial["external_momentum"], scale(proposed["support_impulse_supplied"], -1))
    trial["external_energy"] -= proposed["support_work_supplied"]
    audit["proposed_remaining_thermal_J"] = trial["wall_thermal"]
    if trial["wall_thermal"] < 0:
        assert canonical(state) == before
        return state, False, "negative_proposed_available_thermal", audit
    if trial["wall_mass"] <= 0 or any(count < 0 for count in trial["inventory"].values()):
        return state, False, "invalid_proposed_mass_or_inventory", audit
    energy_residual = total_energy(trial) - total_energy(state)
    momentum_residual = add(total_momentum(trial), scale(total_momentum(state), -1))
    audit["combined_energy_residual_J"] = energy_residual
    audit["combined_momentum_residual_kg_m_s"] = momentum_residual
    if energy_residual != 0 or momentum_residual != ZERO:
        assert canonical(state) == before
        return state, False, "conservation_rejected_after_provisional_gas_insertion", audit
    assert state["wall_mass"] + state["gas_mass"] == trial["wall_mass"] + trial["gas_mass"]
    assert trial["wall_advected_momentum"] == scale(trial["velocity_prescribed"], trial["wall_mass"])
    assert trial["wall_advected_kinetic"] == trial["wall_mass"] * dot(trial["velocity_prescribed"], trial["velocity_prescribed"]) / 2
    assert trial["wall_bound_reference"] == -sum((count * STATES[POOL_STATES[pool]]["D"]
                                                 for pool, count in trial["inventory"].items()), F(0))
    for pool, label in POOL_STATES.items():
        assert state["inventory"][pool] + state["gas_state_counts"][label] == trial["inventory"][pool] + trial["gas_state_counts"][label]
    trial["version"] += 1
    trial["committed_step"] += 1
    trial["cursor"] += len(candidate.supplied_tokens)
    trial["accepted_ids"] = trial["accepted_ids"] | {candidate.transaction_id}
    assert canonical(state) == before
    return trial, True, "accepted", audit


def checkpoint_roundtrip(state, pending):
    checkpoint = {"schema": "manufactured-accounting-checkpoint-v1", "committed": state,
                  "pending": candidate_record(pending) if pending is not None else None}
    restored = decode(json.loads(canonical(checkpoint)))
    assert canonical(restored["committed"]) == canonical(state)
    restored_pending = (candidate_from_record(restored["pending"])
                        if restored["pending"] is not None else None)
    return restored["committed"], restored_pending, digest(checkpoint)


def checked_attempt(state, candidate, **kwargs):
    before_bytes = canonical(state)
    result = attempt(state, candidate, **kwargs)
    assert canonical(state) == before_bytes, "committed input mutated during trial"
    if not result[1]:
        assert canonical(result[0]) == before_bytes, "rejection changed committed state"
    return result


def run_cases():
    cases = []

    def record(name, before, after, accepted, reason, audit, expected_accept):
        assert accepted is expected_accept, (name, reason)
        if not accepted:
            assert canonical(after) == canonical(before), name
        cases.append({"name": name, "accepted": accepted, "reason": reason,
                      "before_state_sha256": digest(before), "after_state_sha256": digest(after),
                      "unchanged_on_rejection": not accepted and canonical(after) == canonical(before),
                      "audit": audit})

    stationary = initial_state()
    candidate = make_candidate(stationary)
    accepted, ok, reason, audit = checked_attempt(stationary, candidate)
    record("stationary_two_packet_commit", stationary, accepted, ok, reason, audit, True)
    assert accepted["inventory"] == {"pool_A": F(8), "pool_B": F(5)}
    assert audit["ledger"]["mass"] == F("1.6e-25")
    assert audit["ledger"]["kinetic_rest_actual"] == F("1.9e-19")
    assert audit["ledger"]["translation_expected_2kBT"] == F("6.6271152e-20")
    assert audit["ledger"]["thermal_debit"] == F("5.0242444363e-19")
    assert accepted["wall_thermal"] == F("1.49757555637e-18")
    assert accepted["cursor"] == 9 and len(accepted["gas_packets"]) == 2
    assert audit["ledger"]["translation_actual_minus_expected"] != 0

    moving = initial_state((F(400), F(-200), F(100)))
    moved, ok, reason, audit = checked_attempt(moving, make_candidate(moving))
    record("prescribed_velocity_two_packet_commit", moving, moved, ok, reason, audit, True)
    assert audit["ledger"]["advected_mass_kinetic_removed"] == F("1.68e-20")
    assert audit["ledger"]["support_work_supplied"] == F("-4.2e-20")
    assert audit["ledger"]["kinetic_lab_actual"] == F("1.648e-19")
    assert audit["ledger"]["thermal_debit"] == F("5.0242444363e-19")
    assert (total_energy(moved) - moved["external_energy"]
            - total_energy(moving) + moving["external_energy"]) == F("-4.2e-20")

    low_thermal = initial_state(thermal=F("2.51212221815e-19"))
    after, ok, reason, audit = checked_attempt(low_thermal, make_candidate(low_thermal))
    record("negative_proposed_available_thermal_rejected", low_thermal, after, ok, reason, audit, False)
    assert reason == "negative_proposed_available_thermal" and audit["provisional_gas_inserted"]

    initial_negative = initial_state(thermal=F("-1e-22"))
    after, ok, reason, audit = checked_attempt(initial_negative, make_candidate(initial_negative))
    record("negative_initial_available_thermal_rejected", initial_negative, after, ok, reason, audit, False)

    for name, altered, expected_reason in (
        ("stale_version_rejected", replace(candidate, version=6), "stale_committed_version_or_step"),
        ("stale_cursor_rejected", replace(candidate, cursor=4), "stale_or_invalid_replay_cursor"),
        ("invalid_geometry_rejected", replace(candidate, geometry="unassociated-geometry"), "invalid_source_or_geometry_association"),
        ("invalid_state_rejected", replace(candidate, packets=(replace(candidate.packets[0], state="undefined_generic_state"), candidate.packets[1])), "invalid_generic_state_membership_or_reference"),
        ("inward_packet_rejected", replace(candidate, packets=(replace(candidate.packets[0], velocity_rest=(F(1), F(-1), F(0))), candidate.packets[1])), "invalid_weight_or_outward_geometry"),
    ):
        after, ok, reason, audit = checked_attempt(stationary, altered)
        record(name, stationary, after, ok, reason, audit, False)
        assert reason == expected_reason

    after, ok, reason, audit = checked_attempt(accepted, candidate)
    record("duplicate_accepted_transaction_rejected", accepted, after, ok, reason, audit, False)
    assert reason == "duplicate_accepted_transaction"

    depleted = initial_state(inventory={"pool_A": F(1), "pool_B": F(8)})
    after, ok, reason, audit = checked_attempt(depleted, make_candidate(depleted))
    record("insufficient_live_coverage_rejected", depleted, after, ok, reason, audit, False)
    assert reason == "insufficient_live_coverage"

    after, ok, reason, audit = checked_attempt(stationary, candidate, corrupt_provisional_gas_energy=True)
    record("conservation_failure_after_provisional_gas_insertion", stationary, after, ok, reason, audit, False)
    assert audit["provisional_gas_records"] == 2 and reason == "conservation_rejected_after_provisional_gas_insertion"
    assert audit["combined_energy_residual_J"] == F("1e-22")
    assert len(after["gas_packets"]) == 0 and after["cursor"] == 5

    replay = make_candidate(after)
    assert canonical(candidate_record(replay)) == canonical(candidate_record(candidate))
    replayed, ok, reason, audit = checked_attempt(after, replay)
    assert canonical(replayed) == canonical(accepted)
    assert canonical(audit["ledger"]) == canonical(ledger(candidate, ZERO))
    record("deterministic_replay_after_rejection", after, replayed, ok, reason, audit, True)

    restarted_before, pending, checkpoint_hash = checkpoint_roundtrip(stationary, candidate)
    assert pending is not None and candidate_record(pending) == candidate_record(candidate)
    restarted_accepted, ok, reason, audit = checked_attempt(restarted_before, pending)
    assert canonical(restarted_accepted) == canonical(accepted)
    audit["checkpoint_sha256"] = checkpoint_hash
    audit["pending_distinct_from_accepted"] = candidate.transaction_id not in restarted_before["accepted_ids"]
    record("restart_before_acceptance_preserves_pending", restarted_before, restarted_accepted, ok, reason, audit, True)

    restarted_after, pending, checkpoint_hash = checkpoint_roundtrip(accepted, None)
    assert pending is None and candidate.transaction_id in restarted_after["accepted_ids"]
    after, ok, reason, audit = checked_attempt(restarted_after, candidate)
    audit["checkpoint_sha256"] = checkpoint_hash
    record("restart_after_acceptance_blocks_duplicate", restarted_after, after, ok, reason, audit, False)
    assert reason == "duplicate_accepted_transaction"
    return cases


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--requirements-document", type=Path,
                        default=Path("/workspace/Power-Flow/docs/boundary_transaction_requirements.md"))
    args = parser.parse_args()
    cases = run_cases()
    source = Path(__file__)
    result = {
        "schema": "manufactured-boundary-owner-acceptance-examples-v1",
        "script_sha256": hashlib.sha256(source.read_bytes()).hexdigest(),
        "arithmetic": "exact Fraction inputs/accounts; no numerical conservation tolerance",
        "fixture_source": "docs/boundary_transaction_requirements.md manufactured two-packet arithmetic case",
        "requirements_document": {"path": str(args.requirements_document),
                                  "sha256": hashlib.sha256(args.requirements_document.read_bytes()).hexdigest()},
        "symbolic_state_scope": "Generic A/B counts; no physical nuclei/charge catalog or molecular assignment",
        "candidate_scope": "Supplied fixed launch records; replay tokens are cursor metadata; no physical sampling",
        "wall_convention": "Externally supported stationary or prescribed common velocity; adsorbed mass already in wall mass",
        "bound_reference": "U_bound=-sum(N_pool*D_pool), independent manufactured constant D; I above gas-ground zero",
        "not_tested": ["live host integration", "EOS admissibility or wall thermodynamic closure",
                       "physical nuclei/charge/chemistry validation", "finite-wall recoil",
                       "trajectories, collisions, radiative modeling or gap stepping",
                       "concurrent atomicity, filesystem durability or distributed restart"],
        "summary": {"cases": len(cases), "accepted_case_outcomes": sum(item["accepted"] for item in cases),
                    "rejected_case_outcomes": sum(not item["accepted"] for item in cases),
                    "all_rejections_preserve_exact_committed_state": all(item["unchanged_on_rejection"] for item in cases if not item["accepted"]),
                    "all_assertions_passed": True},
        "cases": cases,
    }
    with args.output.open("x") as stream:
        json.dump(encode(result), stream, indent=2, sort_keys=True)
        stream.write("\n")
    print(json.dumps({"output": str(args.output), "output_sha256": hashlib.sha256(args.output.read_bytes()).hexdigest(),
                      "script_sha256": result["script_sha256"], **result["summary"]}, indent=2))


if __name__ == "__main__":
    main()
