"""Bounded manufactured finite-volume verification of a periodic reference.

This independent two-field calculation is limited to the four named constant-
property cases below. It is not an experimental simulation or host solver.
"""

from dataclasses import asdict
import hashlib
import json
import math
from pathlib import Path
import sys

import numpy as np
import scipy
from scipy.integrate import solve_ivp
from scipy.sparse import bmat, csr_matrix, diags

ROOT = Path("/workspace/Power-Flow")
sys.path.insert(0, str(ROOT))
from mhdlab.conductive_heating_benchmark import PeriodicConductiveHeating

WORK = Path(__file__).resolve().parent
OUTPUT = WORK / "conductive_fd_evidence"
SOURCE = ROOT / "mhdlab/conductive_heating_benchmark.py"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    OUTPUT.mkdir(exist_ok=False)
    source_sha = sha(SOURCE)
    case_records = []
    sigma, mu, cv, k, b0, stop = 2., .5, 3., 1., -2., .6
    eta = 1 / (mu * sigma)
    period = 2 * math.pi / k
    sizes = [32, 64, 128]
    for kappa in (0., .15, 1.5, 15.):
        model = PeriodicConductiveHeating(sigma, mu, cv, kappa, k, b0)
        records = []
        for size in sizes:
            edges = np.linspace(-.37 * period, .63 * period, size + 1)
            dx = period / size
            centers = (edges[:-1] + edges[1:]) / 2
            # Exact projection of the initial cosine to finite-volume means.
            initial_b = b0 * np.sinc(k * dx / (2 * math.pi)) * np.cos(k * centers)
            initial = np.r_[initial_b, np.zeros(size)]
            laplace = diags([np.ones(size - 1), -2 * np.ones(size), np.ones(size - 1)],
                           [-1, 0, 1], format="lil")
            laplace[0, -1] = laplace[-1, 0] = 1
            laplace = laplace.tocsr() / dx**2
            local_pattern = laplace.copy()
            local_pattern.data[:] = 1
            structure = bmat([[local_pattern, None], [local_pattern, local_pattern]], format="csr")

            def right_hand_side(time, values):
                field = values[:size]
                temperature = values[size:]
                # Periodic face current and average of adjacent face heat.
                # This pairing makes the discrete magnetic work and thermal
                # deposition exactly the same algebraic quantity.
                face_current = (field - np.roll(field, -1)) / (mu * dx)
                face_heat = face_current**2 / sigma
                cell_heat = .5 * (face_heat + np.roll(face_heat, 1))
                return np.r_[eta * (laplace @ field),
                             (kappa * (laplace @ temperature) + cell_heat) / cv]

            solution = solve_ivp(right_hand_side, (0., stop), initial, method="BDF",
                                 rtol=2e-11, atol=2e-13, jac_sparsity=structure,
                                 t_eval=[0., .1, .3, stop])
            assert solution.success, solution.message
            values = solution.y[:, -1]
            field, temperature = values[:size], values[size:]
            face_current = (field - np.roll(field, -1)) / (mu * dx)
            cell_heat = .5 * (face_current**2 + np.roll(face_current**2, 1)) / sigma
            exact = model.cell_averages(edges, stop)
            energy_history = np.mean(solution.y[:size]**2, axis=0) / (2 * mu) + cv * np.mean(solution.y[size:], axis=0)
            initial_energy = np.mean(initial_b**2) / (2 * mu)
            energy_residual = energy_history - initial_energy
            energy_relative = float(np.max(np.abs(energy_residual)) / initial_energy)
            assert energy_relative < 2e-9
            assert np.min(temperature) > -2e-12
            assert np.min(cell_heat) >= 0
            errors = {}
            for name, actual, expected in (
                ("magnetic_cell_mean", field, exact.magnetic_field_t),
                ("temperature_cell_mean", temperature, exact.temperature_rise_k),
                ("joule_cell_mean", cell_heat, exact.joule_power_w_m3),
            ):
                errors[name] = float(np.linalg.norm(actual - expected) / np.linalg.norm(expected))
            exact_budget = model.energy_budget(stop)
            errors["mean_thermal_energy"] = abs(cv * float(np.mean(temperature)) - exact_budget.mean_thermal_energy_j_m3) / exact_budget.mean_thermal_energy_j_m3
            filename = f"kappa_{kappa:g}_cells_{size}.npz"
            np.savez_compressed(OUTPUT / filename, position_edges_m=edges,
                                evaluated_time_s=solution.t, numerical_state=solution.y,
                                exact_magnetic_cell_mean_t=exact.magnetic_field_t,
                                exact_temperature_cell_mean_k=exact.temperature_rise_k,
                                exact_joule_cell_mean_w_m3=exact.joule_power_w_m3,
                                numerical_joule_cell_mean_w_m3=cell_heat,
                                discrete_total_energy_j_m3=energy_history,
                                discrete_energy_residual_j_m3=energy_residual)
            records.append({"cells": size, "relative_l2_errors": errors,
                            "maximum_relative_discrete_energy_residual": energy_relative,
                            "nfev": solution.nfev, "njev": solution.njev,
                            "artifact": filename, "artifact_sha256": sha(OUTPUT / filename)})
        orders = {}
        for name in records[0]["relative_l2_errors"]:
            errors = [item["relative_l2_errors"][name] for item in records]
            order = [math.log(first / second, 2) for first, second in zip(errors[:-1], errors[1:])]
            assert all(1.7 < value < 2.3 for value in order), (kappa, name, errors, order)
            orders[name] = order
        case_records.append({"thermal_conductivity_w_m_k": kappa,
                             "thermal_to_resistive_decay_ratio": model.thermal_mode_decay_rate_s / model.resistive_energy_decay_rate_s,
                             "results": records, "observed_reference_error_orders": orders,
                             "exact_energy_budget": asdict(model.energy_budget(stop))})
    assert sha(SOURCE) == source_sha, "reference implementation changed during verification"
    report = {"schema": "mhdlab-independent-conductive-fv-verification-v1",
              "parameter_status": "manufactured",
              "scope": "independent periodic finite-volume resistive induction and conductive heating verification",
              "parameters": {"conductivity_s_m": sigma, "permeability_h_m": mu,
                             "volumetric_heat_capacity_j_m3_k": cv, "wavenumber_rad_m": k,
                             "initial_field_t": b0, "stop_time_s": stop},
              "integrator": {"method": "BDF", "rtol": 2e-11, "atol": 2e-13,
                             "numpy_version": np.__version__, "scipy_version": scipy.__version__},
              "reference_sha256": source_sha,
              "verification_script_sha256": sha(Path(__file__)), "cases": case_records,
              "limits": ["This is an independent bounded manufactured calculation; no actual FLASH or target host run.",
                         "Finite-volume current and heat are discrete approximations; exact references integrate each cell independently.",
                         "Discrete magnetic energy uses squared cell means and differs from exact continuum storage by projection error.",
                         "Observed errors include the spatial scheme and finite integration tolerances; observed orders are numerical evidence, not certified bounds.",
                         "Constant properties, stationary periodic geometry and supplied Cv; no source chemistry, Hall term, flow, EOS or phase change."]}
    path = OUTPUT / "report.json"
    path.write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
    print(json.dumps({"report": str(path), "report_sha256": sha(path),
                      "cases": len(case_records), "spatial_solutions": sum(len(case["results"]) for case in case_records),
                      "maximum_energy_relative_residual": max(item["maximum_relative_discrete_energy_residual"] for case in case_records for item in case["results"]),
                      "order_range": [min(value for case in case_records for order in case["observed_reference_error_orders"].values() for value in order),
                                      max(value for case in case_records for order in case["observed_reference_error_orders"].values() for value in order)]}, indent=2))


if __name__ == "__main__":
    main()
