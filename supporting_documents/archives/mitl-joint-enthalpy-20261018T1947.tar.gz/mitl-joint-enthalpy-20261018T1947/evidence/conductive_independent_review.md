# Periodic conductive-heating reference: independent review

Reviewed 18 October 2026. Public reference bytes are pinned by SHA256
`63a9ba9f6d97f9b3d6be89cde362faf2f2a8c29432bd9b9c923124c18e57389e`.
No public implementation was edited during this review. The separate targeted
reference tests were inspected rather than repeated.

## Equations and signs

For stationary material, let `eta=1/(mu*sigma)`, `lambda=2*eta*k^2`,
`delta=4*kappa*k^2/Cv` and `M0=B0^2/(4*mu)`. Resistive diffusion gives
`Bx=B0*cos(k*y)*exp(-lambda*t/2)`. Ampere's law gives
`Jz=-dBx/dy/mu`, so the reference's positive sine current has the correct
orientation. Joule power is
`q=(B0^2*k^2/(2*mu^2*sigma))*exp(-lambda*t)*(1-cos(2*k*y))`.

The zero and second Fourier harmonics of `Cv*dT/dt=kappa*T''+q` integrate
independently. With `F=1-exp(-lambda*t)` and
`H=lambda*(exp(-lambda*t)-exp(-delta*t))/(delta-lambda)`, the rise is
`T=(M0/Cv)*(F-H*cos(2*k*y))`. At resonance, `H=lambda*t*exp(-lambda*t)`;
at zero thermal conductivity, `H=F`. Both limits agree with the supplied
implementation. Conduction smooths the profile but leaves mean heat equal to
`M0*F`; mean magnetic storage is `M0*exp(-lambda*t)`. Their sum is `M0`
in a periodic domain with no net Poynting or conductive flux.

The implementation's form `T=(M0/Cv)*(D+2*H*sin(k*y)^2)`, `D=F-H`, avoids
subtracting nearly equal nonnegative terms at magnetic maxima. Its positive
small-rate triangle integral has the correct normalization. The factored
exponential difference has the correct near-resonance and disparate-rate
limits. Finite-volume Joule power integrates `sin^2(k*y)` independently;
squaring a cell-mean current would not give that reference. The temperature
cell average uses the same independently integrated second harmonic.

## New coupled numerical verification

`conductive_fd_verification.py` advances a bounded periodic finite-volume
magnetic/temperature system with centered second differences and a BDF time
integrator. Magnetic field starts from the exact cosine cell projection.
Face currents come from differences of adjacent cell means. Each cell receives
the mean of its two adjacent face Joule powers. This pairing gives the
discrete identity
`d(mean(B_cell^2)/(2*mu))/dt = -mean(J_face^2/sigma)` and exactly the same
mean thermal source. The numerical discrete magnetic reservoir is the square
of cell means; its initial value differs from continuum magnetic storage by
projection error, which is retained rather than hidden in the energy residual.

All inputs are manufactured: `sigma=2 S/m`, `mu=0.5 H/m`, `Cv=3 J/(m^3 K)`,
`k=1 rad/m`, `B0=-2 T`, and final time `0.6 s`. Thermal conductivities
`0,0.15,1.5,15 W/(m K)` select decay-rate ratios `delta/lambda=0,0.1,1,10`.
Each case uses 32, 64 and 128 cells with a shifted periodic origin. These
values select useful numerical limits and do not represent stainless steel.

| Decay-rate ratio | Finest temperature relative L2 error | Temperature orders, 32/64 then 64/128 |
| --- | ---: | --- |
| 0 | 0.000686044 | 1.99401, 1.99850 |
| 0.1 | 0.000630316 | 1.99506, 1.99877 |
| 1 | 0.000353121 | 2.00133, 2.00034 |
| 10 | 0.000304463 | 1.99815, 1.99954 |

All magnetic, temperature, Joule and mean-thermal-energy reference differences
converged with orders between `1.9940085991` and `2.0013312586`. The maximum
relative discrete total-energy residual across saved times and twelve spatial
solutions was `2.1187110392e-10`. Exact formulas were not used to advance the
coupled numerical system; they were used only for initialization projection
and final cell-reference comparison.

## Evidence, resolved verification issue and limits

The numerical command exited zero and is recorded as `conductive-fv-independent`
in `commands.jsonl`. It produced twelve compressed array artifacts and
`conductive_fd_evidence/report.json`, SHA256
`42692df9db8f7021e5964fec216cc0ab6efbdaef65fa903ef55bf71fd8694e55`.
Each archive was reopened with `allow_pickle=False`; its byte hash, finite
arrays, stored energy identity, energy residual and reference-error norms were
recomputed successfully. That final command is `conductive-fv-integrity-corrected`.

The first artifact-integrity command exited one because it subtracted the
stored column-reduced initial energy instead of the separately evaluated
one-dimensional initial reservoir used in the numerical report. Those NumPy
summations differed by `4.44e-16 J/m^3` in one case. The verification script was
corrected to reproduce the declared initial-energy calculation; the numerical
solutions and their original evidence were preserved. No numerical evolution
or passing reference suite was repeated.

The cases qualify an independent constant-property verification ladder. They
do not constitute an actual FLASH, Quark or workstation run, a material EOS,
a foil heating result, a desorption calculation, or experimental validation.
Finite time-integration tolerance remains in the observed spatial differences.
Source-file hashes pin the reviewed version; later formula changes require
assessment before reusing these reference comparisons.
