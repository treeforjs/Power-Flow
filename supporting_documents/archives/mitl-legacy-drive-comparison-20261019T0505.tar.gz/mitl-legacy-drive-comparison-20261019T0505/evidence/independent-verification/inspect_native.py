"""Fresh native inspection of the two published simulation-current insets."""
import hashlib
import io
import json
from pathlib import Path
import pymupdf
from PIL import Image

ROOT=Path(__file__).resolve().parent
LOCAL=ROOT/'source-local'
PDF=Path('/workspace/research_sources/smtrevor_1.pdf')
PIN='1d7b1f9c191a37e94f1cc3634587750f1af35b07eb13e0b94c60f3da47495ed7'

def sha(data):
    return hashlib.sha256(data).hexdigest()

assert sha(PDF.read_bytes())==PIN
LOCAL.mkdir(parents=True,exist_ok=True)
records=[]
with pymupdf.open(PDF) as doc:
    for index,xref,name in [(118,2847,'4.28'),(120,2870,'4.29')]:
        page=doc[index]
        image=Image.open(io.BytesIO(doc.extract_image(xref)['image'])).convert('RGB')
        assert image.size==(975,975)
        native=LOCAL/f'figure-{name}-native.png';image.save(native)
        crop=LOCAL/f'figure-{name}-drive-panel.png';image.crop((0,0,530,485)).resize((1060,970)).save(crop)
        pixels=image.load()
        selected=[(x,y) for x in range(0,530) for y in range(0,485) if pixels[x,y]==(178,34,34)]
        records.append({'figure':name,'page_index':index,'xref':xref,'size':[975,975],
            'RGB_pixels_sha256':sha(image.tobytes()),'page_content_sha256':sha(page.read_contents()),
            'page_text':page.get_text(),'exact_colour_RGB':[178,34,34],
            'exact_colour_pixel_count':len(selected),
            'exact_colour_bbox':[min(x for x,y in selected),min(y for x,y in selected),max(x for x,y in selected),max(y for x,y in selected)],
            'exact_colour_by_column':{str(x):[y for xx,y in selected if xx==x] for x in sorted(set(x for x,y in selected))},
            'local_native_png_sha256':sha(native.read_bytes()),'local_crop_png_sha256':sha(crop.read_bytes())})
out={'schema':'mitl-independent-simulation-drive-native-inspection-v1','source_pdf_sha256':PIN,
    'script_sha256':sha(Path(__file__).read_bytes()),'cases':records,
    'limits':['Native image, color and source text inspection only; no recovery producer or prior test suite called.',
        'The inset is published legacy simulation context. The figure time coordinate does not independently register clocks or recover the simulation input deck.']}
path=ROOT/'native-inspection.json';path.write_text(json.dumps(out,indent=2,allow_nan=False)+'\n')
print(json.dumps({'output':str(path),'sha256':sha(path.read_bytes()),'cases':[{k:r[k] for k in ['figure','RGB_pixels_sha256','exact_colour_bbox','exact_colour_pixel_count']} for r in records]},indent=2))
