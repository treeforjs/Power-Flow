"""Compare frozen simulation-drive CSV/JSON to independent native references."""
import csv
from decimal import Decimal,localcontext
from fractions import Fraction as F
import hashlib
import json
import math
from pathlib import Path
from PIL import Image

ROOT=Path(__file__).resolve().parent
WORK=ROOT.parent
REPO=Path('/workspace/Power-Flow')
PUBLIC={
    'tools/recover_dissertation_simulation_drive.py':'d529b7ef7f2765712d3dc611f783ed4afd4476c71cd263358b1660e8040a9e14',
    'data/dissertation/figure_4_28_simulation_drive.csv':'7d40eeb991f289c18e107c0423cfa366b78af8e9fe943aa823d11a8b23fd6a3c',
    'data/dissertation/figure_4_28_simulation_drive.json':'4109109058df6ec6e20d6efdbe36ec9535a38c41f7e8948630e9a631ae35c61b',
    'data/dissertation/figure_4_29_simulation_drive.csv':'b5b8ffab25d3efd5058a433c1e66aaff85314b5c2d0edffad558c464c74a92ef',
    'data/dissertation/figure_4_29_simulation_drive.json':'776eaaf83a56ed693d4826be58134ed60465513351c4c91cb3689036d88945ff',
}
FIELDS=['source_identifier','figure','snapshot_time_s','pixel_x','pixel_y_median',
    'run_first_pixel_y','run_last_pixel_y','matched_color_pixels','time_ns',
    'time_readout_lower_ns','time_readout_upper_ns','current_MA','current_readout_lower_MA',
    'current_readout_upper_MA','time_s','time_readout_lower_s','time_readout_upper_s',
    'current_A','current_readout_lower_A','current_readout_upper_A','left_display_clip_column',
    'thin_run_endpoint_candidate']
INTEGER_FIELDS={'pixel_x','run_first_pixel_y','run_last_pixel_y','matched_color_pixels',
    'left_display_clip_column','thin_run_endpoint_candidate'}

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def pairs(items):
    result={}
    for key,value in items:
        assert key not in result,('duplicate key',key)
        result[key]=value
    return result

def load(path):
    return json.loads(path.read_text(),object_pairs_hook=pairs,
        parse_constant=lambda s:(_ for _ in ()).throw(ValueError(s)))

def f(record):
    return F(int(record['numerator']),int(record['denominator']))

def decimal_bound(value):
    if not value:
        return F(0)
    with localcontext() as context:
        context.prec=100
        magnitude=(Decimal(abs(value.numerator))/Decimal(value.denominator)).adjusted()
    exponent=magnitude-11
    return F(10**exponent,2) if exponent>=0 else F(1,2*10**(-exponent))

def check(text,exact,arithmetic,key):
    assert text and text.strip()==text
    if key in INTEGER_FIELDS:
        assert str(int(text))==text and F(int(text))==exact
        return F(0)
    assert math.isfinite(float(text)) and math.isfinite(arithmetic)
    actual=F(Decimal(text))
    allowed=decimal_bound(F.from_float(arithmetic))+abs(F.from_float(arithmetic)-exact)
    assert abs(actual-exact)<=allowed,(key,text,float(exact),float(allowed))
    return abs(actual-exact)

assert not (ROOT/'readback.json').exists()
for name,digest in PUBLIC.items():
    assert sha(REPO/name)==digest,name
assert sha(ROOT/'selected-reference.json')=='508dc7da5ed604452a3770ca0a9e6362e840d48be61d8c831c6fdedc495f8264'
assert sha(ROOT/'coordinate-reference.json')=='4d132739cbb4dd4c2b2f760e2a682d7011ab0a8f2adf5b2bb9bd7b69a5ed980c'
native=load(ROOT/'native-inspection.json')
coordinates=load(ROOT/'coordinate-reference.json')
selected=load(ROOT/'selected-reference.json')
assert sha(Path('/workspace/research_sources/smtrevor_1.pdf'))==native['source_pdf_sha256']==coordinates['source_pdf_sha256']
total_cells=0
max_difference={key:F(0) for key in FIELDS[2:]}
cases=[]
other_pins={}
for raw,cal,ref in zip(native['cases'],coordinates['cases'],selected['cases']):
    figure=ref['figure'];stem='figure_'+figure.replace('.','_')+'_simulation_drive'
    csvfile=REPO/'data/dissertation'/(stem+'.csv')
    metadata=load(csvfile.with_suffix('.json'))
    assert metadata['schema']=='mhdlab-dissertation-simulation-drive-recovery-v1'
    assert metadata['source_identifier']==stem
    source=metadata['source']
    expected_source={'pdf_sha256':native['source_pdf_sha256'],'figure':figure,
        'printed_page':94 if figure=='4.28' else 96,'pdf_page':raw['page_index']+1,
        'pdf_page_index':raw['page_index'],'page_content_sha256':raw['page_content_sha256'],
        'page_text':raw['page_text'],'embedded_image_xref':raw['xref'],
        'native_image_size_pixels':[975,975],'native_image_mode':'RGB',
        'decoded_RGB_pixels_sha256':raw['RGB_pixels_sha256']}
    assert all(source[key]==value for key,value in expected_source.items())
    context=metadata['simulation_context'];snapshot=40 if figure=='4.28' else 60
    assert context['code_label_in_dissertation']=='Allegra' and context['drive_shot_caption_label']==17133
    assert context['caption_snapshot_time_s']==snapshot*1e-9
    for key in ['experimental_measurement','FLASH_result','original_simulation_input_array_recovered',
        'experimental_clock_alignment_established','time_shift_or_scale_fit_applied',
        'current_repair_or_normalization_applied','VUV_gate_recovered','snapshot_is_observed_waveform_end']:
        assert context[key] is False
    units=metadata['unit_interpretation']
    assert units['horizontal_axis_label']=='Time [ns]' and units['vertical_axis_label']=='Current [MA]'
    assert units['time_scale_to_s']==1e-9 and units['current_scale_to_A']==1e6
    assert units['original_simulation_input_normalization_verified'] is False
    assert units['negative_display_times_preserved'] is True
    assert units['readout_bounds_clipped_to_nonnegative_current'] is False
    selection=metadata['selection']
    assert selection['panel_ROI_inclusive']=={'x':[90,477],'y':[19,411]}
    assert selection['native_frame_strokes']=={'left_x':[88,89],'right_x':[478,479],'bottom_y':[412,413],'top_y':[17,18]}
    assert selection['source_RGB']==[178,34,34] and selection['column_stride']==1
    assert selection['left_display_support_clipped'] is True
    for key in ['interpolation','smoothing','extrapolation','endpoint_padding','zero_time_or_current_inserted']:
        assert selection[key] is False
    for key in ['independent_noise_or_confidence_interval','bounds_are_observed_source_support',
                'physical_or_simulation_uncertainty_quantified']:
        assert metadata['readout_bounds'][key] is False
    assert metadata['readout_bounds']['correlated_display_bounds_only'] is True
    assert metadata['readout_bounds']['additional_pixel_readout_half_width']==2
    image=Image.open(ROOT/'source-local'/f'figure-{figure}-native.png').convert('RGB')
    assert hashlib.sha256(image.tobytes()).hexdigest()==raw['RGB_pixels_sha256']
    pixels=image.load()
    for y in [17,18,412,413]:
        assert sum(max(pixels[x,y])<128 for x in range(90,478))>=380
    for x in [88,89,478,479]:
        assert sum(max(pixels[x,y])<128 for y in range(19,412))>=380
    for name,unit,reverse in [('time','ns',False),('current','MA',True)]:
        fit=metadata['calibration'][name]
        m=f(cal[name+'_slope_'+unit+'_per_pixel']);b=f(cal[name+'_intercept_'+unit])
        assert fit['slope_exact']==[str(m.numerator),str(m.denominator)]
        assert fit['intercept_exact']==[str(b.numerator),str(b.denominator)]
        assert fit['slope']==float(m) and fit['intercept']==float(b)
        centers=cal[name+'_tick_centers'];values=cal[name+'_tick_values_'+unit]
        residuals=cal[name+'_tick_residuals_'+unit]
        if reverse:
            centers=list(reversed(centers));values=list(reversed(values));residuals=list(reversed(residuals))
        assert fit['tick_pixel_centres']==[float(f(x)) for x in centers]
        assert fit['tick_values']==[float(f(x)) for x in values]
        assert fit['tick_residuals']==[-float(f(x)) for x in residuals]
        assert fit['max_abs_tick_residual']==float(max(abs(f(x)) for x in residuals))
    expected_retained=[{key:row[key] for key in ['pixel_x','exact_colour_runs_inclusive_y','reason']} for row in ref['retained']]
    assert selection['retained_columns']==expected_retained
    assert selection['excluded_columns']==ref['excluded']
    assert selection['retained_count']==ref['retained_count']
    assert selection['excluded_count']==ref['excluded_count'] and selection['catalogued_column_count']==388
    output=metadata['output']
    assert output['csv_sha256']==sha(csvfile) and output['columns']==FIELDS
    assert output['samples']==ref['retained_count'] and output['line_ending']=='LF'
    assert output['generator_sha256']==PUBLIC['tools/recover_dissertation_simulation_drive.py']
    assert output['time_support_ns']==[ref['retained'][0]['arithmetic_values']['time_ns'],ref['retained'][-1]['arithmetic_values']['time_ns']]
    assert output['time_support_s']==[ref['retained'][0]['arithmetic_values']['time_s'],ref['retained'][-1]['arithmetic_values']['time_s']]
    values=[row['arithmetic_values']['current_MA'] for row in ref['retained']]
    assert output['current_extent_MA']==[min(values),max(values)]
    geometryfile=WORK/'recovery'/output['source_geometry_filename']
    assert sha(geometryfile)==output['source_geometry_sha256']
    geometry=load(geometryfile)
    assert geometry['schema']=='mhdlab-simulation-drive-source-geometry-v1'
    assert geometry['source_RGB']==[178,34,34]
    assert geometry['calibration']=={key:metadata['calibration'][key] for key in ['time','current']}
    assert geometry['selection']=={key:selection[key] for key in ['retained_columns','excluded_columns','retained_count','excluded_count','catalogued_column_count']}
    other_pins[str(geometryfile)]=sha(geometryfile)
    for filename,digest in output['QA_files_sha256'].items():
        path=WORK/'recovery'/filename
        assert sha(path)==digest
        other_pins[str(path)]=digest
    assert b'\r' not in csvfile.read_bytes()
    with csvfile.open(newline='') as stream:
        reader=csv.DictReader(stream);assert reader.fieldnames==FIELDS
        rows=list(reader)
    assert len(rows)==ref['retained_count']
    left_count=0;thin_count=0;negative_bounds=0
    for row,expected in zip(rows,ref['retained']):
        assert row['source_identifier']==stem and row['figure']==figure
        exact={key:f(value) for key,value in expected['exact_values'].items()}
        arithmetic=dict(expected['arithmetic_values'])
        exact.update({'snapshot_time_s':F(snapshot,10**9),
            'left_display_clip_column':F(int(expected['pixel_x']==90)),
            'thin_run_endpoint_candidate':F(int(exact['matched_color_pixels']==2))})
        arithmetic.update({'snapshot_time_s':snapshot*1e-9,
            'left_display_clip_column':float(exact['left_display_clip_column']),
            'thin_run_endpoint_candidate':float(exact['thin_run_endpoint_candidate'])})
        assert set(exact)==set(FIELDS[2:])
        for key,value in exact.items():
            difference=check(row[key],value,arithmetic[key],key)
            max_difference[key]=max(max_difference[key],difference)
            total_cells+=1
        left_count+=int(row['left_display_clip_column']);thin_count+=int(row['thin_run_endpoint_candidate'])
        negative_bounds+=float(row['current_readout_lower_MA'])<0
    assert left_count==1 and negative_bounds>0
    cases.append({'figure':figure,'retained_columns':ref['retained_count'],'excluded_columns':ref['excluded_count'],
        'native_columns_catalogued':388,'negative_time_columns':ref['negative_time_columns'],
        'central_negative_current_columns':ref['central_negative_current_columns'],
        'negative_current_lower_bound_columns':negative_bounds,'left_display_clip_columns':left_count,
        'thin_run_endpoint_candidates':thin_count,'retained_time_support_ns':ref['retained_time_support_ns'],
        'excluded_nonempty_cap_columns':ref['missing_terminal_cap_columns']})
assert total_cells==8800
result={'schema':'mitl-independent-simulation-drive-readback-v1','all_checks_passed':True,
    'script_sha256':sha(Path(__file__)),'public_source_sha256':PUBLIC,
    'additional_artifact_sha256':other_pins,'native_inspection_sha256':sha(ROOT/'native-inspection.json'),
    'coordinate_reference_sha256':sha(ROOT/'coordinate-reference.json'),
    'selected_reference_sha256':sha(ROOT/'selected-reference.json'),
    'source_pdf_sha256':native['source_pdf_sha256'],'figures':2,'retained_columns':440,
    'excluded_columns':336,'native_columns_catalogued':776,'numeric_csv_cells_checked':8800,
    'tick_anchors_checked':22,'cases':cases,
    'maximum_absolute_cell_difference':{key:float(value) for key,value in max_difference.items()},
    'successful_producer_replays':0,'physical_clock_alignment_established':False,
    'physical_uncertainty_established':False,'original_simulation_input_recovered':False,
    'limits':['The two curves are reconstructed published legacy simulation insets, distinct from a measured current trace or a recovered simulation input array.',
        'All776 candidate columns are accounted for;440 source columns are retained and336 are excluded without padding. The40ns one-pixel cap remains explicitly excluded.',
        'Negative source display times and negative lower current readout envelopes are preserved; the left-clipped curve start is not an onset.',
        'Every numeric CSV cell is checked against exact-rational native reference with12-significant-digit and separately quantified arithmetic conversion bounds.',
        'Pixel/tick envelopes are correlated display bounds, not physical uncertainty, statistical compatibility, physical clock registration, a missing waveform tail or FLASH validation.']}
path=ROOT/'readback.json';path.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps({'output':str(path),'sha256':sha(path),'all_checks_passed':True,
    'retained_columns':440,'excluded_columns':336,'numeric_csv_cells_checked':8800},indent=2))
