"""Derive independent rational tick maps and exact-red native column runs."""
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path
from PIL import Image

ROOT=Path(__file__).resolve().parent

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def rational(value):
    return {'numerator':str(value.numerator),'denominator':str(value.denominator),'value':float(value)}

def runs(values):
    output=[]
    for value in values:
        if not output or value!=output[-1][-1]+1:
            output.append([value])
        else:
            output[-1].append(value)
    return output

def ols(x,y):
    n=len(x)
    m=(n*sum(a*b for a,b in zip(x,y))-sum(x)*sum(y))/(n*sum(a*a for a in x)-sum(x)**2)
    b=(sum(y)-m*sum(x))/n
    return m,b

native=json.loads((ROOT/'native-inspection.json').read_text())
results=[]
for entry in native['cases']:
    image=Image.open(ROOT/'source-local'/f"figure-{entry['figure']}-native.png").convert('RGB')
    assert hashlib.sha256(image.tobytes()).hexdigest()==entry['RGB_pixels_sha256']
    pixels=image.load()
    xticks=runs([x for x in range(90,478) if max(pixels[x,417])<80])
    yticks=runs([y for y in range(20,412) if max(pixels[84,y])<80])
    assert len(xticks)==5 and len(yticks)==6,(xticks,yticks)
    tx=[F(r[0]+r[-1],2) for r in xticks];ty=[F(20*i) for i in range(5)]
    ix=[F(r[0]+r[-1],2) for r in yticks];iy=[F(5-i,5) for i in range(6)]
    tm,tb=ols(tx,ty);im,ib=ols(ix,iy)
    columns=[]
    for x in range(90,478):
        ys=[y for y in range(19,413) if pixels[x,y]==(178,34,34)]
        rr=runs(ys)
        columns.append({'pixel_x':x,'runs_y_inclusive':[[r[0],r[-1]] for r in rr],
            'source_time_ns':rational(tm*x+tb),
            'center_current_MA':rational(im*F(ys[0]+ys[-1],2)+ib) if len(rr)==1 else None})
    results.append({'figure':entry['figure'],'RGB_pixels_sha256':entry['RGB_pixels_sha256'],
        'time_tick_runs_pixels':[[r[0],r[-1]] for r in xticks],
        'current_tick_runs_pixels':[[r[0],r[-1]] for r in yticks],
        'time_tick_centers':[rational(x) for x in tx],'time_tick_values_ns':[rational(x) for x in ty],
        'current_tick_centers':[rational(x) for x in ix],'current_tick_values_MA':[rational(x) for x in iy],
        'time_slope_ns_per_pixel':rational(tm),'time_intercept_ns':rational(tb),
        'current_slope_MA_per_pixel':rational(im),'current_intercept_MA':rational(ib),
        'time_tick_residuals_ns':[rational(tm*x+tb-y) for x,y in zip(tx,ty)],
        'current_tick_residuals_MA':[rational(im*x+ib-y) for x,y in zip(ix,iy)],
        'column_scan_ROI':{'x_inclusive':[90,477],'y_inclusive':[19,412]},'columns':columns})
out={'schema':'mitl-independent-simulation-drive-coordinate-reference-v1',
    'native_inspection_sha256':sha(ROOT/'native-inspection.json'),'script_sha256':sha(Path(__file__)),
    'source_pdf_sha256':native['source_pdf_sha256'],'cases':results,
    'limits':['All exact-red columns are catalogued before any author-selected support is applied.',
        'Negative source plot times are retained by the map; no inferred current onset, trigger, simulation time registration or missing tail is supplied.',
        'Raster stroke envelopes are correlated display bounds, not physical uncertainties or independent samples.']}
path=ROOT/'coordinate-reference.json';path.write_text(json.dumps(out,indent=2,allow_nan=False)+'\n')
print(json.dumps({'output':str(path),'sha256':sha(path),'case_axes':[{k:v for k,v in c.items() if k not in ['columns']} for c in results]},indent=2))
