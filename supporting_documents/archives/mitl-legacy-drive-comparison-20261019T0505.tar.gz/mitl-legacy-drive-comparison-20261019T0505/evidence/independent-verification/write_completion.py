"""Freeze completed native-drive verification without repeating passing checks."""
import datetime
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
WORK=ROOT.parent
REPO=Path('/workspace/Power-Flow')
READBACK_SHA='35ac1278f727029d48380ca155d34333586967dd91360bf88d4d258abfa66d3b'
GUARDS_SHA='6da979b056e6c03983f42490e64acdeb8feddfb681e60d0600222457a0ec8e26'
LABELS=('independent-simulation-drive-native-inspection',
    'independent-simulation-drive-coordinate-reference','independent-simulation-drive-selected-reference',
    'independent-simulation-drive-final-readback','independent-simulation-drive-new-source-guards')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def load(path):
    return json.loads(path.read_text())

assert not (ROOT/'completion.json').exists()
assert sha(ROOT/'readback.json')==READBACK_SHA
assert sha(ROOT/'source-guards.json')==GUARDS_SHA
readback=load(ROOT/'readback.json');guards=load(ROOT/'source-guards.json')
assert readback['all_checks_passed'] is True and guards['all_checks_passed'] is True
counts={'figures':2,'retained_columns':440,'excluded_columns':336,
    'native_columns_catalogued':776,'numeric_csv_cells_checked':8800,'tick_anchors_checked':22}
assert all(readback[key]==value for key,value in counts.items())
assert readback['successful_producer_replays']==guards['successful_producer_replays']==0
assert readback['physical_clock_alignment_established'] is False
assert readback['physical_uncertainty_established'] is False
assert readback['original_simulation_input_recovered'] is False
assert guards['source_guard_rejections']==4 and guards['guarded_recovery_entry_attempts']==2
assert guards['native_row_extraction_calls_by_invalid_source_controls']==0
assert guards['positive_producer_called_for_verification'] is False
assert guards['old_recovery_or_suite_repeated'] is False
assert len(guards['source_guard_controls'])==4 and all(row['rejected'] is True for row in guards['source_guard_controls'])
assert guards['public_source_sha256']==readback['public_source_sha256']
for name,digest in readback['public_source_sha256'].items():
    assert sha(REPO/name)==digest
for name,digest in readback['additional_artifact_sha256'].items():
    assert sha(Path(name))==digest
assert sha(Path('/workspace/research_sources/smtrevor_1.pdf'))==readback['source_pdf_sha256']==guards['source_pdf_sha256']
assert sum(case['negative_time_columns'] for case in readback['cases'])==22
assert sum(case['negative_current_lower_bound_columns'] for case in readback['cases'])==60
assert sum(case['left_display_clip_columns'] for case in readback['cases'])==2
assert sum(len(case['excluded_nonempty_cap_columns']) for case in readback['cases'])==1
commands=[json.loads(line) for line in (WORK/'commands.jsonl').read_text().splitlines()]
selected=[]
for label in LABELS:
    matches=[entry for entry in commands if Path(entry['log']).name==label+'.log']
    assert len(matches)==1
    entry=matches[0]
    assert entry['exit_code']==0 and sha(Path(entry['log']))==entry['log_sha256']
    selected.append(entry)
artifacts={str(path.relative_to(WORK)):sha(path) for path in sorted(ROOT.iterdir()) if path.is_file()}
for command in selected:
    artifacts[Path(command['log']).name]=command['log_sha256']
result={'schema':'mitl-independent-simulation-drive-completion-v1','status':'passed',
    'all_checks_passed':True,'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'public_source_sha256':readback['public_source_sha256'],'artifact_sha256':artifacts,
    'source_pdf_sha256':readback['source_pdf_sha256'],
    'source_kind':'reconstructed_published_legacy_simulation_raster',**counts,
    'negative_time_columns':22,'negative_current_lower_bound_columns':60,
    'left_display_clip_columns':2,'excluded_single_pixel_cap_columns':1,
    'source_guard_rejections':4,'guarded_recovery_entry_attempts':2,
    'successful_producer_replays':0,'native_row_extraction_calls_by_invalid_source_controls':0,
    'positive_producer_called_for_verification':False,'old_suites_repeated':False,
    'old_recoveries_repeated':False,'portable_test_execution_claimed':False,
    'signed_display_times_preserved':True,'negative_readout_bounds_preserved':True,
    'legacy_simulation_source':True,'physical_clock_alignment_established':False,
    'physical_uncertainty_established':False,'original_simulation_input_recovered':False,
    'original_simulation_input_normalization_verified':False,'FLASH_output':False,
    'readback_sha256':READBACK_SHA,'source_guards_sha256':GUARDS_SHA,
    'cases':readback['cases'],'source_guard_controls':guards['source_guard_controls'],
    'commands':selected,'archive_excluded_paths':['independent-verification/source-local/'],
    'next_use':'Compare literal published coordinates only on finite common support; preserve separate source identities and unregistered clocks.',
    'limits':['The two insets are published legacy Allegra simulation context. They are distinct from a measured current trace, recovered original input deck or FLASH output.',
        'Independent native image identity, dark tick tails and exact rational calibration check every retained/excluded source column and all8800 numeric CSV cells, including12-significant-digit and arithmetic conversion bounds.',
        'Negative display times and lower current envelopes remain signed. The left source support is clipped, and the40ns single-pixel terminal cap is catalogued but excluded. No zero, onset, tail or snapshot endpoint is inserted.',
        'Full-run/readout/tick-fit envelopes are correlated display bounds, not physical uncertainty or independent experimental noise. Readout envelopes do not extend central observed source support.',
        'Two intentionally invalid recovery-entry attempts reject before native row extraction. Pure altered-tick and manufactured multi-run controls also reject; no positive producer replay or recovered output is supplied by these controls.',
        'Literal ns/MA conversion preserves source plot coordinates and does not authenticate original simulation normalization, register source clocks, repair a drive, infer heating or establish physical agreement.',
        'No old recovery, passing suite, source evolution, kinetic model, spectrum, external job or actual FLASH run was repeated.']}
target=ROOT/'completion.json';target.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps({'completion':str(target),'sha256':sha(target),'all_checks_passed':True,
    **counts,'source_guard_rejections':4,'successful_producer_replays':0},indent=2))
