"""Freeze independent native-column selection and displayed-value references."""
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def f(record):
    return F(int(record['numerator']),int(record['denominator']))

def rational(value):
    return {'numerator':str(value.numerator),'denominator':str(value.denominator)}

assert not (ROOT/'selected-reference.json').exists()
reference=json.loads((ROOT/'coordinate-reference.json').read_text())
cases=[]
for case in reference['cases']:
    tm=f(case['time_slope_ns_per_pixel']);tb=f(case['time_intercept_ns'])
    im=f(case['current_slope_MA_per_pixel']);ib=f(case['current_intercept_MA'])
    tr=max(abs(f(r)) for r in case['time_tick_residuals_ns'])
    ir=max(abs(f(r)) for r in case['current_tick_residuals_MA'])
    retained=[];excluded=[]
    for column in case['columns']:
        x=column['pixel_x'];runs=column['runs_y_inclusive']
        if not runs:
            reason='no_exact_colour_run'
        elif len(runs)!=1:
            reason='multiple_exact_colour_runs'
        elif not 2<=runs[0][1]-runs[0][0]+1<=8:
            reason='run_width_outside_2_to_8_pixels'
        else:
            reason='retained'
        raw={'pixel_x':x,'exact_colour_runs_inclusive_y':runs,'reason':reason}
        if reason!='retained':
            excluded.append(raw)
            continue
        first,last=runs[0];median=F(first+last,2)
        time=tm*x+tb;tlo=tm*(x-2)+tb-tr;thi=tm*(x+2)+tb+tr
        current=im*median+ib;ilo=im*(last+2)+ib-ir;ihi=im*(first-2)+ib+ir
        exact={'pixel_x':F(x),'pixel_y_median':median,'run_first_pixel_y':F(first),
            'run_last_pixel_y':F(last),'matched_color_pixels':F(last-first+1),
            'time_ns':time,'time_s':time/F(10**9),'time_readout_lower_ns':tlo,
            'time_readout_upper_ns':thi,'time_readout_lower_s':tlo/F(10**9),
            'time_readout_upper_s':thi/F(10**9),'current_MA':current,
            'current_A':current*10**6,'current_readout_lower_MA':ilo,
            'current_readout_upper_MA':ihi,'current_readout_lower_A':ilo*10**6,
            'current_readout_upper_A':ihi*10**6}
        t=float(tm)*x+float(tb);tl=float(tm)*(x-2)+float(tb)-float(tr);th=float(tm)*(x+2)+float(tb)+float(tr)
        i=float(im)*float(median)+float(ib);il=float(im)*(last+2)+float(ib)-float(ir);ih=float(im)*(first-2)+float(ib)+float(ir)
        arithmetic={key:float(value) for key,value in exact.items()}
        arithmetic.update({'time_ns':t,'time_s':t*1e-9,'time_readout_lower_ns':tl,
            'time_readout_upper_ns':th,'time_readout_lower_s':tl*1e-9,'time_readout_upper_s':th*1e-9,
            'current_MA':i,'current_A':i*1e6,'current_readout_lower_MA':il,'current_readout_upper_MA':ih,
            'current_readout_lower_A':il*1e6,'current_readout_upper_A':ih*1e6})
        assert tlo<time<thi and ilo<current<ihi
        retained.append({**raw,'exact_values':{key:rational(value) for key,value in exact.items()},
            'arithmetic_values':arithmetic,'left_clipped_source_support':x==90})
    expected_count=178 if case['figure']=='4.28' else 262
    assert len(retained)==expected_count and len(excluded)==388-expected_count
    assert [row['pixel_x'] for row in retained]==list(range(90,90+expected_count))
    cases.append({'figure':case['figure'],'RGB_pixels_sha256':case['RGB_pixels_sha256'],
        'retained':retained,'excluded':excluded,'retained_count':len(retained),'excluded_count':len(excluded),
        'central_negative_current_columns':sum(f(row['exact_values']['current_MA'])<0 for row in retained),
        'negative_time_columns':sum(f(row['exact_values']['time_ns'])<0 for row in retained),
        'retained_time_support_ns':[float(f(retained[0]['exact_values']['time_ns'])),float(f(retained[-1]['exact_values']['time_ns']))],
        'clipped_left_source_support':True,
        'missing_terminal_cap_columns':[row['pixel_x'] for row in excluded if row['exact_colour_runs_inclusive_y']]})
out={'schema':'mitl-independent-simulation-drive-selected-reference-v1',
    'coordinate_reference_sha256':sha(ROOT/'coordinate-reference.json'),'script_sha256':sha(Path(__file__)),
    'cases':cases,'total_retained_columns':440,'total_excluded_columns':336,'native_columns_catalogued':776,
    'limits':['The one-pixel40ns terminal cap is catalogued but excluded by the declared2–8pixel support rule.',
        'The first native support column is clipped by the left displayed panel. Negative source times and fitted signed current values are preserved without an onset or zero constraint.',
        'All values and full-run+2pixel+tick-fit bounds are display references only; no physical uncertainty or clock registration is established.']}
path=ROOT/'selected-reference.json';path.write_text(json.dumps(out,indent=2,allow_nan=False)+'\n')
print(json.dumps({'output':str(path),'sha256':sha(path),'cases':[{key:case[key] for key in case if key not in ['retained','excluded']} for case in cases]},indent=2))
