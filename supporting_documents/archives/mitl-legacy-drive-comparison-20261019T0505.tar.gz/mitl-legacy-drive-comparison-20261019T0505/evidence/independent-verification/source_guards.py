"""New invalid-source controls for the new simulation-drive recovery only."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import numpy as np
from PIL import Image

ROOT=Path(__file__).resolve().parent
REPO=Path('/workspace/Power-Flow')
PDF=Path('/workspace/research_sources/smtrevor_1.pdf')
TOOL=REPO/'tools/recover_dissertation_simulation_drive.py'
PIN='d529b7ef7f2765712d3dc611f783ed4afd4476c71cd263358b1660e8040a9e14'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

assert not (ROOT/'source-guards.json').exists()
assert sha(TOOL)==PIN
readback=json.loads((ROOT/'readback.json').read_text())
assert readback['all_checks_passed'] is True
for name,digest in readback['public_source_sha256'].items():
    assert sha(REPO/name)==digest
spec=importlib.util.spec_from_file_location('new_simulation_drive_source_controls',TOOL)
recovery=importlib.util.module_from_spec(spec);spec.loader.exec_module(recovery)
calls=0
original_make_rows=recovery.make_rows
controls=[]

def forbid_rows(*args,**kwargs):
    global calls
    calls+=1
    raise AssertionError('Invalid source reached native row extraction')

def rejected(label,call,fragment):
    try:
        call()
    except ValueError as error:
        assert fragment in str(error),(label,str(error))
        controls.append({'case':label,'rejected':True,'reason':str(error)})
    else:
        raise AssertionError('Invalid source accepted: '+label)

wrong=ROOT/'wrong-source-control.pdf'
assert not wrong.exists()
wrong.write_bytes(b'%PDF-1.0\nDeliberately invalid simulation-source guard fixture.\n')
recovery.make_rows=forbid_rows
try:
    rejected('wrong_pdf_pin',lambda:recovery.recover(wrong),'source PDF SHA256 mismatch')
    saved=recovery.FIGURES
    recovery.FIGURES=copy.deepcopy(saved)
    recovery.FIGURES[0]['rgb_sha256']='0'*64
    try:
        rejected('wrong_native_RGB_pin',lambda:recovery.recover(PDF),'native source RGB SHA256 mismatch')
    finally:
        recovery.FIGURES=saved
finally:
    recovery.make_rows=original_make_rows
assert calls==0
image=Image.open(ROOT/'source-local/figure-4.28-native.png').convert('RGB')
assert hashlib.sha256(image.tobytes()).hexdigest()==recovery.FIGURES[0]['rgb_sha256']
saved_ticks=recovery.TIME_TICK_PIXELS
recovery.TIME_TICK_PIXELS=(saved_ticks[0]+1,*saved_ticks[1:])
try:
    rejected('wrong_native_time_tick_anchor',lambda:recovery.validate_ticks(np.asarray(image)),
             'native time tick anchors do not match configured calibration')
finally:
    recovery.TIME_TICK_PIXELS=saved_ticks
manufactured=np.full((412,478,3),255,dtype=np.uint8)
manufactured[200:203,200]=recovery.SOURCE_RGB
manufactured[300:303,200]=recovery.SOURCE_RGB
selected,reason,runs=recovery.select_column(manufactured,200)
assert selected is None and reason=='multiple_exact_colour_runs' and runs==[[200,202],[300,302]]
controls.append({'case':'synthetic_multiple_exact_colour_runs','rejected':True,'reason':reason,
    'exact_colour_runs_inclusive_y':runs,'fixture_status':'manufactured_selector_failure_control'})
assert len(controls)==4 and all(item['rejected'] for item in controls)
for name,digest in readback['public_source_sha256'].items():
    assert sha(REPO/name)==digest
result={'schema':'mitl-simulation-drive-new-source-guards-v1','all_checks_passed':True,
    'script_sha256':sha(Path(__file__)),'public_source_sha256':readback['public_source_sha256'],
    'readback_sha256':sha(ROOT/'readback.json'),'source_pdf_sha256':sha(PDF),
    'wrong_source_control_sha256':sha(wrong),'source_guard_rejections':4,
    'guarded_recovery_entry_attempts':2,'successful_producer_replays':0,
    'native_row_extraction_calls_by_invalid_source_controls':calls,
    'source_guard_controls':controls,'positive_producer_called_for_verification':False,
    'old_recovery_or_suite_repeated':False,
    'limits':['Only the new recovery entry and its new pure tick/column selectors are used.',
        'Two deliberately invalid recovery attempts reject before source-column extraction and return no recovered curve; declared calibration arithmetic may occur before image validation.',
        'Wrong native tick declarations and manufactured ambiguous-color pixels are rejected by pure selectors without running a positive producer.',
        'Process-local declaration changes are restored, and public files remain byte-identical. No source dataset or physical model is repaired.']}
out=ROOT/'source-guards.json';out.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps({'output':str(out),'sha256':sha(out),'all_checks_passed':True,
    'source_guard_rejections':4,'successful_producer_replays':0},indent=2))
