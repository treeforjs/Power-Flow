"""Commit only frozen, source-verified current-inset recovery files."""
import hashlib
import json
from pathlib import Path
import subprocess

repo = Path('/workspace/Power-Flow')
work = Path(__file__).resolve().parent
def run(*args):
    print(json.dumps(list(args)),flush=True)
    subprocess.run(args,cwd=repo,check=True)
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip() == '65638571ddfa3a887f610021dec58bdbafee54d0'
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=repo,text=True)
assert sha(work/'independent-verification/completion.json') == '0328fc8815b668002deada9101b41f15becda88d15e45104bf504b5d271f73f2'
assert json.loads((work/'independent-verification/completion.json').read_text())['all_checks_passed'] is True
paths = ['tools/recover_dissertation_simulation_drive.py']
for fig in ('4_28','4_29'):
    stem = 'figure_'+fig+'_simulation_drive'
    metadata = repo/'data/dissertation'/f'{stem}.json'
    m = json.loads(metadata.read_text())
    assert sha(repo/m['output']['generator']) == m['output']['generator_sha256']
    assert sha(repo/'data/dissertation'/m['output']['csv_filename']) == m['output']['csv_sha256']
    paths += [f'data/dissertation/{stem}.csv',f'data/dissertation/{stem}.json']
assert sha(repo/paths[0]) == 'd529b7ef7f2765712d3dc611f783ed4afd4476c71cd263358b1660e8040a9e14'
assert not any(line.rstrip()!=line for line in (repo/paths[0]).read_text().splitlines())
run('git','add','--',*paths)
run('git','diff','--cached','--check')
run('git','-c','user.name=Research Development','-c','user.email=research@local.invalid','commit','-m','Recover finite legacy simulation-current insets from published figures')
run('git','show','--format=fuller','--stat','HEAD')
