"""Complete the bounded legacy-drive display recovery after verified delivery.

Draft only: a root-approved final commit is required before execution. Existing
files/records and actual archive bytes are read; no recovery, comparison,
acquisition, inspector, test or numerical producer runs here.
"""
import csv
import datetime
import fcntl
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import subprocess
import tarfile

WORK = Path(__file__).resolve().parent
REPO = Path('/workspace/Power-Flow')
OUT = Path('/workspace/handoffs/mitl-legacy-drive-comparison-20261019T0505')
BASE = '65638571ddfa3a887f610021dec58bdbafee54d0'
EXPECTED_HEAD = 'b27b04fb38238c831e12bf2f3cdfe945e5834d58'
PDF_SHA = '1d7b1f9c191a37e94f1cc3634587750f1af35b07eb13e0b94c60f3da47495ed7'
PRODUCER = 'tools/recover_dissertation_simulation_drive.py'
PINNED = {
    PRODUCER: 'd529b7ef7f2765712d3dc611f783ed4afd4476c71cd263358b1660e8040a9e14',
    'data/dissertation/figure_4_28_simulation_drive.csv': '7d40eeb991f289c18e107c0423cfa366b78af8e9fe943aa823d11a8b23fd6a3c',
    'data/dissertation/figure_4_28_simulation_drive.json': '4109109058df6ec6e20d6efdbe36ec9535a38c41f7e8948630e9a631ae35c61b',
    'data/dissertation/figure_4_29_simulation_drive.csv': 'b5b8ffab25d3efd5058a433c1e66aaff85314b5c2d0edffad558c464c74a92ef',
    'data/dissertation/figure_4_29_simulation_drive.json': '776eaaf83a56ed693d4826be58134ed60465513351c4c91cb3689036d88945ff',
}
PUBLIC = set(PINNED)|{'data/dissertation/recovery_manifest.yaml', 'docs/dissertation_recovery.md',
    'docs/legacy_simulation_drive_recovery.md', 'docs/dissertation_current_depth_recovery.md'}
AUTHOR_SHA = '17f75ffc87d6ba29405e3915602f4ae9c2dadf7afe909f50e75bdf2ca252e62f'
INDEPENDENT_SHA = '0328fc8815b668002deada9101b41f15becda88d15e45104bf504b5d271f73f2'
INDEPENDENT_COUNTERS = {'figures': 2, 'retained_columns': 440, 'excluded_columns': 336,
    'native_columns_catalogued': 776, 'numeric_csv_cells_checked': 8800, 'tick_anchors_checked': 22,
    'negative_time_columns': 22, 'negative_current_lower_bound_columns': 60, 'left_display_clip_columns': 2,
    'excluded_single_pixel_cap_columns': 1, 'source_guard_rejections': 4, 'guarded_recovery_entry_attempts': 2,
    'successful_producer_replays': 0, 'native_row_extraction_calls_by_invalid_source_controls': 0}
SELECTION_SHA = '8f6dc7ec66a118f02360da34160c9f53b9350079d08dbce743d20bae28c7c338'
RECORD_PINS = {
    'author_verification': AUTHOR_SHA, 'independent_completion': INDEPENDENT_SHA,
    'comparison': 'a6b71d79349bb9021fb67f5101daaf01f9f03089ad04b418c04eb466576ddfba',
    'comparison_completion': '611bafad23ee9769232b6445eff981a38fb993f0fc122d7ae7a7eb923602c85f',
    'comparison_review': 'c81f6d84e9479c0bf297642522c4c449349fc0f4d82995958bdac67eccf80c51',
    'visual_review': 'cf437b3e4df6ec9cd503f0f1440b0414bdb9a3bf484be4d4c1a5975adcfbcd52',
    'documentation_association': '2817319819a86f4226c049a8e2d1eabc2e6b924d26208bbb57349d7e371c376b',
    'selection': SELECTION_SHA,
}


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024*1024), b''):
            digest.update(block)
    return digest.hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def clean_head():
    require(type(EXPECTED_HEAD) is str and re.fullmatch('[0-9a-f]{40}', EXPECTED_HEAD), 'root-approved final HEAD is still pending')
    require(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == EXPECTED_HEAD, 'final HEAD changed')
    require(not subprocess.check_output(['git', 'status', '--porcelain'], cwd=REPO, text=True).strip(), 'repository must be clean')
    require(subprocess.check_output(['git', 'branch', '--show-current'], cwd=REPO, text=True).strip() == 'research/flash-publication-foundation', 'unexpected branch')
    subprocess.run(['git', 'merge-base', '--is-ancestor', BASE, EXPECTED_HEAD], cwd=REPO, check=True)
    require(subprocess.check_output(['git', 'rev-list', '--count', BASE+'..'+EXPECTED_HEAD], cwd=REPO, text=True).strip() == '2', 'expected two bounded local commits')
    require(set(subprocess.check_output(['git', 'diff', '--name-only', BASE, EXPECTED_HEAD], cwd=REPO, text=True).splitlines()) == PUBLIC, 'committed public scope changed')


def relative(name):
    path = PurePosixPath(name)
    require(type(name) is str and name and not path.is_absolute() and '..' not in path.parts and str(path) == name, 'unsafe relative artifact path')
    return path


def verify_archive(delivery, frozen, verification):
    require(delivery['status'] == 'passed' and delivery['repository_clean'] is True
            and delivery['input_code_output_bindings_verified'] is True and delivery['unsafe_or_duplicate_members'] == 0, 'delivery has not passed')
    for key in ('folder', 'archive', 'sha256', 'bytes', 'source_commit', 'base_commit', 'manifest_sha256', 'verification_sha256'):
        require(delivery[key] == frozen[key], 'delivery/freeze disagreement: '+key)
    require(delivery['folder'] == str(OUT) and delivery['source_commit'] == verification['source_commit'] == EXPECTED_HEAD
            and delivery['base_commit'] == verification['base_commit'] == BASE, 'delivery identity changed')
    require(verification['schema'] == 'mitl-legacy-drive-comparison-verification-v1', 'unexpected verification schema')
    clean_head()
    archive = Path(delivery['archive'])
    require(archive == OUT.with_suffix('.tar.gz') and sha(archive) == delivery['sha256'] and archive.stat().st_size == delivery['bytes'], 'actual archive pin changed')
    allowed_figures = {'evidence/'+str(relative(name)) for name in verification['allowed_figure_paths']}
    hashes, seen = {}, set()
    with tarfile.open(archive, 'r:gz') as stream:
        for member in stream:
            path = PurePosixPath(member.name)
            require(not path.is_absolute() and '..' not in path.parts and path.parts and path.parts[0] == OUT.name, 'unsafe archive member')
            require(member.name not in seen and not member.issym() and not member.islnk(), 'duplicate/linked archive member')
            seen.add(member.name)
            if member.isdir():
                continue
            require(member.isfile() and len(path.parts) > 1, 'nonregular archive payload')
            name = str(PurePosixPath(*path.parts[1:]))
            require(name not in hashes, 'duplicate normalized archive member')
            parts = relative(name).parts
            require(not any(part in {'source-local', 'fulltexts', 'raw-fulltexts', '__pycache__', '.venv', '.pytest_cache'} for part in parts)
                    and PurePosixPath(name).name != 'smtrevor_1.pdf', 'excluded original/prospective source included')
            require(PurePosixPath(name).suffix.lower() not in {'.pdf', '.png', '.jpg', '.jpeg', '.tif', '.tiff'} or name in allowed_figures, 'unlisted raw image/page included')
            digest = hashlib.sha256()
            with stream.extractfile(member) as payload:
                for block in iter(lambda: payload.read(1024*1024), b''):
                    digest.update(block)
            hashes[name] = digest.hexdigest()
            require(hashes[name] != PDF_SHA and (OUT/name).is_file() and not (OUT/name).is_symlink()
                    and sha(OUT/name) == hashes[name], 'archive/folder bytes differ: '+name)
    manifest = load(OUT/'manifest.sha256.json')
    require(set(hashes) == set(manifest)|{'manifest.sha256.json'} and all(hashes[name] == digest for name, digest in manifest.items()), 'actual archive manifest mismatch')
    require(sha(OUT/'manifest.sha256.json') == delivery['manifest_sha256'] and sha(OUT/'verification.json') == delivery['verification_sha256'], 'manifest/verification hash changed')
    require(len(manifest) == delivery['manifest_entries'] and len(hashes) == delivery['actual_archive_regular_files'], 'archive member count changed')
    listing = load(OUT/'source_file_list.json')
    require(len(listing['byte_identical_public_files']) == 9 and set(listing['byte_identical_public_files']) == PUBLIC
            and listing['packaging_wrappers'] == ['README.md', 'requirements.txt'], 'public/wrapper listing changed')
    require({name[7:] for name in hashes if name.startswith('source/')} == PUBLIC|{'README.md', 'requirements.txt'}, 'unlisted public source payload')
    public_pins = {}
    for name in PUBLIC:
        digest = hashlib.sha256(subprocess.check_output(['git', 'show', EXPECTED_HEAD+':'+name], cwd=REPO)).hexdigest()
        require(hashes['source/'+name] == sha(REPO/name) == digest, 'archive/repository/commit source differs: '+name)
        public_pins[name] = digest
    inventory = [line.split('  ', 1) for line in (OUT/'source-files.sha256').read_text().splitlines()]
    require(len(inventory) == 9 and {name: digest for digest, name in inventory} == public_pins, 'public source inventory differs')
    require(delivery['public_files_byte_identical'] == 9 and delivery['packaging_wrappers'] == 2, 'source scope changed')
    require(delivery['retained_rows_verified'] == 440, 'delivery row count changed')
    for key in ('source_pdf_included', 'raw_source_images_or_pages_included', 'source_recovery_or_comparison_reexecuted', 'portable_execution_performed'):
        require(delivery[key] is False, 'unsupported delivery claim: '+key)
    return public_pins


def verify_maps(record):
    for name, digest in record.get('public_source_sha256', {}).items():
        require(sha(REPO/name) == digest, 'record public source changed: '+name)
    for key in ('artifact_sha256', 'input_files_sha256'):
        for name, digest in record.get(key, {}).items():
            require(sha(Path(name) if Path(name).is_absolute() else WORK/name) == digest, 'record artifact/input changed: '+name)


def verify_records(verification):
    paths = verification['record_paths']
    require(set(paths) == set(RECORD_PINS), 'saved report roles changed')
    records = {}
    for key, name in paths.items():
        relative(name)
        require(sha(WORK/name) == verification['record_sha256'][key] == RECORD_PINS[key], 'saved record pin changed: '+key)
        record = load(WORK/name)
        require(record == verification['records'][key], 'saved record declaration differs: '+key)
        records[key] = record
    author = records['author_verification']
    require(verification['record_sha256']['author_verification'] == AUTHOR_SHA and author['complete'] is True
            and author['new_producer_run_count'] == 1 and author['public_source_sha256'] == PINNED[PRODUCER]
            and author['total_samples'] == 440 and author['total_excluded_columns'] == 336
            and author['total_catalogued_columns'] == 776, 'author run/inventory changed')
    command = author['new_producer_command']
    require(command['exit_code'] == 0 and sha(command['log']) == command['log_sha256'], 'recorded author command changed')
    for name, digest in PINNED.items():
        require(sha(REPO/name) == digest, 'frozen producer/data changed: '+name)
    datasets = verification['datasets']
    require(len(datasets) == 2 and [item['figure'] for item in datasets] == ['4.28', '4.29'], 'dataset associations changed')
    for dataset, figure in zip(datasets, author['figures']):
        metadata = load(REPO/dataset['metadata_path'])
        output, context = metadata['output'], metadata['simulation_context']
        with (REPO/dataset['csv_path']).open(newline='') as stream:
            reader = csv.DictReader(stream)
            rows = list(reader)
        require(len(rows) == output['samples'] == dataset['samples'] == figure['samples']
                and reader.fieldnames == output['columns'] == dataset['columns'], 'saved row/column association differs')
        require(dataset['csv_sha256'] == output['csv_sha256'] == PINNED[dataset['csv_path']]
                and dataset['metadata_sha256'] == PINNED[dataset['metadata_path']]
                and output['generator_sha256'] == dataset['producer_sha256'] == PINNED[PRODUCER], 'saved producer/data association differs')
        require(metadata['source']['pdf_sha256'] == PDF_SHA and context['code_label_in_dissertation'] == 'Allegra'
                and context['drive_shot_caption_label'] == 17133 and metadata['selection']['left_display_support_clipped'] is True, 'legacy source identity/support differs')
        for key in ('experimental_measurement', 'FLASH_result', 'original_simulation_input_array_recovered', 'experimental_clock_alignment_established',
                    'time_shift_or_scale_fit_applied', 'current_repair_or_normalization_applied', 'VUV_gate_recovered', 'snapshot_is_observed_waveform_end'):
            require(context[key] is False, 'unsupported legacy source claim: '+key)
        require(metadata['unit_interpretation']['negative_display_times_preserved'] is True
                and metadata['unit_interpretation']['readout_bounds_clipped_to_nonnegative_current'] is False
                and metadata['readout_bounds']['physical_or_simulation_uncertainty_quantified'] is False, 'display limits changed')
        require(sum(float(row['time_ns']) < 0 for row in rows) == 11
                and sum(float(row['current_readout_lower_MA']) < 0 for row in rows) == 30, 'signed source support/readout changed')
        require(sha(WORK/'recovery'/output['source_geometry_filename']) == output['source_geometry_sha256'], 'source geometry changed')
        for name, digest in output['QA_files_sha256'].items():
            require(sha(WORK/'recovery'/name) == digest, 'QA artifact changed')
    independent = records['independent_completion']
    require(independent['schema'] == 'mitl-independent-simulation-drive-completion-v1'
            and independent['all_checks_passed'] is True and independent['status'] == 'passed'
            and verification['record_sha256']['independent_completion'] == INDEPENDENT_SHA, 'independent completion has not passed or changed')
    for key, expected in INDEPENDENT_COUNTERS.items():
        require(type(independent[key]) is int and independent[key] == expected
                and type(verification['results'][key]) is int and verification['results'][key] == expected, 'independent/delivery counter changed: '+key)
    require(independent['signed_display_times_preserved'] is True and independent['negative_readout_bounds_preserved'] is True
            and independent['legacy_simulation_source'] is True and independent['source_pdf_sha256'] == PDF_SHA, 'independent signed/source declarations changed')
    for key in ('positive_producer_called_for_verification', 'old_suites_repeated', 'old_recoveries_repeated', 'portable_test_execution_claimed',
                'physical_clock_alignment_established', 'physical_uncertainty_established', 'original_simulation_input_recovered',
                'original_simulation_input_normalization_verified', 'FLASH_output'):
        require(independent[key] is False, 'unsupported independent claim: '+key)
    verify_maps(independent)
    require(sha(WORK/'independent-verification/readback.json') == independent['readback_sha256']
            and sha(WORK/'independent-verification/source-guards.json') == independent['source_guards_sha256'], 'independent readback/guard pins changed')
    comparison = records['comparison']
    require(comparison['schema'] == 'mhdlab-finite-support-published-drive-comparison-v1'
            and comparison['status'] == 'completed_display_comparison_only', 'finite comparison is incomplete')
    verify_maps(comparison)
    qualifications = comparison['qualifications']
    for key in ('finite_support_only', 'whole_horizontal_readout_windows_required', 'finite_query_readout_only', 'continuous_central_PL_extrema'):
        require(qualifications[key] is True, 'comparison scope changed: '+key)
    for key in ('readout_bounds_physical_or_certified', 'physical_trigger_or_clock_registration', 'offset_amplitude_timewarp_fit',
                'statistical_error_or_chi_squared', 'raw_waveform_or_exact_solver_input_recovered', 'source_or_recovery_producer_repeated', 'host_or_physics_acceptance'):
        require(qualifications[key] is False, 'unsupported comparison claim: '+key)
    for item in comparison['input_associations']:
        require(sha(item['original_path']) == sha(WORK/item['copy_path']) == item['sha256'], 'comparison original/copied input changed')
    completion = records['comparison_completion']
    require(completion['schema'] == 'mhdlab-published-drive-comparison-completion-v1' and completion['status'] == 'passed'
            and completion['report_sha256'] == RECORD_PINS['comparison'] and completion['script_sha256'] == comparison['script_sha256']
            and completion['actual_comparison_run_count'] == 1 and completion['open_substantive_findings'] == [], 'comparison completion changed')
    verify_maps(completion)
    run = completion['comparison_run']
    require(run['exit_code'] == 0 and sha(run['log']) == run['log_sha256'], 'recorded single comparison run changed')
    for key in ('source_and_recovery_producer_repeated', 'old_tests_or_source_evolution_repeated',
                'physical_clock_alignment_or_input_identity_established', 'continuous_or_joint_readout_compatibility_established',
                'fitting_or_repair_applied', 'statistical_covariance_or_significance_inferred', 'readout_bounds_physical_or_certified'):
        require(completion[key] is False, 'unsupported comparison completion claim: '+key)
    review = records['comparison_review']
    require(review['schema'] == 'mhdlab-published-drive-comparison-review-v1' and review['status'] == 'passed_read_only_code_and_claims_review'
            and review['complete'] is True and review['open_findings'] == [] and review['summary_sha256'] == RECORD_PINS['comparison']
            and review['code_sha256'] == comparison['script_sha256'], 'comparison review changed')
    for name, digest in {**review['supporting_pins'], **review['evidence_logs']}.items():
        require(sha(WORK/name) == digest, 'comparison review evidence changed')
    for key in ('comparison_reexecuted', 'native_recovery_reexecuted', 'public_or_comparison_files_modified'):
        require(review[key] is False, 'unexpected review execution/edit')
    visual = records['visual_review']
    require(visual['numerical_recovery_or_comparison_reexecuted'] is False, 'unexpected visual review execution')
    for name, digest in visual['reviewed'].items():
        require(sha(WORK/name) == digest, 'visually reviewed artifact changed')
    docs = records['documentation_association']
    require(docs['schema'] == 'mitl-simulation-drive-documentation-association-v1'
            and docs['passed'] is True and docs['all_prior_artifacts_preserved'] is True and docs['source_record_unchanged'] is True
            and docs['prior_manifest_targets'] == 45 and docs['numerical_recovery_comparison_or_old_suite_reexecuted'] is False
            and docs['comparison_report_sha256'] == verification['record_sha256']['comparison'], 'documentation binding incomplete')
    for name, digest in docs['public_sha256'].items():
        require(sha(REPO/name) == digest, 'documentation association changed')
    require(sha(WORK/paths['selection']) == SELECTION_SHA and records['selection']['status'] == 'selected_manufactured_reference', 'next selection changed')
    results = verification['results']
    require(results['independent_readback_passed'] is True and results['comparison_pairs'] == 3
            and results['difference_csv_rows'] == comparison['difference_csv_rows'] == 1179
            and results['negative_display_time_columns_preserved'] == 22 and results['actual_comparison_run_count'] == 1
            and results['comparison_read_only_review_passed'] is True and results['comparison_png_visually_inspected'] is True, 'delivery result counts changed')
    for key in ('display_clock_alignment_established', 'physical_readout_uncertainty_established', 'host_or_physics_acceptance',
                'portable_executions_performed', 'packaging_source_recovery_repeated', 'packaging_comparison_repeated',
                'old_recoveries_repeated', 'old_test_suites_repeated', 'full_source_pdf_included', 'raw_source_images_or_pages_included',
                'continuous_or_joint_readout_compatibility_established'):
        require(results[key] is False, 'unsupported result claim: '+key)
    require(not any('test' in key and key != 'old_test_suites_repeated' for key in results), 'this recovery pass has no test count claim')
    return records, datasets


def main():
    status_path = WORK.parent/'mitl-upstream-status.json'
    with (WORK.parent/'mitl-upstream-status.lock').open('a+') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        before = status_path.read_bytes()
        status, lease = json.loads(before), load(WORK/'lease.json')
        now = datetime.datetime.now(datetime.timezone.utc)
        require(status['active_lease_owner'] == lease['pass_id'] == WORK.name
                and datetime.datetime.fromisoformat(status['active_editing_lease_until_utc']) > now, 'lease changed or expired')
        require(status['last_complete_commit'] == lease['baseline_commit'] == BASE and status['handoff'] == lease['prior_handoff']
                and not (WORK/'completion.json').exists(), 'prior checkpoint changed or completion replay attempted')
        preserved = json.loads(json.dumps({key: status[key] for key in ('source_ledger_admission', 'reconstructed_current_17133', 'current_depth_recovery', 'constraints', 'blockers', 'source_desorption_acquisition')}))
        delivery, frozen, verification = load(WORK/'delivery_verification.json'), load(WORK/'frozen_delivery.json'), load(OUT/'verification.json')
        public_pins = verify_archive(delivery, frozen, verification)
        records, datasets = verify_records(verification)
        selection = records['selection']
        require(selection['public_files_edited'] is False and selection['network_used'] is False and selection['numerical_producer_or_model_executed'] is False, 'next reference proposal was executed or edited public files')
        for key, pin in (('proposal', 'proposal_sha256'), ('cached_new_primary_lead', 'cached_new_primary_lead_sha256')):
            require(sha(WORK/'next-upstream-selection'/selection[key]) == selection[pin], 'next proposal/lead pin changed')
        next_task = selection['selected_task']
        require(load(OUT/'next_task.json')['task'] == verification['next_task'] == next_task, 'next task association changed')
        remaining = [dict(item) for item in status['next_work'] if 2 <= item['priority'] <= 7]
        require([item['priority'] for item in remaining] == [2, 3, 4, 5, 6, 7]
                and remaining[-1]['status'] == 'blocked_on_full_text' and remaining[-1]['retry_recorded_blocked_routes'] is False, 'pending queue/gates changed')
        clean_head()
        now = datetime.datetime.now(datetime.timezone.utc)
        require(datetime.datetime.fromisoformat(status['active_editing_lease_until_utc']) > now, 'lease expired during completion')
        history, prior = status.setdefault('verification_history', []), status.setdefault('prior_handoffs', [])
        if not any(item['pass_id'] == status['last_completed_pass_id'] for item in history):
            history.append({'pass_id': status['last_completed_pass_id'], 'commit': status['last_complete_commit'], 'handoff': status['handoff'],
                            'handoff_sha256': status['handoff_sha256'], 'verification': status['last_verified_suite']})
        if status['handoff'] not in prior:
            prior.append(status['handoff'])
        status.update(last_complete_commit=EXPECTED_HEAD, last_completed_pass_id=WORK.name, last_update_utc=now.isoformat(),
            handoff=delivery['archive'], handoff_sha256=delivery['sha256'], handoff_bytes=delivery['bytes'],
            handoff_document=str(OUT/'systems-mitl-legacy-drive-comparison-10192026.md'), active_lease_owner=None,
            active_editing_lease_until_utc=None, reserved_paths=[], active_completed_subtasks=[],
            active_phase='Completed legacy current inset recovery and bounded published-display comparison; local manufactured thermal/desorption feedback reference selected next')
        status['last_verified_suite'] = {**verification['results'], 'scope': 'New legacy simulation drive raster recovery and finite-support display comparison; no physical registration, old suite or portable execution',
            'verification_record': str(OUT/'verification.json'), 'delivery_manifest_entries': delivery['manifest_entries'],
            'public_files_byte_identical': 9, 'packaging_wrappers': 2, 'post_freeze_commands': str(WORK/'commands.jsonl')}
        comparison = records['comparison']
        status['legacy_simulation_drive_recovery'] = {'tool': str(REPO/PRODUCER), 'tool_sha256': PINNED[PRODUCER],
            'guide': str(REPO/'docs/legacy_simulation_drive_recovery.md'), 'source_pdf_sha256': PDF_SHA,
            'datasets': datasets, 'retained_samples': 440, 'excluded_native_columns': 336, 'catalogued_native_columns': 776,
            'negative_display_time_samples': 22, 'negative_current_readout_lower_samples': 60,
            'new_positive_producer_runs': 1, 'author_verification_sha256': AUTHOR_SHA,
            'independent_completion': str(WORK/verification['record_paths']['independent_completion']),
            'independent_completion_sha256': verification['record_sha256']['independent_completion'],
            'comparison': str(WORK/verification['record_paths']['comparison']), 'comparison_sha256': verification['record_sha256']['comparison'],
            'comparison_difference_csv_rows': comparison['difference_csv_rows'], 'comparison_qualifications': comparison['qualifications'],
            'comparison_findings': [{'pair': item['pair'], 'shared_central_support_ns': item['shared_central_support_ns'],
                'central_maximum_absolute_difference_A': item['central_continuous_piecewise_linear_difference']['maximum_absolute_A'],
                'readout_finite_query_status': item['readout_outer_intervals']['status'],
                'readout_supported_queries': item['readout_outer_intervals']['supported_query_count'],
                'readout_zero_excluded_queries': item['readout_outer_intervals']['zero_excluded_query_count']} for item in comparison['comparisons']],
            'physical_trigger_or_clock_registration': False, 'original_simulation_input_recovered': False,
            'drive_repair_or_normalization_applied': False, 'physical_uncertainty_established': False,
            'heating_drive_accepted': False, 'actual_flash_run': False,
            'limits': 'Literal correlated raster-display coordinates on clipped finite support. Central PL extrema and separate finite-query readout boxes do not establish continuous agreement, a physical discrepancy, common clock, sole-offset relation, original drive identity or accepted heating input.'}
        lead = load(WORK/'next-upstream-selection'/selection['cached_new_primary_lead'])
        status.setdefault('deferred_new_primary_leads', []).append({'lead': lead['citation'], 'doi': lead['doi'],
            'record': str(WORK/'next-upstream-selection'/selection['cached_new_primary_lead']), 'record_sha256': selection['cached_new_primary_lead_sha256'],
            'status': 'cached_reference_only_deferred', 'title_verified': False, 'full_text_acquired': False, 'parameters_adopted': 0,
            'next': lead['deferred_action']})
        status['next_work'] = [{'priority': 1, 'task': next_task, 'selection': str(WORK/'next-upstream-selection/selection.json'),
            'selection_sha256': SELECTION_SHA, 'proposal_sha256': selection['proposal_sha256'],
            'limits': 'Manufactured stationary local patch only; separate kinetic barrier and wall removal energy, supplied state internal-energy reference, no host/CR/gap/MHD/phase coupling.'}]+remaining
        require(all(status[key] == value for key, value in preserved.items()), 'prior milestones/constraints/blockers/acquisition gates changed')
        status['completed_milestones'].extend([
            'Recovered two legacy Allegra current insets with178/262 samples;776 native columns are catalogued with336 exclusions. Negative displayed times and signed lower readout envelopes remain; no onset/tail, clock registration or original solver input is inferred.',
            'Finite-support comparison retains original reconstructed inset/C19 inputs, exact rational CSV-decimal central PL differences and separate finite-query readout outer boxes. No offset/amplitude/time-warp fit, statistical discrepancy or physical heating validation is inferred.',
            f'Two local commits through {EXPECTED_HEAD[:7]};9 public files and2 wrappers verify against actual archive {delivery["sha256"]}. Next reference evolves one manufactured stationary patch thermal/inventory state; existing physical and owner-input gates remain.'
        ])
        history.append({'pass_id': WORK.name, 'commit': EXPECTED_HEAD, 'handoff': delivery['archive'], 'handoff_sha256': delivery['sha256'], 'verification': status['last_verified_suite']})
        encoded = (json.dumps(status, indent=2, allow_nan=False)+'\n').encode()
        result = {'utc': now.isoformat(), 'event': 'completed_and_next_selected', 'pass_id': WORK.name, 'commit': EXPECTED_HEAD,
            'archive': delivery['archive'], 'archive_sha256': delivery['sha256'], 'archive_bytes': delivery['bytes'],
            'actual_archive_reverified': True, 'public_scope_sha256': public_pins, 'retained_samples': 440,
            'physical_clock_registration': False, 'physical_uncertainty_established': False, 'heating_drive_accepted': False,
            'portable_executions_performed': False, 'old_test_suites_repeated': False,
            'exact_commands': str(WORK/'commands.jsonl'), 'status_before_sha256': hashlib.sha256(before).hexdigest(),
            'status_after_sha256': hashlib.sha256(encoded).hexdigest(), 'lease_released': True, 'reserved_paths': [],
            'next': next_task, 'next_selection_sha256': SELECTION_SHA,
            'limits': 'Published current-display geometry and bounded comparison only; physical clocks, preprocessing, original simulation drive, physical surface/response inputs and configured licensed FLASH remain unresolved.'}
        (WORK/'status-before-completion.json').write_bytes(before)
        temporary = status_path.with_suffix('.json.new')
        temporary.write_bytes(encoded)
        temporary.replace(status_path)
        (WORK/'completion.json').write_text(json.dumps(result, indent=2, allow_nan=False)+'\n')
        with (WORK.parent/'mitl-upstream-journal.jsonl').open('a') as stream:
            stream.write(json.dumps(result, allow_nan=False)+'\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
