"""Check actual compact inset/comparison archive bytes without replaying science."""
import hashlib
import csv
import io
import json
from pathlib import Path, PurePosixPath
import tarfile

from prepare_delivery import WORK, REPO, BASE, OUT, PUBLIC, WRAPPERS, PRODUCER, PDF_SHA256, clean_head, inspect_dataset, load, loads, save, sha
from freeze_delivery import EXPECTED_CONTROLS, REPORT_PATHS, excluded


def verify_saved_records(records, datasets, original_hashes, documents, raw, omissions):
    author = records['author_verification']
    assert author['schema'] == 'mhdlab-simulation-drive-author-verification-v1' and author['complete'] is True
    assert author['source_PDF_sha256'] == PDF_SHA256 and author['new_producer_run_count'] == 1
    assert author['public_source_sha256'] == original_hashes['source/'+PRODUCER]
    assert author['total_samples'] == 440 and author['total_excluded_columns'] == 336 and author['total_catalogued_columns'] == 776
    assert author['visual_QA']['both_generated_PNGs_viewed'] is True
    assert len(author['figures']) == len(datasets) == 2
    for item, dataset in zip(author['figures'], datasets):
        assert item['figure'] == dataset['figure'] and item['csv_sha256'] == dataset['csv_sha256']
        assert item['metadata_sha256'] == dataset['metadata_sha256']
        assert item['source_geometry_sha256'] == dataset['source_geometry_sha256']
        assert item['QA_files_sha256'] == dataset['QA_files_sha256']
    independent = records['independent_completion']
    assert independent['schema'] == 'mitl-independent-simulation-drive-completion-v1'
    assert independent['status'] == 'passed' and independent['all_checks_passed'] is True
    assert all(type(independent[key]) is int and independent[key] == value for key, value in EXPECTED_CONTROLS.items())
    assert independent['old_suites_repeated'] is False
    assert independent['old_recoveries_repeated'] is False and independent['positive_producer_called_for_verification'] is False
    assert independent['signed_display_times_preserved'] is True
    assert independent['physical_clock_alignment_established'] is False and independent['physical_uncertainty_established'] is False
    for name, digest in independent['public_source_sha256'].items():
        assert original_hashes['source/'+name] == digest
    for name, digest in independent['artifact_sha256'].items():
        archive_name = 'evidence/'+name
        if archive_name in original_hashes:
            assert original_hashes[archive_name] == digest
        else:
            assert any(item['path'] == name and item['sha256'] == digest for item in omissions)
    comparison = records['comparison']
    assert comparison['schema'] == 'mhdlab-finite-support-published-drive-comparison-v1'
    assert comparison['status'] == 'completed_display_comparison_only'
    assert comparison['script_sha256'] == original_hashes['evidence/comparison/compare_published_drives.py']
    assert comparison['manifest_sha256'] == original_hashes['evidence/comparison/inputs_manifest.json']
    assert len(comparison['input_files_sha256']) == len(comparison['input_associations']) == 6
    for name, digest in comparison['input_files_sha256'].items():
        assert original_hashes['evidence/'+name] == digest
    for item in comparison['input_associations']:
        assert comparison['input_files_sha256'][item['copy_path']] == item['sha256']
        assert Path(item['original_path']).parent == REPO/'data/dissertation'
        assert Path(item['original_path']).name == Path(item['copy_path']).name
    for name, digest in comparison['artifact_sha256'].items():
        assert original_hashes['evidence/'+name] == digest
    for name in comparison['input_files_sha256']:
        if Path(name).suffix != '.json':
            continue
        metadata = documents('evidence/'+name)
        csv_name = str(Path(name).parent/metadata['output']['csv_filename'])
        assert comparison['input_files_sha256'][csv_name] == metadata['output']['csv_sha256']
        if name.endswith('shot_17133_current.json'):
            assert metadata['status'] == 'reconstructed_published_vector_polyline'
            assert metadata['source']['figure'] == 'C.19' and metadata['source']['pdf_sha256'] == PDF_SHA256
            assert metadata['output']['samples'] == 132
        else:
            match = next(item for item in datasets if Path(item['metadata_path']).name == Path(name).name)
            assert original_hashes['evidence/'+name] == match['metadata_sha256']
            assert original_hashes['evidence/'+csv_name] == match['csv_sha256']
    for key in ('readout_bounds_physical_or_certified', 'physical_trigger_or_clock_registration', 'offset_amplitude_timewarp_fit',
                'statistical_error_or_chi_squared', 'raw_waveform_or_exact_solver_input_recovered',
                'source_or_recovery_producer_repeated', 'host_or_physics_acceptance'):
        assert comparison['qualifications'][key] is False
    assert comparison['qualifications']['finite_support_only'] is True
    assert comparison['qualifications']['finite_query_readout_only'] is True
    differences = list(csv.DictReader(io.StringIO(raw('evidence/comparison/artifacts/differences.csv').decode())))
    assert len(differences) == comparison['difference_csv_rows'] == 1179
    assert len(comparison['comparisons']) == 3
    documentation = records['documentation_association']
    assert documentation['schema'] == 'mitl-simulation-drive-documentation-association-v1' and documentation['passed'] is True
    assert documentation['all_prior_artifacts_preserved'] is True and documentation['source_record_unchanged'] is True
    assert documentation['numerical_recovery_comparison_or_old_suite_reexecuted'] is False
    assert documentation['comparison_report_sha256'] == original_hashes['evidence/'+REPORT_PATHS['comparison']]
    for name, digest in documentation['public_sha256'].items():
        assert original_hashes['source/'+name] == digest
    review = records['comparison_review']
    assert review['schema'] == 'mhdlab-published-drive-comparison-review-v1' and review['complete'] is True
    assert review['status'] == 'passed_read_only_code_and_claims_review' and review['open_findings'] == []
    assert review['summary_sha256'] == original_hashes['evidence/'+REPORT_PATHS['comparison']]
    assert review['code_sha256'] == comparison['script_sha256']
    for name, digest in {**review['supporting_pins'], **review['evidence_logs']}.items():
        assert original_hashes['evidence/'+name] == digest
    completed = records['comparison_completion']
    assert completed['schema'] == 'mhdlab-published-drive-comparison-completion-v1' and completed['status'] == 'passed'
    assert completed['report_sha256'] == original_hashes['evidence/'+REPORT_PATHS['comparison']]
    assert completed['script_sha256'] == comparison['script_sha256']
    assert completed['actual_comparison_run_count'] == 1 and completed['difference_csv_rows'] == 1179
    assert completed['input_files_sha256'] == comparison['input_files_sha256']
    assert completed['open_substantive_findings'] == [] and completed['PNG_visually_inspected'] is True
    for name, digest in completed['artifact_sha256'].items():
        assert original_hashes['evidence/'+name] == digest
    assert completed['independent_read_only_review']['sha256'] == original_hashes['evidence/'+REPORT_PATHS['comparison_review']]
    for key in ('source_and_recovery_producer_repeated', 'old_tests_or_source_evolution_repeated',
                'figures_contain_source_pixels', 'physical_clock_alignment_or_input_identity_established',
                'continuous_or_joint_readout_compatibility_established', 'fitting_or_repair_applied',
                'statistical_covariance_or_significance_inferred', 'readout_bounds_physical_or_certified'):
        assert completed[key] is False
    visual = records['visual_review']
    assert visual['schema'] == 'mitl-legacy-drive-root-visual-review-v1'
    assert visual['numerical_recovery_or_comparison_reexecuted'] is False
    for name, digest in visual['reviewed'].items():
        assert original_hashes['evidence/'+name] == digest
    assert records['selection']['status'] == 'selected_manufactured_reference'


def main():
    frozen = load(WORK/'frozen_delivery.json')
    clean_head(frozen['source_commit'])
    assert frozen['base_commit'] == BASE and Path(frozen['folder']) == OUT
    archive = Path(frozen['archive'])
    assert archive == OUT.with_suffix('.tar.gz')
    assert sha(archive) == frozen['sha256'] and archive.stat().st_size == frozen['bytes']
    hashes, members = {}, {}
    with tarfile.open(archive, 'r:gz') as tar:
        seen = set()
        for member in tar.getmembers():
            path = PurePosixPath(member.name)
            assert not path.is_absolute() and '..' not in path.parts and path.parts[0] == OUT.name
            assert member.name not in seen and not member.issym() and not member.islnk()
            seen.add(member.name)
            if member.isdir():
                continue
            assert member.isfile()
            name = PurePosixPath(*path.parts[1:]).as_posix()
            assert name != '.' and name not in members
            digest = hashlib.sha256()
            stream = tar.extractfile(member)
            for block in iter(lambda: stream.read(1024*1024), b''):
                digest.update(block)
            assert digest.hexdigest() != PDF_SHA256
            hashes[name], members[name] = digest.hexdigest(), member

        def raw(name):
            data = tar.extractfile(members[name]).read()
            assert hashlib.sha256(data).hexdigest() == hashes[name]
            return data

        def document(name):
            return loads(raw(name))

        manifest = document('manifest.sha256.json')
        assert set(hashes) == set(manifest)|{'manifest.sha256.json'}
        assert len(manifest) == frozen['manifest_entries']
        assert all(hashes[name] == digest for name, digest in manifest.items())
        assert hashes['manifest.sha256.json'] == frozen['manifest_sha256']
        assert hashes['verification.json'] == frozen['verification_sha256']
        assert {str(path.relative_to(OUT)) for path in OUT.rglob('*') if path.is_file()} == set(hashes)
        assert all(sha(OUT/name) == digest for name, digest in hashes.items())
        assert document('source_file_list.json') == {'byte_identical_public_files': list(PUBLIC), 'packaging_wrappers': list(WRAPPERS)}
        assert len(PUBLIC) == 9 and len(WRAPPERS) == 2
        assert {name[7:] for name in hashes if name.startswith('source/')} == set(PUBLIC)|set(WRAPPERS)
        for name in PUBLIC:
            assert hashes['source/'+name] == sha(REPO/name)
        for file_name, names in (('source-files.sha256', PUBLIC), ('wrapper-files.sha256', WRAPPERS)):
            found = {}
            for line in raw(file_name).decode().splitlines():
                digest, name = line.split('  ', 1)
                assert name not in found and digest == hashes['source/'+name]
                found[name] = digest
            assert set(found) == set(names)
        verification = document('verification.json')
        assert verification['schema'] == 'mitl-legacy-drive-comparison-verification-v1'
        assert verification['source_commit'] == frozen['source_commit'] and verification['base_commit'] == BASE
        assert verification['record_paths'] == REPORT_PATHS
        assert all(type(verification['results'][key]) is int and verification['results'][key] == value for key, value in EXPECTED_CONTROLS.items())
        assert verification['results']['portable_executions_performed'] is False
        allowed_archive_figures = {'evidence/'+name for name in verification['allowed_figure_paths']}
        assert all(not excluded(name, allowed_archive_figures) for name in hashes)
        datasets = []
        for record in verification['datasets']:
            dataset = inspect_dataset(raw('source/'+record['csv_path']), document('source/'+record['metadata_path']),
                csv_path=record['csv_path'], metadata_path=record['metadata_path'],
                producer_sha256=hashes['source/'+PRODUCER], metadata_sha256=hashes['source/'+record['metadata_path']])
            assert dataset == record
            assert hashes['evidence/recovery/'+record['source_geometry_filename']] == record['source_geometry_sha256']
            for name, digest in record['QA_files_sha256'].items():
                assert hashes['evidence/recovery/'+name] == digest
            datasets.append(dataset)
        original_hashes = dict(hashes)
        restored_bytes = {}
        for projection in reversed(document('portable_path_projections.json')):
            name = projection['path']
            data = restored_bytes.get(name, raw(name))
            assert hashlib.sha256(data).hexdigest() == projection['portable_sha256']
            replacement = projection['replacement'].encode()
            assert data.count(replacement) == projection['replacements']
            restored = data.replace(replacement, bytes.fromhex(projection['source_prefix_hex']))
            assert hashlib.sha256(restored).hexdigest() == projection['original_sha256']
            restored_bytes[name] = restored
            original_hashes[name] = projection['original_sha256']

        def original_document(name):
            return loads(restored_bytes.get(name, raw(name)))

        for item in verification['copied_input_sha256']:
            assert original_hashes[item['archive']] == item['sha256']
        records = {}
        for key, path in REPORT_PATHS.items():
            name = 'evidence/'+path
            assert original_hashes[name] == verification['record_sha256'][key]
            records[key] = original_document(name)
            assert records[key] == verification['records'][key]
        verify_saved_records(records, datasets, original_hashes, original_document, raw, document('excluded_evidence.json'))
        task = records['selection']['selected_task']
        assert document('next_task.json')['task'] == task == verification['next_task']
        result = {**frozen, 'status': 'passed', 'actual_archive_regular_files': len(hashes),
            'unsafe_or_duplicate_members': 0, 'input_code_output_bindings_verified': True,
            'repository_clean': True, 'retained_rows_verified': sum(record['samples'] for record in datasets),
            'source_pdf_included': False, 'raw_source_images_or_pages_included': False,
            'source_recovery_or_comparison_reexecuted': False, 'portable_execution_performed': False}
    save(WORK/'delivery_verification.json', result)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
