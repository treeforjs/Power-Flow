"""Freeze recovered legacy drive insets and their saved display comparison."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tarfile

from prepare_delivery import WORK, REPO, BASE, OUT, PUBLIC, WRAPPERS, PRODUCER, PDF_SHA256, clean_head, canonical_hash, dataset_bindings, load, save, sha

TEXT_SUFFIXES = {'.py', '.json', '.jsonl', '.log', '.xml', '.md', '.txt', '.patch', '.sha256', '.yaml', '.csv'}
EVIDENCE_DIRS = ('recovery', 'independent-verification', 'comparison', 'next-upstream-selection')
REPORT_PATHS = {
    'author_verification': 'recovery/author-verification.json',
    'independent_completion': 'independent-verification/completion.json',
    'comparison': 'comparison/artifacts/report.json',
    'comparison_completion': 'comparison/completion.json',
    'comparison_review': 'comparison-review.json',
    'visual_review': 'visual-review.json',
    'documentation_association': 'documentation-association.json',
    'selection': 'next-upstream-selection/selection.json',
}
EXPECTED_CONTROLS = {'figures': 2, 'retained_columns': 440, 'excluded_columns': 336,
    'native_columns_catalogued': 776, 'numeric_csv_cells_checked': 8800,
    'tick_anchors_checked': 22, 'negative_time_columns': 22, 'negative_current_lower_bound_columns': 60,
    'left_display_clip_columns': 2, 'excluded_single_pixel_cap_columns': 1,
    'source_guard_rejections': 4, 'guarded_recovery_entry_attempts': 2, 'successful_producer_replays': 0,
    'native_row_extraction_calls_by_invalid_source_controls': 0}
PROJECTIONS = (
    (bytes.fromhex('2f6f70742f636f6465782f72756e74696d65732f636f6465782d7072696d6172792d72756e74696d652f646570656e64656e636965732f707974686f6e'), b'[runtime Python directory]'),
    (bytes.fromhex('2f6574632f636f6465782f'), b'[runtime policy directory]/'),
)


def excluded(relative, allowed_figures=()):
    path = Path(relative)
    if any(part in {'__pycache__', '.pytest_cache', '.venv', 'source-local', 'fulltexts', 'raw-fulltexts'}
           or part.startswith('pytest_') for part in path.parts):
        return True
    if path.suffix == '.pyc' or path.name == 'smtrevor_1.pdf':
        return True
    if path.suffix.lower() in {'.png', '.pdf', '.jpg', '.jpeg', '.tif', '.tiff'}:
        return str(path) not in set(allowed_figures)
    return False


def verify_contracts(datasets, records):
    author = records['author_verification']
    assert author['schema'] == 'mhdlab-simulation-drive-author-verification-v1' and author['complete'] is True
    assert author['public_source'] == PRODUCER and author['public_source_sha256'] == sha(REPO/PRODUCER)
    assert author['source_PDF_sha256'] == PDF_SHA256 and author['new_producer_run_count'] == 1
    assert author['total_samples'] == 440 and author['total_excluded_columns'] == 336 and author['total_catalogued_columns'] == 776
    assert author['visual_QA']['both_generated_PNGs_viewed'] is True
    assert len(author['figures']) == len(datasets) == 2
    allowed_figures = []
    for record, dataset in zip(author['figures'], datasets):
        for record_key, dataset_key in (('figure', 'figure'), ('source_identifier', 'source_identifier'),
                ('csv', 'csv_path'), ('metadata', 'metadata_path'), ('csv_sha256', 'csv_sha256'),
                ('metadata_sha256', 'metadata_sha256'), ('samples', 'samples'),
                ('excluded_columns', 'excluded_columns'), ('catalogued_columns', 'catalogued_columns')):
            assert record[record_key] == dataset[dataset_key]
        assert record['negative_time_samples'] == dataset['negative_display_time_columns'] == 11
        assert record['negative_current_readout_lower_samples'] == dataset['negative_current_readout_lower_columns'] == 30
        assert record['left_display_support_clipped'] is True
        assert canonical_hash(record['calibration']) == dataset['calibration_sha256']
        geometry = WORK/'recovery'/dataset['source_geometry_filename']
        assert Path(record['source_geometry']).resolve() == geometry.resolve()
        assert sha(geometry) == record['source_geometry_sha256'] == dataset['source_geometry_sha256']
        assert record['QA_files_sha256'] == dataset['QA_files_sha256']
        for name, digest in record['QA_files_sha256'].items():
            assert sha(WORK/'recovery'/name) == digest
            allowed_figures.append('recovery/'+name)
    command = author['new_producer_command']
    assert command['exit_code'] == 0 and sha(Path(command['log'])) == command['log_sha256']
    independent = records['independent_completion']
    assert independent['schema'] == 'mitl-independent-simulation-drive-completion-v1'
    assert independent['status'] == 'passed' and independent['all_checks_passed'] is True
    assert all(type(independent[key]) is int and independent[key] == value for key, value in EXPECTED_CONTROLS.items())
    assert independent['old_suites_repeated'] is False
    assert independent['old_recoveries_repeated'] is False and independent['positive_producer_called_for_verification'] is False
    assert independent['signed_display_times_preserved'] is True
    assert independent['physical_clock_alignment_established'] is False and independent['physical_uncertainty_established'] is False
    assert set(independent['public_source_sha256']) == {PRODUCER}|{record[key] for record in datasets for key in ('csv_path', 'metadata_path')}
    for name, digest in independent['public_source_sha256'].items():
        assert sha(REPO/name) == digest
    for name, digest in independent['artifact_sha256'].items():
        assert not Path(name).is_absolute() and sha(WORK/name) == digest
        if name == 'independent-verification/wrong-source-control.pdf':
            allowed_figures.append(name)
    comparison = records['comparison']
    assert comparison['schema'] == 'mhdlab-finite-support-published-drive-comparison-v1'
    assert comparison['status'] == 'completed_display_comparison_only'
    assert comparison['script_sha256'] == sha(WORK/'comparison/compare_published_drives.py')
    assert comparison['manifest_sha256'] == sha(WORK/'comparison/inputs_manifest.json')
    assert len(comparison['input_files_sha256']) == len(comparison['input_associations']) == 6
    for name, digest in comparison['input_files_sha256'].items():
        assert str(Path(name).parent) == 'comparison/inputs' and sha(WORK/name) == digest
    for item in comparison['input_associations']:
        assert comparison['input_files_sha256'][item['copy_path']] == item['sha256'] == sha(Path(item['original_path']))
    for name, digest in comparison['artifact_sha256'].items():
        assert sha(WORK/name) == digest
        if Path(name).suffix in {'.png', '.pdf'}:
            allowed_figures.append(name)
    qualifications = comparison['qualifications']
    for key in ('exact_rational_CSV_decimal_arithmetic', 'finite_support_only', 'whole_horizontal_readout_windows_required',
                'unknown_pixel_axis_correlations_retained', 'finite_query_readout_only', 'continuous_central_PL_extrema'):
        assert qualifications[key] is True
    for key in ('readout_bounds_physical_or_certified', 'physical_trigger_or_clock_registration', 'offset_amplitude_timewarp_fit',
                'statistical_error_or_chi_squared', 'raw_waveform_or_exact_solver_input_recovered',
                'source_or_recovery_producer_repeated', 'host_or_physics_acceptance'):
        assert qualifications[key] is False
    assert len(comparison['comparisons']) == 3 and comparison['difference_csv_rows'] == 1179
    for item in comparison['comparisons']:
        assert item['readout_outer_intervals']['finite_queries_only'] is True
        assert item['readout_outer_intervals']['continuous_envelope_compatibility_established'] is False
    documentation = records['documentation_association']
    assert documentation['schema'] == 'mitl-simulation-drive-documentation-association-v1' and documentation['passed'] is True
    assert documentation['prior_manifest_targets'] == 45 and documentation['all_prior_artifacts_preserved'] is True
    assert documentation['source_record_unchanged'] is True
    assert documentation['numerical_recovery_comparison_or_old_suite_reexecuted'] is False
    assert documentation['comparison_report_sha256'] == sha(WORK/REPORT_PATHS['comparison'])
    for name, digest in documentation['public_sha256'].items():
        assert name in PUBLIC and sha(REPO/name) == digest
    review = records['comparison_review']
    assert review['schema'] == 'mhdlab-published-drive-comparison-review-v1'
    assert review['status'] == 'passed_read_only_code_and_claims_review' and review['complete'] is True
    assert review['open_findings'] == []
    assert review['code_sha256'] == comparison['script_sha256']
    assert review['summary_sha256'] == sha(WORK/REPORT_PATHS['comparison'])
    for name, digest in {**review['supporting_pins'], **review['evidence_logs']}.items():
        assert sha(WORK/name) == digest
    for key in ('comparison_reexecuted', 'native_recovery_reexecuted', 'public_or_comparison_files_modified'):
        assert review[key] is False
    completed = records['comparison_completion']
    assert completed['schema'] == 'mhdlab-published-drive-comparison-completion-v1' and completed['status'] == 'passed'
    assert completed['report_sha256'] == sha(WORK/REPORT_PATHS['comparison'])
    assert completed['script_sha256'] == comparison['script_sha256']
    assert completed['actual_comparison_run_count'] == 1 and completed['comparison_run']['exit_code'] == 0
    assert completed['difference_csv_rows'] == comparison['difference_csv_rows']
    assert completed['open_substantive_findings'] == [] and completed['PNG_visually_inspected'] is True
    for key in ('source_and_recovery_producer_repeated', 'old_tests_or_source_evolution_repeated',
                'figures_contain_source_pixels', 'physical_clock_alignment_or_input_identity_established',
                'continuous_or_joint_readout_compatibility_established', 'fitting_or_repair_applied',
                'statistical_covariance_or_significance_inferred', 'readout_bounds_physical_or_certified'):
        assert completed[key] is False
    assert completed['input_files_sha256'] == comparison['input_files_sha256']
    assert completed['independent_read_only_review']['sha256'] == sha(WORK/REPORT_PATHS['comparison_review'])
    for name, digest in completed['artifact_sha256'].items():
        assert sha(WORK/name) == digest
    visual = records['visual_review']
    assert visual['schema'] == 'mitl-legacy-drive-root-visual-review-v1'
    assert visual['numerical_recovery_or_comparison_reexecuted'] is False
    for name, digest in visual['reviewed'].items():
        assert sha(WORK/name) == digest
    selection = records['selection']
    assert selection['schema'] == 'mhdlab-next-upstream-scientific-task-selection-v1'
    assert selection['status'] == 'selected_manufactured_reference'
    return {'allowed_figure_paths': sorted(set(allowed_figures)),
        'results': {**EXPECTED_CONTROLS, 'independent_readback_passed': True,
            'comparison_pairs': 3, 'difference_csv_rows': comparison['difference_csv_rows'],
            'actual_comparison_run_count': 1, 'comparison_read_only_review_passed': True,
            'comparison_png_visually_inspected': True, 'continuous_or_joint_readout_compatibility_established': False,
            'negative_display_time_columns_preserved': 22, 'display_clock_alignment_established': False,
            'physical_readout_uncertainty_established': False, 'host_or_physics_acceptance': False,
            'portable_executions_performed': False, 'packaging_source_recovery_repeated': False,
            'packaging_comparison_repeated': False, 'old_recoveries_repeated': False,
            'old_test_suites_repeated': False, 'full_source_pdf_included': False,
            'raw_source_images_or_pages_included': False}}


def main():
    payload = WORK/'delivery-preparation/payload'
    preparation = load(payload/'preparation.json')
    head = clean_head(preparation['source_commit'])
    assert preparation['base_commit'] == BASE
    assert not OUT.exists() and not OUT.with_suffix('.tar.gz').exists()
    assert load(payload/'source_file_list.json') == {'byte_identical_public_files': list(PUBLIC), 'packaging_wrappers': list(WRAPPERS)}
    assert len(PUBLIC) == 9 and len(WRAPPERS) == 2
    assert {str(path.relative_to(payload/'source')) for path in (payload/'source').rglob('*') if path.is_file()} == set(PUBLIC)|set(WRAPPERS)
    for name in PUBLIC:
        assert (payload/'source'/name).read_bytes() == (REPO/name).read_bytes()
    datasets = dataset_bindings()
    assert datasets == preparation['datasets']
    records = {key: load(WORK/name) for key, name in REPORT_PATHS.items()}
    contract = verify_contracts(datasets, records)
    allowed_figures = contract['allowed_figure_paths']
    next_task = records['selection']['selected_task']
    assert isinstance(next_task, str) and next_task.strip()
    shutil.copytree(payload, OUT)
    evidence = OUT/'evidence'
    evidence.mkdir()
    try:
        active_log = Path(os.readlink('/proc/self/fd/1')).resolve()
    except OSError:
        active_log = None
    copied_inputs = []
    omitted = []
    copied_root_files = []

    def copy(path, relative):
        assert not path.is_symlink()
        digest = sha(path)
        assert digest != PDF_SHA256
        target = evidence/relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, target)
        assert sha(target) == digest
        copied_inputs.append({'source': str(path), 'archive': str(target.relative_to(OUT)), 'sha256': digest})

    for path in WORK.iterdir():
        if path.is_file() and path.suffix in TEXT_SUFFIXES and path.resolve() != active_log:
            copy(path, Path(path.name))
            copied_root_files.append(path.name)
    for folder in EVIDENCE_DIRS:
        for path in (WORK/folder).rglob('*'):
            assert not path.is_symlink()
            if not path.is_file():
                continue
            relative = path.relative_to(WORK)
            if excluded(relative, allowed_figures):
                omitted.append({'path': str(relative), 'sha256': sha(path), 'bytes': path.stat().st_size,
                    'reason': 'Raw native source image/page, prospective source-local artifact or cache omitted.'})
            else:
                copy(path, relative)
    projections = []
    for path in evidence.rglob('*'):
        if not path.is_file() or path.suffix not in TEXT_SUFFIXES:
            continue
        for prefix, replacement in PROJECTIONS:
            data = path.read_bytes()
            if prefix in data:
                assert replacement not in data
                path.write_bytes(data.replace(prefix, replacement))
                projections.append({'path': str(path.relative_to(OUT)), 'original_sha256': hashlib.sha256(data).hexdigest(),
                    'portable_sha256': sha(path), 'replacements': data.count(prefix), 'source_prefix_hex': prefix.hex(),
                    'replacement': replacement.decode(), 'scope': 'Archive-only machine-directory projection; local raw bytes unchanged.'})
    save(OUT/'portable_path_projections.json', projections)
    save(OUT/'excluded_evidence.json', omitted)
    with (OUT/'legacy-drive-comparison.patch').open('wb') as stream:
        subprocess.run(['git', 'diff', '--binary', BASE, head], cwd=REPO, stdout=stream, check=True)
    verification = {'schema': 'mitl-legacy-drive-comparison-verification-v1',
        'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'source_commit': head, 'base_commit': BASE, 'datasets': datasets, 'results': contract['results'],
        'records': records, 'record_paths': REPORT_PATHS,
        'record_sha256': {key: sha(WORK/name) for key, name in REPORT_PATHS.items()},
        'allowed_figure_paths': allowed_figures, 'copied_input_sha256': copied_inputs,
        'public_files_byte_identical': len(PUBLIC), 'packaging_wrappers': len(WRAPPERS),
        'commits': subprocess.check_output(['git', 'log', '--reverse', '--format=%H %s', BASE+'..'+head], cwd=REPO, text=True).splitlines(),
        'command_snapshot': {'scope': 'Completed pass records before freezing; later archive/verification/completion records remain local.',
                             'copied_root_files': sorted(copied_root_files)},
        'next_task': next_task,
        'limits': ['Recovered published legacy simulation insets and a finite comparison of displayed source-coordinate quantities.',
            'Display readout bounds are correlated geometry, not independent observational noise or physical uncertainty.',
            'No fitted clock offset, waveform alignment, amplitude correction, tail, padding, extrapolation, FLASH drive acceptance or physical discrepancy is established.',
            'Packaging creates no portable environment and repeats no recovery, prior passing test suite, numerical source or owner implementation.']}
    save(OUT/'verification.json', verification)
    save(OUT/'next_task.json', {'task': next_task, 'selection_evidence': 'evidence/'+REPORT_PATHS['selection']})
    (OUT/'systems-mitl-legacy-drive-comparison-10192026.md').write_text(f'''# Legacy current insets and finite display comparison

The public subset is pinned to `{head}`; the patch starts at `{BASE}`.
Nine public files are byte-identical. Two wrappers provide this subset's README
and dependency list. No additional portable environment or execution is claimed.

Both upper-left legacy simulation current insets are retained on explicit finite
published support. Source/PDF/RGB and calibration identity, full selection catalogs,
QA figures, independent readback and guarded-source failures are preserved.
The work-only comparison retains exact C19 and new-inset input bytes and reports
the quantities, support, readout conventions and limitations it actually compares.

The displayed curves do not establish equal clock origins, processing conventions,
physical uncertainty, accepted heating drive or an experimental mismatch. No
alignment or empirical repair is supplied. Raw source pages and native images are
excluded with recorded hashes; generated QA/comparison figures are retained.
Archive-only machine-directory projections are reversible; local raw records
remain unchanged. Exact commands, failed attempts and focused corrections remain
in evidence. No old recovery or prior suite was repeated by packaging.

Next selected task: {next_task}
''')
    manifest = {str(path.relative_to(OUT)): sha(path) for path in OUT.rglob('*') if path.is_file() and path.name != 'manifest.sha256.json'}
    save(OUT/'manifest.sha256.json', manifest)
    words = [bytes.fromhex(value).decode() for value in ('6f70656e6169', '63686174677074', '636c61756465', '636f646578')]
    prohibited = re.compile(r'\b(?:'+'|'.join(words)+r')\b', re.I)
    allowed_archive_figures = {'evidence/'+name for name in allowed_figures}
    for path in OUT.rglob('*'):
        assert not path.is_symlink()
        if path.is_file():
            assert sha(path) != PDF_SHA256 and not excluded(path.relative_to(OUT), allowed_archive_figures)
            if path.suffix in TEXT_SUFFIXES:
                assert not prohibited.search(path.read_text()), str(path)
    clean_head(head)
    assert all(sha(REPO/name) == preparation['public_source_sha256'][name] for name in PUBLIC)
    assert all(sha(Path(item['source'])) == item['sha256'] for item in copied_inputs)
    archive = OUT.with_suffix('.tar.gz')
    with tarfile.open(archive, 'w:gz') as tar:
        tar.add(OUT, arcname=OUT.name)
    record = {'folder': str(OUT), 'archive': str(archive), 'sha256': sha(archive), 'bytes': archive.stat().st_size,
        'source_commit': head, 'base_commit': BASE, 'manifest_entries': len(manifest),
        'public_files_byte_identical': len(PUBLIC), 'packaging_wrappers': len(WRAPPERS),
        'manifest_sha256': sha(OUT/'manifest.sha256.json'), 'verification_sha256': sha(OUT/'verification.json')}
    save(WORK/'frozen_delivery.json', record)
    print(json.dumps(record, indent=2))


if __name__ == '__main__':
    main()
