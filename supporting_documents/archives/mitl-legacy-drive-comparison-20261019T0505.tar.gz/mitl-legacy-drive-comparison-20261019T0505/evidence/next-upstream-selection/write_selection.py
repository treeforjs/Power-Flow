"""Freeze a bounded upstream reference proposal from existing local evidence.

This records source identities and planning only. It evaluates no release law,
temperature evolution, acquisition route, current comparison or numerical model.
"""
import datetime
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
WORK = HERE.parent
REPO = Path('/workspace/Power-Flow')
STATUS = WORK.parent/'mitl-upstream-status.json'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(name, value):
    path = HERE/name
    if path.exists():
        raise RuntimeError('refuse to overwrite a frozen selection artifact: '+name)
    path.write_text(json.dumps(value, indent=2, allow_nan=False)+'\n')


def main():
    now = datetime.datetime.now(datetime.timezone.utc)
    status = json.loads(STATUS.read_text())
    lease = json.loads((WORK/'lease.json').read_text())
    assert status['active_lease_owner'] == lease['pass_id'] == WORK.name
    assert datetime.datetime.fromisoformat(status['active_editing_lease_until_utc']) > now
    assert status['last_complete_commit'] == lease['baseline_commit'] == '65638571ddfa3a887f610021dec58bdbafee54d0'
    assert status['handoff'] == lease['prior_handoff'] and sha(status['handoff']) == lease['prior_handoff_sha256']
    paths = [
        'mhdlab/temkin_release.py', 'mhdlab/temkin_planar.py',
        'mhdlab/conductive_heating_benchmark.py', 'mhdlab/solid_enthalpy.py',
        'mhdlab/window_source_ledger.py', 'docs/boundary_transaction_requirements.md',
        'docs/surface_release_pipeline.md', 'docs/conductive_heating_verification.md',
        'docs/solid_enthalpy_inputs.md', 'docs/temkin_convergence.md',
    ]
    evidence = {name: sha(REPO/name) for name in paths}
    anchors = [
        {'path': 'mhdlab/temkin_release.py', 'anchor': 'Prescribed temperature means that wall debit remains a diagnostic.',
         'scope': 'Existing nonlinear inventory kernel accepts prescribed frozen temperature; it does not solve wall-temperature feedback.'},
        {'path': 'mhdlab/temkin_planar.py', 'anchor': 'make the reported wall-energy debit a diagnostic rather than thermal feedback.',
         'scope': 'Existing resolved source histories retain prescribed wall temperatures.'},
        {'path': 'docs/boundary_transaction_requirements.md', 'anchor': 'It does not implement wall cooling, moving surfaces or host transactions.',
         'scope': 'Existing owner contract and arithmetic transaction controls specify transfers and acceptance; they do not solve a coupled thermal/inventory trajectory.'},
        {'path': 'docs/conductive_heating_verification.md', 'anchor': 'surface desorption or an equation of state.',
         'scope': 'Existing exact induction/Joule/conduction reference excludes surface desorption.'},
        {'path': 'docs/solid_enthalpy_inputs.md', 'anchor': 'no such coupling is installed by this module.',
         'scope': 'Existing phase-qualified Cp/enthalpy evaluation and bounded inverse are material inputs; they do not supply the local thermal feedback model or justify Cv.'},
    ]
    for item in anchors:
        assert item['anchor'] in (REPO/item['path']).read_text()
    cached_text = Path('/workspace/research_sources/surface_desorption/lane_2018_osti.txt')
    cached_registry = Path('/workspace/research_sources/surface_desorption/lane_2018_crossref.json')
    cached_reference = json.loads(cached_registry.read_text())
    message = cached_reference.get('message', cached_reference)
    ref = next(item for item in message['reference'] if item['key'] == 'cmaae4afbib016')
    assert ref['DOI'].lower() == '10.1016/0039-6028(86)90500-5'
    lead = {'schema': 'mitl-unassessed-cached-primary-lead-v1',
        'citation': 'Hendewerk M, Salmeron M and Somorjai GA, Surface Science172,544(1986)',
        'doi': ref['DOI'], 'publisher_asserted_reference': ref,
        'cached_manuscript': str(cached_text), 'cached_manuscript_sha256': sha(cached_text),
        'cached_registry_record': str(cached_registry), 'cached_registry_record_sha256': sha(cached_registry),
        'source_locations': [{'manuscript_page': 2, 'text_lines_1based': [60, 64],
            'claim': 'Lane groups reference16 with water TPD studies of inventory, adsorption sites and dissociation.'},
            {'manuscript_page': 30, 'text_line_1based': 1318, 'claim': 'Reference16 gives the cited authors,year,journal,volume andfirst page.'}],
        'why_new': 'A distinct primary experiment cited by the cached Lane manuscript; its pages and title are absent from the completed Lane/Bennett/Cuneo assessments and differ from blocked Joly2000/LiDylla1995 routes.',
        'title_verified': False, 'full_text_acquired': False, 'surface_or_parameters_verified': False,
        'network_used': False, 'physical_parameters_adopted': 0,
        'deferred_action': 'Verify this citation title and a legitimate full-text location before assessing surface preparation, removable molecular water versus OH inventory, dose convention, heating protocol and observed versus inferred release energy.',
        'limits': 'Publisher reference DOI and secondary contextual citation only; no target-foil qualification, transferable water rate, monolayer convention or wall energy is supplied.'}
    save('cached_primary_lead.json', lead)
    proposal = {
        'scope': 'Single stationary patch, one externally declared parent pool and one fixed emitted-state energy reference; manufactured coefficients only.',
        'proposed_new_paths': ['mhdlab/thermal_feedback_reference.py', 'tests/test_thermal_feedback_reference.py'],
        'optional_later_paths': ['tools/run_thermal_feedback_reference.py', 'configs/thermal_feedback_manufactured.json', 'docs/thermal_feedback_reference.md'],
        'first_domain': 'Constant positive areal heat capacity C_A; zero external input power; no phase change, conduction, radiation, work, wall motion, gap evolution or host transaction.',
        'input_contract': ['Initial areal parent inventory N0 and temperature T0; finite patch area applied exactly once for extensive outputs.',
            'Fixed kinetic reference coverage and independently declared Temkin rate/barrier parameters; never redefine Nref from N0.',
            'Explicit supported positive temperature range, numerical tolerances and status/provenance; no physical defaults.',
            'Independent constant removal cost D and fixed gas internal energy I per parent in a common declared reference; neither inferred from activation barrier. No state catalog or reaction/branching data are generated.',
            'C_A in J m^-2 K^-1 is a supplied thermal-model coefficient, not inferred from the existing mass-specific Cp fit or nominal thickness.'],
        'equations': {'rate': 'Gamma(N,T)=nu*N*exp[-Ea(N)/(k_B*T)]',
            'inventory': 'dN/dt=-Gamma', 'thermal': 'C_A*dT/dt=-Gamma*(D+I+2*k_B*T)',
            'adsorbate_reference': 'U_ads=-D*N', 'gas_expected_energy': 'dE_gas/dt=Gamma*(I+2*k_B*T)',
            'conservation': 'C_A*(T-Tref)-D*N+E_gas is constant; N+N_emitted=N0',
            'independent_thermal_curve': 'T(N)=(T0+A)*exp[2*k_B*(N-N0)/C_A]-A, A=(D+I)/(2*k_B)',
            'stable_evaluation_hint': 'T=T0+(T0+A)*expm1[2*k_B*(N-N0)/C_A], with separately qualified arithmetic.',
            'independent_time_map': 't(N)=integral_N^N0 [1/Gamma(n,T(n))] dn; monotone inversion supplies the reference trajectory.'},
        'independent_checks': ['Verify the analytic N-to-T relation independently from the time integrator and its rate law.',
            'Retain number, thermal, bound-reference, gas translation and internal-energy channels separately, with signed residuals; total-energy residual alone cannot validate allocation.',
            'Compare a constant-barrier case and a nonzero coverage-dependent case using fixed Nref, with all parameters explicitly manufactured.',
            'Compare finite heat-reservoir feedback with the matched prescribed-temperature control; no claim that this difference is a measured water effect.',
            'Refine temporal resolution against the independent monotone integral/inversion reference. Scale errors to explicitly declared emitted-number and each energy-channel budget; report finite changes and observed self-order separately from error certificates.',
            'Reject unsupported temperature/kinetic/representation ranges and insufficient thermal-domain support; do not clip negative inventories, temperature, energies or rare positive contributions.'],
        'work_limit': 'First bounded implementation uses4-6 purposeful manufactured cases and one temporal-refinement family; no spatial mesh, multipool chemistry, phase extension or production coupling.',
        'downstream_limits': ['The2*k_B*T term is the continuum flux-Maxwellian expectation. Finite sampled packet energies and host acceptance remain distinct and separately owned.',
            'No automatic FLASH, Quark or source-history feedback is installed; no existing source, thermal, solver, state or collision/radiative data files are edited.',
            'A nonzero manufactured heating-power branch can be a later independently verified extension after the zero-power reference; it is not required in this bounded first task.'],
    }
    save('thermal_feedback_proposal.json', proposal)
    selection = {'schema': 'mhdlab-next-upstream-scientific-task-selection-v1', 'status': 'selected_manufactured_reference',
        'selected_utc': now.isoformat(),
        'selected_task': 'Implement and independently verify a manufactured single-patch thermal/desorption-feedback reference with joint wall temperature and finite Temkin inventory, using an analytic N-to-T relation and temporal refinement.',
        'why_new_and_useful': 'Current thermal references exclude release, source laws prescribe temperature, and source ledgers/transaction arithmetic do not evolve thermal feedback. This adds a closed local energy-pathway reference before any owner coupling or physical-water inference.',
        'local_scope_verified': anchors, 'existing_public_evidence_sha256': evidence,
        'proposal': 'thermal_feedback_proposal.json', 'proposal_sha256': sha(HERE/'thermal_feedback_proposal.json'),
        'cached_new_primary_lead': 'cached_primary_lead.json', 'cached_new_primary_lead_sha256': sha(HERE/'cached_primary_lead.json'),
        'deferred_literature_lead_not_selected_instead_of_reference': lead['doi'],
        'current0505_scope_remains_separate': 'Two newly reconstructed legacy current insets and finite shared-support display comparison withC19. That comparison cannot establish physical trigger or simulation-clock registration, original drive identity, a sole-offset model or physical heating closure.',
        'blocked_work_preserved': [{'task': 'Owner transport/response acceptance', 'reason': 'Actual collection, field, precision, loss and response definitions remain owner supplied.'},
            {'task': 'Absolute VUV/monolayer inference', 'reason': 'Reduction certificate, covariance, observation mapping, physical parent convention and actual surface parameters remain unavailable.'},
            {'task': 'Joly2000/LiDylla1995 full-text assessment', 'reason': 'Only a new legitimate copy/location reopens assessment; recorded blocked routes are not retried.',
             'access_record': status['source_desorption_acquisition']['access_record'], 'access_record_sha256': status['source_desorption_acquisition']['access_record_sha256']},
            {'task': 'Actual FLASH runs', 'reason': 'Installed licensed source and configured workstation/interfaces remain unavailable.'}],
        'prior_handoff': status['handoff'], 'prior_handoff_sha256': status['handoff_sha256'],
        'status_read_sha256': sha(STATUS), 'lease_sha256': sha(WORK/'lease.json'), 'writer_sha256': sha(__file__),
        'public_files_edited': False, 'network_used': False, 'source_recovery_performed': False,
        'numerical_producer_or_model_executed': False, 'axis_fit_or_alignment_math_performed': False,
        'old_suites_or_source_evolution_repeated': False, 'physical_parameters_adopted': 0,
        'selection_limit': 'Planning and existing text/code declaration checks only. Analytic equations are a proposed manufactured model, not an executed trajectory or physical wall closure.'}
    save('selection.json', selection)
    print(json.dumps({'selection': str(HERE/'selection.json'), 'sha256': sha(HERE/'selection.json'),
        'proposal_sha256': selection['proposal_sha256'], 'cached_primary_lead_sha256': selection['cached_new_primary_lead_sha256'],
        'network_used': False, 'numerical_model_executed': False}, indent=2))


if __name__ == '__main__':
    main()
