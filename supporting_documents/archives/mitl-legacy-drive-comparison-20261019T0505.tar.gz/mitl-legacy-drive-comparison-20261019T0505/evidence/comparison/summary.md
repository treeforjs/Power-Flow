# Published-coordinate current comparison

The central reconstructed legacy current displays lie below the C.19 central average-current display on their shared finite support. Their largest central piecewise-linear difference is about 16.3 kA. The two legacy insets differ by at most about 1.52 kA on common support. These numbers describe the displayed curves, not independently measured errors or recovered physical simulation inputs.

| Pair | Shared central time support [ns] | Maximum absolute central difference [kA] | Queries excluding zero / fully supported queries |
| --- | --- | ---: | ---: |
| legacy_4_28 minus legacy_4_29 | -2.5 to 39.6429 | 1.52107 | 0/292 |
| legacy_4_28 minus C19_17133 | 0.749788 to 39.6429 | 16.2914 | 0/355 |
| legacy_4_29 minus C19_17133 | 0.749788 to 59.6429 | 16.2914 | 0/502 |

No evaluated readout interval excludes zero. This means only that zero difference was not excluded at the finite queries under the supplied estimated readout boxes and conservative monotone piecewise-linear retiming model. It is neither proof of simultaneous or continuous curve agreement nor a recovered physical trigger, clock alignment, processing recipe or original simulation input. No offset, amplitude scale or time warp was fitted. Differences could reflect display reconstruction, filtering, averaging, preprocessing or other unresolved coordinate/input definitions; their cause is not identified here.

The calculation treats literal CSV decimal cells as exact rational declarations. Central-curve extrema are exact for the declared piecewise-linear displays over shared support. For readout intervals, it allows each vertex's horizontal and vertical readout bounds, uses the maximum horizontal displacement, and takes exact extrema of the lower/upper current curves over the entire associated time window. Queries whose full windows extend beyond supplied support have no readout interval. Missing edge support is never clipped, padded or extrapolated.

Source pixel and calibration errors are correlated and no physical covariance model is available. Independent boxes intentionally enlarge the allowed set; their inclusion of zero is therefore a non-exclusion result rather than a statistical compatibility test. The supplied display envelopes are estimates, not certified physical-error bounds. Finite-query bars in the figures are not a reconstruction of a continuous uncertainty envelope. No chi-squared, probability, sample independence or physical significance is assigned.

The exact-byte input copies, metadata associations, code/configuration hashes, a 1179-row differences table and shareable figures are retained with the report. The sources distinguish legacy Allegra simulation insets from the experimental-origin C.19 average-current display. No source producer, simulation, physical solver or old test was repeated.

- [Comparison figure](artifacts/comparison.png)
- [Shareable PDF](artifacts/comparison.pdf)
- [Machine-readable report](artifacts/report.json)
- [Differences CSV](artifacts/differences.csv)
