"""Finite-support comparison of independently reconstructed published currents.

CSV decimal cells are exact rational input declarations. The central curves are
piecewise linear displays, not independently measured interpolated waveforms.
No producer, source law, physical solver, fitting or network operation is used.
"""
from __future__ import annotations
import argparse,bisect,csv,hashlib,json,math,shutil
from fractions import Fraction as F
from pathlib import Path

SCHEMA='mhdlab-finite-support-published-drive-comparison-v1'
PDF_SHA='1d7b1f9c191a37e94f1cc3634587750f1af35b07eb13e0b94c60f3da47495ed7'
CSV_FIELDS=('pair','left_id','right_id','time_ns','left_current_A','right_current_A','central_difference_A','full_readout_windows_supported','left_time_window_lower_ns','left_time_window_upper_ns','right_time_window_lower_ns','right_time_window_upper_ns','left_readout_lower_A','left_readout_upper_A','right_readout_lower_A','right_readout_upper_A','difference_readout_lower_A','difference_readout_upper_A','zero_excluded_by_outer_interval','outer_interval_zero_separation_A')

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def exact(v):return {'numerator':str(v.numerator),'denominator':str(v.denominator)}
def num(v,unit):return {'value':float(v),'exact_fraction':exact(v),'units':unit}
def cell(s):
    if not isinstance(s,str) or not s or len(s)>1024:raise ValueError('Invalid numeric CSV cell')
    value=F(s)
    if not math.isfinite(float(value)):raise ValueError('CSV input outside finite float display range')
    return value

def pointer(doc,keys):
    for key in keys:doc=doc[key]
    return doc

def load_curve(spec,inputs):
    path=inputs/spec['csv_filename'];meta_path=inputs/spec['metadata_filename']
    meta=json.loads(meta_path.read_text())
    for assertion in spec['metadata_assertions']:
        if pointer(meta,assertion['pointer'])!=assertion['expected']:raise ValueError('Metadata identity differs: '+spec['id'])
    if pointer(meta,spec['csv_hash_pointer'])!=sha(path):raise ValueError('Metadata/CSV hash association failed')
    fields=spec['field_map'];values={key:[] for key in fields}
    with path.open(newline='') as stream:
        reader=csv.DictReader(stream)
        if not set(fields.values())<=set(reader.fieldnames or []):raise ValueError('Missing input CSV fields')
        for row in reader:
            if any(row[key]!=value for key,value in spec.get('selector',{}).items()):continue
            for key,name in fields.items():values[key].append(cell(row[name]))
    t=values['time'];n=len(t)
    if not 2<=n<=2000 or any(b<=a for a,b in zip(t,t[1:])):raise ValueError('Strict bounded increasing time support required')
    if any(not values['time_lower'][i]<=t[i]<=values['time_upper'][i] or not values['current_lower'][i]<=values['current'][i]<=values['current_upper'][i] for i in range(n)):raise ValueError('Readout boxes do not contain central vertices')
    radius=max(max(t[i]-values['time_lower'][i],values['time_upper'][i]-t[i]) for i in range(n))
    return {**values,'id':spec['id'],'label':spec['label'],'radius':radius,'metadata':meta,'record_count':n}

def interp(curve,key,q):
    t=curve['time'];v=curve[key]
    if not t[0]<=q<=t[-1]:raise ValueError('Display extrapolation is forbidden')
    j=bisect.bisect_right(t,q)-1
    if j==len(t)-1:return v[j]
    return v[j]+(v[j+1]-v[j])*(q-t[j])/(t[j+1]-t[j])

def window_range(curve,q):
    lo=q-curve['radius'];hi=q+curve['radius'];t=curve['time']
    if lo<t[0] or hi>t[-1]:return None
    j=bisect.bisect_right(t,lo);k=bisect.bisect_left(t,hi)
    lower=min([interp(curve,'current_lower',lo),interp(curve,'current_lower',hi)]+curve['current_lower'][j:k])
    upper=max([interp(curve,'current_upper',lo),interp(curve,'current_upper',hi)]+curve['current_upper'][j:k])
    return lower,upper

def compare(left,right):
    lo=max(left['time'][0],right['time'][0]);hi=min(left['time'][-1],right['time'][-1])
    if not lo<hi:raise ValueError('No positive shared finite support')
    central=sorted({lo,hi,*[q for c in (left,right) for q in c['time'] if lo<q<hi]})
    differences=[interp(left,'current',q)-interp(right,'current',q) for q in central]
    guard_lo=max(left['time'][0]+left['radius'],right['time'][0]+right['radius'])
    guard_hi=min(left['time'][-1]-left['radius'],right['time'][-1]-right['radius'])
    query=set(central)
    if guard_lo<=guard_hi:
        query.update((guard_lo,guard_hi))
    query.update(q+s*c['radius'] for c in (left,right) for q in c['time'] for s in (-1,1) if lo<=q+s*c['radius']<=hi)
    rows=[];pair=left['id']+'_minus_'+right['id'];qualified=[];disjoint=[]
    for q in sorted(query):
        a=interp(left,'current',q);b=interp(right,'current',q)
        lr=window_range(left,q);rr=window_range(right,q);supported=lr is not None and rr is not None
        row={'pair':pair,'left_id':left['id'],'right_id':right['id'],'time_ns':q,'left_current_A':a,'right_current_A':b,'central_difference_A':a-b,'full_readout_windows_supported':supported,'left_time_window_lower_ns':q-left['radius'],'left_time_window_upper_ns':q+left['radius'],'right_time_window_lower_ns':q-right['radius'],'right_time_window_upper_ns':q+right['radius']}
        if supported:
            dl=lr[0]-rr[1];du=lr[1]-rr[0];excluded=dl>0 or du<0;sep=min(abs(dl),abs(du)) if excluded else F(0)
            row.update(left_readout_lower_A=lr[0],left_readout_upper_A=lr[1],right_readout_lower_A=rr[0],right_readout_upper_A=rr[1],difference_readout_lower_A=dl,difference_readout_upper_A=du,zero_excluded_by_outer_interval=excluded,outer_interval_zero_separation_A=sep)
            qualified.append((q,dl,du))
            if excluded:disjoint.append((q,sep))
        rows.append(row)
    min_i=min(range(len(differences)),key=differences.__getitem__);max_i=max(range(len(differences)),key=differences.__getitem__);abs_i=max(range(len(differences)),key=lambda i:abs(differences[i]))
    result={'pair':pair,'left_id':left['id'],'right_id':right['id'],'shared_central_support_ns':[num(lo,'ns'),num(hi,'ns')],'central_continuous_piecewise_linear_difference':{'method':'Exact rational difference of the two declared PL displays; extrema occur at shared-support endpoints or union of original central knot times.','union_knot_count':len(central),'minimum_A':num(differences[min_i],'A'),'minimum_time_ns':num(central[min_i],'ns'),'maximum_A':num(differences[max_i],'A'),'maximum_time_ns':num(central[max_i],'ns'),'maximum_absolute_A':num(abs(differences[abs_i]),'A'),'maximum_absolute_time_ns':num(central[abs_i],'ns')},
        'readout_outer_intervals':{'method':'At q, each curve uses min lower-current PL and max upper-current PL over[q-r,q+r], including all interior knots; r is max absolute vertex time-box displacement. Differences use[left_lower-right_upper,left_upper-right_lower].','fully_supported_query_domain_ns':None if guard_lo>guard_hi else [num(guard_lo,'ns'),num(guard_hi,'ns')],'query_rule':'Shared central union knots plus qualified-domain endpoints and original knots shifted by plus/minus each curve global horizontal radius, restricted to central overlap.','total_query_count':len(rows),'supported_query_count':len(qualified),'unsupported_edge_query_count':len(rows)-len(qualified),'zero_excluded_query_count':len(disjoint),'zero_not_excluded_query_count':len(qualified)-len(disjoint),'maximum_separation_from_zero_A':num(max((v for q,v in disjoint),default=F(0)),'A'),'minimum_separation_among_excluding_queries_A':None if not disjoint else num(min(v for q,v in disjoint),'A'),'first_zero_excluded_query_ns':None if not disjoint else num(disjoint[0][0],'ns'),'last_zero_excluded_query_ns':None if not disjoint else num(disjoint[-1][0],'ns'),'finite_queries_only':True,'continuous_envelope_compatibility_established':False,'status':'conditional_literal_coordinate_readout_box_differences_present' if disjoint else 'no_difference_excluded_at_evaluated_outer_box_queries'},
        'interpretation':'Any zero exclusion is conditional on these literal coordinates, supplied display boxes and the declared monotone PL retiming model; it identifies neither wrong drive nor physical clock or normalization error. Zero inclusion is only non-exclusion by a conservative outer set, not proof of agreement.'}
    return result,rows,central

def plot(curves,pairs,destination):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    fig,axes=plt.subplots(len(pairs),2,figsize=(12,3.5*len(pairs)),squeeze=False,layout='constrained')
    for axrow,(summary,rows,central) in zip(axes,pairs):
        left=curves[summary['left_id']];right=curves[summary['right_id']]
        for c,color in ((left,'firebrick'),(right,'navy')):
            axrow[0].plot([float(q) for q in central],[float(interp(c,'current',q))/1e6 for q in central],label=c['label'],color=color,lw=1.2)
        axrow[0].set(ylabel='Published current [MA]',title=summary['pair']);axrow[0].legend(fontsize=8)
        axrow[1].axhline(0,color='black',lw=.7)
        qualified=[r for r in rows if r['full_readout_windows_supported']]
        axrow[1].vlines([float(r['time_ns']) for r in qualified],[float(r['difference_readout_lower_A'])/1e6 for r in qualified],[float(r['difference_readout_upper_A'])/1e6 for r in qualified],color='cornflowerblue',alpha=.3,lw=.6,label='Outer intervals at finite queries')
        axrow[1].plot([float(q) for q in central],[float(interp(left,'current',q)-interp(right,'current',q))/1e6 for q in central],color='darkred',lw=1,label='Central PL difference')
        axrow[1].set(ylabel='Left minus right [MA]',title='Display readout limits; no statistical error model');axrow[1].legend(fontsize=8)
        for ax in axrow:ax.set_xlabel('Unshifted published time [ns]');ax.grid(alpha=.2)
    fig.suptitle('Published-coordinate current comparison; no trigger registration or drive repair',fontsize=12)
    fig.savefig(destination.with_suffix('.png'),dpi=180);fig.savefig(destination.with_suffix('.pdf'));plt.close(fig)

def main():
    parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--manifest',type=Path,required=True);parser.add_argument('--output-dir',type=Path,required=True);args=parser.parse_args()
    spec=json.loads(args.manifest.read_text());work=Path(__file__).resolve().parent;inputs=work/'inputs'
    if args.output_dir.exists():raise ValueError('A fresh output directory is required')
    # Pin/copy existing artifacts only; no producer or model is called.
    inputs.mkdir(exist_ok=True)
    associations=[]
    for item in spec['curves']:
        for kind in ('csv','metadata'):
            original=Path(item[kind+'_original_path']);dest=inputs/item[kind+'_filename']
            if sha(original)!=item[kind+'_sha256']:raise ValueError('Original input changed before copy')
            if dest.exists():raise ValueError('Input copy already exists; no overwrite')
            shutil.copyfile(original,dest)
            if sha(dest)!=item[kind+'_sha256']:raise ValueError('Input byte-copy failed')
            associations.append({'curve_id':item['id'],'kind':kind,'original_path':str(original),'copy_path':str(dest.relative_to(work.parent)),'sha256':sha(dest)})
    curves={item['id']:load_curve(item,inputs) for item in spec['curves']}
    pairs=[compare(curves[a],curves[b]) for a,b in spec['pairs']]
    args.output_dir.mkdir(parents=True)
    csv_path=args.output_dir/'differences.csv'
    with csv_path.open('w',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=CSV_FIELDS,lineterminator='\n');writer.writeheader()
        for summary,rows,central in pairs:
            for row in rows:writer.writerow({k:('' if k not in row else int(row[k]) if type(row[k]) is bool else format(float(row[k]),'.17g') if isinstance(row[k],F) else row[k]) for k in CSV_FIELDS})
    notes='''These are published current display comparisons, not raw waveforms or registered physical drive inputs. Literal CSV decimal cells define exact rational central knots and readout bounds. Supplied bounds are estimated publication readout envelopes; their adequacy as physical or certified source-error bounds is not established. Central PL extrema are continuous on common finite support. The separate readout diagnostic is evaluated at an explicit finite query set. Its conservative box interpretation allows only strictly order-preserving piecewise-linear vertex retiming and vertical vertex bounds; any actual-error member must satisfy those supplied bounds. Max horizontal displacement r bounds the corresponding nominal coordinate tau by |tau-q|<=r, so extrema of the lower/upper current PL on[q-r,q+r] enclose that retimed display. Whole horizontal windows must remain within central supplied support; edge queries lacking support have no readout interval. Correlated calibration and pixel errors are unknown; independent boxes provide an outer set, not a probability law. Zero inclusion does not prove simultaneous or continuous agreement. Zero exclusion is conditional display-coordinate disagreement only, and identifies neither an erroneous simulation drive nor a physical clock, normalization or trigger error. Filtering, averaging, scaling, preprocessing and more general coordinate relations remain unresolved. No offset, amplitude fit, time warp, smoothing, tail, prehistory, physical derivative or extrapolation is added. No chi-squared, statistical significance, pseudo-independent sample noise or RMS is computed. Finite-query vertical bars in figures are not interpolation of an exact continuous uncertainty envelope. No source/CR/FLASH/Quark producer is called.\n'''
    note_path=args.output_dir/'interpretation.txt';note_path.write_text(notes)
    plot(curves,pairs,args.output_dir/'comparison')
    report={'schema':SCHEMA,'status':'completed_display_comparison_only','script_sha256':sha(Path(__file__)),'manifest_sha256':sha(args.manifest),'input_files_sha256':{a['copy_path']:a['sha256'] for a in associations},'input_associations':associations,'curves':{key:{'label':c['label'],'record_count':c['record_count'],'central_time_support_ns':[num(c['time'][0],'ns'),num(c['time'][-1],'ns')],'global_vertex_time_radius_ns':num(c['radius'],'ns')} for key,c in curves.items()},'comparisons':[item[0] for item in pairs],'difference_csv_rows':sum(len(item[1]) for item in pairs),'artifact_sha256':{str(p.relative_to(work.parent)):sha(p) for p in (csv_path,note_path,args.output_dir/'comparison.png',args.output_dir/'comparison.pdf',args.manifest,Path(__file__))},'qualifications':{'exact_rational_CSV_decimal_arithmetic':True,'finite_support_only':True,'whole_horizontal_readout_windows_required':True,'unknown_pixel_axis_correlations_retained':True,'readout_bounds_physical_or_certified':False,'finite_query_readout_only':True,'continuous_central_PL_extrema':True,'physical_trigger_or_clock_registration':False,'offset_amplitude_timewarp_fit':False,'statistical_error_or_chi_squared':False,'raw_waveform_or_exact_solver_input_recovered':False,'source_or_recovery_producer_repeated':False,'host_or_physics_acceptance':False},'limits':notes.strip()}
    (args.output_dir/'report.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'report':str(args.output_dir/'report.json'),'sha256':sha(args.output_dir/'report.json'),'CSV_rows':report['difference_csv_rows'],'pairs':[{k:c[k] for k in ('pair','shared_central_support_ns','central_continuous_piecewise_linear_difference','readout_outer_intervals')} for c in report['comparisons']]},indent=2))
if __name__=='__main__':main()
