"""Prepare the compact legacy drive inset and finite-display comparison handoff."""
import argparse
import ast
import csv
import hashlib
import io
import json
import math
from pathlib import Path
import re
import shutil
import subprocess

WORK = Path(__file__).resolve().parent
REPO = Path('/workspace/Power-Flow')
BASE = '65638571ddfa3a887f610021dec58bdbafee54d0'
HEAD = 'b27b04fb38238c831e12bf2f3cdfe945e5834d58'
OUT = Path('/workspace/handoffs/mitl-legacy-drive-comparison-20261019T0505')
PDF_SHA256 = '1d7b1f9c191a37e94f1cc3634587750f1af35b07eb13e0b94c60f3da47495ed7'
PRODUCER = 'tools/recover_dissertation_simulation_drive.py'
PUBLIC = (PRODUCER,
    'data/dissertation/figure_4_28_simulation_drive.csv', 'data/dissertation/figure_4_28_simulation_drive.json',
    'data/dissertation/figure_4_29_simulation_drive.csv', 'data/dissertation/figure_4_29_simulation_drive.json',
    'data/dissertation/recovery_manifest.yaml', 'docs/dissertation_recovery.md',
    'docs/legacy_simulation_drive_recovery.md', 'docs/dissertation_current_depth_recovery.md')
WRAPPERS = ('README.md', 'requirements.txt')
FIGURES = (('4.28', '4_28', 119, 118, 4e-8, 178, 210), ('4.29', '4_29', 121, 120, 6e-8, 262, 126))


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024*1024), b''):
            digest.update(block)
    return digest.hexdigest()


def object_pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('duplicate JSON key')
        result[key] = value
    return result


def finite_float(value):
    result = float(value)
    if not math.isfinite(result):
        raise ValueError('nonfinite JSON number')
    return result


def loads(data):
    return json.loads(data, object_pairs_hook=object_pairs, parse_float=finite_float,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def load(path):
    return loads(Path(path).read_text())


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False)+'\n')


def clean_head(expected):
    assert HEAD is not None and re.fullmatch('[0-9a-f]{40}', expected) and expected == HEAD
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == expected
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=REPO, text=True).strip()
    subprocess.run(['git', 'merge-base', '--is-ancestor', BASE, expected], cwd=REPO, check=True)
    return expected


def canonical_hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def inspect_dataset(csv_bytes, metadata, *, csv_path, metadata_path, producer_sha256, metadata_sha256):
    """Bind saved display data, selection catalogs and qualification declarations."""
    assert metadata['schema'] == 'mhdlab-dissertation-simulation-drive-recovery-v1'
    source, context, units, output = (metadata[key] for key in ('source', 'simulation_context', 'unit_interpretation', 'output'))
    figure = next(item for item in FIGURES if item[0] == source['figure'])
    assert source['pdf_sha256'] == PDF_SHA256 and source['pdf_page'] == figure[2] and source['pdf_page_index'] == figure[3]
    assert source['native_image_size_pixels'] == [975, 975] and source['native_image_mode'] == 'RGB'
    for key in ('page_content_sha256', 'decoded_RGB_pixels_sha256', 'extracted_PNG_sha256'):
        assert re.fullmatch('[0-9a-f]{64}', source[key])
    assert context['code_label_in_dissertation'] == 'Allegra' and context['drive_shot_caption_label'] == 17133
    assert abs(context['caption_snapshot_time_s']-figure[4]) <= math.ulp(figure[4])
    for key in ('experimental_measurement', 'FLASH_result', 'original_simulation_input_array_recovered',
                'experimental_clock_alignment_established', 'time_shift_or_scale_fit_applied',
                'current_repair_or_normalization_applied', 'VUV_gate_recovered', 'snapshot_is_observed_waveform_end'):
        assert context[key] is False
    assert units['horizontal_axis_label'] == 'Time [ns]' and units['vertical_axis_label'] == 'Current [MA]'
    assert units['time_scale_to_s'] == 1e-9 and units['current_scale_to_A'] == 1e6
    assert units['original_simulation_input_normalization_verified'] is False
    assert units['negative_display_times_preserved'] is True and units['readout_bounds_clipped_to_nonnegative_current'] is False
    bounds = metadata['readout_bounds']
    assert bounds['correlated_display_bounds_only'] is True
    for key in ('independent_noise_or_confidence_interval', 'bounds_are_observed_source_support', 'physical_or_simulation_uncertainty_quantified'):
        assert bounds[key] is False
    assert output['csv_filename'] == Path(csv_path).name
    assert hashlib.sha256(csv_bytes).hexdigest() == output['csv_sha256']
    assert output['generator'] == PRODUCER and output['generator_sha256'] == producer_sha256
    reader = csv.DictReader(io.StringIO(csv_bytes.decode()))
    rows = list(reader)
    assert reader.fieldnames == output['columns'] and len(reader.fieldnames) == 22
    assert len(rows) == output['samples'] == figure[5]
    assert all(row['source_identifier'] == metadata['source_identifier'] and row['figure'] == figure[0] for row in rows)
    assert all(math.isfinite(float(row[key])) for row in rows for key in reader.fieldnames if key not in {'source_identifier', 'figure'})
    times = [float(row['time_s']) for row in rows]
    assert all(a < b for a, b in zip(times, times[1:]))
    selection = metadata['selection']
    retained = selection['retained_columns']
    excluded = selection['excluded_columns']
    kept_x = [item['pixel_x'] for item in retained]
    excluded_x = [item['pixel_x'] for item in excluded]
    roi = selection['panel_ROI_inclusive']['x']
    all_columns = set(range(roi[0], roi[1]+1))
    assert len(kept_x) == len(set(kept_x)) == len(rows) == selection['retained_count']
    assert len(excluded_x) == len(set(excluded_x)) == figure[6] == selection['excluded_count']
    assert not set(kept_x)&set(excluded_x) and set(kept_x)|set(excluded_x) == all_columns
    assert selection['catalogued_column_count'] == len(all_columns) == 388
    assert {int(row['pixel_x']) for row in rows} == set(kept_x)
    assert selection['left_display_support_clipped'] is True
    for key in ('interpolation', 'smoothing', 'extrapolation', 'endpoint_padding', 'zero_time_or_current_inserted'):
        assert selection[key] is False
    negative_times = sum(time < 0 for time in times)
    assert negative_times == 11 and float(rows[0]['left_display_clip_column']) == 1
    assert min(float(row['current_readout_lower_A']) for row in rows) < 0
    return {'source_identifier': metadata['source_identifier'], 'figure': figure[0],
        'csv_path': csv_path, 'metadata_path': metadata_path, 'csv_sha256': output['csv_sha256'],
        'metadata_sha256': metadata_sha256, 'producer_path': PRODUCER, 'producer_sha256': producer_sha256,
        'columns': reader.fieldnames, 'samples': len(rows), 'excluded_columns': len(excluded),
        'catalogued_columns': len(all_columns), 'negative_display_time_columns': negative_times,
        'negative_current_readout_lower_columns': sum(float(row['current_readout_lower_A']) < 0 for row in rows),
        'selection_sha256': canonical_hash(selection), 'calibration_sha256': canonical_hash(metadata['calibration']),
        'source': source, 'simulation_context': context, 'unit_interpretation': units,
        'time_support_ns': output['time_support_ns'], 'current_extent_MA': output['current_extent_MA'],
        'source_geometry_filename': output['source_geometry_filename'], 'source_geometry_sha256': output['source_geometry_sha256'],
        'QA_files_sha256': output['QA_files_sha256'], 'experimental_clock_alignment_established': False,
        'physical_uncertainty_established': False, 'physical_truth_validated': False}


def dataset_bindings():
    records = []
    for _, identifier, _, _, _, _, _ in FIGURES:
        csv_name = f'data/dissertation/figure_{identifier}_simulation_drive.csv'
        metadata_name = f'data/dissertation/figure_{identifier}_simulation_drive.json'
        records.append(inspect_dataset((REPO/csv_name).read_bytes(), load(REPO/metadata_name),
            csv_path=csv_name, metadata_path=metadata_name, producer_sha256=sha(REPO/PRODUCER),
            metadata_sha256=sha(REPO/metadata_name)))
    return records


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--expected-head', required=True)
    args = parser.parse_args()
    head = clean_head(args.expected_head)
    assert len(PUBLIC) == 9 and PRODUCER in PUBLIC
    for name in PUBLIC:
        path = Path(name)
        assert not path.is_absolute() and '..' not in path.parts
        assert (REPO/name).is_file() and not (REPO/name).is_symlink()
    tree = ast.parse((REPO/PRODUCER).read_text())
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom):
            assert (node.module or '').split('.')[0] not in {'mhdlab', 'tools'}
        elif isinstance(node, ast.Import):
            assert not any(alias.name.split('.')[0] in {'mhdlab', 'tools'} for alias in node.names)
    datasets = dataset_bindings()
    payload = WORK/'delivery-preparation/payload'
    assert not payload.exists() and not OUT.exists() and not OUT.with_suffix('.tar.gz').exists()
    source = payload/'source'
    source.mkdir(parents=True)
    for name in PUBLIC:
        target = source/name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(REPO/name, target)
    (source/'requirements.txt').write_text('numpy\nPyMuPDF\nPillow\nmatplotlib\n')
    (source/'README.md').write_text('''# Legacy current inset and finite-display comparison subset

Nine named public files are copied byte-for-byte. This README and the dependency
list are packaging wrappers. No additional recovery, prior suite, numerical source,
owner code or portable environment is executed during assembly.

The recovered upper-left current insets in Figs.4.28–4.29 are published legacy
Allegra simulation displays. The comparison uses C19 only on shared finite plotted
support. Source-coordinate differences and correlated display readout envelopes
do not establish a physical trigger, common diagnostic processing, experimental
uncertainty, a clock correction, an accepted FLASH drive or a physical discrepancy.
The archived reports state the exact quantities and support used.

Source hashes, full retained/excluded catalogs, QA, independent readback and
comparison inputs are retained. The original dissertation and raw native source
images/pages are excluded. A future deliberate recovery requires that original
PDF. No zero padding, extrapolated waveform or alignment fit is supplied.
''')
    save(payload/'source_file_list.json', {'byte_identical_public_files': list(PUBLIC), 'packaging_wrappers': list(WRAPPERS)})
    (payload/'source-files.sha256').write_text(''.join(f'{sha(source/name)}  {name}\n' for name in PUBLIC))
    (payload/'wrapper-files.sha256').write_text(''.join(f'{sha(source/name)}  {name}\n' for name in WRAPPERS))
    save(payload/'preparation.json', {'source_commit': head, 'base_commit': BASE, 'datasets': datasets,
        'portable_execution_performed': False, 'physical_truth_validated': False,
        'public_source_sha256': {name: sha(REPO/name) for name in PUBLIC}})
    print(json.dumps({'payload': str(payload), 'source_commit': head, 'public_files': len(PUBLIC),
        'packaging_wrappers': len(WRAPPERS), 'retained_rows': sum(item['samples'] for item in datasets)}, indent=2))


if __name__ == '__main__':
    main()
