"""Commit the bounded evidence association after its frozen data commit."""
import hashlib
import json
from pathlib import Path
import subprocess

repo = Path('/workspace/Power-Flow')
work = Path(__file__).resolve().parent
def run(*args):
    print(json.dumps(list(args)),flush=True)
    subprocess.run(args,cwd=repo,check=True)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip() == '23b6e75af7a991acfa6e22964cc156420120d4d8'
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=repo,text=True)
r = json.loads((work/'documentation-association.json').read_text())
assert r['passed'] and r['all_prior_artifacts_preserved']
paths = list(r['public_sha256'])
for path,expected in r['public_sha256'].items():
    assert hashlib.sha256((repo/path).read_bytes()).hexdigest() == expected
assert hashlib.sha256((work/'comparison-review.json').read_bytes()).hexdigest() == 'c81f6d84e9479c0bf297642522c4c449349fc0f4d82995958bdac67eccf80c51'
run('git','add','--',*paths)
run('git','diff','--cached','--check')
run('git','-c','user.name=Research Development','-c','user.email=research@local.invalid','commit','-m','Associate finite simulation-drive evidence and qualified current comparison')
run('git','show','--format=fuller','--stat','HEAD')
run('git','status','--short','--branch')
