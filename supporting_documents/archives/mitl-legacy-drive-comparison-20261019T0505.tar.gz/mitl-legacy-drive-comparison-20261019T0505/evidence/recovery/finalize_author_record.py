"""Inventory only the new simulation-drive outputs and witnessed visual review."""
import csv
import hashlib
import json
from pathlib import Path

ROOT = Path('/workspace/Power-Flow')
WORK = Path(__file__).resolve().parent
PASS = WORK.parent


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


tool = ROOT / 'tools/recover_dissertation_simulation_drive.py'
commands = [json.loads(line) for line in (PASS / 'commands.jsonl').read_text().splitlines()]
producers = [entry for entry in commands if 'tools/recover_dissertation_simulation_drive.py' in entry['command']]
assert len(producers) == 1 and producers[0]['exit_code'] == 0
assert digest(tool) == 'd529b7ef7f2765712d3dc611f783ed4afd4476c71cd263358b1660e8040a9e14'
figures = []
for figure, count in [('4_28', 178), ('4_29', 262)]:
    csv_path = ROOT / f'data/dissertation/figure_{figure}_simulation_drive.csv'
    metadata_path = csv_path.with_suffix('.json')
    metadata = json.loads(metadata_path.read_text())
    rows = list(csv.DictReader(csv_path.open()))
    assert metadata['output']['generator_sha256'] == digest(tool)
    assert metadata['output']['csv_sha256'] == digest(csv_path)
    assert b'\r' not in csv_path.read_bytes()
    assert len(rows) == metadata['output']['samples'] == count
    assert metadata['selection']['catalogued_column_count'] == 388
    geometry = WORK / metadata['output']['source_geometry_filename']
    assert digest(geometry) == metadata['output']['source_geometry_sha256']
    qa = {name: digest(WORK / name) for name in metadata['output']['QA_files_sha256']}
    assert qa == metadata['output']['QA_files_sha256']
    figures.append({'figure': metadata['source']['figure'], 'source_identifier': metadata['source_identifier'],
                    'csv': str(csv_path.relative_to(ROOT)), 'csv_sha256': digest(csv_path),
                    'metadata': str(metadata_path.relative_to(ROOT)), 'metadata_sha256': digest(metadata_path),
                    'samples': len(rows), 'excluded_columns': metadata['selection']['excluded_count'],
                    'catalogued_columns': metadata['selection']['catalogued_column_count'],
                    'negative_time_samples': sum(float(r['time_ns']) < 0 for r in rows),
                    'negative_current_readout_lower_samples': sum(float(r['current_readout_lower_MA']) < 0 for r in rows),
                    'time_support_ns': metadata['output']['time_support_ns'],
                    'current_extent_MA': metadata['output']['current_extent_MA'],
                    'calibration': metadata['calibration'], 'left_display_support_clipped': True,
                    'source_geometry': str(geometry), 'source_geometry_sha256': digest(geometry),
                    'QA_files_sha256': qa})
record = {'schema': 'mhdlab-simulation-drive-author-verification-v1', 'complete': True,
          'public_source': str(tool.relative_to(ROOT)), 'public_source_sha256': digest(tool),
          'source_PDF_sha256': json.loads((WORK / 'native-drive-inspection.json').read_text())['PDF_sha256'],
          'new_producer_run_count': len(producers), 'new_producer_command': producers[0],
          'visual_QA': {'both_generated_PNGs_viewed': True,
                        'findings': 'Both retained overlays follow the native red inset curves. Negative displayed times and un-clipped early current readout envelopes remain visible. No beginning or snapshot endpoint is inserted.'},
          'total_samples': sum(f['samples'] for f in figures),
          'total_excluded_columns': sum(f['excluded_columns'] for f in figures),
          'total_catalogued_columns': sum(f['catalogued_columns'] for f in figures),
          'public_metadata_schema': 'mhdlab-dissertation-simulation-drive-recovery-v1',
          'figures': figures,
          'verification_scope': 'Author output inventory and visual QA only; independent native pixel/calibration readback and source-guard controls recorded separately.',
          'limits': ['Reconstructed published legacy Allegra drive insets, distinct from the experimental Figure C.19 trace.',
                     'Literal current/time coordinates; original simulation input arrays and normalization unavailable.',
                     'Displayed time origin and experimental clock registration unknown; negative times preserved.',
                     'Left-clipped finite support and snapshot endpoints do not recover a complete pulse waveform.',
                     'Full-run and pixel/fit envelopes are correlated display readout bounds, not physical noise.',
                     'No zero insertion, endpoint padding, current repair, time fit, VUV gate or physical heating input.']}
path = WORK / 'author-verification.json'
path.write_text(json.dumps(record, indent=2, allow_nan=False)+'\n')
print(json.dumps({'record': str(path), 'record_sha256': digest(path),
                  'total_samples': record['total_samples'], 'total_excluded_columns': record['total_excluded_columns'],
                  'total_catalogued_columns': record['total_catalogued_columns'],
                  'figures': [{key: value for key, value in f.items() if key in ('figure', 'samples', 'excluded_columns', 'negative_time_samples', 'negative_current_readout_lower_samples', 'time_support_ns', 'current_extent_MA')} for f in figures]}, indent=2))
