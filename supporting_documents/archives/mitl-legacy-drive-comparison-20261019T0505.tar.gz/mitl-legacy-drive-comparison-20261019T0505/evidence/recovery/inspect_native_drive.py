"""Fresh source inspection of the two upper-left legacy simulation drive panels."""
from pathlib import Path
import hashlib
import io
import json
import numpy as np
from PIL import Image
import pymupdf

OUT = Path(__file__).resolve().parent
PDF = Path('/workspace/research_sources/smtrevor_1.pdf')
records = []
with pymupdf.open(PDF) as document:
    for figure, index, xref in [('4.28', 118, 2847), ('4.29', 120, 2870)]:
        page = document[index]
        encoded = document.extract_image(xref)['image']
        image = Image.open(io.BytesIO(encoded))
        image.crop((0, 0, 500, 490)).resize((1000, 980)).save(OUT / f'figure_{figure.replace(".", "_")}_drive_inspection.png')
        pixels = np.asarray(image)
        counts = []
        for x in range(975):
            yy = np.nonzero(np.all(pixels[:, x] == (178, 34, 34), axis=1))[0]
            if len(yy):
                counts.append([x, int(yy.min()), int(yy.max()), len(yy)])
        records.append({'figure': figure, 'page_index': index, 'xref': xref,
                        'page_text': page.get_text(), 'page_content_sha256': hashlib.sha256(page.read_contents()).hexdigest(),
                        'native_image_size': list(image.size), 'native_mode': image.mode,
                        'decoded_RGB_sha256': hashlib.sha256(image.tobytes()).hexdigest(),
                        'encoded_PNG_sha256': hashlib.sha256(encoded).hexdigest(),
                        'red_columns': counts})
record = {'PDF_sha256': hashlib.sha256(PDF.read_bytes()).hexdigest(),
          'parser_version': pymupdf.VersionBind, 'figures': records}
(OUT / 'native-drive-inspection.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'source': str(PDF), 'PDF_sha256': record['PDF_sha256'],
                  'figures': [{k:v for k,v in f.items() if k != 'red_columns'} | {'red_column_count': len(f['red_columns']), 'first': f['red_columns'][:4], 'last': f['red_columns'][-4:]} for f in records]}, indent=2))
print(Path('/workspace/research_work/mitl-upstream-status.json').read_text())
