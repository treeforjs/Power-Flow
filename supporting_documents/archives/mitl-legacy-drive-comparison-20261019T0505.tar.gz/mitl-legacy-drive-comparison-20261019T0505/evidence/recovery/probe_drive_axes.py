"""Read separately visible native tick tails and candidate red column runs."""
from pathlib import Path
import hashlib
import io
import json
import numpy as np
from PIL import Image
import pymupdf

OUT = Path(__file__).resolve().parent


def runs(indices):
    result = []
    for value in indices:
        if not result or value != result[-1][-1]+1:
            result.append([int(value)])
        else:
            result[-1].append(int(value))
    return [[r[0], r[-1]] for r in result]


records = []
with pymupdf.open('/workspace/research_sources/smtrevor_1.pdf') as document:
    for figure, xref in [('4.28', 2847), ('4.29', 2870)]:
        image = Image.open(io.BytesIO(document.extract_image(xref)['image']))
        pixels = np.asarray(image)
        horizontal = {str(y): runs([x for x in range(90, 478) if max(pixels[y, x]) < 128]) for y in range(414, 421)}
        vertical = {str(x): runs([y for y in range(18, 413) if max(pixels[y, x]) < 128]) for x in range(82, 88)}
        columns = []
        for x in range(90, 478):
            indices = np.nonzero(np.all(pixels[19:412, x] == (178, 34, 34), axis=1))[0]+19
            columns.append({'pixel_x': x, 'red_runs_y': runs(indices)})
        records.append({'figure': figure, 'horizontal_ticks': horizontal, 'vertical_ticks': vertical,
                        'candidate_columns': columns})
path = OUT / 'drive-axis-candidate-probe.json'
path.write_text(json.dumps(records, indent=2)+'\n')
print(json.dumps([{k:v for k,v in record.items() if k != 'candidate_columns'} |
                  {'nonempty_columns': sum(bool(c['red_runs_y']) for c in record['candidate_columns']),
                   'nonempty_before_zero': [c for c in record['candidate_columns'] if c['pixel_x'] <= 101 and c['red_runs_y']],
                   'nonempty_ends': [c for c in record['candidate_columns'] if c['red_runs_y']][-5:]} for record in records], indent=2))
print('probe_sha256', hashlib.sha256(path.read_bytes()).hexdigest())
