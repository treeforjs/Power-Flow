"""Associate only the new legacy-drive evidence with its existing source targets."""
import copy
import hashlib
import json
from pathlib import Path
import yaml

repo = Path('/workspace/Power-Flow')
work = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
baseline = json.loads((work/'documentation-baseline.json').read_text())
for name, expected in baseline.items():
    assert sha(repo/name) == expected, name
manifest = repo/'data/dissertation/recovery_manifest.yaml'
main = repo/'docs/dissertation_recovery.md'
depth = repo/'docs/dissertation_current_depth_recovery.md'
guide = repo/'docs/legacy_simulation_drive_recovery.md'
comparison_path = work/'comparison/artifacts/report.json'
comparison = json.loads(comparison_path.read_text())
assert sha(comparison_path) == 'a6b71d79349bb9021fb67f5101daaf01f9f03089ad04b418c04eb466576ddfba'
assert comparison['qualifications']['physical_trigger_or_clock_registration'] is False
assert comparison['qualifications']['offset_amplitude_timewarp_fit'] is False
assert [p['readout_outer_intervals']['supported_query_count'] for p in comparison['comparisons']] == [292,355,502]
assert all(p['readout_outer_intervals']['zero_excluded_query_count'] == 0 for p in comparison['comparisons'])
old_text = manifest.read_text()
before = yaml.safe_load(old_text)
prepared = old_text
datasets = []
for fig, count in [('4.28',178),('4.29',262)]:
    stem = 'figure_'+fig.replace('.','_')+'_simulation_drive'
    mpath = repo/'data/dissertation'/f'{stem}.json'
    m = json.loads(mpath.read_text())
    csv = repo/'data/dissertation'/m['output']['csv_filename']
    assert m['source']['figure'] == fig
    assert m['output']['samples'] == count
    assert m['output']['csv_sha256'] == sha(csv)
    assert m['simulation_context']['experimental_clock_alignment_established'] is False
    assert m['simulation_context']['original_simulation_input_array_recovered'] is False
    assert m['unit_interpretation']['original_simulation_input_normalization_verified'] is False
    artifact = {
        'file':csv.name, 'metadata':mpath.name,
        'generator':m['output']['generator'], 'status':'digitized_published_simulation',
        'csv_sha256':sha(csv),
        'content':f'{count} correlated native columns of the finite upper-left simulation-current display',
        'caption_snapshot_time_s':m['simulation_context']['caption_snapshot_time_s'],
        'time_support_s':m['output']['time_support_s'],
        'current_extent_MA':m['output']['current_extent_MA'],
        'horizontal_axis_label':m['unit_interpretation']['horizontal_axis_label'],
        'vertical_axis_label':m['unit_interpretation']['vertical_axis_label'],
        'original_input_array_recovered':False, 'original_input_normalization_verified':False,
        'experimental_clock_alignment_established':False,
        'left_display_support_clipped':True, 'negative_display_times_preserved':True,
        'candidate_columns':388, 'excluded_columns':m['selection']['excluded_count'],
        'digitization_estimates':{
            'time_plus_minus_ns':2*m['calibration']['time']['slope'],
            'current_recipe':m['readout_bounds']['current_recipe'],
            'meaning':'Correlated display readout bounds only, not physical uncertainty or observed support.'}}
    identifier = 'fig_'+fig.replace('.','_')
    start = prepared.index('- id: '+identifier+'\n')
    end = prepared.index('\n- id: ',start+1)
    block = prepared[start:end]
    assert stem not in block
    fragment = yaml.safe_dump({'recovered_artifacts':[artifact]},sort_keys=False,allow_unicode=True,width=108)
    fragment = fragment[len('recovered_artifacts:\n'):]
    fragment = ''.join('  '+line+'\n' for line in fragment.splitlines())
    assert block.count('  still_pending:\n') == 1
    block = block.replace('  still_pending:\n',fragment+'  still_pending:\n')
    old = '  - legacy simulation drive-current inset and magnetic gap panel\n'
    assert block.count(old) == 1
    block = block.replace(old,'  - magnetic gap panel\n  - original simulation drive input, normalization and experimental clock registration\n')
    prepared = prepared[:start]+block+prepared[end:]
    datasets.append({'figure':fig,'csv_sha256':sha(csv),'metadata_sha256':sha(mpath),'new_artifact':artifact})
after = yaml.safe_load(prepared)
assert before['source'] == after['source']
assert len(before['reconstruction_targets']) == len(after['reconstruction_targets'])
changed = []
for old,new in zip(before['reconstruction_targets'],after['reconstruction_targets']):
    assert old['id'] == new['id']
    if old != new:
        assert old['id'] in ('fig_4_28','fig_4_29')
        restored = copy.deepcopy(new)
        assert restored['recovered_artifacts'][:-1] == old['recovered_artifacts']
        restored['recovered_artifacts'] = old['recovered_artifacts']
        restored['still_pending'] = old['still_pending']
        assert restored == old
        changed.append(old['id'])
assert changed == ['fig_4_28','fig_4_29']
text = main.read_text()
old = 'temperatures, J_z depth profiles and Fig. 4.30 EM width profiles partially recovered; drive insets and magnetic gap panels pending'
assert text.count(old) == 1
text = text.replace(old,'temperatures, J_z depth profiles, finite drive insets and Fig. 4.30 EM width profiles partially recovered; magnetic gap panels pending')
old = 'their magnetic gap panels and legacy simulation drive insets remain pending.'
assert text.count(old) == 1
text = text.replace(old,'their magnetic gap panels remain pending. The finite simulation-drive insets are recovered below.')
marker = '## Recovered electromagnetic width profiles'
assert text.count(marker) == 1
section = '''## Recovered legacy simulation-current insets

The upper-left panels of Figs. 4.28 and 4.29 now supply 178 and 262 native current columns, respectively. Their finite displayed time supports are -2.5–39.642857 ns and -2.5–59.642857 ns. Negative displayed times, the clipped beginning and finite endpoints are preserved; neither snapshot label supplies a missing waveform endpoint. The [recovery guide](legacy_simulation_drive_recovery.md) links the CSVs and source metadata, and explains independent tick calibration and correlated display bounds.

A finite-support comparison with the published shot 17133 current in Fig. C.19 gives a maximum central piecewise-linear difference of about 16.2914 kA on literal plotted coordinates. Conservative outer readout intervals exclude no zero difference at the 355 and 502 supported comparison queries. That is limited non-exclusion by estimated display boxes, not a proof of continuous or joint agreement. Original simulation input arrays, normalization and physical clock registration remain unresolved; no drive correction or heating input is inferred.

'''
text = text.replace(marker,section+marker)
depth_text = depth.read_text()
old = 'magnetic gap panels and legacy simulation drive insets remain pending.'
assert depth_text.count(old) == 1
depth_text = depth_text.replace(old,'magnetic gap panels remain pending. The [finite simulation-drive insets](legacy_simulation_drive_recovery.md) are separately recovered; original inputs and physical clock registration remain unresolved.')
guide_text = guide.read_text()
assert '## Comparison on literal plotted coordinates' not in guide_text
guide_text += '''
## Comparison on literal plotted coordinates

The companion verification handoff retains a standalone comparison script,
six exact CSV/JSON inputs, a difference table and PNG/PDF figures. It compares
piecewise-linear displayed curves only on their shared finite support. It
performs no time shift, amplitude fit, time warp or physical registration.
For the central interpolants, extrema are evaluated at every union knot and
overlap endpoint using exact rational arithmetic on the CSV decimal cells.

| Difference | Central overlap [ns] | Largest absolute central difference [kA] | Supported outer-envelope queries |
| --- | --- | --- | --- |
| Fig. 4.28 minus Fig. 4.29 | −2.5 to 39.642857 | 1.52107 | 292 |
| Fig. 4.28 minus C.19 | 0.749788 to 39.642857 | 16.2914 | 355 |
| Fig. 4.29 minus C.19 | 0.749788 to 59.642857 | 16.2914 | 502 |

Both legacy central interpolants lie below the C.19 central interpolant by
approximately 1.88118–16.2914 kA over their respective overlaps; the largest
absolute difference occurs near 33.74983 ns. This comparison describes the
published coordinates, not the actual simulation input or a calibrated current
error. The two legacy insets differ by at most about 1.52107 kA centrally.

For a query to be supported, each entire horizontal readout window must lie
inside its curve's retained support. The outer current interval contains the
minimum lower and maximum upper display envelopes across that window,
including internal knots. This is conservative under a monotone retiming of
piecewise-linear vertex displays within their estimated time/current boxes.
Edge queries without full support are flagged rather than clipped or extrapolated.

None of the supported finite queries excludes zero difference. This is
non-exclusion by an outer set; it proves neither continuous agreement nor the
existence of one jointly consistent retiming, and it does not register physical
clocks. Pixel/axis correlations remain unknown. The display bounds supply no
statistical likelihood, diagnostic uncertainty or justified drive repair.

The comparison report SHA-256 is
`a6b71d79349bb9021fb67f5101daaf01f9f03089ad04b418c04eb466576ddfba`.
'''
manifest.write_text(prepared)
main.write_text(text)
depth.write_text(depth_text)
guide.write_text(guide_text)
report = {
    'schema':'mitl-simulation-drive-documentation-association-v1','passed':True,
    'script_sha256':sha(__file__), 'baseline_sha256':baseline,
    'datasets':datasets,'prior_manifest_targets':len(before['reconstruction_targets']),
    'changed_existing_targets':changed,'all_prior_artifacts_preserved':True,'source_record_unchanged':True,
    'comparison_report_sha256':sha(comparison_path),
    'public_sha256':{str(p.relative_to(repo)):sha(p) for p in (manifest,main,depth,guide)},
    'numerical_recovery_comparison_or_old_suite_reexecuted':False}
(work/'documentation-association.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
