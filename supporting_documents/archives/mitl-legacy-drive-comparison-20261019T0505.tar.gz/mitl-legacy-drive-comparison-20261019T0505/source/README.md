# Legacy current inset and finite-display comparison subset

Nine named public files are copied byte-for-byte. This README and the dependency
list are packaging wrappers. No additional recovery, prior suite, numerical source,
owner code or portable environment is executed during assembly.

The recovered upper-left current insets in Figs.4.28–4.29 are published legacy
Allegra simulation displays. The comparison uses C19 only on shared finite plotted
support. Source-coordinate differences and correlated display readout envelopes
do not establish a physical trigger, common diagnostic processing, experimental
uncertainty, a clock correction, an accepted FLASH drive or a physical discrepancy.
The archived reports state the exact quantities and support used.

Source hashes, full retained/excluded catalogs, QA, independent readback and
comparison inputs are retained. The original dissertation and raw native source
images/pages are excluded. A future deliberate recovery requires that original
PDF. No zero padding, extrapolated waveform or alignment fit is supplied.
