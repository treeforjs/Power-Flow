#include "mitl_gap_orbits.hpp"

#include <cmath>
#include <iostream>
#include <limits>
#include <numbers>
#include <stdexcept>
#include <string>

namespace gap = quark::physics::gap;

namespace {

constexpr double electron_mass = 9.1093837139e-31;
constexpr double proton_mass = 1.67262192595e-27;
constexpr double elementary_charge = 1.602176634e-19;

void check(bool condition, const char* message) {
    if (!condition) {
        throw std::runtime_error(message);
    }
}

double norm(const gap::Vec3& vector) {
    return std::hypot(vector[0], vector[1], vector[2]);
}

void relative(double actual, double expected, double tolerance, const char* message) {
    check(std::isfinite(actual) && std::isfinite(expected), message);
    if (expected == 0.0) {
        check(actual == 0.0, message);
    } else {
        check(std::abs(actual / expected - 1.0) <= tolerance, message);
    }
}

void neutral_ballistic() {
    const gap::ParticleOrbit initial{{0.0, 0.0, 0.0}, {1e-24, -2e-24, 3e-24}, electron_mass, 0.0};
    const gap::Vec3 electric{1e8, -2e8, 3e8};
    const gap::Vec3 magnetic{0.5, 2.0, -3.0};
    constexpr double dt = 1e-12;
    for (bool relativistic : {false, true}) {
        const auto result = gap::orbit_step(initial, electric, magnetic, dt, relativistic);
        const double total_energy = std::hypot(electron_mass * gap::speed_of_light_m_s * gap::speed_of_light_m_s,
                                               norm(initial.momentum_kg_m_s) * gap::speed_of_light_m_s);
        for (std::size_t axis = 0; axis < 3; ++axis) {
            const double velocity = relativistic
                ? initial.momentum_kg_m_s[axis] * gap::speed_of_light_m_s * gap::speed_of_light_m_s / total_energy
                : initial.momentum_kg_m_s[axis] / electron_mass;
            relative(result.particle.position_m[axis], dt * velocity, 4e-15, "neutral displacement differs");
            check(result.particle.momentum_kg_m_s[axis] == initial.momentum_kg_m_s[axis], "neutral momentum changed");
        }
        check(result.kinetic_delta_j == 0.0, "neutral energy changed");
        check(result.electric_displacement_work_j == 0.0, "neutral electric work is nonzero");
        check(result.gyro_angle_rad == 0.0, "neutral gyro angle is nonzero");
    }
}

void uniform_electric_acceleration() {
    const gap::ParticleOrbit initial{{0.0, 0.0, 0.0}, {2e-24, -1e-24, 3e-24}, electron_mass, -elementary_charge};
    const gap::Vec3 electric{2e4, -1e4, 3e4};
    constexpr double dt = 1e-12;
    const auto result = gap::orbit_step(initial, electric, {}, dt, false);
    double expected_gain = 0.0;
    for (std::size_t axis = 0; axis < 3; ++axis) {
        const double delta_p = initial.charge_c * electric[axis] * dt;
        const double expected_p = initial.momentum_kg_m_s[axis] + delta_p;
        const double expected_x = dt * initial.momentum_kg_m_s[axis] / initial.mass_kg
            + 0.5 * dt * delta_p / initial.mass_kg;
        relative(result.particle.momentum_kg_m_s[axis], expected_p, 3e-15, "uniform E momentum differs");
        relative(result.particle.position_m[axis], expected_x, 3e-15, "uniform E position differs");
        expected_gain += delta_p * (expected_p + initial.momentum_kg_m_s[axis]) / (2.0 * initial.mass_kg);
    }
    relative(result.kinetic_delta_j, expected_gain, 2e-11, "uniform E energy differs");
    relative(result.electric_displacement_work_j, expected_gain, 3e-15, "uniform E work differs");
    check(std::abs(result.work_residual_j / expected_gain) < 2e-11, "uniform E work residual exceeds roundoff");
}

void magnetic_sign_and_frequency() {
    constexpr double speed = 1e6;
    constexpr double field = 0.7;
    constexpr double dt = 1e-12;
    for (double sign : {-1.0, 1.0}) {
        const double mass = sign < 0.0 ? electron_mass : proton_mass;
        const gap::ParticleOrbit initial{{}, {mass * speed, 0.0, 0.0}, mass, sign * elementary_charge};
        const auto result = gap::orbit_step(initial, {}, {0.0, 0.0, field}, dt, false);
        const double signed_angle = 2.0 * std::atan(initial.charge_c * field * dt / (2.0 * mass));
        relative(result.particle.momentum_kg_m_s[0] / (mass * speed), std::cos(signed_angle), 3e-15, "gyro cosine differs");
        relative(result.particle.momentum_kg_m_s[1] / (mass * speed), -std::sin(signed_angle), 3e-15, "gyro sign differs");
        relative(result.gyro_angle_rad, std::abs(initial.charge_c) * field * dt / mass, 3e-15, "gyro frequency differs");
        check(result.electric_displacement_work_j == 0.0, "magnetic field performed electric work");
    }
}

void magnetic_energy_long_run() {
    for (bool relativistic : {false, true}) {
        for (double mass : {electron_mass, proton_mass}) {
            const double velocity_scale = gap::speed_of_light_m_s * (relativistic ? 10.0 : 0.001);
            gap::ParticleOrbit particle{{}, {mass * velocity_scale, 0.3 * mass * velocity_scale, -0.2 * mass * velocity_scale},
                                       mass, mass == electron_mass ? -elementary_charge : elementary_charge};
            const double initial_norm = norm(particle.momentum_kg_m_s);
            const double initial_energy = gap::kinetic_energy_j(particle.momentum_kg_m_s, mass, relativistic);
            for (int step = 0; step < 400; ++step) {
                const auto result = gap::orbit_step(particle, {}, {0.2, -0.1, 1.0}, 1e-11, relativistic);
                check(result.magnetic_rotation_relative_error < 2e-15, "magnetic rotation norm residual too large");
                particle = result.particle;
            }
            relative(norm(particle.momentum_kg_m_s), initial_norm, 3e-13, "magnetic momentum norm drifted");
            relative(gap::kinetic_energy_j(particle.momentum_kg_m_s, mass, relativistic), initial_energy, 6e-13, "magnetic energy drifted");
            if (relativistic) {
                check(norm(gap::velocity_m_s(particle.momentum_kg_m_s, mass)) < gap::speed_of_light_m_s,
                      "relativistic speed reached c");
            }
        }
    }
}

void crossed_field_drift() {
    constexpr int steps = 80;
    constexpr double electric = 1000.0;
    constexpr double magnetic = 0.2;
    constexpr double drift = -electric / magnetic;
    for (double sign : {-1.0, 1.0}) {
        const double mass = sign < 0.0 ? electron_mass : proton_mass;
        const double frequency = elementary_charge * magnetic / mass;
        const double dt = 2.0 * std::tan(std::numbers::pi / static_cast<double>(steps)) / frequency;
        gap::ParticleOrbit particle{{}, {}, mass, sign * elementary_charge};
        for (int step = 0; step < steps; ++step) {
            particle = gap::orbit_step(particle, {electric, 0.0, 0.0}, {0.0, 0.0, magnetic}, dt, false).particle;
        }
        const double duration = static_cast<double>(steps) * dt;
        relative(particle.position_m[1] / duration, drift, 3e-13, "common E cross B drift differs");
        check(std::abs(particle.position_m[0] / duration / drift) < 3e-13, "gyro-turn transverse displacement failed to cancel");
        check(particle.position_m[2] == 0.0, "crossed fields created parallel displacement");
    }
}

void relativistic_crossed_field_refinement() {
    // v = E cross B / B^2 gives exactly E + v cross B = 0. The continuum
    // solution has constant mechanical momentum and a straight trajectory.
    // Standard relativistic Boris approaches this solution as dt is refined;
    // its intermediate gamma does not preserve the drift exactly at finite dt.
    constexpr double beta = 0.6;
    constexpr double magnetic = 1.0;
    constexpr double drift_speed = beta * gap::speed_of_light_m_s;
    const double gamma = 1.0 / std::sqrt(1.0 - beta * beta);
    const gap::Vec3 electric{drift_speed * magnetic, 0.0, 0.0};
    const gap::Vec3 field{0.0, 0.0, magnetic};
    const gap::Vec3 exact_velocity{0.0, -drift_speed, 0.0};
    check(electric[0] + exact_velocity[1] * field[2] == 0.0,
          "crossed-field initial state is not force free");

    for (double sign : {-1.0, 1.0}) {
        const double mass = sign < 0.0 ? electron_mass : proton_mass;
        const gap::ParticleOrbit initial{{}, {0.0, -mass * gamma * drift_speed, 0.0},
                                         mass, sign * elementary_charge};
        relative(gap::velocity_m_s(initial.momentum_kg_m_s, mass)[1], exact_velocity[1],
                 4e-15, "crossed-field initial relativistic velocity differs");
        const double duration = 4.0 * mass * gamma / (elementary_charge * magnetic);
        double previous_position_error = 0.0;
        double previous_momentum_error = 0.0;
        for (int steps : {12, 24, 48, 96}) {
            const double dt = duration / static_cast<double>(steps);
            auto particle = initial;
            for (int step = 0; step < steps; ++step) {
                particle = gap::orbit_step(particle, electric, field, dt, true).particle;
            }
            const gap::Vec3 position_error{
                particle.position_m[0],
                particle.position_m[1] + drift_speed * duration,
                particle.position_m[2]};
            const gap::Vec3 momentum_error{
                particle.momentum_kg_m_s[0] - initial.momentum_kg_m_s[0],
                particle.momentum_kg_m_s[1] - initial.momentum_kg_m_s[1],
                particle.momentum_kg_m_s[2] - initial.momentum_kg_m_s[2]};
            const double position_relative_error = norm(position_error) / (drift_speed * duration);
            const double momentum_relative_error = norm(momentum_error) / norm(initial.momentum_kg_m_s);
            check(std::isfinite(position_relative_error) && position_relative_error > 0.0,
                  "finite-step relativistic drift position error was hidden");
            check(std::isfinite(momentum_relative_error) && momentum_relative_error > 0.0,
                  "finite-step relativistic drift momentum error was hidden");
            if (previous_position_error > 0.0) {
                const double position_ratio = position_relative_error / previous_position_error;
                const double momentum_ratio = momentum_relative_error / previous_momentum_error;
                check(position_ratio > 0.22 && position_ratio < 0.28,
                      "relativistic drift position does not converge at second order");
                check(momentum_ratio > 0.22 && momentum_ratio < 0.28,
                      "relativistic drift momentum does not converge at second order");
            } else {
                check(position_relative_error > 1e-3 && momentum_relative_error > 1e-3,
                      "relativistic drift refinement case is numerically trivial");
            }
            previous_position_error = position_relative_error;
            previous_momentum_error = momentum_relative_error;
        }
        check(previous_position_error < 1.2e-4 && previous_momentum_error < 3e-4,
              "refined relativistic drift trajectory exceeds the verification error bound");
    }
}

void relativistic_electric_and_cold_energy() {
    const gap::ParticleOrbit initial{{}, {}, electron_mass, -elementary_charge};
    constexpr double field = 1e8;
    constexpr double dt = 1e-10;
    const auto result = gap::orbit_step(initial, {field, 0.0, 0.0}, {}, dt);
    const double expected_p = -elementary_charge * field * dt;
    const double normalized_p = expected_p / (electron_mass * gap::speed_of_light_m_s);
    const double expected_energy = (std::sqrt(1.0 + normalized_p * normalized_p) - 1.0)
        * electron_mass * gap::speed_of_light_m_s * gap::speed_of_light_m_s;
    relative(result.particle.momentum_kg_m_s[0], expected_p, 3e-15, "relativistic E momentum differs");
    relative(result.kinetic_delta_j, expected_energy, 3e-15, "relativistic energy differs");
    check(std::abs(result.work_residual_j / expected_energy) > 0.1, "finite-step work quadrature error was hidden");
    relative(result.work_residual_j, result.kinetic_delta_j - result.electric_displacement_work_j, 3e-15, "work residual identity differs");
    constexpr double cold_speed = 1e-5;
    const double cold_energy = gap::kinetic_energy_j({electron_mass * cold_speed, 0.0, 0.0}, electron_mass);
    check(cold_energy > 0.0, "cold kinetic energy cancelled to zero");
    relative(cold_energy, 0.5 * electron_mass * cold_speed * cold_speed, 3e-15, "cold kinetic energy differs");
}

void large_angle_is_not_clipped() {
    const gap::ParticleOrbit initial{{}, {1e-24, 2e-24, 3e-24}, electron_mass, -elementary_charge};
    const auto result = gap::orbit_step(initial, {}, {0.0, 0.0, 1.0}, 1.0, false);
    check(result.gyro_angle_rad > 1e10, "gyro angle was clipped");
    check(result.boris_rotation_angle_rad < std::numbers::pi, "Boris rotation angle is unbounded");
    relative(norm(result.particle.momentum_kg_m_s), norm(initial.momentum_kg_m_s), 4e-15, "large-angle rotation changed momentum norm");
}

template<class Function>
void rejected(Function operation, const char* message) {
    bool threw = false;
    try {
        operation();
    } catch (const std::invalid_argument&) {
        threw = true;
    }
    check(threw, message);
}

void invalid_inputs() {
    const gap::ParticleOrbit good{{}, {}, electron_mass, -elementary_charge};
    const double nan = std::numeric_limits<double>::quiet_NaN();
    const double infinity = std::numeric_limits<double>::infinity();
    for (double invalid_dt : {0.0, -1.0, nan, infinity}) {
        rejected([&] { (void)gap::orbit_step(good, {}, {}, invalid_dt); }, "invalid timestep accepted");
    }
    for (double invalid_mass : {0.0, -electron_mass, nan, infinity}) {
        auto bad = good;
        bad.mass_kg = invalid_mass;
        rejected([&] { (void)gap::orbit_step(bad, {}, {}, 1e-12); }, "invalid mass accepted");
        rejected([&] { (void)gap::kinetic_energy_j({}, invalid_mass); }, "energy accepted invalid mass");
    }
    auto bad = good;
    bad.position_m[0] = infinity;
    rejected([&] { (void)gap::orbit_step(bad, {}, {}, 1e-12); }, "invalid position accepted");
    bad = good;
    bad.momentum_kg_m_s[2] = nan;
    rejected([&] { (void)gap::orbit_step(bad, {}, {}, 1e-12); }, "invalid momentum accepted");
    bad = good;
    bad.charge_c = infinity;
    rejected([&] { (void)gap::orbit_step(bad, {}, {}, 1e-12); }, "invalid charge accepted");
    rejected([&] { (void)gap::orbit_step(good, {nan, 0.0, 0.0}, {}, 1e-12); }, "invalid electric field accepted");
    rejected([&] { (void)gap::orbit_step(good, {}, {0.0, infinity, 0.0}, 1e-12); }, "invalid magnetic field accepted");
}

} // namespace

int main() {
    try {
        neutral_ballistic();
        uniform_electric_acceleration();
        magnetic_sign_and_frequency();
        magnetic_energy_long_run();
        crossed_field_drift();
        relativistic_crossed_field_refinement();
        relativistic_electric_and_cold_energy();
        large_angle_is_not_clipped();
        invalid_inputs();
        std::cout << "9 orbit verification groups passed\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "Orbit verification failed: " << error.what() << '\n';
        return 1;
    }
}
