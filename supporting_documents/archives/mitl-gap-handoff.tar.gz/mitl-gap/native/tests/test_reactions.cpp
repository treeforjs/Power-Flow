// Unconditional checks: these remain active with -DNDEBUG.
// Artificial masses, states and partitions are analytic fixtures, NOT a
// supplied physical water chemistry or fragmentation distribution.
#include "mitl_gap_reactions.hpp"

#include <algorithm>
#include <cmath>
#include <functional>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>
#include <vector>

namespace gap = quark::physics::gap;
namespace {
constexpr double ev_j = 1.602176634e-19;
constexpr double light_speed = 299792458.0;
const gap::SpeciesState electron{"e", 1e-30, -1, {}, 0.0};
const gap::SpeciesState atom_a{"A:g", 2e-27, 0, {{"A", 1}}, 0.0};
const gap::SpeciesState excited_a{"A:x", 2e-27, 0, {{"A", 1}}, 2.0};
const gap::SpeciesState atom_b{"B:g", 6e-27, 0, {{"B", 1}}, 0.0};
const gap::SpeciesState molecule{"AB:g", 8e-27, 0, {{"A", 1}, {"B", 1}}, -5.0};
const gap::SpeciesState molecular_ion{"AB+:g", 8e-27 - 1e-30, 1, {{"A", 1}, {"B", 1}}, 3.0};
const gap::SpeciesState trimer{"A2B:g", 10e-27, 0, {{"A", 2}, {"B", 1}}, -8.0};

void check(bool condition, const std::string& message) {
    if (!condition) {
        throw std::runtime_error(message);
    }
}

bool close(double actual, double expected, double relative = 3e-13, double absolute = 0.0) {
    return std::abs(actual - expected) <= std::max(absolute, relative * std::max(std::abs(actual), std::abs(expected)));
}

double norm(const gap::Vec3& value) {
    return std::hypot(value[0], value[1], value[2]);
}

gap::Vec3 multiply(const gap::Vec3& value, double scale) {
    return {value[0] * scale, value[1] * scale, value[2] * scale};
}

gap::Vec3 plus(const gap::Vec3& first, const gap::Vec3& second) {
    return {first[0] + second[0], first[1] + second[1], first[2] + second[2]};
}

gap::Vec3 rotate(const gap::Vec3& value) {
    return {-value[1], value[0], value[2]};
}

template<class Exception, class Function>
void must_throw(Function&& function, const std::string& message) {
    bool caught = false;
    try {
        std::invoke(std::forward<Function>(function));
    } catch (const Exception&) {
        caught = true;
    }
    check(caught, message);
}

std::vector<gap::Vec3> com_incoming(const std::vector<gap::SpeciesState>& reactants,
                                   double relative_energy_ev, gap::Vec3 boost = {}) {
    const double first_mass = reactants[0].mass_kg;
    const double second_mass = reactants[1].mass_kg;
    const double reduced_mass = first_mass * (second_mass / (first_mass + second_mass));
    const double momentum = std::sqrt(2.0 * reduced_mass * relative_energy_ev * ev_j);
    return {plus({momentum, 0.0, 0.0}, multiply(boost, first_mass)),
            plus({-momentum, 0.0, 0.0}, multiply(boost, second_mass))};
}

gap::ReactionInput event(std::vector<gap::SpeciesState> reactants = {atom_a, atom_b},
                         std::vector<gap::SpeciesState> products = {atom_a, atom_b},
                         double relative_energy_ev = 4.0) {
    gap::ReactionInput result;
    result.reactants = std::move(reactants);
    result.products = std::move(products);
    result.incoming_momenta_kg_m_s = com_incoming(result.reactants, relative_energy_ev);
    result.jacobi_energy_fractions = {1.0};
    result.jacobi_directions = {{0.0, 1.0, 0.0}};
    result.kinematics_provenance = "Analytic deterministic conservation fixture; no physical data";
    return result;
}

double particle_kinetic(const gap::Vec3& momentum, double mass) {
    const double magnitude = norm(momentum);
    return magnitude * magnitude / (2.0 * mass);
}

void conservative(const gap::ReactionOutcome& result) {
    const double energy_scale = std::max({result.kinetic_energy_before_j,
        result.kinetic_energy_after_j, std::abs(result.energy_defect_ev) * ev_j});
    check(std::abs(result.energy_residual_j) <= 3e-13 * energy_scale, "energy ledger residual");
    double momentum_scale = norm(result.momentum_before_kg_m_s);
    for (const auto& momentum : result.outgoing_momenta_kg_m_s) {
        momentum_scale = std::max(momentum_scale, norm(momentum));
    }
    check(norm(result.momentum_residual_kg_m_s) <= 3e-13 * momentum_scale, "momentum ledger residual");
    check(close(result.outgoing_com_kinetic_energy_j, result.available_energy_j), "COM kinetic-energy ledger");
}

void test_two_body_unequal_mass() {
    const auto input = event();
    const auto result = gap::construct_reaction(input);
    check(close(particle_kinetic(result.outgoing_momenta_kg_m_s[0], atom_a.mass_kg) / ev_j, 3.0),
          "light product must carry 3 eV");
    check(close(particle_kinetic(result.outgoing_momenta_kg_m_s[1], atom_b.mass_kg) / ev_j, 1.0),
          "heavy product must carry 1 eV");
    check(result.product_state_ids == std::vector<std::string>{"A:g", "B:g"}, "product order retained");
    conservative(result);
    const auto overload = gap::construct_reaction(input.reactants, input.products,
        input.incoming_momenta_kg_m_s, input.jacobi_energy_fractions, input.jacobi_directions,
        input.kinematics_provenance);
    check(overload.outgoing_momenta_kg_m_s == result.outgoing_momenta_kg_m_s, "convenience overload agrees");
}

void test_endo_exothermic_and_moving_com() {
    for (const bool reverse : {false, true}) {
        auto input = event({electron, reverse ? excited_a : atom_a},
                           {electron, reverse ? atom_a : excited_a}, 5.0);
        input.incoming_momenta_kg_m_s = com_incoming(input.reactants, 5.0, {320.0, -120.0, 81.0});
        const auto result = gap::construct_reaction(input);
        check(close(result.energy_defect_ev, reverse ? -2.0 : 2.0), "state energy defect");
        check(close(result.available_energy_j / ev_j, reverse ? 7.0 : 3.0), "state energy transfer");
        for (std::size_t axis = 0; axis < 3; ++axis) {
            const gap::Vec3 expected{320.0, -120.0, 81.0};
            check(close(result.center_of_mass_velocity_m_s[axis], expected[axis]), "moving COM retained");
        }
        conservative(result);
    }
}

void test_three_body_fragment_recoil() {
    auto input = event({electron, molecule}, {electron, atom_a, atom_b}, 15.0);
    input.jacobi_energy_fractions = {0.6, 0.4};
    input.jacobi_directions = {{1.0, 0.0, 0.0}, {0.0, 1.0, 0.0}};
    const auto result = gap::construct_reaction(input);
    check(close(result.available_energy_j / ev_j, 10.0), "dissociation threshold removed");
    const double mass_heavy = atom_a.mass_kg + atom_b.mass_kg;
    const double expected_electron_energy = 6.0 * mass_heavy / (electron.mass_kg + mass_heavy);
    check(close(particle_kinetic(result.outgoing_momenta_kg_m_s[0], electron.mass_kg) / ev_j,
                expected_electron_energy), "electron mode is not electron kinetic fraction");
    const auto velocity_a = multiply(result.outgoing_momenta_kg_m_s[1], 1.0 / atom_a.mass_kg);
    const auto velocity_b = multiply(result.outgoing_momenta_kg_m_s[2], 1.0 / atom_b.mass_kg);
    const auto relative = plus(velocity_a, multiply(velocity_b, -1.0));
    const double reduced = atom_a.mass_kg * (atom_b.mass_kg / mass_heavy);
    check(close(0.5 * reduced * norm(relative) * norm(relative) / ev_j, 4.0), "heavy-pair relative energy");
    conservative(result);
}

void test_secondary_electron_and_four_products() {
    auto ionization = event({electron, molecule}, {electron, electron, molecular_ion}, 20.0);
    ionization.incoming_momenta_kg_m_s = com_incoming(ionization.reactants, 20.0, {20.0, 30.0, 40.0});
    ionization.jacobi_energy_fractions = {0.8, 0.2};
    ionization.jacobi_directions = {{0.0, 1.0, 0.0}, {1.0, 0.0, 0.0}};
    const auto ionized = gap::construct_reaction(ionization);
    check(close(ionized.available_energy_j / ev_j, 12.0), "parent ionization energy");
    check(ionized.product_state_ids == std::vector<std::string>{"e", "e", "AB+:g"}, "two electron products retained");
    conservative(ionized);
    auto breakup = event({electron, trimer}, {electron, atom_a, atom_a, atom_b}, 20.0);
    breakup.jacobi_energy_fractions = {0.5, 0.2, 0.3};
    breakup.jacobi_directions = {{1.0, 0.0, 0.0}, {0.0, 1.0, 0.0}, {0.0, 0.0, 1.0}};
    const auto four = gap::construct_reaction(breakup);
    check(close(four.available_energy_j / ev_j, 12.0), "four-product available energy");
    conservative(four);
}

void test_frames_and_product_order() {
    auto input = event({electron, molecule}, {electron, atom_a, atom_b}, 15.0);
    input.jacobi_energy_fractions = {0.6, 0.4};
    input.jacobi_directions = {{1.0, 0.0, 0.0}, {0.0, 1.0, 0.0}};
    const auto base = gap::construct_reaction(input);
    auto rotated = input;
    for (auto& momentum : rotated.incoming_momenta_kg_m_s) { momentum = rotate(momentum); }
    for (auto& direction : rotated.jacobi_directions) { direction = rotate(direction); }
    const auto rotated_result = gap::construct_reaction(rotated);
    auto boosted = input;
    const gap::Vec3 boost{400.0, -200.0, 80.0};
    for (std::size_t index = 0; index < 2; ++index) {
        boosted.incoming_momenta_kg_m_s[index] = plus(input.incoming_momenta_kg_m_s[index],
            multiply(boost, input.reactants[index].mass_kg));
    }
    const auto boosted_result = gap::construct_reaction(boosted);
    for (std::size_t index = 0; index < input.products.size(); ++index) {
        const auto expected_rotation = rotate(base.outgoing_momenta_kg_m_s[index]);
        const auto expected_boost = plus(base.outgoing_momenta_kg_m_s[index],
            multiply(boost, input.products[index].mass_kg));
        for (std::size_t axis = 0; axis < 3; ++axis) {
            check(close(rotated_result.outgoing_momenta_kg_m_s[index][axis], expected_rotation[axis], 3e-13, 1e-38),
                  "rotation covariance");
            check(close(boosted_result.outgoing_momenta_kg_m_s[index][axis], expected_boost[axis], 3e-13, 1e-38),
                  "Galilean covariance");
        }
    }
    conservative(boosted_result);
    std::swap(input.products[0], input.products[1]);
    const auto permuted = gap::construct_reaction(input);
    check(permuted.product_state_ids[0] == "A:g" && permuted.product_state_ids[1] == "e", "order must not be sorted");
    check(!close(norm(permuted.outgoing_momenta_kg_m_s[1]), norm(base.outgoing_momenta_kg_m_s[0]), 1e-8),
          "the same fractions describe different Jacobi modes after permutation");
    conservative(permuted);
}

void test_threshold_and_speed_limits() {
    auto input = event({electron, molecule}, {electron, atom_a, atom_b}, 5.0 - 1e-8);
    input.jacobi_energy_fractions = {0.6, 0.4};
    input.jacobi_directions = {{1.0, 0.0, 0.0}, {0.0, 1.0, 0.0}};
    must_throw<gap::InaccessibleReactionError>([&] { (void)gap::construct_reaction(input); }, "subthreshold event rejected");
    input.incoming_momenta_kg_m_s = com_incoming(input.reactants, 5.0);
    const auto at_threshold = gap::construct_reaction(input);
    check(at_threshold.available_energy_j <= 64.0 * std::numeric_limits<double>::epsilon() * 5.0 * ev_j,
          "no arbitrary physical energy floor at threshold");
    input.incoming_momenta_kg_m_s = com_incoming(input.reactants, 5.0 + 1e-8);
    check(close(gap::construct_reaction(input).available_energy_j / ev_j, 1e-8, 1e-6), "above-threshold energy retained");
    auto fast = event();
    fast.incoming_momenta_kg_m_s = {{atom_a.mass_kg * 0.06 * light_speed, 0.0, 0.0}, {0.0, 0.0, 0.0}};
    must_throw<gap::NonrelativisticLimitError>([&] { (void)gap::construct_reaction(fast); }, "incoming speed cap");
    auto exothermic = event({electron, excited_a}, {electron, atom_a}, 0.0);
    exothermic.max_nonrel_beta = 0.001;
    must_throw<gap::NonrelativisticLimitError>([&] { (void)gap::construct_reaction(exothermic); }, "outgoing speed cap");
}

void test_accepted_mass_roundoff_with_large_com_boost() {
    for (const double sign : {-1.0, 1.0}) {
        auto rounded_a = atom_a;
        rounded_a.state_id = sign < 0.0 ? "A:negative_mass_roundoff" : "A:positive_mass_roundoff";
        rounded_a.mass_kg *= 1.0 + sign * 5e-13;
        auto input = event({atom_a, atom_b}, {rounded_a, atom_b}, 4.0);
        input.incoming_momenta_kg_m_s = com_incoming(input.reactants, 4.0, {8e6, -3e6, 2e6});
        const auto result = gap::construct_reaction(input);
        const long double mass_in = static_cast<long double>(atom_a.mass_kg) + atom_b.mass_kg;
        const long double mass_out = static_cast<long double>(rounded_a.mass_kg) + atom_b.mass_kg;
        long double p_squared = 0.0L;
        for (const double component : result.momentum_before_kg_m_s) {
            p_squared += static_cast<long double>(component) * component;
        }
        const long double expected = 0.5L * p_squared * (mass_out - mass_in) / (mass_in * mass_out);
        check(close(result.bulk_mass_roundoff_correction_j, static_cast<double>(expected), 3e-13),
              "accepted mass-roundoff bulk correction has correct magnitude/sign");
        check(close(result.available_energy_j - result.incoming_com_kinetic_energy_j,
                    result.bulk_mass_roundoff_correction_j, 3e-8), "bulk correction enters available COM energy");
        check(std::abs(result.energy_residual_j) < 0.01 * std::abs(result.bulk_mass_roundoff_correction_j),
              "moving-COM ledger residual is much smaller than the required mass-roundoff correction");
        conservative(result);
    }
}

void test_tiny_absolute_threshold_has_no_joule_floor() {
    auto tiny_excited = atom_a;
    tiny_excited.state_id = "A:tiny_absolute_excitation";
    tiny_excited.common_energy_ev = 1e-100;
    auto input = event({atom_a, atom_b}, {tiny_excited, atom_b}, 2e-100);
    const auto result = gap::construct_reaction(input);
    check(close(result.available_energy_j / ev_j, 1e-100), "tiny total-scale available energy retained");
    check(result.available_energy_j > 0.0, "tiny energies must not be replaced by zero");
    conservative(result);
    input.incoming_momenta_kg_m_s = com_incoming(input.reactants, 0.5e-100);
    must_throw<gap::InaccessibleReactionError>([&] { (void)gap::construct_reaction(input); },
        "tiny total-scale inaccessible threshold must still reject");
}

void test_invalid_inputs() {
    const auto reject = [](gap::ReactionInput input, const std::function<void(gap::ReactionInput&)>& change,
                           const std::string& message) {
        change(input);
        must_throw<std::invalid_argument>([&] { (void)gap::construct_reaction(input); }, message);
    };
    const auto base = event();
    reject(base, [](auto& x) { x.reactants.pop_back(); }, "reactant count");
    reject(base, [](auto& x) { x.products.pop_back(); }, "product count");
    reject(base, [](auto& x) { x.incoming_momenta_kg_m_s.pop_back(); }, "momentum count");
    reject(base, [](auto& x) { x.kinematics_provenance.clear(); }, "missing provenance");
    reject(base, [](auto& x) { x.reactants[0].state_id = " "; }, "empty state label");
    reject(base, [](auto& x) { x.products[0].common_energy_ev = 1.0; }, "inconsistent canonical ID");
    reject(base, [](auto& x) { x.products[0] = atom_b; }, "nuclei violation");
    reject(base, [](auto& x) { x.products[0].state_id = "A:charged"; x.products[0].charge_number = 1; }, "charge violation");
    reject(base, [](auto& x) { x.products[0].state_id = "A:wrongmass"; x.products[0].mass_kg *= 2.0; }, "mass violation");
    reject(base, [](auto& x) { x.reactants[0].mass_kg = 0.0; }, "massless particles unsupported");
    reject(base, [](auto& x) { x.reactants[0].common_energy_ev = std::numeric_limits<double>::infinity(); }, "nonfinite energy");
    reject(base, [](auto& x) { x.reactants[0].nuclei["A"] = 0; }, "nonpositive nuclear count");
    reject(base, [](auto& x) { x.jacobi_energy_fractions.clear(); }, "fraction count");
    reject(base, [](auto& x) { x.jacobi_energy_fractions[0] = -1.0; }, "negative fraction");
    reject(base, [](auto& x) { x.jacobi_energy_fractions[0] = 0.5; }, "fraction sum");
    reject(base, [](auto& x) { x.jacobi_energy_fractions[0] = std::numeric_limits<double>::quiet_NaN(); }, "nonfinite fraction");
    reject(base, [](auto& x) { x.jacobi_directions[0] = {0.0, 0.0, 0.0}; }, "zero direction");
    reject(base, [](auto& x) { x.jacobi_directions[0] = {0.0, 2.0, 0.0}; }, "nonunit direction");
    reject(base, [](auto& x) { x.jacobi_directions[0][0] = std::numeric_limits<double>::quiet_NaN(); }, "nonfinite direction");
    reject(base, [](auto& x) { x.incoming_momenta_kg_m_s[0][0] = std::numeric_limits<double>::quiet_NaN(); }, "nonfinite momentum");
    for (const double cap : {0.0, -0.1, 0.051, 0.1, 1.0, std::numeric_limits<double>::quiet_NaN()}) {
        reject(base, [cap](auto& x) { x.max_nonrel_beta = cap; }, "invalid speed cap");
    }
}
} // namespace

int main() {
    try {
        test_two_body_unequal_mass();
        test_endo_exothermic_and_moving_com();
        test_three_body_fragment_recoil();
        test_secondary_electron_and_four_products();
        test_frames_and_product_order();
        test_threshold_and_speed_limits();
        test_accepted_mass_roundoff_with_large_com_boost();
        test_tiny_absolute_threshold_has_no_joule_floor();
        test_invalid_inputs();
        std::cout << "All native reaction kinematics checks passed\n";
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "Native reaction check failed: " << error.what() << '\n';
        return 1;
    }
}
