#pragma once

// Independent public C++20 reference kinematics. This header contains no
// electrothermal implementation, water mechanism, or differential sampler.
// Fractions and directions MUST come from an externally supplied channel
// kernel with its own validity range and provenance.

#include "mitl_gap_orbits.hpp"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <limits>
#include <map>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

namespace quark::physics::gap {

struct SpeciesState {
    // Canonical opaque state ID. Common energy includes formation/binding and
    // internal excitation ONCE, on the same reference for every state.
    std::string state_id;
    double mass_kg{};
    int charge_number{};
    std::map<std::string, int> nuclei;
    double common_energy_ev{};
};

struct ReactionInput {
    std::vector<SpeciesState> reactants; // exactly two massive particles
    std::vector<SpeciesState> products;  // at least two; ordering is significant
    std::vector<Vec3> incoming_momenta_kg_m_s;
    // Mode i separates product i from COM(products i+1,...,N-1). This is NOT
    // the kinetic-energy fraction carried by product i itself.
    std::vector<double> jacobi_energy_fractions;
    std::vector<Vec3> jacobi_directions;
    std::string kinematics_provenance; // required; no inferred distributions
    double max_nonrel_beta{0.05}; // may tighten, but not exceed qualified limit 0.05
};

struct ReactionOutcome {
    std::vector<std::string> product_state_ids;
    std::vector<Vec3> outgoing_momenta_kg_m_s;
    double available_energy_j{}; // total available COM kinetic energy
    double incoming_com_kinetic_energy_j{};
    double outgoing_com_kinetic_energy_j{};
    double kinetic_energy_before_j{};
    double kinetic_energy_after_j{};
    double internal_energy_before_j{};
    double internal_energy_after_j{};
    double total_energy_before_j{};
    double total_energy_after_j{};
    double energy_defect_ev{}; // products minus reactants
    double energy_residual_j{}; // kinetic change + chemical energy defect
    Vec3 momentum_before_kg_m_s{};
    Vec3 momentum_after_kg_m_s{};
    Vec3 momentum_residual_kg_m_s{};
    double mass_residual_kg{};
    Vec3 center_of_mass_velocity_m_s{};
    std::vector<double> jacobi_energy_fractions;
    std::vector<Vec3> jacobi_directions;
    double maximum_incoming_beta{};
    double maximum_outgoing_beta{};
    double threshold_roundoff_correction_j{};
    double bulk_mass_roundoff_correction_j{};
    std::string kinematics_provenance;
};

class InaccessibleReactionError : public std::domain_error {
public:
    using std::domain_error::domain_error;
};

class NonrelativisticLimitError : public std::domain_error {
public:
    using std::domain_error::domain_error;
};

namespace reaction_detail {

inline constexpr long double elementary_charge_c = 1.602176634e-19L;
inline constexpr long double light_speed_m_s = 299792458.0L;
inline constexpr long double mass_relative_tolerance = 1e-12L;
inline constexpr long double normalization_tolerance = 1e-12L;
inline constexpr double maximum_qualified_nonrel_beta = 0.05;
inline constexpr long double roundoff_factor =
    64.0L * static_cast<long double>(std::numeric_limits<double>::epsilon());

inline bool finite(const Vec3& value) {
    return std::all_of(value.begin(), value.end(), [](double item) { return std::isfinite(item); });
}

inline bool valid_label(std::string_view value) {
    constexpr std::string_view whitespace = " \t\r\n\f\v";
    return !value.empty() && whitespace.find(value.front()) == std::string_view::npos
        && whitespace.find(value.back()) == std::string_view::npos;
}

inline double checked_double(long double value, const char* label) {
    if (!std::isfinite(value)
        || std::abs(value) > static_cast<long double>(std::numeric_limits<double>::max())) {
        throw std::invalid_argument(std::string("nonfinite/out-of-range ") + label);
    }
    return static_cast<double>(value);
}

inline long double dot(const Vec3& first, const Vec3& second) {
    long double result = 0.0L;
    for (std::size_t axis = 0; axis < 3; ++axis) {
        result += static_cast<long double>(first[axis]) * static_cast<long double>(second[axis]);
    }
    return result;
}

inline Vec3 scale(const Vec3& vector, long double factor) {
    Vec3 result{};
    for (std::size_t axis = 0; axis < 3; ++axis) {
        result[axis] = checked_double(static_cast<long double>(vector[axis]) * factor, "vector component");
    }
    return result;
}

inline Vec3 add(const Vec3& first, const Vec3& second) {
    Vec3 result{};
    for (std::size_t axis = 0; axis < 3; ++axis) {
        result[axis] = checked_double(static_cast<long double>(first[axis]) + second[axis], "vector sum");
    }
    return result;
}

inline Vec3 subtract(const Vec3& first, const Vec3& second) {
    return add(first, scale(second, -1.0L));
}

inline Vec3 vector_sum(const std::vector<Vec3>& vectors) {
    Vec3 result{};
    for (std::size_t axis = 0; axis < 3; ++axis) {
        long double sum = 0.0L;
        for (const auto& vector : vectors) {
            sum += vector[axis];
        }
        result[axis] = checked_double(sum, "summed momentum");
    }
    return result;
}

inline long double total_mass(const std::vector<SpeciesState>& states, std::size_t begin = 0) {
    long double result = 0.0L;
    for (std::size_t index = begin; index < states.size(); ++index) {
        result += states[index].mass_kg;
    }
    return result;
}

inline long double internal_energy_ev(const std::vector<SpeciesState>& states) {
    long double result = 0.0L;
    for (const auto& state : states) {
        result += state.common_energy_ev;
    }
    return result;
}

inline long double kinetic_energy(const std::vector<Vec3>& momenta,
                                  const std::vector<SpeciesState>& states) {
    long double result = 0.0L;
    for (std::size_t index = 0; index < states.size(); ++index) {
        result += dot(momenta[index], momenta[index]) / (2.0L * states[index].mass_kg);
    }
    return result;
}

inline void validate_states(const std::vector<SpeciesState>& states,
                            std::map<std::string, SpeciesState>& canonical) {
    for (const auto& state : states) {
        if (!valid_label(state.state_id)) {
            throw std::invalid_argument("state_id must be nonempty without surrounding whitespace");
        }
        if (!std::isfinite(state.mass_kg) || state.mass_kg <= 0.0
            || !std::isfinite(state.common_energy_ev)) {
            throw std::invalid_argument("state masses must be positive finite and energies finite; photons unsupported");
        }
        for (const auto& [nucleus, count] : state.nuclei) {
            if (!valid_label(nucleus) || count <= 0) {
                throw std::invalid_argument("nuclear identities must be nonempty and their counts positive");
            }
        }
        const auto [found, inserted] = canonical.emplace(state.state_id, state);
        if (!inserted) {
            const auto& previous = found->second;
            if (state.mass_kg != previous.mass_kg || state.charge_number != previous.charge_number
                || state.nuclei != previous.nuclei || state.common_energy_ev != previous.common_energy_ev) {
                throw std::invalid_argument("canonical state_id has inconsistent mass, charge, nuclei or energy");
            }
        }
    }
}

inline std::map<std::string, std::int64_t> nuclear_totals(const std::vector<SpeciesState>& states) {
    std::map<std::string, std::int64_t> result;
    for (const auto& state : states) {
        for (const auto& [nucleus, count] : state.nuclei) {
            auto& total = result[nucleus];
            if (total > std::numeric_limits<std::int64_t>::max() - count) {
                throw std::invalid_argument("nuclear count overflow");
            }
            total += count;
        }
    }
    return result;
}

inline std::int64_t total_charge(const std::vector<SpeciesState>& states) {
    std::int64_t result = 0;
    for (const auto& state : states) {
        const auto charge = static_cast<std::int64_t>(state.charge_number);
        if ((charge > 0 && result > std::numeric_limits<std::int64_t>::max() - charge)
            || (charge < 0 && result < std::numeric_limits<std::int64_t>::min() - charge)) {
            throw std::invalid_argument("charge count overflow");
        }
        result += charge;
    }
    return result;
}

inline double check_beta(const std::vector<Vec3>& velocities, double cap, const char* label) {
    long double maximum = 0.0L;
    for (const auto& velocity : velocities) {
        const long double speed = std::sqrt(dot(velocity, velocity));
        maximum = std::max(maximum, speed / light_speed_m_s);
    }
    if (!std::isfinite(maximum) || maximum > static_cast<long double>(cap)) {
        throw NonrelativisticLimitError(std::string(label) + " speed exceeds max_nonrel_beta; relativistic reactions unsupported");
    }
    return checked_double(maximum, "maximum beta");
}

} // namespace reaction_detail

// Deterministic constructor only. Caller must select reactions using valid
// integral cross sections and provide a valid differential branch kernel.
// No physical isotropy, equipartition, phase-space law or secondary-electron
// distribution is implied. Photons/surface reactions are not represented.
inline ReactionOutcome construct_reaction(const ReactionInput& input) {
    using namespace reaction_detail;
    if (input.reactants.size() != 2 || input.products.size() < 2) {
        throw std::invalid_argument("exactly two reactants and at least two massive products are required");
    }
    if (input.incoming_momenta_kg_m_s.size() != 2) {
        throw std::invalid_argument("incoming momenta must match the two ordered reactants");
    }
    if (!valid_label(input.kinematics_provenance)) {
        throw std::invalid_argument("explicit nonempty kinematics_provenance is required");
    }
    if (!std::isfinite(input.max_nonrel_beta) || input.max_nonrel_beta <= 0.0
        || input.max_nonrel_beta > maximum_qualified_nonrel_beta) {
        throw std::invalid_argument("max_nonrel_beta must be finite with 0 < max_nonrel_beta <= 0.05");
    }
    std::map<std::string, SpeciesState> canonical;
    validate_states(input.reactants, canonical);
    validate_states(input.products, canonical);
    if (nuclear_totals(input.reactants) != nuclear_totals(input.products)) {
        throw std::invalid_argument("reaction does not conserve nuclei");
    }
    if (total_charge(input.reactants) != total_charge(input.products)) {
        throw std::invalid_argument("reaction does not conserve charge");
    }
    const long double mass_in = total_mass(input.reactants);
    const long double mass_out = total_mass(input.products);
    const long double mass_residual = mass_out - mass_in;
    if (std::abs(mass_residual) > mass_relative_tolerance * std::max(mass_in, mass_out)) {
        throw std::invalid_argument("reaction does not conserve nonrelativistic additive mass");
    }
    const std::size_t mode_count = input.products.size() - 1;
    if (input.jacobi_energy_fractions.size() != mode_count || input.jacobi_directions.size() != mode_count) {
        throw std::invalid_argument("Jacobi fractions and directions must each have N_products-1 entries");
    }
    long double fraction_sum = 0.0L;
    for (const double fraction : input.jacobi_energy_fractions) {
        if (!std::isfinite(fraction) || fraction < 0.0) {
            throw std::invalid_argument("Jacobi fractions must be finite and nonnegative");
        }
        fraction_sum += fraction;
    }
    if (std::abs(fraction_sum - 1.0L) > normalization_tolerance) {
        throw std::invalid_argument("Jacobi fractions must sum to one within 1e-12");
    }
    std::vector<double> fractions;
    std::vector<Vec3> directions;
    fractions.reserve(mode_count);
    directions.reserve(mode_count);
    for (std::size_t index = 0; index < mode_count; ++index) {
        fractions.push_back(checked_double(input.jacobi_energy_fractions[index] / fraction_sum, "energy fraction"));
        const auto& direction = input.jacobi_directions[index];
        if (!finite(direction)) {
            throw std::invalid_argument("Jacobi directions must be finite unit vectors");
        }
        const long double norm = std::sqrt(dot(direction, direction));
        if (std::abs(norm - 1.0L) > normalization_tolerance) {
            throw std::invalid_argument("Jacobi directions must be unit vectors within 1e-12");
        }
        directions.push_back(scale(direction, 1.0L / norm));
    }
    std::vector<Vec3> incoming_velocities;
    incoming_velocities.reserve(2);
    for (std::size_t index = 0; index < 2; ++index) {
        if (!finite(input.incoming_momenta_kg_m_s[index])) {
            throw std::invalid_argument("incoming momenta must be finite");
        }
        incoming_velocities.push_back(scale(input.incoming_momenta_kg_m_s[index], 1.0L / input.reactants[index].mass_kg));
    }
    const double incoming_beta = check_beta(incoming_velocities, input.max_nonrel_beta, "incoming");
    const Vec3 momentum_before = vector_sum(input.incoming_momenta_kg_m_s);
    const Vec3 velocity_com_in = scale(momentum_before, 1.0L / mass_in);
    const Vec3 velocity_com_out = scale(momentum_before, 1.0L / mass_out);
    const Vec3 relative_in = subtract(incoming_velocities[0], incoming_velocities[1]);
    const long double reduced_mass_in = input.reactants[0].mass_kg * (input.reactants[1].mass_kg / mass_in);
    const long double com_energy_before = 0.5L * reduced_mass_in * dot(relative_in, relative_in);
    const long double internal_before_ev = internal_energy_ev(input.reactants);
    const long double internal_after_ev = internal_energy_ev(input.products);
    const long double defect_ev = internal_after_ev - internal_before_ev;
    const long double defect_j = defect_ev * elementary_charge_c;
    // Only correct the bulk kinetic contribution of accepted floating-point
    // mass roundoff; this is not support for a physical nuclear mass defect.
    const long double bulk_mass_correction =
        0.5L * mass_in * dot(velocity_com_in, velocity_com_in) * (mass_residual / mass_out);
    long double available = com_energy_before - defect_j + bulk_mass_correction;
    const long double threshold_tolerance = roundoff_factor
        * std::max({com_energy_before, std::abs(defect_j), std::abs(bulk_mass_correction)});
    if (available < -threshold_tolerance) {
        throw InaccessibleReactionError("incoming relative energy cannot access specified product states");
    }
    const long double threshold_roundoff = std::max(0.0L, -available);
    available = std::max(0.0L, available);

    std::vector<Vec3> com_velocities(input.products.size());
    Vec3 group_velocity{};
    for (std::size_t index = 0; index < mode_count; ++index) {
        const long double remaining_mass = total_mass(input.products, index + 1);
        const long double group_mass = input.products[index].mass_kg + remaining_mass;
        const long double reduced_mass = input.products[index].mass_kg * (remaining_mass / group_mass);
        const long double relative_speed = std::sqrt(2.0L * available * fractions[index] / reduced_mass);
        const Vec3 relative = scale(directions[index], relative_speed);
        com_velocities[index] = add(group_velocity, scale(relative, remaining_mass / group_mass));
        group_velocity = subtract(group_velocity, scale(relative, input.products[index].mass_kg / group_mass));
    }
    com_velocities.back() = group_velocity;
    std::vector<Vec3> velocities_out;
    std::vector<Vec3> momenta_out;
    std::vector<Vec3> momenta_com;
    std::vector<std::string> product_ids;
    velocities_out.reserve(input.products.size());
    momenta_out.reserve(input.products.size());
    momenta_com.reserve(input.products.size());
    product_ids.reserve(input.products.size());
    for (std::size_t index = 0; index < input.products.size(); ++index) {
        velocities_out.push_back(add(com_velocities[index], velocity_com_out));
        momenta_out.push_back(scale(velocities_out.back(), input.products[index].mass_kg));
        momenta_com.push_back(scale(com_velocities[index], input.products[index].mass_kg));
        product_ids.push_back(input.products[index].state_id);
    }
    const double outgoing_beta = check_beta(velocities_out, input.max_nonrel_beta, "outgoing");
    const Vec3 momentum_after = vector_sum(momenta_out);
    const long double kinetic_before = kinetic_energy(input.incoming_momenta_kg_m_s, input.reactants);
    const long double kinetic_after = kinetic_energy(momenta_out, input.products);
    const long double internal_before = internal_before_ev * elementary_charge_c;
    const long double internal_after = internal_after_ev * elementary_charge_c;
    ReactionOutcome result;
    result.product_state_ids = std::move(product_ids);
    result.outgoing_momenta_kg_m_s = std::move(momenta_out);
    result.available_energy_j = checked_double(available, "available COM energy");
    result.incoming_com_kinetic_energy_j = checked_double(com_energy_before, "incoming COM energy");
    result.outgoing_com_kinetic_energy_j = checked_double(kinetic_energy(momenta_com, input.products), "outgoing COM energy");
    result.kinetic_energy_before_j = checked_double(kinetic_before, "incoming kinetic energy");
    result.kinetic_energy_after_j = checked_double(kinetic_after, "outgoing kinetic energy");
    result.internal_energy_before_j = checked_double(internal_before, "incoming internal energy");
    result.internal_energy_after_j = checked_double(internal_after, "outgoing internal energy");
    result.total_energy_before_j = checked_double(kinetic_before + internal_before, "incoming total energy");
    result.total_energy_after_j = checked_double(kinetic_after + internal_after, "outgoing total energy");
    result.energy_defect_ev = checked_double(defect_ev, "energy defect");
    result.energy_residual_j = checked_double(kinetic_after - kinetic_before + defect_j, "energy residual");
    result.momentum_before_kg_m_s = momentum_before;
    result.momentum_after_kg_m_s = momentum_after;
    result.momentum_residual_kg_m_s = subtract(momentum_after, momentum_before);
    result.mass_residual_kg = checked_double(mass_residual, "mass residual");
    result.center_of_mass_velocity_m_s = velocity_com_out;
    result.jacobi_energy_fractions = std::move(fractions);
    result.jacobi_directions = std::move(directions);
    result.maximum_incoming_beta = incoming_beta;
    result.maximum_outgoing_beta = outgoing_beta;
    result.threshold_roundoff_correction_j = checked_double(threshold_roundoff, "threshold roundoff");
    result.bulk_mass_roundoff_correction_j = checked_double(bulk_mass_correction, "bulk mass roundoff");
    result.kinematics_provenance = input.kinematics_provenance;
    return result;
}

inline ReactionOutcome construct_reaction(
    const std::vector<SpeciesState>& reactants,
    const std::vector<SpeciesState>& products,
    const std::vector<Vec3>& incoming_momenta_kg_m_s,
    const std::vector<double>& jacobi_energy_fractions,
    const std::vector<Vec3>& jacobi_directions,
    std::string_view kinematics_provenance,
    double max_nonrel_beta = 0.05) {
    return construct_reaction(ReactionInput{reactants, products, incoming_momenta_kg_m_s,
        jacobi_energy_fractions, jacobi_directions, std::string(kinematics_provenance), max_nonrel_beta});
}

} // namespace quark::physics::gap
