#pragma once

// SI mechanical-momentum orbits in prescribed fields. The caller owns field
// sampling, boundaries, collisions, subcycling and field deposition. Position
// updates use the mean endpoint velocity. This operator supplies no field solve.

#include <array>
#include <cmath>
#include <stdexcept>

namespace quark::physics::gap {

using Vec3 = std::array<double, 3>;
inline constexpr double speed_of_light_m_s = 299792458.0;

struct ParticleOrbit {
    Vec3 position_m{};
    Vec3 momentum_kg_m_s{};
    double mass_kg{0.0};
    double charge_c{0.0};
};

struct OrbitResult {
    ParticleOrbit particle;
    double kinetic_delta_j{0.0};
    double electric_displacement_work_j{0.0};
    double work_residual_j{0.0};
    double gyro_angle_rad{0.0};
    double boris_rotation_angle_rad{0.0};
    double magnetic_rotation_relative_error{0.0};
};

namespace orbit_detail {

inline void require_finite(double value, const char* label) {
    if (!std::isfinite(value)) {
        throw std::invalid_argument(label);
    }
}

inline void require_vector(const Vec3& value, const char* label) {
    for (double component : value) {
        require_finite(component, label);
    }
}

inline void require_mass(double mass) {
    if (!std::isfinite(mass) || mass <= 0.0) {
        throw std::invalid_argument("mass_kg must be finite and positive");
    }
}

inline double finite_result(double value) {
    if (!std::isfinite(value)) {
        throw std::overflow_error("orbit calculation exceeded the finite numeric range");
    }
    return value;
}

inline Vec3 finite_vector(const Vec3& value) {
    for (double component : value) {
        (void)finite_result(component);
    }
    return value;
}

inline double norm(const Vec3& value) {
    return finite_result(std::hypot(value[0], value[1], value[2]));
}

inline double dot(const Vec3& left, const Vec3& right) {
    return left[0] * right[0] + left[1] * right[1] + left[2] * right[2];
}

inline Vec3 add(const Vec3& left, const Vec3& right) {
    return {left[0] + right[0], left[1] + right[1], left[2] + right[2]};
}

inline Vec3 scale(const Vec3& value, double factor) {
    return {value[0] * factor, value[1] * factor, value[2] * factor};
}

inline Vec3 cross(const Vec3& left, const Vec3& right) {
    return {left[1] * right[2] - left[2] * right[1],
            left[2] * right[0] - left[0] * right[2],
            left[0] * right[1] - left[1] * right[0]};
}

inline double gamma(const Vec3& momentum, double mass, bool relativistic) {
    if (!relativistic) {
        return 1.0;
    }
    const double mass_c = finite_result(mass * speed_of_light_m_s);
    const double normalized_momentum = finite_result(norm(momentum) / mass_c);
    return finite_result(std::hypot(1.0, normalized_momentum));
}

} // namespace orbit_detail

// Rationalizing (gamma-1) m c^2 retains the energy of cold particles when gamma
// rounds to one. Nonrelativistic mode returns p^2/(2m).
[[nodiscard]] inline double kinetic_energy_j(
    const Vec3& momentum_kg_m_s, double mass_kg, bool relativistic = true) {
    orbit_detail::require_vector(momentum_kg_m_s, "momentum must be finite");
    orbit_detail::require_mass(mass_kg);
    const double magnitude = orbit_detail::norm(momentum_kg_m_s);
    if (!relativistic) {
        return orbit_detail::finite_result(0.5 * magnitude * (magnitude / mass_kg));
    }
    const double denominator = orbit_detail::finite_result(
        mass_kg * (orbit_detail::gamma(momentum_kg_m_s, mass_kg, true) + 1.0));
    return orbit_detail::finite_result(magnitude * (magnitude / denominator));
}

[[nodiscard]] inline Vec3 velocity_m_s(
    const Vec3& momentum_kg_m_s, double mass_kg, bool relativistic = true) {
    orbit_detail::require_vector(momentum_kg_m_s, "momentum must be finite");
    orbit_detail::require_mass(mass_kg);
    const double denominator = orbit_detail::finite_result(
        mass_kg * orbit_detail::gamma(momentum_kg_m_s, mass_kg, relativistic));
    return orbit_detail::finite_vector({momentum_kg_m_s[0] / denominator,
                                        momentum_kg_m_s[1] / denominator,
                                        momentum_kg_m_s[2] / denominator});
}

// Electric half-kick, standard Boris rotation, electric half-kick. Relativistic
// rotation uses gamma after the first half-kick. E and B are midpoint samples
// supplied by the caller. The gyro angle diagnoses temporal resolution; it is
// never clipped. q E dot displacement is a separate quadrature diagnostic and
// need not equal the relativistic energy increment at finite timestep.
// Standard relativistic Boris also has a finite-step error for force-free
// relativistic E cross B drift; establish trajectory accuracy by refinement.
[[nodiscard]] inline OrbitResult orbit_step(
    const ParticleOrbit& particle,
    const Vec3& electric_field_v_m,
    const Vec3& magnetic_field_t,
    double dt_s,
    bool relativistic = true) {
    orbit_detail::require_vector(particle.position_m, "position must be finite");
    orbit_detail::require_vector(particle.momentum_kg_m_s, "momentum must be finite");
    orbit_detail::require_mass(particle.mass_kg);
    orbit_detail::require_finite(particle.charge_c, "charge must be finite");
    orbit_detail::require_vector(electric_field_v_m, "electric field must be finite");
    orbit_detail::require_vector(magnetic_field_t, "magnetic field must be finite");
    if (!std::isfinite(dt_s) || dt_s <= 0.0) {
        throw std::invalid_argument("dt_s must be finite and positive");
    }

    const double half_charge_dt = orbit_detail::finite_result(0.5 * dt_s * particle.charge_c);
    const Vec3 half_kick = orbit_detail::finite_vector(
        orbit_detail::scale(electric_field_v_m, half_charge_dt));
    const Vec3 momentum_minus = orbit_detail::finite_vector(
        orbit_detail::add(particle.momentum_kg_m_s, half_kick));
    const double gamma_minus = orbit_detail::gamma(momentum_minus, particle.mass_kg, relativistic);
    const double t_factor = orbit_detail::finite_result(half_charge_dt / particle.mass_kg / gamma_minus);
    const Vec3 t = orbit_detail::finite_vector(orbit_detail::scale(magnetic_field_t, t_factor));
    const double t_norm = orbit_detail::norm(t);
    const double inverse_norm = 1.0 / std::hypot(1.0, t_norm);
    const Vec3 scaled_t = orbit_detail::scale(t, inverse_norm);
    // This is algebraically p' = p- + p- x t; p+ = p- + p' x 2t/(1+t.t).
    // Scaling t first avoids the square of a potentially large gyro angle.
    const Vec3 cross_once = orbit_detail::cross(momentum_minus, scaled_t);
    const Vec3 rotation_increment = orbit_detail::scale(
        orbit_detail::add(orbit_detail::scale(cross_once, inverse_norm),
                          orbit_detail::cross(cross_once, scaled_t)), 2.0);
    const Vec3 momentum_rotated = orbit_detail::finite_vector(
        orbit_detail::add(momentum_minus, rotation_increment));
    const Vec3 momentum_new = orbit_detail::finite_vector(
        orbit_detail::add(momentum_rotated, half_kick));
    const Vec3 velocity_old = velocity_m_s(particle.momentum_kg_m_s, particle.mass_kg, relativistic);
    const Vec3 velocity_new = velocity_m_s(momentum_new, particle.mass_kg, relativistic);
    const Vec3 displacement = orbit_detail::finite_vector(
        orbit_detail::scale(orbit_detail::add(velocity_old, velocity_new), 0.5 * dt_s));

    OrbitResult result;
    result.particle = particle;
    result.particle.position_m = orbit_detail::finite_vector(
        orbit_detail::add(particle.position_m, displacement));
    result.particle.momentum_kg_m_s = momentum_new;
    result.kinetic_delta_j = orbit_detail::finite_result(
        kinetic_energy_j(momentum_new, particle.mass_kg, relativistic)
        - kinetic_energy_j(particle.momentum_kg_m_s, particle.mass_kg, relativistic));
    result.electric_displacement_work_j = orbit_detail::finite_result(
        particle.charge_c * orbit_detail::dot(electric_field_v_m, displacement));
    result.work_residual_j = orbit_detail::finite_result(
        result.kinetic_delta_j - result.electric_displacement_work_j);
    result.gyro_angle_rad = orbit_detail::finite_result(2.0 * t_norm);
    result.boris_rotation_angle_rad = 2.0 * std::atan(t_norm);
    const double before_norm = orbit_detail::norm(momentum_minus);
    const double after_norm = orbit_detail::norm(momentum_rotated);
    result.magnetic_rotation_relative_error = before_norm == 0.0 ? 0.0
        : orbit_detail::finite_result(std::abs(after_norm - before_norm) / before_norm);
    return result;
}

} // namespace quark::physics::gap
