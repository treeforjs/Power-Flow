#include "mitl_gap_orbits.hpp"
#include "mitl_gap_reactions.hpp"

#include <algorithm>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <stdexcept>
#include <utility>
#include <vector>

namespace gap = quark::physics::gap;

namespace {

constexpr double ev_j = 1.602176634e-19;
constexpr double electron_mass_kg = 9.1093837139e-31;
constexpr double molecule_mass_kg = 18.0 * 1.66053906892e-27;

struct TrackedParticle {
    gap::SpeciesState state;
    gap::ParticleOrbit orbit;
};

long double total_energy_j(const std::vector<TrackedParticle>& particles) {
    long double result = 0.0L;
    for (const auto& particle : particles) {
        result += gap::kinetic_energy_j(
            particle.orbit.momentum_kg_m_s, particle.state.mass_kg, false);
        result += static_cast<long double>(particle.state.common_energy_ev) * ev_j;
    }
    return result;
}

} // namespace

int main() {
    try {
        // Manufactured states and an explicitly scheduled excitation. The
        // event is not sampled from a physical cross section or reaction rate.
        const gap::SpeciesState electron{"e", electron_mass_kg, -1, {}, 0.0};
        const gap::SpeciesState ground{"M0", molecule_mass_kg, 0, {{"M", 1}}, 0.0};
        const gap::SpeciesState excited{"M1", molecule_mass_kg, 0, {{"M", 1}}, 0.5};
        const gap::SpeciesState ion{"Mi", molecule_mass_kg - electron_mass_kg,
                                    1, {{"M", 1}}, 2.0};
        std::vector<TrackedParticle> particles{
            {electron, {{0.0, 0.0, 0.0},
                {0.0, std::sqrt(2.0 * electron_mass_kg * 5.0 * ev_j), 0.0},
                electron.mass_kg, -ev_j}},
            {ground, {{0.0, 0.0, 0.0}, {0.0, 0.0, 0.0}, ground.mass_kg, 0.0}},
            {ion, {{0.0, 0.0, 0.0}, {0.0, 0.0, 0.0}, ion.mass_kg, ev_j}}
        };
        const gap::Vec3 electric{0.0, 1000.0, 0.0};
        const gap::Vec3 magnetic{0.5, 0.0, 0.0};
        constexpr double dt_s = 1e-12;
        constexpr int steps = 200;
        constexpr int excitation_step = 80;
        const long double initial_energy = total_energy_j(particles);
        long double field_kinetic_gain = 0.0L;
        long double displacement_work = 0.0L;
        long double maximum_step_residual = 0.0L;
        double reaction_residual_j = 0.0;
        double maximum_gyro_angle = 0.0;
        int events = 0;
        for (int step = 0; step < steps; ++step) {
            auto trial = particles;
            long double step_field_gain = 0.0L;
            long double step_displacement_work = 0.0L;
            for (auto& particle : trial) {
                const auto update = gap::orbit_step(
                    particle.orbit, electric, magnetic, dt_s, false);
                particle.orbit = update.particle;
                step_field_gain += update.kinetic_delta_j;
                step_displacement_work += update.electric_displacement_work_j;
                maximum_gyro_angle = std::max(maximum_gyro_angle, update.gyro_angle_rad);
            }
            if (step == excitation_step) {
                gap::ReactionInput input;
                input.reactants = {electron, ground};
                input.products = {electron, excited};
                input.incoming_momenta_kg_m_s = {
                    trial[0].orbit.momentum_kg_m_s, trial[1].orbit.momentum_kg_m_s};
                input.jacobi_energy_fractions = {1.0};
                input.jacobi_directions = {{1.0, 0.0, 0.0}};
                input.kinematics_provenance =
                    "manufactured scheduled event; fixed COM recoil direction for verification";
                const auto event = gap::construct_reaction(input);
                reaction_residual_j = event.energy_residual_j;
                trial[0].orbit.momentum_kg_m_s = event.outgoing_momenta_kg_m_s[0];
                trial[1].orbit.momentum_kg_m_s = event.outgoing_momenta_kg_m_s[1];
                trial[1].state = excited;
                ++events;
            }
            const long double step_residual = total_energy_j(trial)
                - total_energy_j(particles) - step_field_gain;
            maximum_step_residual = std::max(maximum_step_residual, std::abs(step_residual));
            // Candidate states and all accumulated moments are accepted together.
            particles = std::move(trial);
            field_kinetic_gain += step_field_gain;
            displacement_work += step_displacement_work;
        }
        const long double residual = total_energy_j(particles)
            - initial_energy - field_kinetic_gain;
        if (events != 1 || particles[1].state.state_id != excited.state_id
            || !std::isfinite(residual) || !std::isfinite(maximum_step_residual)
            || std::abs(residual) / ev_j > 1e-10L
            || maximum_step_residual / ev_j > 1e-10L
            || std::abs(reaction_residual_j) / ev_j > 1e-10) {
            throw std::runtime_error("coupled prescribed-field energy/state verification failed");
        }
        std::cout << std::setprecision(17)
            << "{\n  \"scope\": \"manufactured prescribed-field native coupling check\",\n"
            << "  \"steps\": " << steps << ",\n"
            << "  \"dt_s\": " << dt_s << ",\n"
            << "  \"scheduled_excitation_events\": " << events << ",\n"
            << "  \"maximum_gyro_angle_rad\": " << maximum_gyro_angle << ",\n"
            << "  \"field_kinetic_gain_ev\": " << field_kinetic_gain / ev_j << ",\n"
            << "  \"electric_displacement_work_ev\": " << displacement_work / ev_j << ",\n"
            << "  \"reaction_residual_ev\": " << reaction_residual_j / ev_j << ",\n"
            << "  \"maximum_step_balance_residual_ev\": " << maximum_step_residual / ev_j << ",\n"
            << "  \"final_balance_residual_ev\": " << residual / ev_j << "\n}\n";
    } catch (const std::exception& error) {
        std::cerr << error.what() << '\n';
        return 1;
    }
}
