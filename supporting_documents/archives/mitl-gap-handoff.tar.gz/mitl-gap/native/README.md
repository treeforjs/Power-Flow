# Native kinetic reference candidates

These standalone C++20 headers implement prescribed-field particle orbits and
conservative state-to-state reaction kinematics. They have no Quark build,
mesh, field-solver, runner or external plasma-library dependency. The namespace
is a proposed integration location; no Quark registration is supplied.

| File | Responsibility |
| --- | --- |
| `include/mitl_gap_orbits.hpp` | Relativistic/nonrelativistic Boris motion, stable kinetic energy and separate field-work diagnostics |
| `include/mitl_gap_reactions.hpp` | Two-reactant to multiple-product recoil from explicit states, energy shares and directions |
| `tests/` | Analytic orbit and reaction-conservation checks, with unconditional runtime checks under `NDEBUG` |
| `examples/coupled_reference.cpp` | Manufactured prescribed-field motion and explicitly scheduled internal-state excitation |

## Reproduce locally

From this directory, with a C++20 compiler and Make:

```bash
make check BUILD_DIR=/tmp/mitl-gap-reference-build
```

Alternatively, with CMake 3.20 or later:

```bash
cmake -S . -B /tmp/mitl-gap-reference-cmake
cmake --build /tmp/mitl-gap-reference-cmake
ctest --test-dir /tmp/mitl-gap-reference-cmake --output-on-failure
```

These are independent reference builds. Host registration and verification in
Quark remain with its integration owner through the accompanying handoff.

## Energy and validity contracts

Momentum is mechanical momentum in SI units. The orbit routine receives
prescribed midpoint fields. Magnetic rotation changes direction without
supplying physical work. Electric displacement work and kinetic-energy change
are reported separately, including their finite-step quadrature residual.
The reported gyro angle must drive the caller's timestep/subcycling policy.

Reaction states share one declared chemical and internal-energy reference.
Their energy difference determines available COM recoil energy. Explicit ordered
Jacobi shares and unit directions determine the final momenta. The required
kinematics provenance records the supplying differential model; numerical
conservation cannot establish that this model describes water fragmentation.

Reaction construction is nonrelativistic and enforces a speed cap of 0.05 c;
callers may tighten this limit. Masses must be additive under that convention; relativistic
mass defects are outside its validity. A relativistic orbit update does not
extend the collision model's energy range.

The example uses a manufactured molecule and a deliberately scheduled event.
It is a mechanical coupling check, not a collision-rate calculation. Production
use still requires the state/data registry, physical differential cross sections,
stochastic event scheduling, spatial collision cells, wall/source accounting,
field/current coupling and complete molecular radiative evolution.
