"""Kinetic transport and state-exchange reference components."""
