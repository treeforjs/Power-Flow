# Manufactured saved coupled-emission window patch

Five new public files and a patch are pinned to the approved checkout. Apply the
patch to the complete baseline at `df8eb7026b3a712bf641cbb4d136c497e8af50ba` before importing, exporting or testing
this reference. This source/ review subset is not a standalone package. No
initializer replacement or portable execution is supplied. The requirements
wrapper copies baseline requirements.txt byte-for-byte; retain the complete
checkout setup and initializer.

Replaying the independent fresh queries additionally requires the accepted
0710 archive pinned in dependency_context.json. Its six original 80-digit and
120-digit seed
checkpoints are referenced by exact names and hashes; their bytes are not
duplicated here. The saved-data export's 12 raw inputs and all new query outputs
are included. This audit packet does not claim a standalone oracle rerunner.

The interface conditions accepted saved constant-power coupled histories on
explicit windows and retains number, time, temperature and energy association.
Unique source/window pairs remain distinct from repeated patch references and
whole-face aggregate/difference records. Joint time-temperature covariance and
channel availability remain explicit; an unavailable source-knot channel must
not become a fabricated zero or an inferred source budget.

The original source, numerical report, code versions and acceptance records are
separate inputs. New adapter tests, parser controls, a saved-data export and
fresh independent off-knot queries retain separate counters. Source evolution,
RHS evaluation, width assembly, old grids and old suites are not replayed. This
is a manufactured upstream interface, with no physical material/water/monolayer,
spectral, field, particle launch, gap, FLASH or host validation.
