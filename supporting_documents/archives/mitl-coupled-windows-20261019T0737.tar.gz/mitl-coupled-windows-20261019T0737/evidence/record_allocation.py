"""Record the newly claimed bounded saved-source window work."""
import datetime, fcntl, hashlib, json
from pathlib import Path

WORK=Path(__file__).resolve().parent
PREVIOUS=WORK.parent/'mitl-upstream-20261019T0710'
def pin(path):
    return {'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
with (WORK.parent/'mitl-upstream-status.lock').open('a+') as lock:
    fcntl.flock(lock,fcntl.LOCK_EX)
    status=json.loads((WORK.parent/'mitl-upstream-status.json').read_text())
    lease=json.loads((WORK/'lease.json').read_text())
    assert status['active_lease_owner']==WORK.name and status['reserved_paths']==lease['reserved_paths']
    assert datetime.datetime.fromisoformat(status['active_editing_lease_until_utc'])>datetime.datetime.now(datetime.timezone.utc)
    planning={name:pin(PREVIOUS/name) for name in [
        'next-upstream-selection/mathematical-notes.json',
        'next-window-export-design/design.json',
        'next-window-reference-plan/reference_method_draft.json',
        'next-upstream-selection/selection.json']}
    record={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'event':'bounded_work_allocation','pass_id':WORK.name,'lease':pin(WORK/'lease.json'),
        'claim_command_log':pin(PREVIOUS/'claim-coupled-window-lease.log'),
        'initial_checks':{'workspace_available':True,'correct_branch':True,
            'clean_baseline':lease['baseline_commit'],'saved_status_sha256':lease['status_before_sha256'],
            'latest_local_handoff_read_before_selection':True,'unexpired_other_lease':False,
            'prior_reservations_empty':True,'prior_handoff_hash_verified':True},
        'planning_inputs_only':planning,
        'allocation':{'core':'new pure-JSON admission, exact Bernstein windows and joint moments; no numerical source imports or calls',
            'tests':'new independent analytic polynomial/admission controls only',
            'producer':'one pure saved-data nine-query export with strict frozen source/query identity',
            'independent_verification':'new bounded moment quadrature/off-knot queries seeded from accepted saved independent states',
            'review':'prospective math, frozen core/code and actual new report; no numeric execution',
            'delivery':'five-file patch and saved evidence metadata only; root execution',
            'root':'guide, actual result association, commits, delivery/status execution and next selection'},
        'mandatory_joint_moment':'Direct local-time times temperature integral against the same positive emission measure, plus covariance statistic; coefficients retain the full joint measure.',
        'prospective_counts':{'unique_source_windows':9,'patch_references':18,'aggregates':6,'contrasts':3},
        'old_source_or_RHS_or_assembly_evaluations_authorized':0,
        'old_reference_full_grid_replays_authorized':0,
        'limits':'Manufactured constant-power saved source only. No velocity sampler, source energy repair, physical surface/calibration inference, gap or owner changes.'}
    target=WORK/'allocation.json'
    assert not target.exists()
    target.write_text(json.dumps(record,indent=2)+'\n')
    with (WORK.parent/'mitl-upstream-journal.jsonl').open('a') as stream:
        stream.write(json.dumps(record)+'\n')
print(json.dumps({'allocation':pin(target),'scope':lease['reserved_paths']},indent=2))
