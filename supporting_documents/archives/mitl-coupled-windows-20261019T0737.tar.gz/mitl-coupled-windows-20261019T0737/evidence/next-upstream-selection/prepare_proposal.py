"""Declare a conditional boundary quadrature handoff; no source evaluation."""

from hashlib import sha256
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
PASS = ROOT.parent


def pin(path: Path) -> dict:
    return {"path": str(path), "sha256": sha256(path.read_bytes()).hexdigest()}


def write(name: str, value: dict) -> None:
    path = ROOT / name
    if path.exists():
        raise ValueError(f"refusing to replace planning artifact: {name}")
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


proposal = {
    "schema": "mhdlab-positive-boundary-quadrature-proposal-v1",
    "task_id": "positive-joint-boundary-quadrature-handoff",
    "status": "conditional_on_actual_coupled_window_acceptance_and_owner_mixture_need",
    "criterion": "Proceed only if the current saved positive joint-piece source passes its actual new reference and final review, and a finite positive time/T/state/number representation concretely advances the queued owner mixture handoff. If the owner already consumes exact joint pieces directly, prefer that interface rather than duplicating it.",
    "current_inputs": {
        "source": pin(Path("/workspace/Power-Flow/mhdlab/coupled_emission_windows.py")),
        "source_freeze": pin(PASS / "core/source-freeze.json"),
        "api": pin(PASS / "core/api-contract.json"),
        "output_contract": pin(PASS / "core/output-contract.json"),
        "static_review": pin(PASS / "core-review/completion.json"),
    },
    "purpose": "Convert accepted positive joint emission pieces into deterministic weighted boundary records while retaining their full time/temperature/state/geometry identity and explicitly measuring every quadrature/projection defect.",
    "bounded_math": {
        "rule": "Five positive Gauss-Legendre nodes per nonzero restricted piece on v in[0,1]. Weight is the GL integration weight times dM/dv at that node; no second duration factor.",
        "ideal_exactness": "dM/dv has degree2 and T degree3. The required1,tlocal,tlocal^2,T,T^2,tlocal*T integrands have degree at most8, so the ideal five-node algebraic rule integrates them exactly (degree9 capacity).",
        "finite_implementation": "Generate nodes/weights with an explicitly qualified deterministic high-precision arithmetic contract, retain its rational decimal approximations, then project the actual exported fields once. Do not call finite approximations mathematically exact GL nodes.",
        "positive_guards": "Positive source pieces have positive dM/dv at interior GL nodes. Require all exported number weights positive and finite, nodes strictly inside their supported piece, and T inside the admitted positive domain. Exact-zero pieces are skipped with a complete reasoned catalogue. Unsupported projection rejects; no capping, clipping, jitter or renormalization.",
    },
    "new_queries": [
        {"window_id": "shifted_interior", "start_duration_fraction": "3/32", "stop_duration_fraction": "11/32"},
        {"window_id": "quarter_cell_interior", "start_duration_fraction": "13/256", "stop_duration_fraction": "99/256"},
    ],
    "reuse_budget": {
        "distinct_saved_scalar_sources": 3,
        "new_source_window_pairs": 6,
        "positive_piece_query_references_if_all_nonzero": 114,
        "distinct_piece_supports_after_nested_query_reuse": 66,
        "distinct_node_evaluations_if_all_nonzero": 330,
        "source_window_node_references": 570,
        "expanded_hypothesis_patch_node_references": 1140,
        "cache_key": "canonical source history plus exact restricted piece bounds; the nested windows share complete-cell nodes rather than evaluating them twice",
        "old_evolution_RHS_assembly_window_export_or_reference_grid_replays": 0,
    },
    "source_use": "Consume only hash-bound saved complete-support joint pieces from the accepted current export. Restrict their exact controls for the two NEW queries; never rerun the original window export or re-evaluate source kinetics/RHS. Saved original coefficients and source identities remain attached.",
    "weighted_record": ["source/report/acceptance hashes", "new query and exact piece support", "source history/state identity", "node index", "positive parent number weight", "time", "temperature", "expected translation2*kB*T", "supplied internal/removal costs", "geometry range and area association", "pre/post-projection values and defects"],
    "area_and_energy": "Keep areal source weights cached once, apply the true patch area once in each patch view, and aggregate emitted-number weighted moments. Binding D and gas internal I stay separate from expected translation. Prescribed input and wall thermal changes stay window diagnostics, not invented per-parent energy assignments. No sampled width position is substituted for the retained patch range.",
    "defect_layers": [
        "Exact polynomial target moments for the two new queries, independently formed from accepted saved coefficients.",
        "Approximate-node/weight generation discrepancy versus exact polynomial moments, before binary projection.",
        "Finite exported-field projection discrepancy, computed from exact Fractions of the actual output weights/time/T and their complete moment sums.",
        "Total represented quadrature-minus-polynomial discrepancy equals the sum of the preceding two discrepancies, without weight rescaling.",
        "Prior source/interpolation/IVP error qualifications remain separate. Acceptance at old window queries does not certify new-query IVP error; a new IVP claim would need a separately justified new query calculation.",
    ],
    "fresh_verification": "Freeze methods, new queries and gross/contrast defect budgets before the sole new boundary batch. Use independent exact power-basis targets plus positive-rule/representation/zero-piece controls, and a distinct high-precision rule comparison. Verify full joint moments, energy, area and reuse from the exported records. No old source/window/reference grid is rerun for activity.",
    "limits": [
        "Deterministic source quadrature records only: no random sampler, molecular mass, physical velocity, flight, kinetic gap, collection kernel or owner implementation.",
        "No physical water, state-branching, fragmentation, Hall/FLASH/Quark, host-budget or spectral claim.",
        "Keep complete source pieces and geometry alongside finite records; a mean temperature or mean time is not a replacement source.",
        "Keep saved queue2-7 and actual material/VUV/full-text/workstation gates unchanged.",
    ],
    "public_implementation_started": False,
    "numerical_execution_during_planning": False,
    "fresh_lease_required": True,
}
write("positive_boundary_quadrature_proposal.json", proposal)
write("conditional-selection.json", {
    "schema": "mhdlab-upstream-conditional-selection-v1",
    "status": "waiting_for_actual_window_reference_acceptance_and_report_review",
    "task_id": proposal["task_id"],
    "proposal": pin(ROOT / "positive_boundary_quadrature_proposal.json"),
    "criterion": proposal["criterion"],
    "final_selection_written": False,
    "fresh_lease_required": True,
    "numerical_execution": False,
})
print(json.dumps({"proposal": pin(ROOT / "positive_boundary_quadrature_proposal.json"), "conditional_selection": pin(ROOT / "conditional-selection.json"), "numerical_execution": False}, indent=2))
