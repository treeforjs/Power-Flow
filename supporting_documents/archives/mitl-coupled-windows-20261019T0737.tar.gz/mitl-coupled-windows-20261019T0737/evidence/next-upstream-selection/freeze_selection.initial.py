"""Bind the next boundary task to actual accepted window evidence only."""

import argparse
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
PASS = ROOT.parent
PUBLIC = Path("/workspace/Power-Flow")
CORE_PATH = "mhdlab/coupled_emission_windows.py"
CORE_SHA = "8a235ed92c0e40ccd43375fcd4d6c6beee05fd460b9fbf15102610c338eba786"


def require(condition: bool, reason: str) -> None:
    if not condition:
        raise ValueError(reason)


def pin(path: Path) -> dict:
    return {"path": str(path), "sha256": sha256(path.read_bytes()).hexdigest()}


def read(relative: str, expected: str) -> tuple[dict, dict]:
    require(type(expected) is str and len(expected) == 64 and all(char in "0123456789abcdef" for char in expected), "approved SHA256 required")
    path = PASS / relative
    record = pin(path)
    require(record["sha256"] == expected, f"approved saved pin mismatch: {relative}")
    return json.loads(path.read_text()), record


def write(name: str, document: dict) -> None:
    path = ROOT / name
    require(not path.exists(), f"refusing to replace frozen selection artifact: {name}")
    path.write_text(json.dumps(document, indent=2, allow_nan=False) + "\n")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--producer-completion-sha256", required=True)
    parser.add_argument("--independent-completion-sha256", required=True)
    parser.add_argument("--independent-report-sha256", required=True)
    parser.add_argument("--oracle-review-sha256", required=True)
    args = parser.parse_args()
    require(pin(PUBLIC / CORE_PATH)["sha256"] == CORE_SHA, "accepted core changed")
    proposal, proposal_pin = read("next-upstream-selection/positive_boundary_quadrature_proposal.json", "c013463986ca27ba2445cf2b8a9a514e963abec9ffb86c19ef43b20239c555cc")
    producer, producer_pin = read("producer/completion.json", args.producer_completion_sha256)
    independent, independent_pin = read("independent-verification/completion.json", args.independent_completion_sha256)
    reference, reference_pin = read("independent-verification/query-initial/report.json", args.independent_report_sha256)
    review, review_pin = read("oracle-review/completion.json", args.oracle_review_sha256)
    tests, tests_pin = read("tests/completion.json", "dc687119f5a09bbceefe0e0ccd6fa6610b666df9b9f99d53f1cc38540c14c95a")
    core_review, core_review_pin = read("core-review/completion.json", "81ff9b4279bc044f2df75c7b275b4bc1b8a76b2c1513862fe4b6d3f9acb9b42d")
    require(producer["status"] == "passed_saved_data_export_and_readback" and producer["positive_saved_data_export_batches"] == 1, "sole saved-data export not accepted")
    require(producer["source_evolution_RHS_assembly_calls"] == 0 and producer["old_suites_or_numerical_cases_replayed"] is False, "source replay declared")
    require(producer["open_substantive_findings"] == [], "producer has unresolved findings")
    report_path = PASS / producer["report_path"]
    producer_report = json.loads(report_path.read_text())
    producer_report_pin = pin(report_path)
    require(producer_report_pin["sha256"] == producer["report_sha256"], "producer report association changed")
    require(producer_report["code_sha256"][CORE_PATH] == CORE_SHA, "producer core pin changed")
    result_pin = pin(PASS / producer["result_path"])
    require(result_pin["sha256"] == producer["result_sha256"] == producer_report["result_sha256"], "window result association changed")
    require(producer["cache"] == {"distinct_source_windows": 9, "patch_references": 18, "aggregate_windows": 6, "contrasts": 3, "source_calls": {"history_evolution": 0, "RHS": 0, "assembly": 0}}, "window reuse/work scope changed")
    require(tests["all_checks_passed"] is True and (tests["unique_new_test_cases"], tests["test_case_executions"], tests["targeted_test_runs"]) == (50, 50, 1), "new test qualification changed")
    require(tests["public_source_sha256"][CORE_PATH] == CORE_SHA and tests["scalar_evolution_calls"] == 0 and tests["scalar_rhs_calls"] == 0 and tests["old_assembly_calls"] == 0, "test source/replay association changed")
    require(core_review["source_changes_requested"] is False, "core review requests changes")
    require(independent["status"] == "passed" and independent["all_checks_passed"] is True, "independent completion not passed")
    require(reference["status"] == "passed" and reference["all_checks_passed"] is True, "independent reference not passed")
    require(independent["report_sha256"] == reference_pin["sha256"], "independent report association mismatch")
    require(reference["producer_report_sha256"] == producer_report_pin["sha256"] and reference["window_document_sha256"] == result_pin["sha256"], "reference source/result association mismatch")
    require(tuple(reference[key] for key in ("distinct_source_window_queries", "patch_references", "aggregate_windows", "width_contrasts")) == (9, 18, 6, 3), "reference window scope changed")
    require(all(reference[key] == 0 for key in ("old_reference_grid_calls", "old_source_RHS_calls", "producer_calls_by_oracle")), "independent old work replay declared")
    require(review["status"] == "accepted" and review["owner_report_sha256"] == reference_pin["sha256"], "actual final method review not accepted")
    require(review["completed_report_bound_without_numerical_replay"] is True, "final review does not bind report")
    require(review.get("further_changes_requested", False) is False, "final review has unresolved requested changes")
    require(all(item.get("status") in ("repaired_before_first_query", "repaired_before_first_reference") for item in review.get("findings", [])), "final review has unresolved findings")

    queue_path = Path("/workspace/research_work/mitl-upstream-status.json")
    status = json.loads(queue_path.read_text())
    queue = [item for item in status["next_work"] if item["priority"] in range(2, 8)]
    require([item["priority"] for item in queue] == list(range(2, 8)), "saved queue2-7 incomplete")
    acceptance = {
        "schema": "mhdlab-boundary-quadrature-predecessor-acceptance-v1",
        "status": "actual_saved_coupled_window_acceptance_bound",
        "source_sha256": CORE_SHA,
        "records": {"producer_completion": producer_pin, "producer_report": producer_report_pin, "window_document": result_pin,
                    "core_tests": tests_pin, "core_review": core_review_pin, "independent_completion": independent_pin,
                    "independent_report": reference_pin, "final_method_review": review_pin},
        "accepted_scope": {"source_windows": 9, "patch_references": 18, "aggregate_windows": 6, "contrasts": 3},
        "actual_reference_observed_scalars": {key: value for key, value in reference.items() if not isinstance(value, (dict, list))},
        "preserved_input_guard_qualification": producer["guard_evidence_claim"],
        "resolved_method_findings": review.get("findings", []),
        "planning_readback_only": True,
        "numerical_execution_by_selection": False,
        "limits": "Actual manufactured positive-piece/window acceptance only; no velocity, molecular/physical parameter, owner, transport or observation acceptance.",
    }
    write("predecessor-acceptance.json", acceptance)
    selection = {
        "schema": "mhdlab-upstream-selected-task-v1",
        "status": "selected_pending_fresh_bounded_lease",
        "selected_utc": datetime.now(timezone.utc).isoformat(),
        "task_id": proposal["task_id"],
        "selected_task": "Positive deterministic joint time/temperature/state/number boundary quadrature handoff for new finite queries.",
        "proposal": proposal_pin,
        "preserved_conditional_selection": pin(ROOT / "conditional-selection.json"),
        "predecessor_acceptance": pin(ROOT / "predecessor-acceptance.json"),
        "criterion_resolution": "Saved queue2 already requires the full source time/state/temperature mixture. A finite positive weighted joint representation concretely advances that upstream numerical handoff; its development does not wait for hypothetical owner permission or an unknown API.",
        "concrete_queued_need": queue[0],
        "work_budget": proposal["reuse_budget"],
        "new_queries": proposal["new_queries"],
        "proposed_public_scope": ["mhdlab/positive_boundary_quadrature.py", "tests/test_positive_boundary_quadrature.py", "tools/export_positive_boundary_quadrature.py", "configs/positive_boundary_quadrature_manufactured.json", "docs/positive_boundary_quadrature.md"],
        "retained_queue_source": pin(queue_path),
        "preserved_queue_items_2_through_7": queue,
        "owner_implementation_verified": False,
        "host_budget_accepted": False,
        "new_query_IVP_error_qualified": False,
        "velocity_samples": 0,
        "public_implementation_started": False,
        "fresh_lease_required": True,
        "public_files_changed_by_selection": [],
        "numerical_execution_by_selection": False,
        "retained_limits": proposal["limits"],
    }
    write("selection.json", selection)
    print(json.dumps({"selection": pin(ROOT / "selection.json"), "predecessor_acceptance": pin(ROOT / "predecessor-acceptance.json"), "numerical_execution": False}, indent=2))


if __name__ == "__main__":
    main()
