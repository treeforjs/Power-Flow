"""Freeze the new window-query design before source-window production."""
import datetime
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
WORK = HERE.parent
OLD = Path('/workspace/research_work/mitl-upstream-20261019T0710')
REPO = Path('/workspace/Power-Flow')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    target = HERE/'before_plan_freeze.json'
    if target.exists() or (WORK/'producer/reference-run/report.json').exists() or (HERE/'query-initial').exists():
        raise RuntimeError('freeze must precede the new window batch and reference queries')
    assert sha(HERE/'input_config.json') == sha(REPO/'configs/coupled_emission_windows_manufactured.json') == '2e8f1eb938a89957d2453f801321365ac6513fa8154b4dd3b925c1a67df1b18c'
    assert sha(HERE/'decimal_forced_reference.py') == 'b6740c00a75b094ea36c9d6c1d941cbe31e19b8100a200613ef8961136c8da89'
    old_report = OLD/'independent-verification/oracle-initial/report.json'
    assert sha(old_report) == '5a0b0cfce3fa594376718579645b8ee424bf80b6de0ac5ade0eeab829fc3d84c'
    report = json.loads(old_report.read_text())
    seeds = report['reference_checkpoint_sha256']
    for name, digest in seeds.items():
        assert sha(OLD/'independent-verification/oracle-initial'/name) == digest
    record = {
        'schema':'mitl-coupled-window-before-plan-freeze-v1',
        'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'frozen':{name:sha(HERE/name) for name in ('oracle_plan.json','input_config.json','decimal_forced_reference.py','freeze_plan.py')},
        'accepted_seed_report_sha256':sha(old_report),
        'accepted_seed_checkpoint_sha256':seeds,
        'new_unique_source_window_queries':9,
        'patch_references':18,'aggregate_windows':6,'width_contrasts':3,
        'new_query_calls_before_freeze':0,'old_full_state_or_RHS_calls':0,'producer_calls_by_oracle':0,
        'qualification':'New full-support moment integrands and bounded off-knot queries only. Accepted checkpoint states are data. No source model, old reference_grid, or prior query output is evaluated. New code freezes separately before the first query.'
    }
    target.write_text(json.dumps(record,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'freeze_sha256':sha(target),'frozen':record['frozen']},indent=2))


if __name__ == '__main__':
    main()
