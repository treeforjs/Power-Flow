"""Own-scale comparisons and positive-mixture reductions for new window queries."""
from decimal import Decimal as D
from fractions import Fraction as F
from power_basis_windows import statistics as fraction_statistics

STAT_KEYS = ('mean_local_time_s','variance_local_time_s2','mean_temperature_k',
    'variance_temperature_k2','mean_local_time_temperature_k_s','covariance_local_time_temperature_k_s')
AREAL_KEYS = ('released_m2','local_time_first_moment_s_m2','local_time_second_moment_s2_m2',
    'temperature_first_moment_k_m2','temperature_second_moment_k2_m2','local_time_temperature_moment_k_s_m2',
    'translational_energy_j_m2','binding_energy_j_m2','internal_energy_j_m2','total_wall_energy_debit_j_m2',
    'input_energy_j_m2','wall_thermal_change_j_m2','adsorbate_reference_change_j_m2','gas_energy_j_m2',
    'total_energy_residual_j_m2')


def dec(value):
    if isinstance(value,F):
        return D(value.numerator)/D(value.denominator)
    return D(value)


def metrics(record,reference=False):
    if reference:
        quantities = {key:record[key] for key in AREAL_KEYS}
        stats = {key:record[key] for key in STAT_KEYS}
    else:
        quantities,stats = record['areal'],record['statistics']
    result = {key:dec(quantities[key]) for key in AREAL_KEYS if key not in (
        'temperature_first_moment_k_m2','temperature_second_moment_k2_m2',
        'local_time_temperature_moment_k_s_m2','total_energy_residual_j_m2')}
    result.update({key:dec(stats[key]) for key in STAT_KEYS if key != 'mean_local_time_temperature_k_s'})
    result['centered_joint_local_time_temperature_k_s'] = dec(stats['mean_local_time_temperature_k_s'])-D(900)*dec(stats['mean_local_time_s'])
    return result


def scales(reference_records):
    maximum = {}
    for record in reference_records:
        for key,item in metrics(record,True).items():
            maximum[key] = max(maximum.get(key,D(0)),abs(item))
    return maximum


def compare(actual,reference,maximum,capacity,tolerance):
    actual_values,expected = metrics(actual),metrics(reference,True)
    result = {}
    span = reference['maximum_node_temperature_k']-reference['minimum_node_temperature_k']
    for key,value in expected.items():
        if key == 'mean_temperature_k':
            scale = span
        elif key == 'wall_thermal_change_j_m2':
            scale = capacity*span
        elif key in ('covariance_local_time_temperature_k_s','centered_joint_local_time_temperature_k_s'):
            scale = maximum[key]
        else:
            scale = abs(value)
        difference = actual_values[key]-value
        if scale == 0:
            if difference != 0:
                raise AssertionError('unresolved true-zero channel '+key)
            ratio = D(0)
        else:
            ratio = abs(difference)/scale
        result[key] = {'signed_error':difference,'scale':scale,'scaled_absolute_error':ratio,'tolerance':tolerance}
        if ratio > tolerance:
            raise AssertionError('new own-scale window qualification failed: '+key+' '+str(ratio))
    return result


def reference_as_polynomial(record):
    return {'areal':{key:record[key] for key in AREAL_KEYS},
        'statistics':{key:record[key] for key in STAT_KEYS}}


def reference_consistency(record,tolerance):
    channels = {
        'endpoint_minus_quadrature_mass_m2':record['released_m2'],
        'total_energy_residual_j_m2':record['total_wall_energy_debit_j_m2'],
        'independent_wall_residual_j_m2':record['total_wall_energy_debit_j_m2'],
        'independent_wall_allocation_residual_j_m2':record['total_wall_energy_debit_j_m2']}
    result = {}
    for key,scale in channels.items():
        ratio = abs(record[key])/scale if scale else abs(record[key])
        if ratio > tolerance:
            raise AssertionError('new independent positive integral consistency unresolved: '+key)
        result[key] = {'signed_residual':record[key],'scale':scale,'scaled_absolute_residual':ratio}
    return result


def aggregate_fraction(records,areas):
    values = {key:sum((record['areal'][key]*area for record,area in zip(records,areas)),F(0)) for key in AREAL_KEYS}
    return {'areal':values,'statistics':fraction_statistics(values)}


def aggregate_reference(records,areas):
    result = {key:sum((record[key]*dec(area) for record,area in zip(records,areas)),D(0)) for key in AREAL_KEYS}
    mass = sum((record['quadrature_mass_m2']*dec(area) for record,area in zip(records,areas)),D(0))
    # Positive centered parallel mixture: retains both within- and between-component variation.
    mean_t = sum((dec(area)*record['quadrature_mass_m2']*record['mean_local_time_s'] for record,area in zip(records,areas)),D(0))/mass
    mean_T = sum((dec(area)*record['quadrature_mass_m2']*record['mean_temperature_k'] for record,area in zip(records,areas)),D(0))/mass
    result.update({'quadrature_mass_m2':mass,'mean_local_time_s':mean_t,'mean_temperature_k':mean_T,
        'variance_local_time_s2':sum((dec(area)*record['quadrature_mass_m2']*(record['variance_local_time_s2']+(record['mean_local_time_s']-mean_t)**2) for record,area in zip(records,areas)),D(0))/mass,
        'variance_temperature_k2':sum((dec(area)*record['quadrature_mass_m2']*(record['variance_temperature_k2']+(record['mean_temperature_k']-mean_T)**2) for record,area in zip(records,areas)),D(0))/mass,
        'covariance_local_time_temperature_k_s':sum((dec(area)*record['quadrature_mass_m2']*(record['covariance_local_time_temperature_k_s']+(record['mean_local_time_s']-mean_t)*(record['mean_temperature_k']-mean_T)) for record,area in zip(records,areas)),D(0))/mass,
        'mean_local_time_temperature_k_s':result['local_time_temperature_moment_k_s_m2']/mass,
        'minimum_node_temperature_k':min(record['minimum_node_temperature_k'] for record in records),
        'maximum_node_temperature_k':max(record['maximum_node_temperature_k'] for record in records)})
    return result


def contrast_metrics(record):
    result = {key:dec(record['areal'][key]) for key in AREAL_KEYS if key!='total_energy_residual_j_m2'}
    result.update({key:dec(record['statistics'][key]) for key in STAT_KEYS})
    return result


def compare_contrasts(actual,reference,coarse,tolerance,reference_tolerance):
    maxima = {}
    differences = {}
    coarse_differences = {}
    for query_id,pair in reference.items():
        values = {key:item-contrast_metrics(pair['uniform'])[key] for key,item in contrast_metrics(pair['nonuniform']).items()}
        differences[query_id] = values
        cp = coarse[query_id]
        coarse_differences[query_id] = {key:item-contrast_metrics(cp['uniform'])[key] for key,item in contrast_metrics(cp['nonuniform']).items()}
        for key,value in values.items():
            maxima[key] = max(maxima.get(key,D(0)),abs(value))
    report = {}
    for query_id,pair in actual.items():
        values = {key:item-contrast_metrics(pair['uniform'])[key] for key,item in contrast_metrics(pair['nonuniform']).items()}
        report[query_id] = {}
        for key,expected in differences[query_id].items():
            difference = values[key]-expected
            change = expected-coarse_differences[query_id][key]
            scale = maxima[key]
            if key == 'input_energy_j_m2':
                if values[key] != 0 or expected != 0 or change != 0:
                    raise AssertionError('equal-input structural width contrast failed')
                ratio = D(0)
            elif scale == 0:
                # A tiny reference-only residual is not used as a fake physical floor.
                if difference != 0 or change != 0:
                    raise AssertionError('unresolved zero physical contrast: '+key)
                ratio = D(0)
            else:
                ratio = abs(difference)/scale
                if ratio > tolerance:
                    raise AssertionError('new own-width-contrast qualification failed: '+key+' '+str(ratio))
            reference_ratio = abs(change)/scale if scale else abs(change)
            if reference_ratio > reference_tolerance:
                raise AssertionError('own-width-contrast reference ladder unresolved: '+key+' '+str(reference_ratio))
            report[query_id][key] = {'prediction':values[key],'reference':expected,'reference_change':change,
                'signed_error':difference,'own_maximum_contrast_scale':scale,'scaled_absolute_error':ratio,
                'scaled_reference_change':reference_ratio,'reference_change_tolerance':reference_tolerance,
                'interpolation_tolerance':tolerance,'remaining_scaled_error_margin':tolerance-ratio,
                'numerical_sign_resolved':abs(expected)>abs(difference)+abs(change),
                'qualification':'Observed discrepancy plus finite reference change; not a certified bound or physical/statistical confidence.'}
    return report
