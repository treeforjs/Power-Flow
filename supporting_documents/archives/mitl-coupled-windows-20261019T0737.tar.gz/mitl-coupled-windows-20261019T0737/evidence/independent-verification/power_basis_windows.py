"""Independent exact ordinary-power-basis source-window algebra."""
from fractions import Fraction as F
import math
import sys

KB = F('1.380649e-23')
QE = F('1.602176634e-19')


def rational(value):
    return F(int(value['numerator']),int(value['denominator']))


def binary(value):
    return F.from_float(float(value))


def packed(value):
    return {'numerator':str(value.numerator),'denominator':str(value.denominator)}


def add(a,b):
    return [(a[i] if i<len(a) else F(0))+(b[i] if i<len(b) else F(0)) for i in range(max(len(a),len(b)))]


def product(a,b):
    result = [F(0)]*(len(a)+len(b)-1)
    for i,x in enumerate(a):
        for j,y in enumerate(b):
            result[i+j] += x*y
    return result


def evaluate(coefficients,x):
    result = F(0)
    for coefficient in reversed(coefficients):
        result = result*x+coefficient
    return result


def integral(coefficients,a,b):
    return sum((c*(b**(i+1)-a**(i+1))/(i+1) for i,c in enumerate(coefficients)),F(0))


def cubic(left,right,left_rate,right_rate,h):
    delta = right-left
    return [left,h*left_rate,3*delta-h*(2*left_rate+right_rate),-2*delta+h*(left_rate+right_rate)]


def statistics(values):
    m = values['released_m2']
    if m == 0:
        return {key:None for key in ('mean_local_time_s','variance_local_time_s2','mean_temperature_k',
            'variance_temperature_k2','mean_local_time_temperature_k_s','covariance_local_time_temperature_k_s')}
    t = values['local_time_first_moment_s_m2']/m
    temperature = values['temperature_first_moment_k_m2']/m
    joint = values['local_time_temperature_moment_k_s_m2']/m
    return {'mean_local_time_s':t,'variance_local_time_s2':values['local_time_second_moment_s2_m2']/m-t*t,
        'mean_temperature_k':temperature,'variance_temperature_k2':values['temperature_second_moment_k2_m2']/m-temperature**2,
        'mean_local_time_temperature_k_s':joint,'covariance_local_time_temperature_k_s':joint-t*temperature}


def window(cache,start,stop):
    history = cache['history']
    samples = history['samples']
    times = [rational(item) for item in cache['logical_time_s']]
    problem = history['problem']
    reservoir = problem['reservoir']
    removal = binary(reservoir['desorption_energy_ev'])*QE
    internal = binary(reservoir['internal_energy_ev'])*QE
    capacity = binary(problem['areal_heat_capacity_j_m2_k'])
    power = binary(history['schedule']['segments'][0]['power_w_m2'])
    keys = ['released_m2','local_time_first_moment_s_m2','local_time_second_moment_s2_m2',
        'temperature_first_moment_k_m2','temperature_second_moment_k2_m2','local_time_temperature_moment_k_s_m2']
    values = dict.fromkeys(keys,F(0))
    pieces = []
    endpoint_temperature = {}
    for j,(ta,tb) in enumerate(zip(times,times[1:])):
        a,b = max(ta,start),min(tb,stop)
        if a >= b:
            continue
        h = tb-ta
        m0,m1 = (binary(samples[i]['released_m2']) for i in (j,j+1))
        t0,t1 = (binary(samples[i]['temperature_k']) for i in (j,j+1))
        g0,g1 = (binary(cache['release_flux_m2_s'][i]) for i in (j,j+1))
        r0,r1 = (binary(cache['rhs'][i]['temperature_rate_k_s']) for i in (j,j+1))
        mpoly = cubic(m0,m1,g0,g1,h)
        tpoly = cubic(t0,t1,r0,r1,h)
        mcontrols = [m0,m0+h*g0/3,m1-h*g1/3,m1]
        tcontrols = [t0,t0+h*r0/3,t1-h*r1/3,t1]
        if any(x>y for x,y in zip(mcontrols,mcontrols[1:])):
            raise ArithmeticError('nonmonotone exact cubic emission controls')
        if any(not binary(problem['temperature_min_k']) <= t <= binary(problem['temperature_max_k']) for t in tcontrols):
            raise ArithmeticError('exact cubic temperature control outside domain')
        u,v = (a-ta)/h,(b-ta)/h
        derivative = [(i+1)*mpoly[i+1] for i in range(3)]
        tau = [ta-start,h]
        factors = [[F(1)],tau,product(tau,tau),tpoly,product(tpoly,tpoly),product(tau,tpoly)]
        terms = {key:integral(product(factor,derivative),u,v) for key,factor in zip(keys,factors)}
        for key,item in terms.items():
            values[key] += item
        endpoint_temperature[a] = evaluate(tpoly,u)
        endpoint_temperature[b] = evaluate(tpoly,v)
        pieces.append({'cell_index':j,'cell_start':ta,'cell_stop':tb,'query_start':a,'query_stop':b,
            'u_start':u,'u_stop':v,'emitted_power_coefficients':mpoly,'temperature_power_coefficients':tpoly,
            'emitted_controls':mcontrols,'temperature_controls':tcontrols,'integrals':terms})
    values['translational_energy_j_m2'] = 2*KB*values['temperature_first_moment_k_m2']
    values['binding_energy_j_m2'] = removal*values['released_m2']
    values['internal_energy_j_m2'] = internal*values['released_m2']
    values['total_wall_energy_debit_j_m2'] = values['binding_energy_j_m2']+values['internal_energy_j_m2']+values['translational_energy_j_m2']
    values['input_energy_j_m2'] = power*(stop-start)
    values['wall_thermal_change_j_m2'] = capacity*(endpoint_temperature[stop]-endpoint_temperature[start])
    values['adsorbate_reference_change_j_m2'] = values['binding_energy_j_m2']
    values['gas_energy_j_m2'] = values['internal_energy_j_m2']+values['translational_energy_j_m2']
    values['total_energy_residual_j_m2'] = values['wall_thermal_change_j_m2']+values['binding_energy_j_m2']+values['gas_energy_j_m2']-values['input_energy_j_m2']
    return {'areal':values,'statistics':statistics(values),'pieces':pieces,
        'endpoint_temperature_start_k':endpoint_temperature[start],'endpoint_temperature_stop_k':endpoint_temperature[stop]}


def check_record(actual,expected):
    if rational(actual['exact']) != expected:
        raise AssertionError('exact rational record mismatch')
    try:
        display = float(expected)
    except OverflowError:
        display = None
    if display is not None and not math.isfinite(display):
        display = None
    if display is None:
        if actual['value'] is not None:
            raise AssertionError('overflow projection mismatch')
    elif type(actual['value']) is not float or actual['value'].hex()!=display.hex():
        raise AssertionError('typed/signed float projection mismatch')
    flags = {'exact_zero':expected==0,'positive':expected>0,'negative':expected<0,
        'finite':display is not None,'underflowed':expected!=0 and display==0,
        'overflowed':display is None,'rounded':display is None or binary(display)!=expected,
        'subnormal':display is not None and 0<abs(display)<sys.float_info.min,
        'exact_rounding_error':None if display is None else packed(binary(display)-expected)}
    if actual['projection'] != flags:
        raise AssertionError('projection flags/error mismatch')


def check_statistics(actual,expected):
    count = 0
    for key,item in expected.items():
        declaration = actual[key]
        if item is None:
            if declaration != {'available':False,'reason':'exact_zero_emitted_mass','record':None}:
                raise AssertionError('empty statistic availability mismatch')
        else:
            if declaration['available'] is not True or declaration['reason'] is not None:
                raise AssertionError('nonempty statistic unavailable')
            check_record(declaration['record'],item)
            count += 1
    return count


def restricted_controls(coefficients,a,b):
    """Power-basis substitution then basis conversion by binomial identities."""
    n = len(coefficients)-1
    local = [sum((coefficients[j]*math.comb(j,k)*a**(j-k)*(b-a)**k
        for j in range(k,n+1)),F(0)) for k in range(n+1)]
    return [sum((local[k]*F(math.comb(i,k),math.comb(n,k)) for k in range(i+1)),F(0))
        for i in range(n+1)]


def check_pieces(actual,expected):
    if len(actual) != len(expected):
        raise AssertionError('piece inventory mismatch')
    count = 0
    for row,piece in zip(actual,expected):
        if type(row['source_cell_index']) is not int or row['source_cell_index'] != piece['cell_index']:
            raise AssertionError('source piece index mismatch')
        for key,reference_key in (('source_start_exact_s','cell_start'),('source_stop_exact_s','cell_stop'),
            ('start_exact_s','query_start'),('stop_exact_s','query_stop'),('source_u_start','u_start'),('source_u_stop','u_stop')):
            if rational(row[key]) != piece[reference_key]:
                raise AssertionError('source/query coordinate mismatch')
            count += 1
        m = restricted_controls(piece['emitted_power_coefficients'],piece['u_start'],piece['u_stop'])
        t = restricted_controls(piece['temperature_power_coefficients'],piece['u_start'],piece['u_stop'])
        checks = {'source_emitted_controls_m2':piece['emitted_controls'],
            'source_temperature_controls_k':piece['temperature_controls'],'emitted_controls_m2':m,
            'temperature_controls_k':t,'emitted_derivative_controls_m2':[3*(b-a) for a,b in zip(m,m[1:])]}
        for key,values in checks.items():
            if [rational(value) for value in row[key]] != values:
                raise AssertionError('exact independently substituted piece controls mismatch: '+key)
            count += len(values)
    return count
