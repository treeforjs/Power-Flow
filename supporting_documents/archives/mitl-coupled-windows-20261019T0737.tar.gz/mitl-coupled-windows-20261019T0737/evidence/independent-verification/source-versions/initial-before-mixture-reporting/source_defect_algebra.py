"""Exact represented-source defects kept separate from polynomial and IVP errors."""
from fractions import Fraction as F
from power_basis_windows import binary, rational, check_record, QE

MAPS = ('stored_channel_deltas','polynomial_minus_source','source_residual_deltas',
    'energy_defect_decomposition','wall_debit_difference_decomposition')
SCALARS = ('reconstructed_source_total_energy_residual_j_m2','energy_defect_difference_j_m2')
MOMENTS = ('local_time_first_moment_s_m2','local_time_second_moment_s2_m2',
    'temperature_first_moment_k_m2','temperature_second_moment_k2_m2','local_time_temperature_moment_k_s_m2')


def exact_source_defects(cache,polynomial,start,stop):
    times = [rational(item) for item in cache['logical_time_s']]
    if start not in times or stop not in times:
        return None
    ia,ib = times.index(start),times.index(stop)
    history = cache['history']
    a,b = history['samples'][ia],history['samples'][ib]
    fields = [key for key in a if key.endswith('_j_m2') or key in ('coverage_m2','released_m2','inventory_residual_m2')]
    delta = {key:binary(b[key])-binary(a[key]) for key in fields}
    p = history['problem']
    removal = binary(p['reservoir']['desorption_energy_ev'])*QE
    internal = binary(p['reservoir']['internal_energy_ev'])*QE
    nloss = binary(a['coverage_m2'])-binary(b['coverage_m2'])
    thermal = binary(p['areal_heat_capacity_j_m2_k'])*(binary(b['temperature_k'])-binary(a['temperature_k']))
    q = polynomial['areal']
    source_energy = thermal+removal*nloss+delta['internal_energy_j_m2']+delta['translational_energy_j_m2']-delta['input_energy_j_m2']
    energy_difference = q['total_energy_residual_j_m2']-source_energy
    energy_terms = {
        'source_inventory_removal_difference_j_m2':removal*(q['released_m2']-nloss),
        'source_internal_allocation_difference_j_m2':internal*q['released_m2']-delta['internal_energy_j_m2'],
        'translation_interpolant_minus_source_j_m2':q['translational_energy_j_m2']-delta['translational_energy_j_m2'],
        'source_input_accumulation_difference_j_m2':delta['input_energy_j_m2']-q['input_energy_j_m2']}
    wall_terms = {
        'source_binding_allocation_difference_j_m2':removal*q['released_m2']-delta['binding_energy_j_m2'],
        'source_internal_allocation_difference_j_m2':internal*q['released_m2']-delta['internal_energy_j_m2'],
        'translation_interpolant_minus_source_j_m2':q['translational_energy_j_m2']-delta['translational_energy_j_m2'],
        'negative_source_wall_channel_difference_j_m2':-(delta['total_wall_energy_debit_j_m2']-delta['binding_energy_j_m2']-delta['internal_energy_j_m2']-delta['translational_energy_j_m2'])}
    if sum(energy_terms.values(),F(0))!=energy_difference:
        raise AssertionError('independent exact energy-defect identity failed')
    if sum(wall_terms.values(),F(0))!=q['total_wall_energy_debit_j_m2']-delta['total_wall_energy_debit_j_m2']:
        raise AssertionError('independent exact gross-wall defect identity failed')
    return {'bounds_source_indices':[ia,ib],'stored_channel_deltas':delta,
        'polynomial_minus_source':{key:item-delta[key] for key,item in q.items() if key in delta},
        'source_residual_deltas':{key:item for key,item in delta.items() if 'residual' in key},
        'energy_defect_decomposition':energy_terms,'wall_debit_difference_decomposition':wall_terms,
        'reconstructed_source_total_energy_residual_j_m2':source_energy,
        'energy_defect_difference_j_m2':energy_difference}


def check_source_comparison(actual,expected):
    moment_expected = {key:{'available':False,'reason':'source_does_not_store_cumulative_time_or_temperature_moments','record':None} for key in MOMENTS}
    if actual['moment_comparisons']!=moment_expected:
        raise AssertionError('source cannot claim stored cumulative time/T moments')
    if expected is None:
        if actual['available'] is not False or actual['reason']!='window_bounds_not_both_saved_source_knots' or actual['bounds_source_indices'] is not None:
            raise AssertionError('off-knot stored-source comparison availability changed')
        if any(actual[key]!={} for key in MAPS) or any(actual[key] is not None for key in SCALARS):
            raise AssertionError('off-knot cumulative source values were invented')
        return 0
    if actual['available'] is not True or actual['reason'] is not None or actual['bounds_source_indices']!=expected['bounds_source_indices']:
        raise AssertionError('knot source comparison association changed')
    count = 0
    for category in MAPS:
        if set(actual[category])!=set(expected[category]):
            raise AssertionError('source defect map inventory changed '+category)
        for key,item in expected[category].items():
            check_record(actual[category][key],item)
            count += 1
    for key in SCALARS:
        check_record(actual[key],expected[key])
        count += 1
    return count


def extensive_name(key):
    return key[:-3]+'_number' if key in ('coverage_m2','released_m2','inventory_residual_m2') else key[:-3]


def scale_defects(reference,area):
    if reference is None:
        return None
    result = {category:{extensive_name(key):item*area for key,item in reference[category].items()} for category in MAPS}
    result.update({extensive_name(key):reference[key]*area for key in SCALARS})
    return result


def check_scaled_defects(actual,expected):
    if expected is None:
        if actual['available'] is not False or actual['reason']!='window_bounds_not_both_saved_source_knots' or actual['extensive']!={}:
            raise AssertionError('scaled off-knot comparison unavailable contract changed')
        return 0
    if actual['available'] is not True or actual['reason'] is not None:
        raise AssertionError('qualified scaled source defects unavailable')
    count = 0
    for category in MAPS:
        if set(actual['extensive'][category])!=set(expected[category]):
            raise AssertionError('scaled source defect keys changed')
        for key,item in expected[category].items():
            check_record(actual['extensive'][category][key],item)
            count += 1
    for key in SCALARS:
        name = extensive_name(key)
        check_record(actual['extensive'][name],expected[name])
        count += 1
    return count


def add_scaled_defects(records):
    if any(item is None for item in records):
        return None
    result = {category:{key:sum((row[category][key] for row in records),F(0)) for key in records[0][category]} for category in MAPS}
    result.update({extensive_name(key):sum((row[extensive_name(key)] for row in records),F(0)) for key in SCALARS})
    return result
