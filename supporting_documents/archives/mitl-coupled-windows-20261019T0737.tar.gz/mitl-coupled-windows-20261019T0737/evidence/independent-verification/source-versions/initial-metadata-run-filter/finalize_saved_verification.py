"""Associate saved new-query results and review without numerical replay."""
import datetime
from decimal import Decimal as D
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
WORK=HERE.parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def decimal(value):
    return D(value['decimal']) if isinstance(value,dict) and 'decimal' in value else D(value)


def maximum_ratio(document,key):
    found=[]
    def visit(item,path):
        if isinstance(item,dict):
            if key in item:
                found.append((decimal(item[key]),path))
            for name,value in item.items():
                visit(value,path+'/'+name)
        elif isinstance(item,list):
            for index,value in enumerate(item):
                visit(value,path+'/'+str(index))
    visit(document,'')
    value,path=max(found,default=(D(0),''))
    return {'checked_values':len(found),'maximum':str(value),'location':path}


def main():
    if (HERE/'completion.json').exists():
        raise RuntimeError('saved completion already exists')
    path=HERE/'query-initial/report.json'
    report=json.loads(path.read_text())
    assert report['status']=='passed' and report['all_checks_passed'] is True
    assert report['distinct_source_window_queries']==9 and report['patch_references']==18
    assert report['aggregate_windows']==6 and report['width_contrasts']==3
    assert report['old_reference_grid_calls']==report['old_source_RHS_calls']==report['producer_calls_by_oracle']==0
    assert report['forbidden_model_or_numerical_package_imports']==[]
    freeze=json.loads((HERE/'final_before_query_freeze.json').read_text())
    for name,digest in freeze['files_sha256'].items():
        assert sha(HERE/name)==digest
    for name,digest in report['checkpoint_sha256'].items():
        assert sha(HERE/'query-initial'/name)==digest
    for name,key in (('reference_windows.json','reference_windows_sha256'),
        ('exact_polynomial_windows.json','exact_polynomial_windows_sha256'),
        ('contrast_queries.json','contrast_queries_sha256'),('source_defects.json','source_defects_sha256')):
        assert sha(HERE/'query-initial'/name)==report[key]
    review_path=WORK/'oracle-review/completion.json'
    review=json.loads(review_path.read_text())
    assert review['status']=='accepted'
    # The independently written review must explicitly contain the final report hash.
    assert sha(path) in json.dumps(review,sort_keys=True)
    producer_path=WORK/'producer/reference-run/report.json'
    assert sha(producer_path)==report['producer_report_sha256']
    commands=[json.loads(line) for line in (WORK/'commands.jsonl').read_text().splitlines()]
    runs=[entry for entry in commands if entry['command'][-1]==str(HERE/'verify_window_queries.py')]
    assert len(runs)==1 and runs[0]['exit_code']==0
    assert sha(runs[0]['log'])==runs[0]['log_sha256']
    counts=report['new_work_counts']
    for key,expected in {'seeded_cells':384,'dense_substeps':1152,'quadrature_nodes':18432,
        'Gamma_node_evaluations':18432,'new_off_knot_state_values':12,
        'window_weight_accumulations':29952,'physical_state_exponential_evaluations':57600,
        'Taylor_coefficient_exponential_calls':107520}.items():
        assert counts[key]==expected
    windows=report['per_window_checks']
    aggregates=report['gross_mixture_checks']
    contrasts=report['own_width_contrast_checks']
    scalar_interpolation={case:{query:value['polynomial_vs_new_IVP'] for query,value in records.items()} for case,records in windows.items()}
    scalar_ladder={case:{query:value['reference_ladder_change'] for query,value in records.items()} for case,records in windows.items()}
    mixture_interpolation={hypothesis:{query:value['polynomial_vs_new_IVP'] for query,value in records.items()} for hypothesis,records in aggregates.items()}
    mixture_ladder={hypothesis:{query:value['reference_ladder_change'] for query,value in records.items()} for hypothesis,records in aggregates.items()}
    summary={'schema':'mitl-independent-coupled-window-summary-v1','status':'passed',
        'source_window_error':maximum_ratio(scalar_interpolation,'scaled_absolute_error'),
        'source_window_reference_change':maximum_ratio(scalar_ladder,'scaled_absolute_error'),
        'gross_mixture_error':maximum_ratio(mixture_interpolation,'scaled_absolute_error'),
        'gross_mixture_reference_change':maximum_ratio(mixture_ladder,'scaled_absolute_error'),
        'own_width_contrast_error':maximum_ratio(contrasts,'scaled_absolute_error'),
        'own_width_contrast_reference_change':maximum_ratio(contrasts,'scaled_reference_change'),
        'new_window_interpolation_target':'2e-4','reference_change_target':'1e-20',
        'new_work_counts':counts,'exact_check_counts':report['exact_check_counts'],
        'report_sha256':sha(path),'qualification':report['qualification']}
    (HERE/'summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True,allow_nan=False)+'\n')
    evidence={str(p.relative_to(WORK)):sha(p) for p in HERE.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='completion.json'}
    evidence['oracle-review/completion.json']=sha(review_path)
    completion={'schema':'mitl-independent-coupled-window-completion-v1','status':'passed','all_checks_passed':True,
        'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'distinct_source_window_queries':9,'precision_levels':2,'new_moment_checkpoints':6,
        'reference_window_records_across_levels':18,'patch_references':18,'aggregate_windows':6,'width_contrasts':3,
        'new_off_knot_endpoint_state_pairs':12,'new_off_knot_scalar_coordinates':24,
        'polynomial_pieces_checked':315,'source_window_knot_comparisons_available':6,
        'source_window_off_knot_comparisons_unavailable':3,
        'new_work_counts':counts,'exact_check_counts':report['exact_check_counts'],
        'completed_independent_query_runs':1,'independent_query_run_attempts':1,
        'old_reference_grid_calls':0,'old_source_RHS_calls':0,'production_source_evolution_calls':0,
        'producer_calls_by_oracle':0,'old_suites_repeated':False,'old_references_repeated':False,
        'source_emission_windows_are_photon_gates':False,'physical_uncertainty_established':False,
        'host_budget_accepted':False,'owner_implementation_verified':False,
        'report_sha256':sha(path),'summary_sha256':sha(HERE/'summary.json'),
        'final_static_review_sha256':sha(review_path),'producer_report_sha256':sha(producer_path),
        'query_run_command':runs[0],
        'source_sha256':report['source_version_sha256'],'artifact_sha256':evidence,
        'qualification':report['qualification']}
    (HERE/'completion.json').write_text(json.dumps(completion,indent=2,sort_keys=True,allow_nan=False)+'\n')
    print(json.dumps({'completion_sha256':sha(HERE/'completion.json'),'summary_sha256':sha(HERE/'summary.json'),
        'summary':summary},indent=2))


if __name__=='__main__':
    main()
