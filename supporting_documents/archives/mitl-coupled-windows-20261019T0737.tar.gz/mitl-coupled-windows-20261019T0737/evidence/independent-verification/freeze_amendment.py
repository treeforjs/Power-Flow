"""Preserve initial code and freeze two pre-query completeness corrections."""
import ast
import datetime
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    target = HERE/'pre_query_completeness_amendment.json'
    if target.exists() or (HERE/'query-initial').exists():
        raise RuntimeError('amendment must precede the first independent query')
    initial = json.loads((HERE/'before_query_code_freeze.json').read_text())
    old = HERE/'source-versions/initial-before-mixture-reporting'
    for name,digest in initial['files_sha256'].items():
        if sha(old/name)!=digest:
            raise RuntimeError('initial frozen bytes not preserved '+name)
        if name not in ('verify_window_queries.py','window_query_checks.py') and sha(HERE/name)!=digest:
            raise RuntimeError('unexpected mathematical/input edit '+name)
    current = {name:sha(HERE/name) for name in initial['files_sha256']}
    for name in current:
        if name.endswith('.py'):
            ast.parse((HERE/name).read_text(),filename=name)
    document = {
        'schema':'mitl-window-pre-query-completeness-amendment-v1',
        'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'original_code_freeze_sha256':sha(HERE/'before_query_code_freeze.json'),
        'preserved_directory':str(old),'final_files_sha256':current,
        'changes':[
            'Explicitly report and admit six gross mixture physical comparisons plus their reference changes, rather than relying on exact aggregation plus per-source admission. Thermal error uses C_areal times total physical area.',
            'Enforce the already declared1e-20 reference-change tolerance separately on each own width-contrast scale after subtraction. Record the reference ratio and interpolation margin.'
        ],
        'mathematical_primitives_changed':False,'fixtures_changed':False,'tolerances_changed':False,
        'new_query_calls_before_amendment':0,'producer_replays':0,
        'plan_sha256':sha(HERE/'oracle_plan.json'),'config_sha256':sha(HERE/'input_config.json'),
        'qualification':'Pre-first-query completeness corrections only. Original files/freeze remain available; no numerical acceptance or replay is claimed.'}
    target.write_text(json.dumps(document,indent=2,sort_keys=True,allow_nan=False)+'\n')
    print(json.dumps({'amendment_sha256':sha(target),'final_files_sha256':current},indent=2))


if __name__=='__main__':
    main()
