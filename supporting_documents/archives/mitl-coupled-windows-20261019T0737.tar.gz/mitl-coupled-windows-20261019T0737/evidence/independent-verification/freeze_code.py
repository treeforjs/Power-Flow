"""Syntax and byte freeze only; no independent numerical query is evaluated."""
import ast
import datetime
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
WORK = HERE.parent
NAMES = ('verify_window_queries.py','seeded_window_reference.py','power_basis_windows.py',
    'window_query_checks.py','source_defect_algebra.py','decimal_forced_reference.py',
    'output_contract.json','oracle_plan.json','input_config.json','freeze_code.py')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    target = HERE/'before_query_code_freeze.json'
    if target.exists() or (HERE/'query-initial').exists():
        raise RuntimeError('new code freeze must precede the only independent query pass')
    before = json.loads((HERE/'before_plan_freeze.json').read_text())
    for name,digest in before['frozen'].items():
        if sha(HERE/name)!=digest:
            raise RuntimeError('a-priori mathematical plan/input changed')
    for name in NAMES:
        if name.endswith('.py'):
            tree = ast.parse((HERE/name).read_text(),filename=name)
            if name!='decimal_forced_reference.py' and any(isinstance(node,ast.Call) and isinstance(node.func,ast.Name) and node.func.id=='reference_grid' for node in ast.walk(tree)):
                raise RuntimeError('old reference grid driver call prohibited')
    document = {'schema':'mitl-coupled-window-before-query-code-freeze-v1',
        'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'files_sha256':{name:sha(HERE/name) for name in NAMES},
        'plan_freeze_sha256':sha(HERE/'before_plan_freeze.json'),
        'accepted_plan_review_sha256':sha(WORK/'oracle-review/plan_review.json'),
        'producer_report_already_exists':(WORK/'producer/reference-run/report.json').exists(),
        'new_query_calls_before_freeze':0,'old_reference_driver_calls':0,
        'qualification':'Syntax and raw-byte binding only. Full-code review is required before the first new moment query; no numerical acceptance is claimed here.'}
    target.write_text(json.dumps(document,indent=2,sort_keys=True,allow_nan=False)+'\n')
    print(json.dumps({'freeze_sha256':sha(target),'files_sha256':document['files_sha256']},indent=2))


if __name__=='__main__':
    main()
