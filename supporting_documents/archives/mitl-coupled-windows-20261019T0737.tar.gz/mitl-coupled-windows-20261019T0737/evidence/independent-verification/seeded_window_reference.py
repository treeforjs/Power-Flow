"""New local moment queries from immutable independently accepted knot states.

The qualified Taylor primitives are reused; their old grid driver is never called.
"""
from decimal import Decimal as D, localcontext
from fractions import Fraction as F
from decimal_forced_reference import (KB, ReferenceParameters, decimal_fraction,
    probability_rule, taylor_coefficients, evaluate)


class WeightedMoments:
    def __init__(self):
        self.mass = self.mean_t = self.mean_T = D(0)
        self.center_t = self.center_T = self.cross = D(0)
        self.raw_t = self.raw_tt = self.raw_T = self.raw_TT = self.raw_tT = D(0)
        self.translation = self.wall = D(0)
        self.min_T = self.max_T = None

    def add(self, weight, time, temperature, parameters):
        if weight <= 0:
            raise ArithmeticError('positive quadrature mass required')
        total = self.mass + weight
        dt, dT = time-self.mean_t, temperature-self.mean_T
        new_t = self.mean_t + weight*dt/total
        new_T = self.mean_T + weight*dT/total
        self.center_t += weight*dt*(time-new_t)
        self.center_T += weight*dT*(temperature-new_T)
        self.cross += weight*dt*(temperature-new_T)
        self.mass, self.mean_t, self.mean_T = total, new_t, new_T
        self.raw_t += weight*time
        self.raw_tt += weight*time*time
        self.raw_T += weight*temperature
        self.raw_TT += weight*temperature*temperature
        self.raw_tT += weight*time*temperature
        self.translation += weight*(2*KB*temperature)
        self.wall += weight*(parameters.removal+parameters.internal+2*KB*temperature)
        self.min_T = temperature if self.min_T is None else min(self.min_T,temperature)
        self.max_T = temperature if self.max_T is None else max(self.max_T,temperature)

    def result(self):
        if self.mass <= 0:
            raise ArithmeticError('manufactured positive query unexpectedly empty')
        return {
            'quadrature_mass_m2':self.mass,
            'local_time_first_moment_s_m2':self.raw_t,
            'local_time_second_moment_s2_m2':self.raw_tt,
            'temperature_first_moment_k_m2':self.raw_T,
            'temperature_second_moment_k2_m2':self.raw_TT,
            'local_time_temperature_moment_k_s_m2':self.raw_tT,
            'translational_energy_j_m2':self.translation,
            'total_wall_energy_debit_j_m2':self.wall,
            'mean_local_time_s':self.mean_t,
            'variance_local_time_s2':self.center_t/self.mass,
            'mean_temperature_k':self.mean_T,
            'variance_temperature_k2':self.center_T/self.mass,
            'mean_local_time_temperature_k_s':self.raw_tT/self.mass,
            'covariance_local_time_temperature_k_s':self.cross/self.mass,
            'minimum_node_temperature_k':self.min_T,
            'maximum_node_temperature_k':self.max_T,
        }


def value(sample,key):
    return D(sample[key]['decimal'])


def time_of(sample):
    item = sample['logical_time']
    return F(int(item['numerator']),int(item['denominator']))


def decode(s,z,nseg,p):
    n = nseg*(-s).exp()
    b = 2*KB*(nseg-n)/p.capacity
    temperature = z*(-b).exp()-p.shift
    if not (0 < n <= nseg <= p.nmax and p.tmin <= temperature <= p.tmax):
        raise ArithmeticError('new independent local query outside declared domain')
    return n,temperature


def query_reference(problem,power_input,seeds,queries,*,precision,order,subdivisions,quadrature_order):
    """Integrate NEW moment integrands, independently reseeding each original cell."""
    with localcontext() as context:
        context.prec = precision
        p = ReferenceParameters.from_inputs(problem)
        power = D.from_float(float(power_input))
        boundaries = {edge for _,a,b in queries for edge in (a,b)}
        endpoint = {}
        for sample in seeds:
            t = time_of(sample)
            if t in boundaries:
                endpoint[t] = (value(sample,'coverage_m2'),value(sample,'temperature_k'))
        accumulators = {key:WeightedMoments() for key,_,_ in queries}
        counts = {'seeded_cells':0,'dense_substeps':0,'quadrature_nodes':0,
            'Gamma_node_evaluations':0,'new_off_knot_state_values':0,
            'physical_state_exponential_evaluations':0,'Taylor_coefficient_exponential_calls':0,
            'window_weight_accumulations':0,
            'old_full_state_driver_calls':0,'source_RHS_calls':0}
        max_n_consistency = max_t_consistency = D(0)
        rule = probability_rule(quadrature_order,precision)
        for left,right in zip(seeds,seeds[1:]):
            a,b = time_of(left),time_of(right)
            nseg = value(left,'coverage_m2')
            s,z = D(0),value(left,'temperature_k')+p.shift
            h_fraction = (b-a)/subdivisions
            h = p.nu*decimal_fraction(h_fraction)
            counts['seeded_cells'] += 1
            for substep in range(subdivisions):
                sa,sb = a+substep*h_fraction,a+(substep+1)*h_fraction
                if any(sa < edge < sb for edge in boundaries):
                    raise ArithmeticError('query boundary must align the predeclared new substeps')
                sc,zc = taylor_coefficients(s,z,p,nseg,power,order)
                counts['dense_substeps'] += 1
                counts['Taylor_coefficient_exponential_calls'] += 4*order
                for node,weight in rule:
                    ns,temperature = decode(evaluate(sc,h*node),evaluate(zc,h*node),nseg,p)
                    factor = (-p.activation*(1-p.alpha*ns/p.nref)/(KB*temperature)).exp()
                    if not 0 < factor <= 1:
                        raise ArithmeticError('independent query Arrhenius factor unsupported')
                    emitted_weight = weight*h*ns*factor
                    node_time = decimal_fraction(sa)+node*decimal_fraction(h_fraction)
                    counts['quadrature_nodes'] += 1
                    counts['Gamma_node_evaluations'] += 1
                    counts['physical_state_exponential_evaluations'] += 3
                    for key,qa,qb in queries:
                        if qa <= sa and sb <= qb:
                            accumulators[key].add(emitted_weight,node_time-decimal_fraction(qa),temperature,p)
                            counts['window_weight_accumulations'] += 1
                s,z = evaluate(sc,h),evaluate(zc,h)
                end_n,end_t = decode(s,z,nseg,p)
                counts['physical_state_exponential_evaluations'] += 2
                if sb in boundaries and sb not in endpoint:
                    endpoint[sb] = (end_n,end_t)
                    counts['new_off_knot_state_values'] += 1
            max_n_consistency = max(max_n_consistency,abs(end_n-value(right,'coverage_m2')))
            max_t_consistency = max(max_t_consistency,abs(end_t-value(right,'temperature_k')))
        windows = {}
        for key,a,b in queries:
            stats = accumulators[key].result()
            na,ta = endpoint[a]
            nb,tb = endpoint[b]
            emitted = na-nb
            if emitted <= 0:
                raise ArithmeticError('endpoint inventory difference unresolved')
            stats.update({
                'released_m2':emitted,
                'binding_energy_j_m2':p.removal*emitted,
                'internal_energy_j_m2':p.internal*emitted,
                'input_energy_j_m2':power*decimal_fraction(b-a),
                'wall_thermal_change_j_m2':p.capacity*(tb-ta),
                'adsorbate_reference_change_j_m2':p.removal*emitted,
                'gas_energy_j_m2':p.internal*emitted+stats['translational_energy_j_m2'],
                'endpoint_temperature_start_k':ta,'endpoint_temperature_stop_k':tb,
                'endpoint_coverage_start_m2':na,'endpoint_coverage_stop_m2':nb,
                'endpoint_minus_quadrature_mass_m2':emitted-stats['quadrature_mass_m2'],
            })
            stats['total_energy_residual_j_m2'] = (stats['wall_thermal_change_j_m2']+
                stats['binding_energy_j_m2']+stats['internal_energy_j_m2']+
                stats['translational_energy_j_m2']-stats['input_energy_j_m2'])
            stats['independent_wall_residual_j_m2'] = (stats['wall_thermal_change_j_m2']+
                stats['total_wall_energy_debit_j_m2']-stats['input_energy_j_m2'])
            stats['independent_wall_allocation_residual_j_m2'] = (stats['total_wall_energy_debit_j_m2']-
                stats['binding_energy_j_m2']-stats['internal_energy_j_m2']-stats['translational_energy_j_m2'])
            windows[key] = stats
        return {'windows':windows,'counts':counts,
            'local_endpoint_consistency_max':{'coverage_m2':max_n_consistency,'temperature_k':max_t_consistency},
            'off_knot_endpoints':{str(t):{'coverage_m2':n,'temperature_k':temperature}
                for t,(n,temperature) in endpoint.items() if all(time_of(item)!=t for item in seeds)}}
