"""Bind final pre-query exact-zero guard and unchanged source/mathematical inputs."""
import ast
import datetime
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    if (HERE/'query-initial').exists() or (HERE/'final_before_query_freeze.json').exists():
        raise RuntimeError('final freeze must precede all query evaluations')
    amendment=json.loads((HERE/'pre_query_completeness_amendment.json').read_text())
    previous=HERE/'source-versions/before-exact-zero-contrast-guard/window_query_checks.py'
    assert sha(previous)==amendment['final_files_sha256']['window_query_checks.py']
    for name,digest in amendment['final_files_sha256'].items():
        if name!='window_query_checks.py':
            assert sha(HERE/name)==digest
        if name.endswith('.py'):
            ast.parse((HERE/name).read_text(),filename=name)
    files={name:sha(HERE/name) for name in amendment['final_files_sha256']}
    document={'schema':'mitl-window-final-before-query-freeze-v1',
        'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'files_sha256':files,'prior_amendment_sha256':sha(HERE/'pre_query_completeness_amendment.json'),
        'final_guard':'Own width-contrast scale exactly zero requires both prediction difference and coarse/refined change exactly zero; no dimensionful fallback tolerance.',
        'preserved_guard_parent_sha256':sha(previous),'mathematical_or_tolerance_change':False,
        'new_query_calls_before_freeze':0,'old_full_state_or_RHS_calls':0}
    target=HERE/'final_before_query_freeze.json'
    target.write_text(json.dumps(document,indent=2,sort_keys=True,allow_nan=False)+'\n')
    print(json.dumps({'freeze_sha256':sha(target),'files_sha256':files},indent=2))


if __name__=='__main__':
    main()
