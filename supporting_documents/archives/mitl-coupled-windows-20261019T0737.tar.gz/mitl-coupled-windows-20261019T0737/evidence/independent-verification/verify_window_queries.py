"""One new bounded moment-query verification; immutable old states are inputs only."""
import datetime
import csv
from decimal import Decimal as D, localcontext
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path
import sys

from seeded_window_reference import query_reference
from power_basis_windows import (window, rational, binary, packed, check_record,
    check_statistics, check_pieces, statistics)
from window_query_checks import (AREAL_KEYS, STAT_KEYS, dec, scales, compare,
    reference_as_polynomial, reference_consistency, aggregate_fraction, aggregate_reference,
    compare_contrasts)
from source_defect_algebra import (exact_source_defects,check_source_comparison,
    scale_defects,check_scaled_defects,add_scaled_defects)

HERE = Path(__file__).resolve().parent
WORK = HERE.parent
OLD = Path('/workspace/research_work/mitl-upstream-20261019T0710')
OUT = HERE/'query-initial'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def encode(value):
    if isinstance(value,D):
        return {'decimal':str(value),'float_projection':float(value)}
    if isinstance(value,F):
        return packed(value)
    if isinstance(value,dict):
        return {key:encode(item) for key,item in value.items()}
    if isinstance(value,(list,tuple)):
        return [encode(item) for item in value]
    return value


def write(path,document):
    path.write_text(json.dumps(encode(document),indent=2,sort_keys=True,allow_nan=False)+'\n')


def load_bound_inputs():
    config = json.loads((HERE/'input_config.json').read_text())
    plan = json.loads((HERE/'oracle_plan.json').read_text())
    freeze = json.loads((HERE/'before_plan_freeze.json').read_text())
    for name,digest in freeze['frozen'].items():
        if sha(HERE/name)!=digest:
            raise RuntimeError('changed a-priori frozen input '+name)
    files = {}
    for alias,record in config['source_binding']['files'].items():
        path = OLD/record['relative_path']
        if sha(path)!=record['sha256']:
            raise RuntimeError('changed accepted source '+alias)
        files[alias] = json.loads(path.read_text())
    for name,record in config['source_binding']['lineage']['auxiliary_files'].items():
        if sha(OLD/record['relative_path'])!=record['sha256']:
            raise RuntimeError('changed source-version lineage '+name)
    for name,digest in files['independent_report']['reference_checkpoint_sha256'].items():
        if sha(OLD/'independent-verification/oracle-initial'/name)!=digest:
            raise RuntimeError('changed own-precision checkpoint '+name)
    return config,plan,files


def own_queries(config,old_config):
    duration = binary(old_config['duration_s'])
    return tuple((item['window_id'],duration*rational(item['start_fraction']),duration*rational(item['stop_fraction']))
        for item in config['queries'])


def distinct_math(assembly,queries):
    return {case:{key:window(cache,start,stop) for key,start,stop in queries}
        for case,cache in assembly['scalar_histories'].items()}


def new_references(old_config,queries,plan):
    references = {'coarse':{},'refined':{}}
    checkpoint_hashes = {}
    totals = {}
    for case in old_config['scalar_cases']:
        case_id = case['case_id']
        for level in ('coarse','refined'):
            precision = plan[level+'_precision']
            checkpoint_name = case_id+'_'+level+'_checkpoint.json'
            seeds = json.loads((OLD/'independent-verification/oracle-initial'/checkpoint_name).read_text())['samples']
            result = query_reference(old_config['common_scalar_problem'],case['power_w_m2'],seeds,queries,
                precision=precision,order=plan[level+'_Taylor_order'],
                subdivisions=plan[level+'_subdivisions'],quadrature_order=plan[level+'_quadrature_order'])
            checkpoint = OUT/(case_id+'_'+level+'_moment_checkpoint.json')
            write(checkpoint,{'schema':'mitl-seeded-new-window-reference-checkpoint-v1','case_id':case_id,
                'level':level,'precision':precision,'Taylor_order':plan[level+'_Taylor_order'],
                'subdivisions':plan[level+'_subdivisions'],'quadrature_order':plan[level+'_quadrature_order'],
                'seed_checkpoint_sha256':sha(OLD/'independent-verification/oracle-initial'/checkpoint_name),
                'result':result})
            checkpoint_hashes[checkpoint.name] = sha(checkpoint)
            references[level][case_id] = result
            for key,count in result['counts'].items():
                totals[key] = totals.get(key,0)+count
            print(json.dumps({'checkpoint':checkpoint.name,'sha256':checkpoint_hashes[checkpoint.name],
                'counts':result['counts']}),flush=True)
    expected = {'seeded_cells':384,'dense_substeps':1152,'quadrature_nodes':18432,
        'Gamma_node_evaluations':18432,'new_off_knot_state_values':12,'source_RHS_calls':0,
        'old_full_state_driver_calls':0}
    for key,count in expected.items():
        if totals[key]!=count:
            raise AssertionError('unexpected fresh query work count '+key)
    return references,checkpoint_hashes,totals


def reference_checks(math_records,references,old_config,plan):
    report = {}
    capacity = D.from_float(float(old_config['common_scalar_problem']['areal_heat_capacity_j_m2_k']))
    for case,queries in math_records.items():
        fine = references['refined'][case]['windows']
        coarse = references['coarse'][case]['windows']
        maximum = scales(fine.values())
        report[case] = {}
        for key,record in queries.items():
            report[case][key] = {
                'polynomial_vs_new_IVP':compare(record,fine[key],maximum,capacity,D(plan['new_window_interpolation_tolerance'])),
                'reference_ladder_change':compare(reference_as_polynomial(coarse[key]),fine[key],maximum,capacity,D(plan['reference_change_tolerance'])),
                'refined_positive_integral_consistency':reference_consistency(fine[key],D(plan['reference_physical_consistency_tolerance']))}
    return report


def mixtures(math_records,references,old_config,query_ids):
    edges = [rational(item) for item in old_config['geometry']['width_edges_m']]
    length = rational(old_config['geometry']['common_length_m'])
    areas = [(b-a)*length for a,b in zip(edges,edges[1:])]
    exact = {}
    independent = {'coarse':{},'refined':{}}
    for key in query_ids:
        exact[key] = {}
        for level in independent:
            independent[level][key] = {}
        for hypothesis,cases in old_config['hypotheses'].items():
            exact[key][hypothesis] = aggregate_fraction([math_records[case][key] for case in cases],areas)
            for level in independent:
                independent[level][key][hypothesis] = aggregate_reference(
                    [references[level][case]['windows'][key] for case in cases],areas)
    return exact,independent,areas


def independent_mixture_as_records(mixtures):
    return {key:{hypothesis:reference_as_polynomial(value) for hypothesis,value in pair.items()}
        for key,pair in mixtures.items()}


def check_mixture_physical_errors(actual,reference,areas,old_config,plan):
    capacity = D.from_float(float(old_config['common_scalar_problem']['areal_heat_capacity_j_m2_k']))*dec(sum(areas,F(0)))
    report = {}
    for hypothesis in old_config['hypotheses']:
        maximum = scales(pair[hypothesis] for pair in reference['refined'].values())
        report[hypothesis] = {}
        for query_id,pair in actual.items():
            fine = reference['refined'][query_id][hypothesis]
            coarse = reference['coarse'][query_id][hypothesis]
            report[hypothesis][query_id] = {
                'polynomial_vs_new_IVP':compare(pair[hypothesis],fine,maximum,capacity,D(plan['new_window_interpolation_tolerance'])),
                'reference_ladder_change':compare(reference_as_polynomial(coarse),fine,maximum,capacity,D(plan['reference_change_tolerance'])),
                'quantity_convention':'All number and energy/moment totals are physical extensive quantities here; temperature/local-time statistics remain normalized mixture diagnostics.'}
    return report


def extensive_key(key):
    return key[:-3]+'_number' if key in ('released_m2','coverage_m2','inventory_residual_m2') else key[:-3]


def verify_source_windows(document,math_records,queries,assembly):
    records = document['source_windows']
    rows = list(records.values()) if isinstance(records,dict) else records
    if len(rows)!=9:
        raise AssertionError('distinct source-window inventory must equal9')
    count = pieces = 0
    found = set()
    for row in rows:
        case,key = row['source_history_id'],row['query_id']
        if (case,key) in found:
            raise AssertionError('duplicate distinct source-window')
        found.add((case,key))
        expected = math_records[case][key]
        start,stop = next((a,b) for q,a,b in queries if q==key)
        for field,value in (('window_start_exact_s',start),('window_stop_exact_s',stop),('local_time_anchor_exact_s',start)):
            if rational(row[field])!=value:
                raise AssertionError('window/common local anchor mismatch')
        if row['canonical_history_sha256']!=assembly['scalar_histories'][case]['history_sha256']:
            raise AssertionError('canonical source history association mismatch')
        expected_state = assembly['scalar_histories'][case]['history']['problem']['reservoir']['state_id']
        if row['state_id']!=expected_state:
            raise AssertionError('exact state label association mismatch')
        for quantity,value in expected['areal'].items():
            check_record(row['areal'][quantity],value)
            count += 1
        count += check_statistics(row['statistics'],expected['statistics'])
        pieces += check_pieces(row['pieces'],expected['pieces'])
        cache = assembly['scalar_histories'][case]
        for piece in row['pieces']:
            j = piece['source_cell_index']
            references = []
            for node in (j,j+1):
                sample = cache['history']['samples'][node]
                references.append({'sample_index':node,'coverage_m2':sample['coverage_m2'],
                    'released_m2':sample['released_m2'],'release_flux_m2_s':cache['rhs'][node]['release_flux_m2_s'],
                    'temperature_rate_k_s':cache['rhs'][node]['temperature_rate_k_s'],
                    'inventory_residual_m2':sample['inventory_residual_m2'],
                    'scalar_residuals':{name:value for name,value in sample.items() if name.endswith('_residual_j_m2')}})
            strict_same(piece['source_endpoint_references'],references)
    return {'quantity_and_statistic_records':count,'piece_exact_associations':pieces}


def strict_same(actual,expected):
    if type(actual) is not type(expected):
        raise AssertionError('source association JSON type mismatch')
    if type(expected) is float:
        if actual.hex()!=expected.hex():
            raise AssertionError('source signed float association mismatch')
    elif type(expected) is dict:
        if set(actual)!=set(expected):
            raise AssertionError('source association key inventory mismatch')
        for key,item in expected.items():
            strict_same(actual[key],item)
    elif type(expected) is list:
        if len(actual)!=len(expected):
            raise AssertionError('source association list inventory mismatch')
        for a,b in zip(actual,expected):
            strict_same(a,b)
    elif actual!=expected:
        raise AssertionError('source identity association mismatch')


def verify_defect_layers(document,polynomial,queries,assembly,areas,old_config):
    expected = {case:{key:exact_source_defects(cache,polynomial[case][key],a,b) for key,a,b in queries}
        for case,cache in assembly['scalar_histories'].items()}
    count = 0
    for row in document['source_windows']:
        count += check_source_comparison(row['source_RK_comparison'],expected[row['source_history_id']][row['query_id']])
    source_keys = {(row['source_history_id'],row['query_id']):row['source_window_key'] for row in document['source_windows']}
    for row in document['patch_windows']:
        case,key,index = row['source_history_id'],row['query_id'],row['patch_index']
        comparison = row['source_RK_comparison']
        if comparison['source_window_key']!=source_keys[case,key]:
            raise AssertionError('patch defect source association mismatch')
        count += check_scaled_defects(comparison,scale_defects(expected[case][key],areas[index]))
    for row in document['aggregate_windows']:
        hypothesis,key = row['hypothesis'],row['query_id']
        cases = old_config['hypotheses'][hypothesis]
        comparison = row['source_RK_comparison']
        if comparison['source_window_keys']!=[source_keys[case,key] for case in cases]:
            raise AssertionError('mixture source defect patch inventory mismatch')
        count += check_scaled_defects(comparison,add_scaled_defects([
            scale_defects(expected[case][key],area) for case,area in zip(cases,areas)]))
    return {'exact_source_defect_records':count},expected


def verify_mixture_records(document,math_records,mixture,areas,old_config):
    count = 0
    patches = document['patch_windows']
    aggregates = document['aggregate_windows']
    contrasts = document['width_window_contrasts']
    if not (len(patches)==18 and len(aggregates)==6 and len(contrasts)==3):
        raise AssertionError('window patch/aggregate/contrast inventories differ')
    seen = set()
    source_keys = {row['source_window_key']:(row['source_history_id'],row['query_id']) for row in document['source_windows']}
    if len(source_keys)!=9:
        raise AssertionError('distinct source-window reference keys are not unique')
    for row in patches:
        hypothesis,index,key = row['hypothesis'],row['patch_index'],row['query_id']
        identity = (hypothesis,index,key)
        if identity in seen or type(index) is not int:
            raise AssertionError('duplicate or mistyped patch identity')
        seen.add(identity)
        case = old_config['hypotheses'][hypothesis][index]
        if row['source_history_id']!=case or rational(row['area_exact_m2'])!=areas[index]:
            raise AssertionError('patch source/actual area association mismatch')
        if source_keys[row['source_window_key']]!=(case,key):
            raise AssertionError('patch references a different cached source-window')
        for quantity,value in math_records[case][key]['areal'].items():
            check_record(row['extensive'][extensive_key(quantity)],value*areas[index])
            count += 1
        count += check_statistics(row['statistics'],math_records[case][key]['statistics'])
    for row in aggregates:
        expected = mixture[row['query_id']][row['hypothesis']]
        for quantity,value in expected['areal'].items():
            check_record(row['extensive'][extensive_key(quantity)],value)
            count += 1
        count += check_statistics(row['statistics'],expected['statistics'])
    for row in contrasts:
        pair = mixture[row['query_id']]
        for key,item in pair['nonuniform']['areal'].items():
            check_record(row['quantity_difference_nonuniform_minus_uniform'][extensive_key(key)],item-pair['uniform']['areal'][key])
            count += 1
        for key,item in pair['nonuniform']['statistics'].items():
            declaration = row['statistics_difference_nonuniform_minus_uniform'][key]
            if declaration['available'] is not True or declaration['reason'] is not None:
                raise AssertionError('positive contrast statistic unavailable')
            check_record(declaration['record'],item-pair['uniform']['statistics'][key])
            count += 1
    return {'mixture_quantity_and_statistic_records':count}


def csv_cell_expectations(document):
    result = {}
    def visit(value,path):
        if isinstance(value,dict) and set(value)=={'exact','value','projection'}:
            result[path] = value['value']
            result[path+'__exact_numerator'] = value['exact']['numerator']
            result[path+'__exact_denominator'] = value['exact']['denominator']
            result[path+'__projection_json'] = json.dumps(value['projection'],sort_keys=True,separators=(',',':'),allow_nan=False)
        elif isinstance(value,dict):
            for key,item in value.items():
                visit(item,path+'__'+key if path else key)
        elif isinstance(value,list):
            result[path] = json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False)
        else:
            result[path] = value
    visit(document,'')
    return result


def verify_csvs(producer,document):
    tables = {key:document[key] for key in ('patch_windows','aggregate_windows','width_window_contrasts')}
    tables['source_windows'] = [{**{key:value for key,value in row.items() if key!='pieces'},
        'piece_count':len(row['pieces'])} for row in document['source_windows']]
    tables['polynomial_pieces'] = [{'source_history_id':row['source_history_id'],'query_id':row['query_id'],
        'state_id':row['state_id'],'piece_index':index,'piece':piece}
        for row in document['source_windows'] for index,piece in enumerate(row['pieces'])]
    cells = numeric = rows = 0
    for name,source_rows in tables.items():
        with (producer/(name+'.csv')).open(newline='') as stream:
            reader = csv.DictReader(stream)
            actual_rows = list(reader)
            headers = reader.fieldnames
        expected_rows = [csv_cell_expectations(row) for row in source_rows]
        if len(actual_rows)!=len(expected_rows) or set(headers)!={key for row in expected_rows for key in row}:
            raise AssertionError('CSV row/column inventory mismatch '+name)
        for row,expected in zip(actual_rows,expected_rows):
            rows += 1
            for key in headers:
                value = expected.get(key)
                actual = row[key]
                if type(value) is float:
                    if float(actual).hex()!=value.hex():
                        raise AssertionError('CSV signed float projection mismatch '+name+'/'+key)
                    numeric += 1
                else:
                    text = 'null' if value is None else 'true' if value is True else 'false' if value is False else str(value)
                    if actual!=text:
                        raise AssertionError('CSV typed declaration mismatch '+name+'/'+key)
                cells += 1
    return {'CSV_rows':rows,'CSV_cells':cells,'CSV_float_projections':numeric}


def verify_declarations(document,config):
    if document['parameter_status']!='manufactured' or document['host_budget_accepted'] is not False or document['owner_implementation_verified'] is not False:
        raise AssertionError('manufactured/no acceptance declarations changed')
    if document['source_admission']['file_sha256']!={key:value['sha256'] for key,value in config['source_binding']['files'].items()}:
        raise AssertionError('accepted immutable source raw-file association changed')
    zero_calls = {'history_evolution':0,'RHS':0,'assembly':0}
    if document['cache']!={'distinct_source_windows':9,'patch_references':18,'aggregate_windows':6,'contrasts':3,'source_calls':zero_calls}:
        raise AssertionError('bounded reuse/no-source-call contract changed')
    if document['source_admission']['source_calls']!=zero_calls:
        raise AssertionError('source admission reports forbidden calls')
    if document['queries']!=config['queries']:
        # coordinate is an input parser declaration; exported queries retain exact fractions and identity.
        expected = [{key:value for key,value in item.items() if key!='coordinate'} for item in config['queries']]
        if document['queries']!=expected:
            raise AssertionError('declared query association changed')
    for row in document['source_windows']:
        if row['independent_window_reference']['available'] is not False:
            raise AssertionError('source export cannot preclaim an independent window reference')
        if row['raw_history_file_sha256']!=config['source_binding']['files'][row['source_history_id']]['sha256']:
            raise AssertionError('source-window raw history association mismatch')


def main():
    config,plan,files = load_bound_inputs()
    # Artifact names are bound in a separate pre-query frozen output contract.
    artifact_contract = json.loads((HERE/'output_contract.json').read_text())
    producer = WORK/'producer/reference-run'
    producer_report = json.loads((producer/'report.json').read_text())
    document_path = producer/artifact_contract['assembly_file']
    document = json.loads(document_path.read_text())
    forbidden_imports = [name for name in sys.modules if name=='mhdlab' or name.startswith('mhdlab.') or name.split('.')[0] in ('numpy','scipy')]
    if forbidden_imports:
        raise RuntimeError('independent verifier imported numerical model/package '+str(forbidden_imports))
    if producer_report['result_file']!=artifact_contract['assembly_file'] or producer_report['result_sha256']!=sha(document_path):
        raise RuntimeError('producer result association changed')
    for name,digest in producer_report['artifact_sha256'].items():
        if sha(producer/name)!=digest:
            raise RuntimeError('changed saved output artifact '+name)
    if OUT.exists():
        raise RuntimeError('fresh independent output directory required; checkpoints are never replayed automatically')
    OUT.mkdir()
    with localcontext() as context:
        context.prec = 120
        old_config,assembly = files['input_config'],files['assembly']
        verify_declarations(document,config)
        queries = own_queries(config,old_config)
        polynomial = distinct_math(assembly,queries)
        # Pure exact algebra precedes any new numerical reference calculation.
        exact_counts = verify_source_windows(document,polynomial,queries,assembly)
        exact_counts.update(verify_csvs(producer,document))
        edges = [rational(item) for item in old_config['geometry']['width_edges_m']]
        length = rational(old_config['geometry']['common_length_m'])
        areas = [(b-a)*length for a,b in zip(edges,edges[1:])]
        exact_mixtures = {key:{hypothesis:aggregate_fraction([polynomial[case][key] for case in cases],areas)
            for hypothesis,cases in old_config['hypotheses'].items()} for key,_,_ in queries}
        exact_counts.update(verify_mixture_records(document,polynomial,exact_mixtures,areas,old_config))
        defect_counts,source_defects = verify_defect_layers(document,polynomial,queries,assembly,areas,old_config)
        exact_counts.update(defect_counts)
        references,checkpoint_hashes,work_counts = new_references(old_config,queries,plan)
        checks = reference_checks(polynomial,references,old_config,plan)
        mixture,independent,areas = mixtures(polynomial,references,old_config,[key for key,_,_ in queries])
        mixture_checks = check_mixture_physical_errors(mixture,independent,areas,old_config,plan)
        contrast = compare_contrasts(mixture,independent_mixture_as_records(independent['refined']),
            independent_mixture_as_records(independent['coarse']),D(plan['new_own_width_contrast_tolerance']),D(plan['reference_change_tolerance']))
        write(OUT/'reference_windows.json',references)
        write(OUT/'exact_polynomial_windows.json',polynomial)
        write(OUT/'contrast_queries.json',contrast)
        write(OUT/'source_defects.json',source_defects)
        write(OUT/'report.json',{
            'schema':'mitl-independent-coupled-window-query-report-v1','status':'passed','all_checks_passed':True,
            'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'source_version_sha256':{name:sha(HERE/name) for name in (
                'verify_window_queries.py','seeded_window_reference.py','power_basis_windows.py',
                'window_query_checks.py','source_defect_algebra.py','decimal_forced_reference.py','oracle_plan.json','input_config.json','output_contract.json')},
            'producer_report_sha256':sha(producer/'report.json'),'window_document_sha256':sha(document_path),
            'accepted_old_report_sha256':config['source_binding']['files']['independent_report']['sha256'],
            'checkpoint_sha256':checkpoint_hashes,'new_work_counts':work_counts,'exact_check_counts':exact_counts,
            'distinct_source_window_queries':9,'patch_references':18,'aggregate_windows':6,'width_contrasts':3,
            'per_window_checks':checks,'own_width_contrast_checks':contrast,
            'gross_mixture_checks':mixture_checks,
            'reference_windows_sha256':sha(OUT/'reference_windows.json'),
            'exact_polynomial_windows_sha256':sha(OUT/'exact_polynomial_windows.json'),
            'contrast_queries_sha256':sha(OUT/'contrast_queries.json'),
            'source_defects_sha256':sha(OUT/'source_defects.json'),
            'old_reference_grid_calls':0,'old_source_RHS_calls':0,'producer_calls_by_oracle':0,
            'forbidden_model_or_numerical_package_imports':forbidden_imports,
            'source_emission_windows_are_photon_gates':False,'host_budget_accepted':False,
            'qualification':[
                'Independent exact ordinary-power-basis algebra checks represented source declarations; it is not independent physical truth.',
                'NEW local moment/off-knot queries start only from accepted own-precision knot states. No old full-state trajectory, RHS or assembly is rerun.',
                'Finite precision/Taylor/substep/quadrature changes and observed interpolation errors are estimates, not certified bounds or physical/statistical uncertainty.',
                'Endpoint inventory mass and positive quadrature normalization mass are retained separately; time/T covariance is independently accumulated with centered positive weights.',
                'Three defect layers remain separate: exact polynomial algebra, represented source integration/allocation defects, and independently estimated IVP/interpolation differences.',
                'Manufactured source emission only; no water/material/state calibration, photon gates, registered experimental clock, gap evolution, velocity, spectra or FLASH result.'
            ]})
    print(json.dumps({'status':'passed','report_sha256':sha(OUT/'report.json'),'counts':work_counts},indent=2))


if __name__=='__main__':
    main()
