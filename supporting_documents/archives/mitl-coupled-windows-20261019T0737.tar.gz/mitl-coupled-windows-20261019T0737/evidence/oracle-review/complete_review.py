"""Bind the completed saved-query report without any numerical replay."""
import datetime
from decimal import Decimal
import hashlib
import json
from pathlib import Path

WORK = Path('/workspace/research_work/mitl-upstream-20261019T0737')
HERE = WORK/'independent-verification'
OUT = WORK/'oracle-review'
RESULTS = HERE/'query-initial'
REPORT = RESULTS/'report.json'
PIN = '80f6577f67dacb29ad5d1f53c13a85b89aa10ab160cd79daf000dd43ca48d733'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def load(path):
    return json.loads(path.read_text())

assert sha(REPORT) == PIN
assert sha(OUT/'pre_run_code_review.json') == '829697450c39905f9d90f1582ca09ff10c6a372c5903360396a05eee8be892ac'
pre = load(OUT/'pre_run_code_review.json')
r = load(REPORT)
assert r['schema'] == 'mitl-independent-coupled-window-query-report-v1'
assert r['status'] == 'passed' and r['all_checks_passed'] is True
for name,digest in r['source_version_sha256'].items():
    assert digest == pre['reviewed_code_and_input_sha256'][name]
    assert sha(HERE/name) == digest
producer = WORK/'producer/reference-run'
assert sha(producer/'report.json') == r['producer_report_sha256'] == '69907c8ba61545b31e67675a2c71bf8b9453006ea9f705b6f16d02e5b1a233ac'
assert sha(producer/'coupled_emission_windows.json') == r['window_document_sha256'] == '64e0ce6b9cb271ad423109f3e52db02ab6017eb0d2591bbc8bdb30ca50aba731'
assert sha(Path('/workspace/Power-Flow/mhdlab/coupled_emission_windows.py')) == '8a235ed92c0e40ccd43375fcd4d6c6beee05fd460b9fbf15102610c338eba786'
assert r['accepted_old_report_sha256'] == '5a0b0cfce3fa594376718579645b8ee424bf80b6de0ac5ade0eeab829fc3d84c'
expected_counts = {'seeded_cells':384,'dense_substeps':1152,'quadrature_nodes':18432,
 'Gamma_node_evaluations':18432,'new_off_knot_state_values':12,
 'window_weight_accumulations':29952,'old_full_state_driver_calls':0,'source_RHS_calls':0,
 'physical_state_exponential_evaluations':57600,'Taylor_coefficient_exponential_calls':107520}
assert r['new_work_counts'] == expected_counts
for key,value in {'distinct_source_window_queries':9,'patch_references':18,'aggregate_windows':6,
                  'width_contrasts':3,'old_reference_grid_calls':0,'old_source_RHS_calls':0,'producer_calls_by_oracle':0}.items():
    assert type(r[key]) is int and r[key] == value
assert r['forbidden_model_or_numerical_package_imports'] == []
assert r['host_budget_accepted'] is r['source_emission_windows_are_photon_gates'] is False
assert len(r['checkpoint_sha256']) == 6
output_pins = dict(r['checkpoint_sha256'])
for name,field in {'reference_windows.json':'reference_windows_sha256',
                   'exact_polynomial_windows.json':'exact_polynomial_windows_sha256',
                   'contrast_queries.json':'contrast_queries_sha256','source_defects.json':'source_defects_sha256'}.items():
    output_pins[name] = r[field]
for name,digest in output_pins.items():
    assert sha(RESULTS/name) == digest

# Summarize reported scalar diagnostics, without recomputing any scientific quantity.
reported = {}
def walk(value,path):
    if isinstance(value,dict):
        for key,item in value.items():
            if key in ('scaled_absolute_error','scaled_reference_change','scaled_absolute_residual') and isinstance(item,dict) and 'decimal' in item:
                reported.setdefault(key,[]).append((Decimal(item['decimal']),'/'.join(path+[key]),item))
            else:
                walk(item,path+[key])
    elif isinstance(value,list):
        for index,item in enumerate(value):
            walk(item,path+[str(index)])
walk(r,[])
observed_maxima = {key:{'reported_value':max(items)[2],'reported_path':max(items)[1],
                       'reported_record_count':len(items)} for key,items in reported.items()}

notes = '''The sole saved new-query report declares all exact source/polynomial/piece/CSV/mixture/source-defect checks passed before new reference evaluation. It then admits nine independent new source-window queries, six full physical mixtures and three own width contrasts under the prospectively frozen interpolation and reference-change thresholds. All three pre-query verifier completeness/true-zero issues were repaired and frozen before the first new query; inputs, thresholds, qualified mathematical primitives and producer bytes remained unchanged.

The actual report binds six new case/precision moment checkpoints. It declares384 independently reseeded cells,1152 new dense substeps,18432 quadrature nodes and shared Gamma node evaluations,12 new off-knot endpoint state pairs and29952 positive weighted window updates. It separately reports57600 physical-state exponential evaluations and107520 Taylor-coefficient exponential calls. These are new moment/off-knot query operations from immutable accepted own-precision N/T knots; the report declares zero old grid/RHS/producer calls. No old full trajectory is replayed by this review.

The largest reported scaled prediction error is about1.656e-7 (middle-power early-window mean temperature, on its own resolved temperature-excursion scale), below the frozen2e-4 admission. The largest separately reported own-contrast ladder change is about8.716e-34, below the frozen1e-20 admission. These are observed report diagnostics and finite reference changes, not interval error bounds or experimental uncertainty. Reference endpoint inventory mass remains distinct from direct positive quadrature normalization mass; no variance/covariance floor or fitted launch temperature is introduced.

The actual source/export report and emitted data retain positive piecewise number/temperature controls, all six mandatory raw moments including local-time*T, full within/between-patch mixtures and signed width contrasts. Exact polynomial defects, represented original source/channel discrepancies and independent IVP/query estimates remain separate. Original knot N and original scalar residuals remain referenced data; off-knot stored RK channel comparisons remain unavailable. Source windows are not photon gates or registered experimental clocks.

This final record is static mathematical/interface/claims review plus raw-byte and completed-report association only. No scientific module, model, RHS, source admission, interpolation, numerical oracle or test is imported/executed by the reviewer. Manufactured constant-power stationary independent patches do not establish physical water/material/monolayers, lateral conduction, launch velocity, molecular-state chemistry, gap transport, spectra, Hall, FLASH or host/owner acceptance.
'''
(OUT/'review.md').write_text(notes)
record = {
 'schema':'mitl-coupled-window-static-oracle-review-v1','status':'accepted',
 'reviewed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'reviewed_source':str(HERE/'verify_window_queries.py'),
 'reviewed_source_sha256':sha(HERE/'verify_window_queries.py'),
 'actual_report_path':str(REPORT),'actual_report_sha256':PIN,
 'owner_report_path':str(REPORT),'owner_report_sha256':PIN,
 'producer_report_sha256':r['producer_report_sha256'],
 'window_document_sha256':r['window_document_sha256'],
 'production_core_sha256':'8a235ed92c0e40ccd43375fcd4d6c6beee05fd460b9fbf15102610c338eba786',
 'source_version_sha256':r['source_version_sha256'],
 'actual_reference_output_sha256':output_pins,
 'owner_report_observed_declarations':{key:r[key] for key in ('schema','status','all_checks_passed',
   'distinct_source_window_queries','patch_references','aggregate_windows','width_contrasts',
   'new_work_counts','exact_check_counts','old_reference_grid_calls','old_source_RHS_calls','producer_calls_by_oracle')},
 'reported_diagnostic_maxima':observed_maxima,
 'actual_own_scale_contrast_and_reference_ladder_records_read':True,
 'gross_physical_mixture_and_positive_integral_qualifications_read':True,
 'completed_report_bound_without_numerical_replay':True,
 'owner_report_numerics_recomputed_by_reviewer':False,
 'findings':pre['findings'],'further_changes_requested':False,
 'scientific_module_imported':False,'numerical_models_or_tests_executed':False,
 'source_evolution_RHS_assembly_or_window_calculation_executed':False,
 'producer_or_oracle_executed':False,'old_grid_or_case_replayed':False,
 'physical_parameters_validated':False,'host_budget_accepted':False,
 'qualification':r['qualification'],
 'read_only_command_failure':{'log':'review-query-defects.log',
   'sha256':'dcd893905ae653657f54f9c47237b52692a6b4a87827b9745491862dc609bec7',
   'reason':'Initial metadata read used nonexistent source_defect_checks.py; corrected to actual source_defect_algebra.py. No scientific call occurred.'},
 'artifact_sha256':{name:sha(OUT/name) for name in ('complete_review.py','freeze_code_review.py','freeze_plan_review.py',
   'plan_review.json','pre_run_code_review.json','pre_run_review.md','review.md')}
}
(OUT/'completion.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'completion':str(OUT/'completion.json'),'sha256':sha(OUT/'completion.json'),
                  'status':'accepted','actual_report_sha256':PIN}))
