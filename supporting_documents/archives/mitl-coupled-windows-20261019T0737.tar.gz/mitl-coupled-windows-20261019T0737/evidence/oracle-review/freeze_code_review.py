"""Freeze a static new-query code review using raw-byte metadata only."""
import datetime
import hashlib
import json
from pathlib import Path

WORK = Path('/workspace/research_work/mitl-upstream-20261019T0737')
HERE = WORK/'independent-verification'
OUT = WORK/'oracle-review'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def load(path):
    return json.loads(path.read_text())

initial = load(HERE/'before_query_code_freeze.json')
assert sha(HERE/'before_query_code_freeze.json') == 'cfb005d06061362b3e26ef10c65e0af2a6bcaba55c8c37d9738655ab6955e6b5'
amendment = load(HERE/'pre_query_completeness_amendment.json')
assert amendment['new_query_calls_before_amendment'] == 0
assert amendment['tolerances_changed'] is amendment['fixtures_changed'] is amendment['mathematical_primitives_changed'] is False
assert amendment['original_code_freeze_sha256'] == sha(HERE/'before_query_code_freeze.json')
preserved = Path(amendment['preserved_directory'])
for name,digest in initial['files_sha256'].items():
    assert sha(preserved/name) == digest, name
for name,digest in amendment['final_files_sha256'].items():
    candidate = HERE/'source-versions/before-exact-zero-contrast-guard'/name if name == 'window_query_checks.py' else HERE/name
    assert sha(candidate) == digest, name
assert sha(HERE/'oracle_plan.json') == '53128110f09d9c5204a5afaa313e09ab110024f45a4ef179f5b3bd479d45475a'
assert sha(HERE/'input_config.json') == '2e8f1eb938a89957d2453f801321365ac6513fa8154b4dd3b925c1a67df1b18c'
assert sha(HERE/'decimal_forced_reference.py') == 'b6740c00a75b094ea36c9d6c1d941cbe31e19b8100a200613ef8961136c8da89'
assert sha(OUT/'plan_review.json') == '19534a62b1b7846e86f3b814aff16f1a4e82ae9f7be679e446831f5cbb114388'
assert not (HERE/'query-initial').exists(), 'This association must precede the first new query output.'
zero_guard = load(HERE/'final_before_query_freeze.json')
assert sha(HERE/'final_before_query_freeze.json') == 'efb4184a0ea6ae8679346df02c69bfb7dd505184bb5876fae43beedde2a92d4e'
assert zero_guard['new_query_calls_before_freeze'] == 0
assert zero_guard['prior_amendment_sha256'] == sha(HERE/'pre_query_completeness_amendment.json')
for name,digest in zero_guard['files_sha256'].items():
    assert sha(HERE/name) == digest, name

findings = [
 {'id':'explicit-gross-mixture-physical-errors','status':'repaired_before_first_query',
  'origin':'Independent verifier owner pre-query completeness review.',
  'issue':'Exact aggregation and per-source admission alone did not explicitly report six gross mixture physical prediction/reference-change checks.',
  'correction':'Six positive mixture comparisons and their reference ladders are now checked with unchanged tolerances; wall-thermal scales use areal capacity times total physical area.'},
 {'id':'own-contrast-reference-ladder','status':'repaired_before_first_query',
  'origin':'Static scientific review before first new query.',
  'issue':'Own width-contrast finite reference changes were reported without the declared own-scale 1e-20 admission; scalar trajectory admission does not imply cancellation-sensitive contrast admission.',
  'correction':'Every physical contrast now admits its reference-ladder change separately using the frozen own maximum contrast scale and frozen threshold.'},
 {'id':'true-zero-reference-ladder','status':'repaired_before_first_query',
  'origin':'Narrow static amendment diff inspection before first new query.',
  'issue':'The new zero-scale reference branch initially used an absolute dimensionful fallback.',
  'correction':'A true-zero own reference scale rejects any nonzero coarse/fine change; exact prescribed input also requires the coarse difference to vanish.'}
]
notes = '''The new seeded-query implementation imports only qualified local Taylor primitives, never the old full-grid driver or production modules. Each original cell restarts from its own precision's accepted N/T knot, with s=0 and Z=T+shift; u=nu*t is retained consistently. Every quadrature node computes one independent Gamma and reuses the same positive emitted weight for all overlapping query moment, translational and wall-debit integrands. Restricted endpoint queries align predeclared substeps. Local endpoint consistency remains diagnostic, separate from endpoint inventory and accumulated quadrature mass.

The positive centered weighted update implements variances and joint covariance; aggregation includes both within- and between-component variation with emitted-mass weights. Direct positive translational and wall-debit integrals are not thermal-residual subtractions. Source/raw polynomial differences, endpoint/quadrature mass and new IVP errors remain distinct.

An independent ordinary power basis reconstructs the represented-source Hermite polynomials, substitutes partial coordinates algebraically, integrates products exactly and compares Bernstein controls by a separate binomial conversion. A single query-start local-time anchor spans all cells. Exact moment, statistics, source-defect, extensive mixture and signed contrast projections are read back independently. Area enters exactly once. Off-knot stored-source energy references remain unavailable; no original N or accumulated source channel is repaired.

The frozen inputs and tolerance plan predate the new export/query outcomes. Own temperature excursion/variance/covariance and own width-contrast scales supplement gross checks. The three pre-query completeness/true-zero repairs above change verification admission/reporting only, with original freezes preserved and no reference call before repair. No mathematical primitive, fixture, threshold or producer bytes change.

This is static source/math/claims review and raw-byte association only. No scientific module is imported or executed by this review. The new query outcome is pending and must be bound separately. The accepted old knot states remain immutable numerical inputs, not independent physical evidence; finite ladder changes and actual errors are estimates rather than interval certification. The scope is manufactured emission windows, with no physical water/material/ML, photon gate/experimental clock, velocity, molecular-state data, transport, spectra, Hall, FLASH or owner/host validation.
'''
(OUT/'pre_run_review.md').write_text(notes)
pins = dict(amendment['final_files_sha256'])
pins.update(zero_guard['files_sha256'])
record = {
 'schema':'mitl-coupled-window-static-query-code-review-v1','status':'accepted',
 'reviewed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'reviewed_source':str(HERE/'verify_window_queries.py'),
 'reviewed_source_sha256':sha(HERE/'verify_window_queries.py'),
 'original_code_freeze_sha256':sha(HERE/'before_query_code_freeze.json'),
 'pre_query_completeness_amendment_sha256':sha(HERE/'pre_query_completeness_amendment.json'),
 'final_before_query_freeze_sha256':sha(HERE/'final_before_query_freeze.json'),
 'plan_review_sha256':sha(OUT/'plan_review.json'),
 'core_review_sha256':sha(WORK/'core-review/completion.json'),
 'reviewed_code_and_input_sha256':pins,'findings':findings,'further_changes_requested':False,
 'new_query_output_existed_at_review':False,
 'scientific_module_imported':False,'numerical_models_or_tests_executed':False,
 'old_grid_or_RHS_replayed':False,'new_moment_queries_executed':False,
 'producer_or_oracle_executed':False,'physical_parameters_validated':False,
 'limits':['Static code/mathematical/association review only; actual new query outcome is pending.',
           'Original freezes and all pre-first-query repairs preserved; no numerical comparison replay.',
           'Manufactured source-emission windows only; no physical or host/owner acceptance.'],
 'artifact_sha256':{'freeze_code_review.py':sha(Path(__file__)),'pre_run_review.md':sha(OUT/'pre_run_review.md')}
}
(OUT/'pre_run_code_review.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'path':str(OUT/'pre_run_code_review.json'),'sha256':sha(OUT/'pre_run_code_review.json'),'status':'accepted'}))
