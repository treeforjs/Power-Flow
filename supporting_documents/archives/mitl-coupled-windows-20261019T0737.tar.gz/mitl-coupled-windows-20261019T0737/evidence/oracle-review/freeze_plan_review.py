"""Freeze prospective coupled-window math/query/threshold review only."""
import datetime as dt
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ORACLE = ROOT.parent / 'independent-verification'
PINS = {
    'oracle_plan.json': '53128110f09d9c5204a5afaa313e09ab110024f45a4ef179f5b3bd479d45475a',
    'before_plan_freeze.json': '5380b9930dc967cefe667c0e07debb9a9d89d127ea695276a917499cf1bab810',
    'input_config.json': '2e8f1eb938a89957d2453f801321365ac6513fa8154b4dd3b925c1a67df1b18c',
    'decimal_forced_reference.py': 'b6740c00a75b094ea36c9d6c1d941cbe31e19b8100a200613ef8961136c8da89'
}

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

if (ROOT / 'plan_review.json').exists():
    raise RuntimeError('Refuse repeated window plan-review freeze')
status = json.loads(Path('/workspace/research_work/mitl-upstream-status.json').read_text())
assert status['active_lease_owner'] == 'mitl-upstream-20261019T0737'
assert dt.datetime.fromisoformat(status['active_editing_lease_until_utc']) > dt.datetime.now(dt.timezone.utc)
assert all(sha(ORACLE / name) == digest for name, digest in PINS.items())
plan = json.loads((ORACLE / 'oracle_plan.json').read_text())
config = json.loads((ORACLE / 'input_config.json').read_text())
checks = [
    ('positive_measure_and_restriction', 'Monotone cubic cumulative-M Bernstein controls give nonnegative quadratic dM/du. Exact restriction to a partial interval rescales that derivative already; a second h or subinterval factor would be incorrect.'),
    ('independent_polynomial_algebra', 'Ordinary Hermite power-basis multiplication, differentiation and antiderivatives provide an independent check of production Bernstein products without copying its implementation.'),
    ('mandatory_joint_statistics', 'One common exact window-start anchor defines local time across all cells. Direct tlocal*T, T/time first and second moments and covariance are mandatory; no mean-temperature substitution is allowed.'),
    ('mass_weighted_full_mixture', 'Distinct source/window quantities are evaluated once, then exact patch areas scale raw measures once. Normalized whole-hypothesis statistics require emitted-mass weights, not bare area weights or averages of component covariances.'),
    ('new_reference_queries_only', 'Own-precision accepted knot N/T values seed local cell calculations. New moment integrands and two off-knot values are queried without calling an old full-state grid driver or producing a new old65-state acceptance grid.'),
    ('node_reuse_and_work_counts', 'One new Gamma at each planned positive quadrature node supplies all moment/energy integrands. Overlapping windows and patch references reuse contributions. Prospective cell/substep/node/off-knot counts are explicit.'),
    ('three_defect_layers', 'Exact polynomial algebra, represented-source knot allocation/input/channel discrepancies and independent IVP/interpolation comparisons remain distinct. Off-knot RK cumulative comparisons are unavailable.'),
    ('energy_reference', 'D and I remain separate supplied fixed costs. Translation and gross-wall references use direct positive integrals, independent of thermal residuals; prescribed input and signed thermal change remain separate.'),
    ('own_variation_and_covariance_scales', 'Time uses a local origin; temperature/variance/covariance errors use resolved variation or an explicitly fixed independent three-query maximum. No gross T0-squared or invented floor hides cancellation.'),
    ('prospective_tolerances_and_contrasts', 'The new2e-4 interpolation/own-width-contrast budgets are declared before export and distinguished from prior scalar accuracy. Reference changes/consistency use1e-20 and are estimates, not interval or physical error certificates.'),
    ('zero_and_sign_rules', 'Exactly zero mass makes normalized moments unavailable. Other structural zeros remain exact; nonzero projection loss rejects. Signed/crossing contrasts are preserved without an expected enhancement or confidence claim.')
]
record = {
    'schema': 'mitl-coupled-window-oracle-plan-review-v1',
    'status': 'plan_review_accepted_for_manufactured_verification',
    'completed_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
    'reviewed_artifact_sha256': PINS,
    'selected_proposal_sha256': sha(ROOT.parent / 'selected-proposal.json'),
    'planning_math_notes_sha256': sha(Path('/workspace/research_work/mitl-upstream-20261019T0710/next-upstream-selection/mathematical-notes.json')),
    'checks': [{'area': name, 'static_review_complete': True, 'finding': finding} for name, finding in checks],
    'current_mandatory_joint_requirement_supersedes_optional_old_note': True,
    'declared_queries': plan['queries'],
    'declared_tolerances': {key: plan[key] for key in ('new_window_interpolation_tolerance',
        'new_own_width_contrast_tolerance', 'reference_change_tolerance', 'reference_physical_consistency_tolerance')},
    'qualifications_reviewed': plan['qualification'],
    'full_new_core_and_reference_code_reviews_pending': True,
    'actual_new_window_results_pending': True,
    'numerical_models_or_tests_executed': False, 'scientific_module_imported': False,
    'source_RHS_assembly_or_reference_queries_executed': False,
    'old_full_state_driver_or_acceptance_repeated': False,
    'physical_parameters_validated': False, 'host_budget_accepted': False,
    'limits': ['Prospective mathematical/query/scale/threshold plan review only.',
               'Actual pure-source admission, polynomial core and new reference code need separate pre-run reviews.',
               'Actual interpolation/variation/covariance/contrast errors must pass the frozen new-query budgets.',
               'Manufactured constant-power source windows only; no physical water/ML/velocity/transport/spectra/FLASH/host acceptance.']
}
path = ROOT / 'plan_review.json'
path.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'plan_review': str(path), 'sha256': sha(path), 'schema': record['schema'],
                  'status': record['status'], 'source_RHS_assembly_or_reference_queries_executed': False}, indent=2))
