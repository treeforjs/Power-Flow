"""New query/source-byte controls only; no polynomial or source model imports."""
import copy,hashlib,importlib.util,json,pathlib,sys,tempfile
R=pathlib.Path('/workspace/Power-Flow');W=pathlib.Path(__file__).resolve().parent;S=pathlib.Path('/workspace/research_work/mitl-upstream-20261019T0710')
spec=importlib.util.spec_from_file_location('window_cli_input',R/'tools/export_coupled_emission_windows.py');cli=importlib.util.module_from_spec(spec);spec.loader.exec_module(cli)
p=R/'configs/coupled_emission_windows_manufactured.json';base=json.loads(p.read_text());cases=[]
def edit(name,fun):
 x=copy.deepcopy(base);fun(x);cases.append((name,x))
edit('missing_query',lambda x:x['queries'].pop())
edit('duplicate_query_id',lambda x:x['queries'][1].update(window_id='complete_source_support'))
edit('noncanonical_fraction_integer',lambda x:x['queries'][1]['start_fraction'].update(numerator='+1'))
edit('zero_fraction_denominator',lambda x:x['queries'][1]['start_fraction'].update(denominator='0'))
edit('unreduced_fraction',lambda x:x['queries'][1]['start_fraction'].update(numerator='2',denominator='32'))
edit('numeric_fraction_token',lambda x:x['queries'][1]['start_fraction'].update(numerator=1))
edit('boolean_fraction_token',lambda x:x['queries'][1]['start_fraction'].update(denominator=True))
edit('wrong_time_coordinate',lambda x:x['queries'][1].update(coordinate='physical_seconds'))
edit('query_outside_support',lambda x:x['queries'][1]['stop_fraction'].update(numerator='2',denominator='1'))
edit('undeclared_shifted_window',lambda x:x['queries'][1]['start_fraction'].update(denominator='15'))
edit('missing_joint_moment',lambda x:x['quantity_contract'].update(joint_local_time_temperature_moment_required=False))
edit('pseudocount_not_allowed',lambda x:x['representation_contract'].update(normalized_zero_mass='floor_to_one'))
edit('unsafe_source_path',lambda x:x['source_binding']['files']['report'].update(relative_path='../report.json'))
edit('duplicate_source_path',lambda x:x['source_binding']['files']['assembly'].update(relative_path=x['source_binding']['files']['report']['relative_path']))
edit('invalid_digest_case',lambda x:x['source_binding']['files']['report'].update(sha256='A'*64))
edit('boolean_zero_call_count',lambda x:x['declared_counts'].update(source_evolution_RHS_assembly_calls=False))
results=[]
with tempfile.TemporaryDirectory(prefix='coupled-window-input-') as tmp:
 for name,value in cases:
  q=pathlib.Path(tmp)/(name+'.json');q.write_text(json.dumps(value))
  try:cli.load_config(q)
  except (ValueError,TypeError,OverflowError) as exc:results.append({'name':name,'outcome':'rejected','reason':str(exc)})
  else:raise RuntimeError(name+' admitted')
 config=cli.load_config(p);results.append({'name':'approved_fixed_exact_queries','outcome':'accepted_without_pure_core_import'})
 bad=copy.deepcopy(config);bad['source_binding']['files']['report']['sha256']='0'*64
 try:cli.read_bound_source(bad,S)
 except ValueError as exc:assert 'hash' in str(exc);results.append({'name':'wrong_trusted_expected_report_digest','outcome':'rejected_before_core_import','reason':str(exc)})
 else:raise RuntimeError('wrong trusted source digest admitted')
 files,aux=cli.read_bound_source(config,S)
 assert len(files)==10 and len(aux)==2
 results.append({'name':'actual_accepted_source_byte_preflight','outcome':'accepted_without_pure_core_import','source_aliases':sorted(files),'auxiliary_aliases':sorted(aux)})
assert not any(k in sys.modules for k in ('mhdlab.coupled_emission_windows',*cli.FORBIDDEN))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
d={'schema':'mhdlab-coupled-window-input-guards-v1','status':'passed','cli_sha256':sha(R/'tools/export_coupled_emission_windows.py'),'config_sha256':sha(p),'script_sha256':sha(pathlib.Path(__file__)),'invalid_query_config_rejections':16,'invalid_source_digest_rejections':1,'accepted_query_plans':1,'accepted_source_byte_preflights':1,'checks':results,'polynomial_window_model_RHS_assembly_or_history_imports_or_calls':False,'old_control_scripts_called':False}
(W/'input_guard_checks.json').write_text(json.dumps(d,indent=2,allow_nan=False)+'\n');print(json.dumps({'status':'passed','report_sha256':sha(W/'input_guard_checks.json'),'invalid_configs':16,'source_digest_rejections':1,'accepted_plan_and_source_preflight':2,'window_calculations':0},indent=2))
