"""Freeze accepted source/query/code and prerequisite evidence before one export."""
import argparse,datetime,hashlib,json,pathlib,shutil
W=pathlib.Path(__file__).resolve().parent;P=W.parent;R=pathlib.Path('/workspace/Power-Flow')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
a=argparse.ArgumentParser();a.add_argument('--core-sha',required=True);a.add_argument('--core-review-sha',required=True);a.add_argument('--plan-review-sha',required=True);args=a.parse_args()
expected={'tools/export_coupled_emission_windows.py':'022950075d557df115b4b6a42e2d906c18d2379c0cbb2bc4bf19d3655b5d2594','configs/coupled_emission_windows_manufactured.json':'2e8f1eb938a89957d2453f801321365ac6513fa8154b4dd3b925c1a67df1b18c','mhdlab/coupled_emission_windows.py':args.core_sha}
for path,digest in expected.items():assert sha(R/path)==digest,path
pins={'independent-verification/oracle_plan.json':'53128110f09d9c5204a5afaa313e09ab110024f45a4ef179f5b3bd479d45475a','independent-verification/before_plan_freeze.json':'5380b9930dc967cefe667c0e07debb9a9d89d127ea695276a917499cf1bab810','core-review/completion.json':args.core_review_sha,'oracle-review/plan_review.json':args.plan_review_sha}
for path,digest in pins.items():assert sha(P/path)==digest,path
lineage=json.loads((W/'final_input_lineage.json').read_text());guard=json.loads((W/'input_guard_checks.json').read_text())
csv_amend=json.loads((W/'csv_availability_amendment.json').read_text())
assert lineage['status']=='passed_static_lineage_and_late_byte_guards'
assert csv_amend['before_cli_sha256']==lineage['final_cli_sha256'] and csv_amend['final_cli_sha256']==expected['tools/export_coupled_emission_windows.py']
assert csv_amend['input_and_query_parser_ASTs_unchanged']
assert guard['status']=='passed' and guard['focused_executions']==2
assert lineage['source_preflight_guard_report_sha256']==sha(W/'input_guard_checks.json')
commands=[json.loads(line) for line in (P/'commands.jsonl').read_text().splitlines()]
tests=[x for x in commands if any('tests/test_coupled_emission_windows.py' in q for q in x['command'])]
assert tests and tests[-1]['exit_code']==0,'new core test gate not yet passed'
assert not any('tools/export_coupled_emission_windows.py' in x['command'] for x in commands)
assert not (W/'reference-run').exists()
versions=W/'source-versions';versions.mkdir(exist_ok=True)
for path in expected:shutil.copyfile(R/path,versions/pathlib.Path(path).name)
report={'schema':'mhdlab-coupled-window-producer-freeze-v1','status':'frozen_before_first_saved_data_export','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'public_source_sha256':expected,'source_snapshots_sha256':{str(p.relative_to(W)):sha(p) for p in versions.iterdir()},'accepted_prerequisite_sha256':pins,'new_core_test_history':tests,'input_guard_report':{'path':'producer/input_guard_checks.json','sha256':sha(W/'input_guard_checks.json')},'final_input_lineage':{'path':'producer/final_input_lineage.json','sha256':sha(W/'final_input_lineage.json')},'csv_export_amendment':{'path':'producer/csv_availability_amendment.json','sha256':sha(W/'csv_availability_amendment.json')},'input_execution_qualification':lineage['source_preflight_execution_qualification'],'late_raw_byte_checks':lineage['focused_late_byte_check_count'],'all_final_source_full_control_rerun_claimed':False,'prior_saved_data_export_batches':0,'planned_source_window_pairs':9,'planned_patch_window_references':18,'planned_aggregates':6,'planned_contrasts':3,'source_evolution_RHS_assembly_calls':0,'production_command':['.venv/bin/python','-W','error','tools/export_coupled_emission_windows.py','--config','configs/coupled_emission_windows_manufactured.json','--source-dir','/workspace/research_work/mitl-upstream-20261019T0710','--output-dir',str(W/'reference-run')]}
(W/'freeze.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps({'freeze':str(W/'freeze.json'),'sha256':sha(W/'freeze.json'),'status':report['status']},indent=2))
