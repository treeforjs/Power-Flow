"""Saved JSON/CSV/hash readback only; no source or polynomial core imports."""
import csv,datetime,hashlib,json,pathlib,sys
W=pathlib.Path(__file__).resolve().parent;P=W.parent;R=pathlib.Path('/workspace/Power-Flow');RUN=W/'reference-run'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
def csvrows(p):
 with p.open() as f:return list(csv.DictReader(f))
def scalar(x):
 if type(x) is float:return format(x,'.17g')
 if x is True:return 'true'
 if x is False:return 'false'
 return str(x)
def flatten(v,prefix=''):
 if type(v) is dict and set(v)=={'exact','value','projection'}:
  return {prefix:scalar(v['value']),prefix+'__exact_numerator':v['exact']['numerator'],prefix+'__exact_denominator':v['exact']['denominator'],prefix+'__projection_json':json.dumps(v['projection'],sort_keys=True,separators=(',',':'),allow_nan=False)}
 if type(v) is dict:
  result={}
  for k,x in v.items():result.update(flatten(x,prefix+'__'+k if prefix else k))
  return result
 if type(v) is list:return {prefix:json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False)}
 return {prefix:'null' if v is None else scalar(v)}
def check_table(filename,expected):
 actual=csvrows(RUN/filename);fields=list(dict.fromkeys(k for row in expected for k in row))
 assert len(actual)==len(expected),filename
 assert list(actual[0])==fields,filename
 for a,e in zip(actual,expected):assert a=={k:e.get(k,'null') for k in fields},filename
 return len(actual)
report=load(RUN/'report.json');freeze=load(W/'freeze.json');config=load(RUN/'input_config.json');doc=load(RUN/report['result_file'])
assert report['schema']=='mhdlab-coupled-emission-windows-export-run-v1'
assert report['artifact_path_base']=='directory containing report.json'
for name,digest in report['artifact_sha256'].items():assert sha(RUN/name)==digest,name
for name,digest in freeze['public_source_sha256'].items():assert sha(R/name)==digest,name
assert report['code_sha256']=={k:v for k,v in freeze['public_source_sha256'].items() if k.endswith('.py')}
assert report['config_sha256']==freeze['public_source_sha256']['configs/coupled_emission_windows_manufactured.json']
assert sha(RUN/report['result_file'])==report['result_sha256']
assert report['source_binding']==config['source_binding'] and report['queries']==config['queries']
source_count=0
for specs in (config['source_binding']['files'],config['source_binding']['lineage']['auxiliary_files']):
 for alias,spec in specs.items():
  name='source-inputs/'+spec['relative_path']
  assert report['copied_source_input_sha256'][name]==spec['sha256']==sha(RUN/name)
  source_count+=1
assert source_count==len(report['copied_source_input_sha256'])==12
commands=[json.loads(line) for line in (P/'commands.jsonl').read_text().splitlines()]
batches=[x for x in commands if 'tools/export_coupled_emission_windows.py' in x['command']]
assert len(batches)==1 and batches[0]['exit_code']==0 and batches[0]['command']==freeze['production_command']
cache=doc['cache'];assert cache==report['cache']
assert cache=={'distinct_source_windows':9,'patch_references':18,'aggregate_windows':6,'contrasts':3,'source_calls':{'history_evolution':0,'RHS':0,'assembly':0}}
assert doc['host_budget_accepted'] is False and doc['owner_implementation_verified'] is False
expected_source=[];expected_pieces=[];piece_counts={};rk_available=rk_unavailable=0;source_keys=set()
for item in doc['source_windows']:
 identity=(item['source_history_id'],item['query_id']);assert identity not in source_keys;source_keys.add(identity)
 source_keys.add(item['source_window_key'])
 row={k:v for k,v in item.items() if k!='pieces'};row['piece_count']=len(item['pieces']);expected_source.append(flatten(row))
 piece_counts[item['source_history_id']+'/'+item['query_id']]=len(item['pieces'])
 for i,piece in enumerate(item['pieces']):
  assert 'source_endpoint_references' in piece
  expected_pieces.append(flatten({'source_history_id':item['source_history_id'],'query_id':item['query_id'],'state_id':item['state_id'],'piece_index':i,'piece':piece}))
 comparison=item['source_RK_comparison']
 if item['query_id']=='off_knot_interior':
  assert comparison['available'] is False and comparison['reason']=='window_bounds_not_both_saved_source_knots';rk_unavailable+=1
 else:assert comparison['available'] is True;rk_available+=1
 for name in ('mean_local_time_temperature_k_s','covariance_local_time_temperature_k_s'):
  stat=item['statistics'][name];assert stat['available'] is True and stat['reason'] is None and stat['record'] is not None
source_n=check_table('source_windows.csv',expected_source)
piece_n=check_table('polynomial_pieces.csv',expected_pieces)
counts={'source_windows':source_n,'polynomial_pieces':piece_n}
for key in ('patch_windows','aggregate_windows','width_window_contrasts'):
 counts[key]=check_table(key+'.csv',[flatten(item) for item in doc[key]])
assert counts==report['record_counts']=={'source_windows':9,'patch_windows':18,'aggregate_windows':6,'width_window_contrasts':3,'polynomial_pieces':315}
for item in doc['patch_windows']:assert item['source_window_key'] in source_keys
assert (rk_available,rk_unavailable)==(6,3)
assert not any(name.startswith('mhdlab.') for name in sys.modules)
contrasts=[]
for item in doc['width_window_contrasts']:
 q=item['quantity_difference_nonuniform_minus_uniform'];s=item['statistics_difference_nonuniform_minus_uniform']
 contrasts.append({'query_id':item['query_id'],'released_number':q['released_number']['value'],'translational_energy_j':q['translational_energy_j']['value'],'covariance_local_time_temperature_difference_k_s':s['covariance_local_time_temperature_k_s']['record']['value'] if s['covariance_local_time_temperature_k_s']['available'] else None,'independent_window_reference':item['independent_window_reference']})
artifacts={str(p.relative_to(P)):sha(p) for p in W.rglob('*') if p.is_file() and p.name!='completion.json' and '__pycache__' not in p.parts}
completion={'schema':'mhdlab-coupled-window-producer-completion-v1','status':'passed_saved_data_export_and_readback','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'report_path':'producer/reference-run/report.json','report_sha256':sha(RUN/'report.json'),'result_path':'producer/reference-run/'+report['result_file'],'result_sha256':report['result_sha256'],'config_sha256':report['config_sha256'],'public_source_sha256':freeze['public_source_sha256'],'positive_saved_data_export_batches':1,'batch':batches[0],'record_counts':counts,'cache':cache,'copied_source_file_count':12,'copied_source_input_sha256':report['copied_source_input_sha256'],'source_binding':report['source_binding'],'accepted_prerequisite_sha256':freeze['accepted_prerequisite_sha256'],'new_core_test_history':freeze['new_core_test_history'],'new_unique_core_checks':50,'input_execution_qualification':freeze['input_execution_qualification'],'late_raw_byte_checks':freeze['late_raw_byte_checks'],'csv_export_amendment':freeze['csv_export_amendment'],'input_guard_report':freeze['input_guard_report'],'final_input_lineage':freeze['final_input_lineage'],'input_setup_counts':{'corrected_preflight_config_load_setup':1,'late_byte_check_config_load_setup':1},'guard_evidence_claim':'Initial19controls attempted:18 succeeded then valid-source preflight stopped on wrong status literal; corrected2preflight controls and2new late-byte controls passed. Input/parser AST equivalence binds unchanged controls; no all-final-source full rerun or unique-total count is claimed. Export-only synthetic2-row CSV-null check is separate.','saved_readback':{'all_output_and12copied_input_hashes_verified':True,'all9_18_6_3_and315CSV_records_match_fullJSON':True,'all_exact_ratio_projection_and_null_availability_fields_retained':True,'joint_local_time_temperature_moments_retained_for_all9_source_windows':True,'source_RK_available_knot_windows':6,'source_RK_unavailable_off_knot_windows':3,'source_and_polynomial_model_imports_or_calls':False},'piece_counts':piece_counts,'source_window_contrast_summary':contrasts,'independent_window_error_qualification_included_here':False,'artifact_sha256':artifacts,'artifact_path_base':'pass directory containing producer/','open_substantive_findings':[],'source_evolution_RHS_assembly_calls':0,'old_suites_or_numerical_cases_replayed':False,'limits':['Exact polynomial algebra and saved source associations only; new independent window-query/moment error qualification remains separate.','Off-knot stored-RK channel comparisons are explicitly unavailable; source RK never stores time/T moment channels.','No source repair, continuous exact kinetics, physical water/material/monolayer, experimental clock, photon gate, velocity launch, transport, spectra, MHD, owner or host inference.']}
(W/'completion.json').write_text(json.dumps(completion,indent=2,allow_nan=False)+'\n')
print(json.dumps({'status':completion['status'],'completion_sha256':sha(W/'completion.json'),'report_sha256':completion['report_sha256'],'result_sha256':completion['result_sha256'],'counts':counts,'source_calls':cache['source_calls'],'contrast_summary':contrasts},indent=2))
