"""Only corrected accepted-review status and a rejecting counterpart; no maths."""
import hashlib,importlib.util,json,pathlib,sys
R=pathlib.Path('/workspace/Power-Flow');W=pathlib.Path(__file__).resolve().parent;S=pathlib.Path('/workspace/research_work/mitl-upstream-20261019T0710')
spec=importlib.util.spec_from_file_location('final_window_input',R/'tools/export_coupled_emission_windows.py');cli=importlib.util.module_from_spec(spec);spec.loader.exec_module(cli)
c=cli.load_config(R/'configs/coupled_emission_windows_manufactured.json');files,aux=cli.read_bound_source(c,S);assert len(files)==10 and len(aux)==2
checks=[{'name':'actual_accepted_source_byte_preflight','outcome':'accepted_before_pure_math_import','source_aliases':sorted(files),'auxiliary_aliases':sorted(aux)}]
original=cli._source_json
def changed_review(data):
 value=original(data)
 if type(value) is dict and value.get('schema')=='mitl-width-power-static-oracle-review-v1':value['status']='not_accepted'
 return value
cli._source_json=changed_review
try:cli.read_bound_source(c,S)
except ValueError as exc:assert 'scientific acceptance' in str(exc);checks.append({'name':'wrong_review_status_controlled_parse_mutation','outcome':'rejected_before_pure_math_import','reason':str(exc)})
else:raise RuntimeError('unaccepted review admitted')
assert not any(n in sys.modules for n in ('mhdlab.coupled_emission_windows',*cli.FORBIDDEN))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
d={'schema':'mhdlab-coupled-window-final-input-preflight-v1','status':'passed','cli_sha256':sha(R/'tools/export_coupled_emission_windows.py'),'config_sha256':sha(R/'configs/coupled_emission_windows_manufactured.json'),'script_sha256':sha(pathlib.Path(__file__)),'checks':checks,'focused_executions':2,'initial_execution':{'log':'coupled-window-input-guards.log','log_sha256':sha(W.parent/'coupled-window-input-guards.log'),'exit_code':1,'initial_cli_sha256':sha(W/'source-versions/initial_cli_before_review_status_fix.py'),'initial_control_script_sha256':sha(W/'check_input_guards.initial.py'),'qualification':'Initial new-input script completed16 invalid-config rejections, one accepted query plan and one wrong-source-digest rejection, then stopped on valid source preflight because CLI expected the wrong scientific-review status. No complete initial result JSON was emitted. No earlier controls reran after the one-literal correction.'},'public_correction':'Scientific review status is the actual pinned literal accepted, not review_complete_no_substantive_issue_identified. Source bytes/config/hashes unchanged.','pure_math_or_source_model_imports_or_calls':False,'new_window_calculations':0}
(W/'input_guard_checks.json').write_text(json.dumps(d,indent=2,allow_nan=False)+'\n');print(json.dumps({'status':'passed','focused_executions':2,'report_sha256':sha(W/'input_guard_checks.json'),'cli_sha256':d['cli_sha256'],'window_calculations':0},indent=2))
