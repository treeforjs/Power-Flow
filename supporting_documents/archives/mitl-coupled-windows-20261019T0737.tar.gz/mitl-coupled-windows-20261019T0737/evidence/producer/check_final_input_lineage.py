"""Exact status-fix lineage and only the added late byte recheck controls."""
import ast,hashlib,importlib.util,json,pathlib,sys
R=pathlib.Path('/workspace/Power-Flow');W=pathlib.Path(__file__).resolve().parent;S=pathlib.Path('/workspace/research_work/mitl-upstream-20261019T0710')
a=W/'source-versions/initial_cli_before_review_status_fix.py';b=W/'source-versions/cli_after_review_status_fix.py';c=R/'tools/export_coupled_emission_windows.py'
assert b.read_text()==a.read_text().replace('review.get("status")!="review_complete_no_substantive_issue_identified"','review.get("status")!="accepted"')
def functions(p):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(p.read_text()).body if isinstance(n,ast.FunctionDef)}
x,y=functions(b),functions(c);assert set(y)-set(x)=={'_late_recheck'}
assert [key for key in x if x[key]!=y[key]]==['run']
assert functions(a)['load_config']==y['load_config']
spec=importlib.util.spec_from_file_location('final_late_input',c);cli=importlib.util.module_from_spec(spec);spec.loader.exec_module(cli)
config=cli.load_config(R/'configs/coupled_emission_windows_manufactured.json');cli._late_recheck(config,S)
checks=[{'name':'late_original_source_bytes','outcome':'matched_all12_expected_hashes'}]
original=cli._read_relative
def changed(base,relative):
 if relative==config['source_binding']['files']['report']['relative_path']:return b'controlled_changed_bytes'
 return original(base,relative)
cli._read_relative=changed
try:cli._late_recheck(config,S)
except ValueError as exc:assert 'late source byte identity' in str(exc);checks.append({'name':'late_changed_bytes_controlled_reader_mutation','outcome':'rejected','reason':str(exc)})
else:raise RuntimeError('late changed bytes admitted')
assert not any(n in sys.modules for n in ('mhdlab.coupled_emission_windows',*cli.FORBIDDEN))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
d={'schema':'mhdlab-coupled-window-final-cli-input-lineage-v1','status':'passed_static_lineage_and_late_byte_guards','script_sha256':sha(pathlib.Path(__file__)),'initial_cli_sha256':sha(a),'review_status_corrected_cli_sha256':sha(b),'final_cli_sha256':sha(c),'status_fix_exact_single_literal_only':True,'status_fix_diff_sha256':sha(W/'review_status_fix.diff'),'all_config_parser_ASTs_unchanged_across_all_versions':True,'late_recheck_change':'Only added a raw-byte SHA recheck helper and its use after new window calculations; the admitted bytes and source inputs are never recalculated.','focused_late_byte_checks':checks,'focused_late_byte_check_count':2,'approved_config_load_setup_count':1,'source_preflight_guard_report_sha256':sha(W/'input_guard_checks.json'),'source_preflight_execution_qualification':{'initial_controls_attempted':19,'initial_controls_succeeded_before_stop':18,'initial_valid_source_preflight_failed':1,'corrected_source_preflight_controls_passed':2,'corrected_source_preflight_approved_config_load_setup':1,'initial_controls_repeated':False,'all_final_source_full_control_rerun_claimed':False},'pure_math_or_source_model_imports_or_calls':False,'new_window_calculations':0}
(W/'final_input_lineage.json').write_text(json.dumps(d,indent=2,allow_nan=False)+'\n')
print(json.dumps({'status':d['status'],'report_sha256':sha(W/'final_input_lineage.json'),'final_cli_sha256':sha(c),'late_checks':2,'window_calculations':0},indent=2))
