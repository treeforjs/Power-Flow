"""Export-only nullable-field qualification from a synthetic two-row table."""
import ast,csv,hashlib,importlib.util,json,pathlib,sys,tempfile
R=pathlib.Path('/workspace/Power-Flow');W=pathlib.Path(__file__).resolve().parent
before=W/'source-versions/cli_before_explicit_csv_null.py';after=R/'tools/export_coupled_emission_windows.py'
def funcs(p):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(p.read_text()).body if isinstance(n,ast.FunctionDef)}
a,b=funcs(before),funcs(after);assert set(a)==set(b) and [k for k in a if a[k]!=b[k]]==['_write_csv']
spec=importlib.util.spec_from_file_location('window_csv_only',after);cli=importlib.util.module_from_spec(spec);spec.loader.exec_module(cli)
q={'exact':{'numerator':'3','denominator':'2'},'value':1.5,'projection':{'exact_zero':False,'rounded':False}}
data=[{'query_id':'knot','source_RK_comparison':{'available':True,'reason':None,'channel':q}}, {'query_id':'off_knot','source_RK_comparison':{'available':False,'reason':'off_knot_no_cumulative_channel_representation'}}]
with tempfile.TemporaryDirectory(prefix='window-null-csv-') as tmp:
 p=pathlib.Path(tmp)/'availability.csv';cli._write_csv(p,[cli._flatten(v) for v in data])
 with p.open() as f:rows=list(csv.DictReader(f))
 assert rows[0]['source_RK_comparison__channel']=='1.5'
 assert rows[0]['source_RK_comparison__reason']=='null'
 assert rows[1]['source_RK_comparison__available']=='false'
 assert rows[1]['source_RK_comparison__channel']=='null'
 assert rows[1]['source_RK_comparison__channel__exact_numerator']=='null'
assert not any(n in sys.modules for n in ('mhdlab.coupled_emission_windows',*cli.FORBIDDEN))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
d={'schema':'mhdlab-coupled-window-csv-availability-amendment-v1','status':'passed_export_only_check','script_sha256':sha(pathlib.Path(__file__)),'before_cli_sha256':sha(before),'final_cli_sha256':sha(after),'changed_functions':['_write_csv'],'input_and_query_parser_ASTs_unchanged':True,'source_change':'CSV missing heterogeneous fields use explicit literal null, preserving off-knot unavailability instead of empty numeric cells.','synthetic_table_rows':2,'polynomial_source_model_or_rhs_imports_or_calls':False,'window_calculations':0,'final_input_lineage_sha256':sha(W/'final_input_lineage.json')}
(W/'csv_availability_amendment.json').write_text(json.dumps(d,indent=2,allow_nan=False)+'\n');print(json.dumps({'status':d['status'],'amendment_sha256':sha(W/'csv_availability_amendment.json'),'final_cli_sha256':sha(after),'window_calculations':0},indent=2))
