"""Bind final code and the saved static review before the one targeted test run."""
import ast
import hashlib
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
REPO = Path('/workspace/Power-Flow')
core_sha, review_sha = sys.argv[1:]
core = REPO / 'mhdlab/coupled_emission_windows.py'
test = REPO / 'tests/test_coupled_emission_windows.py'
review = HERE.parent / 'core-review/completion.json'
plan_path = HERE / 'plan.final50.json'
plan = json.loads(plan_path.read_bytes())
assert plan['case_count'] == 50
assert hashlib.sha256(test.read_bytes()).hexdigest() == plan['test_sha256']
assert hashlib.sha256(core.read_bytes()).hexdigest() == core_sha
assert hashlib.sha256(review.read_bytes()).hexdigest() == review_sha
review_record = json.loads(review.read_bytes())
assert core_sha in json.dumps(review_record)
ast.parse(core.read_bytes(), filename=str(core))
ast.parse(test.read_bytes(), filename=str(test))
target = HERE / 'run-gate.json'
assert not target.exists()
snapshots = {}
for name, source in (('coupled_emission_windows.executed.py', core),
                     ('test_coupled_emission_windows.executed.py', test)):
    saved = HERE / 'source-versions' / name
    assert not saved.exists()
    saved.write_bytes(source.read_bytes())
    snapshots[str(saved.relative_to(HERE))] = hashlib.sha256(saved.read_bytes()).hexdigest()
record = {
    'schema': 'mitl-coupled-window-targeted-test-run-gate-v1',
    'status': 'source_and_saved_static_review_byte_pins_bound',
    'core_sha256': core_sha, 'test_sha256': plan['test_sha256'],
    'static_review_sha256': review_sha,
    'static_review_status': review_record['status'],
    'final_plan_sha256': hashlib.sha256(plan_path.read_bytes()).hexdigest(),
    'snapshot_sha256': snapshots,
    'new_case_count': 50, 'tests_executed_by_gate': 0,
    'core_imports_by_gate': 0,
}
target.write_text(json.dumps(record, sort_keys=True, indent=2) + '\n')
print(json.dumps(record, sort_keys=True))
