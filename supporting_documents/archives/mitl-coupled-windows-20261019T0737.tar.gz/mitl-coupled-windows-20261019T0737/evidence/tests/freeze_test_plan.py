"""Freeze only new polynomial test syntax and predeclared analytic expectations."""
import ast
import hashlib
import json
from pathlib import Path

WORK = Path(__file__).resolve().parent
REPO = Path('/workspace/Power-Flow')
TEST = REPO / 'tests/test_coupled_emission_windows.py'
API = WORK.parent / 'core/api-contract.json'
test_bytes = TEST.read_bytes()
tree = ast.parse(test_bytes, filename=str(TEST))
case_counts = {}
for node in tree.body:
    if isinstance(node, ast.FunctionDef) and node.name.startswith('test_'):
        count = 1
        for decorator in node.decorator_list:
            if isinstance(decorator, ast.Call) and isinstance(decorator.func, ast.Attribute) and decorator.func.attr == 'parametrize':
                assert isinstance(decorator.args[1], (ast.List, ast.Tuple))
                count *= len(decorator.args[1].elts)
        case_counts[node.name] = count
assert sum(case_counts.values()) == 48
imports = [n.module for n in ast.walk(tree) if isinstance(n, ast.ImportFrom)]
assert [m for m in imports if m and m.startswith('mhdlab')] == ['mhdlab.coupled_emission_windows']
record = {
    'schema': 'mitl-coupled-window-polynomial-test-plan-v1',
    'status': 'frozen_pending_source_and_saved_static_review_gate',
    'test_file': str(TEST.relative_to(REPO)),
    'test_sha256': hashlib.sha256(test_bytes).hexdigest(),
    'api_contract_sha256': hashlib.sha256(API.read_bytes()).hexdigest(),
    'case_count': 48,
    'case_counts': case_counts,
    'fixtures': {
        'linear_temperature_quadratic_emission': 'M=2+3u+u^2; T=10+2u; t=4+2u. Full and off-knot [9/2,11/2] exact Fraction moments; partial mass2.',
        'quadratic_temperature': 'M=2u; T=5+u^2; t=7+3u. Exact T^2 and t*T; cov(t,T)=1/4.',
        'common_anchor_multi_cell': 'M(t)=2+3t+t^2; T(t)=10+2t; two length1 cells. Common anchor0; right separate-window time moments explicitly translated.',
        'zero_emission': 'All cumulative controls2, same changing T: no emitted normalized stats; input6, thermal4, defect-2.',
        'large_exact_origin': 'Translate first fixture to2^60 without changing local moments; exact Fraction clock parts remain distinct.',
        'source_admission': 'Ten freshly constructed in-memory invalid JSON documents, no preserved source artifacts or producer calls.',
    },
    'exact_energy_conventions': {
        'kB_j_k': '1.380649e-23', 'qe_j_ev': '1.602176634e-19',
        'translation': '2*kB*integral(T*dM)',
        'binding': 'D*qe*released', 'internal': 'I*qe*released',
        'total_energy_defect': 'C_A*(Tstop-Tstart)+binding+translation+internal-P*(stop-start)',
        'no_defect_repair': True,
    },
    'source_ode_truth': False,
    'manufactured_fixture_status': 'manufactured_polynomial_algebra_only',
    'scalar_evolution_calls': 0, 'scalar_rhs_calls': 0, 'old_assembly_calls': 0,
    'old_test_suites_repeated': False, 'tests_executed_by_freeze': 0,
    'first_run_required_gates': ['final new core SHA frozen', 'saved static core review matching final source SHA'],
    'planned_command': [str(REPO / '.venv/bin/python'), '-W', 'error', '-m', 'pytest', '-q',
                        'tests/test_coupled_emission_windows.py', '--junitxml=' + str(WORK / 'initial.xml')],
    'failure_policy': 'Preserve initial file, output and XML; only a concretely failed changed check may rerun; unchanged passes stay historical.',
}
out = WORK / 'plan.json'
assert not out.exists()
out.write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
print(json.dumps({'case_count': 48, 'test_sha256': record['test_sha256'],
                  'plan_sha256': hashlib.sha256(out.read_bytes()).hexdigest(),
                  'core_imported': False, 'test_executions': 0}, sort_keys=True))
