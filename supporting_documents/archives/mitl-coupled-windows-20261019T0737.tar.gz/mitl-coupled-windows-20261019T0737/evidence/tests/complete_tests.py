"""Record actual targeted-test evidence after a successful first run only."""
import hashlib
import json
from pathlib import Path
import xml.etree.ElementTree as ET

HERE = Path(__file__).resolve().parent
WORK = HERE.parent
REPO = Path('/workspace/Power-Flow')
gate = json.loads((HERE / 'run-gate.json').read_bytes())
source_paths = {
    'mhdlab/coupled_emission_windows.py': REPO / 'mhdlab/coupled_emission_windows.py',
    'tests/test_coupled_emission_windows.py': REPO / 'tests/test_coupled_emission_windows.py',
}
public_sha = {p: hashlib.sha256(f.read_bytes()).hexdigest() for p, f in source_paths.items()}
assert public_sha['mhdlab/coupled_emission_windows.py'] == gate['core_sha256']
assert public_sha['tests/test_coupled_emission_windows.py'] == gate['test_sha256']
entries = [json.loads(line) for line in (WORK / 'commands.jsonl').read_text().splitlines()]
runs = [r for r in entries if Path(r['log']).name == 'coupled-window-tests-initial.log']
assert len(runs) == 1 and runs[0]['exit_code'] == 0
run = runs[0]
assert hashlib.sha256(Path(run['log']).read_bytes()).hexdigest() == run['log_sha256']
xml = ET.parse(HERE / 'initial.xml').getroot()
testcases = list(xml.iter('testcase'))
assert len(testcases) == 50
assert not list(xml.iter('failure')) and not list(xml.iter('error')) and not list(xml.iter('skipped'))
assert all('test_coupled_emission_windows' in c.attrib.get('classname', '') for c in testcases)
artifact_paths = [HERE / 'plan.json', HERE / 'plan.final50.json', HERE / 'run-gate.json',
                  HERE / 'preserved-initial48.json', HERE / 'initial.xml',
                  WORK / 'coupled-window-tests-plan-freeze.log',
                  WORK / 'coupled-window-preserve-unexecuted48.log',
                  WORK / 'coupled-window-parser-test-amendment.log',
                  WORK / 'coupled-window-tests-run-gate.log',
                  Path(run['log']), WORK / 'core-review/completion.json']
artifact_paths += sorted((HERE / 'source-versions').iterdir())
completion = {
    'schema': 'mitl-coupled-emission-window-tests-v1', 'status': 'passed',
    'all_checks_passed': True, 'unique_new_test_cases': 50,
    'test_case_executions': 50, 'targeted_test_runs': 1,
    'passing_test_cases': 50, 'failed_test_cases': 0,
    'initial48_plan_executed': False, 'pre_execution_parser_cases_added': 2,
    'old48_test_function_AST_unchanged_by_amendment': True,
    'manufactured_polynomial_fixtures_only': True,
    'source_ODE_truth_claimed': False,
    'scalar_evolution_calls': 0, 'scalar_rhs_calls': 0, 'old_assembly_calls': 0,
    'old_source_admission_positive_calls': 0, 'old_test_suites_repeated': False,
    'physical_truth_verified': False, 'host_budget_accepted': False,
    'public_source_sha256': public_sha,
    'static_review_sha256': gate['static_review_sha256'],
    'command': run['command'], 'cwd': run['cwd'], 'exit_code': 0,
    'log_sha256': run['log_sha256'],
    'testcase_names': [c.attrib['name'] for c in testcases],
    'artifact_sha256': {str(p.relative_to(WORK)): hashlib.sha256(p.read_bytes()).hexdigest()
                        for p in artifact_paths},
    'limitations': [
        'Analytic polynomial fixtures test interpolation/measure/moment algebra and guards, not source ODE accuracy.',
        'Invalid in-memory admission fixtures exercise rejection only; actual accepted export evidence is owned separately.',
        'No spectra, velocities, gap transport, physical molecular parameters or owner acceptance are inferred.',
    ],
}
out = HERE / 'completion.json'
assert not out.exists()
out.write_text(json.dumps(completion, indent=2, sort_keys=True) + '\n')
print(json.dumps({'status': 'passed', 'unique_new_test_cases': 50,
                  'completion_sha256': hashlib.sha256(out.read_bytes()).hexdigest(),
                  'public_source_sha256': public_sha, 'log_sha256': run['log_sha256']}, sort_keys=True))
