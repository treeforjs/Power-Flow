"""Freeze two added parser-specific controls before the first new test run."""
import ast
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
TEST = Path('/workspace/Power-Flow/tests/test_coupled_emission_windows.py')
INITIAL = HERE / 'source-versions/test_coupled_emission_windows.initial48.py'
old_tree = ast.parse(INITIAL.read_bytes())
new_tree = ast.parse(TEST.read_bytes())
old_functions = {n.name: ast.dump(n, include_attributes=False) for n in old_tree.body if isinstance(n, ast.FunctionDef)}
new_functions = {n.name: ast.dump(n, include_attributes=False) for n in new_tree.body if isinstance(n, ast.FunctionDef)}
assert all(new_functions[name] == body for name, body in old_functions.items())
assert set(new_functions) - set(old_functions) == {'test_strict_json_tokens_reject_before_source_schema_admission'}
added = next(n for n in new_tree.body if isinstance(n, ast.FunctionDef) and n.name == 'test_strict_json_tokens_reject_before_source_schema_admission')
assert len(added.decorator_list[0].args[1].elts) == 2
old_plan = json.loads((HERE / 'source-versions/plan.initial48.json').read_text())
assert old_plan['case_count'] == 48
plan = dict(old_plan)
plan.update({
    'status': 'frozen_50_cases_pending_source_and_saved_static_review_gate',
    'case_count': 50, 'test_sha256': hashlib.sha256(TEST.read_bytes()).hexdigest(),
    'case_counts': {**old_plan['case_counts'], added.name: 2},
    'pre_execution_amendment': {
        'reason': 'Strict JSON token projection and raw negative-zero canonical guards requested before first execution.',
        'initial_test_sha256': hashlib.sha256(INITIAL.read_bytes()).hexdigest(),
        'initial_plan_sha256': hashlib.sha256((HERE / 'source-versions/plan.initial48.json').read_bytes()).hexdigest(),
        'old_test_function_AST_unchanged': True,
        'new_cases': 2, 'test_executions_before_amendment': 0,
        'parser_errors_required': ['nonzero JSON float underflows its representation', 'negative-zero JSON integer is not canonical'],
        'later_schema_rejection_does_not_satisfy_controls': True,
    },
})
out = HERE / 'plan.final50.json'
assert not out.exists()
out.write_text(json.dumps(plan, indent=2, sort_keys=True) + '\n')
print(json.dumps({'case_count': 50, 'old48_AST_unchanged': True, 'test_executions': 0,
                  'test_sha256': plan['test_sha256'],
                  'plan_sha256': hashlib.sha256(out.read_bytes()).hexdigest()}, sort_keys=True))
