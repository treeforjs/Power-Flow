"""Preserve the first unexecuted test plan before adding strict parser controls."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
SOURCE = Path('/workspace/Power-Flow/tests/test_coupled_emission_windows.py')
expected = 'a9b9b829bd7ebd0ec3b0afe7b86e86fb2c3e271848b7de90fe78f1d07fa963c1'
raw = SOURCE.read_bytes()
assert hashlib.sha256(raw).hexdigest() == expected
out = HERE / 'source-versions'
out.mkdir(exist_ok=True)
for target, original in ((out / 'test_coupled_emission_windows.initial48.py', SOURCE),
                         (out / 'plan.initial48.json', HERE / 'plan.json')):
    assert not target.exists()
    target.write_bytes(original.read_bytes())
record = {'schema': 'mitl-coupled-window-unexecuted-plan-preservation-v1',
          'test_executions': 0, 'preserved_case_count': 48,
          'reason': 'Two new strict JSON token guards requested before any execution.',
          'artifact_sha256': {str(p.relative_to(HERE)): hashlib.sha256(p.read_bytes()).hexdigest()
                              for p in sorted(out.iterdir())}}
(HERE / 'preserved-initial48.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
print(json.dumps(record, sort_keys=True))
