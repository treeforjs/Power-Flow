"""Journal the current frozen declarations without executing scientific code."""
import datetime,fcntl,hashlib,json
from pathlib import Path
w=Path(__file__).resolve().parent
names=['core/source-freeze.json','core/output-contract.json','oracle-review/plan_review.json','independent-verification/oracle_plan.json','tests/plan.final50.json']
with (w.parent/'mitl-upstream-status.lock').open('a+') as lock:
    fcntl.flock(lock,fcntl.LOCK_EX)
    status=json.loads((w.parent/'mitl-upstream-status.json').read_text())
    assert status['active_lease_owner']==w.name
    event={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'event':'frozen_gate_checkpoint',
        'pass_id':w.name,'records':{name:hashlib.sha256((w/name).read_bytes()).hexdigest() for name in names},
        'scope':'Frozen stdlib-only joint emission-window implementation;50-case synthetic/invalid-data test design; prospective new-moment reference plan accepted.',
        'last_observed_gate':'Static source/acceptance literal comparison pending; tests and sole export follow actual gate records.',
        'numerical_execution_by_this_command':False,'execution_counts_inferred_from_absent_records':False,
        'next':'Finish static gate, run only the new targeted scope, export9 unique window measures, then execute fresh bounded reference queries.'}
    out=w/'gate-checkpoint.json';assert not out.exists()
    out.write_text(json.dumps(event,indent=2)+'\n')
    with (w.parent/'mitl-upstream-journal.jsonl').open('a') as stream:stream.write(json.dumps(event)+'\n')
print(json.dumps({'checkpoint':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest()}))
