"""Read source text, AST literals and frozen pins without importing delivery helpers."""
import ast
import hashlib
import json
from pathlib import Path
import subprocess

WORK = Path(__file__).resolve().parents[1]
REPO = Path('/workspace/Power-Flow')
EXPECTED_HEAD = 'ea82ae3094ae480cb9c370652fa1eb1c677d8de5'
EXPECTED_BASE = 'df8eb7026b3a712bf641cbb4d136c497e8af50ba'
EXPECTED_RECORDS = {
    'producer_run': '69907c8ba61545b31e67675a2c71bf8b9453006ea9f705b6f16d02e5b1a233ac',
    'producer_completion': '13de9b1da9a1d9846893416c9b065aeadee938277bd2762e20460432d0caf163',
    'input_guards': '8a3b4148f954a615b0d21c9d36a31aa0b8404826add4daea363b682db000fd43',
    'input_lineage': '2f8f006a25a05793f17310ebc5981835deafa73d9f1f62a8abfab7aeaa3990ea',
    'csv_availability_amendment': 'f46bee480170737aa311b653c9ddbf30120559de282315e6bdd4261b364a6b05',
    'producer_before_run': 'cc34917f5d9a6bceb3d1087bb98c84a7d15cbaec928800634a1258e150dc3a0c',
    'tests_completion': 'dc687119f5a09bbceefe0e0ccd6fa6610b666df9b9f99d53f1cc38540c14c95a',
    'core_freeze': '2ae7279fc1535de7f8355c8c176c4a7ff890efcac0e99808292f9a497768cc2e',
    'static_core_review': '81ff9b4279bc044f2df75c7b275b4bc1b8a76b2c1513862fe4b6d3f9acb9b42d',
    'oracle_completion': '7c0715cb1a89b7126c391886ef9a1ea2100f7d9be6f50bb0cd4d07aa64ecfb2a',
    'oracle_report': '80f6577f67dacb29ad5d1f53c13a85b89aa10ab160cd79daf000dd43ca48d733',
    'oracle_summary': 'c0b2f03fce7832ba95e9e9055b25a0b22037de132a580ed6b9cef6f766df5491',
    'oracle_review': '29f5b4e5291eba8e42e46f8f64f41524771f875c6c720898feb1482d7b388de0',
    'root_result_association': 'd2ec079a9895b19ea6f5cd313cd135d13d86a3ec34335dea34eb44b7ee14ded7',
    'selection': 'd161983440e31ec5c61127639ec30c7e670f32772910f10c22b6ddb8129d238c',
}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def literal(tree, key):
    found = [node.value for node in ast.walk(tree) if isinstance(node, ast.Assign)
             and any(isinstance(target, ast.Name) and target.id == key for target in node.targets)]
    assert len(found) == 1, key
    return ast.literal_eval(found[0])


def main():
    helper_names = ('prepare_delivery.py', 'freeze_delivery.py', 'verify_delivery.py')
    trees = {}
    for name in helper_names:
        text = (WORK/name).read_text()
        compile(text, str(WORK/name), 'exec')
        trees[name] = ast.parse(text)
        assert 'raise RuntimeError(' not in text
    prepare, freeze = trees['prepare_delivery.py'], trees['freeze_delivery.py']
    assert literal(prepare, 'HEAD') == EXPECTED_HEAD and literal(prepare, 'BASE') == EXPECTED_BASE
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == EXPECTED_HEAD
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=REPO, text=True).strip()
    public = literal(prepare, 'PUBLIC')
    assert len(public) == 5 and len(literal(prepare, 'WRAPPERS')) == 2
    assert set(subprocess.check_output(['git', 'diff', '--name-only', EXPECTED_BASE, EXPECTED_HEAD], cwd=REPO, text=True).splitlines()) == set(public)
    roles = literal(freeze, 'REPORT_PATHS')
    assert set(roles) == set(EXPECTED_RECORDS) and len(roles) == 15
    actual = {key: sha(WORK/name) for key, name in roles.items()}
    assert actual == EXPECTED_RECORDS
    results = literal(freeze, 'results')
    assert results['unique_source_window_calculations'] == 9 and results['polynomial_pieces'] == 315
    assert results['patch_window_references'] == 18 and results['hypothesis_window_aggregates'] == 6
    assert results['nonuniform_minus_uniform_contrasts'] == 3 and results['new_core_tests_passed'] == 50
    assert results['source_RHS_calls'] == results['source_assembly_calls'] == results['scalar_source_evolution_calls'] == 0
    assert results['new_moment_checkpoints'] == 6 and results['new_node_Gamma_evaluations'] == 18432
    assert results['prior_accepted_seed_archive_required_for_fresh_oracle_rerun'] is True
    assert results['portable_executions_performed'] is False
    record = {'schema': 'mitl-coupled-windows-delivery-helper-readiness-v1', 'status': 'ready_for_root_execution',
        'source_commit': EXPECTED_HEAD, 'base_commit': EXPECTED_BASE,
        'helper_sha256': {name: sha(WORK/name) for name in helper_names},
        'record_paths': roles, 'record_sha256': actual, 'public_source_sha256': {name: sha(REPO/name) for name in public},
        'results': results, 'selection_key': 'selected_task',
        'validation_scope': 'Source text compilation, AST literal and frozen data-pin reads only; delivery helpers not imported or executed.',
        'scientific_model_test_or_oracle_calls': 0, 'assembly_freeze_or_verification_helpers_executed': False,
        'portable_execution_claimed': False}
    (WORK/'delivery-preparation/helper-readiness.json').write_text(json.dumps(record, indent=2, allow_nan=False)+'\n')
    print(json.dumps(record, indent=2))


if __name__ == '__main__':
    main()
