"""Preserve source/declaration pins without executing the implementation."""

from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
PASS = ROOT.parent
SOURCE = Path("/workspace/Power-Flow/mhdlab/coupled_emission_windows.py")
EXPECTED = "8a235ed92c0e40ccd43375fcd4d6c6beee05fd460b9fbf15102610c338eba786"


def pin(path: Path) -> dict:
    return {"path": str(path), "sha256": sha256(path.read_bytes()).hexdigest()}


def write(name: str, value: dict) -> None:
    path = ROOT / name
    if path.exists():
        raise ValueError(f"refusing to replace freeze artifact: {name}")
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n")


if pin(SOURCE)["sha256"] != EXPECTED:
    raise ValueError("source changed before freeze")
snapshot = ROOT / "coupled_emission_windows.frozen.py"
if snapshot.exists():
    raise ValueError("source snapshot already exists")
snapshot.write_bytes(SOURCE.read_bytes())
output = {
    "schema": "mhdlab-coupled-window-output-contract-v1",
    "source": pin(SOURCE),
    "pieces_keys": ["source_cell_index", "source_start_exact_s", "source_stop_exact_s", "start_exact_s", "stop_exact_s", "source_u_start", "source_u_stop", "source_emitted_controls_m2", "source_temperature_controls_k", "emitted_controls_m2", "temperature_controls_k", "emitted_derivative_controls_m2"],
    "piece_high_level_addition": "source_endpoint_references contains original source node indices,N,M,Gamma,Tdot,inventory residual and scalar energy residuals. These are source references, not repaired states.",
    "source_comparison_keys": ["available", "reason", "bounds_source_indices", "stored_channel_deltas", "polynomial_minus_source", "source_residual_deltas", "energy_defect_decomposition", "wall_debit_difference_decomposition", "reconstructed_source_total_energy_residual_j_m2", "energy_defect_difference_j_m2", "moment_comparisons"],
    "stored_channel_deltas": "All source *_j_m2 fields plus coverage_m2,released_m2,inventory_residual_m2, evaluated as exact differences of represented knot values.",
    "polynomial_minus_source": "Each polynomial areal quantity whose key is also a stored channel; exact polynomial quantity minus exact stored channel difference.",
    "source_residual_deltas": "The subset of stored-channel deltas whose keys contain residual; these are not substituted for reconstructed unprojected state energy residuals.",
    "energy_defect_decomposition": {
        "source_inventory_removal_difference_j_m2": "D*(DeltaM-(Na-Nb))",
        "source_internal_allocation_difference_j_m2": "I*DeltaM-DeltaI_RK",
        "translation_interpolant_minus_source_j_m2": "X_poly-DeltaX_RK",
        "source_input_accumulation_difference_j_m2": "DeltaEin_RK-P*(b-a)"
    },
    "wall_debit_difference_decomposition": {
        "source_binding_allocation_difference_j_m2": "D*DeltaM-DeltaB_RK",
        "source_internal_allocation_difference_j_m2": "I*DeltaM-DeltaI_RK",
        "translation_interpolant_minus_source_j_m2": "X_poly-DeltaX_RK",
        "negative_source_wall_channel_difference_j_m2": "-(DeltaW_RK-DeltaB_RK-DeltaI_RK-DeltaX_RK)"
    },
    "source_residual_formula": "C_A*(Tb-Ta)+D*(Na-Nb)+DeltaI_RK+DeltaX_RK-DeltaEin_RK, using unprojected exact arithmetic on represented inputs.",
    "source_comparison_availability": "Only when both bounds are original source knots. Otherwise maps are empty, scalar residual records null, and reason is window_bounds_not_both_saved_source_knots. Original source time/T moments are unavailable for every window.",
    "scaled_comparison": "Patch:{available,reason,source_window_key,extensive}; aggregate:{available,reason,source_window_keys,extensive}. Extensive contains the five map categories with converted unit keys and both scalar residual records. Aggregates sum exact unprojected area products.",
    "statistics_contrast": "Always {available,reason,record}; actual positive windows remain wrapped rather than switching schema.",
    "cache": {"distinct_source_windows": 9, "patch_references": 18, "aggregate_windows": 6, "contrasts": 3, "source_calls": {"history_evolution": 0, "RHS": 0, "assembly": 0}},
    "all_list_sections": ["source_windows", "patch_windows", "aggregate_windows", "width_window_contrasts"],
    "author_implementation_execution": False,
}
write("output-contract.json", output)
freeze = {
    "schema": "mhdlab-coupled-emission-window-core-freeze-v1",
    "frozen_utc": datetime.now(timezone.utc).isoformat(),
    "source": pin(SOURCE), "snapshot": pin(snapshot),
    "api_contract": pin(ROOT / "api-contract.json"), "output_contract": pin(ROOT / "output-contract.json"),
    "preflight_log": pin(PASS / "window-core-preflight.log"),
    "lease": pin(PASS / "lease.json"),
    "proposal": pin(Path("/workspace/research_work/mitl-upstream-20261019T0710/next-upstream-selection/coupled_emission_window_proposal.json")),
    "mathematical_notes": pin(Path("/workspace/research_work/mitl-upstream-20261019T0710/next-upstream-selection/mathematical-notes.json")),
    "pre_freeze_parser_review_correction": {"nonzero_raw_float_to_zero": "reject by exact mantissa digit test before interpreting source graph", "raw_integer_negative_zero": "reject as noncanonical", "positive_source_bytes_changed": False},
    "imports": "stdlib only; no old modules, source constructors, rate evaluators, assembly or numerical producers imported",
    "author_source_calls": {"history_evolution": 0, "RHS": 0, "assembly": 0, "window_calculation": 0, "tests": 0},
    "syntax_AST_and_declaration_work_only": True,
    "tests_and_sole_export_wait_for_static_review": True,
}
write("source-freeze.json", freeze)
print(json.dumps({"source": pin(SOURCE), "freeze": pin(ROOT / "source-freeze.json"), "output_contract": pin(ROOT / "output-contract.json")}, indent=2))
