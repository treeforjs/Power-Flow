"""Bind the accepted window comparison and final guide without new math queries."""
import datetime,hashlib,json
from decimal import Decimal
from fractions import Fraction
from pathlib import Path
WORK=Path(__file__).resolve().parent
REPO=Path('/workspace/Power-Flow')
RUN=WORK/'producer/reference-run'
ORACLE=WORK/'independent-verification/query-initial/report.json'
REVIEW=WORK/'oracle-review/completion.json'
PUBLIC=('mhdlab/coupled_emission_windows.py','tests/test_coupled_emission_windows.py',
    'tools/export_coupled_emission_windows.py','configs/coupled_emission_windows_manufactured.json',
    'docs/coupled_emission_windows.md')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def pin(path):return {'path':str(path),'sha256':sha(path)}
def load(path):return json.loads(path.read_text())
def fraction(record):
    r=record['exact'];return Fraction(int(r['numerator']),int(r['denominator']))
def metric_values(tree,key):
    if isinstance(tree,dict):
        for name,value in tree.items():
            if name==key and isinstance(value,dict) and 'decimal' in value:
                yield Decimal(value['decimal'])
            else:yield from metric_values(value,key)
    elif isinstance(tree,list):
        for value in tree:yield from metric_values(value,key)
producer,oracle,review=load(RUN/'report.json'),load(ORACLE),load(REVIEW)
assert oracle['schema']=='mitl-independent-coupled-window-query-report-v1'
assert oracle['status']=='passed' and oracle['all_checks_passed'] is True
assert review['status']=='accepted' and review['actual_report_sha256']==sha(ORACLE)
assert Path(review['actual_report_path']).resolve()==ORACLE.resolve()
assert oracle['producer_report_sha256']==sha(RUN/'report.json')
a=load(RUN/'coupled_emission_windows.json')
assert oracle['window_document_sha256']==sha(RUN/'coupled_emission_windows.json')
assert a['cache']['source_calls']=={'history_evolution':0,'RHS':0,'assembly':0}
maxima={name:str(max(metric_values(oracle[name],'scaled_absolute_error'))) for name in
    ['per_window_checks','gross_mixture_checks','own_width_contrast_checks']}
maxima['own_contrast_reference_change']=str(max(metric_values(oracle['own_width_contrast_checks'],'scaled_reference_change')))
keys=('released_number','translational_energy_j','total_wall_energy_debit_j','total_energy_residual_j')
aggregates={}
for row in a['aggregate_windows']:
    aggregates.setdefault(row['query_id'],{})[row['hypothesis']]={
        'extensive':{k:row['extensive'][k] for k in keys},'statistics':row['statistics']}
contrasts=[]
for row in a['width_window_contrasts']:
    q=row['query_id'];values=row['quantity_difference_nonuniform_minus_uniform']
    uniform=aggregates[q]['uniform']['extensive']
    contrasts.append({'query_id':q,'extensive':{k:values[k] for k in keys},
        'difference_fraction_of_uniform':{k:float(fraction(values[k])/fraction(uniform[k]))
            for k in ('released_number','translational_energy_j')},
        'numerical_sign_flags':{k:v['numerical_sign_resolved'] for k,v in oracle['own_width_contrast_checks'][q].items()}})
record={'schema':'mitl-coupled-window-root-result-association-v1',
    'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'parameter_status':'manufactured',
    'producer_report':pin(RUN/'report.json'),'oracle_report':pin(ORACLE),'oracle_review':pin(REVIEW),
    'public_source_sha256':{name:sha(REPO/name) for name in PUBLIC},
    'guide':pin(REPO/'docs/coupled_emission_windows.md'),
    'record_counts':producer['record_counts'],'cache':a['cache'],
    'new_reference_work_counts':oracle['new_work_counts'],'exact_check_counts':oracle['exact_check_counts'],
    'maximum_numerical_error_estimates':maxima,'aggregates':aggregates,'contrasts':contrasts,
    'source_RK_comparison_availability':{'available':sum(x['source_RK_comparison']['available'] for x in a['source_windows']),
        'unavailable':sum(not x['source_RK_comparison']['available'] for x in a['source_windows'])},
    'visual_review':{'performed':False,'reason':'Data-only export; no new image was generated or claimed inspected.'},
    'limits':['Source-emission windows are not registered photon gates.',
        'Full joint coefficients accompany means, variances and covariance; no single thermal velocity or particle launch is inferred.',
        'Polynomial, represented source-allocation/integration and new IVP-query errors remain separate; no inventory or energy repair.',
        'Finite numerical estimates are not certified bounds, physical uncertainty or spectral discrimination.',
        'No source/RHS/assembly or new numerical query was repeated by this association.']}
out=WORK/'root-result-association.json';assert not out.exists()
out.write_text(json.dumps(record,indent=2,allow_nan=False)+'\n')
print(json.dumps({'result':pin(out),'maximum_numerical_error_estimates':maxima,
    'window_difference_fractions':{x['query_id']:x['difference_fraction_of_uniform'] for x in contrasts}},indent=2))
