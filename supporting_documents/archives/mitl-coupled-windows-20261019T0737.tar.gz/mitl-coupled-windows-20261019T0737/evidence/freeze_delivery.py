"""Freeze new saved coupled-window evidence without replaying source calculations."""
import datetime
import csv
import hashlib
import io
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tarfile
from xml.etree import ElementTree

from prepare_delivery import WORK, REPO, BASE, OUT, PUBLIC, WRAPPERS, clean_head, dependency_context, input_contract, command_snapshot_prefix, load, save, sha

TEXT_SUFFIXES = {'.py', '.json', '.jsonl', '.log', '.xml', '.md', '.txt', '.patch', '.sha256', '.yaml', '.csv'}
EVIDENCE_DIRS = ('core', 'core-review', 'producer', 'tests', 'independent-verification', 'oracle-review', 'next-upstream-selection', 'delivery-preparation', 'completion-preparation')
REPORT_PATHS = {
    'producer_run': 'producer/reference-run/report.json',
    'producer_completion': 'producer/completion.json',
    'input_guards': 'producer/input_guard_checks.json',
    'input_lineage': 'producer/final_input_lineage.json',
    'csv_availability_amendment': 'producer/csv_availability_amendment.json',
    'producer_before_run': 'producer/freeze.json',
    'tests_completion': 'tests/completion.json',
    'core_freeze': 'core/source-freeze.json',
    'static_core_review': 'core-review/completion.json',
    'oracle_completion': 'independent-verification/completion.json',
    'oracle_report': 'independent-verification/query-initial/report.json',
    'oracle_summary': 'independent-verification/summary.json',
    'oracle_review': 'oracle-review/completion.json',
    'root_result_association': 'root-result-association.json',
    'selection': 'next-upstream-selection/selection.json',
}

PROJECTIONS = (
    (bytes.fromhex('2f6f70742f636f6465782f72756e74696d65732f636f6465782d7072696d6172792d72756e74696d652f646570656e64656e636965732f707974686f6e'), b'[runtime Python directory]'),
    (bytes.fromhex('2f6574632f636f6465782f'), b'[runtime policy directory]/'),
)


def excluded(relative, allowed_figures=()):
    path = Path(relative)
    if 'delivery-preparation' in path.parts and 'payload' in path.parts:
        return True
    if any(part in {'__pycache__', '.pytest_cache', '.venv', 'source-local', 'fulltexts', 'raw-fulltexts',
                    'pytest-temp', 'pytest-tmp', 'test-fixtures', 'fixtures'}
           or part.startswith('.coupled-emission-windows-') for part in path.parts):
        return True
    if path.suffix == '.pyc':
        return True
    if 'source-acquisition' in path.parts:
        return 'raw' in path.parts or path.suffix not in {'.json', '.jsonl', '.py', '.md', '.log', '.sha256'}
    if path.suffix.lower() in {'.png', '.pdf', '.jpg', '.jpeg', '.tif', '.tiff'}:
        return str(path) not in set(allowed_figures)
    return False


def verify_contracts(records, configured_inputs, *, work_sha=None, public_sha=None, work_bytes=None):
    """Check frozen metadata and exact bytes without loading the scientific module."""
    h = work_sha or (lambda name: sha(WORK/name))
    p = public_sha or (lambda name: sha(REPO/name))
    b = work_bytes or (lambda name: (WORK/name).read_bytes())

    def artifacts(mapping, prefix=''):
        assert isinstance(mapping, dict) and mapping
        for name, digest in mapping.items():
            path = Path(name)
            assert not path.is_absolute() and '..' not in path.parts
            assert re.fullmatch('[0-9a-f]{64}', digest) and h(prefix+name) == digest

    def counts(record, expected):
        for key, value in expected.items():
            assert type(record[key]) is int and record[key] == value, key

    def reference(record):
        name = str(Path(record['path']).relative_to(WORK))
        assert h(name) == record['sha256']
        return name

    core_path = 'mhdlab/coupled_emission_windows.py'
    test_path = 'tests/test_coupled_emission_windows.py'
    cli_path = 'tools/export_coupled_emission_windows.py'
    tests = records['tests_completion']
    assert tests['schema'] == 'mitl-coupled-emission-window-tests-v1'
    assert tests['status'] == 'passed' and tests['all_checks_passed'] is True
    counts(tests, {'unique_new_test_cases': 50, 'test_case_executions': 50, 'targeted_test_runs': 1,
        'passing_test_cases': 50, 'failed_test_cases': 0, 'pre_execution_parser_cases_added': 2,
        'scalar_evolution_calls': 0, 'scalar_rhs_calls': 0, 'old_assembly_calls': 0,
        'old_source_admission_positive_calls': 0})
    assert tests['initial48_plan_executed'] is False and tests['old48_test_function_AST_unchanged_by_amendment'] is True
    assert tests['manufactured_polynomial_fixtures_only'] is True and tests['source_ODE_truth_claimed'] is False
    assert tests['old_test_suites_repeated'] is False and tests['physical_truth_verified'] is False
    assert tests['host_budget_accepted'] is False and tests['exit_code'] == 0
    assert all(p(name) == digest for name, digest in tests['public_source_sha256'].items())
    artifacts(tests['artifact_sha256'])
    suites = list(ElementTree.fromstring(b('tests/initial.xml')).iter('testsuite'))
    assert sum(int(suite.attrib.get('tests', 0)) for suite in suites) == 50
    assert all(int(suite.attrib.get(key, 0)) == 0 for suite in suites for key in ('failures', 'errors', 'skipped'))
    core = records['core_freeze']
    assert core['schema'] == 'mhdlab-coupled-emission-window-core-freeze-v1'
    assert core['source']['sha256'] == p(core_path) == core['snapshot']['sha256']
    assert reference(core['snapshot']) == 'core/coupled_emission_windows.frozen.py'
    for key in ('api_contract', 'output_contract', 'preflight_log', 'lease'):
        reference(core[key])
    assert core['proposal']['sha256'] == h('selected-proposal.json')
    counts(core['author_source_calls'], {'history_evolution': 0, 'RHS': 0, 'assembly': 0,
                                         'window_calculation': 0, 'tests': 0})
    assert core['syntax_AST_and_declaration_work_only'] is True
    static = records['static_core_review']
    assert static['schema'] == 'mitl-coupled-window-static-core-review-v1'
    assert static['status'] == 'review_complete_no_substantive_issue_identified' and static['findings'] == []
    assert static['reviewed_source_sha256'] == p(core_path)
    assert static['source_freeze_sha256'] == h(REPORT_PATHS['core_freeze'])
    assert static['output_contract_sha256'] == h('core/output-contract.json')
    assert static['mandatory_joint_time_temperature_moment_and_covariance_reviewed'] is True
    assert static['source_residuals_and_three_defect_layers_preserved'] is True
    for key in ('further_changes_requested', 'scientific_module_imported', 'numerical_models_or_tests_executed',
                'source_admission_or_window_calculation_executed', 'producer_or_oracle_executed',
                'old_source_numerical_checks_replayed', 'physical_parameters_validated', 'host_budget_accepted'):
        assert static[key] is False
    artifacts(static['artifact_sha256'], 'core-review/')
    assert static['source_file_sha256'] == {alias: item['sha256']
        for alias, item in configured_inputs['accepted_source_binding']['files'].items()}
    guards, lineage, csv_amendment = records['input_guards'], records['input_lineage'], records['csv_availability_amendment']
    assert guards['schema'] == 'mhdlab-coupled-window-final-input-preflight-v1' and guards['status'] == 'passed'
    assert guards['config_sha256'] == configured_inputs['config_sha256']
    assert guards['cli_sha256'] == h('producer/source-versions/cli_after_review_status_fix.py')
    counts(guards, {'focused_executions': 2, 'new_window_calculations': 0})
    assert guards['pure_math_or_source_model_imports_or_calls'] is False
    assert guards['initial_execution']['exit_code'] == 1
    assert h(guards['initial_execution']['log']) == guards['initial_execution']['log_sha256']
    assert guards['initial_execution']['initial_cli_sha256'] == h('producer/source-versions/initial_cli_before_review_status_fix.py')
    assert lineage['schema'] == 'mhdlab-coupled-window-final-cli-input-lineage-v1'
    assert lineage['status'] == 'passed_static_lineage_and_late_byte_guards'
    assert lineage['initial_cli_sha256'] == guards['initial_execution']['initial_cli_sha256']
    assert lineage['review_status_corrected_cli_sha256'] == guards['cli_sha256']
    assert lineage['final_cli_sha256'] == h('producer/source-versions/cli_before_explicit_csv_null.py')
    assert lineage['status_fix_exact_single_literal_only'] is True
    assert lineage['all_config_parser_ASTs_unchanged_across_all_versions'] is True
    assert lineage['source_preflight_guard_report_sha256'] == h(REPORT_PATHS['input_guards'])
    counts(lineage, {'focused_late_byte_check_count': 2, 'approved_config_load_setup_count': 1, 'new_window_calculations': 0})
    assert lineage['pure_math_or_source_model_imports_or_calls'] is False
    qualification = lineage['source_preflight_execution_qualification']
    counts(qualification, {'initial_controls_attempted': 19, 'initial_controls_succeeded_before_stop': 18,
        'initial_valid_source_preflight_failed': 1, 'corrected_source_preflight_controls_passed': 2,
        'corrected_source_preflight_approved_config_load_setup': 1})
    assert qualification['initial_controls_repeated'] is False
    assert qualification['all_final_source_full_control_rerun_claimed'] is False
    assert csv_amendment['schema'] == 'mhdlab-coupled-window-csv-availability-amendment-v1'
    assert csv_amendment['status'] == 'passed_export_only_check'
    assert csv_amendment['before_cli_sha256'] == lineage['final_cli_sha256']
    assert csv_amendment['final_cli_sha256'] == p(cli_path)
    assert csv_amendment['changed_functions'] == ['_write_csv']
    assert csv_amendment['input_and_query_parser_ASTs_unchanged'] is True
    counts(csv_amendment, {'synthetic_table_rows': 2, 'window_calculations': 0})
    assert csv_amendment['polynomial_source_model_or_rhs_imports_or_calls'] is False
    assert csv_amendment['final_input_lineage_sha256'] == h(REPORT_PATHS['input_lineage'])
    return verify_saved_export(records, configured_inputs, h, p, b, artifacts, counts, reference)


def verify_saved_export(records, configured_inputs, h, p, b, artifacts, counts, reference):
    run, produced, before = records['producer_run'], records['producer_completion'], records['producer_before_run']
    assert run['schema'] == 'mhdlab-coupled-emission-windows-export-run-v1'
    assert run['status'] == 'manufactured_saved_source_windows_only'
    assert run['config_sha256'] == configured_inputs['config_sha256']
    assert all(p(name) == digest for name, digest in run['code_sha256'].items())
    assert run['source_binding'] == configured_inputs['accepted_source_binding']
    assert run['queries'] == configured_inputs['configuration']['queries']
    assert run['quantity_contract'] == configured_inputs['configuration']['quantity_contract']
    assert run['representation_contract'] == configured_inputs['configuration']['representation_contract']
    assert run['artifact_path_base'] == run['copied_source_path_base'] == 'directory containing report.json'
    prefix = 'producer/reference-run/'
    artifacts(run['artifact_sha256'], prefix)
    artifacts(run['copied_source_input_sha256'], prefix)
    binding = configured_inputs['accepted_source_binding']
    expected_copies = {'source-inputs/'+item['relative_path']: item['sha256']
        for item in list(binding['files'].values())+list(binding['lineage']['auxiliary_files'].values())}
    assert len(expected_copies) == 12 and run['copied_source_input_sha256'] == expected_copies
    assert load_json_bytes(b(prefix+'input_config.json')) == configured_inputs['configuration']
    expected_counts = {'source_windows': 9, 'polynomial_pieces': 315, 'patch_windows': 18,
                       'aggregate_windows': 6, 'width_window_contrasts': 3}
    counts(run['record_counts'], expected_counts)
    result = load_json_bytes(b(prefix+run['result_file']))
    assert h(prefix+run['result_file']) == run['result_sha256']
    assert result['schema'] == 'mhdlab-coupled-emission-windows-v1' and result['parameter_status'] == 'manufactured'
    assert result['host_budget_accepted'] is False and result['owner_implementation_verified'] is False
    counts(result['cache'], {'distinct_source_windows': 9, 'patch_references': 18, 'aggregate_windows': 6, 'contrasts': 3})
    counts(result['cache']['source_calls'], {'history_evolution': 0, 'RHS': 0, 'assembly': 0})
    assert result['cache'] == run['cache']
    admission = result['source_admission']
    assert admission['schema'] == 'mhdlab-coupled-emission-saved-source-admission-v1'
    assert admission['status'] == 'accepted_saved_manufactured_source'
    assert admission['file_sha256'] == {key: item['sha256'] for key, item in binding['files'].items()}
    assert admission['canonical_history_sha256'] == binding['canonical_history_sha256']
    assert admission['numerical_code_sha256'] == binding['numerical_run_code_sha256']
    counts(admission['source_calls'], {'history_evolution': 0, 'RHS': 0, 'assembly': 0})
    assert admission['accepted_independent_scope']['dense_Taylor_coefficients_or_off_knot_queries_retained'] is False
    assert admission['host_budget_accepted'] is False and admission['owner_implementation_verified'] is False
    for section in ('source_windows', 'patch_windows', 'aggregate_windows', 'width_window_contrasts'):
        assert len(result[section]) == expected_counts[section]
        table = list(csv.DictReader(io.StringIO(b(prefix+section+'.csv').decode())))
        assert len(table) == expected_counts[section] and all(value != '' for row in table for value in row.values())
    pieces = [piece for row in result['source_windows'] for piece in row['pieces']]
    assert len(pieces) == len(list(csv.DictReader(io.StringIO(b(prefix+'polynomial_pieces.csv').decode())))) == 315
    aligned = off_knot = 0
    for row in result['source_windows']:
        assert row['canonical_history_sha256'] == binding['canonical_history_sha256'][row['source_history_id']]
        assert row['raw_history_file_sha256'] == binding['files'][row['source_history_id']]['sha256']
        assert row['local_time_anchor_exact_s'] == row['window_start_exact_s']
        assert 'local_time_temperature_moment_k_s_m2' in row['areal']
        for key in ('mean_local_time_temperature_k_s', 'covariance_local_time_temperature_k_s'):
            assert row['statistics'][key]['available'] is True and row['statistics'][key]['record'] is not None
        comparison = row['source_RK_comparison']
        if comparison['available']:
            aligned += 1
            assert comparison['reason'] is None and comparison['bounds_source_indices'] is not None
        else:
            off_knot += 1
            assert comparison['reason'] == 'window_bounds_not_both_saved_source_knots'
            assert comparison['bounds_source_indices'] is None
            assert all(comparison[key] == {} for key in ('stored_channel_deltas', 'polynomial_minus_source',
                'source_residual_deltas', 'energy_defect_decomposition', 'wall_debit_difference_decomposition'))
            assert comparison['reconstructed_source_total_energy_residual_j_m2'] is None
            assert comparison['energy_defect_difference_j_m2'] is None
        assert all(item == {'available': False, 'reason': 'source_does_not_store_cumulative_time_or_temperature_moments', 'record': None}
                   for item in comparison['moment_comparisons'].values())
        assert row['independent_window_reference']['available'] is False and row['independent_window_reference']['record'] is None
    assert aligned == 6 and off_knot == 3
    qualifications = run['qualifications']
    counts(qualifications, {'source_evolution_calls': 0, 'source_RHS_calls': 0, 'source_assembly_calls': 0, 'build_call_count': 1})
    assert qualifications['old_source_models_imported'] is False
    assert qualifications['source_input_hashes_rechecked_after_window_calculations'] is True
    assert qualifications['three_source_error_layers_preserved'] is True
    assert qualifications['joint_local_time_temperature_moment_required'] is True
    assert qualifications['new_independent_window_reference_computed_here'] is False
    assert qualifications['actual_physical_or_spectral_claim'] is False
    assert produced['schema'] == 'mhdlab-coupled-window-producer-completion-v1'
    assert produced['status'] == 'passed_saved_data_export_and_readback'
    assert produced['report_path'] == REPORT_PATHS['producer_run'] and produced['report_sha256'] == h(produced['report_path'])
    assert produced['result_sha256'] == h(produced['result_path']) == run['result_sha256']
    assert produced['config_sha256'] == configured_inputs['config_sha256']
    assert all(p(name) == digest for name, digest in produced['public_source_sha256'].items())
    counts(produced, {'positive_saved_data_export_batches': 1, 'copied_source_file_count': 12,
                      'new_unique_core_checks': 50, 'late_raw_byte_checks': 2, 'source_evolution_RHS_assembly_calls': 0})
    counts(produced['record_counts'], expected_counts)
    assert produced['cache'] == result['cache']
    assert produced['copied_source_input_sha256'] == expected_copies
    assert produced['source_binding'] == binding
    assert produced['input_execution_qualification'] == records['input_lineage']['source_preflight_execution_qualification']
    assert produced['independent_window_error_qualification_included_here'] is False
    assert produced['old_suites_or_numerical_cases_replayed'] is False and produced['open_substantive_findings'] == []
    assert produced['artifact_path_base'] == 'pass directory containing producer/'
    artifacts(produced['artifact_sha256'])
    artifacts(produced['accepted_prerequisite_sha256'])
    for key, role in (('csv_export_amendment', 'csv_availability_amendment'), ('input_guard_report', 'input_guards'), ('final_input_lineage', 'input_lineage')):
        assert produced[key]['path'] == REPORT_PATHS[role] and produced[key]['sha256'] == h(REPORT_PATHS[role])
    assert produced['saved_readback']['all_exact_ratio_projection_and_null_availability_fields_retained'] is True
    assert produced['saved_readback']['joint_local_time_temperature_moments_retained_for_all9_source_windows'] is True
    counts(produced['saved_readback'], {'source_RK_available_knot_windows': 6, 'source_RK_unavailable_off_knot_windows': 3})
    assert produced['saved_readback']['source_and_polynomial_model_imports_or_calls'] is False
    command = produced['batch']
    assert command['exit_code'] == 0 and h(str(Path(command['log']).relative_to(WORK))) == command['log_sha256']
    verify_export_freeze(before, records, configured_inputs, h, p, artifacts)
    return verify_query_reference(records, configured_inputs, h, p, b, artifacts, counts, reference)


def verify_export_freeze(before, records, configured_inputs, h, p, artifacts):
    assert before['schema'] == 'mhdlab-coupled-window-producer-freeze-v1'
    assert before['status'] == 'frozen_before_first_saved_data_export'
    assert all(p(name) == digest for name, digest in before['public_source_sha256'].items())
    artifacts(before['source_snapshots_sha256'], 'producer/')
    artifacts(before['accepted_prerequisite_sha256'])
    assert before['input_execution_qualification'] == records['input_lineage']['source_preflight_execution_qualification']
    for key, role in (('input_guard_report', 'input_guards'), ('final_input_lineage', 'input_lineage'), ('csv_export_amendment', 'csv_availability_amendment')):
        assert before[key]['path'] == REPORT_PATHS[role] and before[key]['sha256'] == h(REPORT_PATHS[role])
    assert before['all_final_source_full_control_rerun_claimed'] is False
    assert before['prior_saved_data_export_batches'] == 0 and before['source_evolution_RHS_assembly_calls'] == 0


def verify_query_reference(records, configured_inputs, h, p, b, artifacts, counts, reference):
    report, complete, summary, review = (records[key] for key in ('oracle_report', 'oracle_completion', 'oracle_summary', 'oracle_review'))
    assert report['schema'] == 'mitl-independent-coupled-window-query-report-v1'
    assert report['status'] == 'passed' and report['all_checks_passed'] is True
    top_counts = {'distinct_source_window_queries': 9, 'patch_references': 18, 'aggregate_windows': 6,
                  'width_contrasts': 3, 'old_reference_grid_calls': 0, 'old_source_RHS_calls': 0, 'producer_calls_by_oracle': 0}
    work_counts = {'Gamma_node_evaluations': 18432, 'Taylor_coefficient_exponential_calls': 107520,
        'dense_substeps': 1152, 'new_off_knot_state_values': 12, 'old_full_state_driver_calls': 0,
        'physical_state_exponential_evaluations': 57600, 'quadrature_nodes': 18432,
        'seeded_cells': 384, 'source_RHS_calls': 0, 'window_weight_accumulations': 29952}
    exact_counts = {'CSV_cells': 17781, 'CSV_float_projections': 1843, 'CSV_rows': 351,
        'exact_source_defect_records': 1078, 'mixture_quantity_and_statistic_records': 567,
        'piece_exact_associations': 7875, 'quantity_and_statistic_records': 189}
    counts(report, top_counts)
    counts(report['new_work_counts'], work_counts)
    counts(report['exact_check_counts'], exact_counts)
    assert report['accepted_old_report_sha256'] == configured_inputs['accepted_source_binding']['files']['independent_report']['sha256']
    assert report['producer_report_sha256'] == h(REPORT_PATHS['producer_run'])
    assert report['window_document_sha256'] == records['producer_run']['result_sha256']
    assert report['forbidden_model_or_numerical_package_imports'] == []
    assert report['host_budget_accepted'] is False and report['source_emission_windows_are_photon_gates'] is False
    artifacts(report['source_version_sha256'], 'independent-verification/')
    artifacts(report['checkpoint_sha256'], 'independent-verification/query-initial/')
    assert len(report['checkpoint_sha256']) == 6
    for name, key in (('reference_windows.json', 'reference_windows_sha256'),
                      ('exact_polynomial_windows.json', 'exact_polynomial_windows_sha256'),
                      ('contrast_queries.json', 'contrast_queries_sha256'), ('source_defects.json', 'source_defects_sha256')):
        assert h('independent-verification/query-initial/'+name) == report[key]
    assert set(report['own_width_contrast_checks']) == {'complete_source_support', 'early_interior', 'off_knot_interior'}
    assert all('covariance_local_time_temperature_k_s' in value for value in report['own_width_contrast_checks'].values())
    assert complete['schema'] == 'mitl-independent-coupled-window-completion-v1'
    assert complete['status'] == 'passed' and complete['all_checks_passed'] is True
    counts(complete, top_counts)
    counts(complete, {'completed_independent_query_runs': 1, 'independent_query_run_attempts': 1,
        'new_moment_checkpoints': 6, 'new_off_knot_endpoint_state_pairs': 12, 'new_off_knot_scalar_coordinates': 24,
        'polynomial_pieces_checked': 315, 'precision_levels': 2, 'reference_window_records_across_levels': 18,
        'production_source_evolution_calls': 0, 'saved_metadata_aggregation_attempts': 2,
        'source_window_knot_comparisons_available': 6, 'source_window_off_knot_comparisons_unavailable': 3})
    assert complete['new_work_counts'] == report['new_work_counts']
    assert complete['exact_check_counts'] == report['exact_check_counts']
    assert complete['report_sha256'] == h(REPORT_PATHS['oracle_report'])
    assert complete['summary_sha256'] == h(REPORT_PATHS['oracle_summary'])
    assert complete['producer_report_sha256'] == h(REPORT_PATHS['producer_run'])
    assert complete['final_static_review_sha256'] == h(REPORT_PATHS['oracle_review'])
    for key in ('host_budget_accepted', 'owner_implementation_verified', 'physical_uncertainty_established',
                'old_references_repeated', 'old_suites_repeated', 'source_emission_windows_are_photon_gates'):
        assert complete[key] is False
    artifacts(complete['artifact_sha256'])
    artifacts(complete['source_sha256'], 'independent-verification/')
    assert complete['source_sha256'] == report['source_version_sha256']
    command = complete['query_run_command']
    assert command['exit_code'] == 0 and h(str(Path(command['log']).relative_to(WORK))) == command['log_sha256']
    assert summary['schema'] == 'mitl-independent-coupled-window-summary-v1' and summary['status'] == 'passed'
    assert summary['report_sha256'] == h(REPORT_PATHS['oracle_report'])
    assert summary['new_work_counts'] == work_counts and summary['exact_check_counts'] == exact_counts
    assert summary['new_window_interpolation_target'] == '2e-4' and summary['reference_change_target'] == '1e-20'
    assert review['schema'] == 'mitl-coupled-window-static-oracle-review-v1' and review['status'] == 'accepted'
    assert review['actual_report_sha256'] == h(REPORT_PATHS['oracle_report']) == review['owner_report_sha256']
    assert review['producer_report_sha256'] == h(REPORT_PATHS['producer_run'])
    assert review['window_document_sha256'] == records['producer_run']['result_sha256']
    assert review['production_core_sha256'] == p('mhdlab/coupled_emission_windows.py')
    artifacts(review['source_version_sha256'], 'independent-verification/')
    artifacts(review['actual_reference_output_sha256'], 'independent-verification/query-initial/')
    artifacts(review['artifact_sha256'], 'oracle-review/')
    assert review['actual_own_scale_contrast_and_reference_ladder_records_read'] is True
    assert review['gross_physical_mixture_and_positive_integral_qualifications_read'] is True
    assert review['completed_report_bound_without_numerical_replay'] is True
    assert review['owner_report_numerics_recomputed_by_reviewer'] is False
    assert len(review['findings']) == 3 and all(row['status'] == 'repaired_before_first_query' for row in review['findings'])
    for key in ('further_changes_requested', 'scientific_module_imported', 'numerical_models_or_tests_executed',
                'source_evolution_RHS_assembly_or_window_calculation_executed', 'producer_or_oracle_executed',
                'old_grid_or_case_replayed', 'physical_parameters_validated', 'host_budget_accepted'):
        assert review[key] is False
    old_acceptance = load_json_bytes(b('producer/reference-run/source-inputs/independent-verification/oracle-initial/report.json'))
    seed_declaration = load_json_bytes(b('independent-verification/before_plan_freeze.json'))
    assert seed_declaration['accepted_seed_report_sha256'] == report['accepted_old_report_sha256']
    assert seed_declaration['accepted_seed_checkpoint_sha256'] == old_acceptance['reference_checkpoint_sha256']
    verify_root_and_selection(records, h, p, b, artifacts, counts, reference)
    relationships = {
        'test_initial48_plan_executed': False, 'test_preexecution_parser_cases_added': 2,
        'all50_test_cases_ran_on_final_core_and_test_bytes': True,
        'input_guard_source_versions': records['input_lineage'],
        'csv_availability_export_only_amendment': records['csv_availability_amendment'],
        'accepted_source_numerical_and_plotting_versions': configured_inputs['accepted_source_binding']['lineage'],
        'accepted_source_and_prior_acceptance_are_inputs_not_new_results': True,
        'old_seed_archive_additional_dependency': {'archive': '/workspace/handoffs/mitl-width-power-20261019T0710.tar.gz',
            'sha256': '571dad5b7316d78eecae911ae592df97ef7c16cf1feffaa24ac12607f50867dd',
            'seed_checkpoint_sha256': seed_declaration['accepted_seed_checkpoint_sha256'],
            'original_seed_bytes_duplicated': False},
        'independent_prequery_completeness_amendment': load_json_bytes(b('independent-verification/pre_query_completeness_amendment.json')),
        'independent_final_guard_freeze': load_json_bytes(b('independent-verification/final_before_query_freeze.json')),
        'independent_metadata_aggregation_attempts': 2, 'independent_numerical_query_attempts': 1,
        'source_evolution_RHS_or_assembly_replayed': False,
    }
    results = {'new_core_tests_passed': 50, 'test_case_executions': 50, 'targeted_test_runs': 1,
        'scalar_source_evolution_calls': 0, 'source_RHS_calls': 0, 'source_assembly_calls': 0,
        'initial_input_guard_attempts': 19, 'initial_input_controls_succeeded': 18,
        'initial_valid_source_preflight_failures': 1, 'focused_corrected_preflight_controls_passed': 2,
        'late_raw_byte_checks': 2, 'synthetic_csv_availability_rows': 2,
        'saved_data_export_batches': 1, 'unique_source_window_calculations': 9, 'polynomial_pieces': 315,
        'patch_window_references': 18, 'hypothesis_window_aggregates': 6, 'nonuniform_minus_uniform_contrasts': 3,
        'copied_raw_export_inputs': 12, 'source_knot_comparisons_available': 6,
        'source_off_knot_comparisons_unavailable': 3, 'mandatory_joint_time_temperature_covariance_retained': True,
        'new_independent_query_runs': 1, 'new_reference_precision_levels': 2, 'new_moment_checkpoints': 6,
        'reference_window_records_across_levels': 18, 'new_seeded_cells': 384, 'new_dense_substeps': 1152,
        'new_node_Gamma_evaluations': 18432, 'new_window_weight_accumulations': 29952,
        'new_reference_physical_state_exponential_evaluations': 57600,
        'new_Taylor_coefficient_exponential_calls': 107520,
        'new_off_knot_endpoint_state_pairs': 12, 'new_off_knot_scalar_coordinates': 24,
        'exact_CSV_cells_checked': 17781, 'exact_CSV_rows_checked': 351,
        'piece_exact_associations_checked': 7875, 'exact_source_defect_records_checked': 1078,
        'old_reference_grid_or_suite_replays': 0, 'source_emission_windows_are_photon_gates': False,
        'own_contrast_and_reference_ladders_separately_qualified': True,
        'prior_accepted_seed_archive_required_for_fresh_oracle_rerun': True,
        'scientific_numerics_reexecuted_during_packaging': False, 'portable_executions_performed': False,
        'physical_truth_validated': False, 'host_budget_accepted': False, 'owner_implementation_verified': False}
    return {'results': results, 'source_version_relationships': relationships, 'allowed_figure_paths': []}


def verify_root_and_selection(records, h, p, b, artifacts, counts, reference):
    root = records['root_result_association']
    assert root['schema'] == 'mitl-coupled-window-root-result-association-v1'
    assert root['parameter_status'] == 'manufactured'
    assert set(root['public_source_sha256']) == set(PUBLIC)
    assert all(p(name) == digest for name, digest in root['public_source_sha256'].items())
    for key, role in (('producer_report', 'producer_run'), ('oracle_report', 'oracle_report'), ('oracle_review', 'oracle_review')):
        assert reference(root[key]) == REPORT_PATHS[role]
    assert root['guide']['sha256'] == p('docs/coupled_emission_windows.md')
    counts(root['record_counts'], {'source_windows': 9, 'patch_windows': 18, 'aggregate_windows': 6,
                                 'width_window_contrasts': 3, 'polynomial_pieces': 315})
    assert root['new_reference_work_counts'] == records['oracle_report']['new_work_counts']
    assert root['exact_check_counts'] == records['oracle_report']['exact_check_counts']
    assert root['source_RK_comparison_availability'] == {'available': 6, 'unavailable': 3}
    assert root['visual_review']['performed'] is False
    selection_contract(records['selection'], h, p, b, artifacts, counts, reference)


def selection_contract(selection, h, p, b, artifacts, counts, reference):
    assert selection['schema'] == 'mhdlab-upstream-selected-task-v1'
    assert selection['status'] == 'selected_pending_fresh_bounded_lease'
    assert selection['task_id'] == 'positive-joint-boundary-quadrature-handoff'
    assert isinstance(selection['selected_task'], str) and selection['selected_task'].strip()
    assert selection['fresh_lease_required'] is True and selection['public_implementation_started'] is False
    assert selection['public_files_changed_by_selection'] == [] and selection['numerical_execution_by_selection'] is False
    assert selection['owner_implementation_verified'] is False and selection['host_budget_accepted'] is False
    for key in ('proposal', 'preserved_conditional_selection', 'predecessor_acceptance'):
        reference(selection[key])


def load_json_bytes(data):
    from prepare_delivery import loads
    return loads(data)


def main():
    payload = WORK/'delivery-preparation/payload'
    preparation = load(payload/'preparation.json')
    head = clean_head(preparation['source_commit'])
    assert preparation['base_commit'] == BASE
    assert not OUT.exists() and not OUT.with_suffix('.tar.gz').exists()
    assert load(payload/'source_file_list.json') == {'byte_identical_public_files': list(PUBLIC), 'packaging_wrappers': list(WRAPPERS)}
    assert len(PUBLIC) == 5 and len(WRAPPERS) == 2
    assert {str(path.relative_to(payload/'source')) for path in (payload/'source').rglob('*') if path.is_file()} == set(PUBLIC)|set(WRAPPERS)
    assert not (payload/'source/mhdlab/__init__.py').exists()
    for name in PUBLIC:
        assert (payload/'source'/name).read_bytes() == (REPO/name).read_bytes()
    context = dependency_context()
    assert context == preparation['dependency_context'] == load(payload/'dependency_context.json')
    configured_inputs = input_contract()
    assert configured_inputs == preparation['input_contract']
    records = {key: load(WORK/name) for key, name in REPORT_PATHS.items()}
    contract = verify_contracts(records, configured_inputs)
    allowed_figures = contract['allowed_figure_paths']
    next_task = records['selection']['selected_task']
    assert isinstance(next_task, str) and next_task.strip()
    shutil.copytree(payload, OUT)
    evidence = OUT/'evidence'
    evidence.mkdir()
    try:
        active_log = Path(os.readlink('/proc/self/fd/1')).resolve()
    except OSError:
        active_log = None
    copied_inputs, omitted, copied_root_files = [], [], []

    def copy(path, relative):
        assert not path.is_symlink()
        digest = sha(path)
        target = evidence/relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, target)
        assert sha(target) == digest
        copied_inputs.append({'source': str(path), 'archive': str(target.relative_to(OUT)), 'sha256': digest})

    for path in WORK.iterdir():
        if path.is_file() and path.suffix in TEXT_SUFFIXES and path.resolve() != active_log:
            copy(path, Path(path.name))
            copied_root_files.append(path.name)
    for folder in EVIDENCE_DIRS:
        for path in (WORK/folder).rglob('*'):
            assert not path.is_symlink()
            if not path.is_file():
                continue
            relative = path.relative_to(WORK)
            if excluded(relative, allowed_figures):
                omitted.append({'path': str(relative), 'sha256': sha(path), 'bytes': path.stat().st_size,
                    'reason': 'Cache, temporary fixture, failed staging data or unselected figure omitted from this new reference evidence.'})
            else:
                copy(path, relative)
    commands_raw = (evidence/'commands.jsonl').read_bytes()
    snapshot = command_snapshot_prefix(commands_raw, (WORK/'commands.jsonl').read_bytes())
    helper_pins = {name: sha(WORK/name) for name in ('prepare_delivery.py', 'freeze_delivery.py', 'verify_delivery.py', 'complete_pass.py')}
    projections = []
    for path in evidence.rglob('*'):
        if not path.is_file() or path.suffix not in TEXT_SUFFIXES:
            continue
        for prefix, replacement in PROJECTIONS:
            data = path.read_bytes()
            if prefix in data:
                assert replacement not in data
                path.write_bytes(data.replace(prefix, replacement))
                projections.append({'path': str(path.relative_to(OUT)), 'original_sha256': hashlib.sha256(data).hexdigest(),
                    'portable_sha256': sha(path), 'replacements': data.count(prefix), 'source_prefix_hex': prefix.hex(),
                    'replacement': replacement.decode(), 'scope': 'Archive-only machine-directory projection; local raw bytes unchanged.'})
    save(OUT/'portable_path_projections.json', projections)
    save(OUT/'excluded_evidence.json', omitted)
    with (OUT/'coupled-emission-windows.patch').open('wb') as stream:
        subprocess.run(['git', 'diff', '--binary', BASE, head], cwd=REPO, stdout=stream, check=True)
    verification = {'schema': 'mitl-coupled-emission-windows-verification-v1',
        'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'source_commit': head, 'base_commit': BASE, 'input_contract': configured_inputs,
        'dependency_context': context, 'package_kind': 'patch_over_exact_complete_baseline',
        'results': contract['results'], 'records': records, 'record_paths': REPORT_PATHS,
        'source_version_relationships': contract['source_version_relationships'],
        'record_sha256': {key: sha(WORK/name) for key, name in REPORT_PATHS.items()},
        'allowed_figure_paths': allowed_figures, 'copied_input_sha256': copied_inputs,
        'public_files_byte_identical': len(PUBLIC), 'packaging_wrappers': len(WRAPPERS),
        'commits': subprocess.check_output(['git', 'log', '--reverse', '--format=%H %s', BASE+'..'+head], cwd=REPO, text=True).splitlines(),
        'source_helper_sha256': helper_pins,
        'command_snapshot': {**snapshot, 'path': 'evidence/commands.jsonl',
            'copied_root_files': sorted(copied_root_files),
            'later_local_completion_repairs_may_exist': True,
            'historical_helper_policy': 'Archive helper bytes are immutable historical snapshots; later local repairs must explicitly bind them and preserve the initial failure.'},
        'next_task': next_task,
        'limits': ['Manufactured saved constant-power coupled source windows only; original source/acceptance and new interpolation/query evidence remain separate.',
            'Full joint time/state/temperature mixtures and time-temperature covariance remain distinct from marginal means.',
            'Unavailable source-knot channels remain unavailable; no physical source-budget or host acceptance is inferred.',
            'No source evolution, source RHS evaluation, width assembly, old grid or old suite is repeated by the new interface.',
            'Fresh independent queries test new off-knot moments with declared approximation and source-error layers; no error certificate or physical uncertainty is supplied.',
            'Replaying the fresh oracle requires the separately pinned 0710 archive containing six original 80/120-digit seed checkpoint files; those old bytes are not duplicated here.',
            'Five-file patch requires the exact complete baseline. No standalone package, initializer workaround or portable execution is claimed.']}
    save(OUT/'verification.json', verification)
    save(OUT/'next_task.json', {'task': next_task, 'selection_evidence': 'evidence/'+REPORT_PATHS['selection']})
    (OUT/'systems-mitl-coupled-emission-windows-10192026.md').write_text(f'''# Manufactured saved coupled-emission windows

Five public files are byte-identical to `{head}`. Apply the patch over the
complete checkout at `{BASE}`. README/requirements are wrappers; no initializer
replacement, standalone package or portable execution is claimed.

The interface exports windows of accepted saved constant-power coupled histories.
Original source histories, numerical code/report and their acceptance remain
separate from new interpolation algebra, window quantities and independent
fresh moment queries. Unique source/window pairs, repeated patch references,
aggregates and signed comparisons retain separate counters. Full time/state/
temperature mixtures and mandatory time-temperature covariance are preserved;
unavailable source-knot channels do not become fabricated budgets.

No source evolution, source RHS calculation, width assembly, old source grid or
old suite is replayed. New independent moment queries retain their own seed,
precision, quadrature and query counts. No physical material/water/monolayer,
observed spectrum, velocity launch, field, gap, FLASH or host validation is
supplied. Finite numerical changes are estimates, not certified error bounds or
physical uncertainty.

Commands form an immutable complete-record byte prefix; later verification and
completion commands may append. Archived helper hashes are historical snapshots;
any later local repair must preserve its initial failure and bind that archived
hash. Reversible machine-directory projections leave raw local evidence unchanged.
Assembly runs no scientific model, test suite or portable environment.

All 12 raw export inputs and all new independent query outputs are included.
Replaying the fresh oracle additionally requires the separately pinned 0710
archive with its six original 80-digit and 120-digit seed checkpoint files.
dependency_context.json and the preserved before-plan freeze record give the
archive path/hash, exact member prefix and every seed filename/hash. Those old
seed bytes are not duplicated in this audit packet.

Next selected task: {next_task}
''')
    manifest = {str(path.relative_to(OUT)): sha(path) for path in OUT.rglob('*') if path.is_file() and path.name != 'manifest.sha256.json'}
    save(OUT/'manifest.sha256.json', manifest)
    words = [bytes.fromhex(value).decode() for value in ('6f70656e6169', '63686174677074', '636c61756465', '636f646578')]
    prohibited = re.compile(r'\b(?:'+'|'.join(words)+r')\b', re.I)
    allowed_archive_figures = {'evidence/'+name for name in allowed_figures}
    for path in OUT.rglob('*'):
        assert not path.is_symlink()
        if path.is_file():
            assert not excluded(path.relative_to(OUT), allowed_archive_figures)
            if path.suffix in TEXT_SUFFIXES:
                assert not prohibited.search(path.read_text()), str(path)
    clean_head(head)
    assert all(sha(REPO/name) == preparation['public_source_sha256'][name] for name in PUBLIC)
    assert all(sha(Path(item['source'])) == item['sha256'] for item in copied_inputs)
    assert all(sha(WORK/item['path']) == item['sha256'] for item in omitted)
    assert all(sha(WORK/name) == digest for name, digest in helper_pins.items())
    command_snapshot_prefix(commands_raw, (WORK/'commands.jsonl').read_bytes())
    archive = OUT.with_suffix('.tar.gz')
    with tarfile.open(archive, 'w:gz') as tar:
        tar.add(OUT, arcname=OUT.name)
    record = {'folder': str(OUT), 'archive': str(archive), 'sha256': sha(archive), 'bytes': archive.stat().st_size,
        'source_commit': head, 'base_commit': BASE, 'manifest_entries': len(manifest),
        'public_files_byte_identical': len(PUBLIC), 'packaging_wrappers': len(WRAPPERS),
        'manifest_sha256': sha(OUT/'manifest.sha256.json'), 'verification_sha256': sha(OUT/'verification.json')}
    save(WORK/'frozen_delivery.json', record)
    print(json.dumps(record, indent=2))


if __name__ == '__main__':
    main()
