"""Prepare an unexecuted root-only metadata completion helper for the new pass."""
import hashlib
import json
from pathlib import Path

WORK = Path(__file__).resolve().parent.parent
PRIOR = WORK.parent / 'mitl-upstream-20261019T0710/complete_pass.py'
source = PRIOR.read_text()
prefix = source.split('def main():', 1)[0]
replacements = {
    'Root-owned metadata completion of the manufactured matched width reference.': 'Root-owned metadata completion of manufactured saved coupled-emission windows.',
    'mitl-width-power-20261019T0710': 'mitl-coupled-windows-20261019T0737',
    "BASE='3bd20e44ba617cca44cbac2df993e1face2ec221'": "BASE='df8eb7026b3a712bf641cbb4d136c497e8af50ba'",
    'mhdlab/thermal_width_power_reference.py': 'mhdlab/coupled_emission_windows.py',
    'tests/test_thermal_width_power_reference.py': 'tests/test_coupled_emission_windows.py',
    'tools/run_thermal_width_power_reference.py': 'tools/export_coupled_emission_windows.py',
    'configs/thermal_width_power_manufactured.json': 'configs/coupled_emission_windows_manufactured.json',
    'docs/thermal_width_power_reference.md': 'docs/coupled_emission_windows.md',
    'mitl-width-power-reference-verification-v1': 'mitl-coupled-emission-windows-verification-v1',
    'width-power-reference.patch': 'coupled-emission-windows.patch',
}
for old, new in replacements.items():
    assert old in prefix, old
    prefix = prefix.replace(old, new)
body = '''def main():
    contract_path=WORK/'completion-preparation/contract.json';contract=load(contract_path)
    require(contract['schema']=='mitl-coupled-window-completion-contract-v1'
        and contract['ready_for_root_execution'] is True and contract['pending']==[],'completion contract is pending')
    require(set(contract['public_source_sha256'])==PUBLIC and set(contract['record_paths'])==set(contract['record_sha256']),'contract scope changed')
    for mapping in ['public_source_sha256','metadata_helpers_sha256','record_sha256']:
        require(all(type(value) is str and re.fullmatch('[0-9a-f]{64}',value) for value in contract[mapping].values()),'final byte pins are pending')
    status_path=WORK.parent/'mitl-upstream-status.json'
    with (WORK.parent/'mitl-upstream-status.lock').open('a+') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        before=status_path.read_bytes();status=json.loads(before);lease=load(WORK/'lease.json')
        now=datetime.datetime.now(datetime.timezone.utc)
        require(status['active_lease_owner']==lease['pass_id']==WORK.name
            and datetime.datetime.fromisoformat(status['active_editing_lease_until_utc'])>now,'lease changed or expired')
        require(status['last_complete_commit']==lease['baseline_commit']==BASE and status['handoff']==lease['prior_handoff']
            and not (WORK/'completion.json').exists(),'prior checkpoint changed or completion replay attempted')
        remaining=[json.loads(json.dumps(item)) for item in status['next_work'] if 2<=item['priority']<=7]
        require([item['priority'] for item in remaining]==[2,3,4,5,6,7],'prior queue priorities changed')
        changed={'last_complete_commit','last_completed_pass_id','last_update_utc','handoff','handoff_sha256','handoff_bytes','handoff_document',
            'active_lease_owner','active_editing_lease_until_utc','reserved_paths','active_completed_subtasks','active_phase',
            'last_verified_suite','next_work','verification_history','prior_handoffs','completed_milestones','manufactured_coupled_emission_windows'}
        preserved=json.loads(json.dumps({key:value for key,value in status.items() if key not in changed}))
        head=clean_head(contract);delivery,verification,archive_hashes,commands=verify_archive(contract)
        records=verify_metadata(contract,verification,archive_hashes)
        clean_head(contract);now=datetime.datetime.now(datetime.timezone.utc)
        require(datetime.datetime.fromisoformat(status['active_editing_lease_until_utc'])>now,'lease expired during verification')
        history=status.setdefault('verification_history',[]);prior=status.setdefault('prior_handoffs',[])
        if status['handoff'] not in prior:
            prior.append(status['handoff'])
        if not any(item['pass_id']==status['last_completed_pass_id'] for item in history):
            history.append({'pass_id':status['last_completed_pass_id'],'commit':status['last_complete_commit'],
                'handoff':status['handoff'],'handoff_sha256':status['handoff_sha256'],'verification':status['last_verified_suite']})
        selection=records['selection']
        status.update(last_complete_commit=head,last_completed_pass_id=WORK.name,last_update_utc=now.isoformat(),
            handoff=delivery['archive'],handoff_sha256=delivery['sha256'],handoff_bytes=delivery['bytes'],
            handoff_document=str(OUT/'systems-mitl-coupled-emission-windows-10192026.md'),active_lease_owner=None,
            active_editing_lease_until_utc=None,reserved_paths=[],active_completed_subtasks=[],
            active_phase='Completed manufactured saved coupled-source emission windows; next bounded upstream task selected')
        status['last_verified_suite']={**verification['results'],
            'scope':'New exact positive polynomial windows of accepted saved source data;50 algebra/admission tests and independent fresh query references. No source evolution, source RHS, old assembly or old-grid replay',
            'verification_record':str(OUT/'verification.json'),'delivery_manifest_entries':delivery['manifest_entries'],
            'public_files_byte_identical':5,'packaging_wrappers':2,'post_freeze_commands':str(WORK/'commands.jsonl'),
            'commands_snapshot_qualification':commands}
        status['manufactured_coupled_emission_windows']={'parameter_status':'manufactured',
            'interface':str(REPO/'mhdlab/coupled_emission_windows.py'),
            'public_source_sha256':contract['public_source_sha256'],'results':verification['results'],
            'record_paths':{role:str(WORK/name) for role,name in contract['record_paths'].items()},'record_sha256':contract['record_sha256'],
            'source_history_feedback_installed':False,'full_joint_time_temperature_mixture_retained':True,
            'mandatory_local_time_temperature_moment_and_covariance_retained':True,
            'source_energy_defect_repaired':False,'off_knot_source_channel_interpolation_invented':False,
            'source_evolutions_by_interface':0,'source_RHS_calls_by_interface':0,'old_width_assembly_calls':0,
            'tests_use_manufactured_polynomial_fixtures_only':True,'original_source_acceptance_retained_separately':True,
            'interval_certification_claimed':False,'physical_parameters_adopted':0,'host_budget_accepted':False,
            'owner_implementation_verified':False,'actual_flash_run':False,
            'physical_water_material_or_surface_parameters_validated':False,'physical_spectra_calculated':False,
            'species_velocity_launch_supplied':False,
            'limits':'Manufactured positive cubic representations of accepted saved constant-power sources only. Exact represented polynomial moments do not make the interpolant an exact ODE trajectory. Original source RK quantities and acceptance, new algebra, independent fresh query approximations and projection errors remain separate. No physical water/material, observed spectra, velocity launch, gap transport, Hall coupling, FLASH or owner acceptance is supplied.'}
        status['next_work']=[{'priority':1,'task':selection['selected_task'],
            'selection':str(WORK/contract['record_paths']['selection']),'selection_sha256':contract['record_sha256']['selection'],
            'limits':'Follow the fresh bounded selection; all actual surface, VUV, owner, FLASH and full-text gates remain in force. The separate manufactured numerical reference adopts no physical parameters.'}]+remaining
        require(status['next_work'][1:]==remaining and all(status[key]==value for key,value in preserved.items()),'earlier evidence,gates or queue changed')
        status['completed_milestones'].extend([
            'A new saved-source window interface preserves positive emitted-number measures, full local-time/temperature moments and mandatory time-temperature covariance. Translation, binding, internal and signed input/thermal/source defects remain separate without normalization or repair.',
            'All50 new algebra/admission controls passed once using explicitly manufactured polynomial and invalid-byte fixtures. Original48test/plan bytes were preserved unexecuted before two parser-specific controls were added; no scalar source evolution, RHS, old assembly or earlier suite was repeated.',
            f'Five public files through {head[:7]} and actual archive {delivery["sha256"]} require the complete df8eb702 baseline. Fresh query references remain separate from source trajectory accuracy; no physical inference, standalone package or portable execution is claimed.'
        ])
        history.append({'pass_id':WORK.name,'commit':head,'handoff':delivery['archive'],'handoff_sha256':delivery['sha256'],'verification':status['last_verified_suite']})
        encoded=(json.dumps(status,indent=2,allow_nan=False)+'\\n').encode()
        result={'utc':now.isoformat(),'event':'completed_and_next_selected','pass_id':WORK.name,'commit':head,
            'archive':delivery['archive'],'archive_sha256':delivery['sha256'],'archive_bytes':delivery['bytes'],
            'actual_archive_reverified':True,'public_scope_sha256':contract['public_source_sha256'],
            'completion_contract_sha256':sha(contract_path),'record_sha256':contract['record_sha256'],
            'manufactured_coupled_emission_windows_qualified':True,'interval_certification_claimed':False,
            'physical_parameters_adopted':0,'host_budget_accepted':False,'owner_implementation_verified':False,'actual_flash_run':False,
            'source_recovery_or_scientific_checks_reexecuted':False,'portable_execution_performed':False,
            'command_snapshot_qualification':commands,'exact_commands':str(WORK/'commands.jsonl'),
            'status_before_sha256':hashlib.sha256(before).hexdigest(),'status_after_sha256':hashlib.sha256(encoded).hexdigest(),
            'lease_released':True,'reserved_paths':[],'next':selection['selected_task'],
            'next_selection_sha256':contract['record_sha256']['selection']}
        require(not (WORK/'status-before-completion.json').exists(),'prior completion snapshot exists')
        (WORK/'status-before-completion.json').write_bytes(before)
        atomic_write(status_path,encoded)
        atomic_write(WORK/'completion.json',(json.dumps(result,indent=2,allow_nan=False)+'\\n').encode())
        with (WORK.parent/'mitl-upstream-journal.jsonl').open('a') as stream:
            stream.write(json.dumps(result,allow_nan=False)+'\\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':
    main()
'''
target = WORK / 'complete_pass.py'
assert not target.exists()
target.write_text(prefix + body)
record = {'schema': 'mitl-coupled-window-completion-draft-v1',
          'status': 'draft_unexecuted_pending_final_roles_results_HEAD_and_delivery',
          'source_template': str(PRIOR), 'source_template_sha256': hashlib.sha256(PRIOR.read_bytes()).hexdigest(),
          'draft_sha256': hashlib.sha256(target.read_bytes()).hexdigest(),
          'status_mutation_executed': False, 'helper_imported_or_executed': False,
          'science_or_old_suite_calls': 0,
          'remaining_gates': ['actual complete producer and independent query records', 'root documentation/selection and approved clean HEAD',
                              'final pure delivery helper roles/results/byte pins', 'one AST/data-pin readiness check',
                              'root-only actual archive freeze and verification before completion']}
(WORK / 'completion-preparation/draft-notes.json').write_text(json.dumps(record, indent=2, sort_keys=True) + '\n')
print(json.dumps(record, sort_keys=True))
