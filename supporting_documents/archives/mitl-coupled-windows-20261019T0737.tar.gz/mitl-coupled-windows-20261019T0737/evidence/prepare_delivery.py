"""Prepare a five-file saved coupled-window patch over an exact complete checkout."""
import argparse
import ast
from decimal import Decimal
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path
import re
import shutil
import subprocess

WORK = Path(__file__).resolve().parent
REPO = Path('/workspace/Power-Flow')
BASE = 'df8eb7026b3a712bf641cbb4d136c497e8af50ba'
HEAD = 'ea82ae3094ae480cb9c370652fa1eb1c677d8de5'
OUT = Path('/workspace/handoffs/mitl-coupled-windows-20261019T0737')
PUBLIC = ('mhdlab/coupled_emission_windows.py', 'tests/test_coupled_emission_windows.py',
    'tools/export_coupled_emission_windows.py', 'configs/coupled_emission_windows_manufactured.json',
    'docs/coupled_emission_windows.md')
WRAPPERS = ('README.md', 'requirements.txt')
BASELINE_CONTEXT = ('requirements.txt', 'pyproject.toml', 'mhdlab/__init__.py', 'mhdlab/thermal_feedback_reference.py', 'mhdlab/thermal_power_reference.py', 'mhdlab/thermal_forced_feedback_reference.py', 'mhdlab/thermal_width_power_reference.py', 'tools/run_thermal_width_power_reference.py')


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024*1024), b''):
            digest.update(block)
    return digest.hexdigest()


def object_pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('duplicate JSON key')
        result[key] = value
    return result


def finite_float(value):
    result = float(value)
    if not math.isfinite(result):
        raise ValueError('nonfinite JSON number')
    if result == 0 and Decimal(value) != 0:
        raise ValueError('nonzero JSON number underflows its representation')
    return result


def loads(data):
    return json.loads(data, object_pairs_hook=object_pairs, parse_float=finite_float,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def load(path):
    return loads(Path(path).read_text())


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False)+'\n')


def baseline_bytes(name):
    return subprocess.check_output(['git', 'show', BASE+':'+name], cwd=REPO)


def clean_head(expected):
    assert HEAD is not None and re.fullmatch('[0-9a-f]{40}', expected) and expected == HEAD
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == expected
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=REPO, text=True).strip()
    subprocess.run(['git', 'merge-base', '--is-ancestor', BASE, expected], cwd=REPO, check=True)
    changed = subprocess.check_output(['git', 'diff', '--name-only', BASE, expected], cwd=REPO, text=True).splitlines()
    assert set(changed) == set(PUBLIC) and len(changed) == len(PUBLIC)
    return expected


def dependency_context():
    pins = {}
    for name in BASELINE_CONTEXT:
        content = baseline_bytes(name)
        digest = hashlib.sha256(content).hexdigest()
        assert sha(REPO/name) == digest
        pins[name] = digest
    imports = {}
    for name in PUBLIC:
        if not name.endswith('.py'):
            continue
        tree = ast.parse((REPO/name).read_text())
        imports[name] = sorted({node.module or '' for node in ast.walk(tree) if isinstance(node, ast.ImportFrom)}
            | {alias.name for node in ast.walk(tree) if isinstance(node, ast.Import) for alias in node.names})
    lease = load(WORK/'lease.json')
    seed_manifest = load(WORK/'independent-verification/before_plan_freeze.json')
    seed_hashes = seed_manifest['accepted_seed_checkpoint_sha256']
    assert len(seed_hashes) == 6 and all(re.fullmatch('[0-9a-f]{64}', value) for value in seed_hashes.values())
    assert lease['prior_handoff'] == '/workspace/handoffs/mitl-width-power-20261019T0710.tar.gz'
    assert lease['prior_handoff_sha256'] == '571dad5b7316d78eecae911ae592df97ef7c16cf1feffaa24ac12607f50867dd'
    return {'required_complete_baseline_checkout': True, 'baseline_commit': BASE,
        'standalone_source_subset': False, 'empty_initializer_added': False,
        'unchanged_context_sha256': pins, 'declared_imports': imports,
        'accepted_saved_data_schema_context': ['mhdlab/thermal_forced_feedback_reference.py', 'mhdlab/thermal_width_power_reference.py'],
        'unchanged_record_dependencies': ['mhdlab/thermal_feedback_reference.py', 'mhdlab/thermal_power_reference.py'],
        'dependency_qualification': 'Accepted saved data and its original code/acceptance lineage are inputs; no source evolution, RHS evaluation or width assembly is replayed.',
        'accepted_reference_seed_data': {'prior_archive': lease['prior_handoff'],
            'prior_archive_sha256': lease['prior_handoff_sha256'], 'own_precision_levels': [80, 120],
            'seed_checkpoint_sha256': seed_hashes,
            'seed_member_prefix': 'mitl-width-power-20261019T0710/evidence/independent-verification/oracle-initial/',
            'seed_hash_manifest_evidence': 'evidence/independent-verification/before_plan_freeze.json',
            'original_seed_bytes_copied_into_current_packet': False,
            'prior_archive_required_for_fresh_oracle_rerun': True,
            'qualification': 'The saved-data export has its12 raw input copies. Replaying the fresh oracle additionally requires the separately pinned accepted seed archive; original seed files are not duplicated here.'},
        'requirements_wrapper_origin': 'Exact bytes of baseline requirements.txt; complete checkout setup remains required.'}


def input_contract():
    """Bind saved-source/window declarations without loading a model."""
    name = 'configs/coupled_emission_windows_manufactured.json'
    config = load(REPO/name)
    assert config['schema'] == 'mhdlab-coupled-emission-windows-manufactured-config-v1'
    assert config['parameter_status'] == 'manufactured'
    assert isinstance(config['provenance'], str) and config['provenance'].strip()
    assert isinstance(config['scope'], str) and config['scope'].strip()
    binding = config['source_binding']
    assert binding['path_base'] == '--source-dir is the accepted0710 pass directory'
    assert set(binding['files']) == {'report', 'assembly', 'input_config', 'reuse_map', 'uniform_power',
        'edge_power', 'middle_power', 'independent_completion', 'independent_report', 'scientific_review'}
    for record in list(binding['files'].values())+list(binding['lineage']['auxiliary_files'].values()):
        path = Path(record['relative_path'])
        assert not path.is_absolute() and '..' not in path.parts and re.fullmatch('[0-9a-f]{64}', record['sha256'])
    assert binding['files']['report']['sha256'] == '21031ac2ef2f1a59bff3ed2afa3efbf7de6b984a4b09fe7d64f0ad5ba2e44cd7'
    assert binding['files']['independent_completion']['sha256'] == 'b1e463a848e5fe6bf759e05d7b8016edfd3d8db12b0a0698ecfb8f8ce2245086'
    assert binding['files']['independent_report']['sha256'] == '5a0b0cfce3fa594376718579645b8ee424bf80b6de0ac5ade0eeab829fc3d84c'
    assert binding['files']['scientific_review']['sha256'] == 'd2a42ce4fb5abb29f9ac358691f7373a1f089cac4a33108a960a2931590a0b39'
    lineage = binding['lineage']
    assert lineage['numerical_run_cli_sha256'] == binding['numerical_run_code_sha256']['tools/run_thermal_width_power_reference.py']
    assert lineage['plot_only_public_cli_sha256'] == sha(REPO/'tools/run_thermal_width_power_reference.py')
    assert lineage['numerical_run_cli_sha256'] != lineage['plot_only_public_cli_sha256']
    assert set(binding['canonical_history_sha256']) == {'uniform_power', 'edge_power', 'middle_power'}
    queries = config['queries']
    assert len(queries) == 3 and len({item['window_id'] for item in queries}) == 3
    for item in queries:
        assert isinstance(item['window_id'], str) and item['window_id'].strip()
        assert item['coordinate'] == 'canonical_duration_fraction' and item['parameter_provenance'].strip()
        fractions = []
        for key in ('start_fraction', 'stop_fraction'):
            record = item[key]
            assert set(record) == {'numerator', 'denominator'}
            assert all(isinstance(record[part], str) and re.fullmatch('0|[1-9][0-9]*', record[part])
                       for part in ('numerator', 'denominator'))
            value = Fraction(int(record['numerator']), int(record['denominator']))
            assert str(value.numerator) == record['numerator'] and str(value.denominator) == record['denominator']
            fractions.append(value)
        assert 0 <= fractions[0] < fractions[1] <= 1
    quantity = config['quantity_contract']
    assert quantity['local_time_anchor'] == 'exact_window_start'
    assert quantity['joint_local_time_temperature_moment_required'] is True
    assert quantity['source_RK_channel_comparison'] == 'available_only_when_both_bounds_are_source_knots'
    assert quantity['time_temperature_mixture'] == 'full_coefficients_and_joint_moments_retained'
    counts = config['declared_counts']
    assert all(type(value) is int for value in counts.values())
    assert counts == {'unique_source_window_calculations': 9, 'patch_window_references': 18,
        'hypothesis_window_aggregates': 6, 'nonuniform_minus_uniform_contrasts': 3,
        'source_evolution_RHS_assembly_calls': 0}
    return {'config_path': name, 'config_sha256': sha(REPO/name), 'configuration': config,
        'parameter_status': 'manufactured', 'declared_counts': counts,
        'accepted_source_binding': binding, 'original_source_and_acceptance_are_inputs': True,
        'joint_time_temperature_covariance_required': True,
        'source_knot_channel_availability_explicit': True,
        'physical_parameters_adopted': False, 'source_RHS_assembly_reexecution_admitted': False,
        'host_or_production_feedback_installed': False}


def command_snapshot_prefix(snapshot, live):
    """Accept only an immutable newline-terminated prefix of complete JSONL records."""
    assert snapshot and snapshot.endswith(b'\n') and live.startswith(snapshot)
    assert all(isinstance(loads(line), dict) for line in snapshot.splitlines())
    return {'sha256': hashlib.sha256(snapshot).hexdigest(), 'bytes': len(snapshot),
        'complete_records': len(snapshot.splitlines()),
        'qualification': 'Exact complete-record byte prefix; later verification/completion records may append.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--expected-head', required=True)
    args = parser.parse_args()
    head = clean_head(args.expected_head)
    for name in PUBLIC:
        assert (REPO/name).is_file() and not (REPO/name).is_symlink()
    context = dependency_context()
    contract = input_contract()
    payload = WORK/'delivery-preparation/payload'
    assert not payload.exists() and not OUT.exists() and not OUT.with_suffix('.tar.gz').exists()
    source = payload/'source'
    source.mkdir(parents=True)
    for name in PUBLIC:
        target = source/name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(REPO/name, target)
    (source/'requirements.txt').write_bytes(baseline_bytes('requirements.txt'))
    (source/'README.md').write_text(f'''# Manufactured saved coupled-emission window patch

Five new public files and a patch are pinned to the approved checkout. Apply the
patch to the complete baseline at `{BASE}` before importing, exporting or testing
this reference. This source/ review subset is not a standalone package. No
initializer replacement or portable execution is supplied. The requirements
wrapper copies baseline requirements.txt byte-for-byte; retain the complete
checkout setup and initializer.

Replaying the independent fresh queries additionally requires the accepted
0710 archive pinned in dependency_context.json. Its six original 80-digit and
120-digit seed
checkpoints are referenced by exact names and hashes; their bytes are not
duplicated here. The saved-data export's 12 raw inputs and all new query outputs
are included. This audit packet does not claim a standalone oracle rerunner.

The interface conditions accepted saved constant-power coupled histories on
explicit windows and retains number, time, temperature and energy association.
Unique source/window pairs remain distinct from repeated patch references and
whole-face aggregate/difference records. Joint time-temperature covariance and
channel availability remain explicit; an unavailable source-knot channel must
not become a fabricated zero or an inferred source budget.

The original source, numerical report, code versions and acceptance records are
separate inputs. New adapter tests, parser controls, a saved-data export and
fresh independent off-knot queries retain separate counters. Source evolution,
RHS evaluation, width assembly, old grids and old suites are not replayed. This
is a manufactured upstream interface, with no physical material/water/monolayer,
spectral, field, particle launch, gap, FLASH or host validation.
''')
    save(payload/'source_file_list.json', {'byte_identical_public_files': list(PUBLIC), 'packaging_wrappers': list(WRAPPERS)})
    (payload/'source-files.sha256').write_text(''.join(f'{sha(source/name)}  {name}\n' for name in PUBLIC))
    (payload/'wrapper-files.sha256').write_text(''.join(f'{sha(source/name)}  {name}\n' for name in WRAPPERS))
    save(payload/'dependency_context.json', context)
    save(payload/'preparation.json', {'source_commit': head, 'base_commit': BASE,
        'input_contract': contract, 'dependency_context': context,
        'portable_execution_performed': False, 'physical_truth_validated': False,
        'public_source_sha256': {name: sha(REPO/name) for name in PUBLIC}})
    print(json.dumps({'payload': str(payload), 'source_commit': head, 'public_files': len(PUBLIC),
        'packaging_wrappers': len(WRAPPERS), 'complete_baseline_checkout_required': True}, indent=2))


if __name__ == '__main__':
    main()
