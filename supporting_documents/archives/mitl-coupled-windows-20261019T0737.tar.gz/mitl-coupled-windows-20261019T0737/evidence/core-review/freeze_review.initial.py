"""Metadata-only frozen-source review association; no scientific imports/calls."""
import ast
import datetime
import hashlib
import json
from pathlib import Path

WORK = Path('/workspace/research_work/mitl-upstream-20261019T0737')
OLD = Path('/workspace/research_work/mitl-upstream-20261019T0710')
OUT = WORK / 'core-review'
SOURCE = Path('/workspace/Power-Flow/mhdlab/coupled_emission_windows.py')
PIN = '8a235ed92c0e40ccd43375fcd4d6c6beee05fd460b9fbf15102610c338eba786'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def load(path):
    return json.loads(path.read_text())

status = load(Path('/workspace/research_work/mitl-upstream-status.json'))
assert '0737' in json.dumps(status['active_lease'])
assert sha(SOURCE) == PIN
freeze = load(WORK/'core/source-freeze.json')
assert freeze['source']['sha256'] == PIN
assert sha(Path(freeze['snapshot']['path'])) == PIN
tree = ast.parse(SOURCE.read_text())
vector = next(ast.literal_eval(node.value) for node in tree.body if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == '_SOURCE_CODE_SHA256' for target in node.targets))
config = load(WORK/'independent-verification/input_config.json')
binding = config['source_binding']
assert len(binding) == 10
paths = {alias: OLD / item['path'] for alias, item in binding.items()}
for alias, path in paths.items():
    assert sha(path) == binding[alias]['sha256'], alias
docs = {key: load(path) for key, path in paths.items()}
report, independent, reference, review = (docs[key] for key in ('report', 'independent_completion', 'independent_report', 'scientific_review'))
assert report['schema'] == 'mhdlab-thermal-width-power-reference-run-v1'
assert report['status'] == 'manufactured_reference_only'
assert report['code_sha256'] == vector
assert independent['schema'] == 'mitl-independent-width-power-completion-v1'
assert independent['status'] == reference['status'] == 'passed'
assert independent['all_checks_passed'] is reference['all_checks_passed'] is True
assert independent['report_sha256'] == binding['independent_report']['sha256']
assert independent['producer_report_sha256'] == binding['report']['sha256']
assert review['schema'] == 'mitl-width-power-static-oracle-review-v1'
assert review['status'] == 'accepted'
assert review['further_changes_requested'] is False
assert review['owner_report_sha256'] == binding['independent_report']['sha256']
assert review['actual_report_sha256'] == binding['independent_report']['sha256']
assert review['completed_report_bound_without_numerical_replay'] is True
assert all(item['status'] == 'repaired_before_first_reference' for item in review['findings'])
counts = {'new_scalar_cases':3,'unique_scalar_reference_samples':195,'unique_scalar_flux_references':195,
          'expanded_patch_samples_checked':390,'aggregate_samples_checked':130,'difference_samples_checked':65,
          'post_source_cache_records_verified':195,'independent_RHS_field_comparisons':1560,
          'new_independent_oracle_runs':1,'old_case_or_oracle_runs':0}
assert all(type(independent.get(key)) is int and independent[key] == count for key,count in counts.items())
assert independent['producer_imports_or_calls'] == []
for key in ('all_eight_RHS_fields_checked','exact_area_and_power_identity_verified','full_patch_mixtures_preserved'):
    assert independent[key] is True
assert independent['dense_Taylor_coefficients_or_off_knot_queries_retained'] is False
assert all(binding[key]['sha256'] in reference['input_sha256'].values() for key in ('report','assembly','input_config'))
for alias, filename in {'assembly':'width_assembly.json','input_config':'input_config.json','reuse_map':'reuse_map.json',**{name:name+'.json' for name in ('uniform_power','edge_power','middle_power')}}.items():
    assert report['artifact_sha256'][filename] == binding[alias]['sha256']
assert report['assembly_sha256'] == binding['assembly']['sha256']
assert report['config_sha256'] == binding['input_config']['sha256']

notes = '''Frozen-source mathematical/interface review

The source admission checks externally supplied raw-byte hashes before parsing and binds the actual accepted independent report and final scientific review. The hardcoded schema, status, finding-status, association field names, counts and executed scientific code vector were compared to the ten hash-pinned 0710 source/acceptance files using metadata only. The scientific review's reviewed_source_sha256 denotes its independent verifier; the production numerical vector is correctly bound separately from the source report. Plot-only later CLI bytes are not substituted for the executed scientific source.

The strict JSON parser rejects duplicate keys, nonfinite values, nonzero decimal tokens that project to zero, raw integer -0 and floating negative zero. Exact rational records are canonical and bit bounded; nonzero output underflow/overflow rejects. Generic exact cell support uses local-time moments, and does not assert that a large absolute origin has distinct binary64 timestamps.

Static inspection finds the de Casteljau restriction and Bernstein product integrals consistent. Restricted derivative controls already contain the restricted measure scale, so no extra cell duration is applied. All six moments include the mandatory joint local-time/temperature moment. One common window anchor is used across pieces; covariance and variances are formed from exact raw moments and validated without clipping. A positive measure with zero variance remains available; only exact zero mass makes normalized statistics unavailable.

Endpoint source N, independently accumulated M and scalar residuals remain referenced source data. Full RHS powers are bound as accepted cached data, rather than reconstructed from separately rounded Gamma. Constant-power sources, complete logical time grids, common states/costs/unit reference area, exact patch geometry and complete patch areal records are checked. Area is applied once to raw areal moments before aggregate normalization, preserving emitted-mass weighting and joint covariance.

Polynomial thermal/storage/input/debit channels use the declared common energy reference and signs; the activation barrier is not debited. Knot-only source comparisons retain both the unprojected endpoint-state energy residual and rounded source residual deltas. Both displayed decomposition formulas have the correct signs; off-knot source-channel comparisons are explicitly unavailable. No source state or source cumulative channel is repaired to enforce polynomial closure. Polynomial/source discrepancies and new independent query error remain separate.

This is static source/claims review plus metadata association only. It executes no scientific module, source admission, interpolation, rate, old loader, evolution, assembly, test or producer. Finite-precision and physical query accuracy remain for the separately frozen new independent verification. Manufactured independent patches supply no real foil/water/monolayer, launch velocity, lateral conduction, molecular-state, transport, spectra, Hall, FLASH or host/owner validation.
'''
(OUT/'review.md').write_text(notes)
record = {
 'schema':'mitl-coupled-window-static-core-review-v1',
 'status':'review_complete_no_substantive_issue_identified',
 'reviewed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'reviewed_source':str(SOURCE),'reviewed_source_sha256':PIN,
 'source_freeze_sha256':sha(WORK/'core/source-freeze.json'),
 'output_contract_sha256':sha(WORK/'core/output-contract.json'),
 'accepted_oracle_plan_review_sha256':sha(WORK/'oracle-review/plan_review.json'),
 'actual_source_acceptance_metadata_literals_checked':True,
 'source_file_sha256':{key:sha(path) for key,path in paths.items()},
 'source_schema_status_and_association_fields_match':True,
 'mandatory_joint_time_temperature_moment_and_covariance_reviewed':True,
 'exact_restriction_mass_and_area_once_reviewed':True,
 'source_residuals_and_three_defect_layers_preserved':True,
 'raw_numeric_underflow_and_negative_zero_rejection_reviewed':True,
 'findings':[], 'further_changes_requested':False,
 'scientific_module_imported':False,'numerical_models_or_tests_executed':False,
 'source_admission_or_window_calculation_executed':False,'producer_or_oracle_executed':False,
 'old_source_numerical_checks_replayed':False,
 'physical_parameters_validated':False,'host_budget_accepted':False,
 'limits':['Static mathematical/source/interface/claims review and metadata association only.',
           'No interpolation or independent query outcome is computed or asserted by this record.',
           'Manufactured constant-power independent-patch sources only; no physical or host/owner validation.'],
 'artifact_sha256':{'freeze_review.py':sha(Path(__file__)),'review.md':sha(OUT/'review.md')}
}
(OUT/'completion.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'completion':str(OUT/'completion.json'),'sha256':sha(OUT/'completion.json'),'status':record['status']}))
