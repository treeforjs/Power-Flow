# Published current-depth recovery subset

Eight named public files are copied byte-for-byte. This README and the dependency
list are packaging wrappers. The standalone recovery script has no repository
module imports. Packaging does not create a portable environment or execute a
second recovery, inspector, source model or prior test suite.

The four signed interior J_z profiles are reconstructed from the published
legacy Allegra simulation raster in Figs.4.28–4.29 at 40/60 ns. Their CSV files
retain 141 rows per profile. Complete retained/excluded row catalogs, source and
RGB hashes, exact axis calibration, correlated display readout bounds, QA and
independent readback are preserved. Original simulation normalization remains
unverified. SI columns apply only the literal printed-unit conversion. These
data do not establish physical J-squared heating, material boundaries, clock
alignment, experimental validation or a FLASH result.

The full dissertation, raw source pages/images, prospective source-local panels
and acquired fulltexts are omitted. Their recorded hashes and metadata remain.
The original PDF is required for a future deliberate recovery replay. Existing
QA figures are included; archive assembly performs no recovery replay.
