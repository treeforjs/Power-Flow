"""One official access check per new DOI; stop on access blocks, no retries.

No API key, credential injection, proxy override, TLS change or protected route
workaround is attempted. No PDF is requested without an explicit public location.
"""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import datetime,hashlib,json,time,urllib.request,urllib.error

ROOT=Path(__file__).resolve().parent;OUT=ROOT/'source-acquisition'/'locations';RAW=OUT/'raw'
LEADS=[('joly_2000','10.1016/S0042-207X(00)00393-6','https://api.elsevier.com/content/article/PII:S0042207X00003936?httpAccept=text/xml','text/xml','Crossref-provided official TDM endpoint; public availability check without API credentials'),('li_dylla_1995','10.1116/1.579673','https://doi.org/10.1116/1.579673','text/html','Official DOI landing route only; no closed publisher PDF request')]
class RedirectRecorder(urllib.request.HTTPRedirectHandler):
    max_redirections=3;max_repeats=1
    def __init__(self):super().__init__();self.chain=[]
    def redirect_request(self,req,fp,code,msg,headers,newurl):
        self.chain.append({'from_url':req.full_url,'http_status':code,'to_url':newurl})
        return super().redirect_request(req,fp,code,msg,headers,newurl)

def fetch(item):
    lead,doi,url,accept,purpose=item;start=datetime.datetime.now(datetime.timezone.utc).isoformat();t0=time.monotonic()
    headers={};body=b'';status=None;final=url;error=None;redirect=RedirectRecorder()
    opener=urllib.request.build_opener(redirect)
    request=urllib.request.Request(url,headers={'User-Agent':'MITL-source-evidence/1.0','Accept':accept})
    try:
        with opener.open(request,timeout=30) as response:
            status=response.status;final=response.url;headers=dict(response.headers.items());body=response.read(32*1024*1024+1)
    except urllib.error.HTTPError as exc:
        status=exc.code;final=exc.url;headers=dict(exc.headers.items());body=exc.read(32*1024*1024+1);error=type(exc).__name__
    except (urllib.error.URLError,TimeoutError) as exc:
        error=type(exc).__name__+': '+str(exc.reason if isinstance(exc,urllib.error.URLError) else exc)
    if len(body)>32*1024*1024:raise RuntimeError('Bounded official response size exceeded')
    path=RAW/(lead+'_official.response');path.write_bytes(body)
    hp=RAW/(lead+'_official.headers.json');hp.write_text(json.dumps(headers,indent=2)+'\n')
    return {'lead':lead,'doi':doi,'purpose':purpose,'requested_url':url,'method':'GET','request_headers':{'User-Agent':'MITL-source-evidence/1.0','Accept':accept},'started_utc':start,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed_s':time.monotonic()-t0,'http_status':status,'final_url':final,'redirect_chain':redirect.chain,'response_headers':headers,'response_headers_file':str(hp),'response_headers_sha256':hashlib.sha256(hp.read_bytes()).hexdigest(),'actual_bytes':len(body),'sha256':hashlib.sha256(body).hexdigest(),'raw_response_file':str(path),'error':error,'TLS_verification':'default enabled','proxy':'inherited environment; not overridden','retry_count':0,'is_pdf_magic':body.startswith(b'%PDF-'),'full_text_adopted':False,'access_block_stops_this_lead':status in (401,403,407,418,429) or error is not None}

with ThreadPoolExecutor(max_workers=2) as pool:rows=list(pool.map(fetch,LEADS))
report={'schema':'mhdlab-new-primary-official-source-access-v1','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'records':rows,'request_limit':'one logical official publisher access check per DOI; normal DOI redirect recorded; zero retries','explicit_OA_or_repository_fulltext_locations':0,'full_text_acquired':False,'physics_parameters_adopted':False,'raw_files_excluded_from_delivery':True}
(OUT/'official_access_report.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps({'schema':report['schema'],'script_sha256':report['script_sha256'],'records':[{k:row[k] for k in ('lead','requested_url','http_status','final_url','redirect_chain','actual_bytes','sha256','error','is_pdf_magic','access_block_stops_this_lead')} for row in rows],'full_text_acquired':False},indent=2))
