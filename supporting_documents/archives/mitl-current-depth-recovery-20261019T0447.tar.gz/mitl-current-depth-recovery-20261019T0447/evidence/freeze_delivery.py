"""Freeze new current-depth recovery evidence without rerunning recovery."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tarfile

from prepare_delivery import WORK, REPO, BASE, OUT, PDF_SHA256, PUBLIC, WRAPPERS, PRODUCER, clean_head, canonical_hash, dataset_bindings, load, save, sha

TEXT_SUFFIXES = {'.py', '.json', '.jsonl', '.log', '.xml', '.md', '.txt', '.patch', '.sha256', '.yaml', '.csv'}
EVIDENCE_DIRS = ('recovery', 'independent-verification', 'next-upstream-selection', 'source-acquisition')
QA_NAMES = {f'figure_{identifier}_current_depth.{suffix}' for identifier in ('4_28', '4_29') for suffix in ('png', 'pdf')}
SOURCE_METADATA_SUFFIXES = {'.json', '.jsonl', '.py', '.md', '.log', '.sha256'}
EXPECTED_CONTROLS = {'figures': 2, 'profiles': 4, 'retained_rows': 564, 'excluded_rows': 1020,
    'native_rows_catalogued': 1584, 'numeric_csv_cells_checked': 10152, 'tick_anchors_checked': 28,
    'source_guard_rejections': 4, 'guarded_recovery_entry_attempts': 2,
    'successful_producer_replays': 0, 'physical_row_extraction_calls_by_invalid_source_controls': 0}
PROJECTIONS = (
    (bytes.fromhex('2f6f70742f636f6465782f72756e74696d65732f636f6465782d7072696d6172792d72756e74696d652f646570656e64656e636965732f707974686f6e'), b'[runtime Python directory]'),
    (bytes.fromhex('2f6574632f636f6465782f'), b'[runtime policy directory]/'),
)


def excluded(relative):
    path = Path(relative)
    parts = path.parts
    if any(part in {'__pycache__', '.pytest_cache', '.venv', 'source-local', 'fulltexts', 'raw-fulltexts'}
           or part.startswith('pytest_') for part in parts):
        return True
    if path.suffix == '.pyc' or path.name == 'smtrevor_1.pdf':
        return True
    if 'recovery' in parts and path.suffix.lower() in {'.png', '.pdf', '.jpg', '.jpeg', '.tif', '.tiff'}:
        return path.name not in QA_NAMES
    if 'source-acquisition' in parts:
        return 'raw' in parts or path.suffix not in SOURCE_METADATA_SUFFIXES
    return False


def verify_author(datasets):
    author = load(WORK/'recovery/author-verification.json')
    assert author['schema'] == 'mhdlab-current-depth-author-verification-v1' and author['complete'] is True
    assert author['public_source'] == PRODUCER and author['public_source_sha256'] == sha(REPO/PRODUCER)
    assert author['source_PDF_sha256'] == PDF_SHA256 and author['new_producer_run_count'] == 1
    assert author['visual_QA']['both_generated_PNGs_viewed'] is True
    assert author['total_samples'] == 564 and author['total_excluded_rows'] == 1020
    assert len(author['figures']) == len(datasets) == 2
    command = author['new_producer_command']
    assert command['exit_code'] == 0 and sha(Path(command['log'])) == command['log_sha256']
    for record, dataset in zip(author['figures'], datasets):
        assert record['figure'] == dataset['figure'] and record['csv'] == dataset['csv_path']
        assert record['metadata'] == dataset['metadata_path']
        assert record['csv_sha256'] == dataset['csv_sha256'] and record['metadata_sha256'] == dataset['metadata_sha256']
        geometry = WORK/'recovery'/dataset['source_geometry_filename']
        assert Path(record['source_geometry']).resolve() == geometry.resolve()
        assert sha(geometry) == record['source_geometry_sha256'] == dataset['source_geometry_sha256']
        assert record['QA_files_sha256'] == dataset['QA_files_sha256']
        assert canonical_hash(record['calibration']) == dataset['calibration_sha256']
        for name, digest in record['QA_files_sha256'].items():
            assert name in QA_NAMES and sha(WORK/'recovery'/name) == digest
        for name, profile in dataset['profiles'].items():
            assert record['profiles'][name]['samples'] == profile['samples']
            assert record['profiles'][name]['excluded_rows'] == profile['excluded_rows']
    return author


def verify_independent(datasets):
    completion = load(WORK/'independent-verification/completion.json')
    assert completion['schema'] == 'mitl-independent-current-depth-completion-v1'
    assert completion['all_checks_passed'] is True and completion['status'] == 'passed'
    assert all(type(completion[key]) is int and completion[key] == value for key, value in EXPECTED_CONTROLS.items())
    assert completion['old_suites_repeated'] is False
    assert completion['all_retained_signed_negative'] is True and completion['physical_normalization_verified'] is False
    assert completion['original_simulation_output_units_confirmed'] is False and completion['J_squared_heating_inferred'] is False
    expected = {PRODUCER}|{record[key] for record in datasets for key in ('csv_path', 'metadata_path')}
    assert set(completion['public_source_sha256']) == expected
    for name, digest in completion['public_source_sha256'].items():
        assert sha(REPO/name) == digest
    for name, digest in completion['artifact_sha256'].items():
        path = Path(name) if Path(name).is_absolute() else WORK/name
        assert sha(path) == digest
    return completion


def acquisition_record():
    path = WORK/'source-acquisition/metadata_report.json'
    record = load(path)
    assert record['schema'] == 'mitl-new-primary-desorption-doi-metadata-v1'
    assert record['all_target_metadata_verified'] is True
    assert record['surface_grade_verified'] is False and record['physical_rates_or_monolayer_convention_adopted'] is False
    assert {item['lead'] for item in record['records']} == {'joly_2000', 'li_dylla_1995'}
    for item in record['records']:
        assert item['metadata_verified'] is True and sha(Path(item['file'])) == item['sha256']
    return record


def acquisition_access_record():
    record = load(WORK/'source-acquisition/locations/acquisition_state.json')
    assert record['schema'] == 'mhdlab-new-primary-desorption-acquisition-state-v1'
    assert record['status'] == 'metadata_only_fulltext_blocked' and record['full_text_acquired'] is False
    assert record['physical_rate_or_monolayer_or_wall_energy_adopted'] is False
    assert record['request_counts']['retries'] == 0 and record['request_counts']['repository_or_PDF_downloads'] == 0
    assert {item['lead'] for item in record['records']} == {'joly_2000', 'li_dylla_1995'}
    for item in record['records']:
        assert item['full_text_acquired'] is False and item['publisher_auth_requirement_established'] is False
    for name, digest in record['artifact_sha256'].items():
        assert sha(WORK/name) == digest
    return {'schema': record['schema'], 'status': record['status'], 'full_text_acquired': record['full_text_acquired'],
        'physical_rate_or_monolayer_or_wall_energy_adopted': record['physical_rate_or_monolayer_or_wall_energy_adopted'],
        'request_counts': record['request_counts'],
        'records': [{key: item[key] for key in ('lead', 'doi', 'verified_title', 'access_state', 'full_text_acquired', 'publisher_auth_requirement_established')}
                    for item in record['records']]}


def documentation_record(datasets):
    record = load(WORK/'documentation-association.json')
    assert record['schema'] == 'mitl-current-depth-documentation-association-v1' and record['passed'] is True
    assert record['prior_manifest_targets'] == 45 and record['all_prior_artifacts_preserved'] is True
    assert record['source_record_unchanged'] is True and record['original_normalization_verified'] is False
    assert record['actual_flash_run'] is False and record['old_recoveries_repeated'] is False
    for name, digest in record['after_sha256'].items():
        assert name in PUBLIC and sha(REPO/name) == digest
    for item, dataset in zip(record['datasets'], datasets):
        assert item['figure'] == dataset['figure'] and item['csv_sha256'] == dataset['csv_sha256']
        assert item['metadata_sha256'] == dataset['metadata_sha256']
    return record


def main():
    payload = WORK/'delivery-preparation/payload'
    preparation = load(payload/'preparation.json')
    head = clean_head(preparation['source_commit'])
    assert preparation['base_commit'] == BASE
    assert not OUT.exists() and not OUT.with_suffix('.tar.gz').exists()
    listing = load(payload/'source_file_list.json')
    assert listing == {'byte_identical_public_files': list(PUBLIC), 'packaging_wrappers': list(WRAPPERS)}
    assert {str(path.relative_to(payload/'source')) for path in (payload/'source').rglob('*') if path.is_file()} == set(PUBLIC)|set(WRAPPERS)
    for name in PUBLIC:
        assert (payload/'source'/name).read_bytes() == (REPO/name).read_bytes()
    datasets = dataset_bindings()
    assert datasets == preparation['datasets']
    author = verify_author(datasets)
    completion = verify_independent(datasets)
    acquisition = acquisition_record()
    acquisition_access = acquisition_access_record()
    documentation = documentation_record(datasets)
    selection = load(WORK/'next-upstream-selection/selection.json')
    assert selection['schema'] == 'mhdlab-next-upstream-scientific-task-selection-v1' and selection['status'] == 'selected'
    next_task = selection['selected_task']
    assert isinstance(next_task, str) and next_task.strip()
    shutil.copytree(payload, OUT)
    evidence = OUT/'evidence'
    evidence.mkdir()
    try:
        active_log = Path(os.readlink('/proc/self/fd/1')).resolve()
    except OSError:
        active_log = None
    copied_root_files = []
    copied_inputs = []
    for path in WORK.iterdir():
        if path.is_file() and path.suffix in TEXT_SUFFIXES and path.resolve() != active_log:
            assert not path.is_symlink()
            target = evidence/path.name
            digest = sha(path)
            shutil.copyfile(path, target)
            assert sha(target) == digest
            copied_inputs.append({'source': str(path), 'archive': str(target.relative_to(OUT)), 'sha256': digest})
            copied_root_files.append(path.name)
    omissions = []
    for folder in EVIDENCE_DIRS:
        for path in (WORK/folder).rglob('*'):
            if path.is_symlink():
                raise ValueError('symlink in evidence')
            if not path.is_file():
                continue
            relative = path.relative_to(WORK)
            if excluded(relative) or (folder == 'source-acquisition' and path.stat().st_size > 2*1024*1024):
                omissions.append({'path': str(relative), 'sha256': sha(path), 'bytes': path.stat().st_size,
                    'reason': 'Raw source image/page, prospective source-local data, fulltext, cache or large acquisition response omitted.'})
                continue
            assert sha(path) != PDF_SHA256
            target = evidence/relative
            target.parent.mkdir(parents=True, exist_ok=True)
            digest = sha(path)
            shutil.copyfile(path, target)
            assert sha(target) == digest
            copied_inputs.append({'source': str(path), 'archive': str(target.relative_to(OUT)), 'sha256': digest})
    projections = []
    for path in evidence.rglob('*'):
        if not path.is_file() or path.suffix not in TEXT_SUFFIXES:
            continue
        for prefix, replacement in PROJECTIONS:
            data = path.read_bytes()
            if prefix not in data:
                continue
            assert replacement not in data
            projected = data.replace(prefix, replacement)
            path.write_bytes(projected)
            projections.append({'path': str(path.relative_to(OUT)), 'original_sha256': hashlib.sha256(data).hexdigest(),
                'portable_sha256': sha(path), 'replacements': data.count(prefix), 'source_prefix_hex': prefix.hex(),
                'replacement': replacement.decode(), 'scope': 'Archive-only machine directory projection; local raw bytes unchanged.'})
    save(OUT/'portable_path_projections.json', projections)
    save(OUT/'excluded_evidence.json', omissions)
    with (OUT/'current-depth-recovery.patch').open('wb') as stream:
        subprocess.run(['git', 'diff', '--binary', BASE, head], cwd=REPO, stdout=stream, check=True)
    results = {**EXPECTED_CONTROLS, 'independent_readback_passed': True,
        'all_retained_signed_negative': True, 'physical_normalization_verified': False,
        'physical_truth_validated': False, 'portable_executions_performed': False,
        'packaging_source_recovery_repeated': False, 'old_recoveries_repeated': False,
        'old_test_suites_repeated': False, 'full_source_pdf_included': False,
        'raw_source_images_or_pages_included': False, 'source_acquisition_metadata_verified': True,
        'source_acquisition_physical_parameters_adopted': False}
    verification = {'schema': 'mitl-current-depth-recovery-verification-v1',
        'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'source_commit': head, 'base_commit': BASE, 'datasets': datasets, 'results': results,
        'public_files_byte_identical': len(PUBLIC), 'packaging_wrappers': len(WRAPPERS),
        'commits': subprocess.check_output(['git', 'log', '--reverse', '--format=%H %s', BASE+'..'+head], cwd=REPO, text=True).splitlines(),
        'author_verification': author, 'author_verification_sha256': sha(WORK/'recovery/author-verification.json'),
        'independent_completion': completion, 'independent_completion_sha256': sha(WORK/'independent-verification/completion.json'),
        'source_acquisition_metadata': acquisition, 'source_acquisition_metadata_sha256': sha(WORK/'source-acquisition/metadata_report.json'),
        'source_acquisition_access': acquisition_access,
        'source_acquisition_access_sha256': sha(WORK/'source-acquisition/locations/acquisition_state.json'),
        'documentation_association': documentation, 'documentation_association_sha256': sha(WORK/'documentation-association.json'),
        'selection_sha256': sha(WORK/'next-upstream-selection/selection.json'), 'next_task': next_task,
        'copied_input_sha256': copied_inputs,
        'command_snapshot': {'scope': 'Completed pass records before freezing; later freeze/verification/completion records remain local.',
                             'copied_root_files': sorted(copied_root_files)},
        'limits': ['Four signed interior legacy Allegra raster lineouts; no experimental or FLASH validation.',
            'Printed J_z normalization is unverified. Literal SI conversion does not qualify dimensional heating input.',
            'Display readout bounds are correlated and do not quantify physical or simulation uncertainty.',
            'No moving boundary, full depth integral, J-squared heating, conductivity, material closure or drive-clock alignment is recovered.',
            'New DOI metadata and bounded location evidence establish citation identity and access status only; no physical desorption parameters are adopted.',
            'Packaging creates no new portable environment and reruns no recovery, prior suite, numerical source or owner implementation.']}
    save(OUT/'verification.json', verification)
    save(OUT/'next_task.json', {'task': next_task, 'selection_evidence': 'evidence/next-upstream-selection/selection.json'})
    (OUT/'systems-mitl-current-depth-recovery-10192026.md').write_text(f'''# Published current-depth recovery

The public subset is pinned to `{head}`; the patch starts at `{BASE}`.
Eight named public files are byte-identical. Two wrappers provide the README
and dependency list. No portable environment or additional execution is claimed.

Four signed J_z profiles at 40/60 ns retain 141 native raster rows each. All 1,584
candidate rows are catalogued: 564 retained and 1,020 excluded. Original source
hashes, decoded RGB identity, exact axis calibration, correlated display bounds,
source geometry, QA figures and independent readback/guard evidence are retained.
These are published legacy Allegra simulations. Original unit normalization
remains unverified; conditional literal SI columns do not authorize heating input.

The source PDF, raw native pages/images, prospective source-local panels and
acquired fulltexts are omitted with hashes where locally present. New Joly/Li–Dylla
DOI metadata and bounded access evidence establish citation identity and access
status only. No rate, monolayer convention or target-material identity is adopted.

No current integral, whole-depth recovery, moving material boundary, Ampere-law
closure, J-squared heating, material law or clock alignment is inferred. Archive-only
machine-directory projections are reversible and leave local raw records unchanged.
Exact commands, failed attempts and focused corrections are preserved in evidence.

Next selected task: {next_task}
''')
    manifest = {str(path.relative_to(OUT)): sha(path) for path in OUT.rglob('*') if path.is_file() and path.name != 'manifest.sha256.json'}
    save(OUT/'manifest.sha256.json', manifest)
    words = [bytes.fromhex(value).decode() for value in ('6f70656e6169', '63686174677074', '636c61756465', '636f646578')]
    prohibited = re.compile(r'\b(?:'+'|'.join(words)+r')\b', re.I)
    for path in OUT.rglob('*'):
        assert not path.is_symlink()
        if path.is_file():
            assert sha(path) != PDF_SHA256 and not excluded(path.relative_to(OUT))
            if path.suffix in TEXT_SUFFIXES:
                assert not prohibited.search(path.read_text()), str(path)
    archive = OUT.with_suffix('.tar.gz')
    clean_head(head)
    assert all(sha(REPO/name) == preparation['public_source_sha256'][name] for name in PUBLIC)
    assert all(sha(Path(item['source'])) == item['sha256'] for item in copied_inputs)
    with tarfile.open(archive, 'w:gz') as tar:
        tar.add(OUT, arcname=OUT.name)
    record = {'folder': str(OUT), 'archive': str(archive), 'sha256': sha(archive), 'bytes': archive.stat().st_size,
        'source_commit': head, 'base_commit': BASE, 'manifest_entries': len(manifest),
        'public_files_byte_identical': len(PUBLIC), 'packaging_wrappers': len(WRAPPERS),
        'manifest_sha256': sha(OUT/'manifest.sha256.json'), 'verification_sha256': sha(OUT/'verification.json')}
    save(WORK/'frozen_delivery.json', record)
    print(json.dumps(record, indent=2))


if __name__ == '__main__':
    main()
