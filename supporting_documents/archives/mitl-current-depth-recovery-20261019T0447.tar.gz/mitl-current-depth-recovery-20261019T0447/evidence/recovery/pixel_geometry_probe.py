"""Inspect J-panel tick centres and complete same-color native row runs."""
from pathlib import Path
import json
import numpy as np
from PIL import Image

OUT=Path(__file__).resolve().parent
def runs(values):
    values=np.asarray(values,dtype=int)
    if not len(values):return []
    groups=np.split(values,np.flatnonzero(np.diff(values)>1)+1)
    return [[int(group[0]),int(group[-1])] for group in groups]
records=[]
for figure in ('4_28','4_29'):
    image=np.asarray(Image.open(OUT/f'figure_{figure}_native.png'))
    record={'figure':figure,
        'black_axis_horizontal_runs':{str(y):runs(np.flatnonzero(np.all(image[y,:500]==(0,0,0),axis=1))) for y in (900,901,903,905,907)},
        'black_axis_vertical_runs':{str(x):runs(np.flatnonzero(np.all(image[495:910,x]==(0,0,0),axis=1))+495) for x in (82,84,86,88,89)},
        'profile_rows':{}}
    for name,color in [('foil_edge',(154,205,50)),('foil_middle',(0,128,0))]:
        line={str(y):runs(np.flatnonzero(np.all(image[y,90:478]==color,axis=1))+90)
              for y in range(900,504,-1)}
        record['profile_rows'][name]=line
        print(figure,name,[(y,line[str(y)]) for y in (810,805,800,795,790,785,630,625,620,615,610,605,600)])
    print(figure,'Xticks',record['black_axis_horizontal_runs'])
    print(figure,'Yticks',record['black_axis_vertical_runs'])
    records.append(record)
(OUT/'pixel_geometry_probe.json').write_text(json.dumps(records,indent=2)+'\n')
