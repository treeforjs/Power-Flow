"""Inventory the newly recovered current profiles without rerunning recovery."""
import csv
import hashlib
import json
from pathlib import Path

ROOT = Path('/workspace/Power-Flow')
WORK = Path(__file__).resolve().parent
PASS = WORK.parent


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


tool = ROOT / 'tools/recover_dissertation_depth_current.py'
commands = [json.loads(line) for line in (PASS / 'commands.jsonl').read_text().splitlines()]
producer_commands = [entry for entry in commands if 'tools/recover_dissertation_depth_current.py' in entry['command']]
assert len(producer_commands) == 1 and producer_commands[0]['exit_code'] == 0
figures = []
for figure in ('4_28', '4_29'):
    csv_path = ROOT / f'data/dissertation/figure_{figure}_current_depth.csv'
    metadata_path = csv_path.with_suffix('.json')
    metadata = json.loads(metadata_path.read_text())
    rows = list(csv.DictReader(csv_path.open()))
    assert metadata['output']['generator_sha256'] == digest(tool)
    assert metadata['output']['csv_sha256'] == digest(csv_path)
    assert len(rows) == metadata['output']['samples'] == 282
    geometry = WORK / metadata['output']['source_geometry_filename']
    assert digest(geometry) == metadata['output']['source_geometry_sha256']
    qa = {name: digest(WORK / name) for name in metadata['output']['QA_files_sha256']}
    assert qa == metadata['output']['QA_files_sha256']
    stats = {}
    for profile in ('foil_edge', 'foil_middle'):
        selected = [row for row in rows if row['profile'] == profile]
        catalogue = metadata['selection']['profiles'][profile]
        assert len(selected) == catalogue['retained_count'] == 141
        assert catalogue['excluded_count'] == 255 and catalogue['catalogued_row_count'] == 396
        stats[profile] = {'samples': len(selected), 'excluded_rows': catalogue['excluded_count'],
                          'signed_Jz_literal_MA_per_cm2': [min(float(r['Jz_literal_MA_per_cm2']) for r in selected),
                                                         max(float(r['Jz_literal_MA_per_cm2']) for r in selected)],
                          'matched_run_width_pixels': sorted({int(r['matched_color_pixels']) for r in selected})}
    figures.append({'figure': metadata['source']['figure'],
                    'csv': str(csv_path.relative_to(ROOT)), 'csv_sha256': digest(csv_path),
                    'metadata': str(metadata_path.relative_to(ROOT)), 'metadata_sha256': digest(metadata_path),
                    'profiles': stats, 'calibration': metadata['calibration'],
                    'gap_coordinate_extent_mm': metadata['output']['gap_coordinate_extent_mm'],
                    'nominal_initial_depth_extent_um': metadata['output']['nominal_initial_depth_extent_um'],
                    'source_geometry': str(geometry), 'source_geometry_sha256': digest(geometry),
                    'QA_files_sha256': qa})
record = {'schema': 'mhdlab-current-depth-author-verification-v1', 'complete': True,
          'public_source': str(tool.relative_to(ROOT)), 'public_source_sha256': digest(tool),
          'source_PDF_sha256': json.loads((WORK / 'native_inspection.json').read_text())['PDF_sha256'],
          'new_producer_run_count': len(producer_commands), 'new_producer_command': producer_commands[0],
          'visual_QA': {'both_generated_PNGs_viewed': True,
                        'findings': 'Retained overlays track the four signed interior raster curves; shaded support avoids visible corners, broad ramps and legend. Negative sign and conditional unit qualification are visible.'},
          'total_samples': 564, 'total_excluded_rows': 1020,
          'public_metadata_schema': 'mhdlab-dissertation-current-depth-recovery-v1',
          'figures': figures,
          'verification_scope': 'Author output inventory and visual QA only; independent native pixel/calibration readback and source-guard controls recorded separately.',
          'limits': ['Published legacy Allegra simulation raster, not experimental or FLASH data.',
                     'Literal conditional J_z normalization unverified; no current or heating closure.',
                     'Conservative display support; actual moving material faces unavailable.',
                     'Readout bounds are correlated display bounds, not independent physical noise.',
                     'Magnetic gap profiles remain pending.']}
path = WORK / 'author-verification.json'
path.write_text(json.dumps(record, indent=2, allow_nan=False) + '\n')
print(json.dumps({'record': str(path), 'record_sha256': digest(path),
                  'total_samples': 564, 'total_excluded_rows': 1020,
                  'figures': [{k: v for k, v in f.items() if k in ('figure', 'profiles', 'gap_coordinate_extent_mm', 'nominal_initial_depth_extent_um')} for f in figures]}, indent=2))
