"""Inspect native Figure4.28/4.29 current panels without executing old producers."""
from pathlib import Path
import hashlib
import io
import json
import numpy as np
from PIL import Image
import pymupdf

PDF=Path('/workspace/research_sources/smtrevor_1.pdf')
OUT=Path(__file__).resolve().parent
records=[]
with pymupdf.open(PDF) as doc:
    for figure,page_index,xref in [('4.28',118,2847),('4.29',120,2870)]:
        page=doc[page_index]
        encoded=doc.extract_image(xref)['image']
        image=Image.open(io.BytesIO(encoded))
        image.save(OUT/f'figure_{figure.replace(".","_")}_native.png')
        image.crop((0,480,500,975)).resize((1000,990)).save(OUT/f'figure_{figure.replace(".","_")}_J_panel_inspection.png')
        record={'figure':figure,'page_index':page_index,'xref':xref,'text':page.get_text(),
                'image_mode':image.mode,'image_size':list(image.size),
                'encoded_png_sha256':hashlib.sha256(encoded).hexdigest(),
                'RGB_sha256':hashlib.sha256(image.tobytes()).hexdigest(),
                'page_content_sha256':hashlib.sha256(page.read_contents()).hexdigest()}
        records.append(record)
print(json.dumps(records,indent=2))
(OUT/'native_inspection.json').write_text(json.dumps({'PDF_sha256':hashlib.sha256(PDF.read_bytes()).hexdigest(),
    'parser_version':pymupdf.VersionBind,'figures':records},indent=2)+'\n')
