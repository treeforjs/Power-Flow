"""Prepare a compact published current-depth recovery handoff after commit."""
import argparse
import ast
import csv
import hashlib
import json
import math
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess

WORK = Path(__file__).resolve().parent
REPO = Path('/workspace/Power-Flow')
BASE = 'bea74a0e08bb531cf790a73bc67f97eb1d6de97b'
HEAD = '65638571ddfa3a887f610021dec58bdbafee54d0'
OUT = Path('/workspace/handoffs/mitl-current-depth-recovery-20261019T0447')
PDF_SHA256 = '1d7b1f9c191a37e94f1cc3634587750f1af35b07eb13e0b94c60f3da47495ed7'
PRODUCER = 'tools/recover_dissertation_depth_current.py'
PUBLIC = (PRODUCER,
    'data/dissertation/figure_4_28_current_depth.csv', 'data/dissertation/figure_4_28_current_depth.json',
    'data/dissertation/figure_4_29_current_depth.csv', 'data/dissertation/figure_4_29_current_depth.json',
    'data/dissertation/recovery_manifest.yaml', 'docs/dissertation_recovery.md',
    'docs/dissertation_current_depth_recovery.md')
WRAPPERS = ('README.md', 'requirements.txt')
FIGURES = (('4.28', '4_28', 119, 118, 4e-8), ('4.29', '4_29', 121, 120, 6e-8))


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024*1024), b''):
            digest.update(block)
    return digest.hexdigest()


def object_pairs(pairs):
    value = {}
    for key, item in pairs:
        if key in value:
            raise ValueError('duplicate JSON key')
        value[key] = item
    return value


def load(path):
    return json.loads(Path(path).read_text(), object_pairs_hook=object_pairs,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False)+'\n')


def clean_head(expected):
    assert re.fullmatch('[0-9a-f]{40}', expected) and expected == HEAD
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == expected
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=REPO, text=True).strip()
    subprocess.run(['git', 'merge-base', '--is-ancestor', BASE, expected], cwd=REPO, check=True)
    return expected


def canonical_hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def inspect_dataset(csv_bytes, metadata, *, csv_path, metadata_path, producer_sha256, metadata_sha256):
    """Check saved bytes and declarations; no image extraction or recovery."""
    import io
    assert metadata['schema'] == 'mhdlab-dissertation-current-depth-recovery-v1'
    figure = next(record for record in FIGURES if record[0] == metadata['source']['figure'])
    source, context, units, output = (metadata[k] for k in ('source', 'simulation_context', 'unit_interpretation', 'output'))
    assert source['pdf_sha256'] == PDF_SHA256
    assert source['pdf_page'] == figure[2] and source['pdf_page_index'] == figure[3]
    assert source['native_image_size_pixels'] == [975, 975] and source['native_image_mode'] == 'RGB'
    for name in ('page_content_sha256', 'decoded_RGB_pixels_sha256', 'extracted_PNG_sha256'):
        assert re.fullmatch('[0-9a-f]{64}', source[name])
    assert context['code_label_in_dissertation'] == 'Allegra' and context['drive_shot'] == 17133
    assert abs(context['time_s']-figure[4]) <= math.ulp(figure[4])
    for name in ('experimental_measurement', 'FLASH_result', 'actual_material_boundaries_recovered', 'coordinate_frame_rotation_applied'):
        assert context[name] is False
    assert context['component_signs_preserved'] is True
    for name in ('original_simulation_output_units_confirmed', 'original_normalization_verified',
                 'normalization_or_legend_error_resolved', 'unit_repair_or_empirical_rescaling_applied'):
        assert units[name] is False
    assert units['literal_conditional_scale_to_A_per_m2'] == 1e10
    assert metadata['nominal_initial_depth']['actual_moving_face_coordinate'] is False
    assert metadata['readout_bounds']['physical_or_simulation_uncertainty_quantified'] is False
    assert metadata['readout_bounds']['correlated_display_bounds_only'] is True
    assert metadata['readout_bounds']['independent_noise_or_confidence_interval'] is False
    assert output['csv_filename'] == Path(csv_path).name
    assert output['csv_sha256'] == hashlib.sha256(csv_bytes).hexdigest()
    assert output['generator'] == PRODUCER and output['generator_sha256'] == producer_sha256
    reader = csv.DictReader(io.StringIO(csv_bytes.decode()))
    rows = list(reader)
    assert reader.fieldnames == output['columns'] and len(rows) == output['samples'] == 282
    profiles = metadata['selection']['profiles']
    assert set(profiles) == {'foil_edge', 'foil_middle'}
    roi = metadata['selection']['panel_ROI_inclusive']['y']
    expected_rows = set(range(roi[0], roi[1]+1))
    profile_records = {}
    for name, record in profiles.items():
        retained = record['retained_rows']
        excluded = record['excluded_rows']
        kept_y = [item['pixel_y'] for item in retained]
        excluded_y = [item['pixel_y'] for item in excluded]
        selected = [row for row in rows if row['profile'] == name]
        assert len(selected) == len(retained) == record['retained_count'] == output['samples_by_profile'][name] == 141
        assert len(excluded) == record['excluded_count'] == 255
        assert len(kept_y) == len(set(kept_y)) and len(excluded_y) == len(set(excluded_y))
        assert not set(kept_y)&set(excluded_y) and set(kept_y)|set(excluded_y) == expected_rows
        assert record['catalogued_row_count'] == len(expected_rows) == 396
        assert {int(row['pixel_y']) for row in selected} == set(kept_y)
        assert all(row['figure'] == figure[0] and abs(float(row['time_s'])-figure[4]) <= math.ulp(figure[4]) for row in selected)
        signed = [float(row['Jz_literal_MA_per_cm2']) for row in selected]
        assert all(math.isfinite(value) and value < 0 for value in signed)
        profile_records[name] = {'samples': len(selected), 'excluded_rows': len(excluded),
            'catalogued_rows': len(expected_rows), 'catalog_sha256': canonical_hash(record),
            'negative_values': len(signed)}
    assert len(rows) == sum(item['samples'] for item in profile_records.values())
    for name in ('interpolation', 'smoothing', 'extrapolation', 'surface_or_endpoint_padding'):
        assert metadata['selection'][name] is False
    return {'figure': figure[0], 'csv_path': csv_path, 'metadata_path': metadata_path,
        'csv_sha256': output['csv_sha256'], 'metadata_sha256': metadata_sha256,
        'producer_path': PRODUCER, 'producer_sha256': producer_sha256, 'columns': reader.fieldnames,
        'samples': len(rows), 'profiles': profile_records, 'source': source,
        'simulation_context': context, 'unit_interpretation': units,
        'calibration_sha256': canonical_hash(metadata['calibration']),
        'source_geometry_filename': output['source_geometry_filename'],
        'source_geometry_sha256': output['source_geometry_sha256'], 'QA_files_sha256': output['QA_files_sha256'],
        'physical_truth_validated': False, 'original_normalization_verified': False}


def dataset_bindings():
    records = []
    for _, identifier, _, _, _ in FIGURES:
        csv_name = f'data/dissertation/figure_{identifier}_current_depth.csv'
        metadata_name = f'data/dissertation/figure_{identifier}_current_depth.json'
        records.append(inspect_dataset((REPO/csv_name).read_bytes(), load(REPO/metadata_name),
            csv_path=csv_name, metadata_path=metadata_name, producer_sha256=sha(REPO/PRODUCER),
            metadata_sha256=sha(REPO/metadata_name)))
    return records


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--expected-head', required=True)
    args = parser.parse_args()
    head = clean_head(args.expected_head)
    for name in PUBLIC:
        path = PurePosixPath(name)
        assert not path.is_absolute() and '..' not in path.parts
        assert (REPO/name).is_file() and not (REPO/name).is_symlink()
    # The standalone tool must not acquire an implicit repository-module closure.
    tree = ast.parse((REPO/PRODUCER).read_text())
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom):
            assert (node.module or '').split('.')[0] not in {'mhdlab', 'tools'}
        elif isinstance(node, ast.Import):
            assert not any(alias.name.split('.')[0] in {'mhdlab', 'tools'} for alias in node.names)
    datasets = dataset_bindings()
    payload = WORK/'delivery-preparation/payload'
    assert not payload.exists() and not OUT.exists() and not OUT.with_suffix('.tar.gz').exists()
    source = payload/'source'
    source.mkdir(parents=True)
    for name in PUBLIC:
        target = source/name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(REPO/name, target)
    (source/'requirements.txt').write_text('numpy\nPyMuPDF\nPillow\nmatplotlib\n')
    (source/'README.md').write_text('''# Published current-depth recovery subset

Eight named public files are copied byte-for-byte. This README and the dependency
list are packaging wrappers. The standalone recovery script has no repository
module imports. Packaging does not create a portable environment or execute a
second recovery, inspector, source model or prior test suite.

The four signed interior J_z profiles are reconstructed from the published
legacy Allegra simulation raster in Figs.4.28–4.29 at 40/60 ns. Their CSV files
retain 141 rows per profile. Complete retained/excluded row catalogs, source and
RGB hashes, exact axis calibration, correlated display readout bounds, QA and
independent readback are preserved. Original simulation normalization remains
unverified. SI columns apply only the literal printed-unit conversion. These
data do not establish physical J-squared heating, material boundaries, clock
alignment, experimental validation or a FLASH result.

The full dissertation, raw source pages/images, prospective source-local panels
and acquired fulltexts are omitted. Their recorded hashes and metadata remain.
The original PDF is required for a future deliberate recovery replay. Existing
QA figures are included; archive assembly performs no recovery replay.
''')
    save(payload/'source_file_list.json', {'byte_identical_public_files': list(PUBLIC), 'packaging_wrappers': list(WRAPPERS)})
    (payload/'source-files.sha256').write_text(''.join(f'{sha(source/name)}  {name}\n' for name in PUBLIC))
    (payload/'wrapper-files.sha256').write_text(''.join(f'{sha(source/name)}  {name}\n' for name in WRAPPERS))
    save(payload/'preparation.json', {'source_commit': head, 'base_commit': BASE, 'datasets': datasets,
        'portable_execution_performed': False, 'physical_truth_validated': False,
        'public_source_sha256': {name: sha(REPO/name) for name in PUBLIC}})
    print(json.dumps({'payload': str(payload), 'source_commit': head, 'public_files': len(PUBLIC),
        'packaging_wrappers': len(WRAPPERS), 'retained_rows': sum(item['samples'] for item in datasets)}, indent=2))


if __name__ == '__main__':
    main()
