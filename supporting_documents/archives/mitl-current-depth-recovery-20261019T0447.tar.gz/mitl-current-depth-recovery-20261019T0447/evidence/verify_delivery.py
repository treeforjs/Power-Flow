"""Verify actual compact current-depth archive bytes and source associations."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import tarfile

from prepare_delivery import WORK, REPO, BASE, OUT, PUBLIC, WRAPPERS, PRODUCER, PDF_SHA256, clean_head, inspect_dataset, load, save, sha
from freeze_delivery import EXPECTED_CONTROLS, excluded


def main():
    frozen = load(WORK/'frozen_delivery.json')
    clean_head(frozen['source_commit'])
    assert frozen['base_commit'] == BASE and Path(frozen['folder']) == OUT
    archive = Path(frozen['archive'])
    assert archive == OUT.with_suffix('.tar.gz')
    assert sha(archive) == frozen['sha256'] and archive.stat().st_size == frozen['bytes']
    hashes, members = {}, {}
    with tarfile.open(archive, 'r:gz') as tar:
        seen = set()
        for member in tar.getmembers():
            path = PurePosixPath(member.name)
            assert not path.is_absolute() and '..' not in path.parts and path.parts[0] == OUT.name
            assert member.name not in seen and not member.issym() and not member.islnk()
            seen.add(member.name)
            if member.isdir():
                continue
            assert member.isfile()
            name = PurePosixPath(*path.parts[1:]).as_posix()
            assert name != '.' and name not in members and not excluded(name)
            digest = hashlib.sha256()
            stream = tar.extractfile(member)
            for block in iter(lambda: stream.read(1024*1024), b''):
                digest.update(block)
            assert digest.hexdigest() != PDF_SHA256
            hashes[name], members[name] = digest.hexdigest(), member

        def raw(name):
            data = tar.extractfile(members[name]).read()
            assert hashlib.sha256(data).hexdigest() == hashes[name]
            return data

        def document(name):
            return json.loads(raw(name))

        manifest = document('manifest.sha256.json')
        assert set(hashes) == set(manifest)|{'manifest.sha256.json'}
        assert len(manifest) == frozen['manifest_entries']
        assert all(hashes[name] == digest for name, digest in manifest.items())
        assert hashes['manifest.sha256.json'] == frozen['manifest_sha256']
        assert hashes['verification.json'] == frozen['verification_sha256']
        assert {str(path.relative_to(OUT)) for path in OUT.rglob('*') if path.is_file()} == set(hashes)
        assert all(sha(OUT/name) == digest for name, digest in hashes.items())
        listing = document('source_file_list.json')
        assert listing == {'byte_identical_public_files': list(PUBLIC), 'packaging_wrappers': list(WRAPPERS)}
        assert {name[7:] for name in hashes if name.startswith('source/')} == set(PUBLIC)|set(WRAPPERS)
        for name in PUBLIC:
            assert hashes['source/'+name] == sha(REPO/name)
        for file_name, names in (('source-files.sha256', PUBLIC), ('wrapper-files.sha256', WRAPPERS)):
            records = {}
            for line in raw(file_name).decode().splitlines():
                digest, name = line.split('  ', 1)
                assert name not in records and digest == hashes['source/'+name]
                records[name] = digest
            assert set(records) == set(names)
        verification = document('verification.json')
        assert verification['schema'] == 'mitl-current-depth-recovery-verification-v1'
        assert verification['source_commit'] == frozen['source_commit'] and verification['base_commit'] == BASE
        results = verification['results']
        assert all(type(results[key]) is int and results[key] == value for key, value in EXPECTED_CONTROLS.items())
        for key in ('physical_normalization_verified', 'physical_truth_validated', 'portable_executions_performed',
                    'packaging_source_recovery_repeated', 'old_recoveries_repeated', 'old_test_suites_repeated',
                    'full_source_pdf_included', 'raw_source_images_or_pages_included', 'source_acquisition_physical_parameters_adopted'):
            assert results[key] is False
        datasets = []
        for record in verification['datasets']:
            metadata = document('source/'+record['metadata_path'])
            dataset = inspect_dataset(raw('source/'+record['csv_path']), metadata,
                csv_path=record['csv_path'], metadata_path=record['metadata_path'],
                producer_sha256=hashes['source/'+PRODUCER], metadata_sha256=hashes['source/'+record['metadata_path']])
            assert dataset == record
            assert hashes['evidence/recovery/'+record['source_geometry_filename']] == record['source_geometry_sha256']
            for name, digest in record['QA_files_sha256'].items():
                assert hashes['evidence/recovery/'+name] == digest
            datasets.append(dataset)
        assert len(datasets) == 2 and sum(record['samples'] for record in datasets) == 564

        # Undo each machine-path projection in reverse order to bind raw evidence.
        restored_bytes = {}
        original_hashes = dict(hashes)
        for projection in reversed(document('portable_path_projections.json')):
            name = projection['path']
            data = restored_bytes.get(name, raw(name))
            assert hashlib.sha256(data).hexdigest() == projection['portable_sha256']
            replacement = projection['replacement'].encode()
            assert data.count(replacement) == projection['replacements']
            restored = data.replace(replacement, bytes.fromhex(projection['source_prefix_hex']))
            assert hashlib.sha256(restored).hexdigest() == projection['original_sha256']
            restored_bytes[name] = restored
            original_hashes[name] = projection['original_sha256']

        def original_document(name):
            return json.loads(restored_bytes.get(name, raw(name)))

        for item in verification['copied_input_sha256']:
            assert original_hashes[item['archive']] == item['sha256']

        author_name = 'evidence/recovery/author-verification.json'
        author = original_document(author_name)
        assert original_hashes[author_name] == verification['author_verification_sha256']
        assert author == verification['author_verification'] and author['complete'] is True
        assert author['new_producer_run_count'] == 1 and author['source_PDF_sha256'] == PDF_SHA256
        assert author['public_source_sha256'] == hashes['source/'+PRODUCER]
        assert author['total_samples'] == 564 and author['total_excluded_rows'] == 1020
        assert author['visual_QA']['both_generated_PNGs_viewed'] is True
        for record, dataset in zip(author['figures'], datasets):
            assert record['figure'] == dataset['figure']
            assert record['csv_sha256'] == dataset['csv_sha256'] and record['metadata_sha256'] == dataset['metadata_sha256']
            assert record['source_geometry_sha256'] == dataset['source_geometry_sha256']
            assert record['QA_files_sha256'] == dataset['QA_files_sha256']

        completion_name = 'evidence/independent-verification/completion.json'
        completion = original_document(completion_name)
        assert original_hashes[completion_name] == verification['independent_completion_sha256']
        assert completion == verification['independent_completion']
        assert completion['schema'] == 'mitl-independent-current-depth-completion-v1'
        assert completion['all_checks_passed'] is True and completion['status'] == 'passed'
        assert all(type(completion[key]) is int and completion[key] == value for key, value in EXPECTED_CONTROLS.items())
        assert completion['old_suites_repeated'] is False and completion['all_retained_signed_negative'] is True
        assert completion['physical_normalization_verified'] is False
        assert completion['original_simulation_output_units_confirmed'] is False and completion['J_squared_heating_inferred'] is False
        for name, digest in completion['public_source_sha256'].items():
            assert hashes['source/'+name] == digest
        for name, digest in completion['artifact_sha256'].items():
            source = Path(name)
            archive_name = 'evidence/'+name
            if not source.is_absolute() and archive_name in original_hashes:
                assert original_hashes[archive_name] == digest
            elif not source.is_absolute() and excluded(name):
                assert any(item['path'] == name and item['sha256'] == digest for item in document('excluded_evidence.json'))
            else:
                assert sha(source if source.is_absolute() else WORK/name) == digest

        acquisition_name = 'evidence/source-acquisition/metadata_report.json'
        acquisition = original_document(acquisition_name)
        assert original_hashes[acquisition_name] == verification['source_acquisition_metadata_sha256']
        assert acquisition == verification['source_acquisition_metadata'] and acquisition['all_target_metadata_verified'] is True
        assert acquisition['physical_rates_or_monolayer_convention_adopted'] is False
        for item in acquisition['records']:
            path = Path(item['file']).relative_to(WORK)
            assert original_hashes['evidence/'+str(path)] == item['sha256']
        access_name = 'evidence/source-acquisition/locations/acquisition_state.json'
        access = original_document(access_name)
        assert original_hashes[access_name] == verification['source_acquisition_access_sha256']
        assert access['status'] == verification['source_acquisition_access']['status'] == 'metadata_only_fulltext_blocked'
        assert access['full_text_acquired'] is False and access['physical_rate_or_monolayer_or_wall_energy_adopted'] is False
        assert access['request_counts']['retries'] == 0 and access['request_counts']['repository_or_PDF_downloads'] == 0
        for name, digest in access['artifact_sha256'].items():
            assert original_hashes['evidence/'+name] == digest
        documentation_name = 'evidence/documentation-association.json'
        documentation = original_document(documentation_name)
        assert original_hashes[documentation_name] == verification['documentation_association_sha256']
        assert documentation == verification['documentation_association'] and documentation['passed'] is True
        assert documentation['all_prior_artifacts_preserved'] is True and documentation['source_record_unchanged'] is True
        for name, digest in documentation['after_sha256'].items():
            assert hashes['source/'+name] == digest
        selection_name = 'evidence/next-upstream-selection/selection.json'
        selection = original_document(selection_name)
        assert original_hashes[selection_name] == verification['selection_sha256']
        assert document('next_task.json')['task'] == selection['selected_task'] == verification['next_task']
        result = {**frozen, 'status': 'passed', 'actual_archive_regular_files': len(hashes),
            'unsafe_or_duplicate_members': 0, 'input_code_output_bindings_verified': True,
            'repository_clean': True, 'retained_rows_verified': 564, 'catalogued_rows_verified': 1584,
            'signed_negative_rows_verified': 564, 'physical_normalization_verified': False,
            'source_pdf_included': False, 'raw_source_images_or_pages_included': False,
            'source_recovery_or_scientific_checks_reexecuted': False}
    save(WORK/'delivery_verification.json', result)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
