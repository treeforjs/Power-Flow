"""Complete the signed current-depth recovery only after verified delivery.

Draft until explicitly executed. This script reads existing evidence and archive
bytes; it performs no recovery, source acquisition, inspector or test execution.
"""
import csv
import datetime
import fcntl
import hashlib
import json
import math
from pathlib import Path, PurePosixPath
import subprocess
import tarfile

WORK = Path(__file__).resolve().parent
REPO = Path('/workspace/Power-Flow')
OUT = Path('/workspace/handoffs/mitl-current-depth-recovery-20261019T0447')
BASE = 'bea74a0e08bb531cf790a73bc67f97eb1d6de97b'
HEAD = '65638571ddfa3a887f610021dec58bdbafee54d0'
PDF_SHA = '1d7b1f9c191a37e94f1cc3634587750f1af35b07eb13e0b94c60f3da47495ed7'
PRODUCER = 'tools/recover_dissertation_depth_current.py'
PINNED = {
    PRODUCER: '77926d95a0e6c01001d7268200a34aa58457cc33d3de051f45f9d0a7ebeb8982',
    'data/dissertation/figure_4_28_current_depth.csv': 'c53365543cbf96b30a7e2e1a1e2e63871dc182bc7e60bd641b93140e6f3726e6',
    'data/dissertation/figure_4_28_current_depth.json': '5e9b662d63393904d2c0714f2ce7c3fb3812735279917f8870b3a8f3032cf4d6',
    'data/dissertation/figure_4_29_current_depth.csv': 'e6009f6f2e578776751805e36367f630bd95127fd4eb0bf183a78938822135c4',
    'data/dissertation/figure_4_29_current_depth.json': 'ce6d64ad1f1f93dcf6fd340ea7815227296cf90b55b460b293dacfb7df134fbf',
}
PUBLIC = set(PINNED)|{'data/dissertation/recovery_manifest.yaml', 'docs/dissertation_recovery.md',
                      'docs/dissertation_current_depth_recovery.md'}
EVIDENCE_PINS = {
    'independent-verification/completion.json': 'c52942cd36099e5f3658372e3a2089227fe71fc31cd35b0d9fb56ed8781d18ba',
    'recovery/author-verification.json': 'a6c695c92b03a6035fe7bea941bdb238cedc43050d20adc6a20eef1eb7712158',
    'documentation-association.json': 'e645b17eb01617425fef772dc212dbb833088aaa7fae251a016decde6df71f50',
    'source-acquisition/metadata_report.json': '3bf010f1ac7f76df07d468016ff26f3b1899bc56f3d7ffdce54b6c5cfb4ac4d3',
    'source-acquisition/locations/acquisition_state.json': 'abfb2b64be2e135b9b8106070c33c490be59448fd7a43ec764e53235429e3c8b',
    'next-upstream-selection/selection.json': '8fb414e73af0cd39e58893dc246bb31dd02d13a6a95e0badd7d6bcfa4ca1f2f8',
    'commit-check-correction.json': '53e62e2196392fd0a9c59eb80ddd0815aaf61e8d93fb1d96dc10d132e1c5cf24',
}
COUNTERS = {'figures': 2, 'profiles': 4, 'retained_rows': 564, 'excluded_rows': 1020,
    'native_rows_catalogued': 1584, 'numeric_csv_cells_checked': 10152, 'tick_anchors_checked': 28,
    'source_guard_rejections': 4, 'guarded_recovery_entry_attempts': 2,
    'successful_producer_replays': 0, 'physical_row_extraction_calls_by_invalid_source_controls': 0}


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024*1024), b''):
            digest.update(block)
    return digest.hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def clean_head():
    require(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == HEAD, 'root-approved HEAD changed')
    require(not subprocess.check_output(['git', 'status', '--porcelain'], cwd=REPO, text=True).strip(), 'repository must be clean')
    require(subprocess.check_output(['git', 'branch', '--show-current'], cwd=REPO, text=True).strip() == 'research/flash-publication-foundation', 'unexpected branch')
    subprocess.run(['git', 'merge-base', '--is-ancestor', BASE, HEAD], cwd=REPO, check=True)
    require(subprocess.check_output(['git', 'rev-list', '--count', BASE+'..'+HEAD], cwd=REPO, text=True).strip() == '2', 'expected two bounded local commits')
    require(set(subprocess.check_output(['git', 'diff', '--name-only', BASE, HEAD], cwd=REPO, text=True).splitlines()) == PUBLIC, 'committed scope changed')


def validate_maps(record):
    for name, digest in record.get('public_source_sha256', {}).items():
        require(sha(REPO/name) == digest, 'independent public source pin changed: '+name)
    for name, digest in record.get('artifact_sha256', {}).items():
        require(sha(Path(name) if Path(name).is_absolute() else WORK/name) == digest, 'artifact pin changed: '+name)


def verify_delivery(delivery, frozen, verification):
    require(delivery['status'] == 'passed' and delivery['repository_clean'] is True
            and delivery['input_code_output_bindings_verified'] is True and delivery['unsafe_or_duplicate_members'] == 0, 'delivery has not passed')
    for key in ('folder', 'archive', 'sha256', 'bytes', 'source_commit', 'base_commit', 'manifest_sha256', 'verification_sha256'):
        require(delivery[key] == frozen[key], 'delivery/freeze disagreement: '+key)
    require(delivery['folder'] == str(OUT) and delivery['source_commit'] == verification['source_commit'] == HEAD
            and delivery['base_commit'] == verification['base_commit'] == BASE, 'delivery identity changed')
    require(verification['schema'] == 'mitl-current-depth-recovery-verification-v1', 'unexpected delivery schema')
    clean_head()
    archive = Path(delivery['archive'])
    require(archive == OUT.with_suffix('.tar.gz') and sha(archive) == delivery['sha256']
            and archive.stat().st_size == delivery['bytes'], 'actual archive pin changed')
    hashes, seen = {}, set()
    qa = {f'figure_4_{figure}_current_depth.{suffix}' for figure in ('28', '29') for suffix in ('png', 'pdf')}
    with tarfile.open(archive, 'r:gz') as stream:
        for member in stream:
            path = PurePosixPath(member.name)
            require(not path.is_absolute() and '..' not in path.parts and path.parts and path.parts[0] == OUT.name, 'unsafe archive member')
            require(member.name not in seen and not member.issym() and not member.islnk(), 'duplicate/linked archive member')
            seen.add(member.name)
            if member.isdir():
                continue
            require(member.isfile() and len(path.parts) > 1, 'nonregular archive payload')
            name = str(PurePosixPath(*path.parts[1:]))
            parts = PurePosixPath(name).parts
            require(not any(p in {'source-local', 'fulltexts', 'raw-fulltexts', '__pycache__', '.venv', '.pytest_cache'} for p in parts)
                    and PurePosixPath(name).name != 'smtrevor_1.pdf', 'excluded original/prospective source included')
            require(not ('source-acquisition' in parts and 'raw' in parts), 'raw acquisition included')
            artificial_control = name == 'evidence/independent-verification/wrong-source-control.pdf'
            require(PurePosixPath(name).suffix.lower() not in {'.pdf', '.png', '.jpg', '.jpeg', '.tif', '.tiff'}
                    or PurePosixPath(name).name in qa or artificial_control, 'raw source image/page included')
            digest = hashlib.sha256()
            with stream.extractfile(member) as payload:
                for block in iter(lambda: payload.read(1024*1024), b''):
                    digest.update(block)
            hashes[name] = digest.hexdigest()
            if artificial_control:
                require(hashes[name] == load(WORK/'independent-verification/source-guards.json')['wrong_source_control_sha256'], 'manufactured wrong-source control pin changed')
            require(hashes[name] != PDF_SHA and (OUT/name).is_file() and not (OUT/name).is_symlink()
                    and sha(OUT/name) == hashes[name], 'archive/folder bytes differ: '+name)
    manifest = load(OUT/'manifest.sha256.json')
    require(set(hashes) == set(manifest)|{'manifest.sha256.json'} and all(hashes[k] == v for k, v in manifest.items()), 'actual archive manifest mismatch')
    require(sha(OUT/'manifest.sha256.json') == delivery['manifest_sha256'] and sha(OUT/'verification.json') == delivery['verification_sha256'], 'manifest/verification hash changed')
    require(len(manifest) == delivery['manifest_entries'] and len(hashes) == delivery['actual_archive_regular_files'], 'archive member count changed')
    listing = load(OUT/'source_file_list.json')
    require(len(listing['byte_identical_public_files']) == 8 and set(listing['byte_identical_public_files']) == PUBLIC
            and listing['packaging_wrappers'] == ['README.md', 'requirements.txt'], 'public/wrapper listing changed')
    require({name[7:] for name in hashes if name.startswith('source/')} == PUBLIC|{'README.md', 'requirements.txt'}, 'unlisted source payload')
    public_pins = {}
    for name in PUBLIC:
        digest = hashlib.sha256(subprocess.check_output(['git', 'show', HEAD+':'+name], cwd=REPO)).hexdigest()
        require(hashes['source/'+name] == sha(REPO/name) == digest, 'archive/repository/commit public bytes differ: '+name)
        public_pins[name] = digest
    lines = [line.split('  ', 1) for line in (OUT/'source-files.sha256').read_text().splitlines()]
    require(len(lines) == len(PUBLIC) and {name: digest for digest, name in lines} == public_pins, 'public source hash inventory differs')
    require(delivery['public_files_byte_identical'] == 8 and delivery['packaging_wrappers'] == 2
            and delivery['retained_rows_verified'] == 564 and delivery['catalogued_rows_verified'] == 1584
            and delivery['signed_negative_rows_verified'] == 564, 'delivery scope/counters changed')
    for key in ('physical_normalization_verified', 'source_pdf_included', 'raw_source_images_or_pages_included', 'source_recovery_or_scientific_checks_reexecuted'):
        require(delivery[key] is False, 'unsupported delivery claim: '+key)
    return public_pins


def verify_evidence(verification):
    for name, digest in PINNED.items():
        require(sha(REPO/name) == digest, 'frozen producer/data changed: '+name)
    for name, digest in EVIDENCE_PINS.items():
        require(sha(WORK/name) == digest, 'frozen evidence changed: '+name)
    independent = load(WORK/'independent-verification/completion.json')
    require(independent['schema'] == 'mitl-independent-current-depth-completion-v1' and independent['all_checks_passed'] is True
            and independent['status'] == 'passed' and independent == verification['independent_completion']
            and verification['independent_completion_sha256'] == EVIDENCE_PINS['independent-verification/completion.json'], 'independent completion mismatch')
    for key, expected in COUNTERS.items():
        require(type(independent[key]) is int and independent[key] == expected and type(verification['results'][key]) is int
                and verification['results'][key] == expected, 'independent/delivery counter mismatch: '+key)
    require(independent['source_pdf_sha256'] == PDF_SHA and independent['all_retained_signed_negative'] is True, 'independent source/sign mismatch')
    for key in ('positive_producer_called_for_verification', 'old_suites_repeated', 'old_recoveries_repeated', 'portable_test_execution_claimed',
                'physical_normalization_verified', 'original_simulation_output_units_confirmed', 'J_squared_heating_inferred',
                'actual_material_boundaries_recovered', 'physical_uncertainty_established', 'measured_current_density', 'FLASH_output'):
        require(independent[key] is False, 'unsupported independent claim: '+key)
    validate_maps(independent)
    require(sha(WORK/'independent-verification/readback.json') == independent['readback_sha256']
            and sha(WORK/'independent-verification/source-guards.json') == independent['source_guards_sha256'], 'independent readback/control pins changed')
    controls = load(WORK/'independent-verification/source-guards.json')
    require(controls['all_checks_passed'] is True and controls['source_guard_rejections'] == 4
            and controls['guarded_recovery_entry_attempts'] == 2 and controls['successful_recovery_replays'] == 0
            and controls['physical_row_extraction_calls_by_invalid_source_controls'] == 0
            and len(controls['source_guard_controls']) == 4 and all(item['rejected'] is True for item in controls['source_guard_controls']), 'new source controls incomplete')
    author = load(WORK/'recovery/author-verification.json')
    require(author == verification['author_verification'] and verification['author_verification_sha256'] == EVIDENCE_PINS['recovery/author-verification.json']
            and author['complete'] is True and author['new_producer_run_count'] == 1 and author['total_samples'] == 564
            and author['total_excluded_rows'] == 1020 and author['public_source_sha256'] == PINNED[PRODUCER], 'author verification changed')
    command = author['new_producer_command']
    require(command['exit_code'] == 0 and sha(command['log']) == command['log_sha256'], 'recorded one producer run changed')
    datasets = verification['datasets']
    require(len(datasets) == 2 and [item['figure'] for item in datasets] == ['4.28', '4.29'], 'dataset association changed')
    for dataset, record in zip(datasets, author['figures']):
        metadata = load(REPO/dataset['metadata_path'])
        with (REPO/dataset['csv_path']).open(newline='') as stream:
            reader = csv.DictReader(stream)
            rows = list(reader)
        require(len(rows) == metadata['output']['samples'] == dataset['samples'] == 282 and reader.fieldnames == dataset['columns'] == metadata['output']['columns'], 'saved row/column association changed')
        require(dataset['csv_sha256'] == metadata['output']['csv_sha256'] == PINNED[dataset['csv_path']]
                and dataset['metadata_sha256'] == PINNED[dataset['metadata_path']]
                and metadata['output']['generator_sha256'] == dataset['producer_sha256'] == PINNED[PRODUCER], 'saved data/producer association changed')
        for key in ('source', 'simulation_context', 'unit_interpretation'):
            require(dataset[key] == metadata[key], 'frozen source/context declarations changed')
        context, units = metadata['simulation_context'], metadata['unit_interpretation']
        require(context['code_label_in_dissertation'] == 'Allegra' and context['drive_shot'] == 17133 and context['component_signs_preserved'] is True
                and context['experimental_measurement'] is False and context['FLASH_result'] is False
                and units['literal_conditional_scale_to_A_per_m2'] == 1e10 and units['original_normalization_verified'] is False
                and units['original_simulation_output_units_confirmed'] is False, 'legacy/conditional unit qualification changed')
        require(all(math.isfinite(float(row['Jz_literal_MA_per_cm2'])) and float(row['Jz_literal_MA_per_cm2']) < 0 for row in rows), 'signed source sample declarations changed')
        require(metadata['nominal_initial_depth']['actual_moving_face_coordinate'] is False and metadata['readout_bounds']['correlated_display_bounds_only'] is True
                and metadata['readout_bounds']['physical_or_simulation_uncertainty_quantified'] is False, 'display bounds promoted to physical evidence')
        require(sha(WORK/'recovery'/dataset['source_geometry_filename']) == dataset['source_geometry_sha256'] == record['source_geometry_sha256'], 'source geometry pin changed')
        for name, digest in dataset['QA_files_sha256'].items():
            require(sha(WORK/'recovery'/name) == digest, 'QA artifact pin changed')
    docs = load(WORK/'documentation-association.json')
    require(docs == verification['documentation_association'] and docs['passed'] is True and docs['prior_manifest_targets'] == 45
            and docs['all_prior_artifacts_preserved'] is True and docs['source_record_unchanged'] is True
            and docs['original_normalization_verified'] is False and docs['actual_flash_run'] is False
            and docs['old_recoveries_repeated'] is False, 'documentation association incomplete')
    for name, digest in docs['after_sha256'].items():
        require(sha(REPO/name) == digest, 'documentation artifact changed')
    visual = load(WORK/'visual-review.json')
    require(visual['source_recovery_repeated'] is False, 'unexpected QA recovery replay')
    for name, digest in visual['files_sha256'].items():
        require(sha(WORK/'recovery'/name) == digest, 'viewed QA pin changed')
    results = verification['results']
    require(results['independent_readback_passed'] is True and results['all_retained_signed_negative'] is True
            and results['source_acquisition_metadata_verified'] is True, 'delivery results incomplete')
    for key in ('physical_normalization_verified', 'physical_truth_validated', 'portable_executions_performed', 'packaging_source_recovery_repeated',
                'old_recoveries_repeated', 'old_test_suites_repeated', 'full_source_pdf_included', 'raw_source_images_or_pages_included', 'source_acquisition_physical_parameters_adopted'):
        require(results[key] is False, 'unsupported delivery result: '+key)
    require(not any('test' in key and key != 'old_test_suites_repeated' for key in results), 'this pass has no test-count claim')
    return datasets


def verify_acquisition(verification):
    metadata = load(WORK/'source-acquisition/metadata_report.json')
    access = load(WORK/'source-acquisition/locations/acquisition_state.json')
    require(metadata == verification['source_acquisition_metadata'] and metadata['all_target_metadata_verified'] is True
            and metadata['full_text_acquired'] is False and metadata['surface_grade_verified'] is False
            and metadata['physical_rates_or_monolayer_convention_adopted'] is False, 'citation acquisition limits changed')
    require(verification['source_acquisition_metadata_sha256'] == EVIDENCE_PINS['source-acquisition/metadata_report.json']
            and verification['source_acquisition_access_sha256'] == EVIDENCE_PINS['source-acquisition/locations/acquisition_state.json'], 'citation/access pin mismatch')
    expected = {'joly_2000': '10.1016/S0042-207X(00)00393-6', 'li_dylla_1995': '10.1116/1.579673'}
    require({item['lead']: item['doi'] for item in metadata['records']} == expected, 'citation identity changed')
    for item in metadata['records']:
        require(item['metadata_verified'] is True and sha(item['file']) == item['sha256'], 'registry artifact changed')
    require(access['status'] == verification['source_acquisition_access']['status'] == 'metadata_only_fulltext_blocked'
            and access['full_text_acquired'] is False and access['physical_rate_or_monolayer_or_wall_energy_adopted'] is False
            and access['request_counts']['retries'] == 0 and access['request_counts']['repository_or_PDF_downloads'] == 0
            and access['frozen_selection_files_changed'] is False, 'blocked access state changed')
    validate_maps(access)
    require({item['lead']: item['doi'] for item in access['records']} == expected, 'access citation identity changed')
    for item in access['records']:
        require(item['full_text_acquired'] is False and item['publisher_auth_requirement_established'] is False
                and item['OpenAlex']['oa_status'] == 'closed' and item['OpenAlex']['best_oa_location'] is None, 'access evidence promoted to full text')
    require([item['access_state'] for item in access['records']] == ['proxy_CONNECT_403_before_upstream_status', 'official_publisher_HTTP403'], 'recorded blocked routes changed')
    return metadata, access


def verify_commit_correction():
    correction = load(WORK/'commit-check-correction.json')
    require(correction['scientific_recovery_or_verification_repeated'] is False, 'unexpected scientific replay during commit correction')
    require(all(item['CRLF_records'] == 283 and item['other_trailing_spaces_or_tabs'] is False for item in correction['CSV_encoding_checks'].values()), 'CSV-aware correction evidence changed')
    records = [json.loads(line) for line in (WORK/'commands.jsonl').read_text().splitlines()]
    names = {'commit-current-depth-recovery.log', 'commit-current-depth-provenance-guide.log'}
    failures = [item for item in records if Path(item['log']).name in names]
    require(len(failures) == 2 and all(item['exit_code'] == 1 and sha(item['log']) == item['log_sha256'] for item in failures), 'original failed commit-check evidence missing')
    return correction


def main():
    status_path = WORK.parent/'mitl-upstream-status.json'
    with (WORK.parent/'mitl-upstream-status.lock').open('a+') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        before = status_path.read_bytes()
        status, claim = json.loads(before), load(WORK/'lease-claim.json')
        now = datetime.datetime.now(datetime.timezone.utc)
        require(status['active_lease_owner'] == claim['pass_id'] == WORK.name and status['active_editing_lease_until_utc'] == claim['lease_until_utc']
                and datetime.datetime.fromisoformat(claim['lease_until_utc']) > now, 'lease changed or expired')
        require(status['last_complete_commit'] == claim['base_commit'] == BASE and status['handoff'] == claim['prior_handoff']
                and not (WORK/'completion.json').exists(), 'prior checkpoint changed or completion replay attempted')
        require(sha(claim['prior_handoff_document']) == claim['prior_handoff_document_sha256'], 'latest prior handoff changed')
        preserved = {key: status[key] for key in ('source_ledger_admission', 'reconstructed_current_17133', 'constraints', 'blockers')}
        delivery, frozen, verification = load(WORK/'delivery_verification.json'), load(WORK/'frozen_delivery.json'), load(OUT/'verification.json')
        public_pins = verify_delivery(delivery, frozen, verification)
        datasets = verify_evidence(verification)
        citation_metadata, access = verify_acquisition(verification)
        correction = verify_commit_correction()
        selection_path = WORK/'next-upstream-selection/selection.json'
        selection = load(selection_path)
        require(selection['status'] == 'selected' and selection['source_recovery_performed'] is False
                and selection['axis_fit_or_alignment_math_performed'] is False and selection['old_suites_or_source_evolution_repeated'] is False
                and selection['public_files_edited'] is False, 'next selection was altered or executed')
        next_task = selection['selected_task']
        require(sha(selection_path) == verification['selection_sha256'] and load(OUT/'next_task.json')['task'] == verification['next_task'] == next_task, 'next selected task association changed')
        remaining = [dict(item) for item in status['next_work'] if 2 <= item['priority'] <= 6]
        require([item['priority'] for item in remaining] == [2, 3, 4, 5, 6], 'pending queue2..6 changed')
        clean_head()
        now = datetime.datetime.now(datetime.timezone.utc)
        require(datetime.datetime.fromisoformat(claim['lease_until_utc']) > now, 'lease expired during completion')
        history, prior = status.setdefault('verification_history', []), status.setdefault('prior_handoffs', [])
        if not any(item['pass_id'] == status['last_completed_pass_id'] for item in history):
            history.append({'pass_id': status['last_completed_pass_id'], 'commit': status['last_complete_commit'], 'handoff': status['handoff'],
                            'handoff_sha256': status['handoff_sha256'], 'verification': status['last_verified_suite']})
        if status['handoff'] not in prior:
            prior.append(status['handoff'])
        status.update(last_complete_commit=HEAD, last_completed_pass_id=WORK.name, last_update_utc=now.isoformat(),
            handoff=delivery['archive'], handoff_sha256=delivery['sha256'], handoff_bytes=delivery['bytes'],
            handoff_document=str(OUT/'systems-mitl-current-depth-recovery-10192026.md'), active_lease_owner=None,
            active_editing_lease_until_utc=None, reserved_paths=[], active_completed_subtasks=[],
            active_phase='Completed four signed legacy J_z depth profiles; two legacy current insets and limited C19 display comparison selected next')
        status['last_verified_suite'] = {**verification['results'], 'scope': 'New signed current-depth raster recovery and independent source/readout controls; no old suite or portable execution',
            'verification_record': str(OUT/'verification.json'), 'delivery_manifest_entries': delivery['manifest_entries'],
            'public_files_byte_identical': 8, 'packaging_wrappers': 2, 'actual_flash_run': False, 'post_freeze_commands': str(WORK/'commands.jsonl')}
        status['current_depth_recovery'] = {'tool': str(REPO/PRODUCER), 'tool_sha256': PINNED[PRODUCER],
            'guide': str(REPO/'docs/dissertation_current_depth_recovery.md'), 'source_pdf_sha256': PDF_SHA,
            'source_kind': 'reconstructed_published_legacy_simulation_raster', 'code_label': 'Allegra', 'drive_shot': 17133,
            'figures': [{**item, 'csv_path': str(REPO/item['csv_path']), 'metadata_path': str(REPO/item['metadata_path'])} for item in datasets],
            **COUNTERS, 'independent_completion': str(WORK/'independent-verification/completion.json'),
            'independent_completion_sha256': EVIDENCE_PINS['independent-verification/completion.json'],
            'author_verification': str(WORK/'recovery/author-verification.json'), 'author_verification_sha256': EVIDENCE_PINS['recovery/author-verification.json'],
            'new_positive_producer_runs': 1, 'positive_producer_called_for_independent_verification': False,
            'documentation_association': str(WORK/'documentation-association.json'), 'documentation_association_sha256': EVIDENCE_PINS['documentation-association.json'],
            'all_retained_signed_negative': True, 'literal_conditional_scale_to_A_per_m2': 1e10,
            'original_normalization_verified': False, 'original_simulation_output_units_confirmed': False,
            'physical_measurement': False, 'physical_uncertainty_established': False, 'actual_moving_faces_recovered': False,
            'current_or_Ampere_closure_inferred': False, 'J_squared_heating_inferred': False,
            'trigger_or_simulation_clock_registered': False, 'actual_flash_run': False,
            'commit_check_correction': str(WORK/'commit-check-correction.json'), 'commit_check_correction_sha256': EVIDENCE_PINS['commit-check-correction.json'],
            'failed_commit_check_attempts_preserved': 2, 'scientific_checks_repeated_for_commit_correction': False,
            'limits': 'Signed smooth interior display support only; complete excluded-row catalogs retained. Literal printed units are conditional, original normalization and moving faces remain unknown. No whole-depth integral, J-squared heating, physical uncertainty, current/field closure or FLASH validation.'}
        status['source_desorption_acquisition'] = {'metadata_report': str(WORK/'source-acquisition/metadata_report.json'),
            'metadata_report_sha256': EVIDENCE_PINS['source-acquisition/metadata_report.json'], 'metadata_records': citation_metadata['records'],
            'access_record': str(WORK/'source-acquisition/locations/acquisition_state.json'), 'access_record_sha256': EVIDENCE_PINS['source-acquisition/locations/acquisition_state.json'],
            'citation_metadata_verified': True, 'status': 'blocked_on_full_text', 'recorded_access_status': access['status'],
            'records': access['records'], 'request_counts': access['request_counts'], 'full_text_acquired': False,
            'physical_parameters_adopted': 0, 'monolayer_convention_adopted': False, 'wall_energy_adopted': False,
            'new_assessment_gate': 'Only after a newly verified legitimate full-text location or owner-supplied copy appears; do not repeat the recorded blocked routes.',
            'limits': access['limits']}
        status['next_work'] = [{'priority': 1, 'task': next_task, 'selection': str(selection_path), 'selection_sha256': EVIDENCE_PINS['next-upstream-selection/selection.json'],
            'limits': 'Finite published display support only; no physical trigger registration, sole-offset assumption, time warp or automatic amplitude correction.'}]+remaining+[
            {'priority': 7, 'task': 'Assess Joly2000 water TPD and Li-Dylla1995 context only if a newly verified legitimate full-text location or owner-supplied copy appears.',
             'status': 'blocked_on_full_text', 'access_record': str(WORK/'source-acquisition/locations/acquisition_state.json'),
             'access_record_sha256': EVIDENCE_PINS['source-acquisition/locations/acquisition_state.json'], 'retry_recorded_blocked_routes': False}]
        require(all(status[key] == value for key, value in preserved.items()), 'prior milestones/constraints/blockers were changed')
        status['completed_milestones'].extend([
            'Recovered four signed J_z depth profiles from published Allegra figures4.28/4.29: 564 retained rows,1020 exclusions and1584 catalogued native rows. Independent exact-rational readback checked10152 numeric cells and28 tick anchors; original normalization and physical heating remain unverified.',
            'Four new source guards reject invalid pins/ticks or manufactured multiple runs; two invalid recovery entries reach zero physical row extractions and no positive producer replay. One new author recovery, QA and documentation association preserve45 prior targets and source identity.',
            'Verified two new desorption DOI citations and bounded official/OpenAlex access evidence. Both full texts remain unavailable in the recorded routes; zero physical parameters adopted. Future full-text assessment is gated on a new legitimate location/copy.',
            f'Two local commits through {HEAD[:7]};8 public files and2 wrappers match actual archive {delivery["sha256"]}. No old recovery/suite or portable execution; CSV-aware commit correction preserves two failed attempts without changed source/data or repeated scientific checks.'
        ])
        history.append({'pass_id': WORK.name, 'commit': HEAD, 'handoff': delivery['archive'], 'handoff_sha256': delivery['sha256'], 'verification': status['last_verified_suite']})
        encoded = (json.dumps(status, indent=2, allow_nan=False)+'\n').encode()
        result = {'utc': now.isoformat(), 'event': 'completed_and_next_selected', 'pass_id': WORK.name, 'commit': HEAD,
            'archive': delivery['archive'], 'archive_sha256': delivery['sha256'], 'archive_bytes': delivery['bytes'],
            'actual_archive_reverified': True, 'public_scope_sha256': public_pins, **COUNTERS, 'physical_normalization_verified': False,
            'portable_executions_performed': False, 'old_test_suites_repeated': False, 'full_text_acquired': False, 'physical_parameters_adopted': 0,
            'exact_commands': str(WORK/'commands.jsonl'), 'status_before_sha256': hashlib.sha256(before).hexdigest(),
            'status_after_sha256': hashlib.sha256(encoded).hexdigest(), 'lease_released': True, 'reserved_paths': [],
            'next': next_task, 'next_selection_sha256': EVIDENCE_PINS['next-upstream-selection/selection.json'],
            'gated_full_text_assessment_status': 'blocked_on_full_text',
            'limits': 'Reconstructed legacy signed raster curves with conditional literal units, not physical measurements or validated heating input. Actual surfaces, original normalization, source/diagnostic clocks, physical surface parameters and configured licensed FLASH remain unresolved.'}
        (WORK/'status-before-completion.json').write_bytes(before)
        temporary = status_path.with_suffix('.json.new')
        temporary.write_bytes(encoded)
        temporary.replace(status_path)
        (WORK/'completion.json').write_text(json.dumps(result, indent=2, allow_nan=False)+'\n')
        with (WORK.parent/'mitl-upstream-journal.jsonl').open('a') as stream:
            stream.write(json.dumps(result, allow_nan=False)+'\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
