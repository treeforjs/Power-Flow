"""Acquire two newly identified DOI registry records without adopting inputs."""
from concurrent.futures import ThreadPoolExecutor
import datetime
import hashlib
import json
from pathlib import Path
import urllib.error
import urllib.parse
import urllib.request

work = Path(__file__).resolve().parent
out = work/'source-acquisition'
out.mkdir(exist_ok=False)
leads = [('joly_2000', '10.1016/S0042-207X(00)00393-6'), ('li_dylla_1995', '10.1116/1.579673')]
sha = lambda data: hashlib.sha256(data).hexdigest()


def acquire(item):
    name, doi = item
    url = 'https://api.crossref.org/works/'+urllib.parse.quote(doi, safe='/')
    request = urllib.request.Request(url, headers={'Accept':'application/json',
        'User-Agent':'MITL-dissertation-source-recovery/1.0'})
    result = {'lead':name, 'doi':doi, 'requested_url':url,
        'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    try:
        with urllib.request.urlopen(request, timeout=35) as response:
            raw = response.read(4*1024*1024+1)
            if len(raw)>4*1024*1024:
                raise ValueError('DOI record exceeds bounded metadata read')
            result.update(http_status=response.status, final_url=response.url,
                content_type=response.headers.get('Content-Type'), bytes=len(raw), sha256=sha(raw))
        path = out/(name+'_crossref.json')
        path.write_bytes(raw)
        document = json.loads(raw)
        message = document['message']
        assert message['DOI'].casefold()==doi.casefold()
        result.update(metadata_verified=True, file=str(path),
            record={k:message.get(k) for k in ('DOI','title','author','container-title','publisher',
                'published','volume','issue','page','type','URL','link','license','relation','abstract')})
    except urllib.error.HTTPError as error:
        raw = error.read(1024*1024)
        path = out/(name+'_http_error.txt')
        path.write_bytes(raw)
        result.update(metadata_verified=False, http_status=error.code, final_url=error.url,
            error_type=type(error).__name__, file=str(path), bytes=len(raw), sha256=sha(raw))
    except Exception as error:
        result.update(metadata_verified=False, error_type=type(error).__name__, error=str(error))
    result['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
    return result


with ThreadPoolExecutor(max_workers=2) as pool:
    records = list(pool.map(acquire, leads))
report = {'schema':'mitl-new-primary-desorption-doi-metadata-v1',
    'script_sha256':sha(Path(__file__).read_bytes()), 'records':records,
    'all_target_metadata_verified':all(r['metadata_verified'] for r in records),
    'full_text_acquired':False, 'surface_grade_verified':False,
    'physical_rates_or_monolayer_convention_adopted':False,
    'limits':['DOI registry metadata verifies citation identity only.',
        'Target full text, actual substrate/preparation, dose, inventory convention and useful experimental data remain uninspected.',
        'No kinetic barrier, thermodynamic removal energy, coverage or nanosecond extrapolation is adopted.']}
(out/'metadata_report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
