"""Bind the new source profiles into documentation without rewriting old data."""
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import yaml

repo = Path('/workspace/Power-Flow')
work = Path(__file__).resolve().parent
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
manifest_path = repo/'data/dissertation/recovery_manifest.yaml'
docs_path = repo/'docs/dissertation_recovery.md'
guide_path = repo/'docs/dissertation_current_depth_recovery.md'
before = {str(p.relative_to(repo)):sha(p) for p in (manifest_path,docs_path,guide_path)}
original = manifest_path.read_text()
parsed_before = yaml.safe_load(original)
prepared = original
datasets = []
for fig in ('4.28','4.29'):
    stem = 'figure_'+fig.replace('.','_')+'_current_depth'
    metadata_path = repo/'data/dissertation'/f'{stem}.json'
    m = json.loads(metadata_path.read_text())
    csv = repo/'data/dissertation'/m['output']['csv_filename']
    assert m['source']['figure'] == fig
    assert m['output']['csv_sha256'] == sha(csv)
    assert m['output']['samples_by_profile'] == {'foil_edge':141,'foil_middle':141}
    assert m['unit_interpretation']['original_normalization_verified'] is False
    artifact = {'file':csv.name,'metadata':metadata_path.name,
        'generator':'tools/recover_dissertation_depth_current.py','status':'digitized_published_simulation',
        'csv_sha256':sha(csv),'content':'282 signed conservative-interior J_z samples; 141 each for foil-edge and foil-middle labels',
        'time_s':m['simulation_context']['time_s'],
        'source_current_axis_label':m['unit_interpretation']['source_current_axis_label'],
        'source_coordinate_axis_label':m['unit_interpretation']['source_gap_axis_label'],
        'literal_conditional_scale_to_A_per_m2':m['unit_interpretation']['literal_conditional_scale_to_A_per_m2'],
        'original_normalization_verified':False,
        'gap_coordinate_extent_mm':m['output']['gap_coordinate_extent_mm'],
        'nominal_initial_depth_extent_um':m['output']['nominal_initial_depth_extent_um'],
        'retained_native_rows':[640,780],'candidate_rows_per_profile':396,'excluded_rows_per_profile':255,
        'digitization_estimates':{'recipe':'Full exact-color run plus +/-2 pixels and maximum tick-fit residual; position uses +/-2 pixels and its fit residual.',
            'meaning':'Correlated display readout bounds only; physical or simulation uncertainty remains unquantified.'}}
    identifier = 'fig_'+fig.replace('.','_')
    target = next(item for item in parsed_before['reconstruction_targets'] if item['id']==identifier)
    next_marker = '\n- id: '
    start = prepared.index('- id: '+identifier+'\n')
    stop = prepared.find(next_marker,start+1)
    assert stop > start
    block = prepared[start:stop]
    assert stem not in block
    fragment = yaml.safe_dump({'recovered_artifacts':[artifact]},sort_keys=False,allow_unicode=True,width=108)
    fragment = fragment[len('recovered_artifacts:\n'):]
    fragment = ''.join('  '+line+'\n' for line in fragment.splitlines())
    assert block.count('  still_pending:\n') == 1
    block = block.replace('  still_pending:\n',fragment+'  still_pending:\n')
    old = '  - drive-current, magnetic-field and current-density panels\n'
    assert block.count(old) == 1
    block = block.replace(old,'  - legacy simulation drive-current inset and magnetic gap panel\n')
    prepared = prepared[:start]+block+prepared[stop:]
    datasets.append({'figure':fig,'csv_sha256':sha(csv),'metadata_sha256':sha(metadata_path),
        'new_artifact':artifact,'original_artifact_count':len(target['recovered_artifacts'])})

parsed_after = yaml.safe_load(prepared)
assert parsed_after['source'] == parsed_before['source']
assert len(parsed_after['reconstruction_targets']) == len(parsed_before['reconstruction_targets'])
changed = []
for old,new in zip(parsed_before['reconstruction_targets'],parsed_after['reconstruction_targets']):
    assert old['id']==new['id']
    if old!=new:
        assert old['id'] in {'fig_4_28','fig_4_29'}
        restored = copy.deepcopy(new)
        assert restored['recovered_artifacts'][:-1] == old['recovered_artifacts']
        restored['recovered_artifacts']=old['recovered_artifacts']
        restored['still_pending']=old['still_pending']
        assert restored==old
        changed.append(old['id'])
assert changed == ['fig_4_28','fig_4_29']

docs = docs_path.read_text()
old = 'temperatures and Fig. 4.30 EM width profiles partially recovered; other field/current panels pending'
assert docs.count(old)==1
docs=docs.replace(old,'temperatures, J_z depth profiles and Fig. 4.30 EM width profiles partially recovered; drive insets and magnetic gap panels pending')
old = 'The magnetic-field/current-density depth panels in Figs. 4.28 and 4.29 remain unrecovered.'
assert docs.count(old)==1
docs=docs.replace(old,'The conservative current-density interiors in Figs. 4.28 and 4.29 are recovered below; their magnetic gap panels and legacy simulation drive insets remain pending.')
section = '''## Recovered current-density depth profiles

The lower-left panels of Figs. 4.28 and 4.29 now provide four signed J_z curves: foil-edge and foil-middle at 40 and 60 ns. Each profile retains 141 native rows, for 564 samples over approximately 2.52232–2.66407 mm from the gap centre. The nominal initial-depth coordinate is 22.3201–164.068 um. It does not identify a moving surface or material boundary.

The [Fig. 4.28 CSV](../data/dissertation/figure_4_28_current_depth.csv) and [metadata](../data/dissertation/figure_4_28_current_depth.json), and [Fig. 4.29 CSV](../data/dissertation/figure_4_29_current_depth.csv) and [metadata](../data/dissertation/figure_4_29_current_depth.json), preserve exact-color runs, signed values, readout bounds and every excluded row. The mask avoids legends, exterior/zero branches and visible corners/boundary ramps. Raster rows and readout bounds remain correlated.

The horizontal axis is J_z [MA/cm²]; the vertical axis is distance from the middle of the A–K gap. Separate SI columns apply only the literal 10¹⁰ A/m² conversion. Original normalization remains unverified, so neither these profiles nor the width lineouts establish J²/sigma heating, a full current integral or Ampere-law closure. These are published legacy simulation profiles, with no physical current-density measurement or FLASH result asserted. See the [recovery guide](dissertation_current_depth_recovery.md) for reproduction and limitations.

'''
assert docs.count('## Recovered electromagnetic width profiles')==1
docs=docs.replace('## Recovered electromagnetic width profiles',section+'## Recovered electromagnetic width profiles')
manifest_path.write_text(prepared)
docs_path.write_text(docs)
report={'schema':'mitl-current-depth-documentation-association-v1','passed':True,
    'script_sha256':sha(__file__),'datasets':datasets,'prior_manifest_targets':len(parsed_before['reconstruction_targets']),
    'all_prior_artifacts_preserved':True,'changed_existing_targets':changed,'source_record_unchanged':True,
    'before_sha256':before,'after_sha256':{str(p.relative_to(repo)):sha(p) for p in (manifest_path,docs_path,guide_path)},
    'original_normalization_verified':False,'actual_flash_run':False,'old_recoveries_repeated':False}
(work/'documentation-association.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
