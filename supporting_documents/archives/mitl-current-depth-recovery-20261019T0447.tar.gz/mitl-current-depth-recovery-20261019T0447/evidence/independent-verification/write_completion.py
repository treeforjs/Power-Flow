"""Freeze existing current-depth verification evidence without repeating it."""
import datetime
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent
WORK=ROOT.parent
REPO=Path('/workspace/Power-Flow')
READBACK_SHA='00440d5dfad25ab1450ad981e5eca47f2a0c0fbb278510fb27af5b458996855e'
GUARDS_SHA='451967a8653b7d8596eb6994eb03b43336e028fdc379c2ad4be5e034e1845cd7'
LABELS=(
    'independent-native-current-depth-inspection',
    'independent-current-depth-axis-inventory',
    'independent-current-depth-dark-raster-inventory',
    'independent-current-depth-coordinate-reference',
    'independent-initial-geometry-context',
    'independent-current-depth-final-readback',
    'independent-current-depth-new-source-guards',
)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def load(path):
    return json.loads(path.read_text())

assert not (ROOT/'completion.json').exists()
assert sha(ROOT/'readback.json')==READBACK_SHA
assert sha(ROOT/'source-guards.json')==GUARDS_SHA
readback=load(ROOT/'readback.json')
guards=load(ROOT/'source-guards.json')
assert readback['all_checks_passed'] is True and guards['all_checks_passed'] is True
expected={'figures':2,'profiles':4,'retained_rows':564,'excluded_rows':1020,
    'native_rows_catalogued':1584,'numeric_csv_cells_checked':10152,'tick_anchors_checked':28}
assert all(readback[key]==value for key,value in expected.items())
assert readback['all_retained_signed_negative'] is True
assert readback['physical_normalization_verified'] is False
assert readback['J_squared_heating_inferred'] is False
assert readback['successful_producer_calls']==readback['old_recovery_calls']==0
assert guards['source_guard_rejections']==4 and guards['successful_recovery_replays']==0
assert guards['physical_row_extraction_calls_by_invalid_source_controls']==0
assert guards['guarded_recovery_entry_attempts']==2
assert guards['positive_producer_called_for_verification'] is False
assert guards['old_recovery_or_suite_repeated'] is False
assert all(item['rejected'] is True for item in guards['source_guard_controls'])
assert guards['public_source_sha256']==readback['public_source_sha256']
for relative,digest in readback['public_source_sha256'].items():
    assert sha(REPO/relative)==digest
for path,digest in readback['input_sha256'].items():
    actual=Path(path) if Path(path).is_absolute() else REPO/path
    assert sha(actual)==digest
entries=[json.loads(line) for line in (WORK/'commands.jsonl').read_text().splitlines()]
selected=[]
for label in LABELS:
    matches=[entry for entry in entries if Path(entry['log']).name==label+'.log']
    assert len(matches)==1
    entry=matches[0]
    assert entry['exit_code']==0 and sha(Path(entry['log']))==entry['log_sha256']
    selected.append(entry)
artifacts={str(path.relative_to(WORK)):sha(path) for path in sorted(ROOT.iterdir()) if path.is_file()}
for entry in selected:
    artifacts[Path(entry['log']).name]=entry['log_sha256']
result={
    'schema':'mitl-independent-current-depth-completion-v1',
    'all_checks_passed':True,'status':'passed',
    'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'public_source_sha256':readback['public_source_sha256'],
    'artifact_sha256':artifacts,
    'source_pdf_sha256':guards['source_pdf_sha256'],
    'source_kind':'reconstructed_published_legacy_simulation_raster',
    **expected,
    'all_retained_signed_negative':True,
    'source_guard_rejections':4,
    'guarded_recovery_entry_attempts':2,
    'successful_producer_replays':0,
    'positive_producer_called_for_verification':False,
    'physical_row_extraction_calls_by_invalid_source_controls':0,
    'old_suites_repeated':False,
    'old_recoveries_repeated':False,
    'portable_test_execution_claimed':False,
    'generic_current_drive_inspector_runs':0,
    'physical_normalization_verified':False,
    'original_simulation_output_units_confirmed':False,
    'J_squared_heating_inferred':False,
    'actual_material_boundaries_recovered':False,
    'physical_uncertainty_established':False,
    'measured_current_density':False,
    'FLASH_output':False,
    'readback_sha256':READBACK_SHA,
    'source_guards_sha256':GUARDS_SHA,
    'source_guard_controls':guards['source_guard_controls'],
    'cases':readback['cases'],
    'commands':selected,
    'archive_excluded_paths':['independent-verification/source-local/'],
    'limits':[
        'The four curves are reconstructed signed raster lineouts from published legacy Allegra simulations at40/60ns for Mykonos17133. They are not measured electromagnetic data or FLASH output.',
        'Independent native pixels, source text, visible dark tick tails and exact-rational calibration verify564 retained rows and all1020 excluded rows. The conservative row640..780 mask is display support, not a material interface.',
        'The horizontal source axis is literal J_z [MA/cm²]; the vertical axis is distance from the middle of the AK gap. The1e10 A/m² factor is a conditional literal conversion, with original units/normalization unverified.',
        'Full matched-color-run plus2pixel/tick-fit envelopes are correlated display readout bounds, not independent noise, confidence intervals or physical uncertainty.',
        'The2.5mm face and nominal depth are explicit initial-geometry references from the5mm gap. Actual moving faces, transverse edge offset, endpoint peak and whole-depth/full-cross-section support remain unavailable.',
        'Two deliberately invalid guarded recovery attempts reject before row extraction; pure wrong-tick and manufactured multi-run controls also reject. No positive producer was called for verification, and no recovered output was generated by these controls.',
        'No old producer or test suite, current-drive inspector, source evolution, current integral, Ampere law, current-density-squared heating, spectrum, external job or actual FLASH run was repeated or inferred.',
    ],
}
target=ROOT/'completion.json'
target.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps({'completion':str(target),'sha256':sha(target),'all_checks_passed':True,
    **expected,'source_guard_rejections':4,'successful_producer_replays':0},indent=2))
