"""New failure controls for the new current-depth recovery contract only."""
import copy
import hashlib
import importlib.util
import json
from pathlib import Path

import numpy as np
from PIL import Image

ROOT=Path(__file__).resolve().parent
REPO=Path('/workspace/Power-Flow')
PDF=Path('/workspace/research_sources/smtrevor_1.pdf')
TOOL=REPO/'tools/recover_dissertation_depth_current.py'
PIN='77926d95a0e6c01001d7268200a34aa58457cc33d3de051f45f9d0a7ebeb8982'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

assert not (ROOT/'source-guards.json').exists()
assert sha(TOOL)==PIN
readback=json.loads((ROOT/'readback.json').read_text())
assert readback['all_checks_passed'] is True
for relative,digest in readback['public_source_sha256'].items():
    assert sha(REPO/relative)==digest
spec=importlib.util.spec_from_file_location('new_current_depth_source_control',TOOL)
recovery=importlib.util.module_from_spec(spec)
spec.loader.exec_module(recovery)
controls=[]
row_selection_calls=0
original_make_rows=recovery.make_rows

def forbid_rows(*args,**kwargs):
    global row_selection_calls
    row_selection_calls+=1
    raise AssertionError('Invalid source reached physical row extraction')

def rejected(label,call,fragment):
    try:
        call()
    except ValueError as error:
        assert fragment in str(error), (label,str(error))
        controls.append({'case':label,'rejected':True,'reason':str(error)})
    else:
        raise AssertionError('Invalid source accepted: '+label)

wrong=ROOT/'wrong-source-control.pdf'
assert not wrong.exists()
wrong.write_bytes(b'%PDF-1.0\nDeliberately invalid source guard fixture.\n')
recovery.make_rows=forbid_rows
try:
    rejected('wrong_pdf_pin',lambda:recovery.recover(wrong),'source PDF SHA256 mismatch')
    saved_figures=recovery.FIGURES
    recovery.FIGURES=copy.deepcopy(saved_figures)
    recovery.FIGURES[0]['rgb_sha256']='0'*64
    try:
        rejected('wrong_native_RGB_pin',lambda:recovery.recover(PDF),'native source RGB SHA256 mismatch')
    finally:
        recovery.FIGURES=saved_figures
finally:
    recovery.make_rows=original_make_rows
assert row_selection_calls==0

image=Image.open(ROOT/'source-local/figure-4.28-native.png').convert('RGB')
pixels=np.asarray(image)
assert hashlib.sha256(image.tobytes()).hexdigest()==recovery.FIGURES[0]['rgb_sha256']
saved_ticks=recovery.CURRENT_TICK_PIXELS
recovery.CURRENT_TICK_PIXELS=(saved_ticks[0]+1,*saved_ticks[1:])
try:
    rejected('wrong_native_current_tick_anchor',lambda:recovery.validate_ticks(pixels),
             'J_z native tick anchors do not match configured calibration')
finally:
    recovery.CURRENT_TICK_PIXELS=saved_ticks

synthetic=np.full((901,478,3),255,dtype=np.uint8)
rgb=(154,205,50)
synthetic[700,200:203]=rgb
synthetic[700,300:303]=rgb
selected,reason,runs=recovery.select_row(synthetic,700,rgb)
assert selected is None and reason=='multiple_exact_colour_runs' and runs==[[200,202],[300,302]]
controls.append({'case':'synthetic_multiple_exact_colour_runs','rejected':True,
    'reason':reason,'exact_colour_runs_inclusive_x':runs,
    'fixture_status':'manufactured_selector_failure_control'})
assert len(controls)==4 and all(c['rejected'] for c in controls)
assert sha(TOOL)==PIN
for relative,digest in readback['public_source_sha256'].items():
    assert sha(REPO/relative)==digest
result={'schema':'mitl-current-depth-new-source-guards-v1','all_checks_passed':True,
    'script_sha256':sha(Path(__file__)),'public_source_sha256':readback['public_source_sha256'],
    'readback_sha256':sha(ROOT/'readback.json'),'source_pdf_sha256':sha(PDF),
    'wrong_source_control_sha256':sha(wrong),'source_guard_rejections':4,
    'guarded_recovery_entry_attempts':2,'successful_recovery_replays':0,
    'physical_row_extraction_calls_by_invalid_source_controls':row_selection_calls,
    'source_guard_controls':controls,'positive_producer_called_for_verification':False,
    'old_recovery_or_suite_repeated':False,
    'limits':['Only the new guarded recovery module and its pure tick/row selectors are imported.',
        'Wrong PDF and native-image pins reject before row extraction. Tick and multi-run cases exercise the new pure selectors with deliberately invalid declarations or manufactured pixels.',
        'The recovery entry prepares declared analytic calibration before native-image checks; these invalid controls supply no successful recovered curve or output.',
        'No original source file, public declaration or recovered artifact is modified; all monkeypatches are local and restored.']}
out=ROOT/'source-guards.json'
out.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps({'output':str(out),'sha256':sha(out),'all_checks_passed':True,
    'source_guard_rejections':4,'successful_recovery_replays':0},indent=2))
