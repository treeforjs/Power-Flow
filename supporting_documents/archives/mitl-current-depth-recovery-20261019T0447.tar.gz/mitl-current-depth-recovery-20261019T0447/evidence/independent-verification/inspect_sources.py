"""Independently inspect the published native current-depth panels."""
import hashlib
import io
import json
from pathlib import Path

import pymupdf
from PIL import Image

ROOT = Path(__file__).resolve().parent
LOCAL = ROOT/'source-local'
PDF = Path('/workspace/research_sources/smtrevor_1.pdf')
PIN = '1d7b1f9c191a37e94f1cc3634587750f1af35b07eb13e0b94c60f3da47495ed7'
CASES = [(118,2847,'4.28'),(120,2870,'4.29')]

def digest(data):
    return hashlib.sha256(data).hexdigest()

assert digest(PDF.read_bytes()) == PIN
LOCAL.mkdir(parents=True,exist_ok=True)
doc=pymupdf.open(PDF)
records=[]
for page_index,xref,figure in CASES:
    page=doc[page_index]
    image=Image.open(io.BytesIO(doc.extract_image(xref)['image'])).convert('RGB')
    assert image.size == (975,975)
    full=LOCAL/f'figure-{figure}-native.png'
    image.save(full)
    crop=LOCAL/f'figure-{figure}-current-panel.png'
    image.crop((0,470,540,975)).resize((1080,1010)).save(crop)
    colors={}
    pixels=image.load()
    for color,name in [((154,205,50),'foil_edge'),((0,128,0),'foil_middle')]:
        found=[(x,y) for y in range(470,975) for x in range(0,540) if pixels[x,y]==color]
        colors[name]={'RGB':list(color),'pixel_count':len(found),
            'bbox_pixels':[min(x for x,y in found),min(y for x,y in found),max(x for x,y in found),max(y for x,y in found)],
            'by_column':{str(x):[y for xx,y in found if xx==x] for x in sorted(set(x for x,y in found))}}
    records.append({'figure':figure,'page_index':page_index,'pdf_page':page_index+1,
        'image_xref':xref,'size_pixels':list(image.size),'RGB_pixels_sha256':digest(image.tobytes()),
        'page_content_sha256':digest(page.read_contents()),'page_text':page.get_text(),
        'page_images':page.get_images(full=True),'colors':colors,
        'local_native_png_sha256':digest(full.read_bytes()),'local_crop_png_sha256':digest(crop.read_bytes())})
result={'schema':'mitl-independent-current-depth-native-inspection-v1','source_pdf_sha256':PIN,
    'script_sha256':digest(Path(__file__).read_bytes()),'cases':records,
    'limits':['Native raster pixels and source text only; no old recovery or new producer called.',
    'Original plot normalization is not authenticated. Literal displayed J_z values cannot establish physical Joule or current-integral closure.']}
out=ROOT/'native-inspection.json'
out.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps({'output':str(out),'sha256':digest(out.read_bytes()),
    'cases':[{k:r[k] for k in ['figure','image_xref','RGB_pixels_sha256','page_content_sha256']} for r in records]},indent=2))
