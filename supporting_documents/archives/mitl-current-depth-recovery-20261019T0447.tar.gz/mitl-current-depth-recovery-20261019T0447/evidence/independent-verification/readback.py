"""Check frozen current-depth files against independently inspected source pixels."""
import csv
from decimal import Decimal, localcontext
from fractions import Fraction as F
import hashlib
import json
import math
from pathlib import Path

from PIL import Image

ROOT=Path(__file__).resolve().parent
WORK=ROOT.parent
REPO=Path('/workspace/Power-Flow')
PUBLIC={
    'tools/recover_dissertation_depth_current.py':'77926d95a0e6c01001d7268200a34aa58457cc33d3de051f45f9d0a7ebeb8982',
    'data/dissertation/figure_4_28_current_depth.csv':'c53365543cbf96b30a7e2e1a1e2e63871dc182bc7e60bd641b93140e6f3726e6',
    'data/dissertation/figure_4_28_current_depth.json':'5e9b662d63393904d2c0714f2ce7c3fb3812735279917f8870b3a8f3032cf4d6',
    'data/dissertation/figure_4_29_current_depth.csv':'e6009f6f2e578776751805e36367f630bd95127fd4eb0bf183a78938822135c4',
    'data/dissertation/figure_4_29_current_depth.json':'ce6d64ad1f1f93dcf6fd340ea7815227296cf90b55b460b293dacfb7df134fbf',
}
FIELDS=['figure','profile','time_s','pixel_y','pixel_x_median','run_first_pixel_x',
    'run_last_pixel_x','matched_color_pixels','gap_coordinate_mm',
    'gap_coordinate_readout_lower_mm','gap_coordinate_readout_upper_mm',
    'nominal_initial_depth_um','nominal_initial_depth_readout_lower_um',
    'nominal_initial_depth_readout_upper_um','Jz_literal_MA_per_cm2',
    'Jz_literal_readout_lower_MA_per_cm2','Jz_literal_readout_upper_MA_per_cm2',
    'Jz_literal_conditional_A_per_m2','Jz_literal_conditional_readout_lower_A_per_m2',
    'Jz_literal_conditional_readout_upper_A_per_m2']
PROFILES={'foil_edge':(154,205,50),'foil_middle':(0,128,0)}
INTEGER_FIELDS={'pixel_y','run_first_pixel_x','run_last_pixel_x','matched_color_pixels'}

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def pairs(items):
    result={}
    for key,value in items:
        assert key not in result, ('duplicate JSON key',key)
        result[key]=value
    return result

def load(path):
    return json.loads(path.read_text(),object_pairs_hook=pairs,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))

def q(record):
    return F(int(record['numerator']),int(record['denominator']))

def rational(value):
    return {'numerator':str(value.numerator),'denominator':str(value.denominator)}

def runs(xs):
    result=[]
    for x in xs:
        if not result or x!=result[-1][-1]+1:
            result.append([x])
        else:
            result[-1].append(x)
    return [[row[0],row[-1]] for row in result]

def decimal_bound(value):
    if not value:
        return F(0)
    with localcontext() as context:
        context.prec=100
        magnitude=(Decimal(abs(value.numerator))/Decimal(value.denominator)).adjusted()
    exponent=magnitude-11
    return F(10**exponent,2) if exponent>=0 else F(1,2*10**(-exponent))

def compare_cell(text,exact,arithmetic,field):
    assert text and text.strip()==text
    if field in INTEGER_FIELDS:
        assert str(int(text))==text and F(int(text))==exact
        return F(0)
    actual=F(Decimal(text))
    assert math.isfinite(float(text)) and math.isfinite(arithmetic)
    rounding=decimal_bound(F.from_float(arithmetic))
    arithmetic_error=abs(F.from_float(arithmetic)-exact)
    assert abs(actual-exact)<=rounding+arithmetic_error, (field,text,float(exact),float(rounding),float(arithmetic_error))
    return abs(actual-exact)

assert not (ROOT/'readback.json').exists()
for name,pin in PUBLIC.items():
    assert sha(REPO/name)==pin, name
native=load(ROOT/'native-inspection.json')
reference=load(ROOT/'coordinate-reference.json')
geometry_context=load(ROOT/'initial-geometry-context.json')
assert sha(Path('/workspace/research_sources/smtrevor_1.pdf'))==native['source_pdf_sha256']=='1d7b1f9c191a37e94f1cc3634587750f1af35b07eb13e0b94c60f3da47495ed7'
assert native['source_pdf_sha256']==reference['cases'][0].get('source_pdf_sha256',native['source_pdf_sha256'])
assert geometry_context['source_pdf_sha256']==native['source_pdf_sha256']
assert '5-mm AK gap' in geometry_context['pages'][2]['text']
assert 'foil thickness was 200' in geometry_context['pages'][2]['text']
reference_rows=[]
reference_catalog=[]
max_difference={field:F(0) for field in FIELDS[2:]}
case_results=[]
total_cells=0
input_pins={name:pin for name,pin in PUBLIC.items()}
for ncase,ref in zip(native['cases'],reference['cases']):
    figure=ref['figure']
    suffix=figure.replace('.','_')
    datafile=REPO/f'data/dissertation/figure_{suffix}_current_depth.csv'
    metafile=datafile.with_suffix('.json')
    metadata=load(metafile)
    assert metadata['schema']=='mhdlab-dissertation-current-depth-recovery-v1'
    source=metadata['source']
    for key,expected in [('pdf_sha256',native['source_pdf_sha256']),('figure',figure),
        ('pdf_page_index',ncase['page_index']),('pdf_page',ncase['pdf_page']),
        ('printed_page',94 if figure=='4.28' else 96),
        ('page_content_sha256',ncase['page_content_sha256']),('embedded_image_xref',ncase['image_xref']),
        ('decoded_RGB_pixels_sha256',ncase['RGB_pixels_sha256']),('native_image_size_pixels',[975,975]),('native_image_mode','RGB')]:
        assert source[key]==expected, (figure,key)
    assert source['page_text']==ncase['page_text']
    simulation=metadata['simulation_context']
    time_ns=40 if figure=='4.28' else 60
    assert simulation['code_label_in_dissertation']=='Allegra' and simulation['drive_shot']==17133
    assert simulation['time_s']==time_ns*1e-9
    for key in ['experimental_measurement','FLASH_result','dielectric_support_included',
                'actual_material_boundaries_recovered','coordinate_frame_rotation_applied']:
        assert simulation[key] is False
    assert simulation['component_signs_preserved'] is True and simulation['edge_width_offset_m'] is None
    assert simulation['initial_foil_thickness_m']==200e-6 and simulation['initial_AK_gap_m']==5e-3
    units=metadata['unit_interpretation']
    assert units['source_current_axis_label']=='J_z [MA/cm²]'
    assert units['source_gap_axis_label']=='Distance from Middle of AK Gap [mm]'
    assert units['literal_conditional_scale_to_A_per_m2']==10**10
    for key in ['original_simulation_output_units_confirmed','original_normalization_verified',
                'normalization_or_legend_error_resolved','unit_repair_or_empirical_rescaling_applied']:
        assert units[key] is False
    assert 'conditional' in units['SI_columns_qualification']
    mask=metadata['selection']
    assert mask['panel_ROI_inclusive']=={'x':[90,477],'y':[505,900]}
    assert mask['retained_interior_y_inclusive']==[640,780] and mask['row_stride']==1
    for key in ['interpolation','smoothing','extrapolation','surface_or_endpoint_padding']:
        assert mask[key] is False
    assert metadata['readout_bounds']['additional_pixel_readout_half_width']==2
    assert metadata['readout_bounds']['correlated_display_bounds_only'] is True
    assert metadata['readout_bounds']['independent_noise_or_confidence_interval'] is False
    assert metadata['readout_bounds']['physical_or_simulation_uncertainty_quantified'] is False
    nominal=metadata['nominal_initial_depth']
    assert nominal['initial_positive_gap_face_mm']==2.5
    assert nominal['actual_moving_face_coordinate'] is False and nominal['initial_geometry_reference_only'] is True
    imagepath=ROOT/'source-local'/f'figure-{figure}-native.png'
    image=Image.open(imagepath).convert('RGB')
    assert hashlib.sha256(image.tobytes()).hexdigest()==ref['RGB_pixels_sha256']==source['decoded_RGB_pixels_sha256']
    pixels=image.load()
    jm=q(ref['current_slope_MA_cm2_per_pixel']);jb=q(ref['current_intercept_MA_cm2'])
    gm=q(ref['depth_slope_mm_per_pixel']);gb=q(ref['depth_intercept_mm'])
    jr=max(abs(q(value)) for value in ref['current_tick_residuals_MA_cm2'])
    gr=max(abs(q(value)) for value in ref['depth_tick_residuals_mm'])
    for kind,m,b in [('current',jm,jb),('gap',gm,gb)]:
        calibration=metadata['calibration'][kind]
        assert calibration['slope_exact']==[str(m.numerator),str(m.denominator)]
        assert calibration['intercept_exact']==[str(b.numerator),str(b.denominator)]
        assert calibration['slope']==float(m) and calibration['intercept']==float(b)
    jcal=metadata['calibration']['current'];gcal=metadata['calibration']['gap']
    assert jcal['tick_pixel_centres']==[float(q(x)) for x in ref['current_tick_centers']]
    assert jcal['tick_values']==[float(q(x)) for x in ref['current_tick_values']]
    assert gcal['tick_pixel_centres']==[float(q(x)) for x in reversed(ref['depth_tick_centers'])]
    assert gcal['tick_values']==[float(q(x)) for x in reversed(ref['depth_tick_values'])]
    assert jcal['tick_residuals']==[-float(q(x)) for x in ref['current_tick_residuals_MA_cm2']]
    assert gcal['tick_residuals']==[-float(q(x)) for x in reversed(ref['depth_tick_residuals_mm'])]
    assert jcal['max_abs_tick_residual']==float(jr) and gcal['max_abs_tick_residual']==float(gr)
    expected=[]
    for profile,color in PROFILES.items():
        kept=[];excluded=[]
        for y in range(900,504,-1):
            xs=[x for x in range(90,478) if pixels[x,y]==color]
            rr=runs(xs)
            selected=640<=y<=780
            reason='retained' if selected else 'outside_conservative_interior_display_mask'
            raw={'pixel_y':y,'exact_colour_runs_inclusive_x':rr,'reason':reason}
            reference_catalog.append({'figure':figure,'profile':profile,**raw})
            if not selected:
                excluded.append(raw)
                continue
            assert len(rr)==1 and len(xs) in [3,4] and 90<xs[0]<=xs[-1]<477
            kept.append(raw)
            first,last=xs[0],xs[-1];median=F(first+last,2)
            gap=gm*y+gb;glo=gm*(y+2)+gb-gr;ghi=gm*(y-2)+gb+gr
            jz=jm*median+jb;jlo=jm*(first-2)+jb-jr;jhi=jm*(last+2)+jb+jr
            gap_float=float(gm)*y+float(gb)
            glo_float=float(gm)*(y+2)+float(gb)-float(gr)
            ghi_float=float(gm)*(y-2)+float(gb)+float(gr)
            jz_float=float(jm)*float(median)+float(jb)
            jlo_float=float(jm)*(first-2)+float(jb)-float(jr)
            jhi_float=float(jm)*(last+2)+float(jb)+float(jr)
            exact={'time_s':F(time_ns,10**9),'pixel_y':F(y),'pixel_x_median':median,
                'run_first_pixel_x':F(first),'run_last_pixel_x':F(last),'matched_color_pixels':F(len(xs)),
                'gap_coordinate_mm':gap,'gap_coordinate_readout_lower_mm':glo,'gap_coordinate_readout_upper_mm':ghi,
                'nominal_initial_depth_um':(gap-F(5,2))*1000,
                'nominal_initial_depth_readout_lower_um':(glo-F(5,2))*1000,
                'nominal_initial_depth_readout_upper_um':(ghi-F(5,2))*1000,
                'Jz_literal_MA_per_cm2':jz,'Jz_literal_readout_lower_MA_per_cm2':jlo,'Jz_literal_readout_upper_MA_per_cm2':jhi,
                'Jz_literal_conditional_A_per_m2':jz*10**10,
                'Jz_literal_conditional_readout_lower_A_per_m2':jlo*10**10,
                'Jz_literal_conditional_readout_upper_A_per_m2':jhi*10**10}
            arithmetic={name:float(value) for name,value in exact.items()}
            arithmetic.update({'time_s':time_ns*1e-9,'gap_coordinate_mm':gap_float,
                'gap_coordinate_readout_lower_mm':glo_float,'gap_coordinate_readout_upper_mm':ghi_float,
                'nominal_initial_depth_um':(gap_float-2.5)*1000,
                'nominal_initial_depth_readout_lower_um':(glo_float-2.5)*1000,
                'nominal_initial_depth_readout_upper_um':(ghi_float-2.5)*1000,
                'Jz_literal_MA_per_cm2':jz_float,'Jz_literal_readout_lower_MA_per_cm2':jlo_float,'Jz_literal_readout_upper_MA_per_cm2':jhi_float,
                'Jz_literal_conditional_A_per_m2':jz_float*1e10,
                'Jz_literal_conditional_readout_lower_A_per_m2':jlo_float*1e10,
                'Jz_literal_conditional_readout_upper_A_per_m2':jhi_float*1e10})
            assert jlo<jz<jhi<0 and glo<gap<ghi
            expected.append((profile,y,exact,arithmetic))
            reference_rows.append({'figure':figure,'profile':profile,'pixel_y':y,
                                   'exact_values':{k:rational(v) for k,v in exact.items()}})
        catalog=mask['profiles'][profile]
        assert catalog['RGB']==list(color)
        assert catalog['retained_rows']==kept and catalog['excluded_rows']==excluded
        assert catalog['retained_count']==141 and catalog['excluded_count']==255 and catalog['catalogued_row_count']==396
    with datafile.open(newline='') as stream:
        reader=csv.DictReader(stream)
        assert reader.fieldnames==FIELDS==metadata['output']['columns']
        actual=list(reader)
    assert len(actual)==len(expected)==282 and metadata['output']['samples']==282
    assert metadata['output']['samples_by_profile']=={'foil_edge':141,'foil_middle':141}
    for output_key,field in [('gap_coordinate_extent_mm','gap_coordinate_mm'),
        ('nominal_initial_depth_extent_um','nominal_initial_depth_um')]:
        assert metadata['output'][output_key]==[min(row[3][field] for row in expected),max(row[3][field] for row in expected)]
    for profile in PROFILES:
        values=[row[3]['Jz_literal_MA_per_cm2'] for row in expected if row[0]==profile]
        assert metadata['output']['signed_Jz_literal_extent_by_profile'][profile]==[min(values),max(values)]
    assert metadata['output']['csv_sha256']==sha(datafile)
    assert metadata['output']['generator_sha256']==PUBLIC['tools/recover_dissertation_depth_current.py']
    geometryfile=WORK/'recovery'/metadata['output']['source_geometry_filename']
    assert sha(geometryfile)==metadata['output']['source_geometry_sha256']
    input_pins[str(geometryfile)]=sha(geometryfile)
    geometry=load(geometryfile)
    assert geometry['profiles']==mask['profiles'] and geometry['calibration']=={
        'current':metadata['calibration']['current'],'gap':metadata['calibration']['gap']}
    for row,(profile,y,exact,arithmetic) in zip(actual,expected):
        assert row['figure']==figure and row['profile']==profile and int(row['pixel_y'])==y
        for field,value in exact.items():
            difference=compare_cell(row[field],value,arithmetic[field],field)
            max_difference[field]=max(max_difference[field],difference)
            total_cells+=1
    case_results.append({'figure':figure,'profiles':2,'retained_rows':282,'excluded_rows':510,
        'all_retained_signed_negative':True,'source_RGB_sha256':ref['RGB_pixels_sha256'],
        'gap_coordinate_extent_mm':metadata['output']['gap_coordinate_extent_mm'],
        'nominal_initial_depth_extent_um':metadata['output']['nominal_initial_depth_extent_um'],
        'Jz_literal_extent_by_profile':metadata['output']['signed_Jz_literal_extent_by_profile']})
assert total_cells==10152 and len(reference_rows)==564 and len(reference_catalog)==1584
retained={'schema':'mitl-current-depth-independent-exact-row-reference-v1','rows':reference_rows,'native_row_catalog':reference_catalog}
rowpath=ROOT/'exact-row-reference.json'
rowpath.write_text(json.dumps(retained,indent=2,allow_nan=False)+'\n')
result={'schema':'mitl-independent-current-depth-readback-v1','all_checks_passed':True,
    'script_sha256':sha(Path(__file__)),'public_source_sha256':PUBLIC,
    'input_sha256':input_pins,'native_inspection_sha256':sha(ROOT/'native-inspection.json'),
    'coordinate_reference_sha256':sha(ROOT/'coordinate-reference.json'),
    'initial_geometry_context_sha256':sha(ROOT/'initial-geometry-context.json'),
    'exact_row_reference_sha256':sha(rowpath),'figures':2,'profiles':4,'retained_rows':564,
    'excluded_rows':1020,'native_rows_catalogued':1584,'numeric_csv_cells_checked':total_cells,
    'tick_anchors_checked':28,'all_retained_signed_negative':True,
    'maximum_absolute_cell_difference':{k:float(v) for k,v in max_difference.items()},
    'cases':case_results,'successful_producer_calls':0,'old_recovery_calls':0,
    'physical_normalization_verified':False,'J_squared_heating_inferred':False,
    'limits':['All recovered samples are signed, correlated raster-display samples from legacy Allegra simulation figures, not measurements or FLASH output.',
        'All1584 native profile rows are accounted;564 clean interior rows are retained,1020 other rows remain explicitly excluded with exact source runs.',
        'CSV decimal bounds include12-significant-digit rounding and separately quantified arithmetic conversion from exact rational calibration.',
        'Conditional SI scaling is literal1e10 only. Original normalization, moving material faces, physical uncertainty, current/Ampere/J-squared closure and simulation/diagnostic clock registration remain unverified.',
        'The2.5mm positive initial gap face is an explicit nominal initial-geometry reference, not a recovered actual surface. No interpolation, sign repair, padding, endpoint, smoothing or producer replay is supplied.']}
target=ROOT/'readback.json'
target.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps({'output':str(target),'sha256':sha(target),'all_checks_passed':True,
    'retained_rows':564,'excluded_rows':1020,'numeric_csv_cells_checked':total_cells},indent=2))
