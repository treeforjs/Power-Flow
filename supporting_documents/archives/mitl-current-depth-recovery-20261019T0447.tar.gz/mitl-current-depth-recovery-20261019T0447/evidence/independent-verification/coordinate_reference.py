"""Exact-rational calibration and native-row reference, independent of recovery."""
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path

from PIL import Image

ROOT=Path(__file__).resolve().parent
INSPECTION=json.loads((ROOT/'native-inspection.json').read_text())
COLORS={'foil_edge':(154,205,50),'foil_middle':(0,128,0)}

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def rational(x):
    return {'numerator':str(x.numerator),'denominator':str(x.denominator),'value':float(x)}

def runs(values):
    output=[]
    for v in values:
        if not output or v>output[-1][-1]+1:
            output.append([v])
        else:
            output[-1].append(v)
    return output

def ols(xs,ys):
    n=len(xs)
    slope=(n*sum(x*y for x,y in zip(xs,ys))-sum(xs)*sum(ys))/(n*sum(x*x for x in xs)-sum(xs)**2)
    intercept=(sum(ys)-slope*sum(xs))/n
    return slope,intercept

results=[]
for original in INSPECTION['cases']:
    image=Image.open(ROOT/'source-local'/('figure-'+original['figure']+'-native.png')).convert('RGB')
    pixels=image.load()
    dark=lambda x,y:max(pixels[x,y])<80
    xticks=runs([x for x in range(90,478) if sum(dark(x,y) for y in range(902,909))>=5])
    yticks=runs([y for y in range(503,904) if sum(dark(x,y) for x in range(82,88))>=5])
    assert len(xticks)==5 and len(yticks)==9, (xticks,yticks)
    xcenters=[F(r[0]+r[-1],2) for r in xticks]
    ycenters=[F(r[0]+r[-1],2) for r in yticks]
    current_values=[F(-4+i,5) for i in range(5)]
    depth_values=[F(28,10)-F(i,20) for i in range(9)]
    jm,jb=ols(xcenters,current_values)
    ym,yb=ols(ycenters,depth_values)
    jres=[jm*x+jb-y for x,y in zip(xcenters,current_values)]
    yres=[ym*x+yb-y for x,y in zip(ycenters,depth_values)]
    color_rows={}
    for name,color in COLORS.items():
        rows=[]
        for y in range(506,901):
            xs=[x for x in range(90,478) if pixels[x,y]==color]
            rr=runs(xs)
            rows.append({'pixel_y':y,'runs':[[a[0],a[-1]] for a in rr],
                'depth_mm':rational(ym*y+yb),
                'center_current_MA_cm2':rational(jm*F(xs[0]+xs[-1],2)+jb) if len(rr)==1 else None,
                'single_run':len(rr)==1,
                'zero_runs':not rr})
        color_rows[name]=rows
    results.append({'figure':original['figure'],
        'RGB_pixels_sha256':original['RGB_pixels_sha256'],
        'frame_dark_strokes':{'x_ranges':[[88,89],[478,479]],'y_ranges':[[505,506],[900,901]]},
        'current_tick_runs_pixels':[[r[0],r[-1]] for r in xticks],
        'depth_tick_runs_pixels':[[r[0],r[-1]] for r in yticks],
        'current_tick_centers':[rational(x) for x in xcenters],
        'depth_tick_centers':[rational(y) for y in ycenters],
        'current_tick_values':[rational(x) for x in current_values],
        'depth_tick_values':[rational(x) for x in depth_values],
        'current_slope_MA_cm2_per_pixel':rational(jm),'current_intercept_MA_cm2':rational(jb),
        'depth_slope_mm_per_pixel':rational(ym),'depth_intercept_mm':rational(yb),
        'current_tick_residuals_MA_cm2':[rational(x) for x in jres],
        'depth_tick_residuals_mm':[rational(x) for x in yres],
        'conditional_SI_factor_A_m2_per_MA_cm2':10**10,
        'original_normalization_verified':False,
        'row_scan_support_pixels':{'x_inclusive':[90,477],'y_inclusive':[506,900]},
        'colors':{k:list(v) for k,v in COLORS.items()},'rows':color_rows})
out={'schema':'mitl-independent-current-depth-coordinate-reference-v1',
    'native_inspection_sha256':sha(ROOT/'native-inspection.json'),
    'script_sha256':sha(Path(__file__)), 'cases':results,
    'axis_orientation':{'horizontal':'literal J_z [MA/cm²]','vertical':'Distance from Middle of AK Gap [mm]'},
    'limits':['Native exact RGB rows include legend, overlapping traces, and near-zero branches; retained interior support requires an explicitly declared mask.',
        'Rational axis fitting preserves signed displayed values and does not establish original Allegra normalization or physical current density.',
        'No extrapolated surface, current integral, current-density-squared heating, field derivative or solver output is inferred.']}
target=ROOT/'coordinate-reference.json'
target.write_text(json.dumps(out,indent=2,allow_nan=False)+'\n')
print(json.dumps({'output':str(target),'sha256':sha(target),'case_axes':[{k:v for k,v in r.items() if k in ['figure','current_tick_runs_pixels','depth_tick_runs_pixels','current_slope_MA_cm2_per_pixel','current_intercept_MA_cm2','depth_slope_mm_per_pixel','depth_intercept_mm']} for r in results]},indent=2))
