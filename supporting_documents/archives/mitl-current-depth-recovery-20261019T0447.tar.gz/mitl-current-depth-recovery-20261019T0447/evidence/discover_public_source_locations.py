"""Bounded new public-source discovery; inherited proxy and TLS trust retained.

One OpenAlex metadata request per DOI. No credentials, retries or solver imports.
Raw responses remain local; summaries do not imply physical parameter validation.
"""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import datetime,hashlib,json,time,urllib.request,urllib.error

ROOT=Path(__file__).resolve().parent
OUT=ROOT/'source-acquisition'/'locations'
RAW=OUT/'raw';RAW.mkdir(parents=True,exist_ok=True)
LEADS=[('joly_2000','10.1016/S0042-207X(00)00393-6'),('li_dylla_1995','10.1116/1.579673')]

def fetch(lead,doi):
    url='https://api.openalex.org/works/https://doi.org/'+doi
    started=datetime.datetime.now(datetime.timezone.utc).isoformat();t0=time.monotonic()
    request=urllib.request.Request(url,headers={'User-Agent':'MITL-source-evidence/1.0','Accept':'application/json'})
    error=None;status=None;final_url=url;headers={};body=b''
    try:
        with urllib.request.urlopen(request,timeout=30) as response:
            status=response.status;final_url=response.url;headers=dict(response.headers.items());body=response.read(8*1024*1024+1)
    except urllib.error.HTTPError as exc:
        status=exc.code;final_url=exc.url;headers=dict(exc.headers.items());body=exc.read(8*1024*1024+1);error=type(exc).__name__
    except (urllib.error.URLError,TimeoutError) as exc:
        error=type(exc).__name__+': '+str(exc.reason if isinstance(exc,urllib.error.URLError) else exc)
    if len(body)>8*1024*1024:raise RuntimeError('Response exceeds bounded metadata size')
    path=RAW/(lead+'_openalex.response');path.write_bytes(body)
    hp=RAW/(lead+'_openalex.headers.json');hp.write_text(json.dumps(headers,indent=2)+'\n')
    row={'lead':lead,'doi':doi,'requested_url':url,'method':'GET','request_headers':{'User-Agent':'MITL-source-evidence/1.0','Accept':'application/json'},'started_utc':started,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'elapsed_s':time.monotonic()-t0,'http_status':status,'final_url':final_url,'response_headers':headers,'response_headers_file':str(hp),'response_headers_sha256':hashlib.sha256(hp.read_bytes()).hexdigest(),'actual_bytes':len(body),'sha256':hashlib.sha256(body).hexdigest(),'raw_response_file':str(path),'error':error,'TLS_verification':'default enabled','proxy':'inherited environment; not overridden','retry_count':0}
    if status==200:
        try:doc=json.loads(body)
        except (ValueError,UnicodeDecodeError) as exc:row['metadata_parse_error']=str(exc)
        else:
            row['metadata']={key:doc.get(key) for key in ('id','doi','display_name','publication_year','open_access','best_oa_location','primary_location','locations','has_fulltext')}
    return row

def main():
    with ThreadPoolExecutor(max_workers=2) as pool:rows=list(pool.map(lambda pair:fetch(*pair),LEADS))
    report={'schema':'mhdlab-new-primary-public-source-locations-v1','script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'records':rows,'request_limit':'one OpenAlex metadata query per DOI; no retries or physical data adoption','full_text_acquired':False,'raw_files_excluded_from_delivery':True,'physics_parameters_adopted':False}
    (OUT/'openalex_report.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    print(json.dumps(report,indent=2,allow_nan=False))
if __name__=='__main__':main()
