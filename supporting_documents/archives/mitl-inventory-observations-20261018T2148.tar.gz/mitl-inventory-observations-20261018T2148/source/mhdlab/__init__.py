"""Portable heating/desorption source verification subset."""
