# Parent inventory and source-grid verification subset

The named public files are byte-identical to the recorded repository commit.
Four packaging wrappers are listed separately in `source_file_list.json`.
The package initializer avoids unrelated solver imports. No separately owned
transport, collision or radiative implementation is included.

Run the new inventory/export checks with:

```sh
python -W error -m pytest tests/test_coverage_inventory.py tests/test_coverage_sources_cli.py
```

Generate an explicitly manufactured source sweep with:

```sh
python tools/build_coverage_sources.py --demo --output-dir /tmp/coverage-sources --plot
```

The monolayer convention, parent partition, kinetics and temperatures in that
example are manufactured. No physical surface coverage or spectrum is inferred.
See `docs/coverage_source_inventory.md` and the top-level handoff for source
associations, experimental-recovery limits and continuation work.

The new observed visible-trace checks run separately with:

```sh
python -W error -m pytest tests/test_dissertation_observed_spectrum.py
```

Exact-PDF integration uses the external `DISSERTATION_SOURCE_PDF` path when
available and otherwise skips explicitly. Raw source pixels and the PDF are
excluded from this archive. The CSV is a partial reconstruction of a published
arbitrary-intensity visible trace; it supplies no detector bins or covariance.
Read `docs/observed_spectrum_recovery.md` before comparing it with predictions.
