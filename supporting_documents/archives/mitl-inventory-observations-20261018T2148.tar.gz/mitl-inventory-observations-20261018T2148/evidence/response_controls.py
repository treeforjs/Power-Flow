"""Independent, work-only number-response controls on exported source bytes.

No gap, collision, photon, detector or radiation model is evaluated.  Kernels
are arbitrary piecewise-constant functions of interval, exact outgoing state
and current patch, with explicitly chosen launch-width apertures.  Fraction
arithmetic keeps the supplied float source/geometry bytes exact for this audit.
"""
from __future__ import annotations

import argparse
import csv
from fractions import Fraction as Q
import hashlib
import json
import math
from pathlib import Path
import sys

import h5py
import numpy as np

REPO = Path('/workspace/Power-Flow')
WORK = Path(__file__).resolve().parent
sys.path.insert(0, str(REPO))
KERNEL_NAMES = ('number', 'time_weight', 'current_weight', 'state_weight', 'mixed_weight', 'signed_weight', 'early_intervals')
LIMITS = [
    'Arbitrary linear number observations, not physical spectra, detector counts, radiation or chemistry predictions.',
    'The chosen kernels are constant within each emitted-source time interval and current patch; they do not test a continuous-time or velocity-dependent response from number-moment datasets.',
    'The analytic matched control retains each original source component and changes launch-width location only; it does not reheat, redeplete or average launch temperatures.',
    'Stored matched-width HDF datasets preserve interval/pool/current number and energy moments; they are not standalone emission-time, state or velocity distributions.',
    'Aperture overlaps assume the exported density is uniform within each source patch. The selected finite apertures and kernel coefficients are manufactured controls, not recovered diagnostic geometry.',
    'Any regression covariance, background, calibration scale and interpolated observation are manufactured. No inference about experimental monolayers or data identifiability follows.',
    'A fixed linear width-independent response must erase the launch-width distinction. Finite collection can break this control, without proving a measurable spectral distinction.',
]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def array_sha(value):
    value = np.ascontiguousarray(value)
    return hashlib.sha256(value.dtype.str.encode() + repr(value.shape).encode() + value.tobytes()).hexdigest()


def number(value):
    result = float(value)
    if not math.isfinite(result):
        raise ValueError('oracle summary exceeds finite float64 range')
    return result


def overlap_fraction(left, right, aperture_left, aperture_right):
    return max(Q(0), min(right, aperture_right) - max(left, aperture_left)) / (right-left)


def self_check():
    # Unequal real patch areas: dz=2, dx=(1,2), density=(3,1), number=(6,4).
    edges = (Q(0), Q(1), Q(3))
    emitted = (Q(6), Q(4))
    aperture = (Q(1, 2), Q(5, 2))
    resolved = sum(n*overlap_fraction(left,right,*aperture)
                   for n,left,right in zip(emitted,edges[:-1],edges[1:]))
    uniform = sum(emitted)*(aperture[1]-aperture[0])/(edges[-1]-edges[0])
    if resolved != 6 or uniform != Q(20,3):
        raise ValueError('closed-form unequal-area fractional aperture oracle failed')
    for weight in (Q(1),Q(2,7),Q(-19,11)):
        resolved_full = sum(emitted)*weight
        uniform_full = sum(n*weight*sum((right-left)/(edges[-1]-edges[0])
                                       for left,right in zip(edges[:-1],edges[1:])) for n in emitted)
        if resolved_full != uniform_full:
            raise ValueError('exact rational full-width invariance failed')
    return {'status':'passed','unequal_patch_areas_m2':[2,4], 'emitted_number':[6,4],
            'aperture_m':['1/2','5/2'],'resolved_aperture_number':6,
            'matched_uniform_aperture_number_exact':'20/3',
            'full_width_invariance_for_signed_and_positive_weights':True}


def dataset(handle, name, unit):
    if not isinstance(handle.get(name, getlink=True), h5py.HardLink):
        raise ValueError('oracle accepts only local HDF datasets')
    item = handle[name]
    if item.attrs.get('units') != unit:
        raise ValueError(f'wrong or missing SI units on {name}')
    result = np.asarray(item[...])
    if not np.all(np.isfinite(result)):
        raise ValueError(f'nonfinite source bytes in {name}')
    return result


def kernels(times, z_edges, states):
    nt, nr, nz = len(times)-1, len(states), len(z_edges)-1
    state_codes = {state:index for index,state in enumerate(sorted(set(states)))}
    duration = Q(float(times[-1]))-Q(float(times[0]))
    z_span = Q(float(z_edges[-1]))-Q(float(z_edges[0]))
    result = np.empty((len(KERNEL_NAMES),nt,nr,nz),dtype=object)
    for t in range(nt):
        time_center = (Q(float(times[t]))+Q(float(times[t+1])))/2
        time_weight = (time_center-Q(float(times[0])))/duration
        for r,state in enumerate(states):
            code = state_codes[state]
            for z in range(nz):
                z_center=(Q(float(z_edges[z]))+Q(float(z_edges[z+1])))/2
                z_weight=(z_center-Q(float(z_edges[0])))/z_span
                result[:,t,r,z] = (Q(1), 1+time_weight, 1+z_weight,
                                    Q(1+code), Q(1,10)+Q((3*t+5*code+7*z)%19,19),
                                    Q((-1)**(t+code+z))*(1+time_weight+z_weight), Q(int(2*t<nt)))
    return result,state_codes


def evaluate_source(path):
    # Reopen the actual independently persisted HDF for every coverage knot.
    with h5py.File(path,'r') as h:
        if h.attrs.get('schema') != 'mhdlab-temkin-planar-release-v1':
            raise ValueError('unsupported source schema')
        times=dataset(h,'time_edges_s','s')
        x=dataset(h,'x_edges_m','m');z=dataset(h,'z_edges_m','m')
        areas=dataset(h,'patch_areas_m2','m^2')
        release=dataset(h,'released_m2','m^-2')
        matched=dataset(h,'matched_uniform_width/released_m2','m^-2')
        pool_records=json.loads(h.attrs['reservoirs_json'])
        state_ids=tuple(record['state_id'] for record in pool_records)
        law=str(h.attrs['law_identity'])
    nt,nr,nz,nx=release.shape
    if matched.shape!=release.shape or areas.shape!=(nz,nx) or (nt,nr,nz,nx)!=(len(times)-1,len(state_ids),len(z)-1,len(x)-1):
        raise ValueError('source shapes do not match the local number/area axes')
    if any(np.any(np.diff(edge)<=0) for edge in [times,x,z]) or np.any(areas<=0) or np.any(release<0) or np.any(matched<0):
        raise ValueError('source geometry or populations are invalid')
    area_geometry_max_relative=0.0
    for zi in range(nz):
        for xi in range(nx):
            geometric=(Q(float(z[zi+1]))-Q(float(z[zi])))*(Q(float(x[xi+1]))-Q(float(x[xi])))
            stored=Q(float(areas[zi,xi]))
            area_geometry_max_relative=max(area_geometry_max_relative,number(abs(stored-geometric)/geometric))
    if area_geometry_max_relative>4*np.finfo(float).eps:
        raise ValueError('stored actual patch area disagrees with geometric edges')
    weights,state_codes=kernels(times,z,state_ids)
    xq=[Q(float(value)) for value in x]
    width=xq[-1]-xq[0]
    apertures=(('full_width',xq[0],xq[-1]),
               ('central_partial',xq[0]+Q(29,100)*width,xq[0]+Q(61,100)*width),
               ('left_partial',xq[0],xq[0]+Q(18,100)*width),
               ('right_partial',xq[0]+Q(77,100)*width,xq[-1]))
    resolved=np.full((len(apertures),len(KERNEL_NAMES)),Q(0),dtype=object)
    redistributed=resolved.copy();persisted=resolved.copy()
    marginal_max_relative=0.0
    marginal_max_absolute=0.0
    exact_full=True
    for t in range(nt):
        for r in range(nr):
            for zi in range(nz):
                counts=[Q(float(release[t,r,zi,xi]))*Q(float(areas[zi,xi])) for xi in range(nx)]
                stored_counts=[Q(float(matched[t,r,zi,xi]))*Q(float(areas[zi,xi])) for xi in range(nx)]
                total,stored_total=sum(counts),sum(stored_counts)
                if total:
                    marginal_max_relative=max(marginal_max_relative,number(abs(stored_total-total)/total))
                elif stored_total:
                    raise ValueError('matched control populated an empty local marginal')
                marginal_max_absolute=max(marginal_max_absolute,number(abs(stored_total-total)))
                # This exact redistribution retains the original component label:
                # no replacement of its time/state/current/temperature mixture.
                if sum(n*sum((right-left)/width for left,right in zip(xq[:-1],xq[1:])) for n in counts)!=total:
                    exact_full=False
                for ai,(_,left,right) in enumerate(apertures):
                    local=sum(n*overlap_fraction(a,b,left,right) for n,a,b in zip(counts,xq[:-1],xq[1:]))
                    uniform=total*(right-left)/width
                    stored_local=sum(n*overlap_fraction(a,b,left,right) for n,a,b in zip(stored_counts,xq[:-1],xq[1:]))
                    for ki in range(len(KERNEL_NAMES)):
                        w=weights[ki,t,r,zi]
                        resolved[ai,ki]+=w*local
                        redistributed[ai,ki]+=w*uniform
                        persisted[ai,ki]+=w*stored_local
    exact_full=bool(exact_full and all(a==b for a,b in zip(resolved[0],redistributed[0])))
    if not exact_full or marginal_max_relative>256*np.finfo(float).eps:
        raise ValueError('full-width source marginal control failed')
    return {'resolved':np.vectorize(number,otypes=[float])(resolved),
            'matched_component_redistribution':np.vectorize(number,otypes=[float])(redistributed),
            'stored_matched_number_moments':np.vectorize(number,otypes=[float])(persisted),
            'apertures':[(name,number(left),number(right)) for name,left,right in apertures],
            'diagnostic':{'source_file':path.name,'source_sha256':sha(path),'law_identity':law,
                          'shape_interval_pool_current_width':list(release.shape),
                          'exact_component_full_width_invariance':exact_full,
                          'stored_matched_local_number_marginal_max_relative_difference':marginal_max_relative,
                          'stored_matched_local_number_marginal_max_absolute_difference':marginal_max_absolute,
                          'stored_area_vs_edge_product_max_relative_roundoff':area_geometry_max_relative,
                          'state_ids':list(state_ids),'state_weight_codes':state_codes,
                          'array_sha256':{name:array_sha(value) for name,value in [('released_m2',release),('patch_areas_m2',areas),('matched_uniform_width/released_m2',matched),('time_edges_s',times),('x_edges_m',x),('z_edges_m',z)]}},
            'kernel_weights':np.vectorize(number,otypes=[float])(weights)}


def fit_controls(coverage,resolved,matched,monolayer):
    from mhdlab.coverage_regression import (BinnedObservation, CalibrationScale,
                                           CoveragePredictionGrid, fit_surface_coverage)
    positive=np.flatnonzero(coverage>0)
    if len(positive)<2:
        raise ValueError('fit illustration needs two positive coverage knots')
    interval=int(positive[0]);fraction=0.37
    truth=float((1-fraction)*coverage[interval]+fraction*coverage[interval+1])
    fixed_scale=1.7
    # One fixed gain per channel is selected once for the entire grid.
    gains=1/np.max(resolved[0,:,0:5],axis=0)
    prediction=resolved[0,:,0:5]*gains
    control_prediction=matched[0,:,0:5]*gains
    support='manufactured arbitrary piecewise-constant interval/state/current number functionals; no wavelengths or physical spectra'
    kwargs={'monolayer_areal_density_m2':monolayer['areal_density_m2'],
            'monolayer_definition':monolayer['definition'],'monolayer_provenance':monolayer['provenance'],
            'signal_units':'arbitrary_linear_observation','bin_edges':np.arange(6,dtype=float),
            'bin_axis_units':'channel_index','bin_support':support,'status':'source_evaluated',
            'provenance':'exported manufactured source byte counts with the stated fixed linear functionals and fixed normalization gains'}
    grid=CoveragePredictionGrid(coverage,prediction,**kwargs)
    control_grid=CoveragePredictionGrid(coverage,control_prediction,**kwargs)
    background=np.full(5,0.03)
    observation_value=fixed_scale*((1-fraction)*prediction[interval]+fraction*prediction[interval+1])+background
    covariance=0.01**2*(0.8*np.eye(5)+0.2*np.ones((5,5)))
    observation=BinnedObservation(observation_value,covariance,background,
                                 signal_units=kwargs['signal_units'],bin_edges=kwargs['bin_edges'],
                                 bin_axis_units=kwargs['bin_axis_units'],bin_support=support,
                                 status='manufactured',provenance='noiseless interpolation of supplied predictions; arbitrary declared covariance/background, no experimental uncertainty claim')
    calibration=CalibrationScale('fixed',fixed_scale=fixed_scale,provenance='manufactured fixed linear normalization')
    fixed=fit_surface_coverage(grid,observation,calibration)
    fixed_control=fit_surface_coverage(control_grid,observation,calibration)
    if abs(fixed['best_fit']['coverage_ml']-truth)>1e-9 or fixed!=fixed_control:
        raise ValueError('manufactured fixed-response source/control fit failed')
    single_kwargs={**kwargs,'bin_edges':np.array([0.,1.])}
    single=CoveragePredictionGrid(coverage,prediction[:,:1],**single_kwargs)
    single_observation=BinnedObservation(observation_value[:1],covariance[:1,:1],background[:1],
                                        signal_units=kwargs['signal_units'],bin_edges=single_kwargs['bin_edges'],
                                        bin_axis_units=kwargs['bin_axis_units'],bin_support=support,
                                        status='manufactured',provenance='one arbitrary number channel from the manufactured interpolated observation')
    free=fit_surface_coverage(single,single_observation,CalibrationScale('free',provenance='manufactured unconstrained positive response scale'))
    if not free['diagnostics']['coverage_amplitude_degeneracy'] or not free['diagnostics']['coverage_unconstrained']:
        raise ValueError('single-number-channel free-amplitude degeneracy was not reported')
    return {'status':'manufactured_only','truth_coverage_ml':truth,'truth_grid_interval':interval,
            'truth_interpolation_fraction':fraction,'fixed_calibration_scale':fixed_scale,
            'channel_gains_observation_per_number':gains.tolist(),'covariance':covariance.tolist(),
            'known_background':background.tolist(),'observation':observation_value.tolist(),
            'fixed_multichannel_resolved':fixed,'fixed_multichannel_matched_control':fixed_control,
            'single_number_channel_free_scale':free,
            'interpretation':'The fixed-scale fit recovers a manufactured interpolated truth; the one-channel free scale leaves coverage confounded with amplitude. Neither is an experimental coverage estimate.'}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-dir',type=Path,default=WORK/'coverage-source-example')
    parser.add_argument('--output-dir',type=Path,default=WORK/'response-controls')
    args=parser.parse_args()
    if args.output_dir.exists():
        raise ValueError('use a new work-only output directory')
    closed_form=self_check()
    report_path=args.source_dir/'report.json'
    source_report=json.loads(report_path.read_text())
    if source_report['parameter_status']!='manufactured':
        raise ValueError('this oracle fixture requires explicit manufactured source parameters')
    for name,digest in source_report['output_sha256'].items():
        if sha(args.source_dir/name)!=digest:
            raise ValueError('input export artifact differs from source report')
    pins={name:sha(REPO/name) for name in source_report['source_sha256']}
    if pins!=source_report['source_sha256']:
        raise ValueError('exported source implementation changed before the independent inspection')
    evaluations=[];coverage=[]
    for entry in source_report['sources']:
        path=args.source_dir/entry['source_file']
        if sha(path)!=entry['source_sha256']:
            raise ValueError('source HDF digest differs from exported knot record')
        evaluations.append(evaluate_source(path));coverage.append(entry['coverage_ml'])
    resolved=np.stack([e['resolved'] for e in evaluations],axis=1)
    matched=np.stack([e['matched_component_redistribution'] for e in evaluations],axis=1)
    stored=np.stack([e['stored_matched_number_moments'] for e in evaluations],axis=1)
    if not np.array_equal(resolved[0],matched[0]):
        raise ValueError('exact full-width equality did not survive float summary serialization')
    if not np.any(resolved[1:]!=matched[1:]):
        raise ValueError('the selected manufactured source did not show any finite-aperture distinction')
    apertures=evaluations[0]['apertures']
    if any(e['apertures']!=apertures for e in evaluations):
        raise ValueError('source geometry changed across coverage knots')
    fits=fit_controls(np.asarray(coverage),resolved,matched,source_report['coverage_source_sweep']['inventory']['monolayer'])
    args.output_dir.mkdir(parents=True)
    np.savez_compressed(args.output_dir/'linear_number_controls.npz',coverage_ml=np.asarray(coverage),
                        resolved=resolved,matched_component_redistribution=matched,
                        stored_matched_number_moments=stored,kernel_weights=evaluations[0]['kernel_weights'])
    with (args.output_dir/'linear_number_controls.csv').open('w',newline='') as stream:
        writer=csv.writer(stream,lineterminator='\n')
        writer.writerow(['coverage_ml','aperture','kernel','resolved_number_functional','matched_component_number_functional','stored_matched_number_moment_functional'])
        for ai,(name,_,_) in enumerate(apertures):
            for ci,layer in enumerate(coverage):
                for ki,kernel in enumerate(KERNEL_NAMES):
                    writer.writerow([layer,name,kernel,float(resolved[ai,ci,ki]),float(matched[ai,ci,ki]),float(stored[ai,ci,ki])])
    (args.output_dir/'manufactured_fit_controls.json').write_text(json.dumps(fits,indent=2,allow_nan=False)+'\n')
    final={'schema':'mhdlab-independent-source-response-controls-v1','status':'passed',
           'parameter_status':'manufactured','observation_quantity':'arbitrary linear emitted-number functional; no spectra',
           'source_dir':str(args.source_dir),'source_report_sha256':sha(report_path),
           'source_implementation_sha256':pins,'oracle_script_sha256':sha(Path(__file__)),
           'regression_source_sha256':sha(REPO/'mhdlab/coverage_regression.py'),
           'identifiability_control_doc_sha256':sha(REPO/'docs/source_identifiability_controls.md'),
           'source_hdf_inspections':[e['diagnostic'] for e in evaluations],
           'exact_full_width_invariance_all_knots':True,'kernel_names':list(KERNEL_NAMES),
           'kernel_definitions':['1','1+normalized interval midpoint','1+normalized current-patch midpoint',
                                '1+lexicographic exact-state index','1/10+((3*time_index+5*state_index+7*current_index)%19)/19',
                                '(-1)^(time_index+state_index+current_index)*(1+normalizedtime+normalizedcurrent)',
                                '1 for first ceil(ninterval/2) intervals, else 0'],
           'apertures':[{'name':name,'left_m':left,'right_m':right} for name,left,right in apertures],
           'finite_aperture_max_absolute_difference':[float(np.max(np.abs(resolved[ai]-matched[ai]))) for ai in range(len(apertures))],
           'closed_form_oracle':closed_form,'manufactured_fixed_scale_fit_truth_ml':fits['truth_coverage_ml'],
           'manufactured_fixed_scale_fit_recovered_ml':fits['fixed_multichannel_resolved']['best_fit']['coverage_ml'],
           'single_number_channel_free_scale_coverage_unconstrained':fits['single_number_channel_free_scale']['diagnostics']['coverage_unconstrained'],
           'output_sha256':{p.name:sha(p) for p in args.output_dir.iterdir() if p.is_file()},'limits':LIMITS}
    (args.output_dir/'report.json').write_text(json.dumps(final,indent=2,allow_nan=False)+'\n')
    # Reopen persisted artifact rather than trusting successful serialization.
    with np.load(args.output_dir/'linear_number_controls.npz') as restored:
        for key,value in [('resolved',resolved),('matched_component_redistribution',matched),('stored_matched_number_moments',stored)]:
            if not np.array_equal(restored[key],value):raise ValueError('oracle NPZ round trip failed')
    print(json.dumps({'output_dir':str(args.output_dir),'report_sha256':sha(args.output_dir/'report.json'),
                      'coverage_knots':len(coverage),'full_width_invariance':True,
                      'finite_aperture_difference':True,'manufactured_truth_ml':fits['truth_coverage_ml'],
                      'manufactured_recovered_ml':fits['fixed_multichannel_resolved']['best_fit']['coverage_ml'],
                      'single_channel_free_amplitude_degeneracy':True},indent=2))


if __name__=='__main__':
    main()
