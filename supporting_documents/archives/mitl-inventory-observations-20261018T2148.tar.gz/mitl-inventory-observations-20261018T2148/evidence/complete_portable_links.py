"""Include existing public targets needed to review the extracted documents."""
import ast
import hashlib
import json
from pathlib import Path
import re
import shutil

repo = Path('/workspace/Power-Flow')
out = Path('/workspace/handoffs/mitl-inventory-observations-20261018T2148')
listing = json.loads((out/'source_file_list.json').read_text())
original = set(listing['byte_identical_public_files'])
names = original | {'configs/joint_source_manufactured.json'}
pending = list(names)
while pending:
    name = pending.pop()
    path = repo/name
    assert path.is_file(),name
    targets = []
    if path.suffix == '.md':
        for href in re.findall(r'\]\(([^)]+)\)',path.read_text()):
            if '://' in href or href.startswith('#'):
                continue
            target = (path.parent/href.strip('<>').split('#',1)[0]).resolve()
            assert target.is_relative_to(repo) and target.is_file(),(name,href)
            targets.append(target.relative_to(repo).as_posix())
    if path.suffix == '.py':
        for node in ast.walk(ast.parse(path.read_text())):
            if isinstance(node,ast.ImportFrom) and node.module:
                module = ('mhdlab/'+node.module.replace('.','/')+'.py' if node.level else
                          node.module.replace('.','/')+'.py' if node.module.startswith('mhdlab.') else None)
                if module and (repo/module).is_file():
                    targets.append(module)
        for node in ast.parse(path.read_text()).body:
            if isinstance(node,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='CODE_PATHS' for t in node.targets):
                targets.extend(ast.literal_eval(node.value))
    for target in targets:
        if target not in names:
            names.add(target)
            pending.append(target)
assert not names.intersection({'mhdlab/runner.py','mhdlab/chemistry.py','mhdlab/state_kinetics.py',
                               'mhdlab/kinetic_gap.py','mhdlab/cr_data.py','mhdlab/bolsig.py'})
for name in names:
    target = out/'source'/name
    target.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(repo/name,target)
listing['byte_identical_public_files']=sorted(names)
(out/'source_file_list.json').write_text(json.dumps(listing,indent=2)+'\n')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
(out/'source-files.sha256').write_text(''.join(f'{sha(out/"source"/name)}  {name}\n' for name in sorted(names)))
print(json.dumps({'public_files':len(names),'added_review_dependencies':sorted(names-original),
                  'no_separately_owned_solver_implementation':True},indent=2))
