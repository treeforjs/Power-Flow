"""Prepare a portable upstream-source subset without unrelated solver imports."""
import ast
import hashlib
import json
from pathlib import Path
import shutil

repo = Path('/workspace/Power-Flow')
out = Path('/workspace/handoffs/mitl-inventory-observations-20261018T2148')
assert not out.exists(), out
source = out/'source'
source.mkdir(parents=True)
names = {
    'mhdlab/coverage_inventory.py', 'mhdlab/coverage_regression.py',
    'tools/build_coverage_sources.py', 'tests/test_coverage_inventory.py',
    'tests/test_coverage_sources_cli.py', 'configs/coverage_source_manufactured.json',
    'docs/coverage_source_inventory.md', 'docs/source_identifiability_controls.md',
    'docs/surface_coverage_inference.md',
}
tool = ast.parse((repo/'tools/build_coverage_sources.py').read_text())
for node in tool.body:
    if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == 'CODE_PATHS' for target in node.targets):
        names.update(ast.literal_eval(node.value))
pending = list(names)
while pending:
    name = pending.pop()
    if not name.endswith('.py'):
        continue
    for node in ast.walk(ast.parse((repo/name).read_text())):
        if isinstance(node, ast.ImportFrom) and node.level and node.module:
            relative = 'mhdlab/'+node.module.replace('.', '/')+'.py'
            if (repo/relative).is_file() and relative not in names:
                names.add(relative)
                pending.append(relative)
for name in sorted(names):
    target = source/name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(repo/name, target)
wrappers = {
    'mhdlab/__init__.py': '"""Portable heating/desorption source verification subset."""\n',
    'pytest.ini': '[pytest]\npythonpath = .\n',
    'requirements.txt': 'numpy\nscipy\nh5py\nmatplotlib\npytest\nPyMuPDF\n',
    'README.md': '''# Parent inventory and source-grid verification subset

The named public files are byte-identical to the recorded repository commit.
Four packaging wrappers are listed separately in `source_file_list.json`.
The package initializer avoids unrelated solver imports. No separately owned
transport, collision or radiative implementation is included.

Run the new inventory/export checks with:

```sh
python -W error -m pytest tests/test_coverage_inventory.py tests/test_coverage_sources_cli.py
```

Generate an explicitly manufactured source sweep with:

```sh
python tools/build_coverage_sources.py --demo --output-dir /tmp/coverage-sources --plot
```

The monolayer convention, parent partition, kinetics and temperatures in that
example are manufactured. No physical surface coverage or spectrum is inferred.
See `docs/coverage_source_inventory.md` and the top-level handoff for source
associations, experimental-recovery limits and continuation work.
''',
}
for name, body in wrappers.items():
    (source/name).write_text(body)
listing = {'byte_identical_public_files': sorted(names), 'packaging_wrappers': sorted(wrappers)}
(out/'source_file_list.json').write_text(json.dumps(listing, indent=2)+'\n')
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
(out/'source-files.sha256').write_text(''.join(f'{sha(source/name)}  {name}\n' for name in sorted(names)))
print(json.dumps({'output':str(out), 'public_files':len(names), 'packaging_wrappers':len(wrappers)}, indent=2))
