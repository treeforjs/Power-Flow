# Acceptance handoff: source-level response controls

The independent work-only oracle passes on the six exported manufactured
coverage knots. It reopens each source HDF, checks its recorded SHA-256 digest
and the export's 16 implementation pins, and uses the actual stored patch
areas. The histories have eight intervals, two independent pools, two current
patches and six width patches. No gap, collision, radiation, detector or physical
spectral calculation is performed.

For each original interval/pool/current/width component, the matched control
retains its component label and moves only its launch-width distribution to a
uniform distribution across the same width. Seven arbitrary linear number
kernels depend on interval, exact state and current patch, including one signed
kernel. With complete width collection, resolved and matched responses agree
**exactly in rational arithmetic** at every knot. The separately stored
matched-width HDF number moments preserve each interval/pool/current marginal
within relative serialization roundoff of `2.998e-16`. The closed-form toy
control also uses unequal patch areas and signed weights.

Finite collection breaks this particular invariance because its kernel depends
on width position. The oracle integrates the exact overlap between each patch
and three declared partial apertures. For example, its central aperture is
`[-0.00105, 0.00055] m` inside the manufactured `[-0.0025, 0.0025] m` face.
Resolved acceptance uses each original patch's fractional overlap; matched
acceptance uses the aperture's fraction of the complete width. No propagation
or local nonlinear chemistry is needed to produce this source-only difference.
These aperture bounds are an arithmetic fixture, not recovered slit geometry.

The fixed-scale illustration fits arbitrary linear number observations on the
supplied prediction grid. A manufactured interpolation at `0.3425` declared
monolayers is recovered as `0.3425`. The single-number-channel illustration with
a free positive response scale reports coverage-amplitude degeneracy. The
observation, covariance, background, response normalization and monolayer
convention are all explicitly manufactured; neither result estimates an
experimental surface inventory.

The next transport/spectral owner should first retain the same resolved and
matched **full** launch mixture and recover the full-width invariance under a
fixed linear response whose complete transport, boundary and collection rules
are independent of launch width. The HDF's matched number/energy moments alone
do not define that full mixture: they must not be used to replace component
temperatures, within-interval emission times, exact states or velocities by
averages. Existing paired emission interfaces or an equivalent explicit
component representation must retain those variables. The oracle here only
tests response weights constant within an interval and patch; it does not prove
continuous-time or velocity-dependent equivalence from number moments alone.

Before interpreting a physical spectral difference, the owner needs these
identified inputs and acceptance conditions:

- Pin the source schema/law, HDF bytes, prescribed thermal history, independent
  inventory convention and allocation hypotheses. Map opaque outgoing state
  identifiers explicitly to the separately supplied transport/chemistry state
  catalog; an initial pool allocation is not a dissociation yield.
- Declare physical launch coordinates and outward normal, finite foil width,
  current-direction length, gap boundaries and loss/reinjection rules. State
  whether the control is periodic, unbounded or fully collected; uniform bulk
  coefficients alone do not eliminate finite-width losses.
- Supply the complete diagnostic collection geometry, spatial and spectral
  binning, optical gate and wavelength response with factor ownership. The
  dissertation's lamp étendue must not be assigned to the different Mykonos
  relay. Keep unresolved absolute-response factors explicit.
- Demonstrate the limiting linear closure before enabling one declared
  width-sensitive mechanism at a time: finite aperture/loss, nonuniform field
  or background, or source-dependent nonlinear plasma/chemistry feedback.
  Preserve energy, number, time/state/velocity correlations and unequal source
  weights. Separate deterministic closure error from sampling error.
- For spectra, supply the independently owned collision/radiation and
  instrument-response definitions and test their numerical convergence. A
  nonzero source statistic or aperture response is not itself a measured
  spectral distinction or evidence of experimental identifiability.

Evidence is `report.json`, `linear_number_controls.npz/.csv` and
`manufactured_fit_controls.json` in this directory. The report pins every
source HDF and source implementation, the regression implementation, the
oracle script and output artifacts. The original captured command is in the
parent pass's `response_controls_initial.log` and `commands.jsonl`; it exited
zero with warnings treated as errors. No unchanged passing suite was repeated.
