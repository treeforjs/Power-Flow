"""Bounded high-precision manufactured nonlinear source-emission windows.

This standalone mathematical oracle calls no production depletion, transport,
collision or radiation solver. Exact decimal inputs and exactly projected binary
inputs are separate reference problems. Local delays are not photon gate times.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
import platform
import sys
import time

import mpmath as mp

PRECISIONS = (100, 160)
PROBABILITIES = ("0.1", "0.5", "0.9")
CASES = (
    ("moderate_nonlinear", "5", "3", ".1", ".7", "1", "1e18"),
    ("maximum_qualified_coupling", "512", "1e6", ".001", ".01", ".1", "1e18"),
    ("late_endpoint_cdfs_round_one", "4", "100", "100", "101", "200", "1e18"),
    ("narrow_local_window", "3", "4", "1", "1.0000000001", "2", "1e18"),
    ("late_number_below_float", "4", "100", "1000", "1001", "2000", "1e18"),
    ("late_fraction_underflow_rescued_by_population", "4", "1", "45000", "45001", "46000", "1e300"),
    ("window_endpoints_merge_in_float", "3", "4", "1", "1.0000000000000001", "2", "1e18"),
    ("late_origin_loses_delay_spread", "2", "1e-12", "1e12", "1000000000000.0003", "1000000000001", "1e18"),
)
COLUMNS = ("initial_coupling", "initial_rate_s_inv", "start_s", "stop_s", "parent_duration_s", "initial_number")


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def integral(s, c):
    """Separated integral, using Ei except near its subtraction singularity."""
    if s == 0:
        return mp.mpf(0)
    if s < mp.mpf(".05")/(1+c):
        # Rescaled positive integration preserves tiny s, including s~1e-400.
        return s*mp.quad(lambda v: mp.exp(c*(-mp.expm1(-s*v))), [0, 1])
    value = mp.exp(c)*(mp.ei(-c)-mp.ei(-c*mp.exp(-s)))
    if value <= 0:
        raise ArithmeticError("nonpositive separated integral")
    return value


def depletion(c, log_rate, duration):
    """Safeguarded Newton in log depletion; bracket follows s<=I<=s*exp(c)."""
    if duration == 0:
        return mp.mpf(0), {"iterations": 0, "absolute_log_time_residual": mp.mpf(0)}
    log_h = log_rate+mp.log(duration)
    lower, upper = log_h-c, log_h
    guess = mp.log(mp.log1p(c*mp.exp(log_h))/c)
    x = min(upper, max(lower, guess))
    tolerance = mp.power(10, -(mp.mp.dps-30))
    for iteration in range(1, 201):
        s = mp.exp(x)
        log_integral = mp.log(integral(s, c))
        error = log_integral-log_h
        if abs(error) <= tolerance:
            return s, {"iterations": iteration, "absolute_log_time_residual": abs(error)}
        if error > 0:
            upper = x
        else:
            lower = x
        derivative = mp.exp(x+c*(-mp.expm1(-s))-log_integral)
        proposed = x-error/derivative
        x = proposed if lower < proposed < upper else (lower+upper)/2
    raise ArithmeticError("bounded log-depletion solve failed its target")


def phi(s):
    return -mp.expm1(-s)


def logphi(s):
    return mp.log(-mp.expm1(-s)) if s <= 1 else mp.log1p(-mp.exp(-s))


def logsum(a, b):
    pivot = max(a, b)
    return pivot+mp.log(mp.exp(a-pivot)+mp.exp(b-pivot))


def oracle(inputs, digits):
    with mp.workdps(digits):
        c, rate, start, stop, duration, number = inputs
        assert 0 < c <= 512 and rate > 0 and number > 0 and 0 <= start < stop <= duration
        log_rate = mp.log(rate)
        length = stop-start
        sa, start_solve = depletion(c, log_rate, start)
        sb, stop_solve = depletion(c, log_rate, stop)
        sd, parent_solve = depletion(c, log_rate, duration)
        ca = c*mp.exp(-sa)
        log_ra = log_rate-c*phi(sa)
        delta, local_solve = depletion(ca, log_ra, length)
        local_fraction = phi(delta)
        log_fraction = -sa+logphi(delta)
        log_number = mp.log(number)+log_fraction
        log_probability = log_fraction-logphi(sd)
        # Independent unrebased endpoints and a positive global increment
        # integral check the local construction without CDF subtraction.
        independent_log_mass = -sa+logphi(sb-sa)
        global_increment = delta*mp.quad(
            lambda v: mp.exp(c*phi(sa+delta*v)-log_rate), [0, 1])
        positive_increment_error = abs(mp.log(global_increment/length))
        original_endpoint_error = abs(independent_log_mass-log_fraction)
        local_mid, mid_solve = depletion(ca, log_ra, length/2)
        cm = ca*mp.exp(-local_mid)
        log_rm = log_ra-ca*phi(local_mid)
        right_delta, right_solve = depletion(cm, log_rm, length/2)
        log_left_mass = -sa+logphi(local_mid)
        log_right_mass = -sa-local_mid+logphi(right_delta)
        partition_error = abs(logsum(log_left_mass, log_right_mass)-log_fraction)
        delays, quantile_cdf_errors, quantile_time_errors = [], [], []
        for probability in PROBABILITIES:
            u = mp.mpf(probability)
            target_delta = -mp.log1p(-u*local_fraction)
            delay = integral(target_delta, ca)*mp.exp(-log_ra)
            checked_delta, evidence = depletion(ca, log_ra, delay)
            checked_cdf = phi(checked_delta)/local_fraction
            delays.append(delay)
            quantile_cdf_errors.append(abs(checked_cdf-u))
            quantile_time_errors.append(evidence["absolute_log_time_residual"])
        tolerance = mp.power(10, -(digits-55))
        checks = {
            "independent_endpoint_log_mass_difference": original_endpoint_error,
            "positive_global_increment_log_time_difference": positive_increment_error,
            "two_rebased_halves_log_mass_partition_difference": partition_error,
            "maximum_local_quantile_cdf_difference": max(quantile_cdf_errors),
            "maximum_local_quantile_log_time_residual": max(quantile_time_errors),
        }
        assert all(value < tolerance for value in checks.values()), checks
        assert all(0 < delay < length for delay in delays)
        assert log_probability <= tolerance and 0 < ca <= c
        endpoint_cdfs = [phi(sa)/phi(sd), phi(sb)/phi(sd)]
        assert abs(phi(mp.mpf(0))/local_fraction) == 0
        assert abs(phi(delta)/local_fraction-1) == 0
        sensitivity = integral(sa, c)*mp.exp(-c*phi(sa)) if sa else mp.mpf(0)
        return {
            "start_s": start, "local_duration_s": length,
            "start_log_survival_depletion": sa, "stop_log_survival_depletion": sb,
            "local_log_survival_depletion": delta, "parent_log_survival_depletion": sd,
            "rebased_coupling": ca, "rebased_log_rate_s_inv": log_ra,
            "log_source_fraction": log_fraction, "log_released_number": log_number,
            "log_parent_conditional_probability": log_probability,
            "released_number": mp.exp(log_number), "starting_survival_fraction": mp.exp(-sa),
            "local_released_fraction_of_start_survivors": local_fraction,
            "local_delay_quantiles_s": delays, "log_local_delay_quantiles_s": [mp.log(value) for value in delays],
            "original_offset_quantiles_s": [start+delay for delay in delays],
            "original_conditional_endpoint_cdfs": endpoint_cdfs,
            "local_cdf_endpoints": [mp.mpf(0), mp.mpf(1)],
            "start_depletion_sensitivity_to_log_start_time": sensitivity,
            "split_half_log_source_fractions": [log_left_mass, log_right_mass],
            "checks": checks, "check_tolerance": tolerance,
            "root_evidence": {"start": start_solve, "stop": stop_solve, "parent": parent_solve, "local": local_solve, "local_left_half": mid_solve, "local_right_half": right_solve},
        }


def stringify(value, digits):
    if isinstance(value, mp.mpf):
        return mp.nstr(value, digits)
    if isinstance(value, dict):
        return {key: stringify(item, digits) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [stringify(item, digits) for item in value]
    return value


def exact_binary(value):
    numerator, denominator = value.as_integer_ratio()
    return mp.mpf(numerator)/denominator


def float_witness(reference):
    log_number = float(reference["log_released_number"])
    try:
        count = math.exp(log_number)
    except OverflowError:
        count = None
    delay = [float(value) for value in reference["local_delay_quantiles_s"]]
    absolute = [float(value) for value in reference["original_offset_quantiles_s"]]
    original_logs = [math.log(value) if value > 0 else None for value in absolute]
    endpoint = [float(value) for value in reference["original_conditional_endpoint_cdfs"]]
    return {
        "count_from_rounded_log": count,
        "positive_count_underflowed": count == 0,
        "direct_float_budget_representation_available": count is not None and count > 0,
        "endpoint_float_cdfs": endpoint, "naive_endpoint_cdf_difference": endpoint[1]-endpoint[0],
        "local_delay_quantiles_s": delay, "original_offset_quantiles_s": absolute,
        "original_offsets_lose_quantile_spread": len(set(absolute)) < len(absolute),
        "original_log_offsets_lose_quantile_spread": len(set(original_logs)) < len(original_logs),
        "local_delay_underflowed": any(value == 0 for value in delay),
        "runtime_window_numerically_qualified": False,
        "qualification": "Input projection and represented reference quantities only; no float runtime source-window algorithm or host budget acceptance is qualified.",
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    assert not args.output.exists(), "preserve previous reference evidence"
    args.output.parent.mkdir(parents=True, exist_ok=True)
    records = []
    started = time.monotonic()
    for case in CASES:
        label, *decimal_inputs = case
        case_started = time.monotonic()
        with mp.workdps(max(PRECISIONS)+30):
            exact_inputs = tuple(mp.mpf(value) for value in decimal_inputs)
            projected = [float(value) for value in decimal_inputs]
            projection_qualified = (all(math.isfinite(value) for value in projected)
                                    and 0 < projected[0] <= 512 and projected[1] > 0 and projected[-1] > 0
                                    and 0 <= projected[2] < projected[3] <= projected[4])
            binary_inputs = tuple(exact_binary(value) for value in projected)
        exact_results = [oracle(exact_inputs, digits) for digits in PRECISIONS]
        with mp.workdps(max(PRECISIONS)):
            checked_keys = ("log_source_fraction", "log_released_number", "log_parent_conditional_probability", "rebased_log_rate_s_inv")
            precision_changes = {key: abs(exact_results[1][key]-exact_results[0][key]) for key in checked_keys}
            precision_changes["maximum_log_delay_change"] = max(abs(a-b) for a, b in zip(exact_results[1]["log_local_delay_quantiles_s"], exact_results[0]["log_local_delay_quantiles_s"]))
            assert max(precision_changes.values()) < mp.mpf("1e-60"), precision_changes
        item = {
            "label": label, "parameter_status": "manufactured", "input_columns": COLUMNS,
            "exact_decimal_inputs": decimal_inputs,
            "exact_decimal_reference": stringify(exact_results[1], max(PRECISIONS)),
            "precision_refinement": {"digits": PRECISIONS, "changes": stringify(precision_changes, max(PRECISIONS)), "interpretation": "finite arithmetic refinement change; not a certified error bound"},
            "float_projection": {"qualified_input_domain": projection_qualified, "input_hex": [value.hex() for value in projected], "definition": "each float converted through exact integer ratio at 190 decimal digits; original decimal problem retained separately"},
        }
        if projection_qualified:
            binary_result = oracle(binary_inputs, max(PRECISIONS))
            item["float_projection"]["high_precision_projected_input_reference"] = stringify(binary_result, max(PRECISIONS))
            item["float_projection"]["float_witness"] = float_witness(binary_result)
        else:
            item["float_projection"]["reason"] = "positive exact-decimal window endpoints merge or leave the supported finite float input domain"
        item["elapsed_s"] = time.monotonic()-case_started
        records.append(item)
        print(json.dumps({"case": label, "input_projection_qualified": projection_qualified, "elapsed_s": item["elapsed_s"]}), flush=True)
    result = {
        "schema": "nonlinear-temkin-source-window-reference-v1", "parameter_status": "manufactured",
        "quantity": "number of one abstract parent population; no molecule, state or mass assignment",
        "script_sha256": sha(__file__), "precision_digits": PRECISIONS, "cases": records,
        "equations": {
            "original_law": "ds/dt=r0*exp[-c*(1-exp(-s))], 0<c<=512",
            "separated_time": "I(s,c)/r0, I=integral_0^s exp[c*(1-exp(-v))]dv",
            "rebased_coupling": "c_a=c*exp(-s_a)",
            "rebased_log_rate": "log(r_a)=log(r0)-c*(1-exp(-s_a))",
            "local_window_mass": "log(deltaN/N0)=-s_a+log[-expm1(-delta_s)]",
            "local_quantile": "delta_s(u)=-log1p[-u*(-expm1(-delta_s))]; delay=I(delta_s(u),c_a)/r_a",
        },
        "methods": {
            "integral": "arbitrary-precision exponential-integral primitive; rescaled positive quadrature near small-s subtraction singularity",
            "inversion": "log-depletion safeguarded Newton with analytic derivative and bracket log(h)-c<=log(s)<=log(h)",
            "independent_checks": "unrebased endpoint inversion; direct positive global increment quadrature; two independently rebased half-window log masses; conditional-CDF replay at three quantiles",
            "error_target": "root log-time residual <10^[-(digits-30)]; independent comparison target <10^[-(digits-55)] to accommodate narrow endpoint subtraction; log-mass refinement separately checked",
        },
        "summary": {"new_cases": len(records), "qualified_float_input_domains": sum(item["float_projection"]["qualified_input_domain"] for item in records), "all_checks_passed": True, "elapsed_s": time.monotonic()-started},
        "runtime": {"python": sys.version, "executable": sys.executable, "platform": platform.platform(), "mpmath": mp.__version__},
        "limits": ["Standalone high-precision references; no public runtime gating implementation or numerical acceptance contract is installed.", "Manufactured reduced-law coefficients only, not measured water/foil rates, surface inventory, reaction branching or a state catalog.", "Starting survival, local depletion and local delay are separate; absolute timestamps or log timestamps may erase conditional spread.", "A finite log mass does not establish a representable conservative packet count, host budget or energy transaction.", "Original full-interval depletion sentinels and endpoint CDF subtraction are not valid late-window source-mass estimators.", "Conditional timing moments, photon timing after transport and gate-conditioned spectra are not evaluated.", "Source-emission windows are distinct from photon observation gates; earlier emitted particles can contribute photons later.", "Finite precision agreement is evidence of arithmetic stability for these cases, not a certified global bound or physical model validation."],
    }
    args.output.write_text(json.dumps(result, indent=2, allow_nan=False)+"\n")
    print(json.dumps({**result["summary"], "sha256": sha(args.output)}, indent=2), flush=True)


if __name__ == "__main__":
    main()
