"""Read-only integrity and numerical-domain summary; no oracle solve repeated."""
import hashlib
import json
import math
from pathlib import Path

import mpmath as mp

ROOT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def exp_or_zero(value):
    try:
        return math.exp(float(value))
    except OverflowError:
        return None


reference = ROOT/"reference.json"
report = json.loads(reference.read_text())
assert report["script_sha256"] == sha(ROOT/"verify_nonlinear_windows.py")
assert len(report["cases"]) == 8 and report["summary"]["all_checks_passed"]
assert not (ROOT/"assessment.json").exists()
cases = []
changes, checks = [], []
with mp.workdps(170):
    for case in report["cases"]:
        result = case["exact_decimal_reference"]
        changes.extend(mp.mpf(value) for value in case["precision_refinement"]["changes"].values())
        checks.extend(mp.mpf(value) for value in result["checks"].values())
        projection = case["float_projection"]
        item = {"label": case["label"], "float_input_domain_qualified": projection["qualified_input_domain"],
                "log_source_fraction": result["log_source_fraction"], "log_released_number": result["log_released_number"],
                "start_depletion": result["start_log_survival_depletion"], "rebased_coupling": result["rebased_coupling"],
                "start_survival_sensitivity_to_log_time": result["start_depletion_sensitivity_to_log_start_time"]}
        if projection["qualified_input_domain"]:
            projected = projection["high_precision_projected_input_reference"]
            checks.extend(mp.mpf(value) for value in projected["checks"].values())
            witness = projection["float_witness"]
            source_fraction = exp_or_zero(projected["log_source_fraction"])
            count = exp_or_zero(projected["log_released_number"])
            item.update(
                projected_log_source_fraction=projected["log_source_fraction"],
                projected_log_released_number=projected["log_released_number"],
                float_source_fraction_underflowed=source_fraction == 0,
                float_count_underflowed=count == 0,
                float_count_from_log=count,
                fraction_underflow_but_count_representable=source_fraction == 0 and count is not None and count > 0,
                endpoint_cdf_subtraction_is_zero=witness["naive_endpoint_cdf_difference"] == 0,
                original_offsets_lose_quantile_spread=witness["original_offsets_lose_quantile_spread"],
                original_log_offsets_lose_quantile_spread=witness["original_log_offsets_lose_quantile_spread"],
                local_delays_positive=all(value > 0 for value in witness["local_delay_quantiles_s"]),
                runtime_window_numerically_qualified=witness["runtime_window_numerically_qualified"],
            )
            assert item["local_delays_positive"] and not item["runtime_window_numerically_qualified"]
        cases.append(item)
    assert sum(item["float_input_domain_qualified"] for item in cases) == 7
    assert any(item.get("fraction_underflow_but_count_representable") for item in cases)
    assert any(item.get("float_count_underflowed") for item in cases)
    assert any(item.get("original_offsets_lose_quantile_spread") or item.get("original_log_offsets_lose_quantile_spread") for item in cases)
    assert any(item.get("endpoint_cdf_subtraction_is_zero") and not item.get("float_count_underflowed") for item in cases)
    result = {
        "schema": "nonlinear-source-window-readback-v1", "parameter_status": "manufactured",
        "reference_sha256": sha(reference), "producer_script_sha256": report["script_sha256"],
        "readback_script_sha256": sha(__file__), "cases": cases,
        "summary": {"new_cases": len(cases), "qualified_float_input_domains": 7,
                    "maximum_finite_precision_log_quantity_change": mp.nstr(max(changes), 30),
                    "maximum_independent_comparison_difference": mp.nstr(max(checks), 30),
                    "fraction_underflow_count_rescue_cases": sum(bool(item.get("fraction_underflow_but_count_representable")) for item in cases),
                    "count_underflow_cases": sum(bool(item.get("float_count_underflowed")) for item in cases),
                    "all_readback_checks_passed": True},
        "limits": "Saved arithmetic reference checks only; no oracle integration repeated, runtime window or host budget qualified."
    }
(ROOT/"assessment.json").write_text(json.dumps(result, indent=2, allow_nan=False)+"\n")
print(json.dumps({**result["summary"], "assessment_sha256": sha(ROOT/"assessment.json")}, indent=2))
