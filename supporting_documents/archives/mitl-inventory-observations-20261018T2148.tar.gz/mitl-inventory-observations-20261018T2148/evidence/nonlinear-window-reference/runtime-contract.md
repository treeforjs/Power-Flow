# Nonlinear source-emission windows: reference and next runtime contract

This work-only reference adds eight manufactured nonlinear cases. It does not
install a production source-window interface. It leaves the public source,
packet and solver implementations unchanged. The preceding eleven
constant-barrier cases were read as prior evidence and were not rerun.

`reference.json` contains separate exact-decimal and exactly projected float64
problems, their input hexadecimal values, 100/160-digit calculations, numerical
checks and explicit limitations. Seven projected input domains are qualified;
one positive decimal window has merged float64 endpoints and is rejected in
that domain. “Qualified input domain” means the declared parameters survive
projection. It does not mean that any float64 runtime algorithm, packet budget
or host transaction has been accepted.

The script uses system Python with mpmath 1.3.0. Its exact executable/version
and script hash are recorded. mpmath was unavailable in the project virtual
environment; no dependency or environment was changed. Both substantive
commands, exits and log hashes are in the enclosing `commands.jsonl`.

## Derived local law

For one frozen-temperature original source interval, define positive log
depletion `s=-log(N/N0)`, initial per-parent rate `r0`, and coupling `0<c<=512`:

```text
ds/dt = r0 exp[-c(1-exp(-s))]
I(s,c) = integral_0^s exp[c(1-exp(-v))] dv
t = I(s,c)/r0.
```

At original offset `a`, obtain `s_a` from the original law. With local delay
`tau=t-a` and local depletion `delta=s-s_a`, the same physical law becomes

```text
c_a = c exp(-s_a)
log(r_a) = log(r0) - c[-expm1(-s_a)]
I(delta,c_a) = r_a tau
log(window_fraction_of_N0) = -s_a + log[-expm1(-delta_b)]
log(window_number) = log(N0) + log(window_fraction_of_N0).
```

Here `delta_b` is the depletion during `h=b-a`. This operation retains the
original material parameters, temperature, state/pool association and physical
inventory. It does not introduce another parent or restart inventory at `N0`.
`c_a` and `r_a` are derived local coefficients, not fitted new material values.

The parent-emission conditional log probability subtracts
`log[-expm1(-s_parent)]` from the log window fraction. A stable `log1mexp`
branch uses `log1p(-exp(-s))` at large `s`, retaining the tiny log normalizer
even when the ordinary released fraction rounds to one.

Conditional local time quantiles follow directly from an open probability `u`:

```text
Z = -expm1(-delta_b)
delta_u = -log1p(-u*Z)
tau_u = I(delta_u,c_a)/r_a.
```

Keep `a` and `tau_u` separately. Their sum and the logarithm of their sum can
lose conditional timing spread. A positive local window does not necessarily
have a representable absolute midpoint or distinct absolute quantiles.

## Numerical evidence

The separated integral uses the exponential-integral primitive
`exp(c)[Ei(-c)-Ei(-c exp(-s))]`. Near small-`s` cancellation it instead uses
the positive rescaled integral
`s * integral_0^1 exp[c(-expm1(-s*z))] dz`.

Safeguarded Newton iteration solves log depletion within
`log(h*r)-c <= log(s) <= log(h*r)`. Its derivative is evaluated from the
same positive separated law. The reference root target is an absolute
log-time residual below `10^[-(digits-30)]`.

Independent checks compare the rebased window with inversion at the original
endpoints, direct positive global-increment quadrature, and the log-sum of two
separately rebased local half-windows. Each of three conditional quantiles is
replayed through a local depletion solve. The half-window partition retains
local coordinates; it does not round an internal split to an absolute float
timestamp. Local CDF endpoints are zero and one under the stated conditional
normalization. These checks use different representations of the same
mathematical law, not an independent physical desorption model.

The largest observed 100-to-160-digit change among the checked log quantities
is `8.70055745e-72`. The largest independent comparison difference at 160 digits
is `3.81693293e-131`. These finite arithmetic results are not rigorous global
error bounds. References do not evaluate gated conditional time moments.

The purposeful cases cover moderate coupling, initial `c=512`, late endpoint
CDF cancellation, a narrow local window, an underflowed count, a fraction that
underflows while its count remains representable, merged projected endpoints
and lost log-absolute timing spread. For the late rescue case,
`log(window_fraction)` is approximately `-830.18018` and
`log(window_number)` is approximately `-139.40466`; multiplying a rounded zero
fraction by `1e300` would erase that positive count. Another case has
`log(window_number)` approximately `-1792.25919` and cannot supply a positive
float64 packet budget.

In the deepest tails, `c_a` itself is positive in the arbitrary-precision
reference but rounds to zero in float64. The reference does not authorize
silently substituting a constant-barrier law. A future implementation must
retain its log representation or explicitly bound the approximation's effect
on the requested time and log-mass observables.

## Runtime acceptance requirements

An immutable future window record should retain the parent law/reference,
original local start/stop, `s_a`, local release normalization, log source amount,
conditional parent probability, original patch area, state/pool identity and
temperature. It should distinguish mathematical log amounts from represented
areal/physical counts and from accepted conservative budgets. Empty windows
need their own explicit convention. Invalid, out-of-parent or merged projected
endpoints must fail without changing an inventory.

Starting survival and local release require separate error qualification.
For enclosing errors on `s_a` and `delta_b`, the mean-value bound is

```text
abs(error(log window mass))
    <= abs(error(s_a)) + abs(error(delta_b))/expm1(delta_min),
```

where `delta_min>0` bounds the local depletion below. At a tiny local depletion,
the second term is approximately its relative error. An inversion's relative
time residual alone is insufficient: the original law has

```text
ds_a / d log(a) = I(s_a,c) / exp[c(1-exp(-s_a))],
```

which grows approximately as `s_a` in a late tail. The reference records this
sensitivity. A future acceptance rule must bound absolute log-mass error as
well as time error; agreement at two arithmetic precisions is supporting
evidence, not an enclosure or certified runtime guarantee.

Partition checks must test the late window locally in log arithmetic. Adding a
tiny tail to an early release near one can hide all tail errors. The original
whole-interval large-depletion sentinel does not establish zero late-window
mass. Endpoint-CDF subtraction and inversion through its rounded difference
are unsuitable when both endpoints round to one.

Preserve original source number/energy associations and avoid accepting a
nonzero mathematical log amount as a represented conservative launch budget.
A sampling interface must specify local time representation, allocation,
weights, underflow/quantization flags and energy transaction semantics before
it can be called by a host. None of those host operations is implemented here.

These windows select source emission times. A photon observation gate selects
later photon times after transport and excitation/radiation. Earlier neutral
emission cannot be discarded solely because it precedes a recorded photon
gate. No gap evolution, chemistry, radiation, molecular state data or spectral
prediction is provided by this reference.
