"""Verify bytes in the compressed delivery and their public source associations."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess
import tarfile

root = Path('/workspace/handoffs/mitl-inventory-observations-20261018T2148')
archive = root.with_suffix('.tar.gz')
repo = Path('/workspace/Power-Flow')
sha = lambda b: hashlib.sha256(b).hexdigest()
with tarfile.open(archive,'r:gz') as stream:
    members = stream.getmembers()
    assert len({m.name for m in members}) == len(members)
    for item in members:
        parts = PurePosixPath(item.name).parts
        assert parts and parts[0] == root.name and '..' not in parts
        assert not PurePosixPath(item.name).is_absolute()
        assert item.isdir() or item.isfile(), item.name
    payload = {str(PurePosixPath(m.name).relative_to(root.name)):stream.extractfile(m).read()
               for m in members if m.isfile()}
manifest = {}
for line in payload['MANIFEST.sha256'].decode().splitlines():
    digest,name = line.split('  ',1)
    assert name not in manifest
    manifest[name] = digest
assert set(payload) == set(manifest)|{'MANIFEST.sha256'}
for name,digest in manifest.items():
    assert sha(payload[name]) == digest, name
listing = json.loads(payload['source_file_list.json'])
for name in listing['byte_identical_public_files']:
    assert payload['source/'+name] == (repo/name).read_bytes(), name
record = json.loads(payload['verification.json'])
commit = subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
assert record['source_commit'] == commit
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip()
changed = subprocess.check_output(['git','diff','--name-only','f4bcf3e4d0e402c3ca57b8ef91dd4e09717e2fda','HEAD'],cwd=repo,text=True).splitlines()
assert set(changed).issubset(set(listing['byte_identical_public_files']))
assert set(changed) == {
    'mhdlab/coverage_inventory.py','tests/test_coverage_inventory.py','docs/coverage_source_inventory.md',
    'tools/build_coverage_sources.py','tests/test_coverage_sources_cli.py','configs/coverage_source_manufactured.json',
    'tools/recover_dissertation_observed_spectrum.py','tests/test_dissertation_observed_spectrum.py',
    'data/dissertation/observed_spectrum_4_15.csv','data/dissertation/observed_spectrum_4_15.json',
    'docs/observed_spectrum_recovery.md',
}
result = {'archive':str(archive),'sha256':sha(archive.read_bytes()),'bytes':archive.stat().st_size,
          'manifest_entries':len(manifest),'archive_regular_files':len(payload),
          'unsafe_archive_entries':0,'public_files_byte_identical':len(listing['byte_identical_public_files']),
          'source_commit':commit,'public_paths_changed':changed,'results':record['results']}
Path(__file__).with_name('delivery_verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
