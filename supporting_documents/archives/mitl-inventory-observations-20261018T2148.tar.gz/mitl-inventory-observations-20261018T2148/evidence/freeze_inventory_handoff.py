"""Freeze source-inventory code, response controls and reconstructed observations."""
import datetime
import copy
import hashlib
import importlib.metadata
import io
import json
from pathlib import Path
import re
import shutil
import subprocess
import tarfile
import tokenize
import xml.etree.ElementTree as ET

repo = Path('/workspace/Power-Flow')
work = Path(__file__).parent
out = Path('/workspace/handoffs/mitl-inventory-observations-20261018T2148')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True).strip()
commit = subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
listing = json.loads((out/'source_file_list.json').read_text())
for name in listing['byte_identical_public_files']:
    assert (repo/name).read_bytes() == (out/'source'/name).read_bytes(), name
assert sha(repo/'mhdlab/coverage_inventory.py') == 'fc77fabf9e6a99ae3ce85e406d029308ddf3eabdb8aa1165a248f5bfbfa03c71'
assert sha(repo/'tools/build_coverage_sources.py') == 'a92fcbde2745a82b5840ab3390a850f9092e176976445730da60956c4f68e9db'

def xml_counts(path):
    root = ET.parse(path).getroot()
    cases = root.findall('.//testcase')
    assert not root.findall('.//failure') and not root.findall('.//error'), path
    return {'passed':sum(c.find('skipped') is None for c in cases),
            'skipped':sum(c.find('skipped') is not None for c in cases)}

inventory_counts = xml_counts(work/'isolated-inventory-results.xml')
assert inventory_counts == {'passed':108, 'skipped':0}
observation_counts = xml_counts(work/'isolated-observation-results.xml')
assert observation_counts == {'passed':18, 'skipped':1}
observations = json.loads((work/'observed-spectrum-recovery/completion.json').read_text())
response = json.loads((work/'response-controls/report.json').read_text())
example = json.loads((work/'coverage-source-example/report.json').read_text())
window = json.loads((work/'nonlinear-window-reference/reference.json').read_text())
window_readback = json.loads((work/'nonlinear-window-reference/assessment.json').read_text())
assert window['summary']['new_cases'] == 8 and window['summary']['all_checks_passed']
assert window_readback['summary']['all_readback_checks_passed']
assert sha(work/'nonlinear-window-reference/reference.json') == window_readback['reference_sha256']
assert sha(work/'nonlinear-window-reference/verify_nonlinear_windows.py') == window['script_sha256']
portable_window = copy.deepcopy(window)
executable_path = portable_window['runtime'].pop('executable')
portable_window['runtime']['executable_path_sha256'] = hashlib.sha256(executable_path.encode()).hexdigest()
portable_window['runtime']['executable_path_note'] = 'Workspace-specific path retained in the original local reference; omitted from portable delivery.'
assert {k:v for k,v in portable_window.items() if k!='runtime'} == {k:v for k,v in window.items() if k!='runtime'}
for record, directory in ((example, work/'coverage-source-example'), (response,work/'response-controls')):
    pins = record.get('source_sha256',record.get('source_implementation_sha256',{}))
    for name,digest in pins.items():
        assert sha(repo/name) == digest, name
    for name,digest in record['output_sha256'].items():
        assert sha(directory/name) == digest, name
assert response['exact_full_width_invariance_all_knots']
assert response['single_number_channel_free_scale_coverage_unconstrained']
assert response['manufactured_fixed_scale_fit_truth_ml'] == response['manufactured_fixed_scale_fit_recovered_ml']
evidence = out/'evidence'
evidence.mkdir(exist_ok=True)
for path in work.iterdir():
    if path.is_file() and path.suffix in {'.py','.json','.jsonl','.log','.xml'} and not path.name.startswith('freeze-inventory-handoff'):
        shutil.copyfile(path,evidence/path.name)
for dirname in ('coverage-source-example','response-controls'):
    shutil.copytree(work/dirname,evidence/dirname,dirs_exist_ok=True)
window_delivery = evidence/'nonlinear-window-reference'
if window_delivery.exists():
    shutil.rmtree(window_delivery)
window_delivery.mkdir()
for path in (work/'nonlinear-window-reference').iterdir():
    if path.is_file() and path.name not in {'reference.json','manifest.json'}:
        shutil.copyfile(path,window_delivery/path.name)
shutil.copyfile(work/'nonlinear-window-reference/manifest.json',window_delivery/'original_manifest.json')
(window_delivery/'reference.portable.json').write_text(json.dumps(portable_window,indent=2,allow_nan=False)+'\n')
projection = {'original_local_reference':str(work/'nonlinear-window-reference/reference.json'),
              'original_reference_sha256':sha(work/'nonlinear-window-reference/reference.json'),
              'portable_file':'reference.portable.json',
              'portable_sha256':sha(window_delivery/'reference.portable.json'),
              'changed_fields':['runtime.executable omitted; path hash and omission note supplied'],
              'all_mathematical_inputs_results_and_checks_identical':True,
              'original_manifest_note':'original_manifest.json and assessment.json pin the unchanged original local reference; top-level delivery manifest pins this portable projection.'}
(window_delivery/'DELIVERY_PROJECTION.json').write_text(json.dumps(projection,indent=2)+'\n')
display = evidence/'observed-spectrum-recovery'
display.mkdir(exist_ok=True)
for path in (work/'observed-spectrum-recovery').rglob('*'):
    if path.is_file() and path.suffix in {'.py','.json','.jsonl','.log'}:
        target = display/path.relative_to(work/'observed-spectrum-recovery')
        target.parent.mkdir(parents=True,exist_ok=True)
        shutil.copyfile(path,target)
# Source-paper pixels and complete source documents stay in the local cache.
with (out/'inventory-observations.patch').open('wb') as stream:
    subprocess.run(['git','diff','f4bcf3e4d0e402c3ca57b8ef91dd4e09717e2fda','HEAD'],cwd=repo,stdout=stream,check=True)
verification = {
    'schema':'mitl-inventory-observations-verification-v1',
    'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'source_commit':commit,'branch':'research/flash-publication-foundation',
    'commits':subprocess.check_output(['git','log','--reverse','--format=%H %s','f4bcf3e4d0e402c3ca57b8ef91dd4e09717e2fda..HEAD'],cwd=repo,text=True).splitlines(),
    'results':{'new_inventory_export_checks':108,'isolated_inventory':inventory_counts,
               'isolated_observations':observation_counts,
               'targeted_unique_passed':127, 'isolated_passed':126, 'isolated_skipped':1,
               'isolated_skip_reason':'Exact external dissertation PDF deliberately absent from portable subset; source reproduction and changed-pixel guards passed in original workspace.',
               'public_files_byte_identical':len(listing['byte_identical_public_files']),
               'packaging_wrappers':len(listing['packaging_wrappers']),
               'unchanged_project_suites_repeated':False,
               'exact_full_width_functional_controls':len(response['kernel_names'])*len(response['source_hdf_inspections']),
               'manufactured_aperture_controls':len(response['apertures'])-1},
    'runtime':{'packages':{name:importlib.metadata.version(name) for name in ('numpy','scipy','h5py','matplotlib','pytest','PyMuPDF')}},
    'source_example_report_sha256':sha(work/'coverage-source-example/report.json'),
    'response_controls_report_sha256':sha(work/'response-controls/report.json'),
    'nonlinear_window_reference':{'sha256':sha(work/'nonlinear-window-reference/reference.json'),
                                  'reference_summary':window['summary'],
                                  'readback_summary':window_readback['summary'],
                                  'runtime':portable_window['runtime'],
                                  'delivery_projection':projection,
                                  'production_window_numerically_qualified':False},
    'observed_recovery_completion':observations,
    'input_labels':{'inventory_example':'manufactured','response_controls':'manufactured arbitrary emitted-number functionals, no spectra',
                    'visible_trace':'reconstructed published arbitrary-intensity display, no raw counts or covariance',
                    'vuv_candidates':'experimental-origin derived-density displays; no alternate observable recovered'},
    'commands':[json.loads(line) for line in (work/'commands.jsonl').read_text().splitlines()],
    'resolved_findings':['Scalar immutable-buffer construction changed zero-dimensional fractions to vectors; original array shape is now retained.',
                         'A numerical monolayer convention cannot substitute for kinetic reference coverage or multiply the parent inventory per state.',
                         'Direct plan/sweep construction validates ledgers, local temperatures, geometry and fixed pool associations.',
                         'Observed VUV candidates carry derived-density axes; they were excluded from a detector-observable recovery.'],
    'limitations':['Physical parent layer convention, allocation, rate/energy laws and original raw diagnostics remain unavailable.',
                   'Prescribed-temperature release uses a diagnostic wall debit; coupled surface cooling is not solved.',
                   'Independent-pool initial fractions are not competing shared-site occupancies, reaction branching or fragment yields.',
                   'The fixed-linear oracle uses number moments with coarse interval kernels and manufactured apertures; it is not a transport or spectral prediction.',
                   'Published visible display samples have common axis/stroke/reduction limitations; no independent Gaussian covariance or corrected absolute amplitude is supplied.',
                   'VUV absolute calibration and physical surface coverage remain unresolved.',
                   'No separately owned solver/data, Quark or actual FLASH execution; no remote publication or external messages.'],
    'next_task':'Qualified law-specific partial source-time windows using the saved 180-digit references; then owner response acceptance and new experimental/normalization evidence.'
}
(out/'verification.json').write_text(json.dumps(verification,indent=2,allow_nan=False)+'\n')
(out/'systems-mitl-inventory-observations-10182026.md').write_text(f'''# MITL parent inventory, source sweep and recovered observations

Power-Flow is pinned to `{commit}` on `research/flash-publication-foundation`.
The new local commits are recorded in `verification.json`; the patch contains
only this pass's changes. The previous handoff is
`/workspace/handoffs/mitl-calibration-coverage-20261018T2048.tar.gz`.

## Inventory and source grid

An explicit parent monolayer density, definition, provenance and status maps a
layer amplitude into one physical inventory. Literal patch multipliers are
retained without normalization. Supplied pool/state fractions partition that
inventory once, with signed rounding residuals recorded. They describe initial
independent pools; they are not fragment yields or shared-pool reaction branches.
The same kinetic reservoir definitions and reference coverages remain fixed at
every layer knot. All knots are checked for density, nonnegative barrier,
coupling, representability, geometry, time and aggregate-memory support before
integration. Direct plan/sweep construction validates the same associations.

The CLI exports one canonical planar source per knot, the unchanged or
manufactured temperature input, exact config bytes, a CSV and a hash-associated
manifest with parent/pool numbers and energy ledgers. The parent-layer metadata
lives in that report/config association; keep it with the canonical source HDFs.
The CSV repeats each parent count across pool rows and must not be summed there.
Local temperature and original time/state/current source components remain
available for the existing paired boundary interfaces. Stored matched-width
moment datasets alone are not full time/velocity distributions.

The manufactured example has six knots including zero and two pools. It claims
no physical water layer density, foil kinetics, coupled cooling or spectrum.
The wall energy debit remains diagnostic at prescribed temperature.

## Response controls

Independent exact-rational readback tested seven arbitrary time/current/state
linear number kernels at six knots. Full-width, launch-width-independent
responses recover exact equality after matched width redistribution. Persisted
moment marginal differences are ordinary serialization rounding. Three finite
apertures use exact patch overlaps and break equality, demonstrating a selected
collection mechanism. These manufactured number functionals are not spectra.
A manufactured supplied-grid fit recovers its stated interpolated layer truth;
one number channel with a free scale remains coverage-degenerate.
`evidence/response-controls/owner_acceptance.md` gives the next owner acceptance
conditions. No external owner message or host change was made.

## Experimental evidence

The recovered visible trace and source-qualified exclusions are documented in
`source/docs/observed_spectrum_recovery.md`. Observed VUV candidate lineouts
already use derived transition-density axes; the narrative's photon-density
terminology remains ambiguous. They were not relabelled as detector counts.
The separable visible diagnostic retains its literal arbitrary units, distinct
shot/timing/collection context, original pixel geometry, masks and correlated
display readout limitations. It is not a recovered raw VUV observation or an
absolute calibration. Source-paper pixels/documents remain outside this packet.

## Nonlinear source-time windows

Eight new manufactured nonlinear cases were evaluated at 100 and 160 decimal
digits and independently checked through positive time-increment integrals,
rebased half-window mass partitions and conditional quantile replay. Seven
cases retain a positive finite float input domain; one pair of window endpoints
merges on projection. The references expose endpoint-CDF cancellation, late
count underflow, fraction underflow with a representable released number, and
loss of delay information at a large time origin. Exact-decimal and exactly
projected float inputs remain separate problems. Finite precision agreement is
not a certified error bound. No runtime source-window interface or host budget
acceptance is implemented or qualified. Read the work-only reference contract
before using these values to develop that interface. Earlier constant-barrier
oracle cases were read and preserved without being rerun.

## Verification and continuation

The inventory/export implementation passed 108 new checks; all 108 also passed in
the portable subset. New observed-trace checks and any explicit external-PDF
skip are recorded separately in `verification.json`. Named public files are
byte-identical; four packaging wrappers isolate imports from unrelated solvers.
Earlier unchanged suites were not repeated. Exact commands, exits, artifact
and log hashes include the initial scalar-shape failure and its correction.
Commands after freezing remain in the current pass's local `commands.jsonl`.

Next selected work qualifies partial source-time windows from the existing
180-digit oracle, preserving late log mass, partial inventory and local delays.
Emission windows remain distinct from recorded photon gates. Physical VUV
normalization still needs reduction/instrument evidence; actual FLASH still
needs installed licensed source and the configured workstation. No separately
owned collision/radiation or kinetic-gap development, Quark source/build/runner,
remote push/merge/publication or external message was performed.
''')
for path in sorted(out.rglob('*'),key=lambda p:len(p.parts),reverse=True):
    if path.is_dir() and path.name in {'__pycache__','.pytest_cache'}:
        shutil.rmtree(path)
    elif path.is_symlink():
        raise ValueError(f'Unexpected delivery symlink: {path}')
words=[[65,73],[67,108,97,117,100,101],[67,104,97,116,71,80,84],[79,112,101,110,65,73],[67,111,100,101,120],[67,111,112,105,108,111,116],[76,76,77]]
pattern=re.compile(r'\b(?:'+'|'.join(''.join(map(chr,word)) for word in words)+r')\b',re.I)
for path in out.rglob('*'):
    if path.is_file() and path.suffix in {'.py','.md','.json','.jsonl','.log','.patch','.xml','.txt'}:
        content = path.read_text()
        if path.suffix == '.py':
            # Source identifiers are not prose; inspect comments/docstrings/literals.
            content = '\n'.join(token.string for token in tokenize.generate_tokens(io.StringIO(content).readline)
                                if token.type in {tokenize.STRING,tokenize.COMMENT})
        assert not pattern.search(content),path
files=[p for p in sorted(out.rglob('*')) if p.is_file() and p.name!='MANIFEST.sha256']
(out/'MANIFEST.sha256').write_text(''.join(f'{sha(path)}  {path.relative_to(out).as_posix()}\n' for path in files))
archive=out.with_suffix('.tar.gz')
with tarfile.open(archive,'w:gz') as stream:
    stream.add(out,arcname=out.name)
digest=sha(archive)
archive.with_suffix(archive.suffix+'.sha256').write_text(f'{digest}  {archive.name}\n')
print(json.dumps({'archive':str(archive),'sha256':digest,'bytes':archive.stat().st_size,'manifest_entries':len(files),'source_commit':commit,'results':verification['results']},indent=2))
