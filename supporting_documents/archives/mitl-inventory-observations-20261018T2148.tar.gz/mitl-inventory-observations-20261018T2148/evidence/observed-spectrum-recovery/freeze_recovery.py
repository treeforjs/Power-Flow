"""Freeze local recovery evidence without changing public artifacts."""
import csv
import datetime
import hashlib
import json
from pathlib import Path
import re

from PIL import Image

root=Path('/workspace/Power-Flow')
work=Path('/workspace/research_work/mitl-upstream-20261018T2148')
out=work/'observed-spectrum-recovery'
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

paths=[root/p for p in (
    'tools/recover_dissertation_observed_spectrum.py',
    'tests/test_dissertation_observed_spectrum.py',
    'data/dissertation/observed_spectrum_4_15.csv',
    'data/dissertation/observed_spectrum_4_15.json',
    'docs/observed_spectrum_recovery.md')]
metadata=json.loads(paths[3].read_text())
with paths[2].open(newline='') as stream:
    rows=list(csv.DictReader(stream))
assert len(rows)==metadata['artifact']['rows']==136
assert sha(paths[2])==metadata['artifact']['csv_sha256']
skipped=metadata['recovery']['sampling']['skipped_columns']
assert len(skipped)==20
assert all(record['reason']=='broad_projected_green_run' for record in skipped)
assert {int(row['pixel_x']) for row in rows} | {item['pixel_x'] for item in skipped} == set(range(220,841,4))
for row in rows:
    assert float(row['wavelength_readout_lower_nm']) < float(row['wavelength_nm']) < float(row['wavelength_readout_upper_nm'])
    assert float(row['intensity_readout_lower_arb']) < float(row['observed_intensity_arb']) < float(row['intensity_readout_upper_arb'])

pdf=Path('/workspace/research_sources/smtrevor_1.pdf')
assert sha(pdf)==metadata['source']['pdf_sha256']
native=out/'figure_4_15_native.png'
image=Image.open(native)
assert image.mode=='RGB' and image.size==(1040,1320)
pixel_hash=hashlib.sha256(image.tobytes()).hexdigest()
assert pixel_hash==metadata['source']['native_rgb_sha256']
qa=out/'figure_4_15_recovery_qa.png'
assert sha(qa)==metadata['source_local_qa']['sha256']

links=[]
for target in re.findall(r'\]\(([^)]+)\)',paths[4].read_text()):
    if '://' in target or target.startswith('#'):
        continue
    linked=(paths[4].parent/target.split('#')[0]).resolve()
    assert linked.is_file(), str(linked)
    links.append(str(linked))

commands=[]
for line in (work/'commands.jsonl').read_text().splitlines():
    record=json.loads(line)
    if Path(record['log']).name.startswith(('observed-', 'observed-spectrum-')):
        assert sha(record['log'])==record['log_sha256']
        commands.append(record)
assert all(record['exit_code']==0 for record in commands)

result={
    'schema':'mhdlab-observed-spectrum-recovery-completion-v1',
    'frozen_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'public_files':[{ 'path':str(path.relative_to(root)), 'sha256':sha(path), 'bytes':path.stat().st_size} for path in paths],
    'source':dict(metadata['source'], local_pdf=str(pdf), actual_pdf_sha256=sha(pdf), actual_native_pixel_sha256=pixel_hash),
    'result':{'diagnostic':'observed visible SVS lineout, not VUV', 'shot':15765,
              'literal_series':'SVS Lineout 3: 330 ns', 'literal_ordinate':'Intensity [arb.]',
              'candidate_columns':156,'retained_samples':136,'omitted_columns':20,
              'omission_reason':'broad projected literal-green strokes; no interpolation',
              'wavelength_range_nm':[float(rows[0]['wavelength_nm']),float(rows[-1]['wavelength_nm'])],
              'csv_sha256':sha(paths[2]),'metadata_sha256':sha(paths[3]),
              'readout_envelopes':'native glyph extent plus common axis-fit residual; not independent measurement errors'},
    'validation':{'initial_scoped_tests':'19 passed under -W error, including external exact-PDF reproduction',
                  'after_geometry_metadata_enrichment':'2 affected artifact/integration checks passed under -W error; unchanged helpers not rerun',
                  'source_native_and_qa_visually_inspected':True,
                  'final_doc_local_links_exist':links,
                  'repository_files_edited_after_freeze':False},
    'eligibility_evidence':{'file':str(out/'eligibility.json'),'sha256':sha(out/'eligibility.json'),
                            'initial_document_hash_note':'The initial eligibility JSON pins the then-current doc; the final expanded doc is pinned under public_files.'},
    'source_local_qa':[{'file':str(path),'sha256':sha(path),'contains_source_pixels':True,
                        'include_in_delivery_archive':False} for path in (native,qa)],
    'limits':metadata['limitations']+[
        'Reported focus/spot geometry does not define a top-hat aperture, etendue, 2D kernel or reconstructed acceptance.',
        'The VUV 29-ns-before-breakdown record and 3-ns gate are separate from the visible 330-ns lineout label.',
        'No spectral-bin width, physical covariance, absolute calibration correction or monolayer estimate is inferred.',
        'The inspected VUV lineouts retain their derived Transition Density ordinate and are not relabelled as a new observation.'
    ],
    'observed_prior_command_records':commands,
    'generating_command_record':{'manifest':str(work/'commands.jsonl'),'label':'observed-visible-final-readback',
                                 'note':'The recorder appends this generating command after completion; its log/exit record is external to this JSON.'},
}
target=out/'completion.json'
target.write_text(json.dumps(result,indent=2,ensure_ascii=False,allow_nan=False)+'\n')
print(json.dumps({'completion':str(target),'sha256':sha(target),'retained_samples':136,'omitted_columns':20,
                  'public_file_hashes':{str(path.relative_to(root)):sha(path) for path in paths}},indent=2))
