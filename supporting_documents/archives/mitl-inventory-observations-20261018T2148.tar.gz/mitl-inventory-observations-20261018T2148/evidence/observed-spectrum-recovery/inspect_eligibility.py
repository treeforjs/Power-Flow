"""Hash-bounded source evidence for a blocked observed-only VUV recovery."""
import argparse
import hashlib
import json
import re
from pathlib import Path

PDF_SHA256='1d7b1f9c191a37e94f1cc3634587750f1af35b07eb13e0b94c60f3da47495ed7'
CANDIDATES=(
    ('4.20',109,2707,15750,'SS304 200 um'),
    ('4.21',110,2721,15765,'SS304 400 um'),
    ('4.26',116,2807,15802,'SS304; model comparison'),
    ('A.14',140,3033,15765,'SS304 400 um'),
)


def caption_excerpt(page, figure):
    text=page.get_text().split('Figure '+figure+':',1)[1]
    return re.split(r'\.\s+',text,maxsplit=1)[0].strip()+'.'


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--pdf',type=Path,required=True)
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--document',type=Path,required=True)
    args=parser.parse_args()
    payload=args.pdf.read_bytes()
    sha=lambda data:hashlib.sha256(data).hexdigest()
    if sha(payload)!=PDF_SHA256:
        raise ValueError('PDF differs from the visually inspected source')
    import pymupdf
    candidates=[]
    with pymupdf.open(stream=payload,filetype='pdf') as doc:
        assert len(doc)==203
        for figure,page_number,xref,shot,material in CANDIDATES:
            page=doc[page_number-1]
            image_records=page.get_images(full=True)
            assert xref in {row[0] for row in image_records}
            pix=pymupdf.Pixmap(doc,xref)
            assert pix.n==3
            candidates.append(dict(figure=figure,printed_page=page_number-25,pdf_page_1based=page_number,
                                   shot=shot,material_context=material,native_image_xref=xref,
                                   width_height_px=[pix.width,pix.height],decoded_channels=pix.n,
                                   decoded_RGB_sha256=sha(pix.samples),
                                   page_content_sha256=sha(page.read_contents()),
                                   caption_excerpt=caption_excerpt(page,figure),
                                   visually_inspected_axis_quote='Transition Density [Emitters/cm³]',
                                   axis_quote_is_OCR=False,
                                   experimental_origin_traces_present=True,
                                   eligible_for_requested_non_density_VUV_observable=False,
                                   decision='Do not relabel derived density as raw detector signal or radiance; no curve digitized'))
        continuation=doc[107].get_text()
        assert 'intensity corrected photon densities' in continuation
        chapter3=[]
        for figure,page_number,decision in (
            ('3.10',71,'Observed XUV imaging plus current/timing; no wavelength spectral trace'),
            ('3.12',73,'Observed visible average spectrum, Intensity (arbitrary); not VUV and different MAIZE/Al context'),
            ('3.13',75,'PrismSPECT simulation; not observed'),
            ('3.14',76,'PrismSPECT simulation; not observed'),
        ):
            page=doc[page_number-1]
            chapter3.append(dict(figure=figure,printed_page=page_number-25,pdf_page_1based=page_number,
                                 page_content_sha256=sha(page.read_contents()),
                                 caption_excerpt=caption_excerpt(page,figure),decision=decision))
        next_page=doc[99]
        next_pix=pymupdf.Pixmap(doc,2554)
        lead=dict(figure='4.15',printed_page=75,pdf_page_1based=100,native_image_xref=2554,
                  width_height_px=[next_pix.width,next_pix.height],decoded_RGB_sha256=sha(next_pix.samples),
                  shot=15765,material='SS304 400 um',literal_axis='Intensity [arb.]',
                  measured_lineout_timing_ns=[65,95,330],proposed_trace='330 ns middle linear visible panel',
                  decision='Propose separate visible-spectrum recovery only; not a substitute for VUV',
                  page_content_sha256=sha(next_page.read_contents()))
    result=dict(schema='observed-spectrum-eligibility-evidence-v1',
                status='blocked_no_requested_non_density_VUV_trace_in_bounded_check',
                source=dict(path=str(args.pdf),sha256=PDF_SHA256,pdf_pages=203,source_pixels_redistributed=False),
                requested_observable='Observed VUV detector counts/arbitrary intensity or clearly identified radiance; derived transition densities and models excluded',
                candidates=candidates,chapter3_bounded_check=chapter3,
                narrative_axis_ambiguity=dict(printed_page=83,pdf_page_1based=108,narrative_quote='intensity corrected photon densities',
                                              plotted_axis_quote='Transition Density [Emitters/cm³]',resolved=False),
                required_owner_record=['actual observation quantity and reduction mapping','spectral/spatial averaging support','gate/gain/background conventions','density/volume/transition conversion already applied'],
                next_experimental_evidence_lead=lead,no_numerical_trace_extracted=True,
                no_provisional_figure4_21_artifacts_created=True,
                public_document=dict(path=str(args.document),sha256=sha(args.document.read_bytes())),
                script_sha256=sha(Path(__file__).read_bytes()),
                limits=['bounded candidate inspection only','no camera raw data, covariance, calibration correction or coverage inferred'])
    args.output.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
    json.loads(args.output.read_text())
    print(json.dumps(dict(output=str(args.output),output_sha256=sha(args.output.read_bytes()),
                         source_pdf_sha256=PDF_SHA256,candidates=len(candidates),
                         eligible_candidates=0,public_document_sha256=result['public_document']['sha256'],
                         next_lead='visible Fig4.15 330 ns lineout; requires separate scope'),indent=2))


if __name__=='__main__':
    main()
