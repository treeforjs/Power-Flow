# Published signed magnetic-gap recovery patch

Nine public files are copied byte-for-byte from `3be2c9b7cf9fdc587eb422f42ec06b714f897acb`. Apply the accompanying
patch to the complete checkout at `b50d65198bfe53b46716dd04b6a434bcd9d0d986`. The README and recovery dependency
list are packaging wrappers; this source subset is not presented as a separately
executed or portable package, and no package initializer replacement is supplied.

The four coarse signed B_x gap profiles come from published legacy Allegra
simulation panels at40/60ns. Complete retained/excluded native row catalogs,
source/PDF/RGB hashes, axis calibration, finite support, display readout bounds,
geometry, generated QA and independent source checks are preserved. Printed
electromagnetic units and normalization remain unverified. Any tesla columns are
only an explicitly conditional literal-unit conversion.

No field derivative, skin depth, exact surface value, current integral, heating,
Hall response, full vector field, physical material closure, clock alignment,
experimental agreement, FLASH result or host acceptance is established. Original
PDF/native image bytes are omitted with hashes; generated QA is included. A
deliberate future recovery requires the original dissertation. Packaging repeats
no recovery, scientific oracle, previous suite or numerical source evolution.
