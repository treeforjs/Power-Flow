"""Inventory one frozen magnetic recovery and witnessed QA without replay."""
import csv
import hashlib
import json
from pathlib import Path

REPO = Path('/workspace/Power-Flow')
HERE = Path(__file__).resolve().parent
PASS = HERE.parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


source = REPO / 'tools/recover_dissertation_gap_magnetic.py'
source_pin = '7b3b52b0e5d4523f74991d2e2f2fc4b3390efdb3376498142ec7ebb2111f568f'
assert sha(source) == source_pin
freeze_path = HERE / 'selection_freeze.json'
freeze = json.loads(freeze_path.read_text())
assert freeze['producer_sha256'] == source_pin
commands = [json.loads(line) for line in (PASS / 'commands.jsonl').read_text().splitlines()]
producers = [entry for entry in commands
             if len(entry['command']) > 1 and entry['command'][1] == 'tools/recover_dissertation_gap_magnetic.py']
assert len(producers) == 1 and producers[0]['exit_code'] == 0
assert producers[0]['start_utc'] > freeze['frozen_utc']
public_files = {str(source.relative_to(REPO)): source_pin}
figures = []
for figure in ('4_28', '4_29'):
    csv_path = REPO / f'data/dissertation/figure_{figure}_magnetic_gap.csv'
    metadata_path = csv_path.with_suffix('.json')
    document = json.loads(metadata_path.read_text())
    rows = list(csv.DictReader(csv_path.open()))
    assert document['schema'] == 'mhdlab-dissertation-magnetic-gap-recovery-v1'
    assert document['output']['generator_sha256'] == source_pin
    assert document['output']['csv_sha256'] == sha(csv_path)
    assert len(rows) == document['output']['samples'] == 262
    assert b'\r' not in csv_path.read_bytes()
    geometry = HERE / document['output']['source_geometry_filename']
    assert sha(geometry) == document['output']['source_geometry_sha256']
    qa = {name: sha(HERE / name) for name in document['output']['QA_files_sha256']}
    assert qa == document['output']['QA_files_sha256']
    profiles = {}
    for profile in ('foil_edge', 'foil_middle'):
        selected = [row for row in rows if row['profile'] == profile]
        catalog = document['selection']['profiles'][profile]
        assert len(selected) == catalog['retained_count'] == 131
        assert catalog['excluded_count'] == 262 and catalog['catalogued_row_count'] == 393
        profiles[profile] = {'samples': 131, 'excluded_rows': 262, 'catalogued_rows': 393,
                             'matched_run_width_pixels': sorted({int(row['matched_color_pixels']) for row in selected}),
                             'signed_Bx_literal_axis_value_extent': [min(float(row['Bx_literal_axis_value']) for row in selected), max(float(row['Bx_literal_axis_value']) for row in selected)],
                             'all_primary_values_negative': all(float(row['Bx_literal_axis_value']) < 0 for row in selected)}
    for path in (csv_path, metadata_path):
        public_files[str(path.relative_to(REPO))] = sha(path)
    figures.append({'figure': document['source']['figure'], 'caption_snapshot_time_s': document['simulation_context']['caption_snapshot_time_s'],
                    'csv': str(csv_path.relative_to(REPO)), 'csv_sha256': sha(csv_path),
                    'metadata': str(metadata_path.relative_to(REPO)), 'metadata_sha256': sha(metadata_path),
                    'profiles': profiles, 'gap_coordinate_extent_mm': document['output']['gap_coordinate_extent_mm'],
                    'calibration': document['calibration'],
                    'source_geometry': str(geometry), 'source_geometry_sha256': sha(geometry), 'QA_files_sha256': qa})
record = {
    'schema': 'mhdlab-magnetic-gap-author-verification-v1', 'complete': True,
    'public_source': str(source.relative_to(REPO)), 'public_source_sha256': source_pin,
    'public_files_sha256': public_files,
    'source_PDF_sha256': freeze['source_PDF_sha256'],
    'selection_freeze': str(freeze_path), 'selection_freeze_sha256': sha(freeze_path),
    'new_positive_producer_run_count': 1, 'new_positive_producer_command': producers[0],
    'visual_QA': {'both_generated_PNGs_viewed': True,
                  'findings': 'Retained overlays follow the four visible central magnetic branches and remain clear of crossings, sharp sheets and legend. Signed components remain negative on both gap-coordinate halves; finite asymmetric support and correlated full-run bounds are visible.'},
    'total_retained_samples': 524, 'total_excluded_rows': 1048, 'total_catalogued_rows': 1572,
    'samples_per_profile': 131, 'excluded_per_profile': 262, 'catalogued_per_profile': 393,
    'exact_gap_support_mm': [['-131', '79'], ['129', '79']],
    'public_metadata_schema': 'mhdlab-dissertation-magnetic-gap-recovery-v1',
    'source_geometry_schema': 'mhdlab-magnetic-gap-source-geometry-v1',
    'figures': figures,
    'verification_scope': 'Author output inventory and visual QA only; separate source guards, independent native pixel/calibration readback and scientific review have their own records. No positive producer is replayed.',
    'limits': ['Published legacy Allegra simulation coarse central-gap lineouts, not measured fields or FLASH data.',
               'Signed literal B_x [100 Tesla] is primary; factor100 tesla conversion is conditional and normalization unverified.',
               'No exterior, crossing, sheet, exact surface field, skin derivative, Ampere/Hall, full vector or host acceptance claim.',
               'No imposed symmetry, sign rotation, gap endpoint insertion, interpolation, smoothing or extrapolation.',
               'Correlated display readout bounds are not physical uncertainty; nominal40/60ns captions do not establish experimental clock registration.']
}
target = HERE / 'author-verification.json'
assert not target.exists()
target.write_text(json.dumps(record, indent=2, allow_nan=False)+'\n')
print(json.dumps({'record': str(target), 'record_sha256': sha(target),
                  'public_files_sha256': public_files, 'retained': 524, 'excluded': 1048,
                  'catalogued': 1572, 'positive_producer_runs': 1}, indent=2))
