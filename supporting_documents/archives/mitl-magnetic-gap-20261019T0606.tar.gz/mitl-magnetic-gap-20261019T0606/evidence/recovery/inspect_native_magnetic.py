"""Fresh native magnetic-panel source identity, labels and colour inventory."""
from pathlib import Path
import hashlib
import io
import json
import numpy as np
from PIL import Image
import pymupdf

PDF = Path('/workspace/research_sources/smtrevor_1.pdf')
OUT = Path(__file__).resolve().parent
PDF_PIN = '1d7b1f9c191a37e94f1cc3634587750f1af35b07eb13e0b94c60f3da47495ed7'
assert hashlib.sha256(PDF.read_bytes()).hexdigest() == PDF_PIN
records = []
with pymupdf.open(PDF) as document:
    for figure, index, xref in [('4.28', 118, 2847), ('4.29', 120, 2870)]:
        page = document[index]
        encoded = document.extract_image(xref)['image']
        image = Image.open(io.BytesIO(encoded))
        assert image.size == (975, 975) and image.mode == 'RGB'
        image.save(OUT / f'figure_{figure.replace(".", "_")}_native.png')
        image.crop((480, 0, 975, 490)).resize((990, 980)).save(OUT / f'figure_{figure.replace(".", "_")}_magnetic_inspection.png')
        pixels = np.asarray(image)
        colours = {}
        for label, rgb in [('foil_edge', (255, 105, 180)), ('foil_middle', (186, 85, 211))]:
            yy, xx = np.nonzero(np.all(pixels[:490, 480:] == rgb, axis=2))
            colours[label] = {'RGB': list(rgb), 'count': len(xx),
                              'bbox_inclusive': [int(xx.min()+480), int(yy.min()), int(xx.max()+480), int(yy.max())]}
        records.append({'figure': figure, 'page_index': index, 'PDF_page': index+1, 'xref': xref,
                        'image_size': list(image.size), 'image_mode': image.mode,
                        'encoded_PNG_sha256': hashlib.sha256(encoded).hexdigest(),
                        'decoded_RGB_sha256': hashlib.sha256(image.tobytes()).hexdigest(),
                        'page_content_sha256': hashlib.sha256(page.read_contents()).hexdigest(),
                        'page_text': page.get_text(), 'magnetic_panel_colour_inventory': colours})
document = {'PDF_path': str(PDF), 'PDF_sha256': PDF_PIN, 'parser_version': pymupdf.VersionBind,
            'figures': records, 'new_axis_fit_performed': False, 'new_curve_recovery_performed': False}
path = OUT / 'native_magnetic_inspection.json'
path.write_text(json.dumps(document, indent=2)+'\n')
print(json.dumps(document, indent=2))
for reference in [Path('/workspace/research_work/mitl-upstream-20261019T0544/next-upstream-selection/magnetic_gap_recovery_proposal.json'),
                  Path('/workspace/handoffs/mitl-thermal-power-20261019T0544/systems-mitl-thermal-power-reference-10192026.md')]:
    print(str(reference), hashlib.sha256(reference.read_bytes()).hexdigest())
    print(reference.read_text()[:1800])
for producer in [Path('/workspace/Power-Flow/tools/recover_dissertation_depth_current.py'),
                 Path('/workspace/Power-Flow/tools/recover_dissertation_em_profiles.py')]:
    text = producer.read_text()
    print('REFERENCE_PATTERN_TEXT_ONLY', str(producer), hashlib.sha256(producer.read_bytes()).hexdigest())
    print(text[:3200])
