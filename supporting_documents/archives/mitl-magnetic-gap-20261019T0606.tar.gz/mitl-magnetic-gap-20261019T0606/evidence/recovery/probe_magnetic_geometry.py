"""Fresh magnetic tick tails and exact native colour runs; no curve output."""
from pathlib import Path
import json
import numpy as np
from PIL import Image

OUT = Path(__file__).resolve().parent


def runs(indices):
    result = []
    for value in indices:
        if not result or value != result[-1][-1]+1:
            result.append([int(value)])
        else:
            result[-1].append(int(value))
    return [[r[0], r[-1]] for r in result]


records = []
for figure in ('4_28', '4_29'):
    pixels = np.asarray(Image.open(OUT / f'figure_{figure}_native.png'))
    horizontal = {str(y): runs([x for x in range(570, 958) if max(pixels[y, x]) < 128]) for y in (415, 417, 419)}
    vertical = {str(x): runs([y for y in range(19, 412) if max(pixels[y, x]) < 128]) for x in (561, 562, 563, 564, 565, 566)}
    catalog = {}
    for name, rgb in [('foil_edge', (255, 105, 180)), ('foil_middle', (186, 85, 211))]:
        catalog[name] = {str(y): runs(np.nonzero(np.all(pixels[y, 570:958] == rgb, axis=1))[0]+570) for y in range(19, 412)}
    records.append({'figure': figure, 'horizontal_tick_tails': horizontal,
                    'vertical_tick_tails': vertical, 'raw_exact_colour_rows': catalog})
path = OUT / 'magnetic_geometry_probe.json'
path.write_text(json.dumps(records, indent=2)+'\n')
print(json.dumps([{k:v for k,v in f.items() if k != 'raw_exact_colour_rows'} |
                  {'selected_raw_rows': {str(y): {name:rows[str(y)] for name,rows in f['raw_exact_colour_rows'].items()}
                                         for y in (19,25,80,85,90,95,100,105,110,115,120,125,130,140,150,170,190,210,230,250,270,280,290,300,305,310,315,320,325,330,340,350,360,370,380,390,400,410)}} for f in records], indent=2))
