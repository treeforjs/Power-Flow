"""Freeze new magnetic-panel source selection and code before one recovery."""
from pathlib import Path
import datetime
import hashlib
import json

HERE = Path(__file__).resolve().parent
REPO = Path('/workspace/Power-Flow')
SOURCE = REPO / 'tools/recover_dissertation_gap_magnetic.py'
PIN = '7b3b52b0e5d4523f74991d2e2f2fc4b3390efdb3376498142ec7ebb2111f568f'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


assert sha(SOURCE) == PIN
inspection_path = HERE / 'native_magnetic_inspection.json'
inspection = json.loads(inspection_path.read_text())
stats_path = HERE / 'central_run_statistics.json'
stats = json.loads(stats_path.read_text())
for figure in stats:
    for profile in figure['profiles'].values():
        assert profile['candidate_central_rows'] == 131
        assert profile['run_count_histogram'] == {'1': 131}
        assert set(profile['run_width_histogram']) == {'3', '4'}
        assert profile['rejected'] == {}
target = HERE / 'selection_freeze.json'
assert not target.exists()
document = {
    'schema': 'mhdlab-magnetic-gap-recovery-selection-freeze-v1',
    'frozen_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'producer': 'tools/recover_dissertation_gap_magnetic.py', 'producer_sha256': PIN,
    'positive_recovery_executed_before_freeze': False,
    'source_PDF_sha256': inspection['PDF_sha256'],
    'source_identity_record': inspection_path.name, 'source_identity_record_sha256': sha(inspection_path),
    'central_run_statistics': stats_path.name, 'central_run_statistics_sha256': sha(stats_path),
    'full_raw_run_probe': 'magnetic_geometry_probe.json',
    'full_raw_run_probe_sha256': sha(HERE / 'magnetic_geometry_probe.json'),
    'panel_ROI_inclusive': {'x': [570, 957], 'y': [19, 411]},
    'retained_central_y_inclusive': [150, 280], 'row_stride': 1,
    'profiles': {'foil_edge_RGB': [255, 105, 180], 'foil_middle_RGB': [186, 85, 211]},
    'run_rule': 'one contiguous exact RGB run of 2–8 pixels, not touching ROI boundaries',
    'primary_outside_reason': 'outside_conservative_central_gap_support',
    'display_context_bands': [
        {'y': [19, 23], 'context': 'upper_frame_margin_excluded'},
        {'y': [24, 85], 'context': 'upper_legend_margin_excluded'},
        {'y': [86, 149], 'context': 'upper_outer_crossing_jump_margin_excluded'},
        {'y': [150, 280], 'context': 'central_gap_support'},
        {'y': [281, 329], 'context': 'lower_crossing_jump_margin_excluded'},
        {'y': [330, 411], 'context': 'lower_outer_frame_support_excluded'}
    ],
    'context_qualification': 'Conservative display-margin labels do not assert that every excluded pixel is a crossing, sheet, overlay or physical boundary.',
    'calibration': {
        'magnetic': {'tick_pixel_centres': [606.5, 706.5, 806.5, 906.5], 'tick_values': [-1, -.5, 0, .5],
                     'slope_exact': ['1', '200'], 'intercept_exact': ['-1613', '400'],
                     'maximum_absolute_tick_residual_exact': ['0', '1']},
        'gap': {'tick_pixel_centres': [56.5, 135.5, 214.5, 293.5, 372.5], 'tick_values': [4, 2, 0, -2, -4],
                'slope_exact': ['-2', '79'], 'intercept_exact': ['429', '79'],
                'maximum_absolute_tick_residual_exact': ['0', '1']}
    },
    'readout_half_width_pixels': 2,
    'readout_recipe': 'Complete matched magnetic run plus +/-2 pixels and tick-fit residual; gap row +/-2 pixels and tick-fit residual. Rational maps and conditional scale project once to float.',
    'primary_quantity': 'signed literal B_x [100 Tesla] axis value',
    'literal_conditional_scale_to_T': 100, 'normalization_verified': False,
    'nominal_time_s': [40e-9, 60e-9], 'experimental_clock_registration_established': False,
    'expected_retained_per_profile': 131, 'expected_excluded_per_profile': 262,
    'expected_total_retained': 524, 'expected_total_excluded': 1048, 'expected_total_catalogued': 1572,
    'exact_gap_support_mm': [['-131', '79'], ['129', '79']],
    'public_output_schema': 'mhdlab-dissertation-magnetic-gap-recovery-v1',
    'source_geometry_schema': 'mhdlab-magnetic-gap-source-geometry-v1',
    'selection_scientific_review': 'Root and separate fresh-source reviewer accepted central support before producer execution.',
    'limits': ['Coarse published legacy simulation central-gap display only.',
               'No exterior, foil skin, derivative, exact surface field, Hall, normalization or physical field acceptance.',
               'No interpolation, smoothing, endpoint padding, imposed symmetry, sign repair or extrapolation.'],
    'writer_sha256': sha(Path(__file__))
}
target.write_text(json.dumps(document, indent=2, allow_nan=False)+'\n')
print(json.dumps({'selection_freeze': str(target), 'selection_freeze_sha256': sha(target),
                  'producer_sha256': PIN, 'expected_retained': 524, 'expected_excluded': 1048,
                  'producer_executed': False}, indent=2))
