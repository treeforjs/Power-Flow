"""Commit the newly source-qualified central magnetic-gap recovery."""
import hashlib
import json
from pathlib import Path
import subprocess

repo=Path('/workspace/Power-Flow')
work=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def run(*args):
    print(json.dumps(list(args)),flush=True)
    subprocess.run(args,cwd=repo,check=True)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()=='b50d65198bfe53b46716dd04b6a434bcd9d0d986'
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=repo,text=True)
records={
 'recovery/author-verification.json':'c38cd664f9f300874bd7f845720b5439b1c967c1248948f82f1ce048d7f1022f',
 'guards/completion.json':'793f0ef221b25f8b0af6d378018149bd85c635fbfa2fc26bf2a73defd999832b',
 'independent-verification/completion.json':'c5e1251b8e25a3d0073adececb975d15e287b979e3c081a2c3efad9c11660819',
 'scientific-review/completion.json':'e829d50d457d11ac0d5f5ef5398bd73a03529b31487b91c0c20857f8bf11b8bf'}
for name,digest in records.items():assert sha(work/name)==digest
check=json.loads((work/'independent-verification/completion.json').read_text())
assert check['all_checks_passed'] is True and check['retained_rows']==524
pins={
 'tools/recover_dissertation_gap_magnetic.py':'7b3b52b0e5d4523f74991d2e2f2fc4b3390efdb3376498142ec7ebb2111f568f',
 'data/dissertation/figure_4_28_magnetic_gap.csv':'08307893990f4d25ce9cf9fcd3bf68f6a8070cdc82f508336249d3a7a2db155b',
 'data/dissertation/figure_4_28_magnetic_gap.json':'ac70c17f3303bf500f03e09923a5e7878638aa8f38104e88e1e4decee2a12702',
 'data/dissertation/figure_4_29_magnetic_gap.csv':'f928d3783a1fa9ebece1576208ef04890b0fbbcf3ecbfdc9363c5c63b6f1dfa0',
 'data/dissertation/figure_4_29_magnetic_gap.json':'70ae3dd5a7a032a4262d9c321ae2fc893a217b3b8ba30abc6c728061faeac43d'}
for name,digest in pins.items():assert sha(repo/name)==digest
run('git','add','--',*pins)
run('git','diff','--cached','--check')
run('git','-c','user.name=Research Development','-c','user.email=research@local.invalid',
    'commit','-m','Recover four signed central magnetic-gap profiles from the dissertation')
run('git','show','--format=fuller','--stat','HEAD')
