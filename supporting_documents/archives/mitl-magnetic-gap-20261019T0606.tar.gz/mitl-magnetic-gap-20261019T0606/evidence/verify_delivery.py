"""Verify actual compressed magnetic-gap payload bytes and saved associations."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import subprocess
import tarfile

from prepare_delivery import (WORK, REPO, BASE, OUT, PUBLIC, WRAPPERS, PRODUCER, PDF_SHA256,
    clean_head, command_snapshot_prefix, inspect_dataset, load, loads, save, sha)
from freeze_delivery import REPORT_PATHS, excluded, verify_contracts


def main():
    frozen = load(WORK/'frozen_delivery.json')
    clean_head(frozen['source_commit'])
    assert frozen['base_commit'] == BASE and Path(frozen['folder']) == OUT
    archive = Path(frozen['archive'])
    assert archive == OUT.with_suffix('.tar.gz')
    assert sha(archive) == frozen['sha256'] and archive.stat().st_size == frozen['bytes']
    hashes, members = {}, {}
    with tarfile.open(archive, 'r:gz') as tar:
        seen = set()
        for member in tar.getmembers():
            path = PurePosixPath(member.name)
            assert not path.is_absolute() and '..' not in path.parts and path.parts[0] == OUT.name
            assert member.name not in seen and not member.issym() and not member.islnk()
            seen.add(member.name)
            if member.isdir():
                continue
            assert member.isfile()
            name = PurePosixPath(*path.parts[1:]).as_posix()
            assert name != '.' and name not in members
            digest = hashlib.sha256()
            stream = tar.extractfile(member)
            for block in iter(lambda: stream.read(1024*1024), b''):
                digest.update(block)
            assert digest.hexdigest() != PDF_SHA256
            hashes[name], members[name] = digest.hexdigest(), member

        def raw(name):
            data = tar.extractfile(members[name]).read()
            assert hashlib.sha256(data).hexdigest() == hashes[name]
            return data

        def document(name):
            return loads(raw(name))

        manifest = document('manifest.sha256.json')
        assert set(hashes) == set(manifest)|{'manifest.sha256.json'}
        assert len(manifest) == frozen['manifest_entries']
        assert all(hashes[name] == digest for name, digest in manifest.items())
        assert hashes['manifest.sha256.json'] == frozen['manifest_sha256']
        assert hashes['verification.json'] == frozen['verification_sha256']
        assert {str(path.relative_to(OUT)) for path in OUT.rglob('*') if path.is_file()} == set(hashes)
        assert all(sha(OUT/name) == digest for name, digest in hashes.items())
        assert document('source_file_list.json') == {'byte_identical_public_files': list(PUBLIC), 'packaging_wrappers': list(WRAPPERS)}
        assert len(PUBLIC) == 9 and len(WRAPPERS) == 2
        assert {name[7:] for name in hashes if name.startswith('source/')} == set(PUBLIC)|set(WRAPPERS)
        assert 'source/mhdlab/__init__.py' not in hashes
        assert all(hashes['source/'+name] == sha(REPO/name) for name in PUBLIC)
        for filename, names in (('source-files.sha256', PUBLIC), ('wrapper-files.sha256', WRAPPERS)):
            found = {}
            for line in raw(filename).decode().splitlines():
                digest, name = line.split('  ', 1)
                assert name not in found and hashes['source/'+name] == digest
                found[name] = digest
            assert set(found) == set(names)
        expected_patch = subprocess.check_output(['git', 'diff', '--binary', BASE, frozen['source_commit']], cwd=REPO)
        assert raw('magnetic-gap-recovery.patch') == expected_patch
        verification = document('verification.json')
        assert verification['schema'] == 'mitl-magnetic-gap-recovery-verification-v1'
        assert verification['source_commit'] == frozen['source_commit'] and verification['base_commit'] == BASE
        assert verification['package_kind'] == 'patch_over_exact_complete_baseline'
        assert verification['required_complete_baseline_checkout'] is True
        assert verification['record_paths'] == REPORT_PATHS
        allowed_archive_figures = {'evidence/'+name for name in verification['allowed_figure_paths']}
        assert all(not excluded(name, allowed_archive_figures) for name in hashes)
        restored_bytes, original_hashes = {}, dict(hashes)
        for projection in reversed(document('portable_path_projections.json')):
            name = projection['path']
            data = restored_bytes.get(name, raw(name))
            assert hashlib.sha256(data).hexdigest() == projection['portable_sha256']
            replacement = projection['replacement'].encode()
            assert data.count(replacement) == projection['replacements']
            restored = data.replace(replacement, bytes.fromhex(projection['source_prefix_hex']))
            assert hashlib.sha256(restored).hexdigest() == projection['original_sha256']
            restored_bytes[name] = restored
            original_hashes[name] = projection['original_sha256']

        def original_bytes(name):
            return restored_bytes.get(name, raw(name))

        def original_document(name):
            return loads(original_bytes(name))

        omissions = document('excluded_evidence.json')
        omitted_hashes = {record['path']: record['sha256'] for record in omissions}
        assert len(omitted_hashes) == len(omissions)
        assert all(excluded(name, verification['allowed_figure_paths']) or digest == PDF_SHA256
                   for name, digest in omitted_hashes.items())

        def saved_work_sha(name):
            target = 'evidence/'+name
            return original_hashes[target] if target in original_hashes else omitted_hashes[name]

        for record in verification['copied_input_sha256']:
            assert original_hashes[record['archive']] == record['sha256']
            source = Path(record['source'])
            historical_helper = record['archive'] in {'evidence/'+name for name in verification['source_helper_sha256']}
            if record['archive'] != 'evidence/commands.jsonl' and not historical_helper:
                assert source.is_file() and not source.is_symlink() and sha(source) == record['sha256']
        snapshot = verification['command_snapshot']
        expected_snapshot = command_snapshot_prefix(original_bytes(snapshot['path']), (WORK/'commands.jsonl').read_bytes())
        assert all(snapshot[key] == value for key, value in expected_snapshot.items())
        assert snapshot['later_local_completion_repairs_may_exist'] is True
        for name, digest in verification['source_helper_sha256'].items():
            # Historical archive snapshots are pinned, independently of later local repairs.
            assert original_hashes['evidence/'+name] == digest
        datasets = []
        for record in verification['datasets']:
            dataset = inspect_dataset(raw('source/'+record['csv_path']), document('source/'+record['metadata_path']),
                csv_path=record['csv_path'], metadata_path=record['metadata_path'],
                producer_sha256=hashes['source/'+PRODUCER], metadata_sha256=hashes['source/'+record['metadata_path']])
            assert dataset == record
            datasets.append(dataset)
        records = {}
        for key, path in REPORT_PATHS.items():
            name = 'evidence/'+path
            assert original_hashes[name] == verification['record_sha256'][key]
            records[key] = original_document(name)
            assert records[key] == verification['records'][key]
        validated = verify_contracts(records, datasets, work_sha=saved_work_sha,
            public_sha=lambda name: hashes['source/'+name], work_bytes=lambda name: original_bytes('evidence/'+name))
        assert validated['results'] == verification['results']
        assert validated['allowed_figure_paths'] == verification['allowed_figure_paths']
        assert document('next_task.json')['task'] == records['selection']['task'] == verification['next_task']
        result = {**frozen, 'status': 'passed', 'actual_archive_regular_files': len(hashes),
            'unsafe_or_duplicate_members': 0, 'input_code_output_bindings_verified': True,
            'repository_clean': True, 'complete_baseline_checkout_required': True,
            'historical_helper_snapshots_bound': True, 'live_commands_exact_complete_record_prefix_verified': True,
            'source_pdf_included': False, 'raw_source_images_or_pages_included': False,
            'physical_normalization_verified': False, 'source_recovery_or_scientific_checks_reexecuted': False,
            'portable_execution_performed': False}
    save(WORK/'delivery_verification.json', result)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
