"""Root-owned metadata completion of the published magnetic-gap recovery.

Reads saved metadata and actual archive bytes. No recovery, scientific model,
previous suite, external source request or owner implementation is executed.
"""
import datetime
import fcntl
import hashlib
import importlib
import json
import os
from pathlib import Path,PurePosixPath
import re
import subprocess
import tarfile

WORK=Path(__file__).resolve().parent
REPO=Path('/workspace/Power-Flow')
OUT=Path('/workspace/handoffs/mitl-magnetic-gap-20261019T0606')
BASE='b50d65198bfe53b46716dd04b6a434bcd9d0d986'
PUBLIC={'tools/recover_dissertation_gap_magnetic.py',
    'data/dissertation/figure_4_28_magnetic_gap.csv','data/dissertation/figure_4_28_magnetic_gap.json',
    'data/dissertation/figure_4_29_magnetic_gap.csv','data/dissertation/figure_4_29_magnetic_gap.json',
    'docs/dissertation_gap_magnetic_recovery.md','data/dissertation/recovery_manifest.yaml',
    'docs/dissertation_recovery.md','docs/dissertation_current_depth_recovery.md'}


def require(condition,message):
    if not condition:
        raise RuntimeError(message)


def sha(path):
    digest=hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):
            digest.update(block)
    return digest.hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def relative(name):
    require(type(name) is str and name,'missing relative path')
    path=PurePosixPath(name)
    require(not path.is_absolute() and '..' not in path.parts and str(path)==name,'unsafe relative path')
    return path


def git(*arguments):
    return subprocess.check_output(['git',*arguments],cwd=REPO)


def clean_head(contract):
    head=contract['approved_head']
    require(type(head) is str and re.fullmatch('[0-9a-f]{40}',head),'root-approved final HEAD is pending')
    require(git('rev-parse','HEAD').decode().strip()==head,'final HEAD changed')
    require(git('branch','--show-current').decode().strip()=='research/flash-publication-foundation','wrong branch')
    require(not git('status','--porcelain').strip(),'repository must be clean')
    subprocess.run(['git','merge-base','--is-ancestor',BASE,head],cwd=REPO,check=True)
    require(set(git('diff','--name-only',BASE,head).decode().splitlines())==PUBLIC,'committed scope changed')
    for name,digest in contract['public_source_sha256'].items():
        require(sha(REPO/name)==digest==hashlib.sha256(git('show',head+':'+name)).hexdigest(),'public/commit bytes changed')
    return head


def command_snapshot(snapshot,current):
    require(snapshot and snapshot.endswith(b'\n') and current.endswith(b'\n')
        and current.startswith(snapshot),'command snapshot is not an exact complete-record prefix')
    def reject_constant(value):
        raise ValueError('nonfinite JSON constant: '+value)
    def parse(data):
        entries=[]
        for line in data.splitlines():
            entry=json.loads(line,parse_constant=reject_constant)
            require(type(entry) is dict and {'command','cwd','start_utc','end_utc','elapsed_s',
                'exit_code','log','log_sha256'}<=set(entry),'incomplete command record')
            require(type(entry['command']) is list and entry['command']
                and all(type(value) is str for value in entry['command'])
                and type(entry['exit_code']) is int and type(entry['cwd']) is str
                and type(entry['log']) is str and type(entry['log_sha256']) is str
                and re.fullmatch('[0-9a-f]{64}',entry['log_sha256']),'invalid command record')
            datetime.datetime.fromisoformat(entry['start_utc'])
            datetime.datetime.fromisoformat(entry['end_utc'])
            entries.append(entry)
        return entries
    archived=parse(snapshot);live=parse(current)
    require(live[:len(archived)]==archived,'parsed command prefix changed')
    return {'archived_sha256':hashlib.sha256(snapshot).hexdigest(),
        'live_sha256_at_completion':hashlib.sha256(current).hexdigest(),
        'archived_bytes':len(snapshot),'live_bytes_at_completion':len(current),
        'archived_complete_entries':len(archived),'live_complete_entries_at_completion':len(live),
        'exact_byte_prefix':True,'parsed_complete_records':True}


def verify_archive(contract):
    frozen=load(WORK/'frozen_delivery.json');delivery=load(WORK/'delivery_verification.json')
    verification=load(OUT/'verification.json')
    require(delivery['status']=='passed' and delivery['repository_clean'] is True
        and delivery['input_code_output_bindings_verified'] is True and delivery['unsafe_or_duplicate_members']==0,'delivery has not passed')
    for key in ['folder','archive','sha256','bytes','source_commit','base_commit','manifest_sha256','verification_sha256']:
        require(delivery[key]==frozen[key],'delivery/freeze association changed')
    require(delivery['folder']==str(OUT) and delivery['source_commit']==verification['source_commit']==contract['approved_head']
        and delivery['base_commit']==verification['base_commit']==BASE,'delivery identity changed')
    require(verification['schema']=='mitl-magnetic-gap-recovery-verification-v1'
        and verification['package_kind']=='patch_over_exact_complete_baseline','package contract changed')
    require(delivery['complete_baseline_checkout_required'] is True and delivery['historical_helper_snapshots_bound'] is True
        and delivery['live_commands_exact_complete_record_prefix_verified'] is True,'snapshot dependency qualification changed')
    require(delivery['source_pdf_included'] is False and delivery['raw_source_images_or_pages_included'] is False
        and delivery['physical_normalization_verified'] is False
        and delivery['source_recovery_or_scientific_checks_reexecuted'] is False
        and delivery['portable_execution_performed'] is False,'unexpected inclusion or execution claim')
    archive=Path(delivery['archive'])
    require(archive==OUT.with_suffix('.tar.gz') and sha(archive)==delivery['sha256']
        and archive.stat().st_size==delivery['bytes'],'actual archive changed')
    hashes={};seen=set();allowed={'evidence/'+str(relative(name)) for name in verification['allowed_figure_paths']}
    with tarfile.open(archive,'r:gz') as stream:
        for member in stream:
            path=PurePosixPath(member.name)
            require(not path.is_absolute() and '..' not in path.parts and path.parts and path.parts[0]==OUT.name,'unsafe archive path')
            require(member.name not in seen and not member.issym() and not member.islnk(),'duplicate/linked archive member')
            seen.add(member.name)
            if member.isdir():
                continue
            require(member.isfile() and len(path.parts)>1,'nonregular archive payload')
            name=str(PurePosixPath(*path.parts[1:]));parts=relative(name).parts
            require(name not in hashes and not any(part in {'source-local','fulltexts','raw-fulltexts','__pycache__','.venv','.pytest_cache','fixtures','test-fixtures'} for part in parts),'excluded/duplicate payload')
            require(PurePosixPath(name).suffix.lower() not in {'.pdf','.png','.jpg','.jpeg','.tif','.tiff'} or name in allowed,'unlisted source image/fulltext')
            data=stream.extractfile(member).read();hashes[name]=hashlib.sha256(data).hexdigest()
            require((OUT/name).is_file() and not (OUT/name).is_symlink() and sha(OUT/name)==hashes[name],'archive/folder bytes differ')
    manifest=load(OUT/'manifest.sha256.json')
    require(set(hashes)==set(manifest)|{'manifest.sha256.json'} and all(hashes[name]==digest for name,digest in manifest.items()),'archive manifest mismatch')
    require(len(manifest)==delivery['manifest_entries'] and len(hashes)==delivery['actual_archive_regular_files'],'archive counts changed')
    require(sha(OUT/'manifest.sha256.json')==delivery['manifest_sha256'] and sha(OUT/'verification.json')==delivery['verification_sha256'],'manifest/verification pin changed')
    require({name[7:] for name in hashes if name.startswith('source/')}==PUBLIC|{'README.md','requirements.txt'}
        and 'source/mhdlab/__init__.py' not in hashes,'public/wrapper source scope changed')
    require(delivery['public_files_byte_identical']==9 and delivery['packaging_wrappers']==2,'public/wrapper count changed')
    for name,digest in contract['public_source_sha256'].items():
        require(hashes['source/'+name]==digest,'archived public bytes changed')
    require(hashes['magnetic-gap-recovery.patch']==hashlib.sha256(git('diff','--binary',BASE,contract['approved_head'])).hexdigest(),'patch does not match final commit')
    original_hashes=dict(hashes);restored={}
    for projection in reversed(load(OUT/'portable_path_projections.json')):
        name=projection['path'];relative(name)
        data=restored.get(name,(OUT/name).read_bytes())
        require(hashlib.sha256(data).hexdigest()==projection['portable_sha256'],'portable projection changed')
        replacement=projection['replacement'].encode()
        require(data.count(replacement)==projection['replacements'],'portable projection count changed')
        data=data.replace(replacement,bytes.fromhex(projection['source_prefix_hex']))
        require(hashlib.sha256(data).hexdigest()==projection['original_sha256'],'original projection pin changed')
        restored[name]=data;original_hashes[name]=projection['original_sha256']
    commands=None
    for item in verification['copied_input_sha256']:
        require(original_hashes[item['archive']]==item['sha256'],'copied archived input changed')
        source=Path(item['source'])
        if source==WORK/'commands.jsonl':
            snapshot=restored.get(item['archive'],(OUT/item['archive']).read_bytes())
            require(hashlib.sha256(snapshot).hexdigest()==item['sha256'],'command snapshot pin changed')
            commands=command_snapshot(snapshot,source.read_bytes())
        else:
            require(item['sha256']==sha(source),'copied original input changed: '+str(source))
    require(commands is not None,'missing archived command snapshot')
    require(verification['command_snapshot']['sha256']==commands['archived_sha256']
        and verification['command_snapshot']['bytes']==commands['archived_bytes']
        and verification['command_snapshot']['complete_records']==commands['archived_complete_entries'],'command snapshot declaration changed')
    return delivery,verification,original_hashes,commands


def verify_metadata(contract,verification,archive_hashes):
    for name,digest in contract['metadata_helpers_sha256'].items():
        require(sha(WORK/relative(name))==digest,'pure metadata helper changed')
    require(verification['source_helper_sha256']=={**contract['metadata_helpers_sha256'],
        'complete_pass.py':sha(__file__)},'archived helper snapshot differs from current strict helper bytes')
    freezer=importlib.import_module('freeze_delivery')
    require(Path(freezer.__file__).resolve()==WORK/'freeze_delivery.py','wrong metadata helper imported')
    require(freezer.REPORT_PATHS==contract['record_paths']==verification['record_paths'],'report roles changed')
    records={}
    for role,name in contract['record_paths'].items():
        path=WORK/relative(name);digest=contract['record_sha256'][role]
        require(sha(path)==digest==verification['record_sha256'][role]==archive_hashes['evidence/'+name],'saved report bytes changed: '+role)
        records[role]=load(path)
        require(records[role]==verification['records'][role],'saved report declaration changed')
    require(freezer.dataset_bindings()==verification['datasets'],'current saved CSV/JSON associations changed')
    declared=freezer.verify_contracts(records,verification['datasets'])
    require(declared['results']==contract['result_values']==verification['results'],'qualified result fields changed')
    require(declared['allowed_figure_paths']==verification['allowed_figure_paths'],'allowed figure scope changed')
    require(records['guard_completion']['all_checks_passed'] is True,'guards are incomplete')
    selection=records['selection']
    require(selection.get('selected') is True or str(selection.get('status','')).startswith('selected'),'next selection is only conditional')
    require(type(selection.get('task')) is str and selection['task'].strip(),'next task missing')
    require(load(OUT/'next_task.json')['task']==verification['next_task']==selection['task'],'next task association changed')
    return records


def atomic_write(path,data):
    temporary=path.with_name(path.name+'.new')
    require(not temporary.exists(),'unresolved temporary file exists')
    with temporary.open('xb') as stream:
        stream.write(data);stream.flush();os.fsync(stream.fileno())
    os.replace(temporary,path)


def main():
    contract_path=WORK/'completion-preparation/contract.json';contract=load(contract_path)
    require(contract['schema']=='mitl-magnetic-gap-completion-contract-v1'
        and contract['ready_for_root_execution'] is True and contract['pending']==[],'completion contract is pending')
    require(set(contract['public_source_sha256'])==PUBLIC and set(contract['record_paths'])==set(contract['record_sha256']),'contract scope changed')
    for mapping in ['public_source_sha256','metadata_helpers_sha256','record_sha256']:
        require(all(type(value) is str and re.fullmatch('[0-9a-f]{64}',value) for value in contract[mapping].values()),'final byte pins are pending')
    status_path=WORK.parent/'mitl-upstream-status.json'
    with (WORK.parent/'mitl-upstream-status.lock').open('a+') as lock:
        fcntl.flock(lock,fcntl.LOCK_EX)
        before=status_path.read_bytes();status=json.loads(before);lease=load(WORK/'lease.json')
        now=datetime.datetime.now(datetime.timezone.utc)
        require(status['active_lease_owner']==lease['pass_id']==WORK.name
            and datetime.datetime.fromisoformat(status['active_editing_lease_until_utc'])>now,'lease changed or expired')
        require(status['last_complete_commit']==lease['baseline_commit']==BASE and status['handoff']==lease['prior_handoff']
            and not (WORK/'completion.json').exists(),'prior checkpoint changed or completion replay attempted')
        remaining=[json.loads(json.dumps(item)) for item in status['next_work'] if 2<=item['priority']<=7]
        require([item['priority'] for item in remaining]==[2,3,4,5,6,7],'prior queue priorities changed')
        changed={'last_complete_commit','last_completed_pass_id','last_update_utc','handoff','handoff_sha256','handoff_bytes','handoff_document',
            'active_lease_owner','active_editing_lease_until_utc','reserved_paths','active_completed_subtasks','active_phase',
            'last_verified_suite','next_work','verification_history','prior_handoffs','completed_milestones','recovered_dissertation_magnetic_gap'}
        preserved=json.loads(json.dumps({key:value for key,value in status.items() if key not in changed}))
        head=clean_head(contract);delivery,verification,archive_hashes,commands=verify_archive(contract)
        records=verify_metadata(contract,verification,archive_hashes)
        clean_head(contract);now=datetime.datetime.now(datetime.timezone.utc)
        require(datetime.datetime.fromisoformat(status['active_editing_lease_until_utc'])>now,'lease expired during verification')
        history=status.setdefault('verification_history',[]);prior=status.setdefault('prior_handoffs',[])
        if status['handoff'] not in prior:
            prior.append(status['handoff'])
        if not any(item['pass_id']==status['last_completed_pass_id'] for item in history):
            history.append({'pass_id':status['last_completed_pass_id'],'commit':status['last_complete_commit'],
                'handoff':status['handoff'],'handoff_sha256':status['handoff_sha256'],'verification':status['last_verified_suite']})
        selection=records['selection']
        status.update(last_complete_commit=head,last_completed_pass_id=WORK.name,last_update_utc=now.isoformat(),
            handoff=delivery['archive'],handoff_sha256=delivery['sha256'],handoff_bytes=delivery['bytes'],
            handoff_document=str(OUT/'systems-mitl-magnetic-gap-recovery-10192026.md'),active_lease_owner=None,
            active_editing_lease_until_utc=None,reserved_paths=[],active_completed_subtasks=[],
            active_phase='Completed coarse signed published magnetic-gap recovery; next bounded upstream task selected')
        status['last_verified_suite']={**verification['results'],
            'scope':'New published legacy magnetic-gap samples, independent native readback and four new invalid-source controls; no earlier producer or suite replay',
            'verification_record':str(OUT/'verification.json'),'delivery_manifest_entries':delivery['manifest_entries'],
            'public_files_byte_identical':9,'packaging_wrappers':2,'post_freeze_commands':str(WORK/'commands.jsonl'),
            'commands_snapshot_qualification':commands}
        status['recovered_dissertation_magnetic_gap']={'parameter_status':'reconstructed',
            'source_kind':'published_legacy_simulation','public_source_sha256':contract['public_source_sha256'],
            'datasets':verification['datasets'],'results':verification['results'],
            'record_paths':{role:str(WORK/name) for role,name in contract['record_paths'].items()},'record_sha256':contract['record_sha256'],
            'source_normalization_verified':False,'tesla_columns_literal_conditional_only':True,
            'physical_parameters_adopted':0,'host_budget_accepted':False,'actual_flash_run':False,
            'field_derivative_skin_depth_surface_field_verified':False,'Hall_or_heating_closure_verified':False,
            'clock_alignment_inferred':False,'physical_spectra_calculated':False,
            'limits':'Finite coarse signed legacy display profiles only. Source identity, literal axes, selection and display readout are retained. Original electromagnetic normalization, full fields, physical uncertainty, current/heating closure, transport and owner acceptance remain unqualified.'}
        status['next_work']=[{'priority':1,'task':selection['task'],
            'selection':str(WORK/contract['record_paths']['selection']),'selection_sha256':contract['record_sha256']['selection'],
            'limits':'Follow the fresh bounded selection; all actual surface, VUV, owner, forced nonzero-barrier, FLASH and full-text gates remain in force.'}]+remaining
        require(status['next_work'][1:]==remaining and all(status[key]==value for key,value in preserved.items()),'earlier evidence,gates or queue changed')
        status['completed_milestones'].extend([
            'Four coarse signed magnetic-gap profiles in published legacy Figures4.28/4.29 now have native source identity, finite selection catalogs, literal axes and conditional tesla columns with original normalization still unverified.',
            'New direct native readback and four frozen-plan invalid-source controls qualify the saved recovery evidence; no successful positive recovery replay, old suite or physical acceptance is attributed to verification.',
            f'Nine public files through {head[:7]} and actual archive {delivery["sha256"]} require the complete b50d651 baseline. Source imagery is omitted with hashes; no standalone or portable execution is claimed.'
        ])
        history.append({'pass_id':WORK.name,'commit':head,'handoff':delivery['archive'],'handoff_sha256':delivery['sha256'],'verification':status['last_verified_suite']})
        encoded=(json.dumps(status,indent=2,allow_nan=False)+'\n').encode()
        result={'utc':now.isoformat(),'event':'completed_and_next_selected','pass_id':WORK.name,'commit':head,
            'archive':delivery['archive'],'archive_sha256':delivery['sha256'],'archive_bytes':delivery['bytes'],
            'actual_archive_reverified':True,'public_scope_sha256':contract['public_source_sha256'],
            'completion_contract_sha256':sha(contract_path),'record_sha256':contract['record_sha256'],
            'source_normalization_verified':False,'tesla_columns_literal_conditional_only':True,
            'physical_parameters_adopted':0,'host_budget_accepted':False,'actual_flash_run':False,
            'source_recovery_or_scientific_checks_reexecuted':False,'portable_execution_performed':False,
            'command_snapshot_qualification':commands,'exact_commands':str(WORK/'commands.jsonl'),
            'status_before_sha256':hashlib.sha256(before).hexdigest(),'status_after_sha256':hashlib.sha256(encoded).hexdigest(),
            'lease_released':True,'reserved_paths':[],'next':selection['task'],
            'next_selection_sha256':contract['record_sha256']['selection']}
        require(not (WORK/'status-before-completion.json').exists(),'prior completion snapshot exists')
        (WORK/'status-before-completion.json').write_bytes(before)
        atomic_write(status_path,encoded)
        atomic_write(WORK/'completion.json',(json.dumps(result,indent=2,allow_nan=False)+'\n').encode())
        with (WORK.parent/'mitl-upstream-journal.jsonl').open('a') as stream:
            stream.write(json.dumps(result,allow_nan=False)+'\n')
    print(json.dumps(result,indent=2))


if __name__=='__main__':
    main()
