# Magnetic-gap recovery delivery preparation

The delivery is a nine-file patch over the exact approved baseline, with README
and recovery-dependency wrappers. No initializer replacement, portable execution,
old recovery, test suite or numerical source replay is part of assembly.

The initial preparer and freezer drafts fail closed until the actual frozen sidecar,
author, independent readback, guard, root review and selection schemas are bound.
Final source and report pins will be added only after the approved clean commit.

Generated QA, calibration, geometry, full selection catalogs, source identities,
commands, failures and focused corrections are retained. Original PDF/native
image bytes and invalid binary fixtures are excluded with path, size and hash.
Archive-only machine-directory projections are reversible; local evidence stays
byte-identical.

The commands file is an exact complete-record byte prefix of the live JSONL log.
Later verification and completion commands may append. Archived helper hashes
are immutable historical snapshots. A later local correction must explicitly
bind its archived predecessor and preserve the initial failure; it must not
invalidate the published archive. Other copied original evidence stays strict.

Signed literal field values and conditional printed-unit conversion remain
distinct from physical electromagnetic normalization, surface values, gradients,
heating, Hall response, clock alignment, experimental validation and host use.
