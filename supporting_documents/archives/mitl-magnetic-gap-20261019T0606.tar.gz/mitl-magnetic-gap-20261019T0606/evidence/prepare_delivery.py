"""Prepare a compact magnetic-gap recovery patch over an approved exact checkout."""
import argparse
import csv
from decimal import Decimal
import hashlib
import io
import json
import math
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess

WORK = Path(__file__).resolve().parent
REPO = Path('/workspace/Power-Flow')
BASE = 'b50d65198bfe53b46716dd04b6a434bcd9d0d986'
HEAD = '3be2c9b7cf9fdc587eb422f42ec06b714f897acb'
OUT = Path('/workspace/handoffs/mitl-magnetic-gap-20261019T0606')
PDF_SHA256 = '1d7b1f9c191a37e94f1cc3634587750f1af35b07eb13e0b94c60f3da47495ed7'
PRODUCER = 'tools/recover_dissertation_gap_magnetic.py'
PUBLIC = (PRODUCER,
    'data/dissertation/figure_4_28_magnetic_gap.csv', 'data/dissertation/figure_4_28_magnetic_gap.json',
    'data/dissertation/figure_4_29_magnetic_gap.csv', 'data/dissertation/figure_4_29_magnetic_gap.json',
    'docs/dissertation_gap_magnetic_recovery.md', 'data/dissertation/recovery_manifest.yaml',
    'docs/dissertation_recovery.md', 'docs/dissertation_current_depth_recovery.md')
WRAPPERS = ('README.md', 'requirements.txt')
FIGURES = (('4.28', '4_28', 119, 118, 4e-8), ('4.29', '4_29', 121, 120, 6e-8))


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024*1024), b''):
            digest.update(block)
    return digest.hexdigest()


def object_pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('duplicate JSON key')
        result[key] = value
    return result


def finite_float(value):
    result = float(value)
    if not math.isfinite(result) or (result == 0 and Decimal(value) != 0):
        raise ValueError('unsupported JSON number projection')
    return result


def loads(data):
    return json.loads(data, object_pairs_hook=object_pairs, parse_float=finite_float,
        parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def load(path):
    return loads(Path(path).read_bytes())


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False)+'\n')


def canonical_hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False).encode()).hexdigest()


def clean_head(expected):
    assert HEAD is not None and re.fullmatch('[0-9a-f]{40}', expected) and expected == HEAD
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == expected
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=REPO, text=True).strip()
    subprocess.run(['git', 'merge-base', '--is-ancestor', BASE, expected], cwd=REPO, check=True)
    changed = subprocess.check_output(['git', 'diff', '--name-only', BASE, expected], cwd=REPO, text=True).splitlines()
    assert set(changed) == set(PUBLIC) and len(changed) == len(PUBLIC)
    return expected


def inspect_dataset(csv_bytes, metadata, *, csv_path, metadata_path, producer_sha256, metadata_sha256):
    """Bind saved CSV/JSON and catalog declarations without any image or source parser."""
    assert metadata['schema'] == 'mhdlab-dissertation-magnetic-gap-recovery-v1'
    source, context, units, output = (metadata[key] for key in ('source', 'simulation_context', 'unit_interpretation', 'output'))
    figure = next(item for item in FIGURES if item[0] == source['figure'])
    assert source['pdf_sha256'] == PDF_SHA256 and source['pdf_page'] == figure[2] and source['pdf_page_index'] == figure[3]
    assert source['native_image_size_pixels'] == [975, 975] and source['native_image_mode'] == 'RGB'
    for key in ('page_content_sha256', 'decoded_RGB_pixels_sha256', 'extracted_PNG_sha256'):
        assert re.fullmatch('[0-9a-f]{64}', source[key])
    assert context['code_label_in_dissertation'] == 'Allegra' and context['drive_shot_caption_label'] == 17133
    assert context['caption_snapshot_time_s'] == figure[4]
    for key in ('experimental_measurement', 'FLASH_result', 'actual_material_boundaries_recovered',
                'full_vector_field_recovered', 'experimental_clock_alignment_established'):
        assert context[key] is False
    assert units['source_magnetic_axis_label'] == 'B_x [100 Tesla]'
    assert units['literal_conditional_scale_to_T'] == 100 and units['component_signs_preserved'] is True
    for key in ('original_electromagnetic_normalization_verified', 'original_simulation_output_units_confirmed',
                'normalization_or_legend_error_resolved', 'unit_repair_or_empirical_rescaling_applied',
                'coordinate_frame_rotation_applied'):
        assert units[key] is False
    assert metadata['readout_bounds']['correlated_display_bounds_only'] is True
    assert metadata['readout_bounds']['physical_or_simulation_uncertainty_quantified'] is False
    assert metadata['readout_bounds']['independent_noise_or_confidence_interval'] is False
    assert output['csv_filename'] == Path(csv_path).name
    assert output['csv_sha256'] == hashlib.sha256(csv_bytes).hexdigest()
    assert output['generator'] == PRODUCER and output['generator_sha256'] == producer_sha256
    reader = csv.DictReader(io.StringIO(csv_bytes.decode()))
    rows = list(reader)
    assert reader.fieldnames == output['columns'] and len(rows) == output['samples'] == 262
    numeric_columns = set(reader.fieldnames)-{'figure', 'profile'}
    assert len(numeric_columns) == 15
    assert all(math.isfinite(float(row[key])) for row in rows for key in numeric_columns)
    selection = metadata['selection']
    assert set(selection['profiles']) == {'foil_edge', 'foil_middle'}
    roi = selection['panel_ROI_inclusive']['y']
    expected_rows = set(range(roi[0], roi[1]+1))
    profile_records = {}
    for name, record in selection['profiles'].items():
        retained, discarded = record['retained_rows'], record['excluded_rows']
        kept_y = [item['pixel_y'] for item in retained]
        excluded_y = [item['pixel_y'] for item in discarded]
        selected = [row for row in rows if row['profile'] == name]
        assert len(selected) == len(retained) == record['retained_count'] == output['samples_by_profile'][name] == 131
        assert len(discarded) == record['excluded_count'] == 262
        assert len(kept_y) == len(set(kept_y)) and len(excluded_y) == len(set(excluded_y))
        assert not set(kept_y)&set(excluded_y) and set(kept_y)|set(excluded_y) == expected_rows
        assert record['catalogued_row_count'] == len(expected_rows) == 393
        assert {int(row['pixel_y']) for row in selected} == set(kept_y)
        assert all(item['reason'] == 'retained' for item in retained)
        assert all(item['reason'].strip() and item['reason'] != 'retained' for item in discarded)
        catalog = {item['pixel_y']: item for item in retained}
        gaps = [Decimal(row['gap_coordinate_mm']) for row in selected]
        assert all(a < b for a, b in zip(gaps, gaps[1:]))
        assert min(gaps) < 0 < max(gaps)
        for row in selected:
            assert row['figure'] == figure[0] and float(row['time_s']) == figure[4]
            literal = Decimal(row['Bx_literal_axis_value'])
            assert literal < 0 and Decimal(row['Bx_literal_conditional_T']) == 100*literal
            for suffix in ('', '_readout_lower', '_readout_upper'):
                assert Decimal(row['Bx_literal_conditional'+suffix+'_T']) == 100*Decimal(row['Bx_literal'+suffix+'_axis_value'])
            assert Decimal(row['Bx_literal_readout_lower_axis_value']) <= literal <= Decimal(row['Bx_literal_readout_upper_axis_value'])
            assert Decimal(row['gap_coordinate_readout_lower_mm']) <= Decimal(row['gap_coordinate_mm']) <= Decimal(row['gap_coordinate_readout_upper_mm'])
            first, last = int(row['run_first_pixel_x']), int(row['run_last_pixel_x'])
            assert catalog[int(row['pixel_y'])]['exact_colour_runs_inclusive_x'] == [[first, last]]
            assert int(row['matched_color_pixels']) == last-first+1
        profile_records[name] = {'samples': len(selected), 'excluded_rows': len(discarded),
            'catalogued_rows': len(expected_rows), 'catalog_sha256': canonical_hash(record),
            'negative_primary_values': len(selected), 'negative_gap_coordinates': sum(value < 0 for value in gaps),
            'positive_gap_coordinates': sum(value > 0 for value in gaps)}
    for key in ('interpolation', 'smoothing', 'extrapolation', 'surface_or_endpoint_padding', 'symmetry_imposed'):
        assert selection[key] is False
    geometry_name = output['source_geometry_filename']
    assert Path(geometry_name).name == geometry_name
    expected_qa = {f'figure_{figure[1]}_magnetic_gap.{suffix}' for suffix in ('png', 'pdf')}
    assert set(output['QA_files_sha256']) == expected_qa
    return {'figure': figure[0], 'csv_path': csv_path, 'metadata_path': metadata_path,
        'csv_sha256': output['csv_sha256'], 'metadata_sha256': metadata_sha256,
        'producer_path': PRODUCER, 'producer_sha256': producer_sha256, 'columns': reader.fieldnames,
        'samples': len(rows), 'profiles': profile_records, 'source': source,
        'simulation_context': context, 'unit_interpretation': units,
        'gap_coordinate_extent_mm': output['gap_coordinate_extent_mm'],
        'calibration_sha256': canonical_hash(metadata['calibration']),
        'source_geometry_filename': geometry_name, 'source_geometry_sha256': output['source_geometry_sha256'],
        'QA_files_sha256': output['QA_files_sha256'], 'physical_truth_validated': False,
        'original_normalization_verified': False}


def dataset_bindings():
    datasets = []
    for _, identifier, _, _, _ in FIGURES:
        csv_name = f'data/dissertation/figure_{identifier}_magnetic_gap.csv'
        metadata_name = f'data/dissertation/figure_{identifier}_magnetic_gap.json'
        datasets.append(inspect_dataset((REPO/csv_name).read_bytes(), load(REPO/metadata_name),
            csv_path=csv_name, metadata_path=metadata_name, producer_sha256=sha(REPO/PRODUCER),
            metadata_sha256=sha(REPO/metadata_name)))
    return datasets


def command_snapshot_prefix(snapshot, live):
    """Require an immutable complete-record byte prefix while later commands may append."""
    assert snapshot and snapshot.endswith(b'\n') and live.startswith(snapshot)
    for line in snapshot.splitlines():
        assert isinstance(loads(line), dict)
    return {'sha256': hashlib.sha256(snapshot).hexdigest(), 'bytes': len(snapshot),
        'complete_records': len(snapshot.splitlines()),
        'qualification': 'Exact complete-record byte prefix; later verification/completion commands may append to the live log.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--expected-head', required=True)
    args = parser.parse_args()
    head = clean_head(args.expected_head)
    for name in PUBLIC:
        path = PurePosixPath(name)
        assert not path.is_absolute() and '..' not in path.parts
        assert (REPO/name).is_file() and not (REPO/name).is_symlink()
    datasets = dataset_bindings()
    payload = WORK/'delivery-preparation/payload'
    assert not payload.exists() and not OUT.exists() and not OUT.with_suffix('.tar.gz').exists()
    source = payload/'source'
    source.mkdir(parents=True)
    for name in PUBLIC:
        target = source/name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(REPO/name, target)
    (source/'requirements.txt').write_text('numpy\nPyMuPDF\nPillow\nmatplotlib\n')
    (source/'README.md').write_text(f'''# Published signed magnetic-gap recovery patch

Nine public files are copied byte-for-byte from `{head}`. Apply the accompanying
patch to the complete checkout at `{BASE}`. The README and recovery dependency
list are packaging wrappers; this source subset is not presented as a separately
executed or portable package, and no package initializer replacement is supplied.

The four coarse signed B_x gap profiles come from published legacy Allegra
simulation panels at40/60ns. Complete retained/excluded native row catalogs,
source/PDF/RGB hashes, axis calibration, finite support, display readout bounds,
geometry, generated QA and independent source checks are preserved. Printed
electromagnetic units and normalization remain unverified. Any tesla columns are
only an explicitly conditional literal-unit conversion.

No field derivative, skin depth, exact surface value, current integral, heating,
Hall response, full vector field, physical material closure, clock alignment,
experimental agreement, FLASH result or host acceptance is established. Original
PDF/native image bytes are omitted with hashes; generated QA is included. A
deliberate future recovery requires the original dissertation. Packaging repeats
no recovery, scientific oracle, previous suite or numerical source evolution.
''')
    save(payload/'source_file_list.json', {'byte_identical_public_files': list(PUBLIC), 'packaging_wrappers': list(WRAPPERS)})
    (payload/'source-files.sha256').write_text(''.join(f'{sha(source/name)}  {name}\n' for name in PUBLIC))
    (payload/'wrapper-files.sha256').write_text(''.join(f'{sha(source/name)}  {name}\n' for name in WRAPPERS))
    save(payload/'preparation.json', {'source_commit': head, 'base_commit': BASE, 'datasets': datasets,
        'package_kind': 'patch_over_exact_complete_baseline', 'required_complete_baseline_checkout': True,
        'portable_execution_performed': False, 'physical_truth_validated': False,
        'public_source_sha256': {name: sha(REPO/name) for name in PUBLIC}})
    print(json.dumps({'payload': str(payload), 'source_commit': head, 'public_files': len(PUBLIC),
        'packaging_wrappers': len(WRAPPERS), 'retained_rows': sum(item['samples'] for item in datasets)}, indent=2))


if __name__ == '__main__':
    main()
