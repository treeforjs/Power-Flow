"""Run only four newly planned invalid-source controls; never recover curves."""
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import sys

WORK=Path(__file__).resolve().parents[1]


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    plan_path=WORK/'guards/plan.json'
    plan=json.loads(plan_path.read_text())
    freeze=json.loads((WORK/'guards/freeze.json').read_text())
    assert plan['status']=='frozen_before_first_guard_execution'
    assert sha(plan_path)==freeze['plan_sha256']
    module_path=Path(plan['module_path']);pdf=Path(plan['PDF_path'])
    assert sha(module_path)==plan['module_sha256']==freeze['module_sha256']
    assert sha(pdf)==plan['PDF_sha256']==freeze['PDF_sha256']
    status_before=sha(WORK.parent/'mitl-upstream-status.json')
    spec=importlib.util.spec_from_file_location('new_magnetic_gap_guard_target',module_path)
    target=importlib.util.module_from_spec(spec)
    sys.modules[spec.name]=target
    spec.loader.exec_module(target)
    outcomes=[]
    producer_results=[]
    unexpected_source_selection_calls=[]

    def must_not_select(*args,**kwargs):
        unexpected_source_selection_calls.append(True)
        raise AssertionError('invalid source reached physical curve selection')

    original_make_rows=target.make_rows
    target.make_rows=must_not_select

    def expect_value_error(control,callback):
        try:
            producer_results.append(callback())
        except ValueError as error:
            assert str(error)==plan['required_errors'][control],(control,str(error))
            outcomes.append({'id':control,'rejected':True,'exception':'ValueError','reason':str(error)})
        else:
            raise AssertionError('invalid source was accepted: '+control)

    fixture=WORK/'guards/fixtures'
    fixture.mkdir(exist_ok=False)
    altered=fixture/'altered-source.pdf'
    data=bytearray(pdf.read_bytes());data[-1]^=1;altered.write_bytes(data)
    assert sha(altered)!=plan['PDF_sha256']
    expect_value_error('altered_pdf_identity',lambda:target.recover(altered))

    original_figures=target.FIGURES
    target.FIGURES=({**original_figures[0],'rgb_sha256':'0'*64},*original_figures[1:])
    try:
        expect_value_error('altered_native_image_identity',lambda:target.recover(pdf))
    finally:
        target.FIGURES=original_figures
        target.make_rows=original_make_rows

    import numpy as np
    import pymupdf
    from PIL import Image
    with pymupdf.open(pdf) as document:
        native_bytes=document.extract_image(plan['first_figure']['xref'])['image']
    with Image.open(io.BytesIO(native_bytes)) as image:
        pixels=np.array(image.convert('RGB'))
    assert hashlib.sha256(pixels.tobytes()).hexdigest()==plan['first_figure']['rgb_sha256']
    white=np.full_like(pixels,255)
    expect_value_error('corrupted_tick_mask',lambda:target.validate_ticks(white))

    synthetic=np.full_like(pixels,255)
    selection=plan['synthetic_selection'];y=selection['pixel_y'];rgb=tuple(selection['RGB'])
    expected_runs=[selection['first_run_inclusive_x'],selection['second_run_inclusive_x']]
    for first,last in expected_runs:
        synthetic[y,first:last+1]=rgb
    selected,reason,runs=target.select_row(synthetic,y,rgb)
    assert selected is None and reason==plan['required_errors']['multiple_exact_colour_runs']
    assert runs==expected_runs
    outcomes.append({'id':'multiple_exact_colour_runs','rejected':True,'selected':None,
        'reason':reason,'retained_runs_inclusive_x':runs})
    assert not producer_results and not unexpected_source_selection_calls and len(outcomes)==4
    assert sha(module_path)==plan['module_sha256']
    assert sha(WORK.parent/'mitl-upstream-status.json')==status_before
    report={'schema':'mitl-magnetic-gap-source-guards-v1','status':'passed','all_checks_passed':True,
        'meaningful_invalid_controls':4,'controls_rejected':4,'guard_run_count':1,
        'source_identity_recover_calls':2,'tick_mask_validation_calls':1,'synthetic_selection_calls':1,
        'successful_positive_producer_replays':0,'physical_curve_selection_reached':0,
        'old_suites_or_producers_repeated':False,'public_files_edited':False,
        'status_or_lease_mutated':False,'status_before_sha256':status_before,'status_after_sha256':status_before,
        'source_pdf_sha256':plan['PDF_sha256'],
        'source_sha256':{'tools/recover_dissertation_gap_magnetic.py':plan['module_sha256']},
        'plan_sha256':sha(plan_path),'plan_freeze_sha256':sha(WORK/'guards/freeze.json'),
        'first_native_rgb_sha256':plan['first_figure']['rgb_sha256'],
        'altered_pdf_sha256':sha(altered),'native_shape':list(pixels.shape),'outcomes':outcomes,
        'artifact_sha256':{name:sha(WORK/name) for name in ['guards/plan.json','guards/freeze.json',
            'guards/freeze_plan.py','guards/run_guards.py']},
        'limits':plan['limits'],'source_status':plan['source_status'],
        'physical_normalization_verified':False,'host_or_owner_implementation_verified':False}
    (WORK/'guards/completion.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__=='__main__':
    main()
