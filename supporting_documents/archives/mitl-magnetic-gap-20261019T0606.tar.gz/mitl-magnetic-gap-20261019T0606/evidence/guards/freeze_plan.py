"""Bind the four-control plan to the newly frozen magnetic recovery source."""
import ast
import hashlib
import json
from pathlib import Path

WORK=Path(__file__).resolve().parents[1]
MODULE=Path('/workspace/Power-Flow/tools/recover_dissertation_gap_magnetic.py')
PDF=Path('/workspace/research_sources/smtrevor_1.pdf')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    digest=sha(MODULE)
    assert digest=='7b3b52b0e5d4523f74991d2e2f2fc4b3390efdb3376498142ec7ebb2111f568f'
    tree=ast.parse(MODULE.read_text())
    values={}
    for node in tree.body:
        if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name):
            if node.targets[0].id in {'PDF_SHA256','FIGURES','PROFILES'}:
                values[node.targets[0].id]=ast.literal_eval(node.value)
    assert sha(PDF)==values['PDF_SHA256']
    plan_path=WORK/'guards/plan.json'
    plan=json.loads(plan_path.read_text())
    assert plan['status']=='awaiting_frozen_new_source' and len(plan['controls'])==4
    plan.update(status='frozen_before_first_guard_execution',
        module_path=str(MODULE),module_sha256=digest,PDF_path=str(PDF),PDF_sha256=values['PDF_SHA256'],
        first_figure=values['FIGURES'][0],synthetic_selection={'pixel_y':210,
            'first_run_inclusive_x':[600,602],'second_run_inclusive_x':[700,702],
            'RGB':list(values['PROFILES'][0][1])},
        required_errors={'altered_pdf_identity':'source PDF SHA256 mismatch',
            'altered_native_image_identity':'native source RGB SHA256 mismatch',
            'corrupted_tick_mask':'magnetic native tick anchors do not match configured calibration',
            'multiple_exact_colour_runs':'multiple_exact_colour_runs'})
    plan_path.write_text(json.dumps(plan,indent=2)+'\n')
    report={'schema':'mitl-magnetic-gap-source-guard-plan-freeze-v1','status':'frozen_before_execution',
        'plan_sha256':sha(plan_path),'module_sha256':digest,'PDF_sha256':sha(PDF),
        'guard_controls':4,'guard_functions_or_recovery_called':False,
        'writer_sha256':sha(__file__)}
    (WORK/'guards/freeze.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__=='__main__':
    main()
