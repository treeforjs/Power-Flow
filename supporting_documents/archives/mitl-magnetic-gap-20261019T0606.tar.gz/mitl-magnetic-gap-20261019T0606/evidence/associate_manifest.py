"""Associate only the newly recovered magnetic-gap artifacts with the manifest."""
import hashlib
import json
from pathlib import Path
import yaml

repo=Path('/workspace/Power-Flow')
work=Path(__file__).resolve().parent
manifest=repo/'data/dissertation/recovery_manifest.yaml'
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
assert sha(manifest)=='e58e6ec43e687494f6f0e02f651a41dc96729616a44076a744ca5769092c7bc2'
tool='tools/recover_dissertation_gap_magnetic.py'
assert sha(repo/tool)=='7b3b52b0e5d4523f74991d2e2f2fc4b3390efdb3376498142ec7ebb2111f568f'
before_text=manifest.read_text()
before=yaml.safe_load(before_text)
text=before_text
new_records={}
for suffix,figure,time_s in [('4_28','4.28',4e-8),('4_29','4.29',6e-8)]:
    stem='figure_'+suffix+'_magnetic_gap'
    data=repo/'data/dissertation'/(stem+'.csv')
    metadata=repo/'data/dissertation'/(stem+'.json')
    record=json.loads(metadata.read_text())
    assert record['schema']=='mhdlab-dissertation-magnetic-gap-recovery-v1'
    out=record['output'];units=record['unit_interpretation'];selection=record['selection']
    assert out['csv_sha256']==sha(data) and out['generator_sha256']==sha(repo/tool)
    assert record['source']['figure']==figure
    assert record['simulation_context']['caption_snapshot_time_s']==time_s
    assert out['samples']==262 and out['samples_by_profile']=={'foil_edge':131,'foil_middle':131}
    assert selection['retained_central_y_inclusive']==[150,280]
    assert all(p['retained_count']==131 and p['excluded_count']==262 and p['catalogued_row_count']==393
               for p in selection['profiles'].values())
    assert units['literal_conditional_scale_to_T']==100
    assert units['original_electromagnetic_normalization_verified'] is False
    artifact={'file':data.name,'metadata':metadata.name,'generator':tool,
      'status':'digitized_published_simulation','csv_sha256':sha(data),'metadata_sha256':sha(metadata),
      'generator_sha256':sha(repo/tool),
      'content':'262 signed conservative central-gap B_x samples; 131 each for foil-edge and foil-middle labels',
      'time_s':time_s,'source_magnetic_axis_label':units['source_magnetic_axis_label'],
      'source_coordinate_axis_label':units['source_gap_axis_label'],
      'primary_quantity':'signed literal B_x plotted axis value',
      'conditional_scale_to_T':100,'original_electromagnetic_normalization_verified':False,
      'gap_coordinate_extent_mm':out['gap_coordinate_extent_mm'],
      'signed_Bx_literal_extent_by_profile':out['signed_Bx_literal_extent_by_profile'],
      'native_retained_rows_inclusive':[150,280],'native_candidate_rows_per_profile':393,
      'retained_samples_by_profile':out['samples_by_profile'],'excluded_rows_per_profile':262,
      'full_vector_field_recovered':False,'exact_surface_field_recovered':False,
      'experimental_clock_alignment_established':False,
      'digitization_estimates':{'magnetic_recipe':record['readout_bounds']['magnetic_recipe'],
        'gap_recipe':record['readout_bounds']['gap_recipe'],
        'meaning':'Correlated native display readout bounds only; no physical uncertainty, derivative or Hall acceptance.'}}
    marker='- id: fig_'+suffix+'\n'
    start=text.index(marker)
    end=text.find('\n- id: ',start+len(marker))
    if end<0:end=len(text)
    part=text[start:end]
    old='  still_pending:\n  - magnetic gap panel\n'
    assert part.count(old)==1 and stem not in part
    raw=yaml.safe_dump([artifact],sort_keys=False,allow_unicode=True,width=108)
    block=''.join('  '+line+'\n' for line in raw.splitlines())
    new=block+'  still_pending:\n  - magnetic boundary jumps, crossings, exterior branches and legend-covered regions\n  - original electromagnetic normalization and unit export\n'
    text=text[:start]+part.replace(old,new)+text[end:]
    new_records['fig_'+suffix]=artifact
after=yaml.safe_load(text)
assert before.keys()==after.keys()
list_key=next(key for key,value in before.items() if isinstance(value,list) and any(isinstance(x,dict) and x.get('id')=='fig_4_28' for x in value))
assert all(before[key]==after[key] for key in before if key!=list_key)
assert len(before[list_key])==len(after[list_key])
for old,new in zip(before[list_key],after[list_key]):
    if not isinstance(old,dict) or old.get('id') not in new_records:
        assert old==new
        continue
    changed={'recovered_artifacts','still_pending'}
    assert all(old[key]==new[key] for key in old if key not in changed)
    assert new['recovered_artifacts']==old['recovered_artifacts']+[new_records[old['id']]]
    assert new['still_pending']==[
      'magnetic boundary jumps, crossings, exterior branches and legend-covered regions',
      'original electromagnetic normalization and unit export']+[x for x in old['still_pending'] if x!='magnetic gap panel']
manifest.write_text(text)
result={'schema':'mitl-magnetic-gap-manifest-association-v1','status':'passed',
  'manifest_before_sha256':hashlib.sha256(before_text.encode()).hexdigest(),
  'manifest_after_sha256':sha(manifest),'only_figure_artifact_and_pending_associations_changed':True,
  'figure_artifacts':new_records,'old_scientific_producers_or_tests_executed':False}
(work/'manifest-association.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps(result,indent=2))
