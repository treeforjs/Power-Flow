"""Write a conditional next-task design from cached evidence only."""
import hashlib,json,pathlib
W=pathlib.Path(__file__).resolve().parent
R=pathlib.Path('/workspace/Power-Flow')
P=W.parent
Q=pathlib.Path('/workspace/research_work/mitl-upstream-20261019T0544')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def pin(p,meaning):return {'path':str(p),'sha256':sha(p),'meaning':meaning}
proposal={
 'schema':'mhdlab-next-forced-arrhenius-feedback-proposal-v1','status':'conditional_planning_only',
 'task':'Implement and independently verify a separate manufactured single-patch prescribed-power reference with strictly positive activation energy and fixed-reference coverage-dependent kinetics.',
 'why_new':'The isolated zero-power reference verifies Arrhenius cooling, while the later prescribed-power reference explicitly rejects nonzero activation energy. Neither verifies temperature-dependent rates coupled to forced heating, power discontinuities and separate gross energy channels.',
 'why_unblocked':'All inputs remain explicitly manufactured, so no new physical material parameter, monolayer convention, calibrated observation, licensed FLASH installation or owner-defined gap response is required for this numerical qualification. The task closes a concrete missing coupling test rather than extending an evidence validator.',
 'evidence':[
  pin(R/'mhdlab/thermal_feedback_reference.py','Separate isolated feedback evolution supports nonzero activation and fixed Nref; its evolution must not be called or rerun.'),
  pin(R/'mhdlab/thermal_power_reference.py','Prescribed-power evolution currently rejects activation_energy_ev != 0; finite schedules and logical-time representation are already specified as data contracts.'),
  pin(R/'docs/thermal_power_reference.md','Current qualified forced branch has zero barrier and makes no temperature-dependent water-release prediction.'),
  pin(Q/'producer/completion.json','Saved zero-barrier forced reference production and parser checks completed separately; no trajectories are to be regenerated.'),
  pin(Q/'independent-verification/completion.json','Independent zero-barrier forced reference evidence already completed separately; its oracle is not a reference for the nonlinear forced IVP.'),
  pin(P/'status-before-lease.json','Saved queue and owner, physical inference, observation, material and FLASH gates before current magnetic-profile task.'),
  pin(W/'inspected_evidence.json','Bounded cached source/status inspection; no source parser, model, producer, oracle or network call.')],
 'suggested_new_public_paths':['mhdlab/thermal_forced_feedback_reference.py','tests/test_thermal_forced_feedback_reference.py','tools/run_thermal_forced_feedback_reference.py','configs/thermal_forced_feedback_manufactured.json','docs/thermal_forced_feedback_reference.md'],
 'proposed_api':{
  'data_inputs':'FeedbackProblem / FeedbackReservoir and PowerSchedule / PowerSegment may be imported as validated immutable data only; do not call either previous evolution function.',
  'rhs':'forced_feedback_rhs(problem, *, coverage_m2, temperature_k, power_w_m2) -> explicit release/temperature rates and positive input/removal/internal/translation/wall powers',
  'evolve':'evolve_forced_feedback(problem: FeedbackProblem, schedule: PowerSchedule) -> ForcedFeedbackHistory',
  'history':'Immutable problem/schedule/samples; .to_dict() retains complete inputs, model identity, logical grid, power-jump rule, units and numerical limitations.',
  'sample':'Retain segment_index, segment_step, rounded time_s, N, T, cumulative emitted amount, gross input, prescribed-input check, removal, internal, translation, gross wall debit, signed thermal change, bound-reference channels and signed number/allocation/channel/total residuals; extensive copies apply patch area once.',
  'qualification':'Manufactured stationary single patch, supplied constant C_A, nonnegative finite prescribed power and strictly positive Ea0 only for the first qualified extension; alpha may be zero or positive. No modification to prior public references.'},
 'equations':[
  'All energies in these equations are SI joules per parent: Ea0=activation_energy_ev*e, D=desorption_energy_ev*e, I=internal_energy_ev*e, with exact SI k_B and elementary charge e.',
  'Ea(N) = Ea0*(1-alpha*N/Nref), with fixed supplied Nref and supported 0<=N<=Nmax, alpha>=0, Ea(N)>=0 throughout the declared domain.',
  'r(N,T) = nu*exp[-Ea(N)/(k_B*T)]; Gamma=N*r; dN/dt=-Gamma.',
  'C_A*dT/dt = P_segment - Gamma*(D+I+2*k_B*T).',
  'dE_input/dt=P_segment; dM/dt=Gamma; dE_removal/dt=D*Gamma; dE_internal/dt=I*Gamma; dE_translation/dt=2*k_B*T*Gamma; dW/dt=Gamma*(D+I+2*k_B*T).',
  'U_ads=-D*N; C_A*(T-T0)+D*(N0-N)+E_internal+E_translation-E_input is a signed independent energy balance, not a definition of any outgoing channel.'
 ],
 'production_requirements':[
  'A separate direct coupled N/T fixed-step numerical IVP, with stages split exactly at every represented schedule knot; a shared boundary state uses old power in the completed segment and new power in the next segment.',
  'No substitution of frozen initial-T rate, zero-barrier law, maintained-T hypothesis or isolated-wall T(N) curve into a forced segment.',
  'State N must remain nonnegative and monotone, T must remain in the declared range, and all stages must satisfy the fixed-reference effective-barrier domain. Reject unsupported stage/domain/representation results without clipping, floors, automatic repairs or retries.',
  'Qualify Arrhenius hazard and population-weighted products before projection, retaining representable extensive transfers or rejecting the unsupported case; no blind exp underflow leading to a claimed zero rate.',
  'Gross positive input and all debit channels must remain distinct when signed net temperature change is small or zero; positive-transfer and lost-increment guards apply independently of total residual.',
  'Raw JSON decimal endpoints must exactly tile the declared finite support before explicit binary64 projection. Reject nonzero numeric lexeme underflow/overflow, raw gaps/overlaps that collapse in float, collapsed positive durations and missing schedule support. Fresh bounded checks are required for the new final CLI; prior checks are design precedent only.',
  'Freeze final source/config/core-test gate before one positive batch. Save all failures/version changes if any; no old producer, reference, recovery, source integration or passing suite replay.'
 ],
 'independent_reference_ladder':{
  'fresh_transformed_ivp':[
   'At each segment start recenter using that segment\'s carried N_s,T_s and local s=0. Let N=N_s*exp(-s), A=(D+I)/(2*k_B), b=2*k_B*(N_s-N)/C_A, Z=(T+A)*exp(b).',
   'Reconstruct T=Z*exp(-b)-A. Independently solve ds/dt=nu*exp[-Ea(N)/(k_B*T)] and dZ/dt=P_segment*exp(b)/C_A using a high-precision method distinct from production direct RK4.',
   'Carry N,T and cumulative physical channels across a power jump, then reset only the numerical segment reference (N_s,b,s,Z). Nref is never reset. Recentring bounds accumulated exponent growth but is not an overflow cure; require finite represented transformed coordinates and reject an unsupported range.',
   'For an off segment Z is constant, furnishing an exact thermal-curve check inside the fresh reference. A constant positive barrier and an empty-inventory limit provide additional analytic structural checks without calling prior evolution/oracles.'
  ],
  'method_and_precision':'Before any new reference run, freeze a high-precision Taylor/collocation or equivalently independent method on the transformed system, with e.g. 80/120 decimal digits, distinct method orders/tolerances and exact represented schedule-knot splitting. Freeze the actual ladder and budget tolerances rather than selecting them after seeing errors. Precision/order changes estimate reference stability; they do not certify an interval enclosure.',
  'channels':'Compute reference number from N_s*exp(-s), input from exact piecewise constant power support, D/I channels from declared costs and independently computed release, and translation/gross wall debit by direct positive quadrature of their physical integrands along the independent trajectory. Never obtain translation, wall debit or temperature by solving a total-energy residual. Split quadrature at every schedule knot.',
  'reference_sampling':'Use the union of saved logical observation grids per distinct fixture, derived exactly from represented endpoints and segment/step indices. Solve reference once per case/precision and reuse saved reference values across its refinement family; do not invoke production or old positive examples for oracle data.',
  'separate_comparisons':['N and emitted amount against independent trajectory.','T and signed thermal excursion, normalized by resolvable excursion or gross input/debit divided by C_A rather than initial T or a nearly cancelled final net change.','Every positive energy channel and gross input on its own reference budget; true zero channels require exact zero.','Signed number, input, allocation, bound-reference, wall-channel and total residuals retained independently of trajectory error.','One common per-segment 8/16/32/64 temporal family with resolvable changes before roundoff; self-orders descriptive, not independent error bounds.'],
  'not_sufficient':['A small total-energy residual.','The old zero-barrier integrating-factor trajectory.','An unforced T(N) relation on a positive-power segment.','One float64 IVP with unexamined internal error estimates.','A production-to-production or same-RK4 reference comparison.']},
 'proposed_manufactured_batch':{
  'status':'fixture-design proposal only; range and tolerances must be agreed before execution, no trajectory evaluated here',
  'common_inputs':{'initial_coverage_m2':2e20,'initial_temperature_k':900,'areal_heat_capacity_j_m2_k':.05,'patch_area_m2':2e-4,'temperature_min_k':600,'temperature_max_k':1300,'attempt_frequency_s':1e8,'reference_coverage_m2':4e20,'max_coverage_m2':4e20,'desorption_energy_ev':.12,'internal_energy_ev':.03,'duration_s':2e-7},
  'cases':[
   {'case_id':'constant_barrier_heating','activation_energy_ev':.25,'coverage_coefficient':0,'segments':[{'start_s':0,'stop_s':2e-7,'power_w_m2':6e7}],'step_grids':[[32]],'purpose':'Forced positive-barrier heating without coverage dependence.'},
   {'case_id':'coverage_dependent_cooling','activation_energy_ev':.35,'coverage_coefficient':.6,'segments':[{'start_s':0,'stop_s':2e-7,'power_w_m2':1e7}],'step_grids':[[32]],'purpose':'Finite positive input competing with cooling and a changing effective barrier; the net direction is a reference outcome, not assumed.'},
   {'case_id':'translation_only_barrier','activation_energy_ev':.35,'coverage_coefficient':.6,'desorption_energy_ev':0,'internal_energy_ev':0,'segments':[{'start_s':0,'stop_s':2e-7,'power_w_m2':1e6}],'step_grids':[[32]],'purpose':'Kinetic barrier is positive while removal/internal debits are exactly zero; only expected translation cools the finite thermal reservoir.'},
   {'case_id':'scheduled_forced_feedback','activation_energy_ev':.35,'coverage_coefficient':.6,'segments':[{'start_s':0,'stop_s':5e-8,'power_w_m2':6e7},{'start_s':5e-8,'stop_s':1e-7,'power_w_m2':0},{'start_s':1e-7,'stop_s':2e-7,'power_w_m2':3e7}],'step_grids':[[8,8,8],[16,16,16],[32,32,32],[64,64,64]],'purpose':'Recentered segment carry, an exact off-segment structural relation, nonlinear response to power changes and one temporal refinement family.'}],
  'trajectory_count':7,'planned_saved_samples':463,
  'separate_new_core_controls':'A bounded empty-inventory positive-barrier case, effective-barrier/temperature-domain and representation rejections, schedule-boundary continuity, fixed Nref, area once and independent barrier/removal allocation; no extra saved positive fixture family or old-case replay.'},
 'deferred_queue_gates':[
  {'task':'Physical water/OH release and monolayer inference','gate':'Requires actual target-surface parent inventory convention, preparation, independently supported rate/energy parameters and material-transfer assessment. Manufactured constants and alpha/Nref are not calibrated physical values.'},
  {'task':'Absolute VUV/spectrum comparison','gate':'Requires response quantity, original calibration/gate/gain/throughput and a defensible observation map with actual noise/covariance. Published transition densities are not total ground neutral density.'},
  {'task':'Owner transport/response acceptance','gate':'Requires owner-declared fields, geometry/collection/loss and response definitions. Preserve full time/state/velocity/current/T mixture; no separately owned solver edits or calls.'},
  {'task':'Actual FLASH/material heating','gate':'Requires licensed installed code, configured compute, validated material/EOS/transport/units and boundary interfaces. Recovered legacy B/J/display drive units and clocks do not establish heating or actual FLASH validation.'},
  {'task':'Joly/Li-Dylla or other physical source acquisition','gate':'No new legitimate full-text location or supplied copy is present in this cached selection; do not repeat blocked access routes or old source audits.'}],
 'current_milestone_dependency':{'pass':'mitl-upstream-20261019T0606','task':'Four coarse signed B_x gap profiles from dissertation Figures4.28/4.29','status':'acceptance_not_yet_bound','requirement':'Do not write final selected-next-task status until the current magnetic profile author/independent verification and output associations pass. Final selection must pin the actual completed verification bytes and retain literal-conditional field normalization and no derivative/heating/clock inference.'},
 'planning_only':{'public_files_edited':False,'new_data_or_source_parser_called':False,'source_digitization_or_axis_fit_performed':False,'model_producer_or_oracle_executed':False,'old_passing_suites_or_audits_repeated':False,'network_used':False,'physical_parameters_adopted':0,'separately_owned_solver_accessed':False}}
(W/'forced_arrhenius_power_proposal.json').write_text(json.dumps(proposal,indent=2,allow_nan=False)+'\n')
print(json.dumps({'proposal':str(W/'forced_arrhenius_power_proposal.json'),'sha256':sha(W/'forced_arrhenius_power_proposal.json'),'status':proposal['status'],'physics_executed':False},indent=2))
