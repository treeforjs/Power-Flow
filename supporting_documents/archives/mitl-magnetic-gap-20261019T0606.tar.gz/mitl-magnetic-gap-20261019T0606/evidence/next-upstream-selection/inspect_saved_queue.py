"""Bounded cached evidence inventory for a next upstream selection; no models."""
from pathlib import Path
import hashlib,json
ROOT=Path('/workspace/Power-Flow');PASS=Path(__file__).resolve().parent.parent
paths=[Path('/workspace/research_work/mitl-upstream-status.json'),PASS/'status-before-lease.json',Path('/workspace/research_work/mitl-upstream-20261019T0544/next-upstream-selection/selection.json'),Path('/workspace/research_work/mitl-upstream-20261019T0544/next-upstream-selection/magnetic_gap_recovery_proposal.json'),Path('/workspace/research_work/mitl-upstream-20261019T0544/producer/completion.json'),Path('/workspace/research_work/mitl-upstream-20261019T0544/independent-verification/completion.json'),ROOT/'docs/thermal_power_reference.md',ROOT/'docs/thermal_feedback_reference.md',ROOT/'mhdlab/thermal_power_reference.py',ROOT/'mhdlab/thermal_feedback_reference.py',ROOT/'data/dissertation/recovery_manifest.yaml']
records=[]
for p in paths:
 if not p.exists():records.append({'path':str(p),'exists':False});continue
 data=p.read_bytes();text=data.decode()
 records.append({'path':str(p),'exists':True,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'relevant_lines':[{'line':i,'text':line[:500]} for i,line in enumerate(text.splitlines(),1) if any(k in line.lower() for k in ('nonzero','activation','next_task','next_step','forced','zero-barrier','independent','still_pending','monolayer','calibrat','material','flash','blocked','thermal-power-reference','scope_limits'))][:55]})
print(json.dumps({'schema':'mhdlab-cached-upstream-selection-inspection-v1','records':records,'network_used':False,'model_or_producer_or_oracle_called':False},indent=2))
(PASS/'next-upstream-selection/inspected_evidence.json').write_text(json.dumps({'schema':'mhdlab-cached-upstream-selection-inspection-v1','records':records,'network_used':False,'model_or_producer_or_oracle_called':False},indent=2)+'\n')
