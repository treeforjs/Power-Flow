"""Bind completed magnetic evidence to a frozen next-task design; no science replay."""
from pathlib import Path
import datetime,hashlib,json
W=Path(__file__).resolve().parent;P=W.parent
D={
 'proposal':(W/'forced_arrhenius_power_proposal.json','b1374c57eeeefc5a6189ee81ac4fa1b7aa6fa6bc65193c94ffe4c158b8730ce1'),
 'author':(P/'recovery/author-verification.json','c38cd664f9f300874bd7f845720b5439b1c967c1248948f82f1ce048d7f1022f'),
 'independent':(P/'independent-verification/completion.json','c5e1251b8e25a3d0073adececb975d15e287b979e3c081a2c3efad9c11660819'),
 'scientific':(P/'scientific-review/completion.json','e829d50d457d11ac0d5f5ef5398bd73a03529b31487b91c0c20857f8bf11b8bf')}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
loaded={}
for name,(p,digest) in D.items():
 assert sha(p)==digest,(name,'source changed')
 loaded[name]=json.loads(p.read_text())
assert loaded['proposal']['status']=='conditional_planning_only'
assert loaded['independent']['schema']=='mitl-independent-magnetic-gap-completion-v1'
assert loaded['independent']['status']=='passed'
assert loaded['scientific']['schema']=='mitl-magnetic-gap-scientific-review-v1'
assert loaded['scientific']['status']=='review_complete_no_substantive_issue_identified'
allchecks={k:v for k,v in loaded['independent'].items() if k.startswith('all_check')}
assert allchecks and all(v is True for v in allchecks.values()),allchecks
selection={
 'schema':'mhdlab-next-upstream-selection-v1','status':'selected_after_current_scientific_acceptance',
 'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'task':loaded['proposal']['task'],
 'rationale':loaded['proposal']['why_new'],
 'bounded_plan':{'path':str(D['proposal'][0]),'sha256':D['proposal'][1],
                 'schema':loaded['proposal']['schema'],'proposal_status_remains':'conditional_planning_only; this record now binds the prerequisite acceptance, not a future implementation result'},
 'current_milestone':{
  'pass':'mitl-upstream-20261019T0606','task':'Four coarse signed B_x gap profiles in dissertation Figures4.28/4.29',
  'scientific_acceptance':'Root accepted pinned author verification, independent readback and independent scientific review before this selection was written.',
  'author_verification':{'path':str(D['author'][0]),'sha256':D['author'][1],'schema':loaded['author']['schema']},
  'independent_verification':{'path':str(D['independent'][0]),'sha256':D['independent'][1],'schema':loaded['independent']['schema'],'status':loaded['independent']['status'],'all_check_fields':allchecks},
  'scientific_review':{'path':str(D['scientific'][0]),'sha256':D['scientific'][1],'schema':loaded['scientific']['schema'],'status':loaded['scientific']['status']},
  'accepted_metrics_from_root_association':{'figures':2,'profiles':4,'retained_native_rows':524,'excluded_native_rows':1048,'catalogued_native_rows':1572,'author_positive_producer_runs':1,'independent_attempts':2,'independent_completed_readbacks':1},
  'preserved_attempt_qualification':'First independent attempt stopped before catalog/CSV comparison because a tick-tail anchor was417 rather than418; both fresh native scans were identical. Completed readback and correction evidence are preserved in the pinned completion; no producer was replayed for selection.',
  'limitations':['Coarse published legacy Allegra simulation gap profiles; not experimental field measurements or actual FLASH output.','Signed literal plotted B_x and the printed conditional scale remain distinct from verified original normalization.','No B derivative, surface-field reconstruction, current/Ampere closure, magnetic-energy closure, J-squared heating, trigger registration, original-mesh recovery or physical source parameter inference.'],
  'final_public_document_association_or_HEAD_claimed':False},
 'next_task_controls':{
  'fresh_lease_required_for_implementation':True,
  'new_separate_module_and_oracle_only':True,
  'previous_evolution_or_producer_or_reference_replay_allowed':False,
  'temperature_dependent_forced_IVP_still_unverified':True,
  'fixture_values_are_unexecuted_design_proposals':True,
  'reference_recentered_at_each_segment':True,
  'fixed_Nref_and_effective_barrier_domain_required':True,
  'positive_translation_and_wall_quadrature_independent_of_residual':True,
  'raw_schedule_and_representation_checks_required_on_new_final_code':True,
  'no_physical_parameters_monolayer_VUV_FLASH_or_host_claim':True},
 'deferred_queue_gates':loaded['proposal']['deferred_queue_gates'],
 'planning_activity':{'metadata_and_cached_text_read_only':True,'new_source_parser_or_digitization_called':False,'model_or_oracle_or_producer_called':False,'network_used':False,'public_files_edited':False,'separately_owned_solver_accessed':False}}
(W/'selection.json').write_text(json.dumps(selection,indent=2,allow_nan=False)+'\n')
completion={'schema':'mhdlab-next-upstream-selection-completion-v1','status':'selected_after_scientific_acceptance','selection_path':str(W/'selection.json'),'selection_sha256':sha(W/'selection.json'),'proposal_sha256':D['proposal'][1],'accepted_current_evidence_sha256':{name:digest for name,(_,digest) in D.items() if name!='proposal'},'inspected_evidence_sha256':sha(W/'inspected_evidence.json'),'script_sha256':sha(Path(__file__)),'public_files_edited':False,'physics_or_source_parsing_or_oracle_executed':False,'network_used':False,'open_substantive_findings':[]}
(W/'completion.json').write_text(json.dumps(completion,indent=2,allow_nan=False)+'\n')
print(json.dumps({'selection':str(W/'selection.json'),'selection_sha256':sha(W/'selection.json'),'completion':str(W/'completion.json'),'completion_sha256':sha(W/'completion.json'),'status':selection['status']},indent=2))
