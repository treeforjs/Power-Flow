"""Freeze source/metadata/visual review without any curve or model replay."""
import argparse
import datetime as dt
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = Path('/workspace/Power-Flow')
WORK = ROOT.parent
SOURCE_SHA = '7b3b52b0e5d4523f74991d2e2f2fc4b3390efdb3376498142ec7ebb2111f568f'
OUTPUT_PINS = {
    'data/dissertation/figure_4_28_magnetic_gap.csv': '08307893990f4d25ce9cf9fcd3bf68f6a8070cdc82f508336249d3a7a2db155b',
    'data/dissertation/figure_4_28_magnetic_gap.json': 'ac70c17f3303bf500f03e09923a5e7878638aa8f38104e88e1e4decee2a12702',
    'data/dissertation/figure_4_29_magnetic_gap.csv': 'f928d3783a1fa9ebece1576208ef04890b0fbbcf3ecbfdc9363c5c63b6f1dfa0',
    'data/dissertation/figure_4_29_magnetic_gap.json': '70ae3dd5a7a032a4262d9c321ae2fc893a217b3b8ba30abc6c728061faeac43d'
}

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def load(path):
    return json.loads(path.read_text())

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--independent-completion', type=Path, required=True)
parser.add_argument('--independent-sha256', required=True)
parser.add_argument('--author-verification', type=Path, required=True)
parser.add_argument('--author-sha256', required=True)
args = parser.parse_args()
if (ROOT / 'completion.json').exists():
    raise RuntimeError('Refuse repeated scientific-review freeze')
status = load(Path('/workspace/research_work/mitl-upstream-status.json'))
assert status['active_lease_owner'] == 'mitl-upstream-20261019T0606'
assert dt.datetime.fromisoformat(status['active_editing_lease_until_utc']) > dt.datetime.now(dt.timezone.utc)
assert sha(REPO / 'tools/recover_dissertation_gap_magnetic.py') == SOURCE_SHA
assert all(sha(REPO / name) == digest for name, digest in OUTPUT_PINS.items())
native = load(ROOT / 'native_source_inspection.json')
assert sha(ROOT / 'native_source_inspection.json') == '4fd4a0c09883d45459b8a72daabeb85db67f016762e5c302f0dbc74e016b9cff'
assert sha(args.independent_completion) == args.independent_sha256
assert sha(args.author_verification) == args.author_sha256
independent = load(args.independent_completion)
author = load(args.author_verification)
figures = []
qa_pins = {}
for name in ('figure_4_28_magnetic_gap.json', 'figure_4_29_magnetic_gap.json'):
    metadata = load(REPO / 'data/dissertation' / name)
    assert metadata['schema'] == 'mhdlab-dissertation-magnetic-gap-recovery-v1'
    unit, context, selection = (metadata[k] for k in ('unit_interpretation', 'simulation_context', 'selection'))
    assert unit['component_signs_preserved'] is True and unit['literal_conditional_scale_to_T'] == 100
    for key in ('original_electromagnetic_normalization_verified', 'original_simulation_output_units_confirmed',
                'normalization_or_legend_error_resolved', 'unit_repair_or_empirical_rescaling_applied',
                'coordinate_frame_rotation_applied'):
        assert unit[key] is False
    for key in ('experimental_measurement', 'FLASH_result', 'actual_material_boundaries_recovered',
                'full_vector_field_recovered', 'experimental_clock_alignment_established'):
        assert context[key] is False
    assert selection['retained_central_y_inclusive'] == [150, 280]
    for key in ('interpolation', 'smoothing', 'extrapolation', 'surface_or_endpoint_padding', 'symmetry_imposed'):
        assert selection[key] is False
    assert metadata['output']['generator_sha256'] == SOURCE_SHA
    assert metadata['output']['samples'] == 262
    assert metadata['output']['samples_by_profile'] == {'foil_edge': 131, 'foil_middle': 131}
    assert metadata['readout_bounds']['correlated_display_bounds_only'] is True
    assert metadata['readout_bounds']['independent_noise_or_confidence_interval'] is False
    assert metadata['readout_bounds']['physical_or_simulation_uncertainty_quantified'] is False
    for qa_name, digest in metadata['output']['QA_files_sha256'].items():
        assert sha(WORK / 'recovery' / qa_name) == digest
        qa_pins[str(Path('recovery') / qa_name)] = digest
    figures.append({'figure': metadata['source']['figure'], 'metadata_path': 'data/dissertation/' + name,
                    'source': metadata['source'], 'output': metadata['output'],
                    'observed_unit_qualification': unit,
                    'observed_limits': metadata['limits']})
notes = '''# Magnetic central-gap source and output scientific review

The previously pending upper-right magnetic panels of Figures 4.28 and 4.29
were freshly viewed from identity-checked native images. The new producer was
read without execution. Its proposed axes/selection were reviewed before its
first positive recovery; both emitted metadata files and both QA PNGs were then
read/viewed before this completion was frozen. No substantive scientific or
claims issue was identified, and no changes were requested.

The vertical coordinate is the signed distance from the middle of the AK gap,
increasing upward. The horizontal quantity is the signed B_x component,
increasing rightward. The native legend assigns pink to foil edge and purple
to foil middle. Central B_x is negative on both halves of the signed gap
coordinate; no sign reversal, absolute value, frame rotation or symmetry
repair is justified by the coordinate sign.

Rows 150–280 form a conservative partial central-gap window. Both native images
show clear separation from the crossings near approximately plus/minus 2 mm,
the sharp foil-associated sheets near plus/minus 2.5 mm and the high-gap legend
overlay. The selected support is about -1.658 to +1.633 mm, not a complete gap,
surface or exterior profile. The catalog's outside-window context labels are
conservative margins; they do not assert that every omitted pixel is occluded
or a crossing. The QA overlays and stair-step signed profiles preserve these
limits and the directly visible raster structure.

The primary recovered quantity is the literal plotted B_x axis value. The
tesla columns use the printed factor 100 conditionally; they do not establish
the original electromagnetic normalization. Full matched-run extent, an
additional two-pixel allowance and tick-fit residual form correlated display
readout bounds. These are neither physical uncertainty nor independent noise.

A nominal 200 micrometre foil occupies only about 7.9 native pixels on this axis.
These central profiles therefore do not supply skin depth, a field derivative,
Ampere/current reconstruction, Joule or magnetic-energy closure, a full field
vector, Hall transport or species magnetization. The source is a published
legacy simulation raster at nominal 40/60 ns caption labels, not experimental
electromagnetic measurements, an actual FLASH result or a registered field
history. Original arrays, moving boundaries, frame mapping and normalization
remain unavailable.

The independent readback and author records are associated by hash. Their
numerical/source-readback results were not rerun by this reviewer. The only
source parsing performed here was one native identity/image extraction for
fresh visual assessment; no curve producer, model or old suite was executed.
Full native source PNGs remain work-only under raw/ and are excluded from the
delivery; their hashes and decoded native identities remain in the record.
'''
(ROOT / 'review.md').write_text(notes)
report = {
    'schema': 'mitl-magnetic-gap-scientific-review-v1',
    'status': 'review_complete_no_substantive_issue_identified',
    'completed_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
    'reviewed_source_path': 'tools/recover_dissertation_gap_magnetic.py',
    'reviewed_source_sha256': SOURCE_SHA,
    'new_public_output_sha256': OUTPUT_PINS,
    'native_source_inspection_sha256': sha(ROOT / 'native_source_inspection.json'),
    'source_images_native_identities': native['figures'],
    'fresh_native_images_visually_inspected': 2,
    'actual_QA_PNGs_visually_inspected': 2,
    'actual_metadata_files_read': 2,
    'QA_artifact_sha256': qa_pins,
    'selection_reviewed_before_positive_recovery': True,
    'source_coordinate_orientation': 'Signed gap distance increases upward; signed B_x axis increases rightward.',
    'color_roles': {'foil_edge': 'pink [255,105,180]', 'foil_middle': 'purple [186,85,211]'},
    'partial_central_profiles': 4,
    'observed_metadata_retained_samples': 524,
    'observed_metadata_excluded_rows': 1048,
    'observed_metadata_catalogued_rows': 1572,
    'figures': figures,
    'author_verification_association': {'path': str(args.author_verification), 'sha256': args.author_sha256,
                                        'schema': author.get('schema'), 'report_reproduced_by_reviewer': False},
    'independent_verification_association': {'path': str(args.independent_completion), 'sha256': args.independent_sha256,
                                             'schema': independent.get('schema'),
                                             'observed_status': independent.get('status'),
                                             'report_reproduced_by_reviewer': False},
    'findings': [], 'source_or_data_changes_requested': False,
    'source_identity_image_extraction_executions': 1,
    'axis_fit_or_curve_digitization_by_reviewer': False,
    'positive_producer_or_model_executed': False,
    'old_producer_suite_or_source_audit_repeated': False,
    'physical_normalization_or_uncertainty_established': False,
    'Hall_magnetization_or_host_field_acceptance': False,
    'archive_excluded_paths': ['raw/'],
    'limits': ['Fresh visual source and emitted-output qualifications review only.',
               'Partial finite central gap branches only; not exterior, crossing, sheet, endpoint or surface recovery.',
               'Conditional printed 100 T conversion; original normalization and coordinate frame remain unverified.',
               'Correlated raster readout bounds do not quantify simulation/physical uncertainty.',
               'No numerical model, positive curve producer, independent readback replay or physical/host acceptance.'],
    'artifact_sha256': {str(p.relative_to(ROOT)): sha(p) for p in sorted(ROOT.iterdir()) if p.is_file()}
}
(ROOT / 'completion.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'completion': str(ROOT / 'completion.json'), 'completion_sha256': sha(ROOT / 'completion.json'),
                  'schema': report['schema'], 'status': report['status'],
                  'reviewed_source_sha256': SOURCE_SHA,
                  'positive_producer_or_model_executed': False}, indent=2))
