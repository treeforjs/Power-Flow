# Magnetic central-gap source and output scientific review

The previously pending upper-right magnetic panels of Figures 4.28 and 4.29
were freshly viewed from identity-checked native images. The new producer was
read without execution. Its proposed axes/selection were reviewed before its
first positive recovery; both emitted metadata files and both QA PNGs were then
read/viewed before this completion was frozen. No substantive scientific or
claims issue was identified, and no changes were requested.

The vertical coordinate is the signed distance from the middle of the AK gap,
increasing upward. The horizontal quantity is the signed B_x component,
increasing rightward. The native legend assigns pink to foil edge and purple
to foil middle. Central B_x is negative on both halves of the signed gap
coordinate; no sign reversal, absolute value, frame rotation or symmetry
repair is justified by the coordinate sign.

Rows 150–280 form a conservative partial central-gap window. Both native images
show clear separation from the crossings near approximately plus/minus 2 mm,
the sharp foil-associated sheets near plus/minus 2.5 mm and the high-gap legend
overlay. The selected support is about -1.658 to +1.633 mm, not a complete gap,
surface or exterior profile. The catalog's outside-window context labels are
conservative margins; they do not assert that every omitted pixel is occluded
or a crossing. The QA overlays and stair-step signed profiles preserve these
limits and the directly visible raster structure.

The primary recovered quantity is the literal plotted B_x axis value. The
tesla columns use the printed factor 100 conditionally; they do not establish
the original electromagnetic normalization. Full matched-run extent, an
additional two-pixel allowance and tick-fit residual form correlated display
readout bounds. These are neither physical uncertainty nor independent noise.

A nominal 200 micrometre foil occupies only about 7.9 native pixels on this axis.
These central profiles therefore do not supply skin depth, a field derivative,
Ampere/current reconstruction, Joule or magnetic-energy closure, a full field
vector, Hall transport or species magnetization. The source is a published
legacy simulation raster at nominal 40/60 ns caption labels, not experimental
electromagnetic measurements, an actual FLASH result or a registered field
history. Original arrays, moving boundaries, frame mapping and normalization
remain unavailable.

The independent readback and author records are associated by hash. Their
numerical/source-readback results were not rerun by this reviewer. The only
source parsing performed here was one native identity/image extraction for
fresh visual assessment; no curve producer, model or old suite was executed.
Full native source PNGs remain work-only under raw/ and are excluded from the
delivery; their hashes and decoded native identities remain in the record.
