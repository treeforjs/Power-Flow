"""Inspect source identity and native B-panel images without curve recovery."""
import datetime as dt
import hashlib
import io
import json
from pathlib import Path

import fitz
from PIL import Image

ROOT = Path(__file__).resolve().parent
PDF = Path('/workspace/research_sources/smtrevor_1.pdf')
SOURCE_PDF_SHA = '1d7b1f9c191a37e94f1cc3634587750f1af35b07eb13e0b94c60f3da47495ed7'
PINS = [
    ('4.28', 118, 2847, '458b3ced8db4501db3fcbcc90939ce5f336a7ec83eb97ee259c66f7112bf07c8',
     '934979de84040dc7970be53747773d2f8c78fedad9ac2b7116757a8052449103'),
    ('4.29', 120, 2870, 'ac25b035329213a8d0a354b8496b1674c2be24ceaeff65d95a48ef2e6376b34f',
     '17080e390125995d993f2fa580e2fcef6cf4cb166a267bf08a9e1a9798a8d43e')
]

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

if (ROOT / 'native_source_inspection.json').exists():
    raise RuntimeError('Refuse repeated source inspection extraction')
status = json.loads(Path('/workspace/research_work/mitl-upstream-status.json').read_text())
assert status['active_lease_owner'] == 'mitl-upstream-20261019T0606'
assert dt.datetime.fromisoformat(status['active_editing_lease_until_utc']) > dt.datetime.now(dt.timezone.utc)
assert digest(PDF.read_bytes()) == SOURCE_PDF_SHA
figures = []
with fitz.open(PDF) as doc:
    for figure, page_index, xref, rgb_sha, page_sha in PINS:
        page = doc[page_index]
        assert digest(page.read_contents()) == page_sha
        raw = doc.extract_image(xref)['image']
        with Image.open(io.BytesIO(raw)) as image:
            assert image.mode == 'RGB' and image.size == (975, 975)
            assert digest(image.tobytes()) == rgb_sha
        name = 'figure_' + figure.replace('.', '_') + '_native.png'
        output = ROOT / 'raw' / name
        output.write_bytes(raw)
        figures.append({'figure': figure, 'pdf_page_index': page_index, 'pdf_page_one_based': page_index + 1,
                        'embedded_image_xref': xref, 'decoded_RGB_sha256': rgb_sha,
                        'page_content_sha256': page_sha, 'native_size_pixels': [975, 975],
                        'native_image_path': str(output.relative_to(ROOT)), 'native_image_sha256': digest(raw),
                        'page_text': page.get_text()})
report = {'schema': 'mitl-magnetic-gap-scientific-source-inspection-v1',
          'source_pdf_path': str(PDF), 'source_pdf_sha256': SOURCE_PDF_SHA,
          'figures': figures, 'curve_recovery_performed': False,
          'positive_producer_or_model_executed': False,
          'scope': 'Fresh native image identity and visual source assessment of previously pending B_x gap panels only.',
          'archive_excluded_paths': ['raw/']}
(ROOT / 'native_source_inspection.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
