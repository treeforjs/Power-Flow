"""Bind reviewed magnetic-gap documentation to frozen source and saved checks."""
import hashlib
import json
from pathlib import Path
import re

repo=Path('/workspace/Power-Flow')
work=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(name):return json.loads((work/name).read_text())
pins={
 'recovery/author-verification.json':'c38cd664f9f300874bd7f845720b5439b1c967c1248948f82f1ce048d7f1022f',
 'guards/completion.json':'793f0ef221b25f8b0af6d378018149bd85c635fbfa2fc26bf2a73defd999832b',
 'independent-verification/completion.json':'c5e1251b8e25a3d0073adececb975d15e287b979e3c081a2c3efad9c11660819',
 'independent-verification/readback.json':'d3b50ea1ffe0ff0306c08dcce5bafe714b8d3db52646a9afd4984aa5bd0b5930',
 'scientific-review/completion.json':'e829d50d457d11ac0d5f5ef5398bd73a03529b31487b91c0c20857f8bf11b8bf',
 'next-upstream-selection/selection.json':'665ca510dc53ee06be1f059dcef4bb039c444f4c4dab0280b3d94fa35c35c2b9'}
for name,digest in pins.items():assert sha(work/name)==digest
author=load('recovery/author-verification.json')
assert author['complete'] is True and author['new_positive_producer_run_count']==1
assert author['total_retained_samples']==524 and author['total_excluded_rows']==1048
assert all(sha(repo/name)==digest for name,digest in author['public_files_sha256'].items())
guards=load('guards/completion.json')
assert guards['all_checks_passed'] is True and guards['controls_rejected']==4
independent=load('independent-verification/completion.json')
assert independent['all_checks_passed'] is True and independent['status']=='passed'
counts={'retained_rows':524,'excluded_rows':1048,'native_rows_catalogued':1572,
 'numeric_csv_cells_checked':7860,'tick_anchors_checked':18,
 'independent_saved_output_readback_attempts':2,'completed_saved_output_readback_passes':1}
assert all(independent[key]==value for key,value in counts.items())
assert independent['initial_schema_declaration_failure_preserved'] is True
review=load('scientific-review/completion.json')
assert review['status']=='review_complete_no_substantive_issue_identified' and review['findings']==[]
assert review['source_or_data_changes_requested'] is False
selection=load('next-upstream-selection/selection.json')
assert selection['status']=='selected_after_current_scientific_acceptance' and selection['task']
manifest=load('manifest-association.json')
assert manifest['status']=='passed' and manifest['only_figure_artifact_and_pending_associations_changed'] is True
assert manifest['manifest_after_sha256']==sha(repo/'data/dissertation/recovery_manifest.yaml')
pins.update({name:sha(work/name) for name in ['manifest-association.json','root-selection-review.json']})
public=list(author['public_files_sha256'])+['docs/dissertation_gap_magnetic_recovery.md',
 'docs/dissertation_recovery.md','docs/dissertation_current_depth_recovery.md',
 'data/dissertation/recovery_manifest.yaml']
assert len(public)==len(set(public))==9
guide=repo/'docs/dissertation_gap_magnetic_recovery.md'
text=guide.read_text()
for claim in ['524','1,048','1,572','7,860','18 tick anchors','Four new invalid-input',
              '−1.658228','+1.632911','conditional SI','first attempt stopped']:
    assert claim in text,claim
assert 'fits have zero\nresidual' in text
links=[]
for target in re.findall(r'\]\(([^)#]+)(?:#[^)]*)?\)',text):
    assert (guide.parent/target).is_file(),target
    links.append(target)
qa={}
for suffix in ['4_28','4_29']:
    metadata=json.loads((repo/'data/dissertation'/('figure_'+suffix+'_magnetic_gap.json')).read_text())
    assert metadata['readout_bounds']['additional_pixel_readout_half_width']==2
    assert all(fit['max_abs_tick_residual_exact']==['0','1'] for key,fit in metadata['calibration'].items()
               if key in ['magnetic','gap'])
    for name,digest in metadata['output']['QA_files_sha256'].items():
        relative='recovery/'+name
        assert sha(work/relative)==digest
        qa[relative]=digest
visual={'schema':'mitl-magnetic-gap-root-visual-review-v1','status':'passed',
 'PNG_figures_actually_viewed_by_root':2,'QA_artifact_sha256':qa,
 'findings':['Both native overlays restrict retained samples to the central shaded rows.',
  'Pink edge and purple middle identities, signed negative component values and gap orientation are clear.',
  'Native staircase structure and full-run display bounds remain visible without hidden branches or endpoint padding.',
  'Titles and axes identify legacy simulation, nominal snapshots, central-only support and unverified normalization.'],
 'replot_or_producer_execution_performed':False,'physical_normalization_accepted':False}
(work/'visual-review.json').write_text(json.dumps(visual,indent=2)+'\n')
pins['visual-review.json']=sha(work/'visual-review.json')
result={'schema':'mitl-magnetic-gap-documentation-association-v1','status':'passed',
 'public_sha256':{name:sha(repo/name) for name in public},'record_sha256':pins,
 'verified_counts':counts,'guide_local_links':links,'manifest_only_new_artifacts_and_pending_changed':True,
 'new_source_guard_controls':4,'new_positive_producer_runs':1,'independent_complete_readbacks':1,
 'initial_readback_failure_and_correction_preserved':True,'next_task':selection['task'],
 'scientific_producers_tests_or_oracles_reexecuted':False,
 'physical_normalization_or_Hall_or_host_acceptance':False}
(work/'documentation-association.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'association_sha256':sha(work/'documentation-association.json'),
 'visual_sha256':sha(work/'visual-review.json'),'public_sha256':result['public_sha256']},indent=2))
