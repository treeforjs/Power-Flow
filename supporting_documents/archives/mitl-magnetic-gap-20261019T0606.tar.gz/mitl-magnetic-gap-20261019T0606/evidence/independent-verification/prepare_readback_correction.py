"""Preserve the initial verifier and freeze the narrow declaration correction."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
WORK = HERE.parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    target = HERE/'readback_freeze_amendment.json'
    if target.exists():
        raise RuntimeError('refuse repeated correction freeze')
    frozen = json.loads((HERE/'before_readback_freeze.json').read_text())
    text = (HERE/'verify_saved_magnetic.py').read_text()
    replacements = [
        ("    amendment = load(HERE/'readback_freeze_amendment.json')\n    same(amendment['original_freeze_sha256'],sha(HERE/'before_readback_freeze.json'))\n", ''),
        ("        if name == 'verify_saved_magnetic.py':\n            same(amendment['original_verifier_sha256'],digest)\n            digest = amendment['corrected_verifier_sha256']\n", ''),
        ("    input_sha256[str(HERE/'verify_saved_magnetic.py')] = amendment['corrected_verifier_sha256']\n    input_sha256[str(HERE/'before_readback_freeze.json')] = sha(HERE/'before_readback_freeze.json')\n    input_sha256[str(HERE/'readback_freeze_amendment.json')] = sha(HERE/'readback_freeze_amendment.json')\n", ''),
        ("        same(detection['magnetic_tick_tail_row'],417)\n", "        same(detection['magnetic_tick_tail_row'],418)\n"),
        ("        declared_magnetic = native_axis(image.load(),dict(plan['magnetic_tick_detection'],tail_row=417),True)\n        same(declared_magnetic,magnetic)\n", ''),
        ("        'readback_attempts':2,'completed_saved_output_readback_passes':1,\n        'initial_readback_failure':'Verifier required its independently chosen tick-tail418, while producer declared417. Both rows directly yield identical native tick runs. Initial failure and original freeze are preserved; corrected comparison verifies both tails.',\n", ''),
    ]
    original = text
    for old,new in replacements:
        assert original.count(old) == 1
        original = original.replace(old,new,1)
    digest = hashlib.sha256(original.encode()).hexdigest()
    assert digest == frozen['independent_code_and_input_sha256']['verify_saved_magnetic.py']
    (HERE/'verify_saved_magnetic.initial.py').write_text(original)
    method = HERE/'method.md'
    method.write_text(method.read_text().rstrip()+'\n')
    assert sha(method) == frozen['independent_code_and_input_sha256']['method.md']
    records = [json.loads(line) for line in (WORK/'commands.jsonl').read_text().splitlines()]
    failed = [row for row in records if Path(row['log']).name == 'independent-magnetic-saved-readback.log']
    assert len(failed)==1 and failed[0]['exit_code']==1
    assert sha(failed[0]['log']) == failed[0]['log_sha256']
    assert 'AssertionError: (417, 418)' in Path(failed[0]['log']).read_text()
    for name,expected in frozen['public_source_sha256'].items():
        assert sha(Path('/workspace/Power-Flow')/name)==expected
    record = {'schema':'mitl-independent-magnetic-readback-freeze-amendment-v1',
        'original_freeze_sha256':sha(HERE/'before_readback_freeze.json'),
        'original_verifier_sha256':digest,'original_verifier_file':'verify_saved_magnetic.initial.py',
        'corrected_verifier_sha256':sha(HERE/'verify_saved_magnetic.py'),
        'correction_notes_sha256':sha(HERE/'readback_correction.md'),
        'initial_failure':failed[0],
        'initial_attempt_stage':'Both first-figure axis fits agreed; metadata tail-row identity guard stopped before catalog or CSV scalar checks.',
        'change':'Retain independent418 fit; require declared417 and independently derive that tail as well, with exact equality of all fitted coordinates, values, coefficients and residuals.',
        'scientific_source_or_producer_or_data_changed':False,
        'producer_or_source_extraction_repeated':False}
    target.write_text(json.dumps(record,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'amendment_sha256':sha(target),
        'original_verifier_sha256':digest,'corrected_verifier_sha256':sha(HERE/'verify_saved_magnetic.py')},indent=2))


if __name__ == '__main__':
    main()
