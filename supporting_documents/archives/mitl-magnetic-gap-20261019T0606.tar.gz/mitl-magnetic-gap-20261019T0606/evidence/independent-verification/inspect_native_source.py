"""Independent read-only source extraction for the new magnetic-gap panels."""
import hashlib
import json
from pathlib import Path

import fitz
from PIL import Image

HERE = Path(__file__).resolve().parent
SOURCE = Path('/workspace/research_sources/smtrevor_1.pdf')
PDF_SHA = '1d7b1f9c191a37e94f1cc3634587750f1af35b07eb13e0b94c60f3da47495ed7'
FIGURES = (
    ('4.28', 118, 2847, '934979de84040dc7970be53747773d2f8c78fedad9ac2b7116757a8052449103',
     '458b3ced8db4501db3fcbcc90939ce5f336a7ec83eb97ee259c66f7112bf07c8'),
    ('4.29', 120, 2870, '17080e390125995d993f2fa580e2fcef6cf4cb166a267bf08a9e1a9798a8d43e',
     'ac25b035329213a8d0a354b8496b1674c2be24ceaeff65d95a48ef2e6376b34f'),
)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    output = HERE/'native-source'
    if output.exists():
        raise RuntimeError('refuse to repeat source extraction over prior output')
    assert sha(SOURCE.read_bytes()) == PDF_SHA
    output.mkdir()
    records = []
    with fitz.open(SOURCE) as doc:
        for figure, page_index, xref, page_sha, rgb_sha in FIGURES:
            page = doc[page_index]
            content = page.read_contents()
            assert sha(content) == page_sha
            pixmap = fitz.Pixmap(doc, xref)
            assert pixmap.n == 3 and pixmap.width == pixmap.height == 975
            pixels = pixmap.samples
            assert sha(pixels) == rgb_sha
            image = Image.frombytes('RGB', (pixmap.width, pixmap.height), pixels)
            stem = 'figure_'+figure.replace('.', '_')
            image.save(output/(stem+'_native.png'))
            image.crop((485, 0, 975, 490)).resize((980, 980)).save(output/(stem+'_magnetic_inspection.png'))
            (output/(stem+'_page_text.txt')).write_text(page.get_text())
            records.append({'figure': figure, 'PDF_page_index': page_index, 'image_xref': xref,
                'page_content_sha256': page_sha, 'RGB_sha256': rgb_sha,
                'native_image': stem+'_native.png', 'native_PNG_sha256': sha((output/(stem+'_native.png')).read_bytes()),
                'page_text_sha256': sha((output/(stem+'_page_text.txt')).read_bytes())})
    record = {'schema': 'mitl-independent-magnetic-native-source-inspection-v1',
        'source_pdf_sha256': PDF_SHA, 'figures': records,
        'source_extractions': 1, 'producer_imports_or_calls': [],
        'new_panel_visual_assessment_pending': True}
    (output/'identity.json').write_text(json.dumps(record, indent=2)+'\n')
    print(json.dumps(record, indent=2))


if __name__ == '__main__':
    main()
