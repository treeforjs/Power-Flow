"""Freeze code, independent native inputs and final saved-output bytes only."""
import datetime
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
WORK = HERE.parent
REPO = Path('/workspace/Power-Flow')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    target = HERE/'before_readback_freeze.json'
    if target.exists() or (HERE/'readback.json').exists():
        raise RuntimeError('refuse repeated freeze or post-readback freeze')
    own = ['verify_saved_magnetic.py','readback_plan.json','source_assessment.json','method.md',
        'freeze_saved_readback.py','inspect_native_source.py','native-source/identity.json',
        'native-source/figure_4_28_native.png','native-source/figure_4_29_native.png']
    public = ['tools/recover_dissertation_gap_magnetic.py']
    artifacts = []
    for suffix in ('4_28','4_29'):
        stem = 'figure_'+suffix+'_magnetic_gap'
        public.extend(['data/dissertation/'+stem+'.csv','data/dissertation/'+stem+'.json'])
        metadata = json.loads((REPO/'data/dissertation'/(stem+'.json')).read_text())
        output = metadata['output']
        for name in [output['source_geometry_filename'],*output['QA_files_sha256']]:
            matches = list((WORK/'recovery').rglob(name))
            assert len(matches) == 1, (name,matches)
            artifacts.append(matches[0])
    record = {'schema':'mitl-independent-magnetic-before-readback-freeze-v1',
        'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'independent_code_and_input_sha256':{name:sha(HERE/name) for name in own},
        'public_source_sha256':{name:sha(REPO/name) for name in public},
        'saved_work_artifact_sha256':{str(path):sha(path) for path in artifacts},
        'independent_saved_output_readback_runs_before_freeze':0,
        'producer_imports_or_calls':[],
        'limits':'This step hashes declarations and saved bytes; it does not evaluate calibration, pixel catalogs, CSV values or any producer/model.'}
    target.write_text(json.dumps(record,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'freeze':str(target),'sha256':sha(target),
        'public_files':len(public),'work_artifacts':len(artifacts)},indent=2))


if __name__ == '__main__':
    main()
