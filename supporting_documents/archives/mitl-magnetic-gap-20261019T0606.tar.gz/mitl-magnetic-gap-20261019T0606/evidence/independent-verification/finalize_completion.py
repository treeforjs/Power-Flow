"""Bind a saved readback and recorded execution without repeating its checks."""
import datetime
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
WORK = HERE.parent
REPO = Path('/workspace/Power-Flow')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    target = HERE/'completion.json'
    if target.exists():
        raise RuntimeError('refuse to replace independent completion')
    report_path = HERE/'readback.json'
    report = json.loads(report_path.read_text())
    assert report['schema'] == 'mitl-independent-magnetic-gap-readback-v1'
    assert report['status'] == 'passed' and report['all_checks_passed'] is True
    counts = {'figures':2,'profiles':4,'retained_rows':524,'excluded_rows':1048,
        'native_rows_catalogued':1572,'numeric_csv_cells_checked':7860,'tick_anchors_checked':18}
    assert all(report[key] == value for key,value in counts.items())
    for path,digest in report['input_sha256'].items():
        assert sha(path) == digest
    for path,digest in report['public_source_sha256'].items():
        assert sha(REPO/path) == digest
    executions = [json.loads(line) for line in (WORK/'commands.jsonl').read_text().splitlines()]
    readbacks = [row for row in executions if Path(row['log']).name in (
        'independent-magnetic-saved-readback.log','independent-magnetic-saved-readback-corrected.log')]
    assert len(readbacks) == 2 and [row['exit_code'] for row in readbacks] == [1,0]
    for row in readbacks:
        assert sha(row['log']) == row['log_sha256']
    artifacts = ['inspect_native_source.py','native-source/identity.json','tick-inspection.json',
        'source_assessment.json','readback_plan.json','method.md','routine-read-notes.json','verify_saved_magnetic.py',
        'freeze_saved_readback.py','before_readback_freeze.json','readback_freeze_amendment.json',
        'verify_saved_magnetic.initial.py','readback_correction.md','prepare_readback_correction.py',
        'readback.json','finalize_completion.py']
    record = {'schema':'mitl-independent-magnetic-gap-completion-v1','status':'passed',
        'all_checks_passed':True,'completed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        **counts,'readback':'independent-verification/readback.json','readback_sha256':sha(report_path),
        'public_source_sha256':report['public_source_sha256'],
        'artifact_sha256':{str((HERE/name).relative_to(WORK)):sha(HERE/name) for name in artifacts},
        'artifact_map_base':'work_directory','public_map_base':'repository',
        'independent_saved_output_readback_attempts':2,
        'completed_saved_output_readback_passes':1,
        'initial_schema_declaration_failure_preserved':True,
        'producer_imports_or_calls':[], 'successful_producer_replays':0,
        'old_suites_repeated':False,'old_recoveries_repeated':False,
        'complete_retained_excluded_catalog_verified':True,
        'signed_literal_values_preserved':True,'literal_conditional_tesla_conversion_only':True,
        'both_signed_gap_coordinate_halves_preserved':True,
        'zero_gap_or_endpoint_inserted':False,
        'physical_normalization_verified':False,'physical_field_uncertainty_established':False,
        'field_derivative_current_heating_or_Hall_inferred':False,
        'actual_FLASH_or_host_result':False,
        'command_records':readbacks,
        'limits':report['limits']}
    target.write_text(json.dumps(record,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'completion':str(target),'sha256':sha(target),'readback_sha256':sha(report_path),**counts},indent=2))


if __name__ == '__main__':
    main()
