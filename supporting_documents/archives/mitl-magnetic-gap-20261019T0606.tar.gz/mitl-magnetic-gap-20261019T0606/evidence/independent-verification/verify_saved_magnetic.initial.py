"""Independent native-pixel/Fraction readback; never imports the producer."""
import csv
from fractions import Fraction as F
import hashlib
import json
from pathlib import Path

from PIL import Image

HERE = Path(__file__).resolve().parent
WORK = HERE.parent
REPO = Path('/workspace/Power-Flow')
PLAN = HERE/'readback_plan.json'
COLORS = {'foil_edge': (255,105,180), 'foil_middle': (186,85,211)}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def same(actual, expected):
    assert type(actual) is type(expected), (actual, expected)
    if isinstance(expected, float):
        assert actual.hex() == expected.hex(), (actual, expected)
    elif isinstance(expected, list):
        assert len(actual) == len(expected)
        for a, e in zip(actual, expected):
            same(a,e)
    elif isinstance(expected, dict):
        assert actual.keys() == expected.keys()
        for key in expected:
            same(actual[key],expected[key])
    else:
        assert actual == expected, (actual, expected)


def grouped(indices):
    result = []
    for index in indices:
        if result and index == result[-1][-1]+1:
            result[-1].append(index)
        else:
            result.append([index])
    return [[run[0], run[-1]] for run in result]


def fit(pixel, value):
    n = len(pixel)
    sx, sy = sum(pixel), sum(value)
    slope = (n*sum(x*y for x,y in zip(pixel,value))-sx*sy)/(n*sum(x*x for x in pixel)-sx*sx)
    intercept = (sy-slope*sx)/n
    residuals = [slope*x+intercept-y for x,y in zip(pixel,value)]
    return {'pixels':pixel, 'values':value, 'slope':slope, 'intercept':intercept,
        'residuals':residuals, 'maximum_residual':max(map(abs,residuals))}


def native_axis(pixels, spec, horizontal):
    if horizontal:
        a,b = spec['x_inclusive']
        runs = grouped(x for x in range(a,b+1) if max(pixels[x,spec['tail_row']]) < spec['dark_threshold_exclusive'])
    else:
        a,b = spec['y_inclusive']
        runs = grouped(y for y in range(a,b+1) if max(pixels[spec['tail_column'],y]) < spec['dark_threshold_exclusive'])
    assert runs == spec['expected_runs']
    return fit([F(a+b,2) for a,b in runs], [F(x) for x in spec['printed_values']])


def expected_figure(image, plan):
    pixels = image.load()
    magnetic = native_axis(pixels,plan['magnetic_tick_detection'],True)
    gap = native_axis(pixels,plan['gap_tick_detection'],False)
    x0,x1 = plan['panel_x_inclusive']
    y0,y1 = plan['candidate_y_inclusive']
    k0,k1 = plan['retained_y_inclusive']
    catalogs = {}
    values = {}
    for profile,color in COLORS.items():
        catalogs[profile] = []
        for y in range(y0,y1+1):
            runs = grouped(x for x in range(x0,x1+1) if pixels[x,y] == color)
            supported = len(runs)==1 and 2 <= runs[0][1]-runs[0][0]+1 <= 8 and runs[0][0]>x0 and runs[0][1]<x1
            keep = k0 <= y <= k1 and supported
            if not k0 <= y <= k1:
                reason = plan['outside_primary_reason']
            elif len(runs) != 1:
                reason = 'ambiguous_or_missing_exact_colour_run'
            elif not supported:
                reason = 'unsupported_run_width_or_ROI_contact'
            else:
                reason = 'retained'
            catalogs[profile].append({'pixel_y':y,'exact_colour_runs_inclusive_x':runs,'reason':reason,'retained':keep})
            if keep:
                first,last = runs[0]
                centre = F(first+last,2)
                literal = magnetic['slope']*centre+magnetic['intercept']
                low = magnetic['slope']*(first-2)+magnetic['intercept']-magnetic['maximum_residual']
                high = magnetic['slope']*(last+2)+magnetic['intercept']+magnetic['maximum_residual']
                gap_value = gap['slope']*y+gap['intercept']
                gap_low = min(gap['slope']*(y-2)+gap['intercept'],gap['slope']*(y+2)+gap['intercept'])-gap['maximum_residual']
                gap_high = max(gap['slope']*(y-2)+gap['intercept'],gap['slope']*(y+2)+gap['intercept'])+gap['maximum_residual']
                values[profile,y] = {
                    'pixel_y':y,'pixel_x_median':centre,'run_first_pixel_x':first,'run_last_pixel_x':last,
                    'matched_color_pixels':last-first+1,'gap_coordinate_mm':gap_value,
                    'gap_coordinate_readout_lower_mm':gap_low,'gap_coordinate_readout_upper_mm':gap_high,
                    'Bx_literal_axis_value':literal,'Bx_literal_readout_lower_axis_value':low,
                    'Bx_literal_readout_upper_axis_value':high,'Bx_literal_conditional_T':100*literal,
                    'Bx_literal_conditional_readout_lower_T':100*low,'Bx_literal_conditional_readout_upper_T':100*high}
    return magnetic,gap,catalogs,values


def check_axis(actual, expected):
    same(actual['tick_pixel_centres'], [float(x) for x in expected['pixels']])
    same(actual['tick_values'], [float(x) for x in expected['values']])
    for key in ('slope','intercept'):
        same(actual[key],float(expected[key]))
        same(actual[key+'_exact'],[str(expected[key].numerator),str(expected[key].denominator)])
    same(actual['tick_residuals'],[float(x) for x in expected['residuals']])
    same(actual['tick_residuals_exact'],[[str(x.numerator),str(x.denominator)] for x in expected['residuals']])
    same(actual['max_abs_tick_residual'],float(expected['maximum_residual']))
    same(actual['max_abs_tick_residual_exact'],[str(expected['maximum_residual'].numerator),str(expected['maximum_residual'].denominator)])


def context(y):
    if y <= 23:
        return 'upper_frame_margin_excluded'
    if y <= 85:
        return 'upper_legend_margin_excluded'
    if y <= 149:
        return 'upper_outer_crossing_jump_margin_excluded'
    if y <= 280:
        return 'central_gap_support'
    if y <= 329:
        return 'lower_crossing_jump_margin_excluded'
    return 'lower_outer_frame_support_excluded'


def check_catalog(actual, expected):
    assert set(actual) == {'RGB','retained_rows','excluded_rows','retained_count','excluded_count','catalogued_row_count','_profile'}
    same(actual['RGB'],list(COLORS[actual['_profile']]))
    by_y = {}
    for label in ('retained_rows','excluded_rows'):
        rows = actual[label]
        assert [row['pixel_y'] for row in rows] == sorted((row['pixel_y'] for row in rows),reverse=True)
        for row in rows:
            assert set(row) == {'pixel_y','exact_colour_runs_inclusive_x','reason','display_context'}
            y = row['pixel_y']
            assert type(y) is int and y not in by_y
            by_y[y] = (row,label)
    assert set(by_y) == {row['pixel_y'] for row in expected}
    for row in expected:
        actual_row,label = by_y[row['pixel_y']]
        same(actual_row['exact_colour_runs_inclusive_x'],row['exact_colour_runs_inclusive_x'])
        same(actual_row['reason'],row['reason'])
        same(actual_row['display_context'],context(row['pixel_y']))
        assert label == ('retained_rows' if row['retained'] else 'excluded_rows')
    same(actual['retained_count'],131)
    same(actual['excluded_count'],262)
    same(actual['catalogued_row_count'],393)


def find_work_artifact(name):
    matches = list((WORK/'recovery').rglob(name))
    assert len(matches) == 1, (name,matches)
    return matches[0]


def main():
    target = HERE/'readback.json'
    if target.exists():
        raise RuntimeError('refuse repeated saved-output readback')
    frozen = load(HERE/'before_readback_freeze.json')
    for name,digest in frozen['independent_code_and_input_sha256'].items():
        assert sha(HERE/name) == digest
    for name,digest in frozen['public_source_sha256'].items():
        assert sha(REPO/name) == digest
    for name,digest in frozen['saved_work_artifact_sha256'].items():
        assert sha(name) == digest
    same(frozen['independent_saved_output_readback_runs_before_freeze'],0)
    plan = load(PLAN)
    identity = load(HERE/'native-source/identity.json')
    columns = ['figure','profile','time_s','pixel_y','pixel_x_median','run_first_pixel_x',
        'run_last_pixel_x','matched_color_pixels','gap_coordinate_mm','gap_coordinate_readout_lower_mm',
        'gap_coordinate_readout_upper_mm','Bx_literal_axis_value','Bx_literal_readout_lower_axis_value',
        'Bx_literal_readout_upper_axis_value','Bx_literal_conditional_T',
        'Bx_literal_conditional_readout_lower_T','Bx_literal_conditional_readout_upper_T']
    results = []
    input_sha256 = {str(HERE/name):digest for name,digest in frozen['independent_code_and_input_sha256'].items()}
    input_sha256.update(frozen['saved_work_artifact_sha256'])
    for source in identity['figures']:
        figure = source['figure']
        stem = 'figure_'+figure.replace('.','_')+'_magnetic_gap'
        csv_path = REPO/'data/dissertation'/(stem+'.csv')
        metadata_path = REPO/'data/dissertation'/(stem+'.json')
        metadata = load(metadata_path)
        same(metadata['schema'],'mhdlab-dissertation-magnetic-gap-recovery-v1')
        source_meta = metadata['source']
        nominal_time = 40e-9 if figure == '4.28' else 60e-9
        printed_page = 94 if figure == '4.28' else 96
        same(source_meta['figure'],figure)
        same(source_meta['pdf_sha256'],identity['source_pdf_sha256'])
        same(source_meta['pdf_page_index'],source['PDF_page_index'])
        same(source_meta['embedded_image_xref'],source['image_xref'])
        same(source_meta['page_content_sha256'],source['page_content_sha256'])
        same(source_meta['decoded_RGB_pixels_sha256'],source['RGB_sha256'])
        same(source_meta['printed_page'],printed_page)
        same(source_meta['pdf_page'],source['PDF_page_index']+1)
        same(source_meta['native_image_size_pixels'],[975,975])
        same(source_meta['native_image_mode'],'RGB')
        assert ('40 ns' if figure == '4.28' else '60 ns') in source_meta['page_text']
        assert 'Allegra' in source_meta['page_text'] and '17133' in source_meta['page_text']
        simulation = metadata['simulation_context']
        same(simulation['code_label_in_dissertation'],'Allegra')
        same(simulation['drive_shot_caption_label'],17133)
        same(simulation['caption_snapshot_time_s'],nominal_time)
        for name in ('experimental_measurement','FLASH_result','actual_material_boundaries_recovered',
                'full_vector_field_recovered','experimental_clock_alignment_established'):
            same(simulation[name],False)
        units = metadata['unit_interpretation']
        same(units['source_magnetic_axis_label'],'B_x [100 Tesla]')
        same(units['source_gap_axis_label'],'Distance from Middle of AK Gap [mm]')
        same(units['literal_conditional_scale_to_T'],100)
        same(units['component_signs_preserved'],True)
        for name in ('original_electromagnetic_normalization_verified','original_simulation_output_units_confirmed',
                'normalization_or_legend_error_resolved','unit_repair_or_empirical_rescaling_applied',
                'coordinate_frame_rotation_applied'):
            same(units[name],False)
        image = Image.open(HERE/'native-source'/source['native_image'])
        assert image.mode == 'RGB' and list(image.size) == plan['native_size']
        assert hashlib.sha256(image.tobytes()).hexdigest() == source['RGB_sha256']
        magnetic,gap,catalogs,values = expected_figure(image,plan)
        check_axis(metadata['calibration']['magnetic'],magnetic)
        check_axis(metadata['calibration']['gap'],gap)
        detection = metadata['calibration']['tick_detection']
        same(detection['dark_channel_threshold_exclusive'],128)
        same(detection['magnetic_tick_tail_row'],418)
        same(detection['gap_tick_tail_column'],561)
        selection = metadata['selection']
        same(selection['panel_ROI_inclusive'],{'x':[570,957],'y':[19,411]})
        same(selection['retained_central_y_inclusive'],[150,280])
        same(selection['row_stride'],1)
        for name in ('interpolation','smoothing','extrapolation','surface_or_endpoint_padding','symmetry_imposed'):
            same(selection[name],False)
        assert set(selection['profiles']) == set(COLORS)
        for profile in COLORS:
            check_catalog(dict(selection['profiles'][profile],_profile=profile),catalogs[profile])
        same(metadata['readout_bounds']['additional_pixel_readout_half_width'],2)
        same(metadata['readout_bounds']['correlated_display_bounds_only'],True)
        same(metadata['readout_bounds']['independent_noise_or_confidence_interval'],False)
        same(metadata['readout_bounds']['physical_or_simulation_uncertainty_quantified'],False)
        output = metadata['output']
        same(output['csv_filename'],csv_path.name)
        same(output['csv_sha256'],sha(csv_path))
        same(output['generator'],'tools/recover_dissertation_gap_magnetic.py')
        same(output['generator_sha256'],frozen['public_source_sha256']['tools/recover_dissertation_gap_magnetic.py'])
        same(output['samples'],262)
        same(output['samples_by_profile'],{'foil_edge':131,'foil_middle':131})
        same(output['columns'],columns)
        same(output['gap_coordinate_extent_mm'],[float(min(v['gap_coordinate_mm'] for v in values.values())),
            float(max(v['gap_coordinate_mm'] for v in values.values()))])
        same(output['signed_Bx_literal_extent_by_profile'],{profile:[
            float(min(v['Bx_literal_axis_value'] for (p,y),v in values.items() if p==profile)),
            float(max(v['Bx_literal_axis_value'] for (p,y),v in values.items() if p==profile))] for profile in COLORS})
        geometry_path = find_work_artifact(output['source_geometry_filename'])
        same(output['source_geometry_sha256'],sha(geometry_path))
        geometry = load(geometry_path)
        same(geometry['schema'],'mhdlab-magnetic-gap-source-geometry-v1')
        same(geometry['figure'],{'figure':figure,'page_index':source['PDF_page_index'],'printed_page':printed_page,
            'xref':source['image_xref'],'time_s':nominal_time,'rgb_sha256':source['RGB_sha256'],
            'reference_png_sha256':source_meta['reference_extracted_PNG_sha256'],
            'page_content_sha256':source['page_content_sha256']})
        same(geometry['calibration'],{key:metadata['calibration'][key] for key in ('magnetic','gap')})
        same(geometry['profiles'],selection['profiles'])
        for name,digest in output['QA_files_sha256'].items():
            same(sha(find_work_artifact(name)),digest)
        with csv_path.open(newline='') as stream:
            reader = csv.DictReader(stream)
            assert reader.fieldnames == columns
            rows = list(reader)
        assert len(rows) == 262 and len(values) == 262
        used = set()
        previous_gap = {}
        for row in rows:
            same(row['figure'],figure)
            profile = row['profile']
            y = int(row['pixel_y'])
            key = profile,y
            assert key in values and key not in used
            used.add(key)
            expected = dict(values[key],time_s=nominal_time)
            for name,value in expected.items():
                same(row[name],format(float(value),'.12g'))
            assert expected['Bx_literal_axis_value'] < 0
            gap_value = expected['gap_coordinate_mm']
            assert gap_value != 0
            if profile in previous_gap:
                assert gap_value > previous_gap[profile]
            previous_gap[profile] = gap_value
        assert used == set(values)
        input_sha256[str(metadata_path)] = sha(metadata_path)
        input_sha256[str(csv_path)] = sha(csv_path)
        results.append({'figure':figure,'profiles':2,'retained_rows':262,'excluded_rows':524,
            'native_rows_catalogued':786,'numeric_csv_cells_checked':len(rows)*15,
            'tick_anchors_checked':9,'signed_literal_min':float(min(v['Bx_literal_axis_value'] for v in values.values())),
            'signed_literal_max':float(max(v['Bx_literal_axis_value'] for v in values.values())),
            'gap_min_mm':float(min(v['gap_coordinate_mm'] for v in values.values())),
            'gap_max_mm':float(max(v['gap_coordinate_mm'] for v in values.values())),
            'csv_sha256':sha(csv_path),'metadata_sha256':sha(metadata_path),
            'source_geometry_sha256':sha(geometry_path)})
    record = {'schema':'mitl-independent-magnetic-gap-readback-v1','status':'passed','all_checks_passed':True,
        'figures':2,'profiles':4,'retained_rows':sum(row['retained_rows'] for row in results),
        'excluded_rows':sum(row['excluded_rows'] for row in results),
        'native_rows_catalogued':sum(row['native_rows_catalogued'] for row in results),
        'numeric_csv_cells_checked':sum(row['numeric_csv_cells_checked'] for row in results),
        'tick_anchors_checked':sum(row['tick_anchors_checked'] for row in results),
        'figure_results':results,'public_source_sha256':frozen['public_source_sha256'],
        'input_sha256':input_sha256,'producer_imports_or_calls':[],
        'successful_producer_replays':0,'old_suites_repeated':False,'old_recoveries_repeated':False,
        'calibration_method':'Exact Fraction OLS from independently detected dark pixel tick runs and literal printed decimal values.',
        'numeric_csv_rule':'Every numeric token equals the independent exact-Fraction result converted once to float and formatted .12g.',
        'limits':['Published legacy Allegra simulation raster only; nominal40/60ns snapshots are not experimentally registered times.',
            'Literal signed B_x and factor100 conditional tesla columns do not verify original normalization.',
            'Conservative central support only; all outer/crossing/jump/legend rows are explicitly excluded.',
            'Pixel/readout bounds are correlated display bounds, not physical uncertainty or independent observations.',
            'No inferred material boundary, derivative, skin depth, current, heating, field energy, Hall transport, FLASH result or host acceptance.']}
    assert record['retained_rows'] == 524 and record['excluded_rows'] == 1048
    assert record['native_rows_catalogued'] == 1572 and record['numeric_csv_cells_checked'] == 7860
    assert record['tick_anchors_checked'] == 18
    target.write_text(json.dumps(record,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'readback':str(target),'sha256':sha(target),
        **{key:record[key] for key in ('figures','profiles','retained_rows','excluded_rows','native_rows_catalogued','numeric_csv_cells_checked','tick_anchors_checked')}},indent=2))


if __name__ == '__main__':
    main()
