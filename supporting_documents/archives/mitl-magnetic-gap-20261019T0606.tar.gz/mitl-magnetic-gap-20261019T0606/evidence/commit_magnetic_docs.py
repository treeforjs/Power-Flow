"""Commit reviewed recovery associations and bounded scientific interpretation."""
import hashlib
import json
from pathlib import Path
import subprocess

repo=Path('/workspace/Power-Flow')
work=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def run(*args):
    print(json.dumps(list(args)),flush=True)
    subprocess.run(args,cwd=repo,check=True)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()=='7141a34158d9fee565df5d617816c7e34ab3cbc8'
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=repo,text=True)
assert sha(work/'documentation-association.json')=='eb2a58f3d6c76b7a84eee9b73423e2afcd226310feb49dc7fb4acc114379ef92'
record=json.loads((work/'documentation-association.json').read_text())
assert record['status']=='passed' and len(record['public_sha256'])==9
assert all(sha(repo/name)==digest for name,digest in record['public_sha256'].items())
paths=['docs/dissertation_gap_magnetic_recovery.md','docs/dissertation_recovery.md',
 'docs/dissertation_current_depth_recovery.md','data/dissertation/recovery_manifest.yaml']
run('git','add','--',*paths)
run('git','diff','--cached','--check')
run('git','-c','user.name=Research Development','-c','user.email=research@local.invalid',
 'commit','-m','Associate magnetic-gap recovery with source evidence and scientific limits')
run('git','show','--format=fuller','--stat','HEAD')
run('git','status','--short')
