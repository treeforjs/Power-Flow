"""Freeze saved magnetic-gap recovery evidence without replaying source extraction."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tarfile

from prepare_delivery import (WORK, REPO, BASE, OUT, PDF_SHA256, PUBLIC, WRAPPERS, PRODUCER,
    clean_head, command_snapshot_prefix, dataset_bindings, load, loads, save, sha)

TEXT_SUFFIXES = {'.py', '.json', '.jsonl', '.log', '.xml', '.md', '.txt', '.patch', '.sha256', '.yaml', '.csv'}
EVIDENCE_DIRS = ('recovery', 'independent-verification', 'guards', 'scientific-review', 'next-upstream-selection',
    'delivery-preparation', 'completion-preparation')
REPORT_PATHS = {
    'author_verification': 'recovery/author-verification.json',
    'independent_completion': 'independent-verification/completion.json',
    'guard_completion': 'guards/completion.json',
    'scientific_review': 'scientific-review/completion.json',
    'manifest_association': 'manifest-association.json',
    'documentation_association': 'documentation-association.json',
    'visual_review': 'visual-review.json',
    'selection': 'next-upstream-selection/selection.json',
}
PROJECTIONS = (
    (bytes.fromhex('2f6f70742f636f6465782f72756e74696d65732f636f6465782d7072696d6172792d72756e74696d652f646570656e64656e636965732f707974686f6e'), b'[runtime Python directory]'),
    (bytes.fromhex('2f6574632f636f6465782f'), b'[runtime policy directory]/'),
)


def excluded(relative, allowed_figures=()):
    path = Path(relative)
    if 'delivery-preparation' in path.parts and 'payload' in path.parts:
        return True
    if any(part in {'__pycache__', '.pytest_cache', '.venv', 'source-local', 'fulltexts', 'raw-fulltexts', 'raw',
                    'pytest-temp', 'pytest-tmp', 'test-fixtures', 'fixtures'} or part.startswith('pytest_')
           for part in path.parts):
        return True
    if path.suffix == '.pyc' or path.name == 'smtrevor_1.pdf':
        return True
    if path.suffix.lower() in {'.npy', '.npz', '.rgb', '.raw', '.bin'}:
        return True
    if 'native-source' in path.parts and path.suffix not in TEXT_SUFFIXES:
        return True
    if path.suffix.lower() in {'.png', '.pdf', '.jpg', '.jpeg', '.tif', '.tiff'}:
        return path.as_posix() not in set(allowed_figures)
    return False


def verify_contracts(records, datasets, *, work_sha=None, public_sha=None, work_bytes=None):
    """Check frozen JSON/CSV/hash declarations only; no recovery or image parser."""
    h = work_sha or (lambda name: sha(WORK/name))
    p = public_sha or (lambda name: sha(REPO/name))
    b = work_bytes or (lambda name: (WORK/name).read_bytes())

    def artifacts(mapping, prefix=''):
        assert isinstance(mapping, dict) and mapping
        for name, digest in mapping.items():
            path = Path(name)
            assert not path.is_absolute() and '..' not in path.parts
            assert re.fullmatch('[0-9a-f]{64}', digest) and h(prefix+name) == digest

    def counts(record, expected):
        for key, value in expected.items():
            assert type(record[key]) is int and record[key] == value, key

    def work_relative(name):
        path = Path(name)
        return str(path.relative_to(WORK)) if path.is_absolute() else name

    public_recovery = {PRODUCER}|{item[key] for item in datasets for key in ('csv_path', 'metadata_path')}
    assert len(datasets) == 2 and sum(item['samples'] for item in datasets) == 524
    author = records['author_verification']
    assert author['schema'] == 'mhdlab-magnetic-gap-author-verification-v1' and author['complete'] is True
    assert author['public_source'] == PRODUCER and author['public_source_sha256'] == p(PRODUCER)
    assert set(author['public_files_sha256']) == public_recovery
    assert all(p(name) == digest for name, digest in author['public_files_sha256'].items())
    assert author['source_PDF_sha256'] == PDF_SHA256
    counts(author, {'new_positive_producer_run_count': 1, 'total_retained_samples': 524,
        'total_excluded_rows': 1048, 'total_catalogued_rows': 1572, 'samples_per_profile': 131,
        'excluded_per_profile': 262, 'catalogued_per_profile': 393})
    assert author['visual_QA']['both_generated_PNGs_viewed'] is True
    command = author['new_positive_producer_command']
    assert command['exit_code'] == 0 and h(work_relative(command['log'])) == command['log_sha256']
    assert h(work_relative(author['selection_freeze'])) == author['selection_freeze_sha256']
    selection_freeze = loads(b(work_relative(author['selection_freeze'])))
    assert selection_freeze['schema'] == 'mhdlab-magnetic-gap-recovery-selection-freeze-v1'
    assert selection_freeze['producer_sha256'] == p(PRODUCER)
    assert selection_freeze['positive_recovery_executed_before_freeze'] is False
    assert selection_freeze['normalization_verified'] is False
    allowed_figures = []
    assert len(author['figures']) == len(datasets)
    for record, dataset in zip(author['figures'], datasets):
        assert record['figure'] == dataset['figure'] and record['csv'] == dataset['csv_path']
        assert record['metadata'] == dataset['metadata_path']
        assert record['csv_sha256'] == dataset['csv_sha256'] and record['metadata_sha256'] == dataset['metadata_sha256']
        geometry = 'recovery/'+dataset['source_geometry_filename']
        assert work_relative(record['source_geometry']) == geometry
        assert h(geometry) == record['source_geometry_sha256'] == dataset['source_geometry_sha256']
        assert loads(b(geometry))['schema'] == author['source_geometry_schema'] == 'mhdlab-magnetic-gap-source-geometry-v1'
        assert record['QA_files_sha256'] == dataset['QA_files_sha256']
        from prepare_delivery import canonical_hash
        assert canonical_hash(record['calibration']) == dataset['calibration_sha256']
        artifacts(record['QA_files_sha256'], 'recovery/')
        allowed_figures.extend('recovery/'+name for name in record['QA_files_sha256'])
        for name, profile in dataset['profiles'].items():
            for key in ('samples', 'excluded_rows', 'catalogued_rows'):
                assert record['profiles'][name][key] == profile[key]
            assert record['profiles'][name]['all_primary_values_negative'] is True

    independent = records['independent_completion']
    assert independent['schema'] == 'mitl-independent-magnetic-gap-completion-v1'
    assert independent['status'] == 'passed' and independent['all_checks_passed'] is True
    science_counts = {'figures': 2, 'profiles': 4, 'retained_rows': 524, 'excluded_rows': 1048,
        'native_rows_catalogued': 1572, 'numeric_csv_cells_checked': 7860, 'tick_anchors_checked': 18}
    counts(independent, {**science_counts, 'independent_saved_output_readback_attempts': 2,
        'completed_saved_output_readback_passes': 1, 'successful_producer_replays': 0})
    assert independent['public_source_sha256'] == author['public_files_sha256']
    assert independent['producer_imports_or_calls'] == []
    assert independent['initial_schema_declaration_failure_preserved'] is True
    for key in ('complete_retained_excluded_catalog_verified', 'signed_literal_values_preserved',
                'literal_conditional_tesla_conversion_only', 'both_signed_gap_coordinate_halves_preserved'):
        assert independent[key] is True
    for key in ('old_suites_repeated', 'old_recoveries_repeated', 'zero_gap_or_endpoint_inserted',
                'physical_normalization_verified', 'physical_field_uncertainty_established',
                'field_derivative_current_heating_or_Hall_inferred', 'actual_FLASH_or_host_result'):
        assert independent[key] is False
    artifacts(independent['artifact_sha256'])
    assert h(independent['readback']) == independent['readback_sha256']
    readback = loads(b(independent['readback']))
    assert readback['schema'] == 'mitl-independent-magnetic-gap-readback-v1'
    assert readback['status'] == 'passed' and readback['all_checks_passed'] is True
    counts(readback, {**science_counts, 'readback_attempts': 2, 'completed_saved_output_readback_passes': 1,
        'successful_producer_replays': 0})
    assert readback['public_source_sha256'] == author['public_files_sha256']
    for name, digest in readback['input_sha256'].items():
        source = Path(name)
        if source.is_relative_to(REPO):
            assert p(str(source.relative_to(REPO))) == digest
        else:
            assert h(work_relative(name)) == digest
    amendment = loads(b('independent-verification/readback_freeze_amendment.json'))
    assert amendment['schema'] == 'mitl-independent-magnetic-readback-freeze-amendment-v1'
    assert amendment['original_freeze_sha256'] == h('independent-verification/before_readback_freeze.json')
    assert amendment['original_verifier_sha256'] == h('independent-verification/'+amendment['original_verifier_file'])
    assert amendment['corrected_verifier_sha256'] == h('independent-verification/verify_saved_magnetic.py')
    assert amendment['scientific_source_or_producer_or_data_changed'] is False
    assert amendment['producer_or_source_extraction_repeated'] is False
    assert [item['exit_code'] for item in independent['command_records']] == [1, 0]
    for item in independent['command_records']:
        assert h(work_relative(item['log'])) == item['log_sha256']

    guards = records['guard_completion']
    assert guards['schema'] == 'mitl-magnetic-gap-source-guards-v1'
    assert guards['status'] == 'passed' and guards['all_checks_passed'] is True
    counts(guards, {'meaningful_invalid_controls': 4, 'controls_rejected': 4, 'guard_run_count': 1,
        'source_identity_recover_calls': 2, 'tick_mask_validation_calls': 1, 'synthetic_selection_calls': 1,
        'successful_positive_producer_replays': 0, 'physical_curve_selection_reached': 0})
    assert guards['source_pdf_sha256'] == PDF_SHA256 and guards['source_sha256'] == {PRODUCER: p(PRODUCER)}
    assert guards['status_before_sha256'] == guards['status_after_sha256']
    for key in ('old_suites_or_producers_repeated', 'public_files_edited', 'status_or_lease_mutated',
                'physical_normalization_verified', 'host_or_owner_implementation_verified'):
        assert guards[key] is False
    assert len(guards['outcomes']) == 4 and all(item['rejected'] is True for item in guards['outcomes'])
    artifacts(guards['artifact_sha256'])

    review = records['scientific_review']
    assert review['schema'] == 'mitl-magnetic-gap-scientific-review-v1'
    assert review['status'] == 'review_complete_no_substantive_issue_identified' and review['findings'] == []
    assert review['reviewed_source_sha256'] == p(PRODUCER)
    assert all(p(name) == digest for name, digest in review['new_public_output_sha256'].items())
    assert review['author_verification_association']['sha256'] == h(REPORT_PATHS['author_verification'])
    assert review['independent_verification_association']['sha256'] == independent['readback_sha256']
    for key in ('source_or_data_changes_requested', 'axis_fit_or_curve_digitization_by_reviewer',
                'positive_producer_or_model_executed', 'old_producer_suite_or_source_audit_repeated',
                'physical_normalization_or_uncertainty_established', 'Hall_magnetization_or_host_field_acceptance'):
        assert review[key] is False
    artifacts(review['QA_artifact_sha256'])
    artifacts(review['artifact_sha256'], 'scientific-review/')
    manifest = records['manifest_association']
    assert manifest['schema'] == 'mitl-magnetic-gap-manifest-association-v1' and manifest['status'] == 'passed'
    assert manifest['manifest_after_sha256'] == p('data/dissertation/recovery_manifest.yaml')
    assert manifest['only_figure_artifact_and_pending_associations_changed'] is True
    assert manifest['old_scientific_producers_or_tests_executed'] is False
    for dataset in datasets:
        entry = manifest['figure_artifacts']['fig_'+dataset['figure'].replace('.', '_')]
        assert entry['csv_sha256'] == dataset['csv_sha256'] and entry['metadata_sha256'] == dataset['metadata_sha256']
        assert entry['generator_sha256'] == p(PRODUCER)
        assert entry['original_electromagnetic_normalization_verified'] is False

    verify_root_reports(records, datasets, h, p, b, artifacts)
    results = {'figures': 2, 'profiles': 4, 'retained_rows': 524, 'excluded_rows': 1048,
        'native_rows_catalogued': 1572, 'numeric_csv_cells_checked': 7860, 'tick_anchors_checked': 18,
        'positive_source_recovery_runs': 1, 'independent_readback_attempts': 2,
        'completed_independent_readbacks': 1, 'initial_pre_cell_declaration_failure_preserved': True,
        'meaningful_invalid_source_controls': 4, 'source_controls_rejected': 4,
        'all_primary_signed_values_negative': True, 'both_signed_gap_coordinate_halves_preserved': True,
        'literal_conditional_tesla_conversion_only': True, 'independent_readback_passed': True,
        'physical_normalization_verified': False, 'physical_truth_validated': False,
        'field_derivative_current_heating_or_Hall_inferred': False, 'actual_FLASH_or_host_result': False,
        'packaging_source_recovery_repeated': False, 'old_recoveries_or_test_suites_repeated': False,
        'full_source_pdf_included': False, 'raw_source_images_or_pages_included': False,
        'portable_executions_performed': False, 'complete_baseline_checkout_required': True}
    return {'allowed_figure_paths': sorted(allowed_figures), 'results': results}


def verify_root_reports(records, datasets, h, p, b, artifacts):
    documentation = records['documentation_association']
    assert documentation['schema'] == 'mitl-magnetic-gap-documentation-association-v1'
    assert documentation['status'] == 'passed' and set(documentation['public_sha256']) == set(PUBLIC)
    assert all(p(name) == digest for name, digest in documentation['public_sha256'].items())
    artifacts(documentation['record_sha256'])
    assert documentation['manifest_only_new_artifacts_and_pending_changed'] is True
    assert documentation['new_source_guard_controls'] == 4 and documentation['new_positive_producer_runs'] == 1
    assert documentation['independent_complete_readbacks'] == 1
    assert documentation['initial_readback_failure_and_correction_preserved'] is True
    assert documentation['scientific_producers_tests_or_oracles_reexecuted'] is False
    assert documentation['physical_normalization_or_Hall_or_host_acceptance'] is False
    visual = records['visual_review']
    assert visual['schema'] == 'mitl-magnetic-gap-root-visual-review-v1' and visual['status'] == 'passed'
    assert visual['PNG_figures_actually_viewed_by_root'] == 2
    assert visual['replot_or_producer_execution_performed'] is False and visual['physical_normalization_accepted'] is False
    artifacts(visual['QA_artifact_sha256'])
    root_selection = loads(b('root-selection-review.json'))
    assert root_selection['schema'] == 'mitl-magnetic-gap-root-selection-review-v1'
    assert root_selection['status'] == 'reviewed_before_positive_recovery' and root_selection['visually_reviewed_by_root'] is True
    for key in ('physical_normalization_accepted', 'derivative_or_surface_field_accepted', 'scientific_execution'):
        assert root_selection[key] is False
    artifacts(root_selection['source_views_sha256'])
    selection = records['selection']
    assert selection['schema'] == 'mhdlab-next-upstream-selection-v1'
    assert selection['status'] == 'selected_after_current_scientific_acceptance'
    assert isinstance(selection['task'], str) and selection['task'].strip() == documentation['next_task']
    milestone_roles = {'author_verification': 'author_verification',
        'independent_verification': 'independent_completion', 'scientific_review': 'scientific_review'}
    for key, role in milestone_roles.items():
        assert selection['current_milestone'][key]['sha256'] == h(REPORT_PATHS[role])
    assert selection['next_task_controls']['fresh_lease_required_for_implementation'] is True
    assert selection['next_task_controls']['temperature_dependent_forced_IVP_still_unverified'] is True
    for key in ('new_source_parser_or_digitization_called', 'model_or_oracle_or_producer_called',
                'network_used', 'public_files_edited', 'separately_owned_solver_accessed'):
        assert selection['planning_activity'][key] is False
    proposal = str(Path(selection['bounded_plan']['path']).relative_to(WORK))
    assert h(proposal) == selection['bounded_plan']['sha256']
    completed = loads(b('next-upstream-selection/completion.json'))
    assert completed['schema'] == 'mhdlab-next-upstream-selection-completion-v1'
    assert completed['status'] == 'selected_after_scientific_acceptance'
    assert completed['selection_sha256'] == h(REPORT_PATHS['selection'])
    assert completed['proposal_sha256'] == h(proposal) and completed['open_substantive_findings'] == []
    for key in ('public_files_edited', 'physics_or_source_parsing_or_oracle_executed', 'network_used'):
        assert completed[key] is False


def main():
    payload = WORK/'delivery-preparation/payload'
    preparation = load(payload/'preparation.json')
    head = clean_head(preparation['source_commit'])
    assert preparation['base_commit'] == BASE and not OUT.exists() and not OUT.with_suffix('.tar.gz').exists()
    assert load(payload/'source_file_list.json') == {'byte_identical_public_files': list(PUBLIC), 'packaging_wrappers': list(WRAPPERS)}
    assert len(PUBLIC) == 9 and len(WRAPPERS) == 2
    assert {str(path.relative_to(payload/'source')) for path in (payload/'source').rglob('*') if path.is_file()} == set(PUBLIC)|set(WRAPPERS)
    assert not (payload/'source/mhdlab/__init__.py').exists()
    assert all((payload/'source'/name).read_bytes() == (REPO/name).read_bytes() for name in PUBLIC)
    datasets = dataset_bindings()
    assert datasets == preparation['datasets']
    records = {key: load(WORK/name) for key, name in REPORT_PATHS.items()}
    contract = verify_contracts(records, datasets)
    allowed_figures = contract['allowed_figure_paths']
    next_task = records['selection']['task']
    assert isinstance(next_task, str) and next_task.strip()
    shutil.copytree(payload, OUT)
    evidence = OUT/'evidence'
    evidence.mkdir()
    try:
        active_log = Path(os.readlink('/proc/self/fd/1')).resolve()
    except OSError:
        active_log = None
    copied_inputs, omissions, copied_root_files = [], [], []

    def copy(path, relative):
        assert not path.is_symlink()
        digest = sha(path)
        assert digest != PDF_SHA256
        target = evidence/relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, target)
        assert sha(target) == digest
        copied_inputs.append({'source': str(path), 'archive': str(target.relative_to(OUT)), 'sha256': digest})

    for path in WORK.iterdir():
        if path.is_file() and path.suffix in TEXT_SUFFIXES and path.resolve() != active_log:
            copy(path, Path(path.name))
            copied_root_files.append(path.name)
    for folder in EVIDENCE_DIRS:
        for path in (WORK/folder).rglob('*'):
            assert not path.is_symlink()
            if not path.is_file():
                continue
            relative = path.relative_to(WORK)
            if excluded(relative, allowed_figures) or sha(path) == PDF_SHA256:
                omissions.append({'path': str(relative), 'sha256': sha(path), 'bytes': path.stat().st_size,
                    'reason': 'Original PDF/native imagery, manufactured invalid binary fixture, cache or temporary data omitted; metadata/hash retained.'})
            else:
                copy(path, relative)
    commands_raw = (evidence/'commands.jsonl').read_bytes()
    snapshot = command_snapshot_prefix(commands_raw, (WORK/'commands.jsonl').read_bytes())
    helper_pins = {name: sha(WORK/name) for name in ('prepare_delivery.py', 'freeze_delivery.py', 'verify_delivery.py', 'complete_pass.py')}
    projections = []
    for path in evidence.rglob('*'):
        if not path.is_file() or path.suffix not in TEXT_SUFFIXES:
            continue
        for prefix, replacement in PROJECTIONS:
            data = path.read_bytes()
            if prefix in data:
                assert replacement not in data
                path.write_bytes(data.replace(prefix, replacement))
                projections.append({'path': str(path.relative_to(OUT)), 'original_sha256': hashlib.sha256(data).hexdigest(),
                    'portable_sha256': sha(path), 'replacements': data.count(prefix), 'source_prefix_hex': prefix.hex(),
                    'replacement': replacement.decode(), 'scope': 'Archive-only machine-directory projection; raw local bytes unchanged.'})
    save(OUT/'portable_path_projections.json', projections)
    save(OUT/'excluded_evidence.json', omissions)
    with (OUT/'magnetic-gap-recovery.patch').open('wb') as stream:
        subprocess.run(['git', 'diff', '--binary', BASE, head], cwd=REPO, stdout=stream, check=True)
    verification = {'schema': 'mitl-magnetic-gap-recovery-verification-v1',
        'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'source_commit': head, 'base_commit': BASE, 'datasets': datasets, 'results': contract['results'],
        'package_kind': 'patch_over_exact_complete_baseline', 'required_complete_baseline_checkout': True,
        'public_files_byte_identical': len(PUBLIC), 'packaging_wrappers': len(WRAPPERS),
        'records': records, 'record_paths': REPORT_PATHS,
        'record_sha256': {key: sha(WORK/name) for key, name in REPORT_PATHS.items()},
        'allowed_figure_paths': allowed_figures, 'copied_input_sha256': copied_inputs,
        'source_helper_sha256': helper_pins,
        'command_snapshot': {**snapshot, 'path': 'evidence/commands.jsonl',
            'copied_root_files': sorted(copied_root_files),
            'later_local_completion_repairs_may_exist': True,
            'historical_helper_policy': 'Archive helper bytes are immutable historical snapshots; any later local repair must explicitly bind them and preserve the original failure.'},
        'commits': subprocess.check_output(['git', 'log', '--reverse', '--format=%H %s', BASE+'..'+head], cwd=REPO, text=True).splitlines(),
        'next_task': next_task,
        'limits': ['Four coarse signed legacy Allegra gap profiles, with complete native row selection catalogs and finite display support.',
            'Printed electromagnetic units/normalization remain unverified; tesla conversion is conditional on the literal axis label.',
            'Display readout bounds are correlated, not physical uncertainty or independent noise.',
            'No derivative, skin depth, exact surface field, current/heating closure, Hall response, full vector fields or clock registration is inferred.',
            'The original PDF and native imagery are omitted with hashes; generated QA remains available.',
            'Nine-file patch requires the exact complete baseline. No recovery, old suite, scientific model or portable environment is replayed by packaging.']}
    save(OUT/'verification.json', verification)
    save(OUT/'next_task.json', {'task': next_task, 'selection_evidence': 'evidence/'+REPORT_PATHS['selection']})
    (OUT/'systems-mitl-magnetic-gap-recovery-10192026.md').write_text(f'''# Published signed magnetic-gap recovery

Nine public files are byte-identical to `{head}`. Apply the patch over the
complete checkout at `{BASE}`. Two wrappers supply the README and recovery
dependency list; there is no initializer workaround or portable execution claim.

The four coarse signed B_x profiles are published legacy Allegra gap panels at
40/60 ns. Original source identity, native geometry, axis/readout conventions,
full retained/excluded catalogs, generated QA, independent readback and actual
source guards are retained. The PDF/native pixels are omitted with recorded
hashes. Original electromagnetic normalization remains unverified, and literal
conditional tesla columns do not establish physical field input.

No field derivative, skin depth, exact surface boundary, current or heating
closure, Hall physics, clock alignment, experimental validation, FLASH output
or host acceptance is inferred. All packaging checks read saved bytes and
declarations; no recovery, prior scientific pass or numerical source is replayed.

Commands are an immutable complete-record byte prefix. Later verification and
completion commands may append locally. Archived helper files are historical
snapshots; any later repair must preserve its initial failure and bind the archived
hash explicitly. Reversible machine-directory projections leave raw local bytes
unchanged.

Next selected task: {next_task}
''')
    manifest = {str(path.relative_to(OUT)): sha(path) for path in OUT.rglob('*') if path.is_file() and path.name != 'manifest.sha256.json'}
    save(OUT/'manifest.sha256.json', manifest)
    words = [bytes.fromhex(value).decode() for value in ('6f70656e6169', '63686174677074', '636c61756465', '636f646578')]
    prohibited = re.compile(r'\b(?:'+'|'.join(words)+r')\b', re.I)
    allowed_archive_figures = {'evidence/'+name for name in allowed_figures}
    for path in OUT.rglob('*'):
        assert not path.is_symlink()
        if path.is_file():
            assert sha(path) != PDF_SHA256 and not excluded(path.relative_to(OUT), allowed_archive_figures)
            if path.suffix in TEXT_SUFFIXES:
                assert not prohibited.search(path.read_text()), str(path)
    clean_head(head)
    assert all(sha(REPO/name) == preparation['public_source_sha256'][name] for name in PUBLIC)
    assert all(sha(Path(item['source'])) == item['sha256'] for item in copied_inputs)
    assert all(sha(WORK/item['path']) == item['sha256'] for item in omissions)
    assert all(sha(WORK/name) == digest for name, digest in helper_pins.items())
    command_snapshot_prefix(commands_raw, (WORK/'commands.jsonl').read_bytes())
    archive = OUT.with_suffix('.tar.gz')
    with tarfile.open(archive, 'w:gz') as tar:
        tar.add(OUT, arcname=OUT.name)
    record = {'folder': str(OUT), 'archive': str(archive), 'sha256': sha(archive), 'bytes': archive.stat().st_size,
        'source_commit': head, 'base_commit': BASE, 'manifest_entries': len(manifest),
        'public_files_byte_identical': len(PUBLIC), 'packaging_wrappers': len(WRAPPERS),
        'manifest_sha256': sha(OUT/'manifest.sha256.json'), 'verification_sha256': sha(OUT/'verification.json')}
    save(WORK/'frozen_delivery.json', record)
    print(json.dumps(record, indent=2))


if __name__ == '__main__':
    main()
