"""Record a pre-production mathematical/fixture/threshold plan review only."""
import datetime as dt
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ORACLE = ROOT.parent / 'independent-verification'
PLAN_SHA = '8c5e12f0ae21a86cd452152f3ccbff1d6096c846215e1e35f7980992adfa62dc'
FREEZE_SHA = '63930f1ea42ed6cb7202a8df64bc383d9feac74ef9b49f03933bc371dab98220'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

if (ROOT / 'plan_review.json').exists():
    raise RuntimeError('Refuse repeated plan-review freeze')
status = json.loads(Path('/workspace/research_work/mitl-upstream-status.json').read_text())
assert status['active_lease_owner'] == 'mitl-upstream-20261019T0625'
assert dt.datetime.fromisoformat(status['active_editing_lease_until_utc']) > dt.datetime.now(dt.timezone.utc)
assert sha(ORACLE / 'oracle_plan.json') == PLAN_SHA
assert sha(ORACLE / 'before_run_freeze.json') == FREEZE_SHA
plan = json.loads((ORACLE / 'oracle_plan.json').read_text())
config = json.loads((ORACLE / 'input_config.json').read_text())
report = {
    'schema': 'mitl-thermal-forced-feedback-oracle-plan-review-v1',
    'status': 'plan_review_accepted_for_manufactured_verification',
    'completed_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
    'reviewed_plan_sha256': PLAN_SHA, 'before_run_freeze_sha256': FREEZE_SHA,
    'reviewed_input_config_sha256': sha(ORACLE / 'input_config.json'),
    'mathematical_derivation': [
        'Ndot=-Gamma, Gamma=nu*N*exp[-Ea0*(1-alpha*N/Nref)/(kB*T)], C*Tdot=P-Gamma*(D+I+2*kB*T).',
        'At each segment start fix the carried independent N_s,T_s; let s=log(N_s/N), A=(D+I)/(2*kB), b=2*kB*(N_s-N)/C and Z=(T+A)*exp(b).',
        'In u=nu*t: ds/du=exp[-Ea0*(1-alpha*N/Nref)/(kB*T)] and dZ/du=P*exp(b)/(C*nu), with T=Z*exp(-b)-A.',
        'Differentiating the transformed temperature reproduces P/C-Gamma*(D+I+2*kB*T)/C. The reference coverage Nref remains the original fixed coefficient after local recentering.',
        'P=0 implies constant Z on that segment while its own N,T carry through every boundary. Independent Gamma, translation and wall integrals can check counts and energy without subtracting a tested thermal ledger.'
    ],
    'fixture_review': {
        'cases': len(config['cases']),
        'case_ids': [case['case_id'] for case in config['cases']],
        'scope': 'New positive-barrier heating, coverage-dependent competition, translation-only debit and a three-segment on/off/on refinement family.',
        'manufactured_label_present': config['parameter_status'] == 'manufactured',
        'fixed_reference_coverage_declared': True,
        'kinetic_barrier_not_removal_cost': True,
        'outcome_direction_not_assumed': True,
        'physical_or_global_domain_validation': False
    },
    'threshold_review': {
        'declared_plan': {key: value for key, value in plan.items() if key not in ('numeric_method', 'qualification')},
        'assessment': 'Explicit working precision/Taylor-order/substep/quadrature ladder, separate outgoing/gross and resolved-temperature scales, and finite self-order requirements are suitable as prospective manufactured-case numerical checks.',
        'tolerances_establish_prior_accuracy': False,
        'required_behavior': 'Unresolved reference changes, domain/monotonicity or budget failures must reject and preserve evidence; no automatic retry, clipping, floor or threshold adjustment.',
        'interval_or_physical_error_certificate': False
    },
    'qualifications_reviewed': plan['qualification'],
    'source_code_review_pending': True,
    'oracle_numerical_report_available_or_reviewed': False,
    'numerical_models_or_tests_executed': False,
    'scientific_module_imported': False,
    'producer_or_oracle_executed': False,
    'old_modules_or_audits_repeated': False,
    'physical_parameters_validated': False,
    'limits': ['This accepts the prospective mathematical/fixture/threshold plan only.',
               'Full frozen oracle source still needs separate review before its first comparison.',
               'Actual reference stability, trajectories, channels and temporal orders must pass the saved-output checks.',
               'No physical water, material, host, gap or state-chemistry qualification.']
}
(ROOT / 'plan_review.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'plan_review': str(ROOT / 'plan_review.json'), 'sha256': sha(ROOT / 'plan_review.json'),
                  'status': report['status'], 'reviewed_plan_sha256': PLAN_SHA,
                  'numerical_models_or_tests_executed': False}, indent=2))
