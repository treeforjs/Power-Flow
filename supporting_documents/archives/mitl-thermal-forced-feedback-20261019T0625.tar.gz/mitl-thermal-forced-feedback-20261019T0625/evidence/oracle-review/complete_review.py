"""Bind the actual oracle report to the frozen static mathematical review."""
import datetime as dt
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ORACLE = ROOT.parent / 'independent-verification'
REPORT = ORACLE / 'oracle-initial/report.json'
REPORT_SHA = 'd6e2932ed8e21914217ff5b34fcbe4a173cbc9cadd6828e77620522d97f420bf'
REFERENCE_SHA = '0f9a884838bc6c7196654293b2e00c110f958bf065575fcf4e559d5da0e87719'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def load(path):
    return json.loads(path.read_text())

if (ROOT / 'completion.json').exists():
    raise RuntimeError('Refuse repeated completed oracle-review freeze')
status = load(Path('/workspace/research_work/mitl-upstream-status.json'))
assert status['active_lease_owner'] == 'mitl-upstream-20261019T0625'
assert dt.datetime.fromisoformat(status['active_editing_lease_until_utc']) > dt.datetime.now(dt.timezone.utc)
assert sha(ROOT / 'plan_review.json') == '331e5cae7bb01b0391d4b82be04c8f4f586aaa91d9b0874f7b4410c205092b10'
assert sha(ROOT / 'pre_run_code_review.json') == '9ea5762f5c130fcc2afc5359932fdb9cbbe8fd75f9378ba7608b745e08e78e55'
code_review = load(ROOT / 'pre_run_code_review.json')
assert all(sha(ORACLE / name) == digest for name, digest in code_review['reviewed_artifact_sha256'].items())
assert sha(REPORT) == REPORT_SHA
report = load(REPORT)
plan = load(ORACLE / 'oracle_plan.json')
assert report['schema'] == 'mitl-independent-thermal-forced-feedback-oracle-v1'
assert report['numeric_method'] == plan['numeric_method']
assert report['qualification'] == plan['qualification']
assert report['source_model_imports'] == []
assert report['positive_core_or_CLI_calls'] == report['old_solver_or_suite_calls'] == 0
assert report['reference_samples_sha256'] == REFERENCE_SHA
assert sha(REPORT.parent / report['reference_samples_file']) == REFERENCE_SHA
checkpoint_pins = report['reference_checkpoint_sha256']
assert len(checkpoint_pins) == 8
assert all(sha(REPORT.parent / name) == digest for name, digest in checkpoint_pins.items())
notes = '''# Positive-barrier forced oracle mathematical and claims review

The mathematical/fixture/threshold plan was accepted before production. The
fresh transformed Taylor reference and final saved-output verifier were then
read in full before the first independent comparison. The original verifier
and checkpoint-only amendment were retained; the reviewed diff adds early
persistence and hash lineage, without changing equations or tolerances.
No substantive issue was identified and no edits were requested.

At each independent segment start, define s=log(N_s/N),
A=(D+I)/(2*kB), b=2*kB*(N_s-N)/C and Z=(T+A)*exp(b). With u=nu*t,
ds/du is the positive Arrhenius suppression and
dZ/du=P*exp(b)/(C*nu). Differentiating T=Z*exp(-b)-A recovers the declared
forced thermal equation. Nref remains fixed across the local resets; the
reference carries its own N,T and integrals through each power jump.

The Taylor multiplication, reciprocal and exponential coefficient recurrences
match this transformed system. Direct positive quadrature independently
integrates count, translation and gross wall removal along its dense state.
The dimensionless-time factors are consistent: count uses N*factor du,
translation adds 2*kB*T, and wall removal adds D+I+2*kB*T. No thermal residual
or tested energy channel defines these integrals. Exact represented-Fraction
support separately supplies the external-input integral and logical time.

The actual completed report, reference sample file and eight persisted
case/precision checkpoints are associated by hash. The report retains the
frozen plan's precision/order/substep/quadrature ladder, separate channel and
resolved-temperature scales, finite self-order estimates and qualifications.
Its observed passing status and counts were read, not numerically reproduced
by this review. No oracle, core, producer, test or scientific module was run
or imported by the reviewer.

This review covers the four declared manufactured nonempty fixtures. Working
precision changes and self-orders are numerical estimates, not interval,
global-error or physical uncertainty certificates. It does not qualify
physical water kinetics, a foil material, state-resolved chemistry, gap
transport or owner/host integration.
'''
(ROOT / 'review.md').write_text(notes)
observed = ('schema', 'status', 'all_checks_passed', 'cases', 'saved_trajectories',
            'saved_sample_rows_checked', 'distinct_reference_samples',
            'CSV_JSON_scalar_cells_checked', 'area_once_checks', 'logical_time_stamp_checks')
completion = {
    'schema': 'mitl-thermal-forced-feedback-static-oracle-review-v1',
    'status': 'review_complete_no_substantive_issue_identified',
    'completed_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
    'plan_review_sha256': sha(ROOT / 'plan_review.json'),
    'pre_run_code_review_sha256': sha(ROOT / 'pre_run_code_review.json'),
    'reviewed_source_sha256': code_review['reviewed_artifact_sha256']['decimal_forced_reference.py'],
    'reviewed_verifier_sha256': code_review['reviewed_artifact_sha256']['verify_saved_forced_feedback.py'],
    'reviewed_artifact_sha256': code_review['reviewed_artifact_sha256'],
    'owner_report_path': str(REPORT), 'owner_report_sha256': REPORT_SHA,
    'reference_samples_sha256': REFERENCE_SHA,
    'reference_checkpoint_sha256': checkpoint_pins,
    'owner_report_observed_declarations': {key: report[key] for key in observed},
    'owner_report_numeric_method_matches_frozen_plan': True,
    'owner_report_qualifications_match_frozen_plan': True,
    'observed_self_order_estimates': {key: [item['order'] for item in values]
                                     for key, values in report['temporal_self_orders'].items()},
    'reported_temperature_and_gross_channel_scales_read': True,
    'completed_report_bound_without_numerical_replay': True,
    'review_checks': code_review['checks'],
    'findings': [], 'source_changes_requested': False,
    'numerical_models_or_tests_executed': False, 'scientific_module_imported': False,
    'oracle_core_or_producer_executed': False, 'old_models_or_audits_repeated': False,
    'owner_report_numerics_recomputed_by_reviewer': False,
    'physical_parameters_validated': False, 'host_budget_accepted': False,
    'limits': ['Read-only mathematical/source/interface/claims review only.',
               'The actual passing report is hash-associated, not numerically reproduced here.',
               'Four declared manufactured nonempty fixtures; not exhaustive oracle/domain qualification.',
               'Working precision/order/substep/quadrature differences and self-orders are estimates, not certificates.',
               'No physical water/material/state-chemistry or host/gap/owner acceptance.'],
    'artifact_sha256': {p.name: sha(p) for p in sorted(ROOT.iterdir()) if p.is_file()}
}
(ROOT / 'completion.json').write_text(json.dumps(completion, indent=2) + '\n')
print(json.dumps({'completion': str(ROOT / 'completion.json'), 'completion_sha256': sha(ROOT / 'completion.json'),
                  'schema': completion['schema'], 'status': completion['status'],
                  'owner_report_sha256': REPORT_SHA, 'numerical_models_or_tests_executed': False}, indent=2))
