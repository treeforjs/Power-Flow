"""Associate newly available static owner aggregation; never replay numerics."""
import datetime as dt
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ORACLE = ROOT.parent / 'independent-verification'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

if (ROOT / 'owner_completion_association.json').exists():
    raise RuntimeError('Refuse repeated owner-completion association')
assert sha(ROOT / 'completion.json') == '74f0dc298c48e83c576d768a48a04f6f185c0bf65fc4ee6a9e66df1b679c0fa4'
assert sha(ORACLE / 'completion.json') == '856635aedd8f5b8c5559a019bb8d3275fb427d12c6e0ed95b4a18e07cc83a14d'
assert sha(ORACLE / 'summary.json') == '81e211b97ce2086dd9ddc8a8db05219eedd1d98fb1850a1275a2b88913c65cb7'
owner = json.loads((ORACLE / 'completion.json').read_text())
review = json.loads((ROOT / 'completion.json').read_text())
assert owner['report_sha256'] == review['owner_report_sha256']
assert owner['summary_sha256'] == sha(ORACLE / 'summary.json')
assert owner['qualification'] == json.loads((ORACLE / 'oracle_plan.json').read_text())['qualification']
record = {
    'schema': 'mitl-thermal-forced-feedback-owner-completion-association-v1',
    'status': 'associated_without_numerical_replay',
    'completed_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
    'immutable_static_review_sha256': sha(ROOT / 'completion.json'),
    'owner_completion_sha256': sha(ORACLE / 'completion.json'),
    'owner_summary_sha256': sha(ORACLE / 'summary.json'),
    'owner_report_sha256': owner['report_sha256'],
    'owner_schema': owner['schema'], 'owner_reported_status': owner['status'],
    'owner_reported_numerical_runs': owner['independent_oracle_numerical_runs'],
    'owner_static_aggregation_correction_read': owner['static_aggregation_correction'],
    'qualifications_unchanged': True,
    'existing_review_modified': False,
    'numerical_models_or_tests_executed': False,
    'oracle_core_or_producer_replayed': False,
    'limits': 'Read-only association of newly completed aggregation. Owner numerics and summary extrema are not recomputed; original static-review hash remains unchanged.'
}
path = ROOT / 'owner_completion_association.json'
path.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'association': str(path), 'sha256': sha(path), 'status': record['status']}, indent=2))
