"""Record pre-run source review of the new transformed Taylor oracle."""
import datetime as dt
import difflib
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ORACLE = ROOT.parent / 'independent-verification'
PINS = {
    'decimal_forced_reference.py': 'b6740c00a75b094ea36c9d6c1d941cbe31e19b8100a200613ef8961136c8da89',
    'verify_saved_forced_feedback.py': 'c0fb60652e2565b58c1183948e236c7534bf86c000c7d118bcbe3c3fa0a86168',
    'verify_saved_forced_feedback.initial.py': '561219e2ee851949c30e61ccbf046092c5dc64e1ebc635b7c76ce94a6e7b3fb6',
    'oracle_plan.json': '8c5e12f0ae21a86cd452152f3ccbff1d6096c846215e1e35f7980992adfa62dc',
    'before_run_freeze.json': '63930f1ea42ed6cb7202a8df64bc383d9feac74ef9b49f03933bc371dab98220',
    'checkpoint_amendment.json': '8d9b7f5f3202809821ea5ecb24b7b76716af1f7d9237f23d66991b6c65514d7f'
}

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

if (ROOT / 'pre_run_code_review.json').exists():
    raise RuntimeError('Refuse repeated pre-run code review freeze')
status = json.loads(Path('/workspace/research_work/mitl-upstream-status.json').read_text())
assert status['active_lease_owner'] == 'mitl-upstream-20261019T0625'
assert dt.datetime.fromisoformat(status['active_editing_lease_until_utc']) > dt.datetime.now(dt.timezone.utc)
assert all(sha(ORACLE / name) == digest for name, digest in PINS.items())
assert sha(ROOT / 'plan_review.json') == '331e5cae7bb01b0391d4b82be04c8f4f586aaa91d9b0874f7b4410c205092b10'
patch = ''.join(difflib.unified_diff((ORACLE / 'verify_saved_forced_feedback.initial.py').read_text().splitlines(keepends=True),
    (ORACLE / 'verify_saved_forced_feedback.py').read_text().splitlines(keepends=True),
    fromfile='initial/verify_saved_forced_feedback.py', tofile='checkpointed/verify_saved_forced_feedback.py'))
(ROOT / 'reviewed-checkpoint-amendment.patch').write_text(patch)
checks = [
    ('transformed_equations', 's=log(N_s/N), b=2*kB*(N_s-N)/C and Z=(T+A)*exp(b) recover the declared coupled thermal/kinetic IVP. The fixed Nref is retained across local resets.'),
    ('Taylor_recurrences', 'Ordinary coefficient multiplication, reciprocal and exponential recurrences correctly form the transformed RHS; division by n+1 advances unnormalized power-series coefficients. No RK stage is reused.'),
    ('dimensionless_channel_scaling', 'The Taylor variable is u=nu*t. Direct count quadrature uses N*factor du, translation uses 2*kB*T*N*factor du and gross wall uses (D+I+2*kB*T)*N*factor du; no missing or duplicate nu appears.'),
    ('independent_segment_state', 'Every segment carries the preceding independent N,T and global integrals, then resets only local s and Z. No producer boundary state seeds the reference. Off-segment Z remains structurally constant.'),
    ('finite_logical_input_and_time', 'Exact Fraction endpoints and step fractions define the union logical grid and finite input integral. Every power jump is split; rounded stamps are independently checked.'),
    ('separate_positive_quadrature', 'Open positive Decimal Gauss-Legendre nodes/weights sample dense Taylor states. Direct Gamma, translation and gross wall integrals remain independent of reconstructed release, thermal subtraction and channel sums.'),
    ('domain_and_monotonicity', 'The four declared nonempty fixtures have explicit domains. Evaluated dense states/endpoints check inventory, temperature, effective barrier and factor; local depletion must advance and off-segment Z must remain unchanged.'),
    ('comparison_and_scales', 'All saved rows are checked using separate emitted/gross budgets and maximum resolved thermal excursion; zero budgets require zero error. Precision/method changes and direct-channel residuals have explicit prospective tolerances.'),
    ('selforders_and_qualification', 'Orders come from consecutive saved endpoint differences with sign/decrease checks. Working precision/order/substep/quadrature changes are estimates, not interval, physical-error or global certificates.'),
    ('independence_and_IO_lineage', 'No core/producer/test/old numerical module is imported or called. The reviewed amendment changes fresh-directory/checkpoint persistence and hash lineage only, with mathematical code/plan and tolerances unchanged.')
]
report = {
    'schema': 'mitl-thermal-forced-feedback-oracle-pre-run-code-review-v1',
    'status': 'review_complete_no_substantive_issue_identified',
    'completed_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
    'reviewed_artifact_sha256': PINS,
    'plan_review_sha256': sha(ROOT / 'plan_review.json'),
    'full_fresh_reference_and_final_verifier_read': True,
    'checkpoint_only_lineage_diff_reviewed': True,
    'reviewed_checkpoint_diff_sha256': sha(ROOT / 'reviewed-checkpoint-amendment.patch'),
    'checks': [{'area': name, 'static_review_complete': True, 'finding': finding} for name, finding in checks],
    'findings': [], 'source_changes_requested': False,
    'numerical_report_binding_pending': True,
    'numerical_models_or_tests_executed': False, 'scientific_module_imported': False,
    'oracle_core_or_producer_executed': False,
    'old_models_or_audits_repeated': False,
    'physical_parameters_validated': False, 'host_budget_accepted': False,
    'limits': ['Pre-run mathematical/source/claims review only.',
               'Four declared manufactured nonempty fixtures; not an exhaustive oracle API/domain qualification.',
               'Actual sole-pass reference stability, saved trajectories/channels and orders remain to be checked.',
               'No numerical accuracy, physical water/material/state-chemistry or host acceptance certificate.']
}
(ROOT / 'pre_run_code_review.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'pre_run_code_review': str(ROOT / 'pre_run_code_review.json'),
                  'sha256': sha(ROOT / 'pre_run_code_review.json'), 'schema': report['schema'],
                  'status': report['status'], 'numerical_models_or_tests_executed': False}, indent=2))
