"""Associate forced-feedback documentation with frozen version-qualified evidence."""
import hashlib
import json
from pathlib import Path
import re

repo=Path('/workspace/Power-Flow')
work=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(name):return json.loads((work/name).read_text())
pins={
 'core-review/completion.json':'4a75363faac81b89f29f274486f9d9bcf302741f5a0ec86c80c4da1e62b3ae7d',
 'tests/completion.json':'071e5afef56f6a2f7ddf0594a18fbbc58f02287b7a51dc71ae1d3c423a373b8f',
 'producer/completion.json':'835bf37391aac90a8495be19b3a2301091934b38af1120a24dbb7a6baccf6b15',
 'producer/reference-run/report.json':'86add83585b0c72d1c22cfd2161d3dc530cb4f9af432f817c4bd6943bc9bfad9',
 'producer/parser_guard_checks.initial.json':'92a9b2ebf8f3289faa582fea7b9621d28db2cfad8ec91a7a5f847f22586887e3',
 'producer/early_numeric_guard_checks.json':'5ad2f2442b8b19d8e37c48e713dedbc0e9b2fbe3a32a3a0a812e7ed897add49c',
 'independent-verification/completion.json':'856635aedd8f5b8c5559a019bb8d3275fb427d12c6e0ed95b4a18e07cc83a14d',
 'independent-verification/summary.json':'81e211b97ce2086dd9ddc8a8db05219eedd1d98fb1850a1275a2b88913c65cb7',
 'independent-verification/oracle-initial/report.json':'d6e2932ed8e21914217ff5b34fcbe4a173cbc9cadd6828e77620522d97f420bf',
 'oracle-review/plan_review.json':'331e5cae7bb01b0391d4b82be04c8f4f586aaa91d9b0874f7b4410c205092b10',
 'oracle-review/pre_run_code_review.json':'9ea5762f5c130fcc2afc5359932fdb9cbbe8fd75f9378ba7608b745e08e78e55',
 'oracle-review/completion.json':'74f0dc298c48e83c576d768a48a04f6f185c0bf65fc4ee6a9e66df1b679c0fa4',
 'oracle-review/owner_completion_association.json':'c02cf13a34c3e7898babe60d780c9078ce1daf1c792f8f394ec100bb851da4cc',
 'independent-verification/before_run_freeze.json':'63930f1ea42ed6cb7202a8df64bc383d9feac74ef9b49f03933bc371dab98220',
 'independent-verification/checkpoint_amendment.json':'8d9b7f5f3202809821ea5ecb24b7b76716af1f7d9237f23d66991b6c65514d7f',
 'next-upstream-selection/selection.json':'7c3df2308d0b61e1b37a37ecd1ec1a19a1fcf2b915f462614cbd6bea36237b38'}
for name,digest in pins.items():assert sha(work/name)==digest,name
core=load('core/source-freeze.json')
assert core['source_sha256']=='16033899c949896ca346eb6cfb6beb9cdd9d9253c1a110fa9f057a9b8bdeac4d'
assert core['frozen_before_first_meaningful_verification'] is True
assert core['model_test_or_oracle_executions_by_author']==0
pins['core/source-freeze.json']=sha(work/'core/source-freeze.json')
tests=load('tests/completion.json')
assert tests['all_checks_passed'] is True and tests['scientific_core_unchanged'] is True
test_counts={'qualified_unique_new_test_cases':32,'test_case_executions':33,
 'initial_tests_passed':31,'initial_tests_failed':1,'corrected_failed_case_passes':1,
 'unchanged_passing_cases_repeated':0}
assert all(tests[key]==value for key,value in test_counts.items())
assert all(sha(repo/name)==digest for name,digest in tests['public_source_sha256'].items())
producer=load('producer/completion.json')
assert producer['status']=='passed_production_and_parser_checks'
assert producer['positive_batch_count']==1 and producer['source_versions']['positive_model_retries']==0
assert producer['parser_evidence']['initial_executions']==17
assert producer['parser_evidence']['final_focused_executions']==5
assert producer['source_versions']['unique22_checks_claimed'] is False
assert all(sha(repo/name)==digest for name,digest in producer['reviewed_source_sha256'].items())
oracle=load('independent-verification/completion.json')
assert oracle['status']=='passed' and oracle['all_checks_passed'] is True
counts={'cases':4,'saved_trajectories':7,'saved_sample_rows_checked':463,
 'CSV_JSON_scalar_cells_checked':7871,'area_once_checks':6482,'logical_time_stamp_checks':463,
 'distinct_reference_samples':292,'resolved_self_order_estimates':18,'independent_oracle_numerical_runs':1}
assert all(oracle[key]==value for key,value in counts.items())
assert oracle['direct_positive_translation_quadrature'] is True
assert oracle['separate_direct_positive_wall_debit_quadrature'] is True
assert oracle['positive_core_or_CLI_calls_by_oracle']==0
review=load('oracle-review/completion.json')
assert review['status']=='review_complete_no_substantive_issue_identified' and review['findings']==[]
selection=load('next-upstream-selection/selection.json')
assert selection['status']=='selected_pending_fresh_bounded_lease' and selection['selected_task']
report=load('independent-verification/oracle-initial/report.json')
fine=next(t for t in report['trajectories'] if t['segment_steps']==[64,64,64])
def value(v):return v['float_projection']
for field,bounds in {'temperature_k':(1.62e-11,1.63e-11),'released_m2':(5.16e-12,5.17e-12),
 'translational_energy_j_m2':(5.09e-12,5.10e-12),'total_wall_energy_debit_j_m2':(5.12e-12,5.14e-12)}.items():
    error=value(fine['all_row_maximum_errors'][field]['absolute_budget_fraction'])
    assert bounds[0]<error<bounds[1]
endpoint=fine['endpoint_reference']
for field,quoted,tolerance in [('temperature_k',928.787538,5e-7),
 ('input_energy_j_m2',6,1e-14),('total_wall_energy_debit_j_m2',4.560623,5e-7),
 ('translational_energy_j_m2',2.333912,5e-7),('wall_thermal_change_j_m2',1.439377,5e-7)]:
    assert abs(value(endpoint[field])-quoted)<tolerance
public=list(tests['public_source_sha256'])+['tools/run_thermal_forced_feedback_reference.py',
 'configs/thermal_forced_feedback_manufactured.json','docs/thermal_forced_feedback_reference.md']
assert len(set(public))==len(public)==5
guide=repo/'docs/thermal_forced_feedback_reference.md';text=guide.read_text()
for claim in ['50-digit','4096','32 new core cases','33 executions','31 initial passes',
 '17 initial executions','five focused checks','463','7,871','6,482','292','4.00268–4.00764',
 '928.787538','4.560623','2.333912','9.26536','1.63 × 10⁻¹¹','5.16 × 10⁻¹²']:
    assert claim in text,claim
links=re.findall(r'\]\(([^)#]+)(?:#[^)]*)?\)',text)
assert all((guide.parent/name).is_file() for name in links)
run=load('producer/reference-run/report.json')
qa={}
for name,digest in run['artifact_sha256'].items():
    if Path(name).suffix not in {'.png','.pdf'}:continue
    relative='producer/reference-run/'+name
    assert sha(work/relative)==digest
    qa[relative]=digest
assert len(qa)==4
visual={'schema':'mitl-thermal-forced-feedback-root-visual-review-v1','status':'passed',
 'PNG_figures_actually_viewed_by_root':2,'QA_artifact_sha256':qa,
 'findings':['All four cases identify manufactured positive-barrier feedback and separately labelled temperature and release fraction.',
  'The scheduled temperature is continuous at both power jumps; positive release continues through the cooling off segment.',
  'Gross input, removal, internal, translation, wall debit and signed thermal change are shown separately.',
  'Legends, units and manufactured scope are legible; no physical water or source-field normalization is inferred.'],
 'plots_or_scientific_execution_repeated':False,'physical_parameters_accepted':False}
(work/'visual-review.json').write_text(json.dumps(visual,indent=2)+'\n')
pins['visual-review.json']=sha(work/'visual-review.json')
result={'schema':'mitl-thermal-forced-feedback-documentation-association-v1','status':'passed',
 'public_sha256':{name:sha(repo/name) for name in public},'record_sha256':pins,
 'verified_counts':counts,'test_execution_history':test_counts,
 'initial_parser_executions':17,'final_focused_parser_executions':5,'unique22_parser_cases_claimed':False,
 'guide_local_links':links,'quoted_scheduled_reference_checked':True,
 'next_task':selection['selected_task'],'scientific_producers_tests_or_oracles_reexecuted':False,
 'physical_water_material_ML_spectral_or_host_acceptance':False}
(work/'documentation-association.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'association_sha256':sha(work/'documentation-association.json'),
 'visual_sha256':sha(work/'visual-review.json'),'public_sha256':result['public_sha256']},indent=2))
