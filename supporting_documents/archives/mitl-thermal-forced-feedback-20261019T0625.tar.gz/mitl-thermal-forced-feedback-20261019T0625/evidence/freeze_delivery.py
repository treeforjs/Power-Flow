"""Freeze new manufactured prescribed-power evidence without replaying the reference."""
import datetime
import csv
import hashlib
import io
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tarfile
from xml.etree import ElementTree

from prepare_delivery import WORK, REPO, BASE, OUT, PUBLIC, WRAPPERS, clean_head, dependency_context, input_contract, command_snapshot_prefix, load, save, sha

TEXT_SUFFIXES = {'.py', '.json', '.jsonl', '.log', '.xml', '.md', '.txt', '.patch', '.sha256', '.yaml', '.csv'}
EVIDENCE_DIRS = ('core', 'core-review', 'producer', 'tests', 'independent-verification', 'oracle-review', 'next-upstream-selection', 'delivery-preparation', 'completion-preparation')
REPORT_PATHS = {
    'producer_run': 'producer/reference-run/report.json',
    'producer_completion': 'producer/completion.json',
    'parser_guards': 'producer/parser_guard_checks.json',
    'early_numeric_guards': 'producer/early_numeric_guard_checks.json',
    'producer_before_run': 'producer/freeze.json',
    'tests_completion': 'tests/completion.json',
    'core_freeze': 'core/source-freeze.json',
    'static_core_review': 'core-review/completion.json',
    'oracle_completion': 'independent-verification/completion.json',
    'oracle_report': 'independent-verification/oracle-initial/report.json',
    'oracle_summary': 'independent-verification/summary.json',
    'oracle_review': 'oracle-review/completion.json',
    'oracle_owner_association': 'oracle-review/owner_completion_association.json',
    'documentation_association': 'documentation-association.json',
    'visual_review': 'visual-review.json',
    'selection': 'next-upstream-selection/selection.json',
}
PROJECTIONS = (
    (bytes.fromhex('2f6f70742f636f6465782f72756e74696d65732f636f6465782d7072696d6172792d72756e74696d652f646570656e64656e636965732f707974686f6e'), b'[runtime Python directory]'),
    (bytes.fromhex('2f6574632f636f6465782f'), b'[runtime policy directory]/'),
)


def excluded(relative, allowed_figures=()):
    path = Path(relative)
    if 'delivery-preparation' in path.parts and 'payload' in path.parts:
        return True
    if any(part in {'__pycache__', '.pytest_cache', '.venv', 'source-local', 'fulltexts', 'raw-fulltexts',
                    'pytest-temp', 'pytest-tmp', 'test-fixtures', 'fixtures'}
           or part.startswith('.thermal-forced-feedback-reference-') for part in path.parts):
        return True
    if path.suffix == '.pyc':
        return True
    if 'source-acquisition' in path.parts:
        return 'raw' in path.parts or path.suffix not in {'.json', '.jsonl', '.py', '.md', '.log', '.sha256'}
    if path.suffix.lower() in {'.png', '.pdf', '.jpg', '.jpeg', '.tif', '.tiff'}:
        return str(path) not in set(allowed_figures)
    return False


def verify_contracts(records, configured_inputs, *, work_sha=None, public_sha=None, work_bytes=None):
    """Check only frozen metadata, saved-file associations and byte identities."""
    h = work_sha or (lambda name: sha(WORK/name))
    p = public_sha or (lambda name: sha(REPO/name))
    b = work_bytes or (lambda name: (WORK/name).read_bytes())

    def artifacts(mapping, prefix=''):
        assert isinstance(mapping, dict) and mapping
        for name, digest in mapping.items():
            path = Path(name)
            assert not path.is_absolute() and '..' not in path.parts
            assert re.fullmatch('[0-9a-f]{64}', digest) and h(prefix+name) == digest

    def counts(record, expected):
        for key, value in expected.items():
            assert type(record[key]) is int and record[key] == value, key

    def rows(name):
        return list(csv.DictReader(io.StringIO(b(name).decode())))

    core_path = 'mhdlab/thermal_forced_feedback_reference.py'
    test_path = 'tests/test_thermal_forced_feedback_reference.py'
    cli_path = 'tools/run_thermal_forced_feedback_reference.py'
    tests = records['tests_completion']
    assert tests['schema'] == 'mitl-thermal-forced-feedback-core-tests-v1'
    assert tests['status'] == 'passed' and tests['all_checks_passed'] is True
    counts(tests, {'qualified_unique_new_test_cases': 32, 'test_case_executions': 33, 'targeted_test_runs': 2,
        'initial_tests_passed': 31, 'initial_tests_failed': 1, 'corrected_failed_case_passes': 1,
        'unchanged_passing_cases_repeated': 0, 'errors': 0, 'skipped': 0})
    assert tests['warnings_as_errors'] is True and tests['initial_failures_preserved'] is True
    assert tests['scientific_core_unchanged'] is True
    assert all(p(name) == digest for name, digest in tests['public_source_sha256'].items())
    versions = tests['source_versions']
    assert versions['initial_run']['core_sha256'] == versions['focused_correction_run']['core_sha256'] == p(core_path)
    assert versions['initial_run']['test_sha256'] == h(versions['initial_run']['preserved_test'])
    assert versions['focused_correction_run']['test_sha256'] == p(test_path)
    assert versions['unchanged_test_functions_AST_identical'] is True
    assert versions['predeclared_tolerance_changed'] is False
    assert versions['all_32_tests_repeated_on_final_test_bytes'] is False
    for key in ('old_suites_or_producers_repeated', 'old_numerical_evolution_called',
                'portable_test_execution_claimed', 'actual_FLASH_run', 'host_budget_accepted'):
        assert tests[key] is False
    artifacts(tests['artifact_sha256'])
    for filename, count, failures in (('tests/core-initial.xml', 32, 1), ('tests/empty-analytic-rerun.xml', 1, 0)):
        suites = list(ElementTree.fromstring(b(filename)).iter('testsuite'))
        assert sum(int(suite.attrib.get('tests', 0)) for suite in suites) == count
        assert sum(int(suite.attrib.get('failures', 0)) for suite in suites) == failures
        assert all(int(suite.attrib.get(key, 0)) == 0 for suite in suites for key in ('errors', 'skipped'))
    for command in tests['command_records']:
        assert h(str(Path(command['log']).relative_to(WORK))) == command['log_sha256']
    core = records['core_freeze']
    assert core['schema'] == 'mhdlab-thermal-forced-feedback-core-freeze-v1'
    assert core['source_sha256'] == p(core_path) and core['frozen_before_first_meaningful_verification'] is True
    assert core['model_test_or_oracle_executions_by_author'] == 0
    assert core['dependencies']['old_numerical_evolution_calls'] is False
    static = records['static_core_review']
    assert static['schema'] == 'mitl-thermal-forced-feedback-static-core-review-v1'
    assert static['status'] == 'review_complete_no_substantive_issue_identified' and static['findings'] == []
    assert static['reviewed_source_sha256'] == p(core_path)
    for key in ('source_changes_requested', 'numerical_models_or_tests_executed', 'scientific_module_imported',
                'producer_or_oracle_executed', 'old_numerical_methods_or_audits_repeated',
                'public_source_edits_by_reviewer', 'physical_parameters_validated', 'host_budget_accepted'):
        assert static[key] is False
    artifacts(static['artifact_sha256'], 'core-review/')

    initial_parser, early = records['parser_guards'], records['early_numeric_guards']
    assert initial_parser['schema'] == 'mhdlab-thermal-forced-feedback-parser-checks-v1'
    assert initial_parser['status'] == 'passed' and len(initial_parser['checks']) == 17
    counts(initial_parser, {'rejected_configurations': 16, 'accepted_configuration_plans': 1})
    assert initial_parser['cli_sha256'] == h('producer/source-versions/initial_cli_before_early_numeric_guard.py')
    assert early['schema'] == 'mhdlab-forced-feedback-early-numeric-checks-v1' and early['status'] == 'passed'
    assert early['checks_count'] == len(early['checks']) == 5
    assert early['cli_sha256'] == p(cli_path) and early['initial_cli_sha256'] == initial_parser['cli_sha256']
    assert early['initial_parser_report_sha256'] == h(REPORT_PATHS['parser_guards'])
    for record in (initial_parser, early):
        assert record['config_sha256'] == configured_inputs['config_sha256']
        assert record['evolution_or_core_imports_called'] is False
    assert initial_parser['raw_effective_barrier_domain_checked_exactly'] is True
    assert initial_parser['strictly_positive_activation_required'] is True

    run, produced, before = records['producer_run'], records['producer_completion'], records['producer_before_run']
    assert run['schema'] == 'mhdlab-thermal-forced-feedback-reference-run-v1'
    assert run['status'] == 'manufactured_reference_only' and run['parameter_status'] == 'manufactured'
    assert run['config_sha256'] == configured_inputs['config_sha256']
    assert run['artifact_path_base'] == 'directory containing report.json'
    counts(run, {'case_count': 4, 'numerical_trajectory_count': 7, 'sample_count': 463})
    assert run['case_count'] == configured_inputs['declared_case_count']
    assert run['numerical_trajectory_count'] == configured_inputs['declared_trajectory_count']
    assert run['sample_count'] == configured_inputs['declared_sample_count']
    assert all(p(name) == digest for name, digest in run['code_sha256'].items())
    cases = {case['case_id']: case for case in configured_inputs['configuration']['cases']}
    expected = {(case['case_id'], tuple(grid)) for case in cases.values() for grid in case['step_grids']}
    assert {(item['case_id'], tuple(item['segment_steps'])) for item in run['trajectories']} == expected
    assert len(run['trajectories']) == 7
    prefix = 'producer/reference-run/'
    artifacts(run['artifact_sha256'], prefix)
    allowed_figures = [prefix+name for name in run['artifact_sha256'] if Path(name).suffix in {'.png', '.pdf'}]
    samples = 0
    for item in run['trajectories']:
        assert h(prefix+item['csv_file']) == item['csv_sha256'] and h(prefix+item['history_file']) == item['history_sha256']
        history = load_json_bytes(b(prefix+item['history_file']))
        assert history['schema'] == 'mhdlab-thermal-forced-feedback-reference-v1'
        assert history['model_identity'] == core['model_identity']
        assert history['arrhenius_evaluation']['base_activation_energy_strictly_positive'] is True
        for key in ('physical_parameters_validated', 'host_budget_accepted', 'owner_implementation_verified'):
            assert history[key] is False
        case = cases[item['case_id']]
        assert item['input_parameters'] == history['problem'] == case['problem']
        assert item['input_segments'] == case['segments']
        assert item['segment_steps'] == case['step_grids'][item['grid_index']]
        assert item['total_steps'] == sum(item['segment_steps'])
        assert len(history['samples']) == item['sample_count'] == item['total_steps']+1
        assert [segment['steps'] for segment in history['schedule']['segments']] == item['segment_steps']
        data = rows(prefix+item['csv_file'])
        assert len(data) == item['sample_count']
        for index, (row, sample) in enumerate(zip(data, history['samples'])):
            flat = {key: value for key, value in sample.items() if key != 'extensive'}
            flat.update(sample['extensive'])
            assert row['case_id'] == item['case_id'] and int(row['sample_index']) == index
            assert int(row['grid_index']) == item['grid_index'] and int(row['total_steps']) == item['total_steps']
            assert all(float(row[key]) == value for key, value in flat.items())
        samples += len(data)
    assert samples == 463 and len(run['temporal_refinement']) == len(rows(prefix+'temporal_refinement.csv')) == 30
    for key in ('explicit_finite_prescribed_power', 'strictly_positive_base_activation_energy',
                'temperature_dependent_coverage_barrier', 'gross_input_and_debit_separate',
                'signed_net_thermal_change_preserved', 'expected_flux_translation_2kBT'):
        assert run['qualifications'][key] is True
    for key in ('independent_reference_error_computed_here', 'old_source_power_or_feedback_evolution_called',
                'physical_parameters_or_water_inferred', 'actual_FLASH_or_host_coupling', 'floor_clamp_or_unsupported_fallback'):
        assert run['qualifications'][key] is False
    assert produced['schema'] == 'mhdlab-forced-feedback-producer-completion-v1'
    assert produced['status'] == 'passed_production_and_parser_checks' and produced['open_substantive_findings'] == []
    counts(produced, {'positive_batch_count': 1, 'case_count': 4, 'numerical_trajectory_count': 7,
        'saved_sample_count': 463, 'temporal_refinement_rows': 30, 'core_unique_checks': 32})
    assert produced['report_sha256'] == h(REPORT_PATHS['producer_run'])
    assert produced['producer_cli_sha256'] == p(cli_path)
    assert all(p(name) == digest for name, digest in produced['reviewed_source_sha256'].items())
    assert produced['core_test_execution_history'] == tests['command_records']
    pv = produced['source_versions']
    assert pv['initial_cli_sha256'] == initial_parser['cli_sha256'] and pv['final_cli_sha256'] == p(cli_path)
    assert pv['initial_parser_executions'] == 17 and pv['final_focused_parser_executions'] == 5
    assert pv['unique22_checks_claimed'] is False and pv['initial_source_snapshot_is_original_captured_bytes'] is True
    assert pv['core_unchanged_for_production'] is True and pv['positive_model_retries'] == 0
    correction = produced['metadata_freeze_correction']
    assert correction['initial_freeze_exit_code'] == 1 and correction['core_cli_config_changed_for_this_fix'] is False
    assert correction['model_called_by_freezer'] is False
    assert correction['initial_helper_sha256'] == h('producer/freeze_producer.initial.py')
    assert produced['old_suites_or_source_evolution_repeated'] is False
    assert produced['old_power_or_feedback_evolution_called'] is False
    artifacts(produced['artifact_sha256'])
    assert before['schema'] == 'mhdlab-forced-feedback-producer-freeze-v1'
    assert before['prior_positive_cli_batches'] == 0 and before['public_source_sha256'] == produced['reviewed_source_sha256']
    assert before['core_test_execution_history'] == tests['command_records']
    assert before['old_evolution_or_producer_calls'] is False
    artifacts(before['saved_source_sha256'], 'producer/')
    return verify_final_reports(records, configured_inputs, h, p, b, artifacts, counts, allowed_figures)


def verify_final_reports(records, configured_inputs, h, p, b, artifacts, counts, allowed_figures):
    oracle, reference, summary = records['oracle_completion'], records['oracle_report'], records['oracle_summary']
    assert oracle['schema'] == 'mitl-independent-thermal-forced-feedback-completion-v1'
    assert oracle['status'] == 'passed' and oracle['all_checks_passed'] is True
    expected = {'cases': 4, 'saved_trajectories': 7, 'saved_sample_rows_checked': 463,
        'CSV_JSON_scalar_cells_checked': 7871, 'area_once_checks': 6482, 'logical_time_stamp_checks': 463,
        'distinct_reference_samples': 292, 'refinement_quantities_checked': 9, 'resolved_self_order_estimates': 18,
        'independent_oracle_numerical_runs': 1, 'positive_core_or_CLI_calls_by_oracle': 0, 'old_solver_or_suite_calls': 0}
    counts(oracle, expected)
    assert oracle['report_sha256'] == h(REPORT_PATHS['oracle_report'])
    assert oracle['summary_sha256'] == h(REPORT_PATHS['oracle_summary'])
    assert oracle['producer_report_sha256'] == h(REPORT_PATHS['producer_run'])
    assert oracle['producer_code_sha256'] == records['producer_run']['code_sha256']
    assert oracle['input_config_sha256'] == configured_inputs['config_sha256']
    assert oracle['core_imports_in_oracle'] == [] and oracle['artifact_map_base'] == 'work_directory'
    for key in ('predeclared_budget_checks_passed', 'individual_energy_channel_checks_passed',
                'direct_positive_translation_quadrature', 'separate_direct_positive_wall_debit_quadrature',
                'exact_fraction_logical_times', 'temperature_and_thermal_excursion_scales_separate_from_gross_channels',
                'empty_inventory_branch_supported_but_not_a_saved_fixture', 'strictly_positive_base_activation_energy'):
        assert oracle[key] is True
    for key in ('source_evolution_repeated', 'old_test_suites_repeated',
                'interval_certification_or_physical_uncertainty_claimed', 'water_or_material_or_state_data_adopted',
                'host_or_gap_or_MHD_coupling_verified'):
        assert oracle[key] is False
    artifacts(oracle['artifact_sha256'])
    assert len(oracle['command_records']) == 1 and oracle['command_records'][0]['exit_code'] == 0
    command = oracle['command_records'][0]
    assert h(str(Path(command['log']).relative_to(WORK))) == command['log_sha256']
    assert reference['schema'] == 'mitl-independent-thermal-forced-feedback-oracle-v1'
    assert reference['status'] == 'passed' and reference['all_checks_passed'] is True
    counts(reference, {key: expected[key] for key in ('cases', 'saved_trajectories', 'saved_sample_rows_checked',
        'CSV_JSON_scalar_cells_checked', 'area_once_checks', 'logical_time_stamp_checks', 'distinct_reference_samples')})
    assert reference['source_model_imports'] == [] and reference['positive_core_or_CLI_calls'] == reference['old_solver_or_suite_calls'] == 0
    assert len(reference['reference_checkpoint_sha256']) == 8 and len(reference['temporal_self_orders']) == 9
    artifacts(reference['reference_checkpoint_sha256'], 'independent-verification/oracle-initial/')
    assert h('independent-verification/oracle-initial/'+reference['reference_samples_file']) == reference['reference_samples_sha256']
    for name, digest in reference['input_sha256'].items():
        assert h(str(Path(name).relative_to(WORK))) == digest
    amendment = load_json_bytes(b('independent-verification/checkpoint_amendment.json'))
    assert amendment['schema'] == 'mitl-independent-forced-feedback-checkpoint-amendment-v1'
    assert amendment['original_freeze_sha256'] == h('independent-verification/before_run_freeze.json')
    assert amendment['original_verifier_sha256'] == h('independent-verification/verify_saved_forced_feedback.initial.py')
    assert amendment['corrected_verifier_sha256'] == h('independent-verification/verify_saved_forced_feedback.py')
    assert amendment['reference_code_sha256'] == h('independent-verification/decimal_forced_reference.py')
    assert amendment['math_plan_sha256'] == h('independent-verification/oracle_plan.json')
    assert amendment['equations_method_inputs_tolerances_changed'] is False
    assert amendment['numerical_reference_calls_before_amendment'] == 0
    correction = oracle['static_aggregation_correction']
    assert correction['initial_command']['exit_code'] == 1 and correction['reference_or_producer_repeated'] is False
    assert correction['initial_code_sha256'] == h('independent-verification/finalize_completion.initial.py')
    assert h(str(Path(correction['initial_command']['log']).relative_to(WORK))) == correction['initial_command']['log_sha256']
    assert summary['schema'] == 'mitl-thermal-forced-feedback-independent-summary-v1' and summary['status'] == 'passed'
    assert summary['oracle_report_sha256'] == h(REPORT_PATHS['oracle_report'])
    assert summary['source_producer_report_sha256'] == h(REPORT_PATHS['producer_run'])
    assert summary['precision_or_self_order_is_certified_bound'] is False
    for key in ('temperature_scale_is_resolved_excursion', 'thermal_scale_is_heat_capacity_times_resolved_excursion',
                'gross_input_or_debit_does_not_replace_temperature_scale'):
        assert summary[key] is True
    review = records['oracle_review']
    assert review['schema'] == 'mitl-thermal-forced-feedback-static-oracle-review-v1'
    assert review['status'] == 'review_complete_no_substantive_issue_identified' and review['findings'] == []
    assert review['owner_report_sha256'] == h(REPORT_PATHS['oracle_report'])
    assert review['reference_samples_sha256'] == reference['reference_samples_sha256']
    assert review['reference_checkpoint_sha256'] == reference['reference_checkpoint_sha256']
    for key in ('source_changes_requested', 'numerical_models_or_tests_executed', 'scientific_module_imported',
                'oracle_core_or_producer_executed', 'old_models_or_audits_repeated',
                'owner_report_numerics_recomputed_by_reviewer', 'physical_parameters_validated', 'host_budget_accepted'):
        assert review[key] is False
    artifacts(review['reviewed_artifact_sha256'], 'independent-verification/')
    artifacts(review['artifact_sha256'], 'oracle-review/')
    association = records['oracle_owner_association']
    assert association['schema'] == 'mitl-thermal-forced-feedback-owner-completion-association-v1'
    assert association['status'] == 'associated_without_numerical_replay'
    assert association['immutable_static_review_sha256'] == h(REPORT_PATHS['oracle_review'])
    assert association['owner_completion_sha256'] == h(REPORT_PATHS['oracle_completion'])
    assert association['owner_summary_sha256'] == h(REPORT_PATHS['oracle_summary'])
    assert association['owner_report_sha256'] == h(REPORT_PATHS['oracle_report'])
    assert association['qualifications_unchanged'] is True
    for key in ('existing_review_modified', 'numerical_models_or_tests_executed', 'oracle_core_or_producer_replayed'):
        assert association[key] is False

    verify_root_reports(records, h, p, b, artifacts)
    relationships = {
        'tests': records['tests_completion']['source_versions'],
        'CLI': records['producer_completion']['source_versions'],
        'oracle_pre_run_checkpoint_IO': amendment,
        'oracle_static_aggregation_correction': correction,
        'unchanged_baseline_parameter_records': {
            'mhdlab/thermal_feedback_reference.py': p('mhdlab/thermal_feedback_reference.py'),
            'mhdlab/thermal_power_reference.py': p('mhdlab/thermal_power_reference.py'),
            'old_numerical_evolution_reused_or_replayed': False}}
    results = {'qualified_unique_new_test_cases': 32, 'test_case_executions': 33, 'targeted_test_runs': 2,
        'initial_test_passes': 31, 'initial_test_failures_preserved': 1, 'focused_corrected_case_passes': 1,
        'unchanged_passing_cases_repeated': 0, 'blanket_final_test_file_run_claimed': False,
        'initial_CLI_parser_executions': 17, 'final_focused_CLI_parser_executions': 5,
        'unique_22_parser_checks_claimed': False, 'actual_positive_cli_batches': 1,
        'manufactured_cases': 4, 'saved_trajectories': 7, 'saved_sample_rows': 463, 'producer_refinement_rows': 30,
        'independent_oracle_runs': 1, 'oracle_csv_json_cells_checked': 7871, 'oracle_area_once_checks': 6482,
        'oracle_logical_time_stamp_checks': 463, 'oracle_distinct_reference_samples': 292,
        'oracle_case_precision_checkpoints': 8, 'oracle_refinement_quantities_checked': 9,
        'oracle_resolved_self_order_estimates': 18, 'per_channel_checks_passed': True,
        'separate_positive_translation_and_wall_quadratures': True,
        'manufactured_positive_barrier_forced_reference_only': True,
        'physical_truth_validated': False, 'current_to_power_mapping_inferred': False,
        'host_or_owner_implementation_verified': False, 'interval_certification_claimed': False,
        'portable_executions_performed': False, 'packaging_reference_test_or_oracle_repeated': False,
        'old_test_suites_repeated': False, 'standalone_source_subset': False,
        'complete_baseline_checkout_required': True}
    return {'allowed_figure_paths': sorted(allowed_figures), 'results': results,
            'source_version_relationships': relationships}


def verify_root_reports(records, h, p, b, artifacts):
    documentation = records['documentation_association']
    assert documentation['schema'] == 'mitl-thermal-forced-feedback-documentation-association-v1'
    assert documentation['status'] == 'passed' and set(documentation['public_sha256']) == set(PUBLIC)
    assert all(p(name) == digest for name, digest in documentation['public_sha256'].items())
    artifacts(documentation['record_sha256'])
    assert documentation['initial_parser_executions'] == 17 and documentation['final_focused_parser_executions'] == 5
    assert documentation['unique22_parser_cases_claimed'] is False and documentation['quoted_scheduled_reference_checked'] is True
    assert documentation['scientific_producers_tests_or_oracles_reexecuted'] is False
    assert documentation['physical_water_material_ML_spectral_or_host_acceptance'] is False
    visual = records['visual_review']
    assert visual['schema'] == 'mitl-thermal-forced-feedback-root-visual-review-v1' and visual['status'] == 'passed'
    assert visual['PNG_figures_actually_viewed_by_root'] == 2
    assert visual['plots_or_scientific_execution_repeated'] is False and visual['physical_parameters_accepted'] is False
    artifacts(visual['QA_artifact_sha256'])
    selection = records['selection']
    assert selection['schema'] == 'mhdlab-upstream-selected-task-v1'
    assert selection['status'] == 'selected_pending_fresh_bounded_lease'
    assert selection['selected_task'] == documentation['next_task']
    assert selection['fresh_lease_required'] is True and selection['public_implementation_started'] is False
    assert selection['public_files_changed_by_selection'] == [] and selection['numerical_execution_by_selection'] is False
    for key in ('proposal', 'inventory', 'conditional_selection_preserved', 'predecessor_acceptance'):
        reference = selection[key]
        assert h(str(Path(reference['path']).relative_to(WORK))) == reference['sha256']


def load_json_bytes(data):
    from prepare_delivery import loads
    return loads(data)


def main():
    payload = WORK/'delivery-preparation/payload'
    preparation = load(payload/'preparation.json')
    head = clean_head(preparation['source_commit'])
    assert preparation['base_commit'] == BASE
    assert not OUT.exists() and not OUT.with_suffix('.tar.gz').exists()
    assert load(payload/'source_file_list.json') == {'byte_identical_public_files': list(PUBLIC), 'packaging_wrappers': list(WRAPPERS)}
    assert len(PUBLIC) == 5 and len(WRAPPERS) == 2
    assert {str(path.relative_to(payload/'source')) for path in (payload/'source').rglob('*') if path.is_file()} == set(PUBLIC)|set(WRAPPERS)
    assert not (payload/'source/mhdlab/__init__.py').exists()
    for name in PUBLIC:
        assert (payload/'source'/name).read_bytes() == (REPO/name).read_bytes()
    context = dependency_context()
    assert context == preparation['dependency_context'] == load(payload/'dependency_context.json')
    configured_inputs = input_contract()
    assert configured_inputs == preparation['input_contract']
    records = {key: load(WORK/name) for key, name in REPORT_PATHS.items()}
    contract = verify_contracts(records, configured_inputs)
    allowed_figures = contract['allowed_figure_paths']
    next_task = records['selection']['selected_task']
    assert isinstance(next_task, str) and next_task.strip()
    shutil.copytree(payload, OUT)
    evidence = OUT/'evidence'
    evidence.mkdir()
    try:
        active_log = Path(os.readlink('/proc/self/fd/1')).resolve()
    except OSError:
        active_log = None
    copied_inputs, omitted, copied_root_files = [], [], []

    def copy(path, relative):
        assert not path.is_symlink()
        digest = sha(path)
        target = evidence/relative
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, target)
        assert sha(target) == digest
        copied_inputs.append({'source': str(path), 'archive': str(target.relative_to(OUT)), 'sha256': digest})

    for path in WORK.iterdir():
        if path.is_file() and path.suffix in TEXT_SUFFIXES and path.resolve() != active_log:
            copy(path, Path(path.name))
            copied_root_files.append(path.name)
    for folder in EVIDENCE_DIRS:
        for path in (WORK/folder).rglob('*'):
            assert not path.is_symlink()
            if not path.is_file():
                continue
            relative = path.relative_to(WORK)
            if excluded(relative, allowed_figures):
                omitted.append({'path': str(relative), 'sha256': sha(path), 'bytes': path.stat().st_size,
                    'reason': 'Cache, temporary fixture, failed staging data or unselected figure omitted from this new reference evidence.'})
            else:
                copy(path, relative)
    commands_raw = (evidence/'commands.jsonl').read_bytes()
    snapshot = command_snapshot_prefix(commands_raw, (WORK/'commands.jsonl').read_bytes())
    helper_pins = {name: sha(WORK/name) for name in ('prepare_delivery.py', 'freeze_delivery.py', 'verify_delivery.py', 'complete_pass.py')}
    projections = []
    for path in evidence.rglob('*'):
        if not path.is_file() or path.suffix not in TEXT_SUFFIXES:
            continue
        for prefix, replacement in PROJECTIONS:
            data = path.read_bytes()
            if prefix in data:
                assert replacement not in data
                path.write_bytes(data.replace(prefix, replacement))
                projections.append({'path': str(path.relative_to(OUT)), 'original_sha256': hashlib.sha256(data).hexdigest(),
                    'portable_sha256': sha(path), 'replacements': data.count(prefix), 'source_prefix_hex': prefix.hex(),
                    'replacement': replacement.decode(), 'scope': 'Archive-only machine-directory projection; local raw bytes unchanged.'})
    save(OUT/'portable_path_projections.json', projections)
    save(OUT/'excluded_evidence.json', omitted)
    with (OUT/'thermal-forced-feedback-reference.patch').open('wb') as stream:
        subprocess.run(['git', 'diff', '--binary', BASE, head], cwd=REPO, stdout=stream, check=True)
    verification = {'schema': 'mitl-thermal-forced-feedback-reference-verification-v1',
        'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'source_commit': head, 'base_commit': BASE, 'input_contract': configured_inputs,
        'dependency_context': context, 'package_kind': 'patch_over_exact_complete_baseline',
        'results': contract['results'], 'records': records, 'record_paths': REPORT_PATHS,
        'source_version_relationships': contract['source_version_relationships'],
        'record_sha256': {key: sha(WORK/name) for key, name in REPORT_PATHS.items()},
        'allowed_figure_paths': allowed_figures, 'copied_input_sha256': copied_inputs,
        'public_files_byte_identical': len(PUBLIC), 'packaging_wrappers': len(WRAPPERS),
        'commits': subprocess.check_output(['git', 'log', '--reverse', '--format=%H %s', BASE+'..'+head], cwd=REPO, text=True).splitlines(),
        'source_helper_sha256': helper_pins,
        'command_snapshot': {**snapshot, 'path': 'evidence/commands.jsonl',
            'copied_root_files': sorted(copied_root_files),
            'later_local_completion_repairs_may_exist': True,
            'historical_helper_policy': 'Archive helper bytes are immutable historical snapshots; later local repairs must explicitly bind them and preserve the initial failure.'},
        'next_task': next_task,
        'limits': ['Manufactured stationary one-patch forced thermal/inventory reference with explicit constant areal heat capacity.',
            'Strictly positive base activation barrier and fixed kinetic reference coverage remain separate from supplied removal/internal costs and expected translation.',
            'Fresh transformed-IVP/direct-positive-channel references and finite refinement estimate numerical changes, not certified errors or physical uncertainty.',
            'No physical water/material calibration, source history, observed-current power conversion, FLASH, gap, CR or owner transaction is supplied.',
            'Five-file patch requires the exact complete baseline. No standalone package, initializer workaround, portable execution or prior passing-case replay is claimed.']}
    save(OUT/'verification.json', verification)
    save(OUT/'next_task.json', {'task': next_task, 'selection_evidence': 'evidence/'+REPORT_PATHS['selection']})
    (OUT/'systems-mitl-thermal-forced-feedback-reference-10192026.md').write_text(f'''# Manufactured forced thermal/inventory reference

Five public files are byte-identical to `{head}`. Apply the patch over the
complete checkout at `{BASE}`. README/requirements are wrappers; no initializer
replacement, standalone package or portable execution is claimed.

This new manufactured reference couples positive-activation-energy,
fixed-reference coverage-dependent release to wall temperature under a fully
supported prescribed power schedule. Input, removal, internal, continuum expected
translation, gross wall debit and signed net thermal change remain separate.
Fresh tests, parser controls, saved trajectories, independent transformed-IVP and
direct positive channel quadrature, refinement and source-version records are
retained. Finite numerical changes are estimates, not certified error bounds or
physical parameter validation. Previous zero-power and zero-barrier references
are separate historical evidence and are not replayed for this pass.

Commands form an immutable complete-record byte prefix; later verification and
completion commands may append. Archived helper hashes are historical snapshots;
any later local repair must preserve its initial failure and bind that archived
hash. Reversible machine-directory projections leave raw local evidence unchanged.
Assembly runs no model, oracle, test suite, prior source or portable environment.

Next selected task: {next_task}
''')
    manifest = {str(path.relative_to(OUT)): sha(path) for path in OUT.rglob('*') if path.is_file() and path.name != 'manifest.sha256.json'}
    save(OUT/'manifest.sha256.json', manifest)
    words = [bytes.fromhex(value).decode() for value in ('6f70656e6169', '63686174677074', '636c61756465', '636f646578')]
    prohibited = re.compile(r'\b(?:'+'|'.join(words)+r')\b', re.I)
    allowed_archive_figures = {'evidence/'+name for name in allowed_figures}
    for path in OUT.rglob('*'):
        assert not path.is_symlink()
        if path.is_file():
            assert not excluded(path.relative_to(OUT), allowed_archive_figures)
            if path.suffix in TEXT_SUFFIXES:
                assert not prohibited.search(path.read_text()), str(path)
    clean_head(head)
    assert all(sha(REPO/name) == preparation['public_source_sha256'][name] for name in PUBLIC)
    assert all(sha(Path(item['source'])) == item['sha256'] for item in copied_inputs)
    assert all(sha(WORK/item['path']) == item['sha256'] for item in omitted)
    assert all(sha(WORK/name) == digest for name, digest in helper_pins.items())
    command_snapshot_prefix(commands_raw, (WORK/'commands.jsonl').read_bytes())
    archive = OUT.with_suffix('.tar.gz')
    with tarfile.open(archive, 'w:gz') as tar:
        tar.add(OUT, arcname=OUT.name)
    record = {'folder': str(OUT), 'archive': str(archive), 'sha256': sha(archive), 'bytes': archive.stat().st_size,
        'source_commit': head, 'base_commit': BASE, 'manifest_entries': len(manifest),
        'public_files_byte_identical': len(PUBLIC), 'packaging_wrappers': len(WRAPPERS),
        'manifest_sha256': sha(OUT/'manifest.sha256.json'), 'verification_sha256': sha(OUT/'verification.json')}
    save(WORK/'frozen_delivery.json', record)
    print(json.dumps(record, indent=2))


if __name__ == '__main__':
    main()
