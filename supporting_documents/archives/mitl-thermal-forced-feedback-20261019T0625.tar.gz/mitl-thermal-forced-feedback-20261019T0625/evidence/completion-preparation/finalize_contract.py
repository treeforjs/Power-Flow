"""Pin final saved metadata and parse helpers without importing/executing them."""
import argparse
import ast
import hashlib
import json
from pathlib import Path
import subprocess

WORK=Path(__file__).resolve().parents[1]
REPO=Path('/workspace/Power-Flow')
BASE='3be2c9b7cf9fdc587eb422f42ec06b714f897acb'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def save(path,value):
    Path(path).write_text(json.dumps(value,indent=2,allow_nan=False)+'\n')


def assignment(tree,name):
    values=[node.value for node in ast.walk(tree) if isinstance(node,ast.Assign)
        and any(isinstance(target,ast.Name) and target.id==name for target in node.targets)]
    assert len(values)==1,name
    def literal(node):
        if isinstance(node,ast.Name):
            return assignment(tree,node.id)
        if isinstance(node,ast.Tuple):
            return tuple(literal(item) for item in node.elts)
        return ast.literal_eval(node)
    return literal(values[0])


def git(*args):
    return subprocess.check_output(['git',*args],cwd=REPO).decode().strip()


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--approved-head',required=True)
    parser.add_argument('--helper-sha256',action='append',required=True)
    parser.add_argument('--record-sha256',action='append',required=True)
    args=parser.parse_args()
    status_path=WORK.parent/'mitl-upstream-status.json';before=sha(status_path)
    names=['prepare_delivery.py','freeze_delivery.py','verify_delivery.py']
    helpers={name:sha(WORK/name) for name in names}
    assert helpers==dict(item.split('=',1) for item in args.helper_sha256)
    assert len(args.helper_sha256)==3
    trees={name:ast.parse((WORK/name).read_text(),filename=name) for name in [*names,'complete_pass.py']}
    public=set(assignment(trees['complete_pass.py'],'PUBLIC'))
    assert len(public)==5 and public==set(assignment(trees['prepare_delivery.py'],'PUBLIC'))
    assert git('rev-parse','HEAD')==args.approved_head
    assert git('branch','--show-current')=='research/flash-publication-foundation'
    assert git('status','--porcelain')==''
    assert set(git('diff','--name-only',BASE,args.approved_head).splitlines())==public
    roles=assignment(trees['freeze_delivery.py'],'REPORT_PATHS')
    results=assignment(trees['freeze_delivery.py'],'results')
    assert len(roles)>=14 and {'producer_run','producer_completion','parser_guards',
        'tests_completion','core_freeze','static_core_review','oracle_completion',
        'oracle_report','oracle_summary','oracle_review',
        'documentation_association','visual_review','selection'}<=set(roles)
    expected_records=dict(item.split('=',1) for item in args.record_sha256)
    assert len(expected_records)==len(args.record_sha256) and set(expected_records)==set(roles)
    pins={role:sha(WORK/path) for role,path in roles.items()}
    assert pins==expected_records
    for name,tree in trees.items():
        assert not any(isinstance(node,ast.Raise) and isinstance(node.exc,ast.Call)
            and isinstance(node.exc.func,ast.Name) and node.exc.func.id=='RuntimeError'
            and node.exc.args and isinstance(node.exc.args[0],ast.Constant)
            and ('draft' in str(node.exc.args[0].value).lower()
                or 'not yet' in str(node.exc.args[0].value).lower()) for node in ast.walk(tree)),name
    records={role:load(WORK/path) for role,path in roles.items()}
    assert records['tests_completion']['all_checks_passed'] is True
    assert records['tests_completion']['qualified_unique_new_test_cases']==32
    assert records['tests_completion']['test_case_executions']==33
    assert records['oracle_completion']['all_checks_passed'] is True
    assert records['selection']['schema']=='mhdlab-upstream-selected-task-v1'
    assert records['selection']['status']=='selected_pending_fresh_bounded_lease'
    public_pins={name:sha(REPO/name) for name in sorted(public)}
    contract={'schema':'mitl-thermal-forced-feedback-completion-contract-v1','ready_for_root_execution':True,
        'approved_head':args.approved_head,'public_source_sha256':public_pins,
        'metadata_helpers_sha256':helpers,'record_paths':roles,'record_sha256':pins,
        'result_values':results,'pending':[],
        'execution_limit':'AST/data-pin prepared only; root alone executes after actual archive verification.'}
    save(WORK/'completion-preparation/contract.json',contract)
    notes={'schema':'mitl-thermal-forced-feedback-completion-preparation-v1','status':'ready_root_execution_pending_archive',
        'approved_head':args.approved_head,'baseline_commit':BASE,'AST_parse_only':True,
        'completion_helper_imported_or_executed':False,'status_or_lease_mutated':False,
        'new_or_old_producer_tests_or_oracles_repeated':False,'source_queries_performed':False,
        'old_queue_2_through_7_and_all_prior_evidence_preserved':True,
        'physical_surface_VUV_owner_FLASH_and_fulltext_gates_preserved':True,
        'new_forced_branch_only_separately_qualified_after_fresh_reference':True,
        'initial_and_focused_test_source_qualifiers_preserved':True,
        'parser_source_and_oracle_checkpoint_lineage_preserved':True,
        'archived_helper_bytes_strict':True,
        'commands_snapshot_policy':'Exact newline-terminated complete parsed JSONL byte prefix; later local commands may append.',
        'actual_archive_required_at_execution':True,'next':records['selection']['selected_task']}
    save(WORK/'completion-preparation/notes.json',notes)
    assert sha(status_path)==before
    report={'schema':'mitl-thermal-forced-feedback-completion-AST-readiness-v1','status':'passed',
        'approved_head':args.approved_head,'AST_parse_only':True,'completion_helper_imported_or_executed':False,
        'scientific_or_source_operations_executed':False,'status_or_lease_mutated':False,
        'status_before_sha256':before,'status_after_sha256':sha(status_path),
        'record_role_count':len(roles),'public_file_count':len(public),'record_sha256':pins,
        'public_source_sha256':public_pins,'metadata_helpers_sha256':helpers,
        'artifact_sha256':{name:sha(WORK/name) for name in ['complete_pass.py',
            'completion-preparation/contract.json','completion-preparation/notes.json',
            'completion-preparation/finalize_contract.py']}}
    save(WORK/'completion-preparation/AST-readiness.json',report)
    print(json.dumps(report,indent=2))


if __name__=='__main__':
    main()
