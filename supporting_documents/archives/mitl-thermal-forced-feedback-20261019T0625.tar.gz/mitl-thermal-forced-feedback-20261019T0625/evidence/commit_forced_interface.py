"""Commit the qualified forced-feedback command, fixtures and guide."""
import hashlib
import json
from pathlib import Path
import subprocess

repo=Path('/workspace/Power-Flow')
work=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def run(*args):
    print(json.dumps(list(args)),flush=True)
    subprocess.run(args,cwd=repo,check=True)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()=='8ef1c242ef4574a44015bcbd4f4d36e62d8af2a5'
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=repo,text=True)
assert sha(work/'documentation-association.json')=='40ca0ef1af2a779960ee9e2017e0073ffc5f59f8b4cbc8dbea868cae8078e7eb'
record=json.loads((work/'documentation-association.json').read_text())
assert record['status']=='passed' and len(record['public_sha256'])==5
assert all(sha(repo/name)==digest for name,digest in record['public_sha256'].items())
paths=['tools/run_thermal_forced_feedback_reference.py','configs/thermal_forced_feedback_manufactured.json',
 'docs/thermal_forced_feedback_reference.md']
run('git','add','--',*paths)
run('git','diff','--cached','--check')
run('git','-c','user.name=Research Development','-c','user.email=research@local.invalid',
 'commit','-m','Expose manufactured forced-feedback runs and independent validation')
run('git','show','--format=fuller','--stat','HEAD')
run('git','status','--short')
