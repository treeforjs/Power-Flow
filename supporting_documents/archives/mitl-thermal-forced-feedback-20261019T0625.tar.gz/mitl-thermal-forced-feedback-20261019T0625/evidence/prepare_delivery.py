"""Prepare a five-file thermal-forced-feedback patch over an exact complete checkout."""
import argparse
import ast
from decimal import Decimal
import hashlib
import json
import math
from pathlib import Path
import re
import shutil
import subprocess

WORK = Path(__file__).resolve().parent
REPO = Path('/workspace/Power-Flow')
BASE = '3be2c9b7cf9fdc587eb422f42ec06b714f897acb'
HEAD = '3bd20e44ba617cca44cbac2df993e1face2ec221'
OUT = Path('/workspace/handoffs/mitl-thermal-forced-feedback-20261019T0625')
PUBLIC = ('mhdlab/thermal_forced_feedback_reference.py', 'tests/test_thermal_forced_feedback_reference.py',
    'tools/run_thermal_forced_feedback_reference.py', 'configs/thermal_forced_feedback_manufactured.json',
    'docs/thermal_forced_feedback_reference.md')
WRAPPERS = ('README.md', 'requirements.txt')
BASELINE_CONTEXT = ('requirements.txt', 'pyproject.toml', 'mhdlab/__init__.py', 'mhdlab/thermal_feedback_reference.py', 'mhdlab/thermal_power_reference.py')


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024*1024), b''):
            digest.update(block)
    return digest.hexdigest()


def object_pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('duplicate JSON key')
        result[key] = value
    return result


def finite_float(value):
    result = float(value)
    if not math.isfinite(result):
        raise ValueError('nonfinite JSON number')
    if result == 0 and Decimal(value) != 0:
        raise ValueError('nonzero JSON number underflows its representation')
    return result


def loads(data):
    return json.loads(data, object_pairs_hook=object_pairs, parse_float=finite_float,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def load(path):
    return loads(Path(path).read_text())


def save(path, value):
    Path(path).write_text(json.dumps(value, indent=2, allow_nan=False)+'\n')


def baseline_bytes(name):
    return subprocess.check_output(['git', 'show', BASE+':'+name], cwd=REPO)


def clean_head(expected):
    assert HEAD is not None and re.fullmatch('[0-9a-f]{40}', expected) and expected == HEAD
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == expected
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=REPO, text=True).strip()
    subprocess.run(['git', 'merge-base', '--is-ancestor', BASE, expected], cwd=REPO, check=True)
    changed = subprocess.check_output(['git', 'diff', '--name-only', BASE, expected], cwd=REPO, text=True).splitlines()
    assert set(changed) == set(PUBLIC) and len(changed) == len(PUBLIC)
    return expected


def dependency_context():
    pins = {}
    for name in BASELINE_CONTEXT:
        content = baseline_bytes(name)
        digest = hashlib.sha256(content).hexdigest()
        assert sha(REPO/name) == digest
        pins[name] = digest
    imports = {}
    for name in PUBLIC:
        if not name.endswith('.py'):
            continue
        tree = ast.parse((REPO/name).read_text())
        imports[name] = sorted({node.module or '' for node in ast.walk(tree) if isinstance(node, ast.ImportFrom)}
            | {alias.name for node in ast.walk(tree) if isinstance(node, ast.Import) for alias in node.names})
    return {'required_complete_baseline_checkout': True, 'baseline_commit': BASE,
        'standalone_source_subset': False, 'empty_initializer_added': False,
        'unchanged_context_sha256': pins, 'declared_imports': imports,
        'requirements_wrapper_origin': 'Exact bytes of baseline requirements.txt; complete checkout setup remains required.'}


def input_contract():
    """Bind the eventual frozen manufactured config without constructing a model."""
    name = 'configs/thermal_forced_feedback_manufactured.json'
    config = load(REPO/name)
    assert config['schema'] == 'mhdlab-thermal-forced-feedback-manufactured-config-v1'
    assert config['parameter_status'] == 'manufactured'
    assert all(config[key].strip() for key in ('provenance', 'scope', 'schedule_time_convention'))
    case_ids = [case['case_id'] for case in config['cases']]
    assert len(case_ids) == len(set(case_ids)) and config['refinement_case_id'] in case_ids
    trajectories = samples = 0
    for case in config['cases']:
        assert case['purpose'].strip() and type(case['duration_s']) in {int, float} and case['duration_s'] > 0
        segments = case['segments']
        assert segments and segments[0]['start_s'] == 0 and segments[-1]['stop_s'] == case['duration_s']
        assert all(a['stop_s'] == b['start_s'] for a, b in zip(segments, segments[1:]))
        for segment in segments:
            assert type(segment['power_w_m2']) in {int, float} and segment['power_w_m2'] >= 0
            assert segment['stop_s'] > segment['start_s'] and segment['power_provenance'].strip()
        problem, reservoir = case['problem'], case['problem']['reservoir']
        assert problem['parameter_status'] == 'manufactured' and problem['parameter_provenance'].strip()
        assert problem['energy_reference'].strip()
        assert type(reservoir['activation_energy_ev']) in {int, float} and reservoir['activation_energy_ev'] > 0
        assert reservoir['reference_coverage_m2'] > 0 and reservoir['max_coverage_m2'] > 0
        assert 0 <= problem['initial_coverage_m2'] <= reservoir['max_coverage_m2']
        assert reservoir['kinetic_provenance'].strip() and reservoir['energy_provenance'].strip()
        assert problem['areal_heat_capacity_j_m2_k'] > 0 and problem['patch_area_m2'] > 0
        for grid in case['step_grids']:
            assert len(grid) == len(segments) and all(type(step) is int and step > 0 for step in grid)
            trajectories += 1
            samples += sum(grid)+1
    return {'config_path': name, 'config_sha256': sha(REPO/name), 'configuration': config,
        'declared_case_count': len(case_ids), 'declared_trajectory_count': trajectories,
        'declared_sample_count': samples, 'refinement_case_id': config['refinement_case_id'],
        'parameter_status': 'manufactured', 'strict_positive_base_barrier_declared': True,
        'physical_parameters_adopted': False, 'power_inferred_from_current_or_material': False,
        'host_or_production_feedback_installed': False,
        'raw_decimal_schedule_checks': 'Raw support and representation checks are bound to separate frozen CLI/version evidence; this function only reads saved declarations.'}


def command_snapshot_prefix(snapshot, live):
    """Accept only an immutable newline-terminated prefix of complete JSONL records."""
    assert snapshot and snapshot.endswith(b'\n') and live.startswith(snapshot)
    assert all(isinstance(loads(line), dict) for line in snapshot.splitlines())
    return {'sha256': hashlib.sha256(snapshot).hexdigest(), 'bytes': len(snapshot),
        'complete_records': len(snapshot.splitlines()),
        'qualification': 'Exact complete-record byte prefix; later verification/completion records may append.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--expected-head', required=True)
    args = parser.parse_args()
    head = clean_head(args.expected_head)
    for name in PUBLIC:
        assert (REPO/name).is_file() and not (REPO/name).is_symlink()
    context = dependency_context()
    contract = input_contract()
    payload = WORK/'delivery-preparation/payload'
    assert not payload.exists() and not OUT.exists() and not OUT.with_suffix('.tar.gz').exists()
    source = payload/'source'
    source.mkdir(parents=True)
    for name in PUBLIC:
        target = source/name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(REPO/name, target)
    (source/'requirements.txt').write_bytes(baseline_bytes('requirements.txt'))
    (source/'README.md').write_text(f'''# Manufactured forced thermal/inventory reference patch

Five new public files and a patch are pinned to the approved checkout. Apply the
patch to the complete baseline at `{BASE}` before importing, running or testing
this reference. This source/ review subset is not a standalone package. No
initializer replacement or portable execution is supplied. The requirements
wrapper copies baseline requirements.txt byte-for-byte; retain the complete
checkout's setup and initializer.

The new reference couples a strictly positive manufactured activation barrier,
fixed-reference coverage-dependent release, finite parent inventory and one
stationary wall temperature under an explicit finite nonnegative power schedule.
Removal, internal energy, expected thermal translation, gross wall debit, input
and signed net thermal changes remain separate. Manufactured inputs do not
establish water/foil calibration, experimental heating, FLASH output or host use.

Fresh tests, parser controls, one saved trajectory batch, a separately developed
transformed coupled-IVP/direct-positive-channel oracle, finite refinement and
signed residuals remain separately pinned. Older zero-power or zero-barrier
passes are not replayed or promoted to evidence for this new reference. Actual
recorded failures, corrections and source versions are preserved. Numerical
changes are estimates, not interval certificates or physical uncertainty.
''')
    save(payload/'source_file_list.json', {'byte_identical_public_files': list(PUBLIC), 'packaging_wrappers': list(WRAPPERS)})
    (payload/'source-files.sha256').write_text(''.join(f'{sha(source/name)}  {name}\n' for name in PUBLIC))
    (payload/'wrapper-files.sha256').write_text(''.join(f'{sha(source/name)}  {name}\n' for name in WRAPPERS))
    save(payload/'dependency_context.json', context)
    save(payload/'preparation.json', {'source_commit': head, 'base_commit': BASE,
        'input_contract': contract, 'dependency_context': context,
        'portable_execution_performed': False, 'physical_truth_validated': False,
        'public_source_sha256': {name: sha(REPO/name) for name in PUBLIC}})
    print(json.dumps({'payload': str(payload), 'source_commit': head, 'public_files': len(PUBLIC),
        'packaging_wrappers': len(WRAPPERS), 'complete_baseline_checkout_required': True}, indent=2))


if __name__ == '__main__':
    main()
