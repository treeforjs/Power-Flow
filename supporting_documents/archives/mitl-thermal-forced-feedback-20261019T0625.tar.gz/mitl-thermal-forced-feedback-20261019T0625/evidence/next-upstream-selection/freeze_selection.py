"""Bind the next task to saved acceptance records without numerical execution."""

from __future__ import annotations

from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
PASS = ROOT.parent
PUBLIC = Path("/workspace/Power-Flow")
CORE = "16033899c949896ca346eb6cfb6beb9cdd9d9253c1a110fa9f057a9b8bdeac4d"


def pin(path: Path) -> dict[str, str]:
    return {"path": str(path), "sha256": sha256(path.read_bytes()).hexdigest()}


def read(name: str, expected: str | None = None) -> tuple[dict, dict[str, str]]:
    path = PASS / name
    record = pin(path)
    if expected is not None and record["sha256"] != expected:
        raise ValueError(f"saved acceptance pin mismatch: {name}")
    return json.loads(path.read_text()), record


def require(condition: bool, reason: str) -> None:
    if not condition:
        raise ValueError(reason)


def write(name: str, record: dict) -> None:
    path = ROOT / name
    require(not path.exists(), f"refusing to replace frozen planning artifact: {name}")
    path.write_text(json.dumps(record, indent=2, allow_nan=False) + "\n")


def main() -> None:
    require(pin(PUBLIC / "mhdlab/thermal_forced_feedback_reference.py")["sha256"] == CORE, "public core changed")
    proposal, proposal_pin = read(
        "next-upstream-selection/matched_width_power_proposal.json",
        "21f5bb9ab6cc97eec06f3c8ddc249bdcd59f23fe30ab84587409a297476d0ca9",
    )
    independent, independent_pin = read(
        "independent-verification/completion.json",
        "856635aedd8f5b8c5559a019bb8d3275fb427d12c6e0ed95b4a18e07cc83a14d",
    )
    report, report_pin = read(
        "independent-verification/oracle-initial/report.json",
        "d6e2932ed8e21914217ff5b34fcbe4a173cbc9cadd6828e77620522d97f420bf",
    )
    producer, producer_pin = read(
        "producer/completion.json",
        "835bf37391aac90a8495be19b3a2301091934b38af1120a24dbb7a6baccf6b15",
    )
    tests, tests_pin = read("tests/completion.json")
    review, review_pin = read("oracle-review/completion.json")
    core_review, core_review_pin = read(
        "core-review/completion.json",
        "4a75363faac81b89f29f274486f9d9bcf302741f5a0ec86c80c4da1e62b3ae7d",
    )
    producer_report_pin = pin(PASS / independent["producer_report"])
    core_path = "mhdlab/thermal_forced_feedback_reference.py"
    require(independent["status"] == "passed" and independent["all_checks_passed"] is True, "independent acceptance absent")
    require(report["status"] == "passed" and report["all_checks_passed"] is True, "independent report not passed")
    require(independent["report_sha256"] == report_pin["sha256"], "independent report association mismatch")
    require((independent["cases"], independent["saved_trajectories"], independent["saved_sample_rows_checked"]) == (4, 7, 463), "unexpected saved benchmark scope")
    require(independent["independent_oracle_numerical_runs"] == 1, "oracle replay count changed")
    require(independent["positive_core_or_CLI_calls_by_oracle"] == 0 and independent["core_imports_in_oracle"] == [], "oracle imported or called production core")
    require(independent["old_solver_or_suite_calls"] == 0, "old numerical replay declared")
    require(independent["producer_code_sha256"][core_path] == CORE, "oracle core association mismatch")
    require(producer["reviewed_source_sha256"][core_path] == CORE, "producer core association mismatch")
    require(producer["positive_batch_count"] == 1 and producer["open_substantive_findings"] == [], "producer acceptance mismatch")
    require(producer_report_pin["sha256"] == independent["producer_report_sha256"] == producer["report_sha256"], "producer report association mismatch")
    require(tests["all_checks_passed"] is True and tests["scientific_core_unchanged"] is True, "tests lack final qualification")
    require((tests["qualified_unique_new_test_cases"], tests["test_case_executions"], tests["unchanged_passing_cases_repeated"]) == (32, 33, 0), "test scope or replay changed")
    require(tests["initial_failures_preserved"] is True, "initial test failure not preserved")
    require(tests["public_source_sha256"][core_path] == CORE, "test core association mismatch")
    require(core_review["source_changes_requested"] is False, "static core review requests changes")
    require(review["owner_report_sha256"] == report_pin["sha256"], "final oracle review report association mismatch")
    require(review["findings"] == [] and review["source_changes_requested"] is False, "final oracle review has findings")
    require(review["completed_report_bound_without_numerical_replay"] is True, "final oracle review does not bind actual report")

    acceptance = {
        "schema": "mhdlab-width-power-predecessor-acceptance-v1",
        "status": "actual_saved_forced_scalar_acceptance_bound",
        "core_sha256": CORE,
        "records": {
            "core_review": core_review_pin,
            "tests": tests_pin,
            "producer": producer_pin,
            "producer_report": producer_report_pin,
            "independent_completion": independent_pin,
            "independent_report": report_pin,
            "final_independent_method_review": review_pin,
        },
        "observed_scope": {"cases": 4, "trajectories": 7, "saved_rows": 463},
        "test_history": {
            "unique_cases": 32,
            "case_executions": 33,
            "initial_passes": 31,
            "initial_test_only_failures": 1,
            "focused_corrected_case_passes": 1,
            "scientific_core_unchanged": True,
            "unchanged_passing_cases_repeated": 0,
            "blanket_final_test_bytes_run_claimed": False,
        },
        "independent_qualification": independent["qualification"],
        "preserved_static_aggregation_correction": independent["static_aggregation_correction"],
        "observed_core_model_batches": 1,
        "observed_independent_numeric_batches": 1,
        "planning_readback_only": True,
        "new_or_old_numerical_execution_by_selection": False,
        "acceptance_limits": "Bounded manufactured scalar model qualification only; no physical water/material, host, gap, MHD or observation acceptance.",
    }
    write("predecessor-acceptance.json", acceptance)
    selection = {
        "schema": "mhdlab-upstream-selected-task-v1",
        "status": "selected_pending_fresh_bounded_lease",
        "selected_utc": datetime.now(timezone.utc).isoformat(),
        "task_id": proposal["task_id"],
        "selected_task": "Manufactured matched-total-input uniform versus nonuniform width-patch heating with coupled positive-barrier finite-inventory release.",
        "proposal": proposal_pin,
        "inventory": pin(ROOT / "inventory.json"),
        "conditional_selection_preserved": pin(ROOT / "conditional-selection.json"),
        "predecessor_acceptance": pin(ROOT / "predecessor-acceptance.json"),
        "selection_reason": "The coupled scalar model passed its actual saved independent reference, opening a bounded new width-power adapter. Existing matched-uniform source ledgers preserve supplied thermal mixtures rather than evolving distinct power responses.",
        "next_batch": {
            "new_scalar_histories": 3,
            "steps_each": 64,
            "total_distinct_samples": 195,
            "hypotheses": 2,
            "independent_patches_per_hypothesis": 3,
            "exact_area_weights": ["1/4", "1/2", "1/4"],
            "uniform_power_w_m2": [60_000_000, 60_000_000, 60_000_000],
            "nonuniform_power_w_m2": [90_000_000, 30_000_000, 90_000_000],
            "reused_identical_histories_re_evolved": False,
            "old_saved_cases_replayed": False,
            "sign_or_magnitude_of_difference_assumed": False,
        },
        "public_implementation_started": False,
        "fresh_lease_required": True,
        "public_files_changed_by_selection": [],
        "numerical_execution_by_selection": False,
        "retained_limits_and_gates": proposal["limits"] + proposal["retained_gates"][1:],
    }
    write("selection.json", selection)
    print(json.dumps({"selection": pin(ROOT / "selection.json"), "predecessor_acceptance": pin(ROOT / "predecessor-acceptance.json"), "numerical_execution": False}, indent=2))


if __name__ == "__main__":
    main()
