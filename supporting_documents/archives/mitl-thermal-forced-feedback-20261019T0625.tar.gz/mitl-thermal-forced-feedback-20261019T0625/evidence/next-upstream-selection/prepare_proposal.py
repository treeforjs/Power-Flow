"""Write a conditional next-task plan using declarations and exact arithmetic only."""

from __future__ import annotations

from fractions import Fraction
from hashlib import sha256
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
PASS = ROOT.parent
PUBLIC = Path("/workspace/Power-Flow")
STATUS = Path("/workspace/research_work/mitl-upstream-status.json")


def pin(path: Path) -> dict[str, str]:
    return {"path": str(path), "sha256": sha256(path.read_bytes()).hexdigest()}


def exact(value: Fraction) -> dict[str, str | float]:
    return {
        "numerator": str(value.numerator),
        "denominator": str(value.denominator),
        "value": float(value),
    }


def write(name: str, document: dict) -> None:
    path = ROOT / name
    if path.exists():
        raise ValueError(f"refusing to replace existing planning artifact: {path}")
    path.write_text(json.dumps(document, indent=2, allow_nan=False) + "\n")


def signature(problem: dict, segments: list[dict], duration: float) -> dict:
    reservoir = problem["reservoir"]
    return {
        "duration_s": duration,
        "segments": [
            {key: segment[key] for key in ("start_s", "stop_s", "power_w_m2")}
            for segment in segments
        ],
        "kinetics": {
            key: reservoir[key]
            for key in (
                "attempt_frequency_s", "activation_energy_ev", "coverage_coefficient",
                "reference_coverage_m2", "max_coverage_m2", "desorption_energy_ev",
                "internal_energy_ev",
            )
        },
        "initial_and_thermal": {
            key: problem[key]
            for key in (
                "initial_coverage_m2", "initial_temperature_k",
                "areal_heat_capacity_j_m2_k", "temperature_min_k", "temperature_max_k",
            )
        },
    }


def main() -> None:
    current_config_path = PUBLIC / "configs/thermal_forced_feedback_manufactured.json"
    current = json.loads(current_config_path.read_text())
    status = json.loads(STATUS.read_text())
    edges = [Fraction(-1, 512), Fraction(-1, 1024), Fraction(1, 1024), Fraction(1, 512)]
    length = Fraction(1, 128)
    areas = [(right - left) * length for left, right in zip(edges, edges[1:])]
    total_area = sum(areas, Fraction())
    uniform = [60_000_000] * 3
    nonuniform = [90_000_000, 30_000_000, 90_000_000]
    uniform_total_power = sum((area * power for area, power in zip(areas, uniform)), Fraction())
    nonuniform_total_power = sum((area * power for area, power in zip(areas, nonuniform)), Fraction())
    if uniform_total_power != nonuniform_total_power:
        raise ValueError("proposed power matching is not exact")

    reservoir = {
        "name": "manufactured_width_parent",
        "state_id": "M:manufactured-width-parent",
        "attempt_frequency_s": 100_000_000.0,
        "activation_energy_ev": 0.35,
        "desorption_energy_ev": 0.12,
        "internal_energy_ev": 0.03,
        "coverage_coefficient": 0.6,
        "reference_coverage_m2": 4e20,
        "max_coverage_m2": 4e20,
        "kinetic_provenance": "Manufactured first-order positive-base-barrier parameters with fixed supplied Nref; no physical surface inference.",
        "energy_provenance": "Manufactured independent removal D and internal I; neither is inferred from kinetic Ea.",
    }
    problem = {
        "reservoir": reservoir,
        "initial_coverage_m2": 2e20,
        "initial_temperature_k": 900.0,
        "areal_heat_capacity_j_m2_k": 0.05,
        "patch_area_m2": 1.0,
        "temperature_min_k": 600.0,
        "temperature_max_k": 1300.0,
        "parameter_status": "manufactured",
        "parameter_provenance": "Independent stationary manufactured width patches; unit reference area supplies areal histories only.",
        "energy_reference": "U_ads=-D*N; gas internal I and expected translation 2*kB*T remain separate; gross input and withdrawal are independently retained.",
    }
    duration = 2e-7
    new_cases = []
    for label, power in (("uniform_power", 60_000_000), ("edge_power", 90_000_000), ("middle_power", 30_000_000)):
        segments = [{"start_s": 0.0, "stop_s": duration, "power_w_m2": power}]
        new_cases.append({
            "case_id": label,
            "power_w_m2": power,
            "steps": 64,
            "signature": signature(problem, segments, duration),
        })
    old_cases = [
        {"case_id": case["case_id"], "signature": signature(case["problem"], case["segments"], case["duration_s"])}
        for case in current["cases"]
    ]
    matches = [
        {"new_case_id": new["case_id"], "saved_case_id": old["case_id"]}
        for new in new_cases for old in old_cases if new["signature"] == old["signature"]
    ]
    if matches:
        raise ValueError("proposal duplicates an existing full scalar input case")

    kb = Fraction("1.380649e-23")
    elementary_charge = Fraction("1.602176634e-19")
    capacity = Fraction.from_float(problem["areal_heat_capacity_j_m2_k"])
    initial_t = Fraction.from_float(problem["initial_temperature_k"])
    initial_n = Fraction.from_float(problem["initial_coverage_m2"])
    tmax = Fraction.from_float(problem["temperature_max_k"])
    duration_exact = Fraction.from_float(duration)
    upper = initial_t + Fraction(max(nonuniform)) * duration_exact / capacity
    cost_bound = (
        (Fraction.from_float(reservoir["desorption_energy_ev"]) + Fraction.from_float(reservoir["internal_energy_ev"]))
        * elementary_charge + 2 * kb * tmax
    )
    lower = initial_t - initial_n * cost_bound / capacity
    if not Fraction(600) < lower <= upper < Fraction(1300):
        raise ValueError("proposed whole-inventory domain bounds do not fit supplied support")

    inputs = {
        "core": pin(PUBLIC / "mhdlab/thermal_forced_feedback_reference.py"),
        "core_freeze": pin(PASS / "core/source-freeze.json"),
        "core_static_review": pin(PASS / "core-review/completion.json"),
        "current_config": pin(current_config_path),
        "cached_status": pin(STATUS),
        "window_ledger": pin(PUBLIC / "mhdlab/window_source_ledger.py"),
        "source_resolution_guide": pin(PUBLIC / "docs/source_window_resolution.md"),
        "zero_barrier_power_guide": pin(PUBLIC / "docs/thermal_power_reference.md"),
    }
    inventory = {
        "schema": "mhdlab-width-power-next-task-inventory-v1",
        "scope": "Read-only declaration inventory, hashing and exact parameter arithmetic; no source evolution, tests, oracle or saved numerical-result replay.",
        "inputs": inputs,
        "cached_active_phase": status["active_phase"],
        "cached_next_work": status["next_work"],
        "existing_matched_uniform_control": {
            "path": str(PUBLIC / "mhdlab/window_source_ledger.py"),
            "quote": "Matched uniform width changes only width position; current/state/time/temperature and supplied independent energy-cost mixtures remain those of the original components.",
            "distinction": "That control redistributes an already supplied source mixture. It does not impose different width powers and evolve their coupled temperature/inventory response.",
        },
        "existing_current_scalar_case_signatures": old_cases,
        "proposed_scalar_case_signatures": new_cases,
        "matching_complete_current_scalar_inputs": matches,
        "novelty_scope": "No duplicate full scalar forcing/parameter case appears in the current forced-feedback batch; no claim of a global search of all unpublished work.",
    }
    write("inventory.json", inventory)
    proposal = {
        "schema": "mhdlab-matched-width-power-proposal-v1",
        "task_id": "manufactured-matched-width-power-feedback",
        "status": "conditional_on_current_forced_scalar_independent_acceptance",
        "purpose": "Quantify whether equal total prescribed input delivered uniformly or unevenly across independent width patches changes finite parent release and outgoing expected translation, before any transport or observation mapping.",
        "inputs": inputs,
        "inventory": pin(ROOT / "inventory.json"),
        "proposed_public_scope": [
            "mhdlab/thermal_width_power_reference.py",
            "tests/test_thermal_width_power_reference.py",
            "tools/run_thermal_width_power_reference.py",
            "configs/thermal_width_power_manufactured.json",
            "docs/thermal_width_power_reference.md",
        ],
        "geometry": {
            "status": "manufactured",
            "width_edges_m": [exact(item) for item in edges],
            "common_length_m": exact(length),
            "patch_areas_m2": [exact(item) for item in areas],
            "total_area_m2": exact(total_area),
            "area_weights": [exact(item / total_area) for item in areas],
            "no_actual_foil_geometry_association": True,
        },
        "power_hypotheses": {
            "uniform_w_m2": uniform,
            "nonuniform_w_m2": nonuniform,
            "exact_common_total_input_power_w": exact(uniform_total_power),
            "duration_s": duration,
            "canonical_duration_exact_s": exact(duration_exact),
            "exact_common_total_input_energy_j": exact(uniform_total_power * duration_exact),
            "matching": "Exact Fraction area-times-power equality of represented inputs over identical finite time support; no fitted scaling or renormalization.",
        },
        "common_scalar_problem": problem,
        "distinct_new_scalar_cases": new_cases,
        "execution_budget": {
            "distinct_new_histories": 3,
            "steps_per_history": 64,
            "samples_per_history": 65,
            "total_distinct_scalar_samples": 195,
            "reuse_map": {
                "uniform": ["uniform_power", "uniform_power", "uniform_power"],
                "nonuniform": ["edge_power", "middle_power", "edge_power"],
            },
            "no_re_evolution_for_reused_patch": True,
            "no_saved_case_replay": True,
            "refinement": "No automatic new refinement family. The unchanged scalar solver has its own qualification; compare these three new histories to fresh independent references. Any unresolved discrepancy requires a separately recorded affected scope.",
        },
        "a_priori_temperature_support": {
            "upper_k": exact(upper),
            "upper_reason": "Nonnegative gross withdrawal gives T<=T0+max(P)*duration/C_A.",
            "lower_k": exact(lower),
            "lower_reason": "At most N0 parents can leave, and each wall debit is bounded by D+I+2*kB*Tmax on the declared support; nonnegative input only raises this lower bound.",
            "qualification": "Represented-input algebraic bounds, conditional on nonnegative inventories and the stated debit law; not a physical material-temperature prediction.",
        },
        "adapter_requirements": [
            "Consume the three new scalar histories as areal quantities. Apply actual patch area once; never rescale their already extensive fields.",
            "Require common initial inventory, T, areal capacity, kinetic/internal/removal parameters, state identity and finite logical time grid across hypotheses, varying only prescribed power and its patch assignment.",
            "Associate each patch with its exact geometry and immutable scalar-history identity; left/right edge reuse is explicit, not a new integration.",
            "Export each patch's N,T,release flux, cumulative emitted number and all input/removal/internal/translation/gross-wall/net-thermal/adsorbate-reference channels, plus extensive totals and signed residuals.",
            "Evaluate instantaneous flux from the new coupled N,T at each saved logical time, retaining the existing approximate-exponential numerical contract; share each distinct evaluation across reused patches.",
            "Retain the full area/time/state/temperature mixture. Do not replace patch temperatures by a mean temperature or infer a single thermal velocity for a varying mixture.",
            "Form equal-input and aggregate channel comparisons with exact represented-input arithmetic where possible, with explicit projection and rounding diagnostics.",
            "Report actual signs and magnitudes of release, translation, temperature and ledger differences; do not encode an expected nonlinear enhancement.",
        ],
        "independent_acceptance": [
            "Freeze the adapter, inputs, verification plan and tolerances before its one new batch.",
            "Obtain fresh independent transformed-IVP/positive-channel-quadrature references for each of the three distinct forcing cases; do not call the production solver from the reference.",
            "Reuse each independent scalar reference for identical patches, preserving separate patch geometry and provenance.",
            "Check each saved patch N,T,flux and independent energy channels, exact common input, area once, whole-area initial inventory and aggregate conservation residuals.",
            "Use an independently formed patch aggregation and exact power identity; energy closure alone cannot establish correct nonlinear trajectories or emission allocation.",
            "Keep existing fixed linear full-width source/response invariances as separate qualified controls. They do not establish nonlinear power-to-release equivalence or spectral observability.",
        ],
        "limits": [
            "Manufactured stationary independent patches only; no lateral conduction, moving boundaries, phase change, radiation or field-derived heating.",
            "No physical water coverage, material kinetics, outgoing state branching, fragment transport or spectral discrimination claim.",
            "No FLASH, Hall, Quark owner implementation, host transaction, gap or separately owned chemistry/CR changes.",
            "Expected emitted translation 2*kB*T is a scalar energy channel; no species mass, velocity distribution or launch is supplied here.",
            "No absolute monolayer, VUV calibration or experimental clock registration is inferred.",
        ],
        "retained_gates": [
            "Current positive-Ea scalar must pass its actual frozen independent verification before this task is selected.",
            "Actual material coefficients, monolayer convention and initial pool allocation remain unavailable.",
            "Fe2O3(001) source metadata is verified but full text remains unavailable; adopt no parameters from it.",
            "Joly2000 and Li-Dylla1995 full-text access remains gated; do not retry unchanged blocked routes.",
            "Owner transport/response, physical VUV observation mapping, licensed FLASH setup and actual field/material interfaces retain their separate gates.",
        ],
        "numerical_execution_during_planning": False,
    }
    write("matched_width_power_proposal.json", proposal)
    conditional = {
        "schema": "mhdlab-upstream-conditional-selection-v1",
        "status": "waiting_for_current_independent_forced_scalar_acceptance",
        "candidate_task_id": proposal["task_id"],
        "proposal": pin(ROOT / "matched_width_power_proposal.json"),
        "required_before_final_selection": [
            "Actual saved current-pass independent report states acceptance and is pinned by SHA256.",
            "Its source, input and saved producer associations bind the final core and CLI batch.",
            "Preserve the initial test-only failure and focused correction evidence rather than claiming an unchanged full repeat.",
            "Root supplies a fresh bounded editing lease before any public adapter implementation or numerical batch.",
        ],
        "final_selection_written": False,
        "public_files_changed_by_planning": [],
        "numerical_execution": False,
    }
    write("conditional-selection.json", conditional)
    print(json.dumps({
        "proposal": pin(ROOT / "matched_width_power_proposal.json"),
        "inventory": pin(ROOT / "inventory.json"),
        "conditional_selection": pin(ROOT / "conditional-selection.json"),
        "distinct_histories": len(new_cases),
        "exact_power_match": True,
        "temperature_bounds_k": [float(lower), float(upper)],
        "duplicate_current_cases": len(matches),
        "numerical_execution": False,
    }, indent=2))


if __name__ == "__main__":
    main()
