"""Preserve the first test version and apply its already declared T tolerance."""
import difflib
import hashlib
import json
from pathlib import Path

WORK=Path(__file__).resolve().parents[1]
REPO=Path('/workspace/Power-Flow')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    target=REPO/'tests/test_thermal_forced_feedback_reference.py'
    assert sha(target)=='e6612e6941e25dbe4d964de3d1deb51efc1d7b556e2e6c49a30aa2f4185a8134'
    initial=target.read_bytes()
    preserved=WORK/'tests/test_thermal_forced_feedback_reference.initial.py'
    with preserved.open('xb') as stream:
        stream.write(initial)
    old='    assert history.samples[-1].temperature_k == 912.0\n'
    new='    assert history.samples[-1].temperature_k == pytest.approx(912.0, rel=0, abs=5e-13)\n'
    assert initial.decode().count(old)==1
    changed=initial.decode().replace(old,new)
    target.write_text(changed)
    diff=WORK/'tests/empty-assertion-correction.diff'
    diff.write_text(''.join(difflib.unified_diff(initial.decode().splitlines(keepends=True),
        changed.splitlines(keepends=True),fromfile='initial-test-source',tofile='corrected-test-source')))
    record={'schema':'mitl-forced-feedback-test-correction-v1','status':'single_failed_assertion_corrected',
        'initial_test_sha256':sha(preserved),'final_test_sha256':sha(target),
        'core_sha256':sha(REPO/'mhdlab/thermal_forced_feedback_reference.py'),
        'initial_log_sha256':sha(WORK/'forced-feedback-core-initial.log'),
        'initial_passed':31,'initial_failed':1,'unchanged_passing_cases_to_repeat':0,
        'failed_case_to_rerun':'test_empty_inventory_has_exact_logical_input_and_analytic_heating',
        'correction':'Redundant final exact equality now uses the same predeclared 5e-13 K analytic tolerance already checked at every sample.',
        'scientific_core_or_data_changed':False,'predeclared_tolerance_changed':False,
        'producer_or_test_executed_here':False,
        'artifact_sha256':{str(path.relative_to(WORK)):sha(path) for path in [preserved,diff,Path(__file__)]}}
    (WORK/'tests/correction.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(record,indent=2))


if __name__=='__main__':
    main()
