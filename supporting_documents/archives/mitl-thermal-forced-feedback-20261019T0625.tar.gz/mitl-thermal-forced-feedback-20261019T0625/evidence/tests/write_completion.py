"""Bind preserved JUnit/log/source versions without rerunning numerical checks."""
import ast
import hashlib
import json
from pathlib import Path
from xml.etree import ElementTree

WORK=Path(__file__).resolve().parents[1]
REPO=Path('/workspace/Power-Flow')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def junit(path):
    root=ElementTree.parse(path).getroot()
    suites=[root] if root.tag=='testsuite' else list(root.findall('testsuite'))
    return {key:sum(int(suite.attrib.get(key,'0')) for suite in suites)
            for key in ['tests','failures','errors','skipped']}


def main():
    core=REPO/'mhdlab/thermal_forced_feedback_reference.py'
    target=REPO/'tests/test_thermal_forced_feedback_reference.py'
    initial=WORK/'tests/test_thermal_forced_feedback_reference.initial.py'
    freeze=load(WORK/'tests/freeze.json');correction=load(WORK/'tests/correction.json')
    assert sha(core)==freeze['source_sha256']['mhdlab/thermal_forced_feedback_reference.py']==correction['core_sha256']
    assert sha(initial)==freeze['source_sha256']['tests/test_thermal_forced_feedback_reference.py']==correction['initial_test_sha256']
    assert sha(target)==correction['final_test_sha256']
    old=ast.parse(initial.read_text());new=ast.parse(target.read_text())
    functions=lambda tree:{node.name:ast.dump(node,include_attributes=False)
        for node in tree.body if isinstance(node,ast.FunctionDef)}
    old_functions,new_functions=functions(old),functions(new)
    assert old_functions.keys()==new_functions.keys()
    changed=[name for name in old_functions if old_functions[name]!=new_functions[name]]
    assert changed==['test_empty_inventory_has_exact_logical_input_and_analytic_heating']
    assert [ast.dump(node) for node in old.body if not isinstance(node,ast.FunctionDef)]==[
        ast.dump(node) for node in new.body if not isinstance(node,ast.FunctionDef)]
    first=junit(WORK/'tests/core-initial.xml');focused=junit(WORK/'tests/empty-analytic-rerun.xml')
    assert first=={'tests':32,'failures':1,'errors':0,'skipped':0}
    assert focused=={'tests':1,'failures':0,'errors':0,'skipped':0}
    entries=[json.loads(line) for line in (WORK/'commands.jsonl').read_text().splitlines()]
    labels=['forced-feedback-core-initial.log','forced-feedback-empty-analytic-rerun.log']
    runs=[next(entry for entry in entries if Path(entry['log']).name==label) for label in labels]
    assert [entry['exit_code'] for entry in runs]==[1,0]
    assert all(sha(entry['log'])==entry['log_sha256'] for entry in runs)
    assert all(entry['command'][1:3]==['-W','error'] for entry in runs)
    review=WORK/'core-review/completion.json'
    assert sha(review)=='4a75363faac81b89f29f274486f9d9bcf302741f5a0ec86c80c4da1e62b3ae7d'
    reviewed=load(review)
    assert reviewed['status']=='review_complete_no_substantive_issue_identified'
    artifacts=['tests/plan.json','tests/freeze.json','tests/freeze_test_plan.py',
        'tests/test_thermal_forced_feedback_reference.initial.py','tests/correction.json',
        'tests/empty-assertion-correction.diff','tests/correct_empty_assertion.py',
        'tests/core-initial.xml','tests/empty-analytic-rerun.xml',
        'forced-feedback-core-initial.log','forced-feedback-empty-assertion-correction.log',
        'forced-feedback-empty-analytic-rerun.log','tests/write_completion.py']
    source_versions={
        'initial_run':{'core_sha256':sha(core),'test_sha256':sha(initial),'tests':32,'passed':31,'failed':1,
            'preserved_test':'tests/test_thermal_forced_feedback_reference.initial.py'},
        'focused_correction_run':{'core_sha256':sha(core),'test_sha256':sha(target),'tests':1,'passed':1,'failed':0,
            'node':'test_empty_inventory_has_exact_logical_input_and_analytic_heating'},
        'unchanged_test_functions_AST_identical':True,'changed_functions':changed,
        'predeclared_tolerance_changed':False,'all_32_tests_repeated_on_final_test_bytes':False}
    record={'schema':'mitl-thermal-forced-feedback-core-tests-v1','status':'passed','all_checks_passed':True,
        'qualified_unique_new_test_cases':32,'test_case_executions':33,'targeted_test_runs':2,
        'initial_tests_passed':31,'initial_tests_failed':1,'corrected_failed_case_passes':1,
        'initial_failures_preserved':True,'unchanged_passing_cases_repeated':0,
        'errors':0,'skipped':0,'warnings_as_errors':True,'scientific_core_unchanged':True,
        'positive_trajectory_families':2,'area_rescaling_controls':1,'RHS_relations':7,
        'source_versions':source_versions,
        'public_source_sha256':{'mhdlab/thermal_forced_feedback_reference.py':sha(core),
            'tests/test_thermal_forced_feedback_reference.py':sha(target)},
        'static_review_record':'core-review/completion.json','static_review_sha256':sha(review),
        'plan_sha256':sha(WORK/'tests/plan.json'),'command_records':runs,
        'artifact_sha256':{name:sha(WORK/name) for name in artifacts},
        'old_suites_or_producers_repeated':False,'old_numerical_evolution_called':False,
        'portable_test_execution_claimed':False,'physical_parameters_adopted':0,
        'actual_FLASH_run':False,'host_budget_accepted':False,
        'limits':'Manufactured new core controls only. One redundant exact final-temperature assertion was corrected to its existing analytic tolerance. The initial31 passes and focused corrected pass remain associated with their actual preserved test bytes; no blanket final-test-byte run is claimed.'}
    (WORK/'tests/completion.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(record,indent=2))


if __name__=='__main__':
    main()
