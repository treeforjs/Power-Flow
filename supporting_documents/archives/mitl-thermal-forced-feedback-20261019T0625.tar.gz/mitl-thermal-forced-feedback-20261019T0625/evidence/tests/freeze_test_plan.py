"""Pin source/test/plan bytes without importing or executing either module."""
import argparse
import ast
import hashlib
import json
from pathlib import Path

WORK=Path(__file__).resolve().parents[1]
REPO=Path('/workspace/Power-Flow')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--expected-core-sha256',required=True)
    args=parser.parse_args()
    core=REPO/'mhdlab/thermal_forced_feedback_reference.py'
    target=REPO/'tests/test_thermal_forced_feedback_reference.py'
    assert sha(core)==args.expected_core_sha256
    tree=ast.parse(target.read_text())
    ast.parse(core.read_text())
    count=0
    for node in tree.body:
        if isinstance(node,ast.FunctionDef) and node.name.startswith('test_'):
            cardinality=1
            for decorator in node.decorator_list:
                if isinstance(decorator,ast.Call) and isinstance(decorator.func,ast.Attribute) and decorator.func.attr=='parametrize':
                    assert isinstance(decorator.args[1],(ast.List,ast.Tuple))
                    cardinality*=len(decorator.args[1].elts)
            count+=cardinality
    plan=json.loads((WORK/'tests/plan.json').read_text())
    assert count==plan['expected_new_test_cases']==32
    record={'schema':'mitl-forced-feedback-core-test-freeze-v1','status':'frozen_before_first_test_run',
        'expected_new_test_cases':count,'source_sha256':{
            'mhdlab/thermal_forced_feedback_reference.py':sha(core),
            'tests/test_thermal_forced_feedback_reference.py':sha(target)},
        'plan_sha256':sha(WORK/'tests/plan.json'),'writer_sha256':sha(__file__),
        'core_or_tests_imported_or_executed':False,
        'actual_test_execution_requires_root_static_review_gate':True}
    (WORK/'tests/freeze.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps(record,indent=2))


if __name__=='__main__':
    main()
