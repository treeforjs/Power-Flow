"""Freeze checkpoint-only verifier changes before the first reference call."""
import ast
import datetime
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    target=HERE/'checkpoint_amendment.json'
    if target.exists() or (HERE/'oracle-initial').exists():
        raise RuntimeError('checkpoint freeze must precede first reference evaluation')
    original=json.loads((HERE/'before_run_freeze.json').read_text())
    for name,digest in original['independent_code_and_plan_sha256'].items():
        if name=='verify_saved_forced_feedback.py':
            assert sha(HERE/'verify_saved_forced_feedback.initial.py')==digest
        else:
            assert sha(HERE/name)==digest
    ast.parse((HERE/'verify_saved_forced_feedback.py').read_text())
    record={'schema':'mitl-independent-forced-feedback-checkpoint-amendment-v1',
        'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'original_freeze_sha256':sha(HERE/'before_run_freeze.json'),
        'original_verifier_sha256':sha(HERE/'verify_saved_forced_feedback.initial.py'),
        'corrected_verifier_sha256':sha(HERE/'verify_saved_forced_feedback.py'),
        'math_plan_sha256':sha(HERE/'oracle_plan.json'),
        'reference_code_sha256':sha(HERE/'decimal_forced_reference.py'),
        'change':'Create the fresh output directory before reference evaluation and write each completed case/precision grid checkpoint with code/config/plan pins before later comparisons. Preserve initial source/freeze; no resume/cache feature or mathematical change.',
        'equations_method_inputs_tolerances_changed':False,
        'numerical_reference_calls_before_amendment':0}
    target.write_text(json.dumps(record,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'amendment_sha256':sha(target),
        'corrected_verifier_sha256':record['corrected_verifier_sha256']},indent=2))


if __name__=='__main__':
    main()
