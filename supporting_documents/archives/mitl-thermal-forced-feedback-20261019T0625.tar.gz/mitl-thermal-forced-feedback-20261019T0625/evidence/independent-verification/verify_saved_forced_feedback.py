"""Independent all-sample verification of saved manufactured positive-barrier forced trajectories.

Only local JSON/CSV and the fresh Decimal transformed Taylor reference are read.
There are no repository numerical, old solver, test or producer imports/calls.
"""
import argparse
import csv
import hashlib
import json
from decimal import Decimal, localcontext
from fractions import Fraction
from pathlib import Path

from decimal_forced_reference import reference_grid, represented, QE

D = Decimal
HERE = Path(__file__).resolve().parent
CHANNELS = ('coverage_m2', 'temperature_k', 'released_m2', 'input_energy_j_m2',
    'prescribed_input_energy_j_m2', 'binding_energy_j_m2', 'internal_energy_j_m2',
    'translational_energy_j_m2', 'total_wall_energy_debit_j_m2', 'gas_energy_j_m2',
    'wall_thermal_change_j_m2', 'adsorbate_reference_energy_j_m2',
    'adsorbate_reference_change_j_m2', 'adsorbate_reference_inventory_change_j_m2')


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def encode(value):
    if isinstance(value, D):
        return {'decimal': str(value), 'float_projection': float(value)}
    if isinstance(value, Fraction):
        return {'numerator': str(value.numerator), 'denominator': str(value.denominator), 'float_projection': float(value)}
    if isinstance(value, dict):
        return {key: encode(item) for key,item in value.items()}
    if isinstance(value, (tuple,list)):
        return [encode(item) for item in value]
    return value


def projected(value):
    if type(value) in (int,float):
        return ('float_input', float(value).hex())
    if isinstance(value,dict):
        return {key:projected(item) for key,item in value.items()}
    if isinstance(value,list):
        return [projected(item) for item in value]
    return value


def logical_grid(case, grid):
    records = [(0,0,Fraction(0))]
    for index,(segment,steps) in enumerate(zip(case['segments'],grid)):
        start,stop = (Fraction.from_float(float(segment[key])) for key in ('start_s','stop_s'))
        records.extend((index,step,start+(stop-start)*Fraction(step,steps)) for step in range(1,steps+1))
    return records


def schedule_for(case, grid):
    return {'duration_s':case['duration_s'], 'segments':[{**segment,'steps':steps} for segment,steps in zip(case['segments'],grid)]}


def fraction_input(case, time):
    value = Fraction(0)
    for segment in case['segments']:
        start,stop = (Fraction.from_float(float(segment[key])) for key in ('start_s','stop_s'))
        if start < time:
            value += Fraction.from_float(float(segment['power_w_m2']))*(min(stop,time)-start)
    return value


def normalized(error, scale):
    if scale:
        return abs(error)/scale
    require(error == 0, 'a structurally zero budget has nonzero error')
    return D(0)


def budget_scales(case, references):
    final = references[max(references)]
    t0 = represented(case['problem']['initial_temperature_k'])
    capacity = represented(case['problem']['areal_heat_capacity_j_m2_k'])
    excursion = max(abs(sample['temperature_k']-t0) for sample in references.values())
    scales = {key:abs(final[key]) for key in CHANNELS}
    scales['coverage_m2'] = scales['released_m2']
    scales['temperature_k'] = excursion
    scales['wall_thermal_change_j_m2'] = capacity*excursion
    scales['adsorbate_reference_energy_j_m2'] = scales['binding_energy_j_m2']
    return scales, {'temperature_excursion_k':excursion, 'thermal_excursion_j_m2':capacity*excursion,
        'gross_input_j_m2':final['input_energy_j_m2'], 'gross_wall_debit_j_m2':final['total_wall_energy_debit_j_m2'],
        'near_zero_net_convention':'Temperature and thermal errors use maximum resolved excursion over the case grid, separately from positive input/debit budgets. Exactly zero excursion requires exactly zero error.'}


def residuals(sample, case, scales):
    x = {key:represented(sample[key]) for key in CHANNELS}
    problem = case['problem']
    n0,t0,capacity = (represented(problem[key]) for key in ('initial_coverage_m2','initial_temperature_k','areal_heat_capacity_j_m2_k'))
    removal = represented(problem['reservoir']['desorption_energy_ev'])*QE
    internal = represented(problem['reservoir']['internal_energy_ev'])*QE
    thermal = capacity*(x['temperature_k']-t0)
    return {
        'N_plus_M_minus_N0_m2': (x['coverage_m2']+x['released_m2']-n0,scales['released_m2']),
        'thermal_minus_input_plus_wall_j_m2': (thermal-x['input_energy_j_m2']+x['total_wall_energy_debit_j_m2'],scales['wall_thermal_change_j_m2']),
        'wall_minus_binding_internal_translation_j_m2': (x['total_wall_energy_debit_j_m2']-x['binding_energy_j_m2']-x['internal_energy_j_m2']-x['translational_energy_j_m2'],scales['total_wall_energy_debit_j_m2']),
        'binding_minus_D_M_j_m2': (x['binding_energy_j_m2']-removal*x['released_m2'],scales['binding_energy_j_m2']),
        'internal_minus_I_M_j_m2': (x['internal_energy_j_m2']-internal*x['released_m2'],scales['internal_energy_j_m2']),
        'adsorbate_change_minus_inventory_change_j_m2': (x['adsorbate_reference_change_j_m2']-removal*(n0-x['coverage_m2']),scales['binding_energy_j_m2']),
        'gas_minus_internal_translation_j_m2': (x['gas_energy_j_m2']-x['internal_energy_j_m2']-x['translational_energy_j_m2'],scales['gas_energy_j_m2']),
        'saved_thermal_minus_C_deltaT_j_m2': (x['wall_thermal_change_j_m2']-thermal,scales['wall_thermal_change_j_m2']),
        'saved_adsorbate_energy_plus_D_N_j_m2': (x['adsorbate_reference_energy_j_m2']+removal*x['coverage_m2'],scales['binding_energy_j_m2']),
        'input_integrated_minus_prescribed_j_m2': (x['input_energy_j_m2']-x['prescribed_input_energy_j_m2'],scales['input_energy_j_m2']),
        'total_thermal_adsorbate_gas_minus_input_j_m2': (thermal+removal*(n0-x['coverage_m2'])+x['gas_energy_j_m2']-x['input_energy_j_m2'],
            max(scales['input_energy_j_m2'],scales['total_wall_energy_debit_j_m2']))}


def compare_trajectory(record,case,run_dir,references,plan):
    grid = record['segment_steps']
    logical = logical_grid(case,grid)
    history_path,csv_path = run_dir/record['history_file'],run_dir/record['csv_file']
    require(sha(history_path)==record['history_sha256'] and sha(csv_path)==record['csv_sha256'],'producer output pin differs')
    history = load(history_path)
    require(projected(history['problem'])==projected(case['problem'])==projected(record['input_parameters']),'problem input differs')
    require(len(history['schedule']['segments'])==len(case['segments']),'schedule count differs')
    for actual,expected,steps in zip(history['schedule']['segments'],case['segments'],grid):
        require(actual['steps']==steps and all(projected(actual[key])==projected(expected[key]) for key in expected),'schedule declaration differs')
    samples=history['samples']
    with csv_path.open(newline='') as stream:
        csv_rows=list(csv.DictReader(stream))
    require(len(samples)==len(csv_rows)==len(logical)==sum(grid)+1,'saved sample count differs')
    with localcontext() as context:
        context.prec=plan['refined_precision']
        scales,scale_notes=budget_scales(case,references)
        tolerance=D(plan['coarse_family_budget_tolerance'] if min(grid)<32 else plan['trajectory_budget_tolerance'])
        maxima={key:{'absolute_budget_fraction':D(-1)} for key in CHANNELS}
        ledgers={}
        csv_cells=area_checks=stamp_checks=0
        for index,(sample,csv_row,(segment,step,time)) in enumerate(zip(samples,csv_rows,logical)):
            require(sample['segment_index']==segment and sample['segment_step']==step,'logical sample identity differs')
            require(float(sample['time_s']).hex()==float(time).hex(),'rounded time stamp differs from exact logical grid')
            stamp_checks+=1
            for key in ('time_s','segment_index','segment_step',*CHANNELS):
                require(float(csv_row[key]).hex()==float(sample[key]).hex(),'CSV/JSON scalar differs: '+key)
                csv_cells+=1
            reference=references[time]
            for key in CHANNELS:
                error=represented(sample[key])-reference[key]
                fraction=normalized(error,scales[key])
                if fraction>maxima[key]['absolute_budget_fraction']:
                    maxima[key]={'signed_error':error,'absolute_budget_fraction':fraction,'budget_scale':scales[key],'sample_index':index}
                require(fraction<=tolerance,'independent all-row error exceeds budget: '+key)
            exact_input=fraction_input(case,time)
            require(float(sample['prescribed_input_energy_j_m2']).hex()==float(exact_input).hex(),'prescribed input is not exact schedule integral projection')
            for key,(residual,scale) in residuals(sample,case,scales).items():
                fraction=normalized(residual,scale)
                if fraction>ledgers.get(key,{}).get('absolute_budget_fraction',D(-1)):
                    ledgers[key]={'signed_residual':residual,'absolute_budget_fraction':fraction,'budget_scale':scale,'sample_index':index}
                require(fraction<=D(plan['ledger_budget_tolerance']),'independent signed ledger exceeds budget: '+key)
            area=Fraction.from_float(float(case['problem']['patch_area_m2']))
            mappings=[(key,key[:-3]) for key in CHANNELS if key.endswith('_j_m2')]
            mappings += [('coverage_m2','coverage_number'),('released_m2','released_number'),('inventory_residual_m2','inventory_residual_number')]
            for areal,extensive in mappings:
                expected=float(Fraction.from_float(float(sample[areal]))*area)
                require(float(sample['extensive'][extensive]).hex()==expected.hex(),'area-once projection differs: '+extensive)
                area_checks+=1
        final_reference=references[logical[-1][2]]
        return {'case_id':record['case_id'],'segment_steps':grid,'total_steps':sum(grid),'sample_rows':len(samples),
            'CSV_JSON_scalar_cells_checked':csv_cells,'rounded_stamp_projection_checks':stamp_checks,'area_once_checks':area_checks,
            'source_artifact_sha256':{str(history_path):sha(history_path),str(csv_path):sha(csv_path)},
            'budget_scales':scales,'scale_conventions':scale_notes,'declared_error_budget_fraction':tolerance,
            'all_row_maximum_errors':maxima,'independent_signed_ledger_maxima':ledgers,
            'endpoint_values':{key:represented(samples[-1][key]) for key in CHANNELS},
            'endpoint_reference':final_reference}


def order(a,b,c):
    coarse,fine=a-b,b-c
    if not coarse or not fine or coarse*fine<=0 or abs(coarse)<=abs(fine):
        return {'order':None,'status':'unresolved_zero_cancellation_sign_or_nonasymptotic_change','coarse_change':coarse,'fine_change':fine}
    return {'order':abs(coarse/fine).ln()/D(2).ln(),'status':'finite_self_difference_estimate','coarse_change':coarse,'fine_change':fine}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run-dir',type=Path,required=True)
    parser.add_argument('--output-dir',type=Path,required=True)
    args=parser.parse_args()
    require(not args.output_dir.exists(),'fresh independent output directory required')
    freeze,plan=load(HERE/'before_run_freeze.json'),load(HERE/'oracle_plan.json')
    amendment=load(HERE/'checkpoint_amendment.json')
    require(sha(HERE/'before_run_freeze.json')==amendment['original_freeze_sha256'],'original freeze differs')
    for name,digest in freeze['independent_code_and_plan_sha256'].items():
        if name=='verify_saved_forced_feedback.py':
            require(digest==amendment['original_verifier_sha256'],'initial verifier association differs')
            digest=amendment['corrected_verifier_sha256']
        require(sha(HERE/name)==digest,'frozen independent code/plan changed')
    config,producer=load(HERE/'input_config.json'),load(args.run_dir/'report.json')
    require(config['schema']=='mhdlab-thermal-forced-feedback-manufactured-config-v1' and len(config['cases'])==4,'fixture count/schema differs')
    require(producer['schema']=='mhdlab-thermal-forced-feedback-reference-run-v1' and len(producer['trajectories'])==7,'producer schema/trajectory count differs')
    require(sha(HERE/'input_config.json')==sha(args.run_dir/'input_config.json')==producer['config_sha256'],'frozen config association differs')
    cases={case['case_id']:case for case in config['cases']}
    require({(r['case_id'],tuple(r['segment_steps'])) for r in producer['trajectories']}=={(case['case_id'],tuple(grid)) for case in cases.values() for grid in case['step_grids']},'case/grid selection differs')
    args.output_dir.mkdir(parents=True)
    checkpoint_sha256={}
    def checkpoint(case_id,level,samples):
        path=args.output_dir/(case_id+'_'+level+'_reference_checkpoint.json')
        path.write_text(json.dumps(encode({'case_id':case_id,'level':level,
            'config_sha256':sha(HERE/'input_config.json'),'oracle_plan_sha256':sha(HERE/'oracle_plan.json'),
            'reference_code_sha256':sha(HERE/'decimal_forced_reference.py'),
            'samples':[{'logical_time':time,**sample} for time,sample in sorted(samples.items())]}),indent=2,allow_nan=False)+'\n')
        checkpoint_sha256[path.name]=sha(path)
    references,precision_changes={},{}
    for case_id,case in cases.items():
        times={record[2] for grid in case['step_grids'] for record in logical_grid(case,grid)}
        schedule=schedule_for(case,case['step_grids'][-1])
        coarse=reference_grid(case['problem'],schedule,times,precision=plan['coarse_precision'],order=plan['coarse_order'],subdivisions=plan['coarse_subdivisions'],quadrature_order=plan['coarse_quadrature_order'])
        checkpoint(case_id,'coarse',coarse)
        refined=reference_grid(case['problem'],schedule,times,precision=plan['refined_precision'],order=plan['refined_order'],subdivisions=plan['refined_subdivisions'],quadrature_order=plan['refined_quadrature_order'])
        checkpoint(case_id,'refined',refined)
        with localcontext() as context:
            context.prec=plan['refined_precision']
            scales,_=budget_scales(case,refined)
            changes={key:{'absolute_budget_fraction':D(-1)} for key in CHANNELS}
            for time in sorted(times):
                for key in CHANNELS:
                    change=coarse[time][key]-refined[time][key]
                    fraction=normalized(change,scales[key])
                    if fraction>changes[key]['absolute_budget_fraction']:
                        changes[key]={'signed_change':change,'absolute_budget_fraction':fraction,'budget_scale':scales[key],'logical_time':time}
                    require(fraction<=D(plan['reference_change_tolerance']),'precision/order change unresolved: '+key)
                for level in (coarse,refined):
                    structural={
                        'independent_total_energy_residual_j_m2':scales['wall_thermal_change_j_m2'],
                        'independent_wall_energy_residual_j_m2':scales['wall_thermal_change_j_m2'],
                        'independent_wall_channel_residual_j_m2':scales['total_wall_energy_debit_j_m2'],
                        'independent_count_quadrature_residual_m2':scales['released_m2']}
                    for key,scale in structural.items():
                        require(normalized(level[time][key],scale)<=D(plan['reference_change_tolerance']),
                            'independent direct channel/trajectory consistency unresolved: '+key)
                    require(level[time]['off_segment_Z_change_k']==0,'off-segment transformed invariant differs')
        references[case_id]=refined
        precision_changes[case_id]=changes
        print('completed independent Decimal reference '+case_id,flush=True)
    comparisons=[compare_trajectory(record,cases[record['case_id']],args.run_dir,references[record['case_id']],plan) for record in producer['trajectories']]
    family=sorted((item for item in comparisons if item['case_id']==config['refinement_case_id']),key=lambda item:item['segment_steps'][0])
    require([item['segment_steps'] for item in family]==[[8]*3,[16]*3,[32]*3,[64]*3],'refinement family differs')
    orders={}
    with localcontext() as context:
        context.prec=plan['refined_precision']
        for key in ('coverage_m2','temperature_k','released_m2','binding_energy_j_m2','internal_energy_j_m2','translational_energy_j_m2','total_wall_energy_debit_j_m2','gas_energy_j_m2','wall_thermal_change_j_m2'):
            values=[item['endpoint_values'][key] for item in family]
            orders[key]=[order(*values[:3]),order(*values[1:])]
            if key in plan['required_resolved_self_order_quantities']:
                require(all(value['order'] is not None and value['order']>=D(plan['minimum_resolved_self_order']) for value in orders[key]),'required temporal self-order unresolved: '+key)
    reference_path=args.output_dir/'reference_samples.json'
    reference_path.write_text(json.dumps(encode({case_id:[{'logical_time':time,**sample} for time,sample in sorted(samples.items())] for case_id,samples in references.items()}),indent=2,allow_nan=False)+'\n')
    result={'schema':'mitl-independent-thermal-forced-feedback-oracle-v1','status':'passed','all_checks_passed':True,
        'cases':4,'saved_trajectories':7,'saved_sample_rows_checked':sum(item['sample_rows'] for item in comparisons),
        'CSV_JSON_scalar_cells_checked':sum(item['CSV_JSON_scalar_cells_checked'] for item in comparisons),
        'area_once_checks':sum(item['area_once_checks'] for item in comparisons),
        'logical_time_stamp_checks':sum(item['rounded_stamp_projection_checks'] for item in comparisons),
        'distinct_reference_samples':sum(len(samples) for samples in references.values()),
        'reference_samples_file':reference_path.name,'reference_samples_sha256':sha(reference_path),
        'reference_checkpoint_sha256':checkpoint_sha256,
        'all_row_reference_precision_order_changes':precision_changes,'trajectories':comparisons,'temporal_self_orders':orders,
        'input_sha256':{str(HERE/'input_config.json'):sha(HERE/'input_config.json'),str(args.run_dir/'report.json'):sha(args.run_dir/'report.json')},
        'source_model_imports':[],'positive_core_or_CLI_calls':0,'old_solver_or_suite_calls':0,
        'translation_reference':'Direct positive quadrature of2*kB*T*Gamma along the independent transformed Taylor dense trajectory, splitatallpowerjumps; not a tested-energy-residual difference.',
        'wall_reference':'Separate direct positive quadrature ofGamma*(D+I+2*kB*T), not binding+internal+translation or a tested thermal residual.',
        'numeric_method':plan['numeric_method'],'qualification':plan['qualification']}
    path=args.output_dir/'report.json'
    path.write_text(json.dumps(encode(result),indent=2,allow_nan=False)+'\n')
    print(json.dumps({'report':str(path),'sha256':sha(path),'cases':4,'trajectories':7,'sample_rows':result['saved_sample_rows_checked'],'self_orders':encode(orders)},indent=2))


if __name__=='__main__':
    main()
