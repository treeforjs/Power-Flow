"""Freeze mathematical reference, input projections and budgets before runs."""
import ast
import datetime
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
WORK=HERE.parent
REPO=Path('/workspace/Power-Flow')


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    target=HERE/'before_run_freeze.json'
    if target.exists() or (WORK/'producer/reference-run/report.json').exists():
        raise RuntimeError('freeze must precede producer and oracle numerical runs')
    names=['decimal_forced_reference.py','verify_saved_forced_feedback.py','oracle_plan.json','input_config.json','freeze_oracle.py']
    for name in names:
        if name.endswith('.py'):
            ast.parse((HERE/name).read_text())
    config=REPO/'configs/thermal_forced_feedback_manufactured.json'
    assert sha(HERE/'input_config.json')==sha(config)=='8fd0727c66ac013a8e2620085b037f5d64bf4d2baeec4b113c350152a89ea637'
    record={'schema':'mitl-independent-forced-feedback-before-run-freeze-v1',
        'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'independent_code_and_plan_sha256':{name:sha(HERE/name) for name in names},
        'public_input_config':str(config),'public_input_config_sha256':sha(config),
        'cases':4,'expected_saved_trajectories':7,'expected_saved_sample_rows':463,
        'independent_oracle_numerical_run_count_before_freeze':0,
        'positive_core_or_CLI_calls_by_oracle':0,'saved_producer_report_already_available':False,
        'input_and_tolerance_selection':'Four agreed manufactured fixtures and all budgets, precisions, Taylor/quadrature orders and substeps frozen before either new producer or oracle numerical run.',
        'limits':'Static AST/hash/config read only; no reference or model constructor/function is imported or evaluated by this step.'}
    target.write_text(json.dumps(record,indent=2,allow_nan=False)+'\n')
    print(json.dumps({'freeze':str(target),'sha256':sha(target),'code_sha256':record['independent_code_and_plan_sha256']},indent=2))


if __name__=='__main__':
    main()
