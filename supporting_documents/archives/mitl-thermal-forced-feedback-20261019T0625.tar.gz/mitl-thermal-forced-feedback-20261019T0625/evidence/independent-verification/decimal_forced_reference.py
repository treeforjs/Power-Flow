"""Independent positive-barrier transformed Taylor IVP and channel quadrature.

No repository model, old reference, producer or solver is imported or called.
"""
from dataclasses import dataclass
from decimal import Decimal, getcontext, localcontext
from fractions import Fraction
from functools import lru_cache
import math

D = Decimal
KB = D('1.380649e-23')
QE = D('1.602176634e-19')


def represented(value):
    return D.from_float(float(value))


def decimal_fraction(value):
    return D(value.numerator)/D(value.denominator)


def multiply(a,b):
    return [sum((a[j]*b[n-j] for j in range(n+1)),D(0)) for n in range(len(a))]


def exponential(a):
    result = [a[0].exp()]
    for n in range(1,len(a)):
        result.append(sum((j*a[j]*result[n-j] for j in range(1,n+1)),D(0))/n)
    return result


def reciprocal(a):
    if a[0] <= 0:
        raise ValueError('Taylor reciprocal requires positive constant temperature')
    result = [1/a[0]]
    for n in range(1,len(a)):
        result.append(-sum((a[j]*result[n-j] for j in range(1,n+1)),D(0))/a[0])
    return result


def evaluate(coefficients,offset):
    value = coefficients[-1]
    for coefficient in reversed(coefficients[:-1]):
        value = coefficient+offset*value
    return value


@lru_cache(maxsize=8)
def probability_rule(order,precision):
    """Decimal-refined roots and weights; binary cosines supply seeds only."""
    if type(order) is not int or order<2 or order%2:
        raise ValueError('even positive quadrature order required')
    with localcontext() as context:
        context.prec=precision
        tolerance=D(10)**(-precision+12)
        result=[]
        for j in range(1,order//2+1):
            root=D.from_float(math.cos(math.pi*(j-.25)/(order+.5)))
            for _ in range(100):
                previous,current=D(1),root
                for n in range(2,order+1):
                    previous,current=current,((2*n-1)*root*current-(n-1)*previous)/n
                derivative=order*(root*current-previous)/(root*root-1)
                change=current/derivative
                root-=change
                if abs(change)<=tolerance:
                    break
            else:
                raise RuntimeError('Decimal Legendre root unresolved')
            previous,current=D(1),root
            for n in range(2,order+1):
                previous,current=current,((2*n-1)*root*current-(n-1)*previous)/n
            derivative=order*(root*current-previous)/(root*root-1)
            weight=1/((1-root*root)*derivative*derivative)
            result.extend((((1-root)/2,weight),((1+root)/2,weight)))
        result.sort()
        if any(not 0<node<1 or weight<=0 for node,weight in result):
            raise RuntimeError('quadrature positivity unresolved')
        if abs(sum(weight for _,weight in result)-1)>D(10)**(-precision+10):
            raise RuntimeError('quadrature normalization unresolved')
        return tuple(result)


@dataclass(frozen=True)
class ReferenceParameters:
    n0:D
    t0:D
    capacity:D
    area:D
    nu:D
    activation:D
    removal:D
    internal:D
    alpha:D
    nref:D
    nmax:D
    tmin:D
    tmax:D

    @classmethod
    def from_inputs(cls,problem):
        reservoir=problem['reservoir']
        result=cls(*(represented(problem[key]) for key in ('initial_coverage_m2','initial_temperature_k',
            'areal_heat_capacity_j_m2_k','patch_area_m2')),
            represented(reservoir['attempt_frequency_s']),represented(reservoir['activation_energy_ev'])*QE,
            represented(reservoir['desorption_energy_ev'])*QE,represented(reservoir['internal_energy_ev'])*QE,
            *(represented(reservoir[key]) for key in ('coverage_coefficient','reference_coverage_m2','max_coverage_m2')),
            represented(problem['temperature_min_k']),represented(problem['temperature_max_k']))
        if not (0<=result.n0<=result.nmax and result.nu>0 and result.activation>0 and result.removal>=0
                and result.internal>=0 and result.alpha>=0 and result.nref>0 and result.nmax>0
                and result.alpha*result.nmax<=result.nref and result.capacity>0 and result.area>0
                and 0<result.tmin<=result.t0<=result.tmax):
            raise ValueError('unsupported independent manufactured domain')
        return result

    @property
    def shift(self):
        return (self.removal+self.internal)/(2*KB)

    def state(self,s,z,nseg):
        if s<0:
            raise ValueError('negative local depletion')
        n=nseg*(-s).exp()
        b=2*KB*(nseg-n)/self.capacity
        temperature=z*(-b).exp()-self.shift
        if not (0<n<=nseg<=self.nmax and self.tmin<=temperature<=self.tmax):
            raise ValueError('independent trajectory outside declared domain')
        barrier=self.activation*(1-self.alpha*n/self.nref)
        if barrier<0:
            raise ValueError('effective barrier outside declared domain')
        factor=(-barrier/(KB*temperature)).exp()
        if not 0<factor<=1:
            raise ValueError('independent Arrhenius factor unsupported')
        return n,temperature,b,factor


def rhs_series(s,z,parameters,nseg,power):
    """Coefficients in local dimensionless time u=nu*(t-t_expansion)."""
    one=[D(1)]+[D(0)]*(len(s)-1)
    survival=exponential([-x for x in s])
    b=[2*KB*nseg*(a-v)/parameters.capacity for a,v in zip(one,survival)]
    inverse_factor=exponential([-x for x in b])
    temperature=multiply(z,inverse_factor)
    temperature[0]-=parameters.shift
    effective=[parameters.activation*(a-parameters.alpha*nseg*v/parameters.nref) for a,v in zip(one,survival)]
    exponent=multiply([-x/KB for x in effective],reciprocal(temperature))
    hazard=exponential(exponent)
    z_rate=[power*x/(parameters.capacity*parameters.nu) for x in exponential(b)]
    return hazard,z_rate


def taylor_coefficients(s,z,parameters,nseg,power,order):
    s_coeff,z_coeff=[s],[z]
    for n in range(order):
        ds,dz=rhs_series(s_coeff,z_coeff,parameters,nseg,power)
        s_coeff.append(ds[n]/(n+1))
        z_coeff.append(dz[n]/(n+1))
    return s_coeff,z_coeff


def exact_input(segments,time):
    result=Fraction(0)
    for start,stop,power in segments:
        if start<time:
            result+=power*(min(time,stop)-start)
    return result


def sample(parameters,time,n,temperature,translation,wall,count_quadrature,input_energy,segment_index,
        local_s,local_z,local_b,off_segment_z_change):
    emitted=parameters.n0-n
    binding,internal=parameters.removal*emitted,parameters.internal*emitted
    thermal=parameters.capacity*(temperature-parameters.t0)
    return {'time_s':decimal_fraction(time),'coverage_m2':n,'temperature_k':temperature,'released_m2':emitted,
        'input_energy_j_m2':input_energy,'prescribed_input_energy_j_m2':input_energy,
        'binding_energy_j_m2':binding,'internal_energy_j_m2':internal,
        'translational_energy_j_m2':translation,'total_wall_energy_debit_j_m2':wall,
        'gas_energy_j_m2':internal+translation,'wall_thermal_change_j_m2':thermal,
        'adsorbate_reference_energy_j_m2':-parameters.removal*n,
        'adsorbate_reference_change_j_m2':binding,'adsorbate_reference_inventory_change_j_m2':binding,
        'independent_total_energy_residual_j_m2':thermal+binding+internal+translation-input_energy,
        'independent_wall_energy_residual_j_m2':thermal+wall-input_energy,
        'independent_wall_channel_residual_j_m2':wall-binding-internal-translation,
        'independent_count_quadrature_residual_m2':count_quadrature-emitted,
        'direct_count_quadrature_m2':count_quadrature,
        'reference_segment_index':segment_index,'reference_local_depletion':local_s,
        'reference_local_Z_k':local_z,'reference_local_b':local_b,
        'off_segment_Z_change_k':off_segment_z_change}


def reference_grid(problem,schedule,times,*,precision,order,subdivisions,quadrature_order):
    """One independently carried trajectory per case and precision/method ladder."""
    with localcontext() as context:
        context.prec=precision
        parameters=ReferenceParameters.from_inputs(problem)
        if not (type(order)is int and order>=2 and type(subdivisions)is int and subdivisions>0):
            raise ValueError('unsupported Taylor method selection')
        segments=tuple(tuple(Fraction.from_float(float(item[key])) for key in ('start_s','stop_s','power_w_m2'))
            for item in schedule['segments'])
        queries=sorted(set(times)|{Fraction(0)}|{edge for start,stop,_ in segments for edge in (start,stop)})
        if not (segments and segments[0][0]==0 and all(a<b and p>=0 for a,b,p in segments)
                and all(a[1]==b[0] for a,b in zip(segments,segments[1:]))
                and queries[0]==0 and queries[-1]==segments[-1][1]==Fraction.from_float(float(schedule['duration_s']))):
            raise ValueError('invalid exact represented finite schedule')
        if any(not isinstance(time,Fraction) for time in times):
            raise TypeError('exact Fraction observation times required')
        n,temperature=parameters.n0,parameters.t0
        translation=wall=count_integral=D(0)
        results={Fraction(0):sample(parameters,Fraction(0),n,temperature,translation,wall,count_integral,
            D(0),0,D(0),temperature+parameters.shift,D(0),D(0))}
        if parameters.n0==0:
            for time in queries[1:]:
                energy=decimal_fraction(exact_input(segments,time))
                results[time]=sample(parameters,time,D(0),parameters.t0+energy/parameters.capacity,
                    D(0),D(0),D(0),energy,0,D(0),D(0),D(0),D(0))
            return results
        rule=probability_rule(quadrature_order,precision)
        for segment_index,(start,stop,power_fraction) in enumerate(segments):
            nseg=n
            s,z=D(0),temperature+parameters.shift
            segment_z=z
            previous=start
            power=decimal_fraction(power_fraction)
            for time in (value for value in queries if start<value<=stop):
                h=decimal_fraction(Fraction.from_float(float(problem['reservoir']['attempt_frequency_s']))*(time-previous)/subdivisions)
                for _ in range(subdivisions):
                    sc,zc=taylor_coefficients(s,z,parameters,nseg,power,order)
                    count_increment=translation_increment=wall_increment=D(0)
                    for node,weight in rule:
                        state_s,state_z=evaluate(sc,h*node),evaluate(zc,h*node)
                        node_n,node_t,_,factor=parameters.state(state_s,state_z,nseg)
                        population=node_n*factor
                        count_increment+=weight*population
                        translation_increment+=weight*(2*KB*node_t)*population
                        wall_increment+=weight*(parameters.removal+parameters.internal+2*KB*node_t)*population
                    count_integral+=h*count_increment
                    translation+=h*translation_increment
                    wall+=h*wall_increment
                    new_s,new_z=evaluate(sc,h),evaluate(zc,h)
                    if new_s<=s or (power==0 and new_z!=z):
                        raise RuntimeError('reference monotonicity or exact off-segment structure unresolved')
                    s,z=new_s,new_z
                    n,temperature,b,_=parameters.state(s,z,nseg)
                energy=decimal_fraction(exact_input(segments,time))
                off_change=z-segment_z if power==0 else D(0)
                results[time]=sample(parameters,time,n,temperature,translation,wall,count_integral,
                    energy,segment_index,s,z,b,off_change)
                previous=time
        return results
