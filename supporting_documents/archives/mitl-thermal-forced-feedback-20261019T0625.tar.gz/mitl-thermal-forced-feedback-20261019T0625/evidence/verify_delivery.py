"""Verify the actual prescribed-power archive without replaying numerical work."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import tarfile
import subprocess

from prepare_delivery import WORK, REPO, BASE, OUT, PUBLIC, WRAPPERS, baseline_bytes, clean_head, command_snapshot_prefix, load, loads, save, sha
from freeze_delivery import REPORT_PATHS, excluded, verify_contracts


def verify_saved_records(records, configured_inputs, original_hashes, documents, raw, omissions):
    return verify_contracts(records, configured_inputs,
        work_sha=lambda name: original_hashes['evidence/'+name],
        public_sha=lambda name: (original_hashes['source/'+name] if 'source/'+name in original_hashes
            else documents('dependency_context.json')['unchanged_context_sha256'][name]),
        work_bytes=lambda name: raw('evidence/'+name))


def main():
    frozen = load(WORK/'frozen_delivery.json')
    clean_head(frozen['source_commit'])
    assert frozen['base_commit'] == BASE and Path(frozen['folder']) == OUT
    archive = Path(frozen['archive'])
    assert archive == OUT.with_suffix('.tar.gz')
    assert sha(archive) == frozen['sha256'] and archive.stat().st_size == frozen['bytes']
    hashes, members = {}, {}
    with tarfile.open(archive, 'r:gz') as tar:
        seen = set()
        for member in tar.getmembers():
            path = PurePosixPath(member.name)
            assert not path.is_absolute() and '..' not in path.parts and path.parts[0] == OUT.name
            assert member.name not in seen and not member.issym() and not member.islnk()
            seen.add(member.name)
            if member.isdir():
                continue
            assert member.isfile()
            name = PurePosixPath(*path.parts[1:]).as_posix()
            assert name != '.' and name not in members
            digest = hashlib.sha256()
            stream = tar.extractfile(member)
            for block in iter(lambda: stream.read(1024*1024), b''):
                digest.update(block)
            hashes[name], members[name] = digest.hexdigest(), member

        def raw(name):
            data = tar.extractfile(members[name]).read()
            assert hashlib.sha256(data).hexdigest() == hashes[name]
            return data

        def document(name):
            return loads(raw(name))

        manifest = document('manifest.sha256.json')
        assert set(hashes) == set(manifest)|{'manifest.sha256.json'}
        assert len(manifest) == frozen['manifest_entries']
        assert all(hashes[name] == digest for name, digest in manifest.items())
        assert hashes['manifest.sha256.json'] == frozen['manifest_sha256']
        assert hashes['verification.json'] == frozen['verification_sha256']
        assert {str(path.relative_to(OUT)) for path in OUT.rglob('*') if path.is_file()} == set(hashes)
        assert all(sha(OUT/name) == digest for name, digest in hashes.items())
        assert document('source_file_list.json') == {'byte_identical_public_files': list(PUBLIC), 'packaging_wrappers': list(WRAPPERS)}
        assert len(PUBLIC) == 5 and len(WRAPPERS) == 2
        assert {name[7:] for name in hashes if name.startswith('source/')} == set(PUBLIC)|set(WRAPPERS)
        assert 'source/mhdlab/__init__.py' not in hashes
        for name in PUBLIC:
            assert hashes['source/'+name] == sha(REPO/name)
        for file_name, names in (('source-files.sha256', PUBLIC), ('wrapper-files.sha256', WRAPPERS)):
            found = {}
            for line in raw(file_name).decode().splitlines():
                digest, name = line.split('  ', 1)
                assert name not in found and digest == hashes['source/'+name]
                found[name] = digest
            assert set(found) == set(names)
        context = document('dependency_context.json')
        assert context['required_complete_baseline_checkout'] is True and context['baseline_commit'] == BASE
        assert context['standalone_source_subset'] is False and context['empty_initializer_added'] is False
        for name, digest in context['unchanged_context_sha256'].items():
            assert hashlib.sha256(baseline_bytes(name)).hexdigest() == digest == sha(REPO/name)
        assert hashes['source/requirements.txt'] == context['unchanged_context_sha256']['requirements.txt']
        assert raw('thermal-forced-feedback-reference.patch') == subprocess.check_output(['git', 'diff', '--binary', BASE, frozen['source_commit']], cwd=REPO)
        verification = document('verification.json')
        assert verification['schema'] == 'mitl-thermal-forced-feedback-reference-verification-v1'
        assert verification['source_commit'] == frozen['source_commit'] and verification['base_commit'] == BASE
        assert verification['dependency_context'] == context
        assert verification['package_kind'] == 'patch_over_exact_complete_baseline'
        assert verification['record_paths'] == REPORT_PATHS
        assert verification['results']['portable_executions_performed'] is False
        configured_inputs = verification['input_contract']
        assert configured_inputs['config_sha256'] == hashes['source/'+configured_inputs['config_path']]
        config = document('source/'+configured_inputs['config_path'])
        assert config == configured_inputs['configuration']
        allowed_archive_figures = {'evidence/'+name for name in verification['allowed_figure_paths']}
        assert all(not excluded(name, allowed_archive_figures) for name in hashes)
        original_hashes = dict(hashes)
        restored_bytes = {}
        for projection in reversed(document('portable_path_projections.json')):
            name = projection['path']
            data = restored_bytes.get(name, raw(name))
            assert hashlib.sha256(data).hexdigest() == projection['portable_sha256']
            replacement = projection['replacement'].encode()
            assert data.count(replacement) == projection['replacements']
            restored = data.replace(replacement, bytes.fromhex(projection['source_prefix_hex']))
            assert hashlib.sha256(restored).hexdigest() == projection['original_sha256']
            restored_bytes[name] = restored
            original_hashes[name] = projection['original_sha256']

        def original_document(name):
            return loads(restored_bytes.get(name, raw(name)))

        def original_bytes(name):
            return restored_bytes.get(name, raw(name))

        for item in verification['copied_input_sha256']:
            assert original_hashes[item['archive']] == item['sha256']
            historical_helper = item['archive'] in {'evidence/'+name for name in verification['source_helper_sha256']}
            if item['archive'] != 'evidence/commands.jsonl' and not historical_helper:
                source = Path(item['source'])
                assert source.is_file() and not source.is_symlink() and sha(source) == item['sha256']
        snapshot = verification['command_snapshot']
        expected_snapshot = command_snapshot_prefix(original_bytes(snapshot['path']), (WORK/'commands.jsonl').read_bytes())
        assert all(snapshot[key] == value for key, value in expected_snapshot.items())
        for name, digest in verification['source_helper_sha256'].items():
            assert original_hashes['evidence/'+name] == digest
        records = {}
        for key, path in REPORT_PATHS.items():
            name = 'evidence/'+path
            assert original_hashes[name] == verification['record_sha256'][key]
            records[key] = original_document(name)
            assert records[key] == verification['records'][key]
        validated = verify_saved_records(records, configured_inputs, original_hashes, original_document, original_bytes,
                                        document('excluded_evidence.json'))
        assert validated['results'] == verification['results']
        assert validated['source_version_relationships'] == verification['source_version_relationships']
        assert validated['allowed_figure_paths'] == verification['allowed_figure_paths']
        task = records['selection']['selected_task']
        assert document('next_task.json')['task'] == task == verification['next_task']
        result = {**frozen, 'status': 'passed', 'actual_archive_regular_files': len(hashes),
            'unsafe_or_duplicate_members': 0, 'input_code_output_bindings_verified': True,
            'repository_clean': True, 'complete_baseline_checkout_required': True,
            'source_subset_standalone': False, 'empty_initializer_added': False,
            'reference_test_oracle_or_old_suites_reexecuted': False, 'portable_execution_performed': False, 'historical_helper_snapshots_bound': True,
            'live_commands_exact_complete_record_prefix_verified': True}
    save(WORK/'delivery_verification.json', result)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
