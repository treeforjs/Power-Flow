"""Bind final bytes and accepted prerequisite evidence before sole production."""
import datetime,hashlib,json,pathlib,shutil
W=pathlib.Path(__file__).resolve().parent;P=W.parent;R=pathlib.Path('/workspace/Power-Flow')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
expected={'tools/run_thermal_forced_feedback_reference.py':'8440562336604e46ca00c09d1f4191d7ce15a496426194d20de30a2a52715007','configs/thermal_forced_feedback_manufactured.json':'8fd0727c66ac013a8e2620085b037f5d64bf4d2baeec4b113c350152a89ea637','mhdlab/thermal_forced_feedback_reference.py':'16033899c949896ca346eb6cfb6beb9cdd9d9253c1a110fa9f057a9b8bdeac4d'}
for p,d in expected.items():assert sha(R/p)==d,p
initial=json.loads((W/'parser_guard_checks.initial.json').read_text());final=json.loads((W/'early_numeric_guard_checks.json').read_text())
assert initial['status']=='passed' and initial['rejected_configurations']==16 and initial['accepted_configuration_plans']==1
assert final['status']=='passed' and final['checks_count']==5
assert final['cli_sha256']==expected['tools/run_thermal_forced_feedback_reference.py']
assert final['config_sha256']==expected['configs/thermal_forced_feedback_manufactured.json']
planpaths={'before_run_freeze.json':'63930f1ea42ed6cb7202a8df64bc383d9feac74ef9b49f03933bc371dab98220','oracle_plan.json':'8c5e12f0ae21a86cd452152f3ccbff1d6096c846215e1e35f7980992adfa62dc'}
for name,digest in planpaths.items():assert sha(P/'independent-verification'/name)==digest,name
review=P/'oracle-review/plan_review.json';assert sha(review)=='331e5cae7bb01b0391d4b82be04c8f4f586aaa91d9b0874f7b4410c205092b10'
core_freeze=P/'core/source-freeze.json';assert sha(core_freeze)=='66929baedc0f5591006cabf1eeac800d9dba4838abacc3b3fed67d2333d6df40'
commands=[json.loads(line) for line in (P/'commands.jsonl').read_text().splitlines()]
gates=[x for x in commands if any(arg.startswith('tests/test_thermal_forced_feedback_reference.py') for arg in x['command'])]
assert gates and gates[-1]['exit_code']==0,'new final core test gate not yet passed'
assert not any('tools/run_thermal_forced_feedback_reference.py' in x['command'] for x in commands)
assert not (W/'reference-run').exists()
versions=W/'source-versions';versions.mkdir(exist_ok=True)
for p in (*expected,'mhdlab/thermal_feedback_reference.py','mhdlab/thermal_power_reference.py'):
 shutil.copyfile(R/p,versions/pathlib.Path(p).name)
report={'schema':'mhdlab-forced-feedback-producer-freeze-v1','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'frozen_before_first_positive_batch','public_source_sha256':{p:sha(R/p) for p in (*expected,'mhdlab/thermal_feedback_reference.py','mhdlab/thermal_power_reference.py')},'saved_source_sha256':{str(p.relative_to(W)):sha(p) for p in versions.iterdir()},'parser_evidence':{'initial_report':'parser_guard_checks.initial.json','initial_sha256':sha(W/'parser_guard_checks.initial.json'),'initial_executions':17,'initial_rejected_configs':16,'initial_accepted_plans':1,'final_focused_report':'early_numeric_guard_checks.json','final_sha256':sha(W/'early_numeric_guard_checks.json'),'final_focused_executions':5,'qualification':'Different source versions; focused checks overlap earlier purposes. This is not a claim of22 unique checks.'},'independent_before_run_freeze':{'path':'independent-verification/before_run_freeze.json','sha256':planpaths['before_run_freeze.json']},'independent_plan':{'path':'independent-verification/oracle_plan.json','sha256':planpaths['oracle_plan.json']},'plan_math_review':{'path':'oracle-review/plan_review.json','sha256':sha(review),'acceptance':'Root reported prospective mathematical/fixture/threshold plan accepted before production; no oracle result is claimed.'},'core_source_freeze':{'path':'core/source-freeze.json','sha256':sha(core_freeze)},'core_test_gate':gates[-1],'core_test_execution_history':gates,'core_test_qualification':'Initial new scope had31passes and one redundant fixture assertion outside its already-declared tolerance; test-only assertion correction followed by only that case, core unchanged. Final unique32-check gate reported by test owner before this freeze.','static_core_review_gate':'Root/core author reported completed static review against frozen final source before this freezer was executed.','prior_positive_cli_batches':0,'planned_case_count':4,'planned_numerical_trajectory_count':7,'planned_sample_count':463,'old_evolution_or_producer_calls':False,'production_command':['.venv/bin/python','-W','error','tools/run_thermal_forced_feedback_reference.py','--config','configs/thermal_forced_feedback_manufactured.json','--output-dir',str(W/'reference-run'),'--plot']}
(W/'freeze.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps({'freeze':str(W/'freeze.json'),'sha256':sha(W/'freeze.json'),'status':report['status']},indent=2))
