"""Only the new early-projection guard and directly affected parse paths."""
import hashlib,importlib.util,json,pathlib,sys,tempfile
ROOT=pathlib.Path('/workspace/Power-Flow');W=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('new_forced_parser',ROOT/'tools/run_thermal_forced_feedback_reference.py');cli=importlib.util.module_from_spec(spec);spec.loader.exec_module(cli)
p=ROOT/'configs/thermal_forced_feedback_manufactured.json';text=p.read_text()
checks=[]
with tempfile.TemporaryDirectory(prefix='forced-early-number-') as tmp:
 for name,key,old,new,reason in [('huge_alpha_before_fraction','coverage_coefficient','0','1e100000000','overflows'),('tiny_reference_before_fraction','reference_coverage_m2','4e+20','1e-100000000','underflows'),('tiny_positive_base_barrier','activation_energy_ev','0.25','1e-1000','underflows')]:
  needle=json.dumps(key)+': '+old;assert needle in text
  q=pathlib.Path(tmp)/(name+'.json');q.write_text(text.replace(needle,json.dumps(key)+': '+new,1))
  try:cli.load_config(q)
  except ValueError as exc:assert reason in str(exc);checks.append({'name':name,'outcome':'rejected','reason':str(exc)})
  else:raise RuntimeError(name+' admitted')
 c=cli.load_config(p);assert len(c['cases'])==4
 assert sum(len(x['step_grids']) for x in c['cases'])==7
 checks.append({'name':'approved_raw_plan','outcome':'accepted_without_evolution'})
 # The early guard retains Decimal values; sub-ULP raw gaps remain detectable.
 needle='"start_s": 5e-08';assert needle in text
 q=pathlib.Path(tmp)/'gap.json';q.write_text(text.replace(needle,'"start_s": 5.00000000000000000001e-8',1))
 try:cli.load_config(q)
 except ValueError as exc:assert 'raw decimal schedule' in str(exc);checks.append({'name':'raw_gap_precision_preserved','outcome':'rejected','reason':str(exc)})
 else:raise RuntimeError('raw gap admitted')
assert not any(n in sys.modules for n in ('mhdlab.thermal_forced_feedback_reference','mhdlab.thermal_feedback_reference','mhdlab.thermal_power_reference'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
d={'schema':'mhdlab-forced-feedback-early-numeric-checks-v1','status':'passed','script_sha256':sha(pathlib.Path(__file__)),'cli_sha256':sha(ROOT/'tools/run_thermal_forced_feedback_reference.py'),'config_sha256':sha(p),'checks':checks,'checks_count':5,'evolution_or_core_imports_called':False,'source_change':'Finite/nonzero binary64 numerical lexeme projection is now checked inside Decimal parsing, before exact barrier-domain Fraction arithmetic; Decimal itself remains retained for raw schedule comparisons.','initial_cli_sha256':sha(W/'source-versions/initial_cli_before_early_numeric_guard.py'),'initial_parser_report_sha256':sha(W/'parser_guard_checks.initial.json')}
(W/'early_numeric_guard_checks.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({'status':'passed','checks_count':5,'report_sha256':sha(W/'early_numeric_guard_checks.json'),'cli_sha256':d['cli_sha256']},indent=2))
