"""Read and qualify saved producer artifacts only; no numerical model imports."""
import csv,datetime,hashlib,json,math,pathlib
from fractions import Fraction
W=pathlib.Path(__file__).resolve().parent;P=W.parent;R=pathlib.Path('/workspace/Power-Flow');RUN=W/'reference-run'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
freeze=load(W/'freeze.json');report=load(RUN/'report.json')
assert freeze['prior_positive_cli_batches']==0
for p,digest in freeze['public_source_sha256'].items():assert sha(R/p)==digest,p
assert report['code_sha256']=={p:d for p,d in freeze['public_source_sha256'].items() if p.endswith('.py')}
assert report['config_sha256']==freeze['public_source_sha256']['configs/thermal_forced_feedback_manufactured.json']
assert report['artifact_path_base']=='directory containing report.json'
for p,digest in report['artifact_sha256'].items():assert sha(RUN/p)==digest,p
assert (report['case_count'],report['numerical_trajectory_count'],report['sample_count'])==(4,7,463)
commands=[json.loads(line) for line in (P/'commands.jsonl').read_text().splitlines()]
batches=[x for x in commands if 'tools/run_thermal_forced_feedback_reference.py' in x['command']]
assert len(batches)==1 and batches[0]['exit_code']==0 and batches[0]['command']==freeze['production_command']
config=load(RUN/'input_config.json');cases={c['case_id']:c for c in config['cases']}
row_count=boundary_count=0;finals=[]
for tr in report['trajectories']:
 with (RUN/tr['csv_file']).open() as stream:rows=list(csv.DictReader(stream))
 history=load(RUN/tr['history_file'])
 assert len(rows)==tr['sample_count']==len(history['samples'])==sum(tr['segment_steps'])+1
 assert sha(RUN/tr['csv_file'])==tr['csv_sha256'] and sha(RUN/tr['history_file'])==tr['history_sha256']
 case=cases[tr['case_id']];area=Fraction.from_float(case['problem']['patch_area_m2'])
 indices=[(0,0)]+[(i,j) for i,n in enumerate(tr['segment_steps']) for j in range(1,n+1)]
 prior_n=case['problem']['initial_coverage_m2']
 for row,saved,(i,j) in zip(rows,history['samples'],indices):
  assert int(row['segment_index'])==saved['segment_index']==i
  assert int(row['segment_step'])==saved['segment_step']==j
  assert 0<=saved['coverage_m2']<=prior_n;prior_n=saved['coverage_m2']
  assert case['problem']['temperature_min_k']<=saved['temperature_k']<=case['problem']['temperature_max_k']
  for key,value in saved.items():
   if key=='extensive':
    for ek,ev in value.items():assert float(row[ek])==ev
   else:assert float(row[key])==value
  segment=case['segments'][i]
  a,b=map(Fraction.from_float,(float(segment['start_s']),float(segment['stop_s'])))
  logical=a+(b-a)*j/tr['segment_steps'][i]
  assert float(row['time_s'])==float(logical)
  ein=sum((Fraction.from_float(float(s['power_w_m2']))*(Fraction.from_float(float(s['stop_s']))-Fraction.from_float(float(s['start_s']))) for s in case['segments'][:i]),Fraction())
  ein+=Fraction.from_float(float(segment['power_w_m2']))*(logical-a)
  assert float(row['prescribed_input_energy_j_m2'])==float(ein)
  for key,value in saved.items():
   if key.endswith('_j_m2'):assert saved['extensive'][key[:-3]]==float(Fraction.from_float(value)*area)
  if j==tr['segment_steps'][i]:boundary_count+=1
 final=tr['final_sample']
 finals.append({'case_id':tr['case_id'],'segment_steps':tr['segment_steps'],'sample_count':len(rows),'final_temperature_k':final['temperature_k'],'final_released_m2':final['released_m2'],'final_input_energy_j_m2':final['input_energy_j_m2'],'final_binding_energy_j_m2':final['binding_energy_j_m2'],'final_internal_energy_j_m2':final['internal_energy_j_m2'],'final_translational_energy_j_m2':final['translational_energy_j_m2'],'final_total_wall_energy_debit_j_m2':final['total_wall_energy_debit_j_m2'],'final_wall_thermal_change_j_m2':final['wall_thermal_change_j_m2'],'max_absolute_residuals':tr['max_absolute_residuals']})
 row_count+=len(rows)
assert row_count==463 and boundary_count==15
with (RUN/'temporal_refinement.csv').open() as stream:refinement=list(csv.DictReader(stream))
assert len(refinement)==len(report['temporal_refinement'])==30
orders=[x['observed_self_order'] for x in report['temporal_refinement'] if x['observed_self_order'] is not None]
assert orders and all(math.isfinite(x) for x in orders)
artifacts={str(p.relative_to(P)):sha(p) for p in RUN.iterdir() if p.is_file()}
for p in W.iterdir():
 if p.is_file() and p.name!='completion.json':artifacts[str(p.relative_to(P))]=sha(p)
for p in (W/'source-versions').iterdir():artifacts[str(p.relative_to(P))]=sha(p)
completion={'schema':'mhdlab-forced-feedback-producer-completion-v1','status':'passed_production_and_parser_checks','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'report_path':'producer/reference-run/report.json','report_sha256':sha(RUN/'report.json'),'producer_cli_sha256':sha(R/'tools/run_thermal_forced_feedback_reference.py'),'config_sha256':sha(R/'configs/thermal_forced_feedback_manufactured.json'),'reviewed_source_sha256':freeze['public_source_sha256'],'positive_batch_count':1,'batch':batches[0],'case_count':4,'numerical_trajectory_count':7,'saved_sample_count':463,'temporal_refinement_rows':30,'core_test_execution_history':freeze['core_test_execution_history'],'core_unique_checks':32,'core_gate_qualification':freeze['core_test_qualification'],'independent_plan_and_review':{k:freeze[k] for k in ('independent_before_run_freeze','independent_plan','plan_math_review')},'parser_evidence':freeze['parser_evidence'],'source_versions':{'public_cli_corrections_before_production':1,'correction':'Decimal numeric tokens now qualify finite/nonzero binary64 projection before exact domain Fraction arithmetic; original Decimal still retained for raw schedule equality.','initial_cli_sha256':sha(W/'source-versions/initial_cli_before_early_numeric_guard.py'),'final_cli_sha256':sha(R/'tools/run_thermal_forced_feedback_reference.py'),'initial_parser_executions':17,'final_focused_parser_executions':5,'unique22_checks_claimed':False,'initial_source_snapshot_is_original_captured_bytes':True,'core_unchanged_for_production':True,'positive_model_retries':0},'metadata_freeze_correction':{'initial_freeze_exit_code':1,'reason':'Exact argv membership missed the passing pytest targeted nodeid; initial helper and failed log preserved. Prefix matching corrected the metadata reader before production.','core_cli_config_changed_for_this_fix':False,'model_called_by_freezer':False,'initial_helper_sha256':sha(W/'freeze_producer.initial.py')},'saved_readback':{'all_artifact_hashes_verified':True,'all_463_csv_samples_match_native_history_json':True,'logical_segment_step_stamps_checked':True,'prescribed_input_checked_on_exact_logical_grid':True,'all_energy_extensive_copies_apply_area_once':True,'nonnegative_monotone_inventory_and_declared_Tdomain_checked':True,'shared_completed_segment_boundaries':boundary_count},'trajectories':finals,'resolved_finite_grid_self_order_min':min(orders),'resolved_finite_grid_self_order_max':max(orders),'independent_oracle_result_included_here':False,'artifact_sha256':artifacts,'artifact_path_base':'pass directory containing producer/','open_substantive_findings':[],'old_suites_or_source_evolution_repeated':False,'old_power_or_feedback_evolution_called':False,'limits':['Manufactured positive-base-barrier stationary single-patch finite prescribed-power numerical reference only.','Finite-grid changes are descriptive, with independent saved-only trajectory/channel comparison kept separate.','No physical water or material parameter, monolayer, source history, conduction, phase change, actual MHD, owner solver or host coupling inferred.']}
(W/'completion.json').write_text(json.dumps(completion,indent=2,allow_nan=False)+'\n')
print(json.dumps({'status':completion['status'],'completion_sha256':sha(W/'completion.json'),'report_sha256':completion['report_sha256'],'positive_batch_count':1,'trajectories':7,'samples':463,'refinement_rows':30,'resolved_self_order_range':[min(orders),max(orders)],'final_states':[{k:v for k,v in x.items() if k not in ('max_absolute_residuals',)} for x in finals]},indent=2))
