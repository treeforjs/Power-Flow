"""New positive-barrier forced-feedback parser checks only; no evolution or core imports."""
import copy,hashlib,importlib.util,json,pathlib,sys,tempfile
ROOT=pathlib.Path('/workspace/Power-Flow')
WORK=pathlib.Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('power_cli_parser',ROOT/'tools/run_thermal_forced_feedback_reference.py')
cli=importlib.util.module_from_spec(spec);spec.loader.exec_module(cli)
config_path=ROOT/'configs/thermal_forced_feedback_manufactured.json'
raw=config_path.read_text();base=json.loads(raw)
cases=[]
def mutate(name,edit):
 c=copy.deepcopy(base);edit(c);cases.append((name,json.dumps(c)))
def raw_numeric(name,key,old,new):
 token=json.dumps(key)+': '+old
 assert token in raw
 cases.append((name,raw.replace(token,json.dumps(key)+': '+new,1)))
raw_numeric('positive_cost_lexeme_underflow','desorption_energy_ev','0.12','1e-1000')
raw_numeric('negative_cost_lexeme_underflow','desorption_energy_ev','0.12','-1e-1000')
raw_numeric('positive_power_lexeme_overflow','power_w_m2','60000000.0','1e1000')
raw_numeric('nonfinite_power_lexeme','power_w_m2','60000000.0','NaN')
# These represented decimal differences are smaller than a binary64 ULP.
for name,start in [('raw_gap_collapses_in_float','5.00000000000000000001e-8'),('raw_overlap_collapses_in_float','4.99999999999999999999e-8')]:
 c=copy.deepcopy(base)
 text=json.dumps(c)
 needle='"start_s": 5e-08'
 assert needle in text
 cases.append((name,text.replace(needle,'"start_s": '+start,1)))
c=copy.deepcopy(base)
text=json.dumps(c)
# A complete nonzero raw interval may not collapse to zero binary64 duration.
text=text.replace('"duration_s": 2e-07','"duration_s": 1e-1000',1).replace('"stop_s": 2e-07','"stop_s": 1e-1000',1)
cases.append(('positive_raw_duration_collapses',text))
mutate('missing_final_schedule_support',lambda c:c['cases'][0]['segments'][0].update(stop_s=1e-7))
mutate('negative_prescribed_power',lambda c:c['cases'][0]['segments'][0].update(power_w_m2=-1))
mutate('unsupported_zero_base_activation_energy',lambda c:c['cases'][1]['problem']['reservoir'].update(activation_energy_ev=0))
raw_numeric('positive_activation_lexeme_underflow','activation_energy_ev','0.25','1e-1000')
raw_numeric('negative_activation_lexeme_underflow','activation_energy_ev','0.25','-1e-1000')
raw_numeric('raw_negative_effective_barrier_erased_by_float','coverage_coefficient','0','1.00000000000000000000001')
mutate('boolean_step_count',lambda c:c['cases'][0].update(step_grids=[[True]]))
mutate('missing_segment_step_count',lambda c:c['cases'][3].update(step_grids=[[8,8]]))
cases.append(('duplicate_top_level_key',raw.replace('"parameter_status": "manufactured",','"parameter_status": "manufactured", "parameter_status": "manufactured",',1)))
results=[]
with tempfile.TemporaryDirectory(prefix='power-parser-') as tmp:
 for name,text in cases:
  p=pathlib.Path(tmp)/(name+'.json');p.write_text(text)
  try:cli.load_config(p)
  except (ValueError,TypeError,OverflowError) as exc:results.append({'name':name,'outcome':'rejected','error_type':type(exc).__name__,'reason':str(exc)})
  else:raise RuntimeError('invalid configuration admitted: '+name)
 validated=cli.load_config(config_path)
 assert len(validated['cases'])==4
 assert sum(len(case['step_grids']) for case in validated['cases'])==7
 assert sum(sum(grid)+1 for case in validated['cases'] for grid in case['step_grids'])==463
 assert all(check['raw_adjacency_and_support_checked'] for check in validated['raw_schedule_validation'])
 results.append({'name':'approved_explicit_plan','outcome':'accepted_without_evolution','cases':4,'trajectories':7,'planned_samples':463})
assert not any(name in sys.modules for name in ('mhdlab.thermal_forced_feedback_reference','mhdlab.thermal_feedback_reference','mhdlab.thermal_power_reference'))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
report={'schema':'mhdlab-thermal-forced-feedback-parser-checks-v1','status':'passed','script_sha256':sha(pathlib.Path(__file__)),'cli_sha256':sha(ROOT/'tools/run_thermal_forced_feedback_reference.py'),'config_sha256':sha(config_path),'rejected_configurations':len(cases),'accepted_configuration_plans':1,'checks':results,'evolution_or_core_imports_called':False,'raw_gap_overlap_checks_precede_binary64_projection':True,'raw_effective_barrier_domain_checked_exactly':True,'strictly_positive_activation_required':True}
(WORK/'parser_guard_checks.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
print(json.dumps({'status':'passed','rejected_configurations':len(cases),'accepted_configuration_plans':1,'report_sha256':sha(WORK/'parser_guard_checks.json')},indent=2))
