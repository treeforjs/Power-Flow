"""Commit qualified manufactured forced temperature-dependent release and tests."""
import hashlib
import json
from pathlib import Path
import subprocess

repo=Path('/workspace/Power-Flow')
work=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def run(*args):
    print(json.dumps(list(args)),flush=True)
    subprocess.run(args,cwd=repo,check=True)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()=='3be2c9b7cf9fdc587eb422f42ec06b714f897acb'
assert not subprocess.check_output(['git','diff','--cached','--name-only'],cwd=repo,text=True)
records={
 'tests/completion.json':'071e5afef56f6a2f7ddf0594a18fbbc58f02287b7a51dc71ae1d3c423a373b8f',
 'producer/completion.json':'835bf37391aac90a8495be19b3a2301091934b38af1120a24dbb7a6baccf6b15',
 'independent-verification/completion.json':'856635aedd8f5b8c5559a019bb8d3275fb427d12c6e0ed95b4a18e07cc83a14d',
 'core-review/completion.json':'4a75363faac81b89f29f274486f9d9bcf302741f5a0ec86c80c4da1e62b3ae7d',
 'oracle-review/completion.json':'74f0dc298c48e83c576d768a48a04f6f185c0bf65fc4ee6a9e66df1b679c0fa4',
 'oracle-review/owner_completion_association.json':'c02cf13a34c3e7898babe60d780c9078ce1daf1c792f8f394ec100bb851da4cc'}
for name,digest in records.items():assert sha(work/name)==digest
tests=json.loads((work/'tests/completion.json').read_text())
assert tests['all_checks_passed'] is True and tests['qualified_unique_new_test_cases']==32
assert tests['test_case_executions']==33 and tests['unchanged_passing_cases_repeated']==0
oracle=json.loads((work/'independent-verification/completion.json').read_text())
assert oracle['all_checks_passed'] is True and oracle['independent_oracle_numerical_runs']==1
pins={
 'mhdlab/thermal_forced_feedback_reference.py':'16033899c949896ca346eb6cfb6beb9cdd9d9253c1a110fa9f057a9b8bdeac4d',
 'tests/test_thermal_forced_feedback_reference.py':'6b0c5283b97f1195d4a9b868600b36c4001286b8d7536533b26775f741e8999c'}
for name,digest in pins.items():assert sha(repo/name)==digest
assert tests['public_source_sha256']==pins
run('git','add','--',*pins)
run('git','diff','--cached','--check')
run('git','-c','user.name=Research Development','-c','user.email=research@local.invalid',
 'commit','-m','Add manufactured forced desorption feedback with a positive activation barrier')
run('git','show','--format=fuller','--stat','HEAD')
