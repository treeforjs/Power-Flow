"""Compile helper source text and bind metadata without importing the helpers."""
import ast
import hashlib
import json
from pathlib import Path

work = Path(__file__).resolve().parents[1]
names = ('prepare_delivery.py', 'freeze_delivery.py', 'verify_delivery.py')
trees, pins = {}, {}
for name in names:
    source = (work/name).read_text()
    compile(source, str(work/name), 'exec')
    trees[name] = ast.parse(source)
    pins[name] = hashlib.sha256((work/name).read_bytes()).hexdigest()

def literal(tree, name):
    values = [node.value for node in ast.walk(tree) if isinstance(node, ast.Assign)
        and any(isinstance(target, ast.Name) and target.id == name for target in node.targets)]
    assert len(values) == 1
    return ast.literal_eval(values[0])

approved = '3bd20e44ba617cca44cbac2df993e1face2ec221'
assert literal(trees['prepare_delivery.py'], 'HEAD') == approved
roles = literal(trees['freeze_delivery.py'], 'REPORT_PATHS')
assert len(roles) == 16
readiness = {'schema': 'mitl-thermal-forced-feedback-delivery-helper-readiness-v1',
    'status': 'syntax_and_saved_pin_reads_passed', 'approved_head': approved,
    'base_commit': literal(trees['prepare_delivery.py'], 'BASE'), 'helper_sha256': pins,
    'record_paths': roles,
    'record_sha256': {key: hashlib.sha256((work/name).read_bytes()).hexdigest() for key, name in roles.items()},
    'results': literal(trees['freeze_delivery.py'], 'results'),
    'helpers_imported_or_executed': False, 'assembly_or_freeze_executed': False,
    'science_tests_or_oracle_executed': False, 'portable_execution_claimed': False,
    'package_kind': 'patch_over_exact_complete_baseline',
    'command_snapshot_policy': 'Exact complete-record byte prefix, with immutable archived helper snapshots.',
    'notes': 'Text compilation, AST literal reads and saved-file SHA256 reads only.'}
(work/'delivery-preparation/readiness.json').write_text(json.dumps(readiness, indent=2, allow_nan=False)+'\n')
print(json.dumps(readiness, indent=2, allow_nan=False))
