"""Freeze read-only positive-barrier forced-core scientific/domain review."""
import datetime as dt
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOURCE = Path('/workspace/Power-Flow/mhdlab/thermal_forced_feedback_reference.py')
EXPECTED_SHA = '16033899c949896ca346eb6cfb6beb9cdd9d9253c1a110fa9f057a9b8bdeac4d'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

if (ROOT / 'completion.json').exists():
    raise RuntimeError('Refuse repeated core-review freeze')
status = json.loads(Path('/workspace/research_work/mitl-upstream-status.json').read_text())
assert status['active_lease_owner'] == 'mitl-upstream-20261019T0625'
assert dt.datetime.fromisoformat(status['active_editing_lease_until_utc']) > dt.datetime.now(dt.timezone.utc)
assert sha(SOURCE) == EXPECTED_SHA
checks = [
    ('strict_positive_base_and_fixed_reference_barrier',
     'API snapshots reconstruct validated problem data, reject Ea0<=0 and retain the originally supplied Nref. The exact Fraction complement 1-alpha*N/Nref rejects negative effective barriers.'),
    ('bounded_rate_approximation',
     'Exact rational beta is checked in [0,4096] before evaluation. Beta zero returns exactly one; positive suppression must resolve below one. A fixed Decimal50 context has explicit rounding, exponent bounds and traps.'),
    ('approximation_not_exact_claim',
     'History identifies the Decimal exponential as a numerical approximation and rejects physical-cap or certified-error interpretations. The supported beta interval applies to evaluated nonempty states.'),
    ('coupled_coverage_temperature',
     'Each direct RK4 stage recomputes the Arrhenius factor from its own N and T. No maintained-temperature or analytic thermal trajectory substitutes for either evolved variable.'),
    ('kinetic_barrier_not_energy_debit',
     'Activation energy affects only the kinetic factor. Wall debit is release times independently supplied removal D, internal I and expected translation 2*kB*T.'),
    ('gross_and_signed_channels',
     'The Decimal factor is retained as a Fraction through dt*nu*N, SI costs, signed net thermal increment and RK weights. Exact-zero thermal balance leaves gross positive input and removal channels distinct.'),
    ('domain_and_representation',
     'Original negative Real inputs reject before conversion. Nonzero projection underflow/overflow, positive cumulative stagnation, lost signed state changes, exhaustion, unsupported state stages and nonadvancing times reject without clipping.'),
    ('finite_support_and_jump_endpoint_rule',
     'Revalidated schedule data require exact finite tiling. Logical times use Fraction segment differences and local step counts. All stages in one segment use its power; the next segment carries the same state with its new power.'),
    ('input_integral',
     'Prescribed input uses a separate exact Fraction finite segment integral and is exposed alongside the integrated gross input and residual.'),
    ('energy_reference_signs',
     'Bound adsorbate reference energy is -D*N, gas receives internal plus translation, and total residual is thermal plus inventory bound-reference change plus gas minus external input.'),
    ('area_once',
     'Evolution and channels remain per area. Patch area appears once only in extensive sample projections.'),
    ('data_only_reuse',
     'Only immutable parameter/schedule records and their data validators are reused. No earlier numerical source evolution, spectral/state chemistry, gap, host, MHD or owner method is called.')
]
notes = '''# Positive-barrier forced-core static review

The new forced-feedback core was read in full at the source hash recorded in
completion.json, before its numerical tests or positive producer batch. No
substantive correctness or claims issue was identified and no edits were
requested. Its positive base activation energy and fixed-reference
coverage-dependent kinetic barrier remain separate from the wall removal and
gas internal-energy costs.

Inventory and temperature evolve independently through direct segment-local
RK4 stages. The bounded Decimal50 Arrhenius approximation is retained as a
Fraction before population, energy and signed thermal products, with explicit
underflow, stagnation and domain rejection. A zero signed net thermal change
does not erase gross input or desorption channels. Data snapshots revalidate
problem and schedule declarations without calling earlier numerical methods.
Finite logical time, shared boundary state, segment power and area conversion
follow the stated conventions.

This is source inspection, not a numerical execution, accuracy certificate or
physical validation. Working exponential precision and the supported beta
range do not establish an interval error enclosure or physical barrier cap.
Actual manufactured trajectories, channel comparisons and refinement evidence
still require the separate prospective numerical checks. No physical water,
foil, state chemistry, gap, MHD or host coupling is qualified here.
'''
(ROOT / 'review.md').write_text(notes)
report = {
    'schema': 'mitl-thermal-forced-feedback-static-core-review-v1',
    'status': 'review_complete_no_substantive_issue_identified',
    'completed_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
    'reviewed_source_path': str(SOURCE), 'reviewed_source_sha256': EXPECTED_SHA,
    'full_new_module_read': True, 'source_changes_requested': False, 'findings': [],
    'checks': [{'area': name, 'static_review_complete': True, 'finding': finding} for name, finding in checks],
    'numerical_models_or_tests_executed': False, 'scientific_module_imported': False,
    'producer_or_oracle_executed': False, 'old_numerical_methods_or_audits_repeated': False,
    'public_source_edits_by_reviewer': False, 'physical_parameters_validated': False,
    'host_budget_accepted': False,
    'limits': ['Static scientific/domain/interface source inspection only.',
               'Decimal50 exponential is approximate; no certified error or physical beta cap.',
               'Separate tests, manufactured trajectories and independent reference must supply numerical evidence.',
               'No physical water/material/state-chemistry, host, gap or MHD acceptance.'],
    'artifact_sha256': {p.name: sha(p) for p in sorted(ROOT.iterdir()) if p.is_file()}
}
(ROOT / 'completion.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'completion': str(ROOT / 'completion.json'), 'completion_sha256': sha(ROOT / 'completion.json'),
                  'reviewed_source_sha256': EXPECTED_SHA, 'schema': report['schema'],
                  'status': report['status'], 'numerical_models_or_tests_executed': False}, indent=2))
