# Manufactured forced thermal/inventory reference patch

Five new public files and a patch are pinned to the approved checkout. Apply the
patch to the complete baseline at `3be2c9b7cf9fdc587eb422f42ec06b714f897acb` before importing, running or testing
this reference. This source/ review subset is not a standalone package. No
initializer replacement or portable execution is supplied. The requirements
wrapper copies baseline requirements.txt byte-for-byte; retain the complete
checkout's setup and initializer.

The new reference couples a strictly positive manufactured activation barrier,
fixed-reference coverage-dependent release, finite parent inventory and one
stationary wall temperature under an explicit finite nonnegative power schedule.
Removal, internal energy, expected thermal translation, gross wall debit, input
and signed net thermal changes remain separate. Manufactured inputs do not
establish water/foil calibration, experimental heating, FLASH output or host use.

Fresh tests, parser controls, one saved trajectory batch, a separately developed
transformed coupled-IVP/direct-positive-channel oracle, finite refinement and
signed residuals remain separately pinned. Older zero-power or zero-barrier
passes are not replayed or promoted to evidence for this new reference. Actual
recorded failures, corrections and source versions are preserved. Numerical
changes are estimates, not interval certificates or physical uncertainty.
